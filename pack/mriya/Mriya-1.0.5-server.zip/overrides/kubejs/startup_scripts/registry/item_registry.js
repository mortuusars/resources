StartupEvents.registry('item', event => {
    mriyaStartup.CustomItems.register(event)
})