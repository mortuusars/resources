StartupEvents.registry('fluid', event => {
    event.create('mriya:wine', 'basic')
        .thickTexture(0x7a0006)
        .displayName('Wine')
        .noBlock()
})