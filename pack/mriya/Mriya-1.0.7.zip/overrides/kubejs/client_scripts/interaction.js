BlockEvents.rightClicked(event => {
    const p = event.player;
    const item = p.getItemInHand(event.hand);
})