package io.github.mortuusars.sootychimneys.fabric;

import fuzs.forgeconfigapiport.fabric.api.v5.ConfigRegistry;
import io.github.mortuusars.sootychimneys.Config;
import net.fabricmc.api.ModInitializer;

import io.github.mortuusars.sootychimneys.SootyChimneys;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_6862;
import net.minecraft.class_7706;
import net.minecraft.class_7924;
import net.neoforged.fml.config.ModConfig;

public final class SootyChimneysFabric implements ModInitializer {
    @Override
    public void onInitialize() {
        SootyChimneys.init();

        ConfigRegistry.INSTANCE.register(SootyChimneys.ID, ModConfig.Type.COMMON, Config.Common.SPEC);
        ConfigRegistry.INSTANCE.register(SootyChimneys.ID, ModConfig.Type.CLIENT, Config.Client.SPEC);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(content -> {
            content.method_45421(SootyChimneys.Items.BRICK_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.DIRTY_BRICK_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.COBBLESTONE_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.DIRTY_COBBLESTONE_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.STONE_BRICK_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.DIRTY_STONE_BRICK_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.MUD_BRICK_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.DIRTY_MUD_BRICK_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.IRON_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.DIRTY_IRON_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.COPPER_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.DIRTY_COPPER_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.TERRACOTTA_CHIMNEY.get());
            content.method_45421(SootyChimneys.Items.DIRTY_TERRACOTTA_CHIMNEY.get());
        });

        SootyChimneys.Stats.register();
    }

    public static class Tags {
        public static class Items {
            public static final class_6862<class_1792> SOOT_SCRAPERS = class_6862.method_40092(class_7924.field_41197, SootyChimneys.resource("soot_scrapers"));
        }
    }
}
