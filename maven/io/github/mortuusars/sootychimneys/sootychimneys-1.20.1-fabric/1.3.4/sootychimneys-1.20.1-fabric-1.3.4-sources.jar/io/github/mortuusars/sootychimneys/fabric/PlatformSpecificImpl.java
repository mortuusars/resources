package io.github.mortuusars.sootychimneys.fabric;

import net.minecraft.class_1799;

public class PlatformSpecificImpl {
    public static boolean canBeUsedToScrapeSoot(class_1799 stack) {
        return stack.method_31573(SootyChimneysFabric.Tags.Items.SOOT_SCRAPERS);
    }
}
