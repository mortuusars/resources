package io.github.mortuusars.sootychimneys.fabric.integration.create;

import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import io.github.mortuusars.sootychimneys.Config;
import io.github.mortuusars.sootychimneys.block.ChimneyBlock;
import net.minecraft.class_1937;
import net.minecraft.class_2394;

/**
 * Used to define how blocks should behave on a moving contraption.
 */
public class ChimneyMovementBehaviour implements MovementBehaviour {
    @Override
    public void tick(MovementContext context) {
        class_1937 level = context.world;
        if (level != null && level.field_9236 && context.position != null
                && context.state.method_26204() instanceof ChimneyBlock chimneyBlock
                && chimneyBlock.shouldEmitSmoke(context.state, context.contraption.getContraptionWorld(), context.localPos)
                && level.method_8409().method_43058() < Config.Common.SMOKE_STRENGTH.get()) {
            class_2394 particle = chimneyBlock.getParticle(context.state, context.contraption.getContraptionWorld(), context.localPos);
            chimneyBlock.emitParticle(level, context.position.field_1352, context.position.field_1351, context.position.field_1350, particle);
        }
    }
}