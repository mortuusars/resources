package io.github.mortuusars.sootychimneys.fabric.integration.create;

import com.simibubi.create.api.behaviour.interaction.MovingInteractionBehaviour;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.ContraptionWorld;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import io.github.mortuusars.sootychimneys.block.ChimneyBlock;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3499;
import net.minecraft.class_5819;
import org.apache.commons.lang3.tuple.MutablePair;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

public class ChimneyInteractionBehaviour extends MovingInteractionBehaviour {
    @Override
    public boolean handlePlayerInteraction(class_1657 player, class_1268 activeHand,
                                           class_2338 localPos, AbstractContraptionEntity contraptionEntity) {

        Contraption contraption = contraptionEntity.getContraption();
        ContraptionWorld contraptionLevel = contraption.getContraptionWorld();
        class_2680 state = contraptionLevel.method_8320(localPos);
        if (!(state.method_26204() instanceof ChimneyBlock chimney)) {
            return false;
        }
        @Nullable MutablePair<class_3499.class_3501, MovementContext> actor = contraption.getActorAt(localPos);

        boolean newBlockedValue = !state.method_11654(ChimneyBlock.BLOCKED);
        class_2680 newState = contraptionLevel.method_8320(localPos)
                .method_11657(ChimneyBlock.BLOCKED, newBlockedValue);
        class_3499.class_3501 structureBlockInfo = new class_3499.class_3501(localPos, newState, null);
        if (actor == null) {
            return false;
        }

        actor.setLeft(structureBlockInfo);
        MovementContext context = actor.getRight();
        context.state = newState;

        if (!contraptionLevel.field_9236) {
            contraptionEntity.setBlock(localPos, structureBlockInfo);

            Vector3f particleOrigin = chimney.getType().smokeProperties().getParticleOrigin();
            class_5819 random = player.method_37908().method_8409();
            class_243 pos = context.position;

            player.method_37908().method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, newBlockedValue ? class_3417.field_17746 : class_3417.field_17742, class_3419.field_15245,
                    0.8f, 0.85f + contraptionLevel.field_9229.method_43057() * 0.05f);
            for (int i = 0; i < random.method_43048(5); i++) {
                ((class_3218) player.method_37908()).method_14199(class_2398.field_11251,
                        pos.method_10216() + particleOrigin.x(), pos.method_10214() + particleOrigin.y() - 0.1, pos.method_10215() + particleOrigin.z(),
                        1, random.method_43059() * 0.1d, random.method_43059() * 0.1d, random.method_43059() * 0.1d, 0);
            }
        } else {
            String messageTranslationKey = "message.sootychimneys." + (newBlockedValue ? "blocked" : "open");
            player.method_7353(class_2561.method_43471(messageTranslationKey), true);
        }

        return true;
    }
}