package io.github.mortuusars.sootychimneys.integration.jei.drawable;

import io.github.mortuusars.sootychimneys.utils.Tuple;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableAnimated;
import mezz.jei.api.gui.drawable.IDrawableStatic;
import mezz.jei.api.helpers.IGuiHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec2;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

public class ChimneySmokeAnimatedDrawable implements IDrawableAnimated {
    private final Random random;
    private final List<IDrawable> smokeParticles;
    private final List<Tuple<Vec2, Integer>> currentParticles;

    private float speed = 1f;
    private float intensity = 1f;

    private int animationSpeedTicks = 1;
    private long previousGameTime = 0;

    private int particleAddDelay = 0;

    public ChimneySmokeAnimatedDrawable(IGuiHelper helper) {
        random = new Random();
        smokeParticles = new ArrayList<>();
        currentParticles = new ArrayList<>();

        // Add 11 and 10 to start from smaller particles and create smoother animation:
        IDrawableStatic particle11 = helper.drawableBuilder(Identifier.withDefaultNamespace("textures/particle/big_smoke_11.png"), 0, 0, 16, 16)
                .setTextureSize(16, 16)
                .build();
        smokeParticles.add(particle11);

        IDrawableStatic particle10 = helper.drawableBuilder(Identifier.withDefaultNamespace("textures/particle/big_smoke_10.png"), 0, 0, 16, 16)
                .setTextureSize(16, 16)
                .build();
        smokeParticles.add(particle10);

        for (int i = 0; i < 12; i++) {
            IDrawableStatic particle = helper.drawableBuilder(Identifier.withDefaultNamespace("textures/particle/big_smoke_" + i + ".png"), 0, 0, 16, 16)
                    .setTextureSize(16, 16)
                    .build();
            smokeParticles.add(particle);
        }
    }

    @Override
    public void draw(GuiGraphicsExtractor guiGraphics, int xOffset, int yOffset) {
        calculateAnimationTick();

        for (Tuple<Vec2, Integer> particle : currentParticles) {
            Vec2 pos = particle.getFirst();
            int index = particle.getSecond();

            IDrawable particleFrame = smokeParticles.get(index);

            particleFrame.draw(guiGraphics, (int) (xOffset + pos.x), (int) (yOffset + pos.y));
        }
    }

    private void update() {
        particleAddDelay--;

        if (particleAddDelay <= 0 && currentParticles.size() < (int) (11 * getIntensity())) {
            particleAddDelay = random.nextInt(4, (int)(11 - 5 * getIntensity()));
            currentParticles.add(new Tuple<>(new Vec2((float) random.nextGaussian(), (float) -(random.nextDouble() * 5)), 0));
        }

        List<Tuple<Vec2, Integer>> particlesToRemove = new ArrayList<>();

        for (Tuple<Vec2, Integer> particle : currentParticles) {
            // Update smoke frame and position
            particle.setFirst(particle.getFirst().add(new Vec2(random.nextInt(0, 2), -2 * getSpeed())));
            particle.setSecond(particle.getSecond() + 1);

            if (particle.getSecond() >= smokeParticles.size())
                particlesToRemove.add(particle);
        }

        particlesToRemove.forEach(currentParticles::remove);
    }

    private void calculateAnimationTick() {
        long gameTime = Objects.requireNonNull(Minecraft.getInstance().level).getGameTime();
        if (Math.abs(gameTime - previousGameTime) > animationSpeedTicks) {
            update();
            previousGameTime = gameTime;
        }
    }
    @Override
    public int getWidth() {
        return 16;
    }

    @Override
    public int getHeight() {
        return 16;
    }

    public int getAnimationSpeedTicks() {
        return animationSpeedTicks;
    }
    public void setAnimationSpeedTicks(int ticks) {
        animationSpeedTicks = ticks;
    }
    public float getSpeed() {
        return speed;
    }
    public void setSpeed(float speed) {
        this.speed = speed;
    }
    public float getIntensity() {
        return intensity;
    }
    public void setIntensity(float strength) {
        this.intensity = strength;
    }
}
