package io.github.mortuusars.sootychimneys.fabric;

import fuzs.forgeconfigapiport.fabric.api.v5.ConfigRegistry;
import io.github.mortuusars.sootychimneys.Config;
import net.fabricmc.api.ModInitializer;

import io.github.mortuusars.sootychimneys.SootyChimneys;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.recipe.v1.sync.RecipeSynchronization;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.fml.config.ModConfig;

public final class SootyChimneysFabric implements ModInitializer {
    @Override
    public void onInitialize() {
        SootyChimneys.init();

        ConfigRegistry.INSTANCE.register(SootyChimneys.ID, ModConfig.Type.COMMON, Config.Common.SPEC);
        ConfigRegistry.INSTANCE.register(SootyChimneys.ID, ModConfig.Type.CLIENT, Config.Client.SPEC);

        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS).register(content -> {
            content.accept(SootyChimneys.Items.BRICK_CHIMNEY.get());
            content.accept(SootyChimneys.Items.DIRTY_BRICK_CHIMNEY.get());
            content.accept(SootyChimneys.Items.COBBLESTONE_CHIMNEY.get());
            content.accept(SootyChimneys.Items.DIRTY_COBBLESTONE_CHIMNEY.get());
            content.accept(SootyChimneys.Items.STONE_BRICK_CHIMNEY.get());
            content.accept(SootyChimneys.Items.DIRTY_STONE_BRICK_CHIMNEY.get());
            content.accept(SootyChimneys.Items.MUD_BRICK_CHIMNEY.get());
            content.accept(SootyChimneys.Items.DIRTY_MUD_BRICK_CHIMNEY.get());
            content.accept(SootyChimneys.Items.IRON_CHIMNEY.get());
            content.accept(SootyChimneys.Items.DIRTY_IRON_CHIMNEY.get());
            content.accept(SootyChimneys.Items.COPPER_CHIMNEY.get());
            content.accept(SootyChimneys.Items.DIRTY_COPPER_CHIMNEY.get());
            content.accept(SootyChimneys.Items.TERRACOTTA_CHIMNEY.get());
            content.accept(SootyChimneys.Items.DIRTY_TERRACOTTA_CHIMNEY.get());
        });

        RecipeSynchronization.synchronizeRecipeSerializer(SootyChimneys.RecipeSerializers.SOOT_SCRAPING.get());
    }
}
