package io.github.mortuusars.sootychimneys;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1799;

public class PlatformSpecific {
    @ExpectPlatform
    public static boolean canBeUsedToScrapeSoot(class_1799 stack) {
        throw new AssertionError();
    }
}
