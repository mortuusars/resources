package io.github.mortuusars.sootychimneys.data.wind;

import net.minecraft.class_1937;

public enum TimeOfDay {
    MORNING,
    DAY,
    EVENING,
    NIGHT;

    public static TimeOfDay fromSunAngle(double degrees){
        if (degrees <= 290 && degrees > 270)
            return TimeOfDay.MORNING;
        else if (degrees <= 270 && degrees > 95)
            return TimeOfDay.NIGHT;
        else if (degrees <= 95 && degrees > 75)
            return TimeOfDay.EVENING;
        else
            return TimeOfDay.DAY;
    }

    public static TimeOfDay of(class_1937 level){
        return fromSunAngle((level.method_8442(level.method_8532()) * 180/Math.PI));
    }
}
