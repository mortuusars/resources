package io.github.mortuusars.sootychimneys.integration.jei.drawable;

import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableAnimated;
import mezz.jei.api.gui.drawable.IDrawableStatic;
import mezz.jei.api.helpers.IGuiHelper;
import net.minecraft.class_241;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3545;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

public class ChimneySmokeAnimatedDrawable implements IDrawableAnimated {
    private final Random random;
    private final List<IDrawable> smokeParticles;
    private final List<class_3545<class_241, Integer>> currentParticles;

    private float speed = 1f;
    private float intensity = 1f;

    private int animationSpeedTicks = 1;
    private long previousGameTime = 0;

    private int particleAddDelay = 0;

    public ChimneySmokeAnimatedDrawable(IGuiHelper helper) {
        random = new Random();
        smokeParticles = new ArrayList<>();
        currentParticles = new ArrayList<>();

        // Add 11 and 10 to start from smaller particles and create smoother animation:
        IDrawableStatic particle11 = helper.drawableBuilder(class_2960.method_60656("textures/particle/big_smoke_11.png"), 0, 0, 16, 16)
                .setTextureSize(16, 16)
                .build();
        smokeParticles.add(particle11);

        IDrawableStatic particle10 = helper.drawableBuilder(class_2960.method_60656("textures/particle/big_smoke_10.png"), 0, 0, 16, 16)
                .setTextureSize(16, 16)
                .build();
        smokeParticles.add(particle10);

        for (int i = 0; i < 12; i++) {
            IDrawableStatic particle = helper.drawableBuilder(class_2960.method_60656("textures/particle/big_smoke_" + i + ".png"), 0, 0, 16, 16)
                    .setTextureSize(16, 16)
                    .build();
            smokeParticles.add(particle);
        }
    }

    @Override
    public void draw(class_332 guiGraphics, int xOffset, int yOffset) {
        calculateAnimationTick();

        for (class_3545<class_241, Integer> particle : currentParticles) {
            class_241 pos = particle.method_15442();
            int index = particle.method_15441();

            IDrawable particleFrame = smokeParticles.get(index);

//            guiGraphics.pose().translate(0, 0, 100); // increase z-index so smoke renders above other things

            particleFrame.draw(guiGraphics, (int) (xOffset + pos.field_1343), (int) (yOffset + pos.field_1342));
        }
    }

    private void update() {
        particleAddDelay--;

        if (particleAddDelay <= 0 && currentParticles.size() < (int) (11 * getIntensity())) {
            particleAddDelay = random.nextInt(4, (int)(11 - 5 * getIntensity()));
            currentParticles.add(new class_3545<>(new class_241((float) random.nextGaussian(), (float) -(random.nextDouble() * 5)), 0));
        }

        List<class_3545<class_241, Integer>> particlesToRemove = new ArrayList<>();

        for (class_3545<class_241, Integer> particle : currentParticles) {
            // Update smoke frame and position
            particle.method_34965(particle.method_15441() + 1);
            particle.method_34964(particle.method_15442().method_35586(new class_241(random.nextInt(0, 2), -2 * getSpeed())));

            if (particle.method_15441() >= smokeParticles.size())
                particlesToRemove.add(particle);
        }

        particlesToRemove.forEach(currentParticles::remove);
    }

    private void calculateAnimationTick() {
        long gameTime = Objects.requireNonNull(class_310.method_1551().field_1687).method_8510();
        if (Math.abs(gameTime - previousGameTime) > animationSpeedTicks) {
            update();
            previousGameTime = gameTime;
        }
    }
    @Override
    public int getWidth() {
        return 16;
    }

    @Override
    public int getHeight() {
        return 16;
    }

    public int getAnimationSpeedTicks() {
        return animationSpeedTicks;
    }
    public void setAnimationSpeedTicks(int ticks) {
        animationSpeedTicks = ticks;
    }
    public float getSpeed() {
        return speed;
    }
    public void setSpeed(float speed) {
        this.speed = speed;
    }
    public float getIntensity() {
        return intensity;
    }
    public void setIntensity(float strength) {
        this.intensity = strength;
    }
}
