package io.github.mortuusars.sootychimneys.recipe.result;

import com.google.common.base.Preconditions;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1799;
import net.minecraft.class_5819;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ChanceResult(class_1799 stack, float chance) {
    public static final Codec<ChanceResult> CHANCE_RESULT_ONLY_CODEC = RecordCodecBuilder.create(instance -> instance.group(
                    class_1799.field_24671.fieldOf("item").forGetter(ChanceResult::stack),
                    Codec.FLOAT
                            .optionalFieldOf("chance", 1F)
                            .validate(chance -> {
                                if (Float.isNaN(chance)) {
                                    return DataResult.error(() -> "'chance' cannot be NaN.");
                                } else if (chance <= 0.0)
                                    return DataResult.error(() -> "'chance' '{" + chance + "}' is not valid. Should be larger than 0.");
                                return DataResult.success(chance);
                            })
                            .forGetter(ChanceResult::chance))
            .apply(instance, ChanceResult::new));

    public static final Codec<ChanceResult> CODEC = Codec.either(class_1799.field_24671, CHANCE_RESULT_ONLY_CODEC).xmap(
            itemStackOrChanceResult -> Either.unwrap(itemStackOrChanceResult.mapLeft(ChanceResult::new)),
            chanceResult -> chanceResult.chance() >= 1f ? Either.left(chanceResult.stack()) : Either.right(chanceResult)
    );

    public static final class_9139<class_9129, ChanceResult> STREAM_CODEC = class_9139.method_56435(
            class_1799.field_48349, ChanceResult::stack,
            class_9135.field_48552, ChanceResult::chance,
            ChanceResult::new
    );

    public ChanceResult(class_1799 stack, float chance) {
        Preconditions.checkArgument(!stack.method_7960(), "Item Stack cannot be empty.");
        this.stack = stack;
        Preconditions.checkArgument(!Float.isNaN(chance), "Chance '{}' is not valid. Should not be NaN.", chance);
        Preconditions.checkArgument(chance > 0.0, "Chance '{}' is not valid. Should be larger than 0.", chance);
        this.chance = chance;
    }

    public ChanceResult(class_1799 stack) {
        this(stack, 1f);
    }

    public class_1799 rollOutput(class_5819 rand) {
        int outputAmount = stack.method_7947();
        for (int roll = 0; roll < stack.method_7947(); roll++)
            if (rand.method_43057() > chance)
                outputAmount--;
        if (outputAmount == 0)
            return class_1799.field_8037;
        class_1799 out = stack.method_7972();
        out.method_7939(outputAmount);
        return out;
    }
}
