package io.github.mortuusars.sootychimneys.data;

import net.minecraft.class_265;

public record ChimneyShape(class_265 regular, class_265 stacked) { }
