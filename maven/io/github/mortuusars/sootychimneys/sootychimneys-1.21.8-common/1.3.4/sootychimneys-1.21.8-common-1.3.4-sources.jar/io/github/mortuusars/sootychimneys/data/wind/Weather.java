package io.github.mortuusars.sootychimneys.data.wind;

import net.minecraft.class_1937;

public enum Weather {
    CLEAR,
    RAIN,
    THUNDER;

    public static Weather of(class_1937 level){
        if (level.method_8478(0) > 0.0f)
            return Weather.THUNDER;
        else if (level.method_8430(0) > 0.0f)
            return Weather.RAIN;
        else
            return Weather.CLEAR;
    }
}
