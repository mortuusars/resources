package io.github.mortuusars.sootychimneys.mixin;

import io.github.mortuusars.sootychimneys.Config;
import io.github.mortuusars.sootychimneys.data.wind.Wind;
import io.github.mortuusars.sootychimneys.data.wind.WindData;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2400;
import net.minecraft.class_3922;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3922.class)
public class CampfireParticleMixin {
    @Inject(method = "makeParticles", at = @At("HEAD"), cancellable = true)
    private static void onMakeParticles(class_1937 level, class_2338 pos, boolean isSignalFire, boolean spawnExtraSmoke, CallbackInfo ci) {
        if (!Config.Common.WIND_ENABLED.get() || !Config.Common.WIND_AFFECTS_CAMPFIRE.get()) {
            return;
        }

        WindData wind = Wind.getWind();
        float strength = wind.getAdjustedStrength();
        double xSpeed = wind.getXCoordinate() * strength;
        double zSpeed = wind.getYCoordinate() * strength;

        class_5819 randomSource = level.method_8409();
        class_2400 simpleParticleType = isSignalFire ? class_2398.field_17431 : class_2398.field_17430;
        level.method_17452(
                simpleParticleType,
                true,
                (double)pos.method_10263() + 0.5 + randomSource.method_43058() / 3.0 * (double)(randomSource.method_43056() ? 1 : -1),
                (double)pos.method_10264() + randomSource.method_43058() + randomSource.method_43058(),
                (double)pos.method_10260() + 0.5 + randomSource.method_43058() / 3.0 * (double)(randomSource.method_43056() ? 1 : -1),
                xSpeed,
                0.07,
                zSpeed
        );

        if (spawnExtraSmoke) {
            level.method_8406(
                    class_2398.field_11251,
                    (double)pos.method_10263() + 0.5 + randomSource.method_43058() / 4.0 * (double)(randomSource.method_43056() ? 1 : -1),
                    (double)pos.method_10264() + 0.4,
                    (double)pos.method_10260() + 0.5 + randomSource.method_43058() / 4.0 * (double)(randomSource.method_43056() ? 1 : -1),
                    xSpeed,
                    0.005,
                    zSpeed
            );
        }

        ci.cancel();
    }
}
