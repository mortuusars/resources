package io.github.mortuusars.sootychimneys.integration.jei.recipe;

import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class SootCoveringJeiRecipe {
    private final class_1799 cleanChimneyStack;
    private final class_1799 dirtyChimneyStack;

    public SootCoveringJeiRecipe(class_1792 cleanChimney, class_1792 dirtyChimney) {
        this.cleanChimneyStack = new class_1799(cleanChimney);
        this.dirtyChimneyStack = new class_1799(dirtyChimney);
    }

    public class_1799 getCleanChimney() {
        return cleanChimneyStack;
    }

    public class_1799 getDirtyChimney() {
        return dirtyChimneyStack;
    }
}
