package io.github.mortuusars.sootychimneys.block;

import io.github.mortuusars.sootychimneys.Config;
import io.github.mortuusars.sootychimneys.SootyChimneys;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class ChimneyBlockEntity extends class_2586 {
    public ChimneyBlockEntity(class_2338 pos, class_2680 blockState) {
        super(SootyChimneys.BlockEntityTypes.CHIMNEY.get(), pos, blockState);
    }

    public static <T extends class_2586> void particleTick(class_1937 level, class_2338 blockPos, class_2680 blockState, T ignoredT) {
        if (level.method_8409().method_43058() < Config.Common.SMOKE_STRENGTH.get()
                && blockState.method_26204() instanceof ChimneyBlock chimney
                && chimney.shouldEmitSmoke(blockState, level, blockPos)) {
            class_2394 particle = chimney.getParticle(blockState, level, blockPos);
            chimney.emitParticle(level, blockPos.method_10263() + 0.5, blockPos.method_10264() + 0.5, blockPos.method_10260() + 0.5, particle);
        }
    }
}
