package io.github.mortuusars.sootychimneys.neoforge.datagen.server;

import io.github.mortuusars.sootychimneys.SootyChimneys;
import io.github.mortuusars.sootychimneys.recipe.SootScrapingRecipe;
import io.github.mortuusars.sootychimneys.recipe.result.ChanceResult;
import net.minecraft.advancements.Advancement;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.MultiRegistryBootstrap;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.data.recipes.RecipeProvider;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.Tags;
import org.jspecify.annotations.NonNull;

import java.util.List;
import java.util.Set;

public class RecipesDatagen extends RecipeProvider {
    public RecipesDatagen(
            BootstrapContext<Recipe<?>> recipes,
            BootstrapContext<Advancement> advancements) {
        super(recipes, advancements);
    }

    @Override
    protected void buildRecipes() {
        shaped(RecipeCategory.DECORATIONS, SootyChimneys.Items.BRICK_CHIMNEY.get())
              .define('B', Blocks.BRICKS)
              .define('C', ItemTags.COALS)
              .define('b', Items.BRICK)
              .pattern("b b")
              .pattern("B B")
              .pattern("BCB")
              .unlockedBy("has_brick", has(Items.BRICK))
              .save(output);

        shaped(RecipeCategory.DECORATIONS, SootyChimneys.Items.COBBLESTONE_CHIMNEY.get())
              .define('B', Blocks.COBBLESTONE)
              .define('C', ItemTags.COALS)
              .define('b', Blocks.COBBLESTONE_SLAB)
              .pattern("b b")
              .pattern("B B")
              .pattern("BCB")
              .unlockedBy("has_cobblestone", has(Blocks.COBBLESTONE))
              .save(output);

        shaped(RecipeCategory.DECORATIONS, SootyChimneys.Items.STONE_BRICK_CHIMNEY.get())
              .define('B', Blocks.STONE_BRICKS)
              .define('C', ItemTags.COALS)
              .pattern("B B")
              .pattern("B B")
              .pattern("BCB")
              .unlockedBy("has_stone", has(Items.STONE))
              .save(output);

        shaped(RecipeCategory.DECORATIONS, SootyChimneys.Items.MUD_BRICK_CHIMNEY.get())
              .define('B', Blocks.MUD_BRICKS)
              .define('C', ItemTags.COALS)
              .pattern("B B")
              .pattern("B B")
              .pattern("BCB")
              .unlockedBy("has_mud", has(Items.MUD))
              .save(output);

        shaped(RecipeCategory.DECORATIONS, SootyChimneys.Items.IRON_CHIMNEY.get())
              .define('I', Tags.Items.INGOTS_IRON)
              .define('C', ItemTags.COALS)
              .define('N', Tags.Items.NUGGETS_IRON)
              .pattern("I I")
              .pattern("N N")
              .pattern("ICI")
              .unlockedBy("has_iron", has(Tags.Items.NUGGETS_IRON))
              .save(output);

        shaped(RecipeCategory.DECORATIONS, SootyChimneys.Items.COPPER_CHIMNEY.get())
              .define('I', Tags.Items.INGOTS_COPPER)
              .define('C', ItemTags.COALS)
              .define('B', Tags.Items.STORAGE_BLOCKS_COPPER)
              .pattern("   ")
              .pattern("I I")
              .pattern("BCB")
              .unlockedBy("has_copper", has(Tags.Items.INGOTS_COPPER))
              .save(output);

        shaped(RecipeCategory.DECORATIONS, SootyChimneys.Items.TERRACOTTA_CHIMNEY.get())
              .define('T', Blocks.TERRACOTTA)
              .define('C', ItemTags.COALS)
              .pattern("   ")
              .pattern("T T")
              .pattern("TCT")
              .unlockedBy("has_terracotta", has(Blocks.TERRACOTTA))
              .save(output);

        sootScraping(SootyChimneys.Items.DIRTY_BRICK_CHIMNEY.get(), 0.75f);
        sootScraping(SootyChimneys.Items.DIRTY_COBBLESTONE_CHIMNEY.get(), 0.75f);
        sootScraping(SootyChimneys.Items.DIRTY_STONE_BRICK_CHIMNEY.get(), 0.75f);
        sootScraping(SootyChimneys.Items.DIRTY_MUD_BRICK_CHIMNEY.get(), 0.5f);
        sootScraping(SootyChimneys.Items.DIRTY_IRON_CHIMNEY.get(), 0.5f);
        sootScraping(SootyChimneys.Items.DIRTY_COPPER_CHIMNEY.get(), 0.5f);
        sootScraping(SootyChimneys.Items.DIRTY_TERRACOTTA_CHIMNEY.get(), 0.5f);
    }

    public void sootScraping(ItemLike chimney, float chance) {
        Identifier id = BuiltInRegistries.ITEM.getKey(chimney.asItem()).withPrefix("soot_scraping/");
        output.accept(
              ResourceKey.create(Registries.RECIPE, id),
              new SootScrapingRecipe(Ingredient.of(chimney), List.of(new ChanceResult(new ItemStackTemplate(Items.DYE.black()), chance))),
              null
        );
    }

    public static MultiRegistryBootstrap create() {
        return new MultiRegistryBootstrap() {
            @Override
            public @NonNull Set<ResourceKey<? extends Registry<?>>> requestedRegistries() {
                return Set.of(
                    Registries.RECIPE,
                    Registries.ADVANCEMENT
                );
            }

            @Override
            public void run(@NonNull BootstrapGetter registries) {
                new RecipesDatagen(
                    registries.get(Registries.RECIPE),
                    registries.get(Registries.ADVANCEMENT)
                ).buildRecipes();
            }
        };
    }
}