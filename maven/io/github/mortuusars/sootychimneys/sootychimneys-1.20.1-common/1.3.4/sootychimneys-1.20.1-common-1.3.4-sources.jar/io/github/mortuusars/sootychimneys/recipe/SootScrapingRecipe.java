package io.github.mortuusars.sootychimneys.recipe;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.JsonOps;
import io.github.mortuusars.sootychimneys.SootyChimneys;
import io.github.mortuusars.sootychimneys.block.ChimneyBlock;
import io.github.mortuusars.sootychimneys.data.Chimney;
import io.github.mortuusars.sootychimneys.recipe.ingredient.ChanceResult;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;

import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_3956;
import net.minecraft.class_5455;

public class SootScrapingRecipe implements class_1860<class_1263> {
    public static final int MAX_RESULTS = 3;
    public static final Logger LOGGER = LogUtils.getLogger();

    private final class_2960 id;
    private final class_1856 chimney;
    private final class_2371<ChanceResult> results;

    public SootScrapingRecipe(class_2960 id, class_1856 chimney, class_2371<ChanceResult> results) {
        this.id = id;
        this.chimney = chimney;
        this.results = results;
    }

    @Override
    public boolean method_8118() {
        return true;
    }

    @Override
    public @NotNull class_2960 method_8114() {
        return this.id;
    }

    public class_1856 getIngredientChimney() {
        return chimney;
    }

    public class_1799 getResultChimney() {
        for (class_1799 item : chimney.method_8105()) {
            if (item.method_7909() instanceof class_1747 blockItem
                  && blockItem.method_7711() instanceof ChimneyBlock sootyChimney)
                return new class_1799(Chimney.getCleanBlock(sootyChimney));
        }

        return new class_1799(class_1802.field_8077);
    }

    @Override
    public @NotNull class_2371<class_1856> method_8117() {
        class_2371<class_1856> nonnulllist = class_2371.method_10211();
        nonnulllist.add(this.chimney);
        return nonnulllist;
    }

    public List<ChanceResult> getResults() {
        return results;
    }

    @Override
    public boolean method_8115(class_1263 container, @NotNull class_1937 level) {
        if (container.method_5442()) {
            return false;
        }

        int itemsInContainer = 0;
        boolean chimneyMatched = false;

        for (int i = 0; i < container.method_5439(); i++) {
            class_1799 stack = container.method_5438(i);
            if (!stack.method_7960())
                itemsInContainer++;

            if (chimney.method_8093(stack)) {
                chimneyMatched = true;
            }
        }

        return itemsInContainer <= 2 && chimneyMatched;
    }

    @Override
    public @NotNull class_1799 method_8116(@NotNull class_1263 container, @NotNull class_5455 registryAccess) {
        return getResultChimney();
    }

    @Override
    public boolean method_8113(int pWidth, int pHeight) {
        return false;
    }

    @Override
    public @NotNull class_1799 method_8110(@NotNull class_5455 registryAccess) {
        return getResultChimney();
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return SootyChimneys.RecipeSerializers.SOOT_SCRAPING.get();
    }

    @Override
    public @NotNull class_3956<?> method_17716() {
        return SootyChimneys.RecipeTypes.SOOT_SCRAPING.get();
    }

    public static class Serializer implements class_1865<SootScrapingRecipe> {
        @Override
        public @NotNull SootScrapingRecipe method_8121(@NotNull class_2960 recipeId, @NotNull JsonObject json) {
            final class_1856 chimney = class_1856.method_52177(json.getAsJsonObject("chimney"));

            if (chimney.method_8103()) {
                throw new JsonParseException("No 'chimney' is set for soot scraping recipe");
            } else {
                final class_2371<ChanceResult> results = class_2371.method_10211();
                JsonArray resultsJsonArray = class_3518.method_15261(json, "results");
                for (JsonElement result : resultsJsonArray) {
                    results.add(ChanceResult.CODEC.parse(JsonOps.INSTANCE, result).getOrThrow(false, LOGGER::error));
                }
                if (results.size() > MAX_RESULTS) {
                    throw new JsonParseException("Too many results for soot scraping recipe! The maximum quantity of unique results is " + MAX_RESULTS);
                } else {
                    return new SootScrapingRecipe(recipeId, chimney, results);
                }
            }
        }

        @Override
        public void toNetwork(@NotNull class_2540 buffer, SootScrapingRecipe recipe) {
            recipe.chimney.method_8088(buffer);
            buffer.method_10804(recipe.results.size());
            for (ChanceResult result : recipe.results) {
                result.toBuffer(buffer);
            }
        }

        @Override
        public @NotNull SootScrapingRecipe method_8122(@NotNull class_2960 recipeId, @NotNull class_2540 buffer) {
            class_1856 chimney = class_1856.method_8086(buffer);

            int resultsCount = buffer.method_10816();
            class_2371<ChanceResult> results = class_2371.method_10213(resultsCount, ChanceResult.EMPTY);
            results.replaceAll(ignored -> ChanceResult.fromBuffer(buffer));

            return new SootScrapingRecipe(recipeId, chimney, results);
        }
    }
}