package io.github.mortuusars.sootychimneys.recipe.ingredient;

import com.google.gson.JsonElement;
import com.google.gson.JsonSyntaxException;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_5819;
import net.minecraft.class_7923;

/**
 * Credits to the Create team (and Farmer's Delight) for the implementation of results with chances!
 */
@SuppressWarnings({"deprecation", "ClassCanBeRecord", "Convert2MethodRef"})
public class ChanceResult {
    public static final Codec<ChanceResult> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                // Not using ItemStack.CODEC here. This way json is more intuitive, without one more object.
                class_7923.field_41178.method_39673().fieldOf("item").forGetter(chanceResult -> chanceResult.stack.method_7909()),
                Codec.INT.optionalFieldOf("Count", 1).forGetter(chanceResult -> chanceResult.stack.method_7947()),
                class_2487.field_25128.optionalFieldOf("tag").forGetter(chanceResult -> Optional.ofNullable(chanceResult.stack.method_7969())),
                Codec.FLOAT.optionalFieldOf("chance", 1F).forGetter(ChanceResult::getChance))
          .apply(instance, (item, count, compoundTag, chance) -> {
              class_1799 stack = new class_1799(item, count);
              compoundTag.ifPresent(tag -> stack.method_7980(tag));
              return new ChanceResult(stack, chance);
          }));

    public static final ChanceResult EMPTY = new ChanceResult(class_1799.field_8037, 1);

    private final class_1799 stack;
    private final float chance;

    public ChanceResult(class_1799 stack, float chance) {
        this.stack = stack;

        if (chance == 0 || Float.isNaN(chance))
            throw new IllegalArgumentException("Chance cannot be 0 or NaN.\n" + this.toJson().toString());

        this.chance = chance;
    }

    public class_1799 getStack() {
        return stack;
    }

    public float getChance() {
        return chance;
    }

    public class_1799 rollOutput(class_5819 rand) {
        int outputAmount = stack.method_7947();
        for (int roll = 0; roll < stack.method_7947(); roll++)
            if (rand.method_43057() > chance)
                outputAmount--;
        if (outputAmount == 0)
            return class_1799.field_8037;
        class_1799 out = stack.method_7972();
        out.method_7939(outputAmount);
        return out;
    }

    public JsonElement toJson() {
        return CODEC.encodeStart(JsonOps.INSTANCE, this).getOrThrow(false,
              (String error) -> { throw new IllegalStateException(error); });
    }

    public static ChanceResult fromJson(JsonElement jsonElement) {
        if (!jsonElement.isJsonObject())
            throw new JsonSyntaxException("Must be a json object");

        return CODEC.decode(JsonOps.INSTANCE, jsonElement).getOrThrow(false,
              (String error) -> { throw new IllegalStateException(error); }).getFirst();
    }

    public void toBuffer(class_2540 buf) {
        buf.method_10793(getStack());
        buf.writeFloat(getChance());
    }

    public static ChanceResult fromBuffer(class_2540 buf) {
        return new ChanceResult(buf.method_10819(), buf.readFloat());
    }
}