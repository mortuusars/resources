package io.github.mortuusars.sootychimneys.neoforge.integration.create;

import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import io.github.mortuusars.sootychimneys.Config;
import io.github.mortuusars.sootychimneys.block.ChimneyBlock;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.world.level.Level;

/**
 * Used to define how blocks should behave on a moving contraption.
 */
public class ChimneyMovementBehaviour implements MovementBehaviour {
    @Override
    public void tick(MovementContext context) {
        Level level = context.world;
        if (level != null && level.isClientSide && context.position != null
                && context.state.getBlock() instanceof ChimneyBlock chimneyBlock
                && chimneyBlock.shouldEmitSmoke(context.state, context.world, context.localPos)
                && level.getRandom().nextDouble() < Config.Common.SMOKE_STRENGTH.get()) {
            ParticleOptions particle = chimneyBlock.getParticle(context.state, context.world, context.localPos);
            chimneyBlock.emitParticle(level, context.position.x, context.position.y, context.position.z, particle);
        }
    }
}