package io.github.mortuusars.sootychimneys.forge.integration.create;

import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import io.github.mortuusars.sootychimneys.Config;
import io.github.mortuusars.sootychimneys.block.ChimneyBlock;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.world.level.Level;

/**
 * Used to define how blocks should behave on a moving contraption.
 */
public class ChimneyMovementBehaviour implements MovementBehaviour {
    @Override
    public void tick(MovementContext context) {
        Level level = context.world;
        if (level != null && level.f_46443_ && context.position != null
                && context.state.m_60734_() instanceof ChimneyBlock chimneyBlock
                && chimneyBlock.shouldEmitSmoke(context.state, context.contraption.getContraptionWorld(), context.localPos)
                && level.m_213780_().m_188500_() < Config.Common.SMOKE_STRENGTH.get()) {
            ParticleOptions particle = chimneyBlock.getParticle(context.state, context.contraption.getContraptionWorld(), context.localPos);
            chimneyBlock.emitParticle(level, context.position.f_82479_, context.position.f_82480_, context.position.f_82481_, particle);
        }
    }
}