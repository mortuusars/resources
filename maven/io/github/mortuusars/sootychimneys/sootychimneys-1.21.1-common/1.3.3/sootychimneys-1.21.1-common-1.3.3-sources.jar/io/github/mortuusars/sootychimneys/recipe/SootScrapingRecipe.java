package io.github.mortuusars.sootychimneys.recipe;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.sootychimneys.SootyChimneys;
import io.github.mortuusars.sootychimneys.block.ChimneyBlock;
import io.github.mortuusars.sootychimneys.data.Chimney;
import io.github.mortuusars.sootychimneys.recipe.result.ChanceResult;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9696;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public record SootScrapingRecipe(class_1856 chimney, List<ChanceResult> results) implements class_1860<class_9696> {
    public static final int MAX_RESULTS = 6;

    @Override
    public boolean method_8118() {
        return true;
    }

    public class_1799 getResultChimney() {
        for (class_1799 item : chimney.method_8105()) {
            if (item.method_7909() instanceof class_1747 blockItem
                    && blockItem.method_7711() instanceof ChimneyBlock chimneyBlock
                    && chimneyBlock.isDirty()) {
                class_1792 cleanItem = Chimney.getCleanBlock(chimneyBlock).method_8389();
                return new class_1799(cleanItem);
            }
        }

        return new class_1799(class_1802.field_8077);
    }

    @Override
    public @NotNull class_2371<class_1856> method_8117() {
        class_2371<class_1856> nonnulllist = class_2371.method_10211();
        nonnulllist.add(this.chimney);
        return nonnulllist;
    }

    @Override
    public boolean matches(class_9696 input, class_1937 level) {
        return chimney().method_8093(input.method_59984(0));
    }

    @Override
    public @NotNull class_1799 assemble(class_9696 input, class_7225.class_7874 registries) {
        return getResultChimney();
    }

    @Override
    public boolean method_8113(int width, int height) {
        return false;
    }

    @Override
    public @NotNull class_1799 method_8110(class_7225.class_7874 registries) {
        return this.results.getFirst().stack();
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return SootyChimneys.RecipeSerializers.SOOT_SCRAPING.get();
    }

    @Override
    public @NotNull class_3956<?> method_17716() {
        return SootyChimneys.RecipeTypes.SOOT_SCRAPING.get();
    }

    public static class Serializer implements class_1865<SootScrapingRecipe> {
        public static final MapCodec<SootScrapingRecipe> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                        class_1856.field_46095
                                .fieldOf("chimney")
                                .forGetter(SootScrapingRecipe::chimney),
                        ChanceResult.CODEC.listOf(0, 3)
                                .validate(list -> list.size() <= MAX_RESULTS
                                        ? DataResult.success(list)
                                        : DataResult.error(() -> "SootScrapingRecipe should have at most " + MAX_RESULTS + " results."))
                                .fieldOf("results")
                                .forGetter(SootScrapingRecipe::results))
                .apply(instance, SootScrapingRecipe::new));

        public static final class_9139<class_9129, SootScrapingRecipe> STREAM_CODEC =
                class_9139.method_56435(
                        class_1856.field_48355, SootScrapingRecipe::chimney,
                        ChanceResult.STREAM_CODEC.method_56433(class_9135.method_58000(MAX_RESULTS)), SootScrapingRecipe::results,
                        SootScrapingRecipe::new
                );

        @Override
        public @NotNull MapCodec<SootScrapingRecipe> method_53736() {
            return CODEC;
        }

        @Override
        public @NotNull class_9139<class_9129, SootScrapingRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }
}
