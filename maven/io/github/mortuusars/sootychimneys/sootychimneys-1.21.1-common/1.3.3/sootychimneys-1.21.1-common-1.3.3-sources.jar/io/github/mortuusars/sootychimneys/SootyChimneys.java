package io.github.mortuusars.sootychimneys;

import io.github.mortuusars.sootychimneys.block.ChimneyBlock;
import io.github.mortuusars.sootychimneys.block.ChimneyBlockEntity;
import io.github.mortuusars.sootychimneys.data.Chimney;
import io.github.mortuusars.sootychimneys.data.ChimneyTypes;
import io.github.mortuusars.sootychimneys.recipe.SootScrapingRecipe;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1865;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3446;
import net.minecraft.class_3620;
import net.minecraft.class_3956;
import net.minecraft.class_4970;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class SootyChimneys {
    public static final String ID = "sootychimneys";

    public static void init() {
        Blocks.init();
        BlockEntityTypes.init();
        EntityTypes.init();
        Items.init();
        DataComponents.init();
        MenuTypes.init();
        RecipeTypes.init();
        RecipeSerializers.init();
        CriteriaTriggers.init();
        SoundEvents.init();
        ArgumentTypes.init();
        WorldGenFeatures.init();
        ParticleTypes.init();
    }

//    private void enqueueIMC(final InterModEnqueueEvent event) {
//        if (ModList.get().isLoaded("create")) {
//            CreateIntegration.registerMovingBehaviors();
//        }
//    }

    /**
     * Creates resource location in the mod namespace with the given path.
     */
    public static class_2960 resource(String path) {
        return class_2960.method_60655(ID, path);
    }

    public static class Blocks {
        public static final Supplier<ChimneyBlock> BRICK_CHIMNEY = Register.block("brick_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15987)
                        .method_9626(class_2498.field_29034)
                        .method_9629(2f, 2f)
                        .method_36557(2.2f)
                        .method_29292(), Chimney.State.CLEAN, ChimneyTypes.BRICK));

        public static final Supplier<ChimneyBlock> DIRTY_BRICK_CHIMNEY = Register.block("dirty_brick_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15987)
                        .method_9626(class_2498.field_29034)
                        .method_9629(2f, 2f)
                        .method_36557(2.2f)
                        .method_29292(), Chimney.State.DIRTY, ChimneyTypes.BRICK));

        public static final Supplier<ChimneyBlock> COBBLESTONE_CHIMNEY = Register.block("cobblestone_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15978)
                        .method_9626(class_2498.field_11544)
                        .method_9629(2f, 2f)
                        .method_36557(2.2f)
                        .method_29292(), Chimney.State.CLEAN, ChimneyTypes.COBBLESTONE));

        public static final Supplier<ChimneyBlock> DIRTY_COBBLESTONE_CHIMNEY = Register.block("dirty_cobblestone_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15978)
                        .method_9626(class_2498.field_11544)
                        .method_9629(2f, 2f)
                        .method_36557(2.2f)
                        .method_29292(), Chimney.State.DIRTY, ChimneyTypes.COBBLESTONE));

        public static final Supplier<ChimneyBlock> STONE_BRICK_CHIMNEY = Register.block("stone_brick_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15978)
                        .method_9626(class_2498.field_22143)
                        .method_9629(2f, 2f)
                        .method_36557(2.2f)
                        .method_29292(), Chimney.State.CLEAN, ChimneyTypes.STONE_BRICK));

        public static final Supplier<ChimneyBlock> DIRTY_STONE_BRICK_CHIMNEY = Register.block("dirty_stone_brick_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15978)
                        .method_9626(class_2498.field_22143)
                        .method_9629(2f, 2f)
                        .method_36557(2f)
                        .method_29292(), Chimney.State.DIRTY, ChimneyTypes.STONE_BRICK));

        public static final Supplier<ChimneyBlock> MUD_BRICK_CHIMNEY = Register.block("mud_brick_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15977)
                        .method_9626(class_2498.field_37641)
                        .method_9629(2f, 2f)
                        .method_36557(2.2f)
                        .method_29292(), Chimney.State.CLEAN, ChimneyTypes.MUD_BRICK));

        public static final Supplier<ChimneyBlock> DIRTY_MUD_BRICK_CHIMNEY = Register.block("dirty_mud_brick_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15977)
                        .method_9626(class_2498.field_37641)
                        .method_9629(2f, 2f)
                        .method_36557(2f)
                        .method_29292(), Chimney.State.DIRTY, ChimneyTypes.MUD_BRICK));

        public static final Supplier<ChimneyBlock> IRON_CHIMNEY = Register.block("iron_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15978)
                        .method_9626(class_2498.field_11533)
                        .method_9629(2f, 2f)
                        .method_36557(2.2f)
                        .method_29292(), Chimney.State.CLEAN, ChimneyTypes.IRON));

        public static final Supplier<ChimneyBlock> DIRTY_IRON_CHIMNEY = Register.block("dirty_iron_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15978)
                        .method_9626(class_2498.field_11533)
                        .method_9629(2f, 2f)
                        .method_36557(2f)
                        .method_29292(), Chimney.State.DIRTY, ChimneyTypes.IRON));

        public static final Supplier<ChimneyBlock> COPPER_CHIMNEY = Register.block("copper_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15987)
                        .method_9626(class_2498.field_27204)
                        .method_9629(2f, 2f)
                        .method_36557(2.2f)
                        .method_29292(), Chimney.State.CLEAN, ChimneyTypes.COPPER));

        public static final Supplier<ChimneyBlock> DIRTY_COPPER_CHIMNEY = Register.block("dirty_copper_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15987)
                        .method_9626(class_2498.field_27204)
                        .method_9629(2f, 2f)
                        .method_36557(2f)
                        .method_29292(), Chimney.State.DIRTY, ChimneyTypes.COPPER));

        public static final Supplier<ChimneyBlock> TERRACOTTA_CHIMNEY = Register.block("terracotta_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15987)
                        .method_9626(class_2498.field_28060)
                        .method_9629(2f, 2f)
                        .method_36557(2.2f)
                        .method_29292(), Chimney.State.CLEAN, ChimneyTypes.TERRACOTTA));

        public static final Supplier<ChimneyBlock> DIRTY_TERRACOTTA_CHIMNEY = Register.block("dirty_terracotta_chimney",
                () -> new ChimneyBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_15987)
                        .method_9626(class_2498.field_28060)
                        .method_9629(2f, 2f)
                        .method_36557(2f)
                        .method_29292(), Chimney.State.DIRTY, ChimneyTypes.TERRACOTTA));

        static void init() { }
    }

    public static class BlockEntityTypes {
        public static final Supplier<class_2591<ChimneyBlockEntity>> CHIMNEY = Register.blockEntityType("chimney",
                () -> Register.newBlockEntityType(ChimneyBlockEntity::new,
                        Blocks.BRICK_CHIMNEY.get(),
                        Blocks.DIRTY_BRICK_CHIMNEY.get(),
                        Blocks.COBBLESTONE_CHIMNEY.get(),
                        Blocks.DIRTY_COBBLESTONE_CHIMNEY.get(),
                        Blocks.STONE_BRICK_CHIMNEY.get(),
                        Blocks.DIRTY_STONE_BRICK_CHIMNEY.get(),
                        Blocks.MUD_BRICK_CHIMNEY.get(),
                        Blocks.DIRTY_MUD_BRICK_CHIMNEY.get(),
                        Blocks.IRON_CHIMNEY.get(),
                        Blocks.DIRTY_IRON_CHIMNEY.get(),
                        Blocks.COPPER_CHIMNEY.get(),
                        Blocks.DIRTY_COPPER_CHIMNEY.get(),
                        Blocks.TERRACOTTA_CHIMNEY.get(),
                        Blocks.DIRTY_TERRACOTTA_CHIMNEY.get()));

        static void init() { }
    }

    public static class Items {
        public static final Supplier<class_1747> BRICK_CHIMNEY = Register.item("brick_chimney",
                () -> new class_1747(Blocks.BRICK_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> DIRTY_BRICK_CHIMNEY = Register.item("dirty_brick_chimney",
                () -> new class_1747(Blocks.DIRTY_BRICK_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> COBBLESTONE_CHIMNEY = Register.item("cobblestone_chimney",
                () -> new class_1747(Blocks.COBBLESTONE_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> DIRTY_COBBLESTONE_CHIMNEY = Register.item("dirty_cobblestone_chimney",
                () -> new class_1747(Blocks.DIRTY_COBBLESTONE_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> STONE_BRICK_CHIMNEY = Register.item("stone_brick_chimney",
                () -> new class_1747(Blocks.STONE_BRICK_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> DIRTY_STONE_BRICK_CHIMNEY = Register.item("dirty_stone_brick_chimney",
                () -> new class_1747(Blocks.DIRTY_STONE_BRICK_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> MUD_BRICK_CHIMNEY = Register.item("mud_brick_chimney",
                () -> new class_1747(Blocks.MUD_BRICK_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> DIRTY_MUD_BRICK_CHIMNEY = Register.item("dirty_mud_brick_chimney",
                () -> new class_1747(Blocks.DIRTY_MUD_BRICK_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> IRON_CHIMNEY = Register.item("iron_chimney",
                () -> new class_1747(Blocks.IRON_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> DIRTY_IRON_CHIMNEY = Register.item("dirty_iron_chimney",
                () -> new class_1747(Blocks.DIRTY_IRON_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> COPPER_CHIMNEY = Register.item("copper_chimney",
                () -> new class_1747(Blocks.COPPER_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> DIRTY_COPPER_CHIMNEY = Register.item("dirty_copper_chimney",
                () -> new class_1747(Blocks.DIRTY_COPPER_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> TERRACOTTA_CHIMNEY = Register.item("terracotta_chimney",
                () -> new class_1747(Blocks.TERRACOTTA_CHIMNEY.get(), new class_1792.class_1793()));
        public static final Supplier<class_1747> DIRTY_TERRACOTTA_CHIMNEY = Register.item("dirty_terracotta_chimney",
                () -> new class_1747(Blocks.DIRTY_TERRACOTTA_CHIMNEY.get(), new class_1792.class_1793()));

        static void init() { }
    }

    public static class DataComponents {
        static void init() { }
    }

    public static class MenuTypes {
        static void init() { }
    }

    public static class LootTables {
    }

    public static class CriteriaTriggers {
        public static void init() {
        }
    }

    public static class Stats {
        public static final Map<class_2960, class_3446> STATS = new HashMap<>();

        public static final class_2960 SOOT_SCRAPED = register(resource("soot_scraped"), class_3446.field_16975);

        @SuppressWarnings("SameParameterValue")
        private static class_2960 register(class_2960 location, class_3446 formatter) {
            STATS.put(location, formatter);
            return location;
        }

        public static void register() {
            STATS.forEach((location, formatter) -> {
                class_2378.method_10230(class_7923.field_41183, location, location);
                net.minecraft.class_3468.field_15419.method_14955(location, formatter);
            });
        }
    }

    public static class SoundEvents {
        private static Supplier<class_3414> registerBlockSound(String name) {
            return Register.soundEvent("block." + ID + "." + name,
                    () -> class_3414.method_47908(SootyChimneys.resource("block." + ID + "." + name)));
        }

        static void init() { }
    }

    public static class SoundTypes {
    }

    public static class Tags {
        public static class Items {
            public static final class_6862<class_1792> CHIMNEYS = class_6862.method_40092(class_7924.field_41197, resource("chimneys"));
            public static final class_6862<class_1792> SOOTY_CHIMNEYS = class_6862.method_40092(class_7924.field_41197, resource("sooty_chimneys"));
            public static final class_6862<class_1792> C_CHIMNEYS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("c:chimneys"));
        }

        public static class Blocks {
            public static final class_6862<class_2248> CHIMNEYS = class_6862.method_40092(class_7924.field_41254, resource("chimneys"));
            public static final class_6862<class_2248> SOOTY_CHIMNEYS = class_6862.method_40092(class_7924.field_41254, resource("sooty_chimneys"));
            public static final class_6862<class_2248> C_CHIMNEYS = class_6862.method_40092(class_7924.field_41254, class_2960.method_60654("c:chimneys"));
            public static final class_6862<class_2248> SMOKE_BLOCKING = class_6862.method_40092(class_7924.field_41254, SootyChimneys.resource("smoke_blocking"));
            public static final class_6862<class_2248> SMOKE_BOOSTING = class_6862.method_40092(class_7924.field_41254, SootyChimneys.resource("smoke_boosting"));
        }
    }

    public static class EntityTypes {
        static void init() { }
    }

    public static class RecipeTypes {
        public static final Supplier<class_3956<SootScrapingRecipe>> SOOT_SCRAPING = Register.recipeType("soot_scraping",
                () -> new class_3956<>() {
                    @Override
                    public String toString() {
                        return ID + ":soot_scraping";
                    }
                });

        static void init() { }
    }

    public static class RecipeSerializers {
        public static final Supplier<class_1865<?>> SOOT_SCRAPING =
                Register.recipeSerializer("soot_scraping", SootScrapingRecipe.Serializer::new);

        static void init() { }
    }

    public static class WorldGenFeatures {
        static void init() { }
    }

    public static class ArgumentTypes {
        public static void init() { }
    }

    public static class ParticleTypes {
        public static void init() { }
    }
}
