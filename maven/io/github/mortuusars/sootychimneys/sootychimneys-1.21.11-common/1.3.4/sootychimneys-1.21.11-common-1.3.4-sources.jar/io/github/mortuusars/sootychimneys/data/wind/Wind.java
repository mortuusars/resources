package io.github.mortuusars.sootychimneys.data.wind;

import net.minecraft.class_1937;
import net.minecraft.class_3532;
import net.minecraft.class_5819;

public class Wind {
    private final static WindData wind = new WindData(0, 0f);

    public static WindData getWind() {
        return wind;
    }

    public static void update(class_1937 level) {
        class_5819 random = level.method_8409();

        WindState windState = getWindState(level);

        double addDegrees = windState.max() * (random.method_43048(2) - 1);
        float targetStrength = class_3532.method_37959(random.method_43057(), 0f, 1f, windState.min(), windState.max());
        float strength = class_3532.method_16439(0.1f, wind.getStrength(), targetStrength);

        wind.set(wind.getAngleInDegrees() + addDegrees, strength);
    }

    private static WindState getWindState(class_1937 level) {
        final int day = (int)(level.method_75260() / 24000L);
        final TimeOfDay timeOfDay = TimeOfDay.of(level);
        final Weather weather = Weather.of(level);

        if (weather == Weather.THUNDER) {
            return WindState.STORMY;
        } else if (weather == Weather.RAIN) {
            return timeOfDay != TimeOfDay.EVENING && day % 3 > 0 ? WindState.WINDY : WindState.BREEZE;
        } else if (timeOfDay == TimeOfDay.DAY) {
            return day % 5 > 2 ? WindState.BREEZE : WindState.CALM;
        } else {
            return day % 4 == 0 ? WindState.BREEZE : WindState.CALM;
        }
    }
}
