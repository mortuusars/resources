package io.github.mortuusars.sootychimneys.integration.jei.category;

import io.github.mortuusars.sootychimneys.SootyChimneys;
import io.github.mortuusars.sootychimneys.block.ChimneyBlock;
import io.github.mortuusars.sootychimneys.data.smoke.SmokeProperties;
import io.github.mortuusars.sootychimneys.integration.jei.JeiRecipeTypes;
import io.github.mortuusars.sootychimneys.integration.jei.drawable.ChimneySmokeAnimatedDrawable;
import io.github.mortuusars.sootychimneys.integration.jei.recipe.SootCoveringJeiRecipe;
import io.github.mortuusars.sootychimneys.integration.jei.renderer.ScalableItemStackRenderer;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableStatic;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.recipe.types.IRecipeType;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

import java.util.HashMap;
import java.util.Map;

public class SootCoveringRecipeCategory implements IRecipeCategory<SootCoveringJeiRecipe> {
    public static final int BG_WIDTH = 153;
    public static final int BG_HEIGHT = 65;

    public static final Map<class_1792, Integer> CHIMNEY_SMOKE_Y_ORIGIN = new HashMap<>() {{
        put(SootyChimneys.Items.BRICK_CHIMNEY.get(), 3);
        put(SootyChimneys.Items.DIRTY_BRICK_CHIMNEY.get(), 3);
        put(SootyChimneys.Items.COBBLESTONE_CHIMNEY.get(), 3);
        put(SootyChimneys.Items.DIRTY_COBBLESTONE_CHIMNEY.get(), 3);
        put(SootyChimneys.Items.STONE_BRICK_CHIMNEY.get(), 0);
        put(SootyChimneys.Items.DIRTY_STONE_BRICK_CHIMNEY.get(), 0);
        put(SootyChimneys.Items.MUD_BRICK_CHIMNEY.get(), 3);
        put(SootyChimneys.Items.DIRTY_MUD_BRICK_CHIMNEY.get(), 3);
        put(SootyChimneys.Items.IRON_CHIMNEY.get(), 2);
        put(SootyChimneys.Items.DIRTY_IRON_CHIMNEY.get(), 2);
        put(SootyChimneys.Items.COPPER_CHIMNEY.get(), -1);
        put(SootyChimneys.Items.DIRTY_COPPER_CHIMNEY.get(), -1);
        put(SootyChimneys.Items.TERRACOTTA_CHIMNEY.get(), 10);
        put(SootyChimneys.Items.DIRTY_TERRACOTTA_CHIMNEY.get(), 10);
    }};

    private final class_2561 title;
    private final IDrawableStatic icon;
    private final IDrawableStatic background;
    private final IGuiHelper helper;

    public SootCoveringRecipeCategory(IGuiHelper helper) {
        this.helper = helper;
        title = class_2561.method_43471("jei.sootychimneys.category.soot_covering");

//        Identifier texture = SootyChimneys.resource("textures/gui/jei/soot_covering.png");

        icon = helper.drawableBuilder(SootyChimneys.resource("textures/gui/jei/soot_covering_icon.png"), 0, 0, 16, 16)
                .setTextureSize(16, 16)
                .build();

        background = helper.createDrawable(SootyChimneys.resource("textures/gui/jei/soot_covering.png"), 0, 0, BG_WIDTH, BG_HEIGHT);
    }

    @Override
    public void setRecipe(@NotNull IRecipeLayoutBuilder builder, @NotNull SootCoveringJeiRecipe recipe, @NotNull IFocusGroup focuses) {
        ChimneySmokeAnimatedDrawable ingredientSmoke = createSmokeDrawable(recipe.getCleanChimney());
        Integer yOffset = CHIMNEY_SMOKE_Y_ORIGIN.get(recipe.getCleanChimney().method_7909());
        builder.addSlot(RecipeIngredientRole.INPUT, 10, 18)
                .setCustomRenderer(VanillaTypes.ITEM_STACK, new ScalableItemStackRenderer(2.5f))
                .setOverlay(ingredientSmoke, (int) ((16 * 2.5f) / 2 - 8), yOffset)
                .add(recipe.getCleanChimney())
                .setSlotName("CleanChimney");

        ChimneySmokeAnimatedDrawable resultSmoke = createSmokeDrawable(recipe.getDirtyChimney());
        Integer yOffset1 = CHIMNEY_SMOKE_Y_ORIGIN.get(recipe.getDirtyChimney().method_7909());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 103, 18)
                .setCustomRenderer(VanillaTypes.ITEM_STACK, new ScalableItemStackRenderer(2.5f))
                .setOverlay(resultSmoke, (int) ((16 * 2.5f) / 2 - 8), yOffset1)
                .add(recipe.getDirtyChimney())
                .setSlotName("DirtyChimney");
    }

    private ChimneySmokeAnimatedDrawable createSmokeDrawable(class_1799 chimney) {
        ChimneySmokeAnimatedDrawable drawable = new ChimneySmokeAnimatedDrawable(helper);

        if (chimney.method_7909() instanceof class_1747 blockItem
                && blockItem.method_7711() instanceof ChimneyBlock chimneyBlock) {
            SmokeProperties smokeProperties = chimneyBlock.getType().smokeProperties();
            drawable.setSpeed(smokeProperties.getSpeed());
            drawable.setIntensity(smokeProperties.getIntensity());
        }

        return drawable;
    }

    @Override
    public void draw(SootCoveringJeiRecipe recipe, @NonNull IRecipeSlotsView recipeSlotsView, @NonNull class_332 guiGraphics, double mouseX, double mouseY) {
        background.draw(guiGraphics);
    }

    @Override
    public @NotNull class_2561 getTitle() {
        return title;
    }

    @Override
    public int getWidth() {
        return BG_WIDTH;
    }

    @Override
    public int getHeight() {
        return BG_HEIGHT;
    }

    @Override
    public @NotNull IDrawable getIcon() {
        return icon;
    }

    @Override
    public @NotNull IRecipeType<SootCoveringJeiRecipe> getRecipeType() {
        return JeiRecipeTypes.SOOT_COVERING;
    }
}
