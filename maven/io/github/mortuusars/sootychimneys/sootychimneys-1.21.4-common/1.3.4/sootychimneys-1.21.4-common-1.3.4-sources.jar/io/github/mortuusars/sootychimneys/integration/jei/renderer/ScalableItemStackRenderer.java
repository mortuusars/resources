package io.github.mortuusars.sootychimneys.integration.jei.renderer;

import com.mojang.logging.LogUtils;
import mezz.jei.api.ingredients.IIngredientRenderer;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class ScalableItemStackRenderer implements IIngredientRenderer<class_1799> {
    private final float xScale;
    private final float yScale;
    private final float zScale;

    public ScalableItemStackRenderer(float scale) {
        this.xScale = scale;
        this.yScale = scale;
        this.zScale = scale;
    }

    @Override
    public void render(class_332 guiGraphics, class_1799 ingredient) {
        if (ingredient != null) {
            guiGraphics.method_51448().method_22903();
            {
                guiGraphics.method_51448().method_22905(xScale, yScale, zScale);
                guiGraphics.method_51427(ingredient, 0, 0);
            }
            guiGraphics.method_51448().method_22909();
        }
    }

    @Override
    public int getWidth() {
        return ((int) (xScale * 16));
    }

    @Override
    public int getHeight() {
        return ((int) (yScale * 16));
    }

    @Override
    public @NotNull List<class_2561> getTooltip(class_1799 ingredient, class_1836 tooltipFlag) {
        class_310 minecraft = class_310.method_1551();
        class_1657 player = minecraft.field_1724;
        try {
            return ingredient.method_7950(class_1792.class_9635.method_59528(Objects.requireNonNull(player).method_37908()), player, tooltipFlag);
        } catch (Exception e) {
            LogUtils.getLogger().error("Failed to get tooltip: {}", ingredient, e);
            return Collections.emptyList();
        }
    }
}
