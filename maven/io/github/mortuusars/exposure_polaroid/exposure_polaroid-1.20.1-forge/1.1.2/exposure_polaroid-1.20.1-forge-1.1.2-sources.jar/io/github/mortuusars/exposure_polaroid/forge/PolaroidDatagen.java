package io.github.mortuusars.exposure_polaroid.forge;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure_polaroid.ExposurePolaroid;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.DisplayInfo;
import net.minecraft.advancements.FrameType;
import net.minecraft.advancements.critereon.InventoryChangeTrigger;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.PackOutput;
import net.minecraft.data.recipes.FinishedRecipe;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.data.recipes.RecipeProvider;
import net.minecraft.data.recipes.ShapedRecipeBuilder;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Items;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.common.data.ForgeAdvancementProvider;
import net.minecraftforge.data.event.GatherDataEvent;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public class PolaroidDatagen {
    public static void gather(GatherDataEvent event) {
        DataGenerator dataGenerator = event.getGenerator();
        PackOutput packOutput = dataGenerator.getPackOutput();
        CompletableFuture<HolderLookup.Provider> lookupProvider = event.getLookupProvider();
        ExistingFileHelper existingFileHelper = event.getExistingFileHelper();
        dataGenerator.addProvider(true,new PolaroidAdvancements(packOutput,lookupProvider,existingFileHelper,List.of(new PolaroidAdvancements.Adventure())));
        dataGenerator.addProvider(true,new PolaroidRecipes(packOutput));
    }

    static class PolaroidAdvancements extends ForgeAdvancementProvider {
        public PolaroidAdvancements(PackOutput output, CompletableFuture<HolderLookup.Provider> registries, ExistingFileHelper existingFileHelper, List<AdvancementGenerator> subProviders) {
            super(output, registries, existingFileHelper, subProviders);
        }

        static class Adventure implements AdvancementGenerator {

            @Override
            public void generate(HolderLookup.Provider arg, Consumer<Advancement> consumer, ExistingFileHelper existingFileHelper) {
                Advancement advancement = Advancement.Builder.m_138353_()
                        .m_138396_(Exposure.resource("adventure/exposure"))
                        .m_138358_(new DisplayInfo(ExposurePolaroid.Items.INSTANT_CAMERA.get().m_7968_(),
                                Component.m_237115_("advancement.exposure_polaroid.instant_classic.title"),
                                Component.m_237115_("advancement.exposure_polaroid.instant_classic.description"),null, FrameType.TASK,true,true,false))
                        .m_138386_("get_instant_camera", InventoryChangeTrigger.TriggerInstance.m_43199_(ExposurePolaroid.Items.INSTANT_CAMERA.get()))
                        .save(consumer,
                        ExposurePolaroid.resource("adventure/instant_classic"),existingFileHelper);
            }
        }

    }


    static class PolaroidRecipes extends RecipeProvider {
        public PolaroidRecipes(PackOutput output) {
            super(output);
        }

        @Override
        protected void m_245200_(Consumer<FinishedRecipe> writer) {
            ShapedRecipeBuilder.m_245327_(RecipeCategory.MISC,ExposurePolaroid.Items.INSTANT_CAMERA.get())
                    .m_206416_('B', ItemTags.f_13171_)
                    .m_126127_('G', Items.f_42027_)
                    .m_126127_('I', Items.f_42416_)
                    .m_206416_('F', Exposure.Tags.Items.FLASHES)
                    .m_126127_('C', Items.f_41960_)
                    .m_126130_("III")
                    .m_126130_("BGF")
                    .m_126130_("ICI")
                    .m_126132_(m_176602_(Items.f_42416_),m_125977_(Items.f_42416_))
                    .m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.MISC,ExposurePolaroid.Items.INSTANT_BLACK_AND_WHITE_SLIDE.get())
                    .m_126127_('B', Items.f_42499_)
                    .m_126127_('K', Items.f_42498_)
                    .m_126127_('P', Items.f_42516_)
                    .m_126130_("BKB")
                    .m_126130_("PPP")
                    .m_126132_(m_176602_(Items.f_42498_),m_125977_(Items.f_42498_))
                    .m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.MISC,ExposurePolaroid.Items.HIGH_SENSITIVITY_INSTANT_BLACK_AND_WHITE_SLIDE.get())
                    .m_126127_('B', Items.f_42499_)
                    .m_126127_('K', Items.f_42498_)
                    .m_126127_('C', Items.f_42696_)
                    .m_126127_('P', Items.f_42516_)
                    .m_126130_("BKC")
                    .m_126130_("PPP")
                    .m_126132_(m_176602_(Items.f_42498_),m_125977_(Items.f_42498_))
                    .m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.MISC,ExposurePolaroid.Items.INSTANT_COLOR_SLIDE.get())
                    .m_126127_('L', Items.f_42534_)
                    .m_126127_('K', Items.f_42498_)
                    .m_126127_('C', Items.f_42492_)
                    .m_126127_('M', Items.f_42537_)
                    .m_126127_('Y', Items.f_42539_)
                    .m_126127_('P', Items.f_42516_)
                    .m_126130_("LKL")
                    .m_126130_("CMY")
                    .m_126130_("PPP")
                    .m_126132_(m_176602_(Items.f_42498_),m_125977_(Items.f_42498_))
                    .m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.MISC,ExposurePolaroid.Items.HIGH_SENSITIVITY_INSTANT_COLOR_SLIDE.get())
                    .m_126127_('L', Items.f_42534_)
                    .m_126127_('K', Items.f_42498_)
                    .m_126127_('C', Items.f_42492_)
                    .m_126127_('M', Items.f_42537_)
                    .m_126127_('Y', Items.f_42539_)
                    .m_126127_('P', Items.f_42516_)
                    .m_126127_('R', Items.f_42696_)
                    .m_126130_("LKR")
                    .m_126130_("CMY")
                    .m_126130_("PPP")
                    .m_126132_(m_176602_(Items.f_42498_),m_125977_(Items.f_42498_))
                    .m_176498_(writer);
        }
    }
}
