package io.github.mortuusars.exposure_polaroid.client.camera.viewfinder;

import io.github.mortuusars.exposure.client.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.client.camera.viewfinder.ViewfinderCameraControlsScreen;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure_polaroid.ExposurePolaroid;
import io.github.mortuusars.exposure_polaroid.client.gui.screen.camera.button.ExposureSliderButton;
import io.github.mortuusars.exposure_polaroid.client.gui.screen.camera.button.SlideCounterWidget;
import io.github.mortuusars.exposure_polaroid.client.gui.screen.camera.button.ZoomWidget;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_7919;
import net.minecraft.class_8666;

public class InstantCameraControlsScreen extends ViewfinderCameraControlsScreen {
    public static final class_8666 ZOOM_SPRITES = new class_8666(
            ExposurePolaroid.resource("camera_controls/zoom"),
            ExposurePolaroid.resource("camera_controls/zoom_disabled"),
            ExposurePolaroid.resource("camera_controls/zoom_highlighted"));

    public static final class_8666 SLIDE_COUNTER_SPRITES = new class_8666(
            ExposurePolaroid.resource("camera_controls/slide_counter"),
            ExposurePolaroid.resource("camera_controls/slide_counter_disabled"),
            ExposurePolaroid.resource("camera_controls/slide_counter_highlighted"));

    protected static final int SIDE_BUTTONS_WIDTH = 49;

    public InstantCameraControlsScreen(Camera camera, Viewfinder viewfinder) {
        super(camera, viewfinder);
    }

    @Override
    protected void method_25426() {
        refreshMovementKeys();

        leftPos = (field_22789 - 256) / 2;
        topPos = Math.round(viewfinder.overlay().getOpening().y + viewfinder.overlay().getOpening().height - 256);

        boolean hasFlash = camera.map((i, s) -> i.getFlash().isAvailable(s)).orElse(false);

        int widgetsWidth = SIDE_BUTTONS_WIDTH + 1 + BUTTON_WIDTH + 1 + (hasFlash ? BUTTON_WIDTH + 1 : 0) + SIDE_BUTTONS_WIDTH;

        int elementX = leftPos + 128 - (widgetsWidth / 2);
        int elementY = topPos + 238;

        // Order of adding influences TAB key behavior

        class_4185 exposureSliderButton = createExposureSliderButton(elementY);
        method_37063(exposureSliderButton);

        ZoomWidget zoomWidget = new ZoomWidget(elementX, elementY, SIDE_BUTTONS_WIDTH, BUTTON_HEIGHT, ZOOM_SPRITES, camera);
        zoomWidget.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure_polaroid.camera_controls.zoom.tooltip")));
        method_37060(zoomWidget);
        elementX += zoomWidget.method_25368();

        addSeparator(elementX, elementY);
        elementX += SEPARATOR_WIDTH;

        class_4185 selfTimerButton = createSelfTimerButton();
        selfTimerButton.method_46421(elementX);
        selfTimerButton.method_46419(elementY);
        method_37063(selfTimerButton);
        elementX += selfTimerButton.method_25368();

        addSeparator(elementX, elementY);
        elementX += SEPARATOR_WIDTH;

        if (hasFlash) {
            class_4185 flashModeButton = createFlashModeButton();
            flashModeButton.method_46421(elementX);
            flashModeButton.method_46419(elementY);
            method_37063(flashModeButton);
            elementX += flashModeButton.method_25368();

            addSeparator(elementX, elementY);
            elementX += SEPARATOR_WIDTH;
        }

        SlideCounterWidget slideCounterWidget = new SlideCounterWidget(elementX, elementY, SIDE_BUTTONS_WIDTH, BUTTON_HEIGHT, SLIDE_COUNTER_SPRITES, camera);
        method_37060(slideCounterWidget);
    }

    protected class_4185 createExposureSliderButton(int elementY) {
        ExposureSliderButton exposureSliderButton = new ExposureSliderButton(leftPos + 88, elementY - 15, camera);
        exposureSliderButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure_polaroid.camera_controls.exposure_slider.tooltip")));
        return exposureSliderButton;
    }
}