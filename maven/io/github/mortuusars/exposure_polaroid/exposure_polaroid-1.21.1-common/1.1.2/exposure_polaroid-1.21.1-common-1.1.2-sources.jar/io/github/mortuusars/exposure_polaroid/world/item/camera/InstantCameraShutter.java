package io.github.mortuusars.exposure_polaroid.world.item.camera;

import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.item.camera.Shutter;
import io.github.mortuusars.exposure.world.sound.Sound;
import io.github.mortuusars.exposure_polaroid.ExposurePolaroid;
import net.minecraft.class_1297;

public class InstantCameraShutter extends Shutter {
    @Override
    public void playOpenSound(CameraHolder holder) {
        class_1297 entity = holder.asHolderEntity();
        Sound.play(entity, ExposurePolaroid.SoundEvents.INSTANT_CAMERA_RELEASE.get(), entity.method_5634(), 1.2f, 1.0f, 0.2f);
    }

    @Override
    public void playCloseSound(CameraHolder holder) {
    }
}
