package io.github.mortuusars.exposure_polaroid.world.item;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.data.Lenses;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.clientbound.CaptureStartS2CP;
import io.github.mortuusars.exposure.server.CameraInstances;
import io.github.mortuusars.exposure.util.ExtraData;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.world.camera.capture.CaptureProperties;
import io.github.mortuusars.exposure.world.camera.capture.ProjectionInfo;
import io.github.mortuusars.exposure.world.camera.component.FocalRange;
import io.github.mortuusars.exposure.world.camera.component.ShutterSpeed;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.item.FilmItem;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import io.github.mortuusars.exposure.world.item.StackedPhotographsItem;
import io.github.mortuusars.exposure.world.item.camera.Attachment;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import io.github.mortuusars.exposure.world.item.camera.CameraSettings;
import io.github.mortuusars.exposure.world.item.camera.Shutter;
import io.github.mortuusars.exposure.world.item.component.StoredItemStack;
import io.github.mortuusars.exposure.world.item.util.ItemAndStack;
import io.github.mortuusars.exposure.world.level.LevelUtil;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import io.github.mortuusars.exposure.world.sound.Sound;
import io.github.mortuusars.exposure_polaroid.Config;
import io.github.mortuusars.exposure_polaroid.ExposurePolaroid;
import io.github.mortuusars.exposure_polaroid.world.camera.PolaroidFrameExtraData;
import io.github.mortuusars.exposure_polaroid.world.item.camera.InstantCameraAttachment;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import net.minecraft.class_6880;

public class InstantCameraItem extends CameraItem {
    public static final class_2960 CAPTURE_TYPE = ExposurePolaroid.resource("instant_camera");

    public InstantCameraItem(Shutter shutter, class_1793 properties) {
        super(shutter, properties);
    }

    protected @NotNull List<Attachment<?>> defineAttachments() {
        return List.of(InstantCameraAttachment.INSTANT_SLIDE);
    }

    protected List<ShutterSpeed> defineShutterSpeeds() {
        return List.of(
                new ShutterSpeed("1/125"),
                new ShutterSpeed("1/103"),
                new ShutterSpeed("1/81"),
                new ShutterSpeed("1/60"),
                new ShutterSpeed("1/41"),
                new ShutterSpeed("1/30"),
                new ShutterSpeed("1/20")
        );
    }

    // --

    @Override
    public class_2960 getCaptureType(class_1799 stack) {
        return CAPTURE_TYPE;
    }

    @Override
    public class_3414 getViewfinderOpenSound() {
        return ExposurePolaroid.SoundEvents.INSTANT_CAMERA_VIEWFINDER_OPEN.get();
    }

    @Override
    public class_3414 getViewfinderCloseSound() {
        return ExposurePolaroid.SoundEvents.INSTANT_CAMERA_VIEWFINDER_CLOSE.get();
    }

    @Override
    protected Optional<ProjectionInfo> getProjectionInfo(class_1799 stack) {
        return Optional.empty();
    }

    @Override
    public class_6880<ColorPalette> getColorPalette(class_5455 registryAccess, class_1799 stack) {
        class_5321<ColorPalette> key = InstantCameraAttachment.INSTANT_SLIDE.map(stack, FilmItem::getColorPaletteId)
                .orElse(ColorPalettes.DEFAULT);
        return ColorPalettes.get(registryAccess, key);
    }

    @Override
    public FocalRange getFocalRange(class_5455 registryAccess, class_1799 stack) {
        // Even though you can't install lens in survival, it can be added as a component to create camera with custom focal range.
        if (!Attachment.LENS.isEmpty(stack)) {
            return Attachment.LENS.map(stack, lensStack -> Lenses.getFocalRange(registryAccess, lensStack)
                            .orElse(FocalRange.parse(Config.Server.INSTANT_CAMERA_FOCAL_RANGE.get())))
                    .orElse(FocalRange.parse(Config.Server.INSTANT_CAMERA_FOCAL_RANGE.get()));
        }
        return FocalRange.parse(Config.Server.INSTANT_CAMERA_FOCAL_RANGE.get());
    }

    @Override
    public double getYPositionOffset(class_1799 stack) {
        return 0;
    }

    @Override
    public float getCropFactor() {
        return 0.75f;
    }

    public int getMaxSlideCount() {
        return Config.Server.INSTANT_CAMERA_SLIDE_CAPACITY.get();
    }

    public int getRemainingSlides(class_1799 stack) {
        return InstantCameraAttachment.INSTANT_SLIDE.get(stack).getForReading().method_7947();
    }

    @Override
    public boolean hasFlash(class_1799 stack) {
        return true;
    }

    // --

    @Override
    public boolean method_31567(@NotNull class_1799 stack) {
        return Config.Client.INSTANT_CAMERA_SHOW_FULLNESS_BAR_ON_ITEM.get() && !InstantCameraAttachment.INSTANT_SLIDE.isEmpty(stack);
    }

    @Override
    public int method_31569(@NotNull class_1799 stack) {
        return InstantCameraAttachment.INSTANT_SLIDE.map(stack, this::getSlideFullness).orElse(0);
    }

    protected int getSlideFullness(class_1799 stack) {
        return Math.min(1 + 12 * stack.method_7947() / getMaxSlideCount(), 13);
    }

    @Override
    public int method_31571(@NotNull class_1799 stack) {
        class_1799 slide = InstantCameraAttachment.INSTANT_SLIDE.get(stack).getForReading();
        int max = getMaxSlideCount();
        float f = Math.max(0.0F, ((float) slide.method_7947()) / (float) max);
        return class_3532.method_15369(f / 3.0F, 1.0F, 1.0F);
    }

    // --

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> components, class_1836 tooltipFlag) {
        if (Config.Client.INSTANT_CAMERA_SHOW_SLIDES_COUNT_IN_TOOLTIP.get()) {
            InstantCameraAttachment.INSTANT_SLIDE.ifPresent(stack, (slideItem, slideStack) -> {
                int exposed = slideStack.method_7947();
                int max = getMaxSlideCount();
                components.add(class_2561.method_43469("item.exposure_polaroid.instant_camera.tooltip.slides", exposed, max));
            });
        }

        if (Config.Client.INSTANT_CAMERA_SHOW_TOOLTIP_DETAILS.get()) {
            if (class_437.method_25442()) {
                components.add(class_2561.method_43471("item.exposure_polaroid.instant_camera.tooltip.details_insert"));
            } else {
                components.add(class_2561.method_43471("tooltip.exposure.hold_for_details"));
            }
        }
    }

    @Override
    public boolean method_31566(class_1799 stack, class_1799 otherStack, class_1735 slot, class_5536 action, class_1657 player, class_5630 access) {
        if (action != class_5536.field_27014 || !slot.method_32754(player)) return false;

        StoredItemStack slide = InstantCameraAttachment.INSTANT_SLIDE.get(stack);

        if (InstantCameraAttachment.INSTANT_SLIDE.matches(otherStack)) {
            class_1799 storedStack = slide.getForReading();
            int availableSlots = Math.max(0, getMaxSlideCount() - storedStack.method_7947());

            if (availableSlots == 0 || (!storedStack.method_7960() && !class_1799.method_31577(storedStack, otherStack))) {
                player.method_5783(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), 0.9f, 1f);
                return true;
            }

            class_1799 insertedStack = otherStack.method_7971(availableSlots);
            insertedStack.method_7939(insertedStack.method_7947() + storedStack.method_7947());
            InstantCameraAttachment.INSTANT_SLIDE.set(stack, insertedStack);
            InstantCameraAttachment.INSTANT_SLIDE.playInsertSoundSided(player);

            // For some unknown reason, inserting slides when camera already has some does not sync it to the server.
            // But only if the player is in "inventory" tab of creative inventory.
            // This fixes it:
            if (player.method_7337()) {
                Minecrft.gameMode().method_2909(stack, slot.field_7874);
            }

            return true;
        }

        if (otherStack.method_7960() && !slide.isEmpty() && !player.method_7357().method_7904(this)) {
            access.method_32332(slide.getCopy());
            InstantCameraAttachment.INSTANT_SLIDE.set(stack, class_1799.field_8037);
            player.method_37908().method_43129(player, player, Exposure.SoundEvents.CAMERA_GENERIC_CLICK.get(),
                    class_3419.field_15248, 0.5f, 0.7f);
            return true;
        }

        return false;
    }

    @Override
    public int calculateCooldownAfterShot(class_1799 stack, CaptureProperties captureProperties) {
        return 40;
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 level, class_1297 entity, int slotId, boolean isSelected) {
        super.method_7888(stack, level, entity, slotId, isSelected);

        if (!(entity instanceof class_1657 player)) return;

        @Nullable Frame frame = stack.method_57824(Exposure.DataComponents.PHOTOGRAPH_FRAME);
        if (!player.method_7357().method_7904(stack.method_7909()) && frame != null) {
            stack.method_57381(Exposure.DataComponents.PHOTOGRAPH_FRAME);
            printPhotograph(stack, level, player, frame);
        }
    }

    private static void printPhotograph(class_1799 stack, class_1937 level, class_1657 player, Frame frame) {
        if (!player.method_7337()) {
            class_1799 slide = InstantCameraAttachment.INSTANT_SLIDE.get(stack).getCopy();
            slide.method_7934(1);
            slide = slide.method_7960() ? class_1799.field_8037 : slide;
            InstantCameraAttachment.INSTANT_SLIDE.set(stack, slide);
        }

        class_1799 photograph = new class_1799(Exposure.Items.PHOTOGRAPH.get());
        photograph.method_57379(Exposure.DataComponents.PHOTOGRAPH_FRAME, frame);

        boolean placedInInventory = false;

        for (int slot = 0; slot < player.method_31548().field_7547.size(); slot++) {
            class_1799 item = player.method_31548().method_5438(slot);
            if (item.method_7960()) {
                player.method_31548().method_5447(slot, photograph);
                photograph.method_7912(class_1661.field_30637);
                placedInInventory = true;
            } else if (item.method_7909() instanceof PhotographItem) {
                StackedPhotographsItem stackedPhotographsItem = Exposure.Items.STACKED_PHOTOGRAPHS.get();
                class_1799 stackedPhotographsStack = new class_1799(stackedPhotographsItem);

                stackedPhotographsItem.addPhotographOnTop(stackedPhotographsStack, item);
                stackedPhotographsItem.addPhotographOnTop(stackedPhotographsStack, photograph);

                player.method_31548().method_5447(slot, stackedPhotographsStack);
                stackedPhotographsStack.method_7912(class_1661.field_30637);

                placedInInventory = true;
            } else if (item.method_7909() instanceof StackedPhotographsItem stackedPhotographs && stackedPhotographs.canAddPhotograph(item)) {
                stackedPhotographs.addPhotographOnTop(item, photograph);
                item.method_7912(class_1661.field_30637);
                placedInInventory = true;
            }

            if (placedInInventory) {
                level.method_43129(player, player, Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), class_3419.field_15248,
                        0.6f, level.method_8409().method_43057() * 0.2f + 0.9f);
                break;
            }
        }

        if (!level.field_9236 && !placedInInventory) {
            @Nullable class_1542 itemEntity = player.method_7329(photograph, true, false);
            if (itemEntity != null) {
                itemEntity.method_6975();
            }

            level.method_43129(null, player, Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), class_3419.field_15248, 0.6f,
                    level.method_8409().method_43057() * 0.2f + 1.2f);
        }

        if (player instanceof class_3222 serverPlayer) {
            Exposure.CriteriaTriggers.FRAME_PRINTED.get().trigger(serverPlayer, player.method_24515(), frame, photograph);
        }
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(@NotNull class_1937 level, @NotNull class_1657 player, @NotNull class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (hand == class_1268.field_5808
                && player.method_6079().method_7909() instanceof CameraItem offhandCameraItem
                && offhandCameraItem.isActive(player.method_6079())) {
            return class_1271.method_22430(stack);
        }

        if (!isActive(stack)) {
            return activateInHand(player, stack, hand);
        }

        return release(player, stack);
    }

    @Override
    public @NotNull class_1271<class_1799> release(CameraHolder holder, class_1799 stack) {
        class_1297 entity = holder.asHolderEntity();
        class_1937 level = entity.method_37908();

        Sound.playSided(entity, getReleaseButtonSound(), entity.method_5634(), 0.3f, 1f, 0.1f);

        if (level.field_9236
                || getShutter().isOpen(stack)
                || InstantCameraAttachment.INSTANT_SLIDE.isEmpty(stack)
                || !CameraInstances.canReleaseShutter(CameraId.ofStack(stack))) {
            return class_1271.method_22428(stack);
        }

        ItemAndStack<InstantSlideItem> film = InstantCameraAttachment.INSTANT_SLIDE.get(stack).getItemAndStackCopy();

        if (level instanceof class_3218 serverLevel) {
            if (!(holder.getPlayerExecutingExposure() instanceof class_3222 serverPlayer)) {
                Exposure.LOGGER.error("Cannot start capture: photographer '{}' does not have valid executing player.", holder);
                return class_1271.method_22428(stack);
            }

            int lightLevel = LevelUtil.getLightLevelAt(level, entity.method_24515());
            boolean shouldFlashFire = shouldFlashFire(stack, lightLevel);
            ShutterSpeed shutterSpeed = CameraSettings.SHUTTER_SPEED.getOrDefault(stack);

            getShutter().open(holder, serverLevel, stack, shutterSpeed);

            boolean flashHasFired = shouldFlashFire && tryUseFlash(entity, serverLevel, stack);

            CameraId cameraId = getOrCreateID(stack);
            String exposureId = ExposureIdentifier.createId(serverPlayer);

            CaptureProperties captureProperties = new CaptureProperties.Builder(exposureId)
                    .setCameraHolder(holder)
                    .setCameraID(cameraId)
                    .setShutterSpeed(CameraSettings.SHUTTER_SPEED.getOrDefault(stack))
                    .setFilmType(film.getItem().getType())
                    .setFrameSize(film.getItem().getFrameSize(film.getItemStack()))
                    .setFovOverride(getFov(level, stack))
                    .setCropFactor(getCropFactor())
                    .setColorPalette(getColorPalette(level.method_30349(), stack))
                    .setFlash(flashHasFired)
                    .setChromaticChannel(getChromaticChannel(stack))
                    .extraData(tag -> tag.method_10569("light_level", lightLevel))
                    .build();

            CameraInstances.createOrUpdate(cameraId, instance -> {
                int cooldown = calculateCooldownAfterShot(stack, captureProperties);
                instance.setDeferredCooldown(cooldown);
            });

            addNewFrame(serverLevel, holder, stack, captureProperties);

            ExposureServer.exposureRepository().expect(serverPlayer, exposureId);
            Packets.sendToClient(new CaptureStartS2CP(getCaptureType(stack), captureProperties), serverPlayer);
        }

        return class_1271.method_22428(stack);
    }

    @Override
    protected void addFrameExtraData(CameraHolder holder, class_3218 level, class_1799 camera, CaptureProperties captureProperties, List<class_2338> positionsInFrame, List<class_1309> entitiesInFrame, ExtraData data) {
        data.put(PolaroidFrameExtraData.INSTANT, true);
        super.addFrameExtraData(holder, level, camera, captureProperties, positionsInFrame, entitiesInFrame, data);
    }

    @Override
    public void addFrameToFilm(class_1799 stack, Frame frame) {
        stack.method_57379(Exposure.DataComponents.PHOTOGRAPH_FRAME, frame);
    }
}