package io.github.mortuusars.exposure_polaroid.fabric;

import io.github.mortuusars.exposure_polaroid.ExposurePolaroid;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class RegisterImpl {

    public static <T extends class_1792> Supplier<T> item(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41178, ExposurePolaroid.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_3414> Supplier<T> soundEvent(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41172, ExposurePolaroid.resource(id), supplier.get());
        return () -> obj;
    }
}
