package io.github.mortuusars.exposure_polaroid.client.gui.screen.camera.button;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.ModWidgetSprites;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.item.camera.CameraSettings;
import io.github.mortuusars.exposure_polaroid.Config;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_5250;
import net.minecraft.class_6382;
import org.jetbrains.annotations.NotNull;

public class ZoomWidget extends class_339 {
    protected final ModWidgetSprites sprites;
    protected final Camera camera;
    protected final int secondaryFontColor;
    protected final int mainFontColor;

    public ZoomWidget(int x, int y, int width, int height, ModWidgetSprites sprites, Camera camera) {
        super(x, y, width, height, class_2561.method_43473());
        this.sprites = sprites;
        this.camera = camera;
        mainFontColor = Config.getColor(Config.Client.VIEWFINDER_FONT_MAIN_COLOR);
        secondaryFontColor = Config.getColor(Config.Client.VIEWFINDER_FONT_SECONDARY_COLOR);
    }

    public void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        boolean isFar = camera.map((i, s) -> CameraSettings.ZOOM.getOrDefault(s) > 0.5).orElse(false);

        class_327 font = class_310.method_1551().field_1772;
        class_5250 text = class_2561.method_43471("gui.exposure_polaroid.camera_controls.zoom." + (isFar ? "far" : "near"));
        int textWidth = font.method_27525(text);
        int xPos = 17 + (29 - textWidth) / 2;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        class_2960 sliderSprite = sprites.get(this.method_37303(), this.method_25367());
        guiGraphics.method_25290(sliderSprite, method_46426(), method_46427(),0,0, field_22758, field_22759,sprites.width(),sprites.height());

        guiGraphics.method_51439(font, text, method_46426() + xPos, method_46427() + 8, secondaryFontColor, false);
        guiGraphics.method_51439(font, text, method_46426() + xPos, method_46427() + 7, mainFontColor, false);
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) { }
}