package io.github.mortuusars.exposure_polaroid;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_3414;

public class Register {
    @ExpectPlatform
    public static <T extends class_1792> Supplier<T> item(String id, Supplier<T> supplier) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T extends class_3414> Supplier<T> soundEvent(String id, Supplier<T> supplier) {
        throw new AssertionError();
    }
}
