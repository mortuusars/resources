package io.github.mortuusars.exposure_polaroid.world.item;

import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.film.properties.FilmStyle;
import io.github.mortuusars.exposure.world.item.SensitiveFilmItem;
import io.github.mortuusars.exposure.world.item.interfaces.DefaultFilmStyle;
import io.github.mortuusars.exposure_polaroid.Config;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class InstantSlideItem extends class_1792 implements SensitiveFilmItem, DefaultFilmStyle {
    protected final ExposureType type;

    final FilmStyle defaultFilmStyle;

    public InstantSlideItem(ExposureType type, class_1793 properties, FilmStyle defaultFilmStyle) {
        super(properties);
        this.type = type;
        this.defaultFilmStyle = defaultFilmStyle;
    }

    @Override
    public FilmStyle getDefaultFilmStyle() {
        return defaultFilmStyle;
    }

    @Override
    public ExposureType getType() {
        return type;
    }

    @Override
    public int getDefaultMaxFrameCount(class_1799 stack) {
        return 1;
    }

    @Override
    public int getMaxFrameCount(class_1799 stack) {
        return 1;
    }

    @Override
    public int getDefaultFrameSize(class_1799 stack) {
        return Config.Server.INSTANT_CAMERA_FRAME_SIZE.get();
    }

    @Override
    public void method_7851(class_1799 stack, class_1937 context, List<class_2561> list, class_1836 tooltipFlag) {
        addFrameSizeToTooltip(stack, list);

        if (tooltipFlag.method_8035()) {
            addPaletteToTooltip(stack, list);
            addStyleToTooltip(stack, list);
        }
    }
}
