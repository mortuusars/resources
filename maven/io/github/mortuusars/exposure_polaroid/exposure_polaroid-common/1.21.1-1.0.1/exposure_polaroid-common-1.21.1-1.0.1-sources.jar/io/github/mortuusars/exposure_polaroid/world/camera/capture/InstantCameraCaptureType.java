package io.github.mortuusars.exposure_polaroid.world.camera.capture;

import io.github.mortuusars.exposure_polaroid.ExposurePolaroid;
import net.minecraft.class_2960;

public class InstantCameraCaptureType {
    public static final class_2960 INSTANT_CAMERA = ExposurePolaroid.resource("instant_camera");
}
