package io.github.mortuusars.exposure_polaroid.client.animation;

import io.github.mortuusars.exposure.client.animation.CameraPoses;
import io.github.mortuusars.exposure.client.animation.EasingFunction;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_3532;
import net.minecraft.class_572;
import net.minecraft.class_630;

public class InstantCameraPoses extends CameraPoses {
    @Override
    public void applyHolding(class_572<?> model, class_1309 entity, class_1306 arm) {
        boolean mirror = arm == class_1306.field_6182;

        class_630 cameraArm = mirror ? model.field_27433 : model.field_3401;
        cameraArm.field_3654 = class_3532.method_15363(model.field_3398.field_3654 - 1.95F, -3.3f, -0.35f);
        cameraArm.field_3675 = model.field_3398.field_3675 - ((float) (Math.PI / 12) * (mirror ? -1 : 1));
        float xVal = class_3532.method_37959(cameraArm.field_3654, -3.3f, -0.35f, -0.3f, 0.3f);
        if (!mirror) {
            xVal *= -1;
        }
        cameraArm.field_3674 += xVal;

        class_630 supportingArm = mirror ? model.field_3401 : model.field_27433;
        supportingArm.field_3654 = class_3532.method_15363(model.field_3398.field_3654 - 1.6F, -2.95f, 0);
        supportingArm.field_3675 = model.field_3398.field_3675 - ((float) (Math.PI / 6) * (!mirror ? -1 : 1));
        float supXVal = class_3532.method_37959(cameraArm.field_3654, -3.3f, -0.35f, -0.3f, 0.3f);
        if (mirror) {
            supXVal *= -1;
        }
        supportingArm.field_3674 += supXVal;

        float actionProgress = getCameraActionAnim(entity);
        actionProgress = (float) EasingFunction.EASE_OUT_CUBIC.ease(actionProgress);
        float actionAnim =  actionProgress > 0.3F ? (1F - actionProgress) : actionProgress;

        supportingArm.field_3654 += (actionAnim * 0.1F) * (mirror ? -1 : 1);
        supportingArm.field_3675 += (actionAnim * 0.1F) * (mirror ? -1 : 1);
    }
}
