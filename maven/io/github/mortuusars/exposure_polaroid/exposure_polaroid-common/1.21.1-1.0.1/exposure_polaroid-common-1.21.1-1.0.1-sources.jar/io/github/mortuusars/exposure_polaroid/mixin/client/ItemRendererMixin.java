package io.github.mortuusars.exposure_polaroid.mixin.client;

import io.github.mortuusars.exposure.PlatformHelperClient;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure_polaroid.ExposurePolaroid;
import io.github.mortuusars.exposure_polaroid.ExposurePolaroidClient;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_918.class)
public abstract class ItemRendererMixin {
    @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true)
    class_1087 renderItem(class_1087 model, class_1799 itemStack, class_811 displayContext, boolean leftHand,
                          class_4587 poseStack, class_4597 buffer, int combinedLight, int combinedOverlay) {
        if (class_310.method_1551().field_1687 != null && itemStack.method_31574(ExposurePolaroid.Items.INSTANT_CAMERA.get()) && displayContext == class_811.field_4317) {
            class_1087 guiModel = PlatformHelperClient.getModel(ExposurePolaroidClient.Models.INSTANT_CAMERA_GUI);
            return guiModel.method_4710().method_3495(guiModel, itemStack, Minecrft.level(), Minecrft.player(), 0);
        }
        return model;
    }
}