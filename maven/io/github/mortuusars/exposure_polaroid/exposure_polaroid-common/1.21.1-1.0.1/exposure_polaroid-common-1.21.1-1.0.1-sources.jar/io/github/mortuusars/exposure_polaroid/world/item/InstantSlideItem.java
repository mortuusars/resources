package io.github.mortuusars.exposure_polaroid.world.item;

import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.item.FilmItem;
import io.github.mortuusars.exposure_polaroid.Config;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_5321;

public class InstantSlideItem extends class_1792 implements FilmItem {
    protected final ExposureType type;

    public InstantSlideItem(ExposureType type, class_1793 properties) {
        super(properties);
        this.type = type;
    }

    @Override
    public ExposureType getType() {
        return type;
    }

    @Override
    public int getDefaultMaxFrameCount(class_1799 stack) {
        return 1;
    }

    @Override
    public int getMaxFrameCount(class_1799 stack) {
        return 1;
    }

    @Override
    public int getDefaultFrameSize(class_1799 stack) {
        return Config.Server.INSTANT_CAMERA_FRAME_SIZE.get();
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        int frameSize = getFrameSize(stack);
        if (frameSize != getDefaultFrameSize(stack)) {
            tooltipComponents.add(class_2561.method_43469("item.exposure.film_roll.tooltip.frame_size",
                            class_2561.method_43470(String.format("%.1f", frameSize / 10f)))
                    .method_27692(class_124.field_1080));
        }

        class_5321<ColorPalette> colorPaletteId = getColorPaletteId(stack);
        if (tooltipFlag.method_8035() && !colorPaletteId.equals(ColorPalettes.DEFAULT)) {
            tooltipComponents.add(class_2561.method_43469("item.exposure.film_roll.tooltip.palette", colorPaletteId.method_29177().toString())
                    .method_27692(class_124.field_1080));
        }
    }
}
