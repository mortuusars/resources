package io.github.mortuusars.exposure_polaroid.client.gui.screen.camera.button;

import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.camera.component.ShutterSpeed;
import io.github.mortuusars.exposure.world.item.camera.CameraSettings;
import io.github.mortuusars.exposure_polaroid.ExposurePolaroid;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_8666;

public class ExposureSliderButton extends class_4185 {
    public static final class_2960 BASE = ExposurePolaroid.resource("camera_controls/exposure_slider_base");

    public static final class_8666 SLIDER = new class_8666(
            ExposurePolaroid.resource("camera_controls/exposure_slider"),
            ExposurePolaroid.resource("camera_controls/exposure_slider_disabled"),
            ExposurePolaroid.resource("camera_controls/exposure_slider_highlighted"));

    protected static final int SLIDER_WIDTH = 122;
    protected static final int SLIDER_HEIGHT = 15;
    protected static final int SLIDER_MOVEMENT_RANGE = 58;

    protected final Camera camera;

    public ExposureSliderButton(int x, int y, Camera camera) {
        super(x, y, 79, 15, class_2561.method_43473(), b -> {
        }, n -> class_2561.method_43473());
        this.camera = camera;
    }

    @Override
    protected void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        guiGraphics.method_52706(BASE, method_46426(), method_46427() + 1, field_22758, field_22759 - 1);

        List<ShutterSpeed> shutterSpeeds = camera.map((i, s) -> i.getAvailableShutterSpeeds()).orElse(List.of(ShutterSpeed.DEFAULT));
        if (shutterSpeeds.isEmpty()) {
            shutterSpeeds = List.of(ShutterSpeed.DEFAULT);
        }
        ShutterSpeed shutterSpeed = CameraSettings.SHUTTER_SPEED.getOrDefault(camera);

        int indexOf = shutterSpeeds.indexOf(shutterSpeed);
        int index = indexOf == -1 ? shutterSpeeds.size() / 2 : indexOf;
        float position = 1f - ((float) (index) / (shutterSpeeds.size() - 1));

        int offset = Math.round(SLIDER_MOVEMENT_RANGE * position);

        class_2960 sliderSprite = SLIDER.method_52729(this.method_37303(), this.method_25367());
        guiGraphics.method_52708(sliderSprite, SLIDER_WIDTH, SLIDER_HEIGHT, offset, 0,
                method_46426() + 8, method_46427(), 64, 15);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (scrollY != 0) {
            //noinspection SuspiciousNameCombination
            moveSlider(class_3532.method_17822(scrollY));
            return true;
        }
        return false;
    }

    @Override
    protected void method_25349(double mouseX, double mouseY, double dragX, double dragY) {
        setSliderToMousePosition(mouseX);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (method_25361(mouseX, mouseY)) {
            if (method_25351(button)) {
                setSliderToMousePosition(mouseX);
                return true;
            }

            if (button == class_3675.field_32002) {
                List<ShutterSpeed> shutterSpeeds = camera.map((i, s) -> i.getAvailableShutterSpeeds()).orElse(List.of(ShutterSpeed.DEFAULT));
                if (shutterSpeeds.isEmpty()) return true;

                int defaultIndex = shutterSpeeds.indexOf(ShutterSpeed.DEFAULT);
                int index = defaultIndex != -1 ? defaultIndex : shutterSpeeds.size() / 2;

                ShutterSpeed shutterSpeed = CameraSettings.SHUTTER_SPEED.getOrDefault(camera);
                ShutterSpeed newShutterSpeed = shutterSpeeds.get(index);

                if (!shutterSpeed.equals(newShutterSpeed)) {
                    CameraSettings.SHUTTER_SPEED.setAndSync(camera, newShutterSpeed);
                }

                return true;
            }
        }

        return false;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == class_3675.field_31983) {
            moveSlider(-1);
            return true;
        } else if (keyCode == class_3675.field_31984) {
            moveSlider(1);
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    protected void setSliderToMousePosition(double mouseX) {
        List<ShutterSpeed> shutterSpeeds = camera.map((i, s) -> i.getAvailableShutterSpeeds()).orElse(List.of(ShutterSpeed.DEFAULT));
        if (shutterSpeeds.isEmpty()) return;

        int start = method_46426() + 8;
        int end = method_46426() + 8 + 64;
        int range = end - start;
        int distancePerNotch = range / shutterSpeeds.size();

        int index = (int) class_3532.method_15350((mouseX - start) / distancePerNotch, 0, shutterSpeeds.size() - 1);

        ShutterSpeed shutterSpeed = CameraSettings.SHUTTER_SPEED.getOrDefault(camera);
        ShutterSpeed newShutterSpeed = shutterSpeeds.get(index);

        if (!shutterSpeed.equals(newShutterSpeed)) {
            CameraSettings.SHUTTER_SPEED.setAndSync(camera, newShutterSpeed);
        }
    }

    protected boolean moveSlider(int direction) {
        direction = class_3532.method_17822(direction);

        List<ShutterSpeed> shutterSpeeds = camera.map((i, s) -> i.getAvailableShutterSpeeds()).orElse(List.of(ShutterSpeed.DEFAULT));
        ShutterSpeed currentShutterSpeed = CameraSettings.SHUTTER_SPEED.getOrDefault(camera);

        int indexOf = shutterSpeeds.indexOf(currentShutterSpeed);
        int index = indexOf == -1 ? shutterSpeeds.size() / 2 : indexOf;
        index = class_3532.method_15340(index + direction, 0, shutterSpeeds.size() - 1);

        ShutterSpeed newShutterSpeed = shutterSpeeds.get(index);

        if (!currentShutterSpeed.equals(newShutterSpeed)) {
            CameraSettings.SHUTTER_SPEED.setAndSync(camera, newShutterSpeed);
            return true;
        }

        return false;
    }
}
