package io.github.mortuusars.exposure_polaroid.client.camera.viewfinder;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.client.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.client.camera.viewfinder.ViewfinderOverlay;
import io.github.mortuusars.exposure.client.util.GuiUtil;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure_polaroid.ExposurePolaroid;
import io.github.mortuusars.exposure_polaroid.world.item.InstantCameraItem;
import io.github.mortuusars.exposure_polaroid.world.item.camera.InstantCameraAttachment;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class InstantCameraViewfinderOverlay extends ViewfinderOverlay {
    public static final class_2960 VIEWFINDER_TEXTURE = ExposurePolaroid.resource("textures/gui/viewfinder/viewfinder.png");
    public static final class_2960 NO_SLIDES_ICON_TEXTURE = ExposurePolaroid.resource("textures/gui/viewfinder/no_slides.png");
    public static final class_2960 REMAINING_SLIDES_ICON_TEXTURE = ExposurePolaroid.resource("textures/gui/viewfinder/remaining_slides.png");

    public InstantCameraViewfinderOverlay(Camera camera, Viewfinder viewfinder) {
        super(camera, viewfinder);
    }

    @Override
    protected void drawViewfinderTexture(class_332 guiGraphics) {
        GuiUtil.blit(VIEWFINDER_TEXTURE, guiGraphics.method_51448(), opening, 0, 0, (int) opening.width, (int) opening.height, 0);
    }

    @Override
    protected void renderStatusIcons(class_4587 poseStack, class_1799 cameraStack) {
        class_1799 slideStack = InstantCameraAttachment.INSTANT_SLIDE.get(cameraStack).getForReading();
        if (slideStack.method_7960()) {
            renderNoSlidesIcon(poseStack);
            return;
        }

        renderRemainingSlidesIcon(poseStack, cameraStack);
    }

    protected void renderNoSlidesIcon(class_4587 poseStack) {
        RenderSystem.setShaderTexture(0, NO_SLIDES_ICON_TEXTURE);
        int x = (int) ((opening.x + (opening.width / 2) - 12));
        int y = (int) (opening.y + opening.height - 18);
        GuiUtil.blit(poseStack, x, y, 23, 18, 0, 0, 23, 18, 0);
    }

    protected void renderRemainingSlidesIcon(class_4587 poseStack, class_1799 cameraStack) {
        if (!(cameraStack.method_7909() instanceof InstantCameraItem instantCamera)) return;

        int maxSlides = instantCamera.getMaxSlideCount();
        int remainingSlides = instantCamera.getRemainingSlides(cameraStack);

        if (maxSlides > 5 && remainingSlides <= 3) {
            RenderSystem.setShaderTexture(0, REMAINING_SLIDES_ICON_TEXTURE);
            float x = (int) (opening.x + (opening.width / 2) - 17);
            float y = (int) (opening.y + opening.height - 15);
            int vOffset = (remainingSlides - 1) * 15;
            GuiUtil.blit(poseStack, x, y, 33, 15, 0, vOffset, 33, 45, 0);
        }
    }
}
