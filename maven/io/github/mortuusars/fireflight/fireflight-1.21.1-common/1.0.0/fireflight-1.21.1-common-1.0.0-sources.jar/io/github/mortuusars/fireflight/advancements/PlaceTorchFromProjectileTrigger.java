package io.github.mortuusars.fireflight.advancements;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.fireflight.torch_shooting.TorchType;
import io.github.mortuusars.fireflight.world.entity.Torch;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_2025;
import net.minecraft.class_2048;
import net.minecraft.class_2090;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public class PlaceTorchFromProjectileTrigger extends class_4558<PlaceTorchFromProjectileTrigger.TriggerInstance> {
    public @NotNull Codec<PlaceTorchFromProjectileTrigger.TriggerInstance> method_54937() {
        return PlaceTorchFromProjectileTrigger.TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player, Torch torch) {
        this.method_22510(player, (triggerInstance) -> triggerInstance.matches(player, torch));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  Optional<class_2090> placeLocation,
                                  Optional<TorchType> torchType,
                                  Optional<class_2025> distance) implements class_4558.class_8788 {

        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(i -> i.group(
              class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::comp_2029),
              class_2090.field_45760.optionalFieldOf("place_location").forGetter(TriggerInstance::placeLocation),
              TorchType.CODEC.optionalFieldOf("torch_type").forGetter(TriggerInstance::torchType),
              class_2025.field_45728.optionalFieldOf("distance").forGetter(TriggerInstance::distance)
        ).apply(i, TriggerInstance::new));

        public boolean matches(class_3222 player, Torch torch) {
            class_243 pos = torch.method_19538();
            return (placeLocation.isEmpty() || placeLocation.get().method_9018(player.method_51469(), pos.method_10216(), pos.method_10214(), pos.method_10215()))
                  && (torchType.isEmpty() || torchType.get().equals(torch.getTorchType()))
                  && (this.distance.isEmpty() || (torch.getShootPosition() instanceof class_243 shootPos
                                                    && this.distance.get().method_8859(pos.method_10216(), pos.method_10214(), pos.method_10215(), shootPos.method_10216(), shootPos.method_10214(), shootPos.method_10215())));
        }
    }
}
