package io.github.mortuusars.fireflight.torch_shooting;

import io.github.mortuusars.fireflight.Config;
import io.github.mortuusars.fireflight.Fireflight;
import io.github.mortuusars.fireflight.world.entity.RedstoneTorch;
import io.github.mortuusars.fireflight.world.entity.SoulTorch;
import io.github.mortuusars.fireflight.world.entity.Torch;
import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1937;

public class TorchShooting {
    public static Predicate<class_1799> getSupportedHeldProjectiles(class_1657 player, class_1799 weaponStack,
                                                                   class_1811 weaponItem, Predicate<class_1799> original) {
        if (weaponStack.method_31573(Fireflight.Tags.Items.CANNOT_SHOOT_TORCHES)) {
            return original;
        }

        return switch (Config.Server.OFFHAND_TORCH_SELECTION.get()) {
            case ALWAYS -> original.or(Fireflight::isShootableTorch);
            case WHEN_STANDING -> !player.method_21823()
                  ? original.or(Fireflight::isShootableTorch)
                  : original;
            case WHEN_SNEAKING -> player.method_21823()
                  ? original.or(Fireflight::isShootableTorch)
                  : original;
            case NEVER -> original;
        };
    }

    public static Predicate<class_1799> getAllSupportedProjectiles(class_1657 player, class_1799 weaponStack,
                                                                  class_1811 weaponItem, Predicate<class_1799> original) {
        if (weaponStack.method_31573(Fireflight.Tags.Items.CANNOT_SHOOT_TORCHES)) {
            return original;
        }

        InventoryTorchSelection selection = player.method_21823()
              ? Config.Server.INVENTORY_TORCH_SELECTION_WHEN_SNEAKING.get()
              : Config.Server.INVENTORY_TORCH_SELECTION_WHEN_STANDING.get();

        Predicate<class_1799> predicate = applyTorchSelection(selection, player, weaponStack, weaponItem, original);

        // Fixes not being able to shoot when started using bow while sneaking and then stopped sneaking while no other ammo is in inventory
        if (!player.method_21823()
              && player.method_6115()
              && Config.Server.INVENTORY_TORCH_SELECTION_WHEN_STANDING.get() == InventoryTorchSelection.IGNORE_TORCHES
              && Config.Server.INVENTORY_TORCH_SELECTION_WHEN_SNEAKING.get() != InventoryTorchSelection.IGNORE_TORCHES
              && !player.method_31548().method_55753(original)
              && player.method_31548().method_55753(Fireflight::isShootableTorch)) {
            return predicate.or(Fireflight::isShootableTorch);
        }

        return predicate;
    }

    private static Predicate<class_1799> applyTorchSelection(InventoryTorchSelection selection,
                                                            class_1657 player, class_1799 weaponStack,
                                                            class_1811 weaponItem, Predicate<class_1799> original) {
        return switch (selection) {
            case ONLY_TORCHES -> Fireflight::isShootableTorch;
            case PRIORITIZE_TORCHES -> player.method_31548().method_55753(Fireflight::isShootableTorch)
                      ? Fireflight::isShootableTorch
                      : original;
            case INCLUDE_TORCHES -> original.or(Fireflight::isShootableTorch);
            case IGNORE_TORCHES -> original;
        };
    }

    public static Optional<class_1676> createProjectile(class_1811 instance, class_1937 level, class_1309 shooter,
                                                        class_1799 weapon, class_1799 ammo, boolean isCrit) {
        return Optional.ofNullable(TorchType.getFromStack(ammo))
              .map(type -> {
                  class_1799 pickupStack = ammo.method_46651(1);
                  Torch projectile = switch (type) {
                      case TORCH -> new Torch(level, shooter, pickupStack);
                      case SOUL_TORCH -> new SoulTorch(level, shooter, pickupStack);
                      case REDSTONE_TORCH -> new RedstoneTorch(level, shooter, pickupStack);
                  };
                  projectile.method_7438(type.getDamage());
                  return projectile;
              });
    }

    public static int getDurabilityCost(class_1811 item, class_1799 ammo, int original) {
        return TorchType.mapOrDefault(ammo, TorchType::getWeaponDurabilityCost, original);
    }
}
