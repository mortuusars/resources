package io.github.mortuusars.fireflight.mixin.shoot_sound;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.fireflight.Fireflight;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1753.class)
public class BowItemMixin {
    @SuppressWarnings({"LocalMayUseName", "NameDoesntMatchTargetClass"})
    @WrapOperation(method = "releaseUsing", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;playSound(Lnet/minecraft/world/entity/player/Player;DDDLnet/minecraft/sounds/SoundEvent;Lnet/minecraft/sounds/SoundSource;FF)V"))
    private void wrapPlaySound(class_1937 instance, @Nullable class_1657 player, double x, double y, double z,
                               class_3414 sound, class_3419 category, float volume, float pitch, Operation<Void> original,
                               @Local(ordinal = 1) class_1799 projectile) {
        if (Fireflight.isShootableTorch(projectile)) {
            pitch /= 2f;
        }

        if (projectile.method_31573(Fireflight.Tags.Items.SOUL_TORCH)) {
            instance.method_60511(null, x, y, z, class_3417.field_23060, category, volume, pitch);
        }

        original.call(instance, player, x, y, z, sound, category, volume, pitch);
    }
}
