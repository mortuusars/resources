package io.github.mortuusars.fireflight.client.render;

import com.google.common.base.Preconditions;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;

public class LayeredBakedModel implements class_1087 {
    private final List<class_1087> layers;

    public LayeredBakedModel(List<class_1087> layers) {
        Preconditions.checkArgument(!layers.isEmpty(), "Should have at least one model.");
        this.layers = layers;
    }

    @Override
    public @NotNull List<class_777> method_4707(@Nullable class_2680 state, @Nullable class_2350 direction, @NotNull class_5819 random) {
        List<class_777> quads = new ArrayList<>();

        for (class_1087 layer : layers) {
            List<class_777> layerQuads = layer.method_4707(state, direction, random);
            quads.addAll(layerQuads);
        }

        return quads;
    }

    @Override
    public boolean method_4708() {
        return layers.getFirst().method_4708();
    }

    @Override
    public boolean method_4712() {
        return layers.getFirst().method_4712();
    }

    @Override
    public boolean method_24304() {
        return layers.getFirst().method_24304();
    }

    @Override
    public boolean method_4713() {
        return layers.getFirst().method_4713();
    }

    @Override
    public @NotNull class_1058 method_4711() {
        return layers.getFirst().method_4711();
    }

    @Override
    public @NotNull class_806 method_4710() {
        return layers.getFirst().method_4710();
    }

    @Override
    public @NotNull class_809 method_4709() {
        return layers.getFirst().method_4709();
    }
}