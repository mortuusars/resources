package io.github.mortuusars.fireflight.mixin.client;

import io.github.mortuusars.fireflight.Config;
import io.github.mortuusars.fireflight.Fireflight;
import io.github.mortuusars.fireflight.FireflightClient;
import io.github.mortuusars.fireflight.client.render.LayeredBakedModel;
import io.github.mortuusars.mortaar.Platform;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_918;
import net.minecraft.class_9278;
import net.minecraft.class_9334;

@Mixin(class_918.class)
public class ItemRendererMixin {
    /**
     * Combines item model with overlay model.
     */
    @Inject(method = "getModel", at = @At("RETURN"), cancellable = true)
    private void onGetModel(class_1799 stack, class_1937 level, class_1309 entity, int seed, CallbackInfoReturnable<class_1087> cir) {
        if (!Config.Client.RENDER_TORCH.get() || !(entity instanceof class_1657) || stack.method_31573(Fireflight.Tags.Items.CANNOT_SHOOT_TORCHES))
            return;

        class_1091 modelLocation;
        if (stack.method_7909() instanceof class_1753) {
            if (!Fireflight.isShootableTorch(entity.method_18808(stack))) {
                return;
            }

            if (!Config.Client.RENDER_TORCH_AS_OVERLAY.get()) {
                cir.setReturnValue(Platform.Client.getModelWithOverrides(FireflightClient.Models.BOW_FULL, stack, level, entity, seed));
                return;
            }

            modelLocation = FireflightClient.Models.BOW_OVERLAY;
        } else if (stack.method_7909() instanceof class_1764) {
            if (!(stack.method_57824(class_9334.field_49649) instanceof class_9278 projectiles)
                  || projectiles.method_57442()
                  || !Fireflight.isShootableTorch(projectiles.method_57437().getFirst())) {
                return;
            }

            modelLocation = FireflightClient.Models.CROSSBOW_OVERLAY;
        } else {
            return;
        }

        class_1087 model = Platform.Client.getModelWithOverrides(modelLocation, stack, level, entity, seed);

        class_1087 originalModel = cir.getReturnValue();
        LayeredBakedModel layeredModel = new LayeredBakedModel(List.of(originalModel, model));

        cir.setReturnValue(layeredModel);
    }
}