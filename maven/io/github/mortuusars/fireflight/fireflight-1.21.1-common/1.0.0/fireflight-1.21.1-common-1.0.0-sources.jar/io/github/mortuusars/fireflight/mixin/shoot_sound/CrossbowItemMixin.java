package io.github.mortuusars.fireflight.mixin.shoot_sound;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.fireflight.world.entity.Torch;
import net.minecraft.class_1676;
import net.minecraft.class_1764;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1764.class)
public class CrossbowItemMixin {
    @WrapOperation(method = "shootProjectile", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/CrossbowItem;getShotPitch(Lnet/minecraft/util/RandomSource;I)F"))
    private float wrapPlaySound(class_5819 random, int index, Operation<Float> original, @Local(argsOnly = true) class_1676 projectile) {
        Float pitch = original.call(random, index);

        if (projectile instanceof Torch) {
            pitch *= 0.7f;
        }

        return pitch;
    }
}
