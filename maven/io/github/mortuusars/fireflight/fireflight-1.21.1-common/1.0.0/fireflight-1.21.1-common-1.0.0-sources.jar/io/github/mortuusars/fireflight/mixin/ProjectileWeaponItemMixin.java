package io.github.mortuusars.fireflight.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.fireflight.Config;
import io.github.mortuusars.fireflight.Fireflight;
import io.github.mortuusars.fireflight.torch_shooting.InventoryTorchSelection;
import io.github.mortuusars.fireflight.torch_shooting.TorchShooting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Predicate;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1937;

@Mixin(value = class_1811.class, priority = 999) // Slightly higher priority than default
public class ProjectileWeaponItemMixin {
    @WrapOperation(method = "shoot", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ProjectileWeaponItem;createProjectile(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;Z)Lnet/minecraft/world/entity/projectile/Projectile;"))
    private class_1676 wrapCreateProjectile(class_1811 instance, class_1937 level, class_1309 shooter,
                                            class_1799 weapon, class_1799 ammo, boolean isCrit, Operation<class_1676> original) {
        return TorchShooting.createProjectile(instance, level, shooter, weapon, ammo, isCrit)
              .orElseGet(() -> original.call(instance, level, shooter, weapon, ammo, isCrit));
    }

    @WrapOperation(method = "shoot", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ProjectileWeaponItem;getDurabilityUse(Lnet/minecraft/world/item/ItemStack;)I"))
    private int wrapCreateProjectile(class_1811 instance, class_1799 stack, Operation<Integer> original) {
        return TorchShooting.getDurabilityCost(instance, stack, original.call(instance, stack));
    }

    @SuppressWarnings("NameDoesntMatchTargetClass")
    @WrapOperation(method = "draw", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ProjectileWeaponItem;useAmmo(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/LivingEntity;Z)Lnet/minecraft/world/item/ItemStack;"))
    private static class_1799 wrapDraw(class_1799 weapon, class_1799 ammo, class_1309 shooter, boolean intangible,
                                      Operation<class_1799> original, @Local(argsOnly = true, ordinal = 1) class_1799 originalAmmo) {
        // This matters when shooting from Crossbow enchanted with Multishot.
        // 2/3 Multishot projectiles do not consume ammo which is problematic as placed torches always drop the item when broken.
        if (Fireflight.isShootableTorch(ammo)) {
            ammo = originalAmmo; // Pass original stack instead of a copy, to properly shrink it
            intangible = false; // Torches are not intangible
        }

        return original.call(weapon, ammo, shooter, intangible);
    }

    @Inject(method = "getHeldProjectile", at = @At("HEAD"), cancellable = true)
    private static void onGetHeldProjectile(class_1309 shooter, Predicate<class_1799> isAmmo, CallbackInfoReturnable<class_1799> cir) {
        if (shooter instanceof class_1657 player
              && Config.Server.BLOCK_GET_HELD_PROJECTILE_CHANGES.get()
              && ((Config.Server.INVENTORY_TORCH_SELECTION_WHEN_STANDING.get() == InventoryTorchSelection.PRIORITIZE_TORCHES && !player.method_21823() && player.method_31548().method_55753(Fireflight::isShootableTorch))
                || (Config.Server.INVENTORY_TORCH_SELECTION_WHEN_SNEAKING.get() == InventoryTorchSelection.PRIORITIZE_TORCHES && player.method_21823() && player.method_31548().method_55753(Fireflight::isShootableTorch)))
              && !isAmmo.test(shooter.method_6079())
              && !isAmmo.test(shooter.method_6047())) {
            cir.setReturnValue(class_1799.field_8037);
        }
    }
}
