package io.github.mortuusars.fireflight;

import io.github.mortuusars.fireflight.torch_shooting.TorchType;
import io.github.mortuusars.mortaar.Platform;
import net.minecraft.class_1091;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_638;
import net.minecraft.class_9278;
import net.minecraft.class_9334;

public class FireflightClient {
    public static void init() {
        ItemModelOverrides.register();
        Models.init();
    }

    public static class Models {
        public static final class_1091 BOW_FULL =
              Platform.Client.registerCustomModel(Fireflight.resource("item/bow_full"));
        public static final class_1091 BOW_OVERLAY =
              Platform.Client.registerCustomModel(Fireflight.resource("item/bow_overlay"));
        public static final class_1091 CROSSBOW_OVERLAY =
              Platform.Client.registerCustomModel(Fireflight.resource("item/crossbow_overlay"));

        public static void init() {

        }
    }

    public static class ItemModelOverrides {
        public static final class_2960 TORCH_TYPE = Fireflight.resource("torch_type");

        public static void register() {
            class_5272.method_27881(TORCH_TYPE, ItemModelOverrides::getTorchType);
        }

        /**
         * Ammo type. Torch - 0.1, Soul Torch - 0.2, Redstone Torch - 0.3. All other ammo - 0.0.
         */
        public static float getTorchType(class_1799 stack, class_638 level, class_1309 entity, int seed) {
            if (entity instanceof class_1657 player && !stack.method_31573(Fireflight.Tags.Items.CANNOT_SHOOT_TORCHES)) {
                if (stack.method_7909() instanceof class_1753) {
                    if (player.method_6115()) {
                        return TorchType.mapOrDefault(player.method_18808(stack), TorchType::getModelOverrideValue, 0f);
                    }
                }

                if (stack.method_57824(class_9334.field_49649) instanceof class_9278 projectiles) {
                    for (class_1799 projectile : projectiles.method_57437()) {
                        return TorchType.mapOrDefault(projectile, TorchType::getModelOverrideValue, 0f);
                    }
                }
            }

            return 0f;
        }
    }
}
