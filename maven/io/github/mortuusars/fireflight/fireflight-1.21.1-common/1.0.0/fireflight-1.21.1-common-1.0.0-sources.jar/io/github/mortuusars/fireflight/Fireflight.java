package io.github.mortuusars.fireflight;

import io.github.mortuusars.fireflight.advancements.PlaceTorchFromProjectileTrigger;
import io.github.mortuusars.fireflight.world.entity.RedstoneTorch;
import io.github.mortuusars.fireflight.world.entity.SoulTorch;
import io.github.mortuusars.fireflight.world.entity.Torch;
import io.github.mortuusars.fireflight.torch_shooting.TorchType;
import io.github.mortuusars.mortaar.Register;
import io.github.mortuusars.mortaar.Registrar;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class Fireflight {
    public static final String ID = "fireflight";

    public static final Registrar REGISTRAR = Register.registrar(ID);

    public static void init() {
        EntityTypes.init();
        CriteriaTriggers.init();
    }

    public static class_2960 resource(String path) {
        return class_2960.method_60655(ID, path);
    }

    public static boolean isShootableTorch(class_1799 stack) {
        return TorchType.isShootableTorch(stack);
    }

    public static class EntityTypes {
        public static final Supplier<class_1299<Torch>> TORCH = REGISTRAR.entityType("torch",
              Torch::new, class_1311.field_17715, true, builder -> builder
                    .method_17687(0.5F, 0.5F)
                    .method_19947());

        public static final Supplier<class_1299<SoulTorch>> SOUL_TORCH = REGISTRAR.entityType("soul_torch",
              SoulTorch::new, class_1311.field_17715, true, builder -> builder
                    .method_17687(0.5F, 0.5F)
                    .method_19947());

        public static final Supplier<class_1299<RedstoneTorch>> REDSTONE_TORCH = REGISTRAR.entityType("redstone_torch",
              RedstoneTorch::new, class_1311.field_17715, true, builder -> builder
                    .method_17687(0.5F, 0.5F)
                    .method_19947());

        public static void init() {
        }
    }

    public static class CriteriaTriggers {
        public static Supplier<PlaceTorchFromProjectileTrigger> PLACE_TORCH_FROM_PROJECTILE =
              REGISTRAR.criterionTrigger("place_torch_from_projectile", PlaceTorchFromProjectileTrigger::new);

        public static void init() {
        }
    }

    public static class Tags {
        public static class Items {
            public static final class_6862<class_1792> TORCH = class_6862.method_40092(class_7924.field_41197, Fireflight.resource("torches"));
            public static final class_6862<class_1792> SOUL_TORCH = class_6862.method_40092(class_7924.field_41197, Fireflight.resource("soul_torches"));
            public static final class_6862<class_1792> REDSTONE_TORCH = class_6862.method_40092(class_7924.field_41197, Fireflight.resource("redstone_torches"));

            public static final class_6862<class_1792> CANNOT_SHOOT_TORCHES = class_6862.method_40092(class_7924.field_41197, Fireflight.resource("cannot_shoot_torches"));
        }
    }
}
