package io.github.mortuusars.fireflight.client.render;

import io.github.mortuusars.fireflight.Fireflight;
import io.github.mortuusars.fireflight.torch_shooting.TorchType;
import io.github.mortuusars.fireflight.world.entity.Torch;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_876;
import org.jetbrains.annotations.NotNull;

public class TorchArrowRenderer extends class_876<Torch> {
    public static final class_2960 TORCH_ARROW_LOCATION = Fireflight.resource("textures/entity/projectile/torch.png");
    public static final class_2960 SOUL_TORCH_ARROW_LOCATION = Fireflight.resource("textures/entity/projectile/soul_torch.png");
    public static final class_2960 REDSTONE_TORCH_ARROW_LOCATION = Fireflight.resource("textures/entity/projectile/redstone_torch.png");

    private final TorchType type;

    public TorchArrowRenderer(class_5617.class_5618 context, TorchType type) {
        super(context);
        this.type = type;
    }

    public @NotNull class_2960 getTextureLocation(@NotNull Torch entity) {
        return switch (type) {
            case TORCH -> TORCH_ARROW_LOCATION;
            case SOUL_TORCH -> SOUL_TORCH_ARROW_LOCATION;
            case REDSTONE_TORCH -> REDSTONE_TORCH_ARROW_LOCATION;
        };
    }
}