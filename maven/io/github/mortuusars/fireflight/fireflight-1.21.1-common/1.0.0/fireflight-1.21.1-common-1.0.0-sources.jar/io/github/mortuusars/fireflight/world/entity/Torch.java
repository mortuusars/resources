package io.github.mortuusars.fireflight.world.entity;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.fireflight.Config;
import io.github.mortuusars.fireflight.Fireflight;
import io.github.mortuusars.fireflight.torch_shooting.TorchType;
import net.minecraft.class_1264;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1827;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2398;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5431;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.naming.OperationNotSupportedException;

public class Torch extends class_1665 {
    protected @Nullable class_243 shootPosition;
    protected boolean torchWasPlaced;
    protected int inGroundItemDropTimer = Config.Server.TORCH_PROJECTILE_STUCK_DROP_TIME.get();

    public Torch(class_1299<? extends Torch> entityType, class_1937 level) {
        super(entityType, level);
    }

    public Torch(class_1937 level, class_1309 shooter, class_1799 pickupStack) {
        this(Fireflight.EntityTypes.TORCH.get(), level, shooter, pickupStack);
    }

    public Torch(class_1937 level, double x, double y, double z, class_1799 pickupStack) {
        this(Fireflight.EntityTypes.TORCH.get(), level, x, y, z, pickupStack);
    }

    protected Torch(class_1299<? extends Torch> entityType, class_1937 level, class_1309 shooter, class_1799 pickupStack) {
        super(entityType, shooter, level, pickupStack, null);
    }

    protected Torch(class_1299<? extends class_1665> entityType, class_1937 level, double x, double y, double z, class_1799 pickupStack) {
        super(entityType, x, y, z, level, pickupStack, null);
    }

    public TorchType getTorchType() {
        return TorchType.TORCH;
    }

    public @Nullable class_243 getShootPosition() {
        return shootPosition;
    }

    @Override
    protected @NotNull class_3414 method_7440() {
        return class_3417.field_14718;
    }

    @Override
    public void method_7444(@NotNull class_3414 pSoundEvent) {
        super.method_7444(method_7440());
    }

    @Override
    protected @NotNull class_1799 method_57314() {
        return new class_1799(class_1802.field_8810);
    }

    @Override
    public boolean method_7443() {
        return false;
    }

    @Override
    public void method_5773() {
        if (torchWasPlaced) {
            this.method_5650(class_5529.field_26999);
        }

        if (field_7588 && !torchWasPlaced) {
            if (inGroundItemDropTimer == 0) {
                if (!method_37908().field_9236) {
                    class_1264.method_5449(method_37908(), method_23317(), method_23318(), method_23321(), method_7445());
                    method_5783(class_3417.field_15215, 0.7f, 0.7f);
                }

                this.method_5650(class_5529.field_26999);
            } else {
                inGroundItemDropTimer--;
            }
        }

        super.method_5773();

        if (method_37908().field_9236) {
            spawnOnTickParticles(method_37908());
        }
    }

    @Override
    public @NotNull class_243 method_31166(float partialTicks) {
        return method_19538();
    }

    @Override
    public void method_7485(double x, double y, double z, float velocity, float inaccuracy) {
        // Pickup is controlled by INTANGIBLE_PROJECTILE in 1.21, which we remove when consuming ammo.
        // if (getOwner() instanceof Player player && !player.isCreative()) {
        //     this.pickup = Pickup.ALLOWED; // Hopefully this wouldn't cause a dupe of some sort.
        // }

        velocity *= TorchType.mapOrDefault(method_7445(), type -> type.getVelocityMultiplier().get().floatValue(), 1.0f);

        super.method_7485(x, y, z, velocity, inaccuracy);

        shootPosition = method_19538();
    }

    @Override
    protected void method_7450(@NotNull class_1309 targetEntity) {
        int ticks = Config.Server.TORCH_IGNITE_EFFECT_DURATION.get();
        if (ticks > 0) {
            targetEntity.method_56073(ticks);
        }
    }

    @Override
    protected void method_24920(@NotNull class_3965 blockHitResult) {
        super.method_24920(blockHitResult);

        class_1937 level = method_37908();
        class_2350 impactFace = blockHitResult.method_17780();
        class_2338 blockPos = blockHitResult.method_17777().method_10093(impactFace);
        class_2680 blockStateAtPos = method_37908().method_8320(blockPos);

        boolean canPlaceTorchAtHitPos = (blockStateAtPos.method_26215() || blockStateAtPos.method_45474()) && !(blockStateAtPos.method_26204() instanceof class_2404);
        boolean isSameItem = method_7445().method_7909() == blockStateAtPos.method_26204().method_8389();

        if (!method_5799() && canPlaceTorchAtHitPos && !isSameItem) {
            class_2350 torchFacing = null;

            if (impactFace == class_2350.field_11033) { // Search the nearest block that can hold a torch
                boolean hasHorizontalBlock = false;

                for (class_2350 direction : class_2350.method_10159(this)) {
                    if (direction.method_10166().method_10179()) {
                        class_2338 pos = blockPos.method_10093(direction);
                        class_2350 oppositeFace = direction.method_10153();
                        if (level.method_8320(pos).method_26206(level, pos, oppositeFace)) {
                            torchFacing = oppositeFace;
                            hasHorizontalBlock = true;
                        }
                    }
                }

                if (!hasHorizontalBlock) { // Check block below
                    class_2338 belowPos = blockPos.method_10093(class_2350.field_11033);
                    class_2680 belowBlockState = level.method_8320(belowPos);
                    if (belowBlockState.method_30368(level, belowPos, class_2350.field_11036, class_5431.field_25823))
                        torchFacing = class_2350.field_11036;
                }
            } else if (level.method_8320(blockHitResult.method_17777())
                  .method_30368(level, blockHitResult.method_17777(), impactFace, impactFace == class_2350.field_11036 ? class_5431.field_25823 : class_5431.field_25822)) {
                torchFacing = impactFace;
            } else if (level.method_8320(blockPos.method_10074())
                  .method_30368(level, blockPos.method_10074(), class_2350.field_11036, class_5431.field_25823)) {
                torchFacing = class_2350.field_11036;
            }

            if (torchFacing != null) {
                try {
                    class_2680 torchBlockState = createTorchBlockStateForFacing(torchFacing);
                    if (!level.field_9236) {
                        level.method_8501(blockPos, torchBlockState);
                    }
                    torchWasPlaced = true;
                } catch (OperationNotSupportedException ignored) {
                }
            }
        }

        if (torchWasPlaced && shootPosition != null && method_24921() instanceof class_3222 player) {
            LogUtils.getLogger().info("Light: {}, Distance: {}",
                  method_37908().method_22339(blockPos),
                  shootPosition.method_1022(blockHitResult.method_17784()));
            Fireflight.CriteriaTriggers.PLACE_TORCH_FROM_PROJECTILE.get().trigger(player, this);
        }

        if (!torchWasPlaced && impactFace != class_2350.field_11036) {
            method_26352(); // Fall to the ground to be reachable (or have another chance for placing
        }

        if (level.field_9236) {
            this.spawnOnBlockHitParticles(level, blockHitResult);
        }
    }

    @Override
    protected void method_7454(@NotNull class_3966 entityHitResult) {
        super.method_7454(entityHitResult);

        if (method_37908() instanceof class_3218 serverLevel) {
            spawnServerOnEntityHitParticles(serverLevel, entityHitResult);
        }
    }

    protected class_2680 createTorchBlockStateForFacing(class_2350 facing) throws OperationNotSupportedException {
        if (facing == class_2350.field_11033) {
            throw new OperationNotSupportedException("Ceiling torches are not supported.");
        }

        class_1792 torchItem = method_7445().method_7909();

        if (torchItem instanceof class_1827 standingAndWallBlockItem) {

            //TODO: maybe use BlockPlaceContext?

            // Checking this firstly to prevent torch mis-matching:
            // If the torch cannot work fully (standing and wall) - better to use default torch.
            if (!standingAndWallBlockItem.field_8918.method_9564().method_28498(class_2741.field_12481)) {
                LogUtils.getLogger().error("Failed to place torch from arrow: '{}' has no HorizontalFacing property. " +
                      "Default torch will be used instead. (Even if the direction is UP).", torchItem);
                return getDefaultTorchBlockStateForFacing(facing);
            }

            if (facing == class_2350.field_11036) {
                return standingAndWallBlockItem.method_7711().method_9564();
            } else {
                return standingAndWallBlockItem.field_8918.method_9564().method_11657(class_2741.field_12481, facing);
            }
        } else if (torchItem instanceof class_1747 blockItem && blockItem.method_7711().method_9564().method_28498(class_2741.field_12525))
            return blockItem.method_7711().method_9564().method_11657(class_2741.field_12525, facing);
        else
            return getDefaultTorchBlockStateForFacing(facing);
    }

    /**
     * Used as a backup in case Block from specified TorchItem cannot be placed correctly.
     */
    protected class_2680 getDefaultTorchBlockStateForFacing(class_2350 facing) throws OperationNotSupportedException {
        if (facing == class_2350.field_11033) {
            throw new OperationNotSupportedException("Ceiling torches are not supported.");
        }

        if (facing == class_2350.field_11036) {
            return class_2246.field_10336.method_9564();
        } else {
            return class_2246.field_10099.method_9564().method_11657(class_2741.field_12481, facing);
        }
    }

    /**
     * Only called client-side.
     */
    protected void spawnOnTickParticles(class_1937 level) {
        if (method_5799()) {
            return;
        }

        if (field_7588 && field_5974.method_43048(4) != 0) {
            return;
        } else if (field_5974.method_43048(2) != 0) {
            return;
        }

        if (level.field_9229.method_43057() >= 0.5) {
            level.method_17452(class_2398.field_11240, true, this.method_23317(), this.method_23318(), this.method_23321(), 0.0D, 0.03D, 0.0D);
        } else {
            level.method_17452(class_2398.field_27783, true, this.method_23317(), this.method_23318(), this.method_23321(), 0.0D, 0.03D, 0.0D);
        }

        if (level.method_8409().method_43048(2) == 0) {
            level.method_8406(class_2398.field_11251, this.method_23317(), this.method_23318(), this.method_23321(), 0.0D, 0.03D, 0.0D);
        }
    }

    /**
     * Only called client-side.
     */
    protected void spawnOnBlockHitParticles(class_1937 level, @NotNull class_3965 blockHitResult) {
        class_2350 impactFace = blockHitResult.method_17780();
        class_2338 blockPos = blockHitResult.method_17777().method_10093(impactFace);

        boolean isInWater = method_5799() || level.method_8320(blockPos).method_27852(class_2246.field_10382);
        if (isInWater) {
            return;
        }

        class_2382 impactFaceNormal = impactFace.method_10153().method_10163();
        class_243 faceOffset = new class_243(impactFaceNormal.method_10263() / 3D, impactFaceNormal.method_10264() / 3D, impactFaceNormal.method_10260() / 3D);
        class_243 pos = new class_243(blockPos.method_10263() + 0.5, blockPos.method_10264() + 0.5, blockPos.method_10260() + 0.5).method_1019(faceOffset);

        int particles = torchWasPlaced ? 10 : 5;

        for (int i = 0; i < particles; i++) {
            double xo = impactFaceNormal.method_10263() * 0.15D + (level.field_9229.method_43058() * 0.2 - 0.1);
            double yo = impactFaceNormal.method_10264() * 0.15D + (level.field_9229.method_43058() * 0.2 - 0.1);
            double zo = impactFaceNormal.method_10260() * 0.15D + (level.field_9229.method_43058() * 0.2 - 0.1);

            if (field_5974.method_43048(3) == 0)
                level.method_17452(class_2398.field_27783, true, pos.field_1352, pos.field_1351, pos.field_1350, xo * -1, yo * -1, zo * -1);
            else
                level.method_17452(class_2398.field_11239, true, pos.field_1352, pos.field_1351, pos.field_1350, xo * -1, yo * -1, zo * -1);
        }
    }

    /**
     * Only called server-side. #onEntityHit is not working reliably on client-side.
     */
    protected void spawnServerOnEntityHitParticles(class_3218 level, class_3966 entityHitResult) {
        class_1297 entity = entityHitResult.method_17782();
        for (int i = 0; i < 8; i++) {
            double x = field_5974.method_43058() * 0.2;
            double y = field_5974.method_43058() * 0.2;
            double z = field_5974.method_43058() * 0.2;

            level.method_14199(class_2398.field_11239, entity.method_23317(), method_19538().field_1351, entity.method_23321(), 1, x, y, z, 0);
        }
    }

    @Override
    public void method_5652(@NotNull class_2487 tag) {
        super.method_5652(tag);

        if (shootPosition != null) {
            tag.method_10549("ShootPositionX", shootPosition.method_10216());
            tag.method_10549("ShootPositionY", shootPosition.method_10214());
            tag.method_10549("ShootPositionZ", shootPosition.method_10215());
        }

        if (torchWasPlaced) tag.method_10556("TorchWasPlaced", true);
        tag.method_10569("InGroundItemDropTimer", inGroundItemDropTimer);
    }

    @Override
    public void method_5749(@NotNull class_2487 tag) {
        super.method_5749(tag);

        if (tag.method_10545("ShootPositionX")
              && tag.method_10545("ShootPositionY")
              && tag.method_10545("ShootPositionZ")) {
            shootPosition = new class_243(
                  tag.method_10574("ShootPositionX"),
                  tag.method_10574("ShootPositionY"),
                  tag.method_10574("ShootPositionZ")
            );
        } else {
            shootPosition = null;
        }

        torchWasPlaced = tag.method_10577("TorchWasPlaced");
        inGroundItemDropTimer = tag.method_10550("InGroundItemDropTimer");
    }
}