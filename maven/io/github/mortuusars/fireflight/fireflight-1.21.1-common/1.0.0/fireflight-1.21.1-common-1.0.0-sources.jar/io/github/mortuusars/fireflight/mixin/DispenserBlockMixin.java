package io.github.mortuusars.fireflight.mixin;

import io.github.mortuusars.fireflight.Config;
import io.github.mortuusars.fireflight.Fireflight;
import io.github.mortuusars.fireflight.torch_shooting.TorchShootingDispenseBehavior;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2357;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2315.class)
public class DispenserBlockMixin {
    /**
     * Using 'DispenserBlock#registerBehavior' does not really work for us, because it's hardcoded to an item, and we use tags for torches.
     */
    @Inject(method = "getDispenseMethod", at = @At("HEAD"), cancellable = true)
    private void onGetDispenseMethod(class_1937 level, class_1799 item, CallbackInfoReturnable<class_2357> cir) {
        if (Config.Server.DISPENSER_SHOOTS_TORCHES.get() && Fireflight.isShootableTorch(item)) {
            cir.setReturnValue(TorchShootingDispenseBehavior.INSTANCE);
        }
    }
}
