package io.github.mortuusars.fireflight.torch_shooting;

import io.github.mortuusars.fireflight.world.entity.RedstoneTorch;
import io.github.mortuusars.fireflight.world.entity.SoulTorch;
import io.github.mortuusars.fireflight.world.entity.Torch;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1665;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2342;
import net.minecraft.class_2347;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_9463;

/**
 * Pretty much a copy of ProjectileDispenseBehavior. We cannot use it directly because torch is not a ProjectileItem.
 */
public class TorchShootingDispenseBehavior extends class_2347 {
    public static final TorchShootingDispenseBehavior INSTANCE = new TorchShootingDispenseBehavior();

    private final class_9463 projectileItem;

    private TorchShootingDispenseBehavior() {
        projectileItem = new class_9463() {
            @Override
            public @NotNull class_1676 method_58648(class_1937 level, class_2374 pos, class_1799 stack, class_2350 direction) {
                return Optional.ofNullable(TorchType.getFromStack(stack))
                      .map(type -> {
                          class_1799 pickupStack = stack.method_46651(1);
                          Torch projectile = switch (type) {
                              case TORCH -> new Torch(level, pos.method_10216(), pos.method_10214(), pos.method_10215(), pickupStack);
                              case SOUL_TORCH -> new SoulTorch(level, pos.method_10216(), pos.method_10214(), pos.method_10215(), pickupStack);
                              case REDSTONE_TORCH -> new RedstoneTorch(level, pos.method_10216(), pos.method_10214(), pos.method_10215(), pickupStack);
                          };
                          projectile.method_7438(type.getDamage());
                          projectile.field_7572 = class_1665.class_1666.field_7593;
                          return projectile;
                      })
                      .orElseGet(() -> {
                          class_1799 pickupStack = stack.method_46651(1);
                          Torch projectile = new Torch(level, pos.method_10216(), pos.method_10214(), pos.method_10215(), pickupStack);
                          projectile.field_7572 = class_1665.class_1666.field_7593;
                          return projectile;
                      });
            }
        };
    }

    public @NotNull class_1799 method_10135(class_2342 blockSource, class_1799 item) {
        class_1937 level = blockSource.comp_1967();
        class_2350 direction = blockSource.comp_1969().method_11654(class_2315.field_10918);
        class_9463.class_9464 config = projectileItem.method_58653();
        class_2374 position = config.comp_2544().getDispensePosition(blockSource, direction);
        class_1676 projectile = projectileItem.method_58648(level, position, item, direction);
        projectile.method_7485(direction.method_10148(), direction.method_10164(), direction.method_10165(), config.comp_2546(), config.comp_2545());
        level.method_8649(projectile);
        item.method_7934(1);
        return item;
    }

    protected void method_10136(class_2342 blockSource) {
        blockSource.comp_1967().method_20290(projectileItem.method_58653().comp_2547().orElse(1002), blockSource.comp_1968(), 0);
    }
}
