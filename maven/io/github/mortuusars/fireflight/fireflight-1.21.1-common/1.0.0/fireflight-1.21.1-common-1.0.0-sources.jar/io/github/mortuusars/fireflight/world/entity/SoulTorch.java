package io.github.mortuusars.fireflight.world.entity;

import io.github.mortuusars.fireflight.Config;
import io.github.mortuusars.fireflight.Fireflight;
import io.github.mortuusars.fireflight.torch_shooting.TorchType;
import org.jetbrains.annotations.NotNull;

import javax.naming.OperationNotSupportedException;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class SoulTorch extends Torch {
    public SoulTorch(class_1299<? extends Torch> entityType, class_1937 level) {
        super(entityType, level);
    }

    public SoulTorch(class_1937 level, class_1309 shooter, class_1799 pickupStack) {
        super(Fireflight.EntityTypes.SOUL_TORCH.get(), level, shooter, pickupStack);
    }

    public SoulTorch(class_1937 level, double x, double y, double z, class_1799 pickupStack) {
        super(Fireflight.EntityTypes.SOUL_TORCH.get(), level, x, y, z, pickupStack);
    }

    public TorchType getTorchType() {
        return TorchType.SOUL_TORCH;
    }

    @Override
    protected void method_7450(@NotNull class_1309 targetEntity) {
        int ticks = Config.Server.SOUL_TORCH_WITHER_EFFECT_DURATION.get();
        if (ticks > 0) {
            class_1293 mobeffectinstance = new class_1293(class_1294.field_5920, ticks, 0);
            targetEntity.method_37222(mobeffectinstance, method_37225());
        }
    }

    protected class_2680 getDefaultTorchBlockStateForFacing(class_2350 facing) throws OperationNotSupportedException {
        if (facing == class_2350.field_11033) {
            throw new OperationNotSupportedException("Ceiling torches are not supported.");
        }

        if (facing == class_2350.field_11036) {
            return class_2246.field_22092.method_9564();
        } else {
            return class_2246.field_22093.method_9564().method_11657(class_2741.field_12481, facing);
        }
    }

    protected void spawnOnTickParticles(class_1937 level) {
        if (method_5799()) {
            return;
        }

        if (field_7588 && field_5974.method_43048(4) != 0) {
            return;
        }

        if (level.method_8409().method_43048(2) == 0) {
            level.method_17452(class_2398.field_22246, true,
                  method_23317(), method_23318(), method_23321(), 0.0D, 0.01D, 0.0D);
        }

        if (level.method_8409().method_43048(3) == 0) {
            level.method_17452(class_2398.field_11251, true,
                  method_23317(), method_23318(), method_23321(), 0.0D, 0.03D, 0.0D);
        }
    }

    protected void spawnOnBlockHitParticles(class_1937 level, @NotNull class_3965 blockHitResult) {
        class_2350 impactFace = blockHitResult.method_17780();
        class_2338 blockPos = blockHitResult.method_17777().method_10093(impactFace);

        boolean isInWater = method_5799() || level.method_8320(blockPos).method_27852(class_2246.field_10382);
        if (isInWater) {
            return;
        }

        class_2382 impactFaceNormal = impactFace.method_10153().method_10163();
        class_243 faceOffset = new class_243(impactFaceNormal.method_10263() / 3D, impactFaceNormal.method_10264() / 3D, impactFaceNormal.method_10260() / 3D);
        class_243 pos = new class_243(blockPos.method_10263() + 0.5, blockPos.method_10264() + 0.5, blockPos.method_10260() + 0.5).method_1019(faceOffset);

        int particles = torchWasPlaced ? 10 : 5;

        for (int i = 0; i < particles; i++) {
            double xo = impactFaceNormal.method_10263() * 0.15D + (level.field_9229.method_43058() * 0.2 - 0.1);
            double yo = impactFaceNormal.method_10264() * 0.15D + (level.field_9229.method_43058() * 0.2 - 0.1);
            double zo = impactFaceNormal.method_10260() * 0.15D + (level.field_9229.method_43058() * 0.2 - 0.1);

            if (field_5974.method_43048(3) == 0) {
                level.method_17452(class_2398.field_23114, true,
                      pos.field_1352, pos.field_1351, pos.field_1350, xo * -1, yo * -1, zo * -1);
            } else {
                level.method_17452(class_2398.field_22246, true,
                      pos.field_1352, pos.field_1351, pos.field_1350, xo * -1, yo * -1, zo * -1);
            }
        }
    }

    protected void spawnServerOnEntityHitParticles(class_3218 level, class_3966 entityHitResult) {
        class_1297 entity = entityHitResult.method_17782();
        for (int i = 0; i < 8; i++) {
            double x = field_5974.method_43058() * 0.2;
            double y = field_5974.method_43058() * 0.2;
            double z = field_5974.method_43058() * 0.2;

            level.method_14199(class_2398.field_23114, entity.method_23317(), method_19538().field_1351, entity.method_23321(), 1, x, y, z, 0);
        }
    }
}