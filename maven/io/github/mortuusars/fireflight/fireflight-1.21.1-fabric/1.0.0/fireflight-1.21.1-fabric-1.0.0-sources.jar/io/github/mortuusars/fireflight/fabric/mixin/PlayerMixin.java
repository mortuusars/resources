package io.github.mortuusars.fireflight.fabric.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.fireflight.torch_shooting.TorchShooting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.function.Predicate;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1811;

/**
 * NeoForge and Fabric calls differ.
 * NeoForge passes 'ItemStack weaponStack' into ProjectileWeaponItem#getXXXProjectiles, and Fabric does not.
 */
@Mixin(class_1657.class)
public class PlayerMixin {
    @WrapOperation(method = "getProjectile", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ProjectileWeaponItem;getSupportedHeldProjectiles()Ljava/util/function/Predicate;"))
    private Predicate<class_1799> wrapGetSupportedHeldProjectiles(class_1811 instance, Operation<Predicate<class_1799>> original,
                                                                 @Local(argsOnly = true) class_1799 weaponStack) {
        return TorchShooting.getSupportedHeldProjectiles((class_1657) (Object) this, weaponStack, instance, original.call(instance));
    }

    @WrapOperation(method = "getProjectile", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ProjectileWeaponItem;getAllSupportedProjectiles()Ljava/util/function/Predicate;"))
    private Predicate<class_1799> wrapGetAllSupportedProjectiles(class_1811 instance, Operation<Predicate<class_1799>> original,
                                                                @Local(argsOnly = true) class_1799 weaponStack) {
        return TorchShooting.getAllSupportedProjectiles((class_1657) (Object) this, weaponStack, instance, original.call(instance));
    }
}
