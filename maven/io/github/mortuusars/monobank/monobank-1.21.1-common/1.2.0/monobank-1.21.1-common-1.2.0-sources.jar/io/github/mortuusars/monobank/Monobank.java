package io.github.mortuusars.monobank;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.monobank.advancement.trigger.MonobankInventoryChangedTrigger;
import io.github.mortuusars.monobank.advancement.trigger.MonobankLockReplacedTrigger;
import io.github.mortuusars.monobank.advancement.trigger.MonobankUnlockedTrigger;
import io.github.mortuusars.monobank.world.block.monobank.component.Lock;
import io.github.mortuusars.monobank.world.item.ReplacementLockItem;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlock;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import io.github.mortuusars.monobank.world.inventory.menu.MonobankMenu;
import io.github.mortuusars.monobank.world.inventory.menu.LockReplacementMenu;
import io.github.mortuusars.monobank.world.inventory.menu.CombinationMenu;
import org.slf4j.Logger;

import javax.xml.crypto.Data;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3446;
import net.minecraft.class_3620;
import net.minecraft.class_3917;
import net.minecraft.class_4970;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9331;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class Monobank {
    public static final String ID = "monobank";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static void init() {
        Blocks.init();
        BlockEntityTypes.init();
        EntityTypes.init();
        Items.init();
        DataComponents.init();
        MenuTypes.init();
        CriteriaTriggers.init();
        RecipeSerializers.init();
        SoundEvents.init();
        ArgumentTypes.init();
    }

    /**
     * Creates resource location in the mod namespace with the given path.
     */
    public static class_2960 resource(String path) {
        return class_2960.method_60655(ID, path);
    }

    public static class Blocks {
        public static final Supplier<class_2248> MONOBANK = Register.block("monobank",
                () -> new MonobankBlock(class_4970.class_2251.method_9637()
                        .method_31710(class_3620.field_16009)
                        .method_9629(8F, 1200F)
                        .method_22488() // Without this door and items inside will be black.
                        .method_9626(class_2498.field_22150)));

        static void init() {
        }
    }

    public static class BlockEntityTypes {
        public static final Supplier<class_2591<MonobankBlockEntity>> MONOBANK = Register.blockEntityType("monobank",
                () -> Register.newBlockEntityType(MonobankBlockEntity::new, Blocks.MONOBANK.get()));

        static void init() {
        }
    }

    public static class Items {
        public static final Supplier<class_1747> MONOBANK = Register.item("monobank",
                () -> new class_1747(Blocks.MONOBANK.get(), new class_1792.class_1793()
                        .method_7889(1)
                        .method_24359()));

        public static final Supplier<class_1792> REPLACEMENT_LOCK = Register.item("replacement_lock",
                () -> new ReplacementLockItem(new class_1792.class_1793()
                        .method_7889(16)));

        static void init() {
        }
    }

    public static class DataComponents {
        public static final class_9331<Lock> LOCK = Register.dataComponentType("lock", arg -> arg.method_57881(Lock.CODEC));

        static void init() {
        }
    }

    public static class EntityTypes {
        static void init() {
        }
    }

    public static class MenuTypes {
        public static final Supplier<class_3917<MonobankMenu>> MONOBANK =
                Register.menuType("monobank", MonobankMenu::fromBuffer);

        public static final Supplier<class_3917<CombinationMenu>> MONOBANK_COMBINATION =
                Register.menuType("lock_picking", CombinationMenu::fromBuffer);

        public static final Supplier<class_3917<LockReplacementMenu>> MONOBANK_LOCK_REPLACEMENT =
                Register.menuType("lock_replacement", LockReplacementMenu::fromBuffer);

        static void init() {
        }
    }

    public static class RecipeSerializers {
        static void init() {
        }
    }

    public static class SoundEvents {
        public static final Supplier<class_3414> MONOBANK_OPEN = register("block.monobank.open");
        public static final Supplier<class_3414> MONOBANK_CLOSE = register("block.monobank.close");
        public static final Supplier<class_3414> MONOBANK_LOCK = register("block.monobank.lock");
        public static final Supplier<class_3414> MONOBANK_UNLOCK = register("block.monobank.unlock");
        public static final Supplier<class_3414> MONOBANK_CLICK = register("block.monobank.click");

        private static Supplier<class_3414> register(String path) {
            Preconditions.checkState(path != null && !path.isEmpty(), "'path' should not be empty.");
            return Register.soundEvent(path, () -> class_3414.method_47908(Monobank.resource(path)));
        }

        static void init() {
        }
    }

    public static class Stats {
        private static final Map<class_2960, class_3446> STATS = new HashMap<>();

        private static class_2960 register(class_2960 location, class_3446 formatter) {
            STATS.put(location, formatter);
            return location;
        }

        public static void register() {
            STATS.forEach((location, formatter) -> {
                class_2378.method_10230(class_7923.field_41183, location, location);
                net.minecraft.class_3468.field_15419.method_14955(location, formatter);
            });
        }
    }

    public static class CriteriaTriggers {
        public static Supplier<MonobankInventoryChangedTrigger> MONOBANK_INVENTORY_CHANGED = Register.criterionTrigger("monobank_inventory_changed", MonobankInventoryChangedTrigger::new);
        public static Supplier<MonobankUnlockedTrigger> MONOBANK_UNLOCKED = Register.criterionTrigger("monobank_unlocked", MonobankUnlockedTrigger::new);
        public static Supplier<MonobankLockReplacedTrigger> MONOBANK_LOCK_REPLACED = Register.criterionTrigger("monobank_lock_replaced", MonobankLockReplacedTrigger::new);

        public static void init() {
        }
    }

    public static class Tags {
        public static class Items {
            public static final class_6862<class_1792> LOCK_BLACKLIST = class_6862.method_40092(class_7924.field_41197, resource("lock_blacklist"));
        }

        public static class Blocks {
        }

        public static class EntityTypes {
        }
    }

    public static class LootTables {
        public static final class_5321<class_52> COMBINATION_DEFAULT =
                class_5321.method_29179(class_7924.field_50079, resource("combination/default"));
    }

    public static class ArgumentTypes {
        public static void init() {
        }
    }
}
