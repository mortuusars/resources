package io.github.mortuusars.monobank.client.gui.tooltip;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.monobank.client.gui.screen.MonobankScreen;
import io.github.mortuusars.monobank.world.block.monobank.component.Combination;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5632;
import net.minecraft.class_5684;

public class CombinationTooltip implements class_5684, class_5632 {
    private final ArrayList<class_1799> items;

    public CombinationTooltip(Combination combination) {
        items = new ArrayList<>();
        for (int i = 0; i < Combination.SIZE; i++) {
            items.add(new class_1799(combination.getItem(i)));
        }
    }

    @Override
    public void method_32666(@NotNull class_327 font, int mouseX, int mouseY, class_332 graphics) {
        graphics.method_25302(MonobankScreen.TEXTURE, mouseX, mouseY, 176, 12, 72, 30);
        for (int i = 0; i < items.size(); i++) {
            graphics.method_51427(items.get(i), mouseX + 7 + 18 * i + 3 * i, mouseY + 7);
        }
    }

    @Override
    public int method_32661() {
        return 32;
    }

    @Override
    public int method_32664(@NotNull class_327 font) {
        return 18 * 3 + 2;
    }
}
