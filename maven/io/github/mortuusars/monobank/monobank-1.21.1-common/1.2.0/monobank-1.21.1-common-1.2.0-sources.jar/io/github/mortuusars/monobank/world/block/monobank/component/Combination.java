package io.github.mortuusars.monobank.world.block.monobank.component;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.monobank.Monobank;
import org.jetbrains.annotations.NotNull;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.OptionalInt;
import java.util.stream.Stream;
import net.minecraft.class_1263;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Defines item combination which is needed to unlock the Monobank.
 */
public record Combination(class_1792 first, class_1792 second, class_1792 third) implements Iterable<class_1792> {
    public static final int SIZE = 3;
    public static final Combination EMPTY = new Combination(class_1802.field_8162, class_1802.field_8162, class_1802.field_8162);

    public static final Codec<Combination> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_7923.field_41178.method_39673().optionalFieldOf("first", class_1802.field_8162).forGetter(Combination::first),
            class_7923.field_41178.method_39673().optionalFieldOf("second", class_1802.field_8162).forGetter(Combination::second),
            class_7923.field_41178.method_39673().optionalFieldOf("third", class_1802.field_8162).forGetter(Combination::third)
    ).apply(instance, Combination::new));

    public Combination(class_1799 first, class_1799 second, class_1799 third) {
        this(first.method_7909(), second.method_7909(), third.method_7909());
    }

    public class_1792 getItem(int slot) {
        Preconditions.checkElementIndex(slot, 3);
        return switch (slot) {
            case 0 -> first();
            case 1 -> second();
            case 2 -> third();
            default -> throw new IllegalStateException("Unexpected value: " + slot);
        };
    }

    public boolean isEmpty() {
        return first.equals(class_1802.field_8162) && second.equals(class_1802.field_8162) && third.equals(class_1802.field_8162);
    }

    // -- Match

    public boolean matches(int slot, class_1792 key) {
        class_1792 item = getItem(slot);
        return item.equals(class_1802.field_8162) || item.equals(key);
    }

    public boolean matches(int slot, class_1799 key) {
        return matches(slot, key.method_7909());
    }

    public boolean matches(class_1263 container) {
        if (isEmpty()) return true;

        for (int i = 0; i < 3; i++) {
            if (container.method_5439() - 1 < i) {
                if (getItem(i).equals(class_1802.field_8162)) {
                    continue;
                } else {
                    return false;
                }
            }

            if (!matches(i, container.method_5438(i).method_7909())) {
                return false;
            }
        }

        return true;
    }

    // -- Save / Load

    public static Combination load(class_2499 listTag) {
        return new Combination(
                findItemById(listTag.method_10608(0)),
                findItemById(listTag.method_10608(1)),
                findItemById(listTag.method_10608(2)));
    }

    public class_2499 save() {
        class_2499 list = new class_2499();
        for (class_1792 item : this) {
            class_2960 location = class_7923.field_41178.method_10221(item);
            class_2519 stringTag = class_2519.method_23256(location.toString());
            list.add(stringTag);
        }
        return list;
    }

    public void toBuffer(class_2540 buffer) {
        buffer.method_10814(class_7923.field_41178.method_10221(first).toString());
        buffer.method_10814(class_7923.field_41178.method_10221(second).toString());
        buffer.method_10814(class_7923.field_41178.method_10221(third).toString());
    }

    public static Combination fromBuffer(class_2540 buffer) {
        return new Combination(
                findItemById(buffer.method_19772()),
                findItemById(buffer.method_19772()),
                findItemById(buffer.method_19772()));
    }

    // --

    @Override
    public String toString() {
        return "Combination:[" + first.toString() + ", " + second.toString() + ", " + third.toString() + "]";
    }

    // -- Iterable

    @Override
    public @NotNull Iterator<class_1792> iterator() {
        return new Iterator<>() {
            private int index = 0;

            @Override
            public boolean hasNext() {
                return index < SIZE;
            }

            @Override
            public class_1792 next() {
                if (!hasNext()) throw new NoSuchElementException();
                return switch (index++) {
                    case 0 -> first;
                    case 1 -> second;
                    case 2 -> third;
                    default -> throw new IllegalStateException();
                };
            }
        };
    }

    public Stream<class_1792> stream() {
        return Stream.of(first, second, third);
    }

    // -- Util

    /**
     * Finds combination slot matching the key or -1 if none found.
     */
    public OptionalInt findMatchingSlot(class_1792 key) {
        for (int i = 0; i < SIZE; i++) {
            if (matches(i, key)) {
                return OptionalInt.of(i);
            }
        }
        return OptionalInt.empty();
    }

    private static @NotNull class_1792 findItemById(String location) {
        if (location.isBlank()) {
            return class_1802.field_8162;
        }
        try {
            return class_7923.field_41178.method_10223(class_2960.method_60654(location));
        } catch (Exception e) {
            Monobank.LOGGER.error("Unknown item in combination: {}", location);
            return class_1802.field_8162;
        }
    }
}
