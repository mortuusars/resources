package io.github.mortuusars.monobank.client.gui.screen;

import io.github.mortuusars.monobank.Monobank;
import io.github.mortuusars.monobank.client.gui.tooltip.CombinationTooltip;
import io.github.mortuusars.monobank.util.NumberFormatter;
import io.github.mortuusars.monobank.world.inventory.BigSlot;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import io.github.mortuusars.monobank.world.inventory.ResizeableSlot;
import io.github.mortuusars.monobank.world.inventory.menu.MonobankMenu;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_5250;
import net.minecraft.class_5632;

public class MonobankScreen extends class_465<MonobankMenu> {
    public static final class_2960 TEXTURE = Monobank.resource("textures/gui/monobank.png");

    protected final class_2561 CTRL_TOOLTIP = class_2561.method_43471("monobank.gui.monobank.tooltip.ctrl_take_single")
            .method_27692(class_124.field_1063);
    protected final class_2561 CTRL_SHIFT_TOOLTIP = class_2561.method_43471("monobank.gui.monobank.tooltip.ctrl_shift_take_all")
            .method_27692(class_124.field_1063);
    protected final class_2561 OWNER_TOOLTIP = class_2561.method_43471("monobank.gui.monobank.tooltip.owner");
    protected final class_2561 BREAK_IN_ATTEMPTED_TOOLTIP = class_2561.method_43471("monobank.gui.monobank.tooltip.break_in_attempted");
    protected final class_2561 BREAK_IN_SUCCEEDED_TOOLTIP = class_2561.method_43471("monobank.gui.monobank.tooltip.break_in_succeeded");

    protected final MonobankBlockEntity blockEntity;
    protected Optional<class_5632> combinationTooltip;

    protected class_1937 level;

    public MonobankScreen(MonobankMenu containerMenu, class_1661 playerinventory, class_2561 title) {
        super(containerMenu, playerinventory, title);
        combinationTooltip = Optional.empty();
        blockEntity = containerMenu.getBlockEntity();
        level = Objects.requireNonNull(class_310.method_1551().field_1687);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        this.method_2380(graphics, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTick, int mouseX, int mouseY) {
        graphics.method_25302(TEXTURE, this.field_2776, this.field_2800, 0, 0, this.field_2792, this.field_2779);

        if (method_17577().extraInfo.isOwner) {
            graphics.method_25302(TEXTURE, field_2776 + 161, field_2800 + 3, 176, 0, 12, 12);

            if (method_17577().extraInfo.hasWarning()) {
                if (method_17577().extraInfo.breakInSucceeded) {
                    if (level.method_8510() % 10 > 5) // Blinking fast
                        graphics.method_25302(TEXTURE, field_2776 + 151, field_2800 + 38, 188, 0, 10, 10);
                }
                else if (method_17577().extraInfo.breakInAttempted) {
                    if (level.method_8510() % 26 > 12) // Blinking slowly
                        graphics.method_25302(TEXTURE, field_2776 + 151, field_2800 + 38, 188, 0, 10, 10);
                }
            }
        }
    }

    @Override
    protected void method_2380(@NotNull class_332 graphics, int x, int y) {
        if (this.field_2797.method_34255().method_7960() && field_2787 != null &&
                field_2787 instanceof BigSlot bankSlot && bankSlot.method_7681()) {
            renderBankSlotTooltip(bankSlot.method_7677(), graphics, x, y);
        }
        else if (method_17577().extraInfo.isOwner && method_2378(161, 3, 12, 12, x, y)) { // Owner
            if (combinationTooltip.isEmpty() && blockEntity.getLock().hasCombination())
                combinationTooltip = Optional.of(new CombinationTooltip(blockEntity.getLock().getCombination()));
            graphics.method_51437(field_22793, List.of(OWNER_TOOLTIP), combinationTooltip, x, y);
        }
        else if (method_17577().extraInfo.isOwner && method_17577().extraInfo.hasWarning() && method_2378(151, 38, 10, 10, x, y)) { // Warning
            if (method_17577().extraInfo.breakInSucceeded)
                graphics.method_51438(field_22793, BREAK_IN_SUCCEEDED_TOOLTIP, x, y);
            else if (method_17577().extraInfo.breakInAttempted)
                graphics.method_51438(field_22793, BREAK_IN_ATTEMPTED_TOOLTIP, x, y);
        }
        else {
            super.method_2380(graphics, x, y);
        }
    }

    protected void renderBankSlotTooltip(class_1799 stack, class_332 graphics, int x, int y) {
        List<class_2561> tooltip = new ArrayList<>(method_25408(class_310.method_1551(), stack));
        int stackCount = stack.method_7947();
        if (stackCount > 999) {
            String formattedCount = NumberFormatter.separateThousands(stack.method_7947());
            class_5250 newTitle = tooltip.getFirst().method_27661()
                    .method_10852(class_2561.method_43470(" - ").method_27692(class_124.field_1080))
                    .method_10852(class_2561.method_43469("monobank.gui.monobank.count", formattedCount).method_27692(class_124.field_1080));
            tooltip.set(0, newTitle);
        }

        tooltip.add(CTRL_TOOLTIP);
        tooltip.add(CTRL_SHIFT_TOOLTIP);

        graphics.method_51437(field_22793, tooltip, stack.method_32347(), x, y);
    }

    @Override
    protected void method_2383(@NotNull class_1735 slot, int slotId, int mouseButton, @NotNull class_1713 type) {
        if (slotId == MonobankMenu.MONOBANK_SLOT_INDEX && mouseButton == 0) {
            if (type == class_1713.field_7793) {
                return;
            }

            if (class_437.method_25441() && class_437.method_25442()) {
                mouseButton = MonobankMenu.TRANSFER_ALL_BUTTON_ID;
                type = class_1713.field_7794;
            }
            else if (class_437.method_25441()) {
                mouseButton = MonobankMenu.TRANSFER_SINGLE_BUTTON_ID;
                type = class_1713.field_7794;
            }
        }

        super.method_2383(slot, slotId, mouseButton, type);
    }

    /**
     * Takes resizable slots into account.
     */
    @Override
    public boolean method_2387(class_1735 slot, double mouseX, double mouseY) {
        if (slot instanceof ResizeableSlot resizeableSlot) {
            return method_2378(slot.field_7873, slot.field_7872, resizeableSlot.getWidth(), resizeableSlot.getHeight(), mouseX, mouseY);
        }
        return super.method_2387(slot, mouseX, mouseY);
    }
}
