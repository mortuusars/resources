package io.github.mortuusars.monobank.world.block.monobank.component;

import io.github.mortuusars.monobank.Monobank;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import io.github.mortuusars.monobank.world.inventory.menu.MonobankMenu;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5561;

public class MonobankOpenersCounter extends class_5561 {
    public static final int UPDATE_DOOR_EVENT_ID = 1;
    private final MonobankBlockEntity blockEntity;

    public MonobankOpenersCounter(MonobankBlockEntity blockEntity) {
        this.blockEntity = blockEntity;
    }

    @Override
    protected void method_31681(class_1937 level, class_2338 pos, class_2680 state) {
        blockEntity.playSoundAtDoor(Monobank.SoundEvents.MONOBANK_OPEN.get());
    }

    @Override
    protected void method_31683(class_1937 level, class_2338 pos, class_2680 state) {
        blockEntity.playSoundAtDoor(Monobank.SoundEvents.MONOBANK_CLOSE.get());
    }

    @Override
    protected void method_31682(class_1937 level, class_2338 pos, class_2680 state, int count, int openCount) {
        // Send update to client:
        level.method_8427(pos, state.method_26204(), UPDATE_DOOR_EVENT_ID, openCount);
    }

    @Override
    protected boolean method_31679(class_1657 player) {
        return player.field_7512 instanceof MonobankMenu monobankMenu && monobankMenu.getBlockEntity() == blockEntity;
    }
}
