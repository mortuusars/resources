package io.github.mortuusars.monobank.client.gui.screen;

import io.github.mortuusars.monobank.Config;
import io.github.mortuusars.monobank.Monobank;
import io.github.mortuusars.monobank.client.gui.rendering.ExtendedSlotRenderer;
import io.github.mortuusars.monobank.world.inventory.menu.CombinationMenu;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_765;
import io.github.mortuusars.monobank.world.inventory.MatchTemplateSlot;
import org.jetbrains.annotations.NotNull;

public class CombinationScreen extends class_465<CombinationMenu> {
    public static final class_2960 TEXTURE = Monobank.resource("textures/gui/monobank_combination.png");

    public CombinationScreen(CombinationMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);

        // Keyhole casing overlay
        graphics.method_25302(TEXTURE, field_2776 + 73, field_2800 + 28, 176, 0, 72, 30);

        this.method_2380(graphics, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTick, int mouseX, int mouseY) {
        graphics.method_25302(TEXTURE, this.field_2776, this.field_2800, 0, 0, this.field_2792, this.field_2779);
    }

    @Override
    protected void method_2380(@NotNull class_332 graphics, int x, int y) {
        if (field_2787 instanceof MatchTemplateSlot matchTemplateSlot && !matchTemplateSlot.method_7681()) {
            graphics.method_51438(class_310.method_1551().field_1772, matchTemplateSlot.getTemplateTooltip(), x, y);
        } else
            super.method_2380(graphics, x, y);
    }

    // -- Slot

    @Override
    protected void method_2385(class_332 guiGraphics, class_1735 slot) {
        super.method_2385(guiGraphics, slot);
        if (slot instanceof MatchTemplateSlot templateSlot) {
            renderTemplateSlotOverlay(guiGraphics, templateSlot);
            renderTemplateSlotIcon(guiGraphics, templateSlot);
        }
    }

    protected void renderTemplateSlotOverlay(class_332 guiGraphics, MatchTemplateSlot slot) {
        if (slot.method_7681() && !slot.containedItemMatches()) {
            int x = slot.field_7873;
            int y = slot.field_7872;
            guiGraphics.method_48196(class_1921.method_51785(), x, y, x + 16, y + 16, 5, 0x66FF5A4D);
        }
    }

    protected void renderTemplateSlotIcon(class_332 guiGraphics, MatchTemplateSlot slot) {
        if (slot.method_7681() || !Config.Server.COMBINATION_HINT_ICON.get()) {
            return;
        }

        int x = slot.field_7873;
        int y = slot.field_7872;

        // Ghost (template) item
        ExtendedSlotRenderer.renderFakeItem(guiGraphics, slot.getTemplateItem(), x, y,
                0, 0, class_765.field_32767, 16, 16);

        double opacity1 = Config.Server.COMBINATION_HINT_ICON_OPACITY.get();
        double opacity2 = opacity1 * opacity1 * opacity1 * opacity1;
        int alpha1 = (int) ((1.0 - opacity1) * 255);
        int alpha2 = (int) ((1.0 - opacity2) * 255);

        int color1 = (alpha1 << 24) | 0x8B8B8B;
        int color2 = (alpha2 << 24) | 0x8B8B8B;

        // Gray checkerboard overlay to hide the item:
        for (int v = 0; v < 4; v++) {
            for (int h = 0; h < 4; h++) {
                int color = (h + v) % 2 == 0 ? color1 : color2;
                guiGraphics.method_48196(class_1921.method_51785(),
                        x + h * 4,
                        y + v * 4,
                        x + h * 4 + 4,
                        y + v * 4 + 4, 50, color);
            }
        }
    }
}
