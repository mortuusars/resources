package io.github.mortuusars.monobank.world;

import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.monobank.Config;
import io.github.mortuusars.monobank.Monobank;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3781;
import net.minecraft.class_3784;
import net.minecraft.class_3785;
import net.minecraft.class_5321;
import net.minecraft.class_5497;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class VillageStructures {
    private static final class_5321<class_5497> MOSSIFY_10_PROCESSOR_LIST_KEY = class_5321.method_29179(
            class_7924.field_41247, class_2960.method_60655("minecraft", "mossify_10_percent"));
    private static final class_5321<class_5497> STREET_PLAINS_PROCESSOR_LIST_KEY = class_5321.method_29179(
            class_7924.field_41247, class_2960.method_60655("minecraft", "street_plains"));
    private static final Logger LOGGER = LogUtils.getLogger();


    public static void addVillageStructures(MinecraftServer server) {
        if (!Config.Server.GENERATE_VILLAGE_STRUCTURES.get()) {
            return;
        }

        class_2378<class_3785> templatePools = server.method_30611().method_33310(class_7924.field_41249).orElseThrow();
        class_2378<class_5497> processorListsRegistry = server.method_30611().method_33310(class_7924.field_41247).orElseThrow();

        class_6880<class_5497> mossify10ProcessorList = processorListsRegistry.method_40290(MOSSIFY_10_PROCESSOR_LIST_KEY);
        class_6880<class_5497> streetPlainsProcessorList = processorListsRegistry.method_40290(STREET_PLAINS_PROCESSOR_LIST_KEY);

        Integer vaultWeight = Config.Server.VAULT_WEIGHT.get();

        // Injecting custom street that has smaller bounding box. Without it vaults will not generate.
        VillageStructures.addStructureToPoolLegacy(templatePools, streetPlainsProcessorList,
                class_2960.method_60654("minecraft:village/plains/streets"),
                Monobank.ID + ":village/streets/plains_straight_fix_01", class_3785.class_3786.field_16686, vaultWeight);

        VillageStructures.addStructureToPoolSingle(templatePools, mossify10ProcessorList,
                class_2960.method_60654("minecraft:village/plains/houses"),
                Monobank.ID + ":village/houses/plains_vault",  class_3785.class_3786.field_16687, vaultWeight);

        // Injecting custom street that has smaller bounding box. Without it vaults will not generate.
        VillageStructures.addStructureToPoolLegacy(templatePools, streetPlainsProcessorList,
                class_2960.method_60654("minecraft:village/taiga/streets"),
                Monobank.ID + ":village/streets/taiga_straight_fix_01", class_3785.class_3786.field_16686, vaultWeight);

        VillageStructures.addStructureToPoolSingle(templatePools, mossify10ProcessorList,
                class_2960.method_60654("minecraft:village/taiga/houses"),
                Monobank.ID + ":village/houses/taiga_vault",  class_3785.class_3786.field_16687, vaultWeight);

        // Injecting custom street that has smaller bounding box. Without it vaults will not generate.
        VillageStructures.addStructureToPoolLegacy(templatePools, streetPlainsProcessorList,
                class_2960.method_60654("minecraft:village/desert/streets"),
                Monobank.ID + ":village/streets/desert_straight_fix_01", class_3785.class_3786.field_16686, vaultWeight);

        VillageStructures.addStructureToPoolSingle(templatePools, mossify10ProcessorList,
                class_2960.method_60654("minecraft:village/desert/houses"),
                Monobank.ID + ":village/houses/desert_vault",  class_3785.class_3786.field_16687, vaultWeight);

        // Injecting custom street that has smaller bounding box. Without it vaults will not generate.
        VillageStructures.addStructureToPoolLegacy(templatePools, streetPlainsProcessorList,
                class_2960.method_60654("minecraft:village/snowy/streets"),
                Monobank.ID + ":village/streets/snowy_straight_fix_01", class_3785.class_3786.field_16686, vaultWeight);

        VillageStructures.addStructureToPoolSingle(templatePools, mossify10ProcessorList,
                class_2960.method_60654("minecraft:village/snowy/houses"),
                Monobank.ID + ":village/houses/snowy_vault",  class_3785.class_3786.field_16687, vaultWeight);

        // Injecting custom street that has smaller bounding box. Without it vaults will not generate.
        VillageStructures.addStructureToPoolLegacy(templatePools, streetPlainsProcessorList,
                class_2960.method_60654("minecraft:village/savanna/streets"),
                Monobank.ID + ":village/streets/savanna_straight_fix_01", class_3785.class_3786.field_16686, vaultWeight);

        VillageStructures.addStructureToPoolSingle(templatePools, mossify10ProcessorList,
                class_2960.method_60654("minecraft:village/savanna/houses"),
                Monobank.ID + ":village/houses/savanna_vault",  class_3785.class_3786.field_16687, vaultWeight);
    }

    private static void addStructureToPoolLegacy(class_2378<class_3785> templatePoolRegistry,
                                                 class_6880<class_5497> processorListHolder,
                                                 class_2960 poolRL,
                                                 String nbtPieceRL,
                                                 class_3785.class_3786 projection,
                                                 int weight) {
        class_3785 pool = templatePoolRegistry.method_10223(poolRL);
        if (pool == null) {
            LOGGER.error("Pool '{}' not found.", poolRL);
            return;
        }

        class_3781 piece = class_3781.method_30426(nbtPieceRL, processorListHolder).apply(projection);
        addPieceToPool(piece, pool, weight);
    }

    private static void addStructureToPoolSingle(class_2378<class_3785> templatePoolRegistry,
                                                 class_6880<class_5497> processorListHolder,
                                                 class_2960 poolRL,
                                                 String nbtPieceRL,
                                                 class_3785.class_3786 projection,
                                                 int weight) {

        class_3785 pool = templatePoolRegistry.method_10223(poolRL);
        if (pool == null) {
            LOGGER.error("Pool '{}' not found.", poolRL);
            return;
        }

        class_3781 piece = class_3781.method_30435(nbtPieceRL, processorListHolder)
                .apply(projection);

        addPieceToPool(piece, pool, weight);
    }

    private static void addPieceToPool(class_3781 piece, class_3785 pool, int weight) {
        for (int i = 0; i < weight; i++) {
            pool.field_16680.add(piece);
        }

        List<Pair<class_3784, Integer>> listOfPieceEntries = new ArrayList<>(pool.field_16864);
        listOfPieceEntries.add(new Pair<>(piece, weight));
        pool.field_16864 = listOfPieceEntries;
    }
}

