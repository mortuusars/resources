package io.github.mortuusars.monobank;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1087;
import net.minecraft.class_1091;

public class PlatformHelperClient {
    @ExpectPlatform
    public static class_1087 getModel(class_1091 model) {
        throw new AssertionError();
    }
}
