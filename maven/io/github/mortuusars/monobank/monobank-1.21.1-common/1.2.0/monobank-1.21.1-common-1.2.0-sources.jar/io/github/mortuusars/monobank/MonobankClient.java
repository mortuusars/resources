package io.github.mortuusars.monobank;

import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import io.github.mortuusars.monobank.world.block.monobank.component.Lock;
import net.minecraft.class_1091;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_5272;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class MonobankClient {
    @SuppressWarnings("deprecation")
    public static void init() {
        class_5272.method_27879(Monobank.Items.MONOBANK.get(), Monobank.resource("locked"), (stack, level, entity, seed) -> {
            class_9279 tag = stack.method_57825(class_9334.field_49611, class_9279.field_49302);
            if (tag.method_57463().method_10573(MonobankBlockEntity.LOCK_TAG, class_2520.field_33260)) {
                class_2487 lockTag = tag.method_57463().method_10562(MonobankBlockEntity.LOCK_TAG);
                return lockTag.method_10577(Lock.LOCKED_TAG) ? 1 : 0;
            }
            return 0;
        });
    }

    public static class Models {
        public static final class_1091 MONOBANK_DOOR =
                new class_1091(Monobank.resource("monobank_door"), "standalone");
    }
}
