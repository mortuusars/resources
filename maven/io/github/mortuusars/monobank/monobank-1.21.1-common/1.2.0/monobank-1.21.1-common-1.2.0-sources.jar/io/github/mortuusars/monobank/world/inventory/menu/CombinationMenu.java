package io.github.mortuusars.monobank.world.inventory.menu;

import io.github.mortuusars.monobank.Monobank;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import io.github.mortuusars.monobank.world.block.monobank.component.Combination;
import io.github.mortuusars.monobank.world.inventory.MatchTemplateSlot;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1712;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_3222;
import org.jetbrains.annotations.NotNull;

public class CombinationMenu extends class_1703 implements class_1712 {
    protected final class_1263 keyContainer = new class_1277(Combination.SIZE);
    protected final MonobankBlockEntity blockEntity;
    protected final Combination combination;
    protected final class_1657 player;
    protected final class_1937 level;

    public CombinationMenu(int containerID, class_1661 playerInventory, MonobankBlockEntity blockEntity, Combination combination) {
        super(Monobank.MenuTypes.MONOBANK_COMBINATION.get(), containerID);
        this.blockEntity = blockEntity;
        this.combination = combination;
        this.player = playerInventory.field_7546;
        this.level = playerInventory.field_7546.method_37908();

        method_7596(this);

        method_7621(new MatchTemplateSlot(keyContainer, 0, 80, 35, new class_1799(combination.getItem(0))));
        method_7621(new MatchTemplateSlot(keyContainer, 1, 101, 35, new class_1799(combination.getItem(1))));
        method_7621(new MatchTemplateSlot(keyContainer, 2, 122, 35, new class_1799(combination.getItem(2))));

        // Player hotbar slots
        for (int column = 0; column < 9; ++column) {
            method_7621(new class_1735(playerInventory, column, 8 + column * 18, 142));
        }

        // Player inventory slots
        for (int row = 0; row < 3; ++row) {
            for (int column = 0; column < 9; ++column) {
                method_7621(new class_1735(playerInventory, column + row * 9 + 9, 8 + column * 18, 84 + row * 18));
            }
        }

        // Empty combination should be handled earlier - this is just to be safe.
        if (!level.field_9236 && blockEntity.getLock().getCombination().isEmpty()) {
            blockEntity.startUnlocking(playerInventory.field_7546);
        }
    }

    public static CombinationMenu fromBuffer(int containerID, class_1661 playerInventory, class_2540 buffer) {
        class_2338 pos = buffer.method_10811();
        class_2586 blockEntityAtPos = playerInventory.field_7546.method_37908().method_8321(pos);
        if (blockEntityAtPos instanceof MonobankBlockEntity blockEntity) {
            return new CombinationMenu(containerID, playerInventory, blockEntity, Combination.fromBuffer(buffer));
        } else {
            throw new IllegalStateException("Block entity at pos '" + pos + "' is not MonobankBlockEntity, but " + blockEntityAtPos);
        }
    }

    // --

    public MonobankBlockEntity getBlockEntity() {
        return blockEntity;
    }

    public Combination getCombination() {
        return combination;
    }

    // --

    @Override
    public @NotNull class_1799 method_7601(class_1657 player, int index) {
        class_1735 clickedSlot = this.field_7761.get(index);
        if (!clickedSlot.method_7681()) {
            return class_1799.field_8037;
        }

        class_1799 clickedSlotStack = clickedSlot.method_7677();

        if (index < 3) { // From lock
            // Count should be 1 always, but if not - remove all:
            class_1799 removedStack = clickedSlot.method_7671(clickedSlotStack.method_7947());

            // Try to insert removed portion into player's inventory.
            // Stack's count will be decreased by the amount inserted.
            this.method_7616(removedStack, 3, this.field_7761.size(), false);

            if (!removedStack.method_7960()) {
                // Insert remainder back:
                clickedSlot.method_32756(removedStack);
            }
        } else {
            boolean insertedToMatching = false;
            for (int i = 0; i < Combination.SIZE; i++) {
                if (field_7761.get(i) instanceof MatchTemplateSlot matchTemplateSlot
                        && !matchTemplateSlot.method_7681()
                        && getCombination().matches(i, clickedSlotStack)
                        && matchTemplateSlot.method_7680(clickedSlotStack)) {
                    matchTemplateSlot.method_32756(clickedSlotStack.method_7971(1));
                    insertedToMatching = true;
                    break;
                }
            }

            if (!insertedToMatching) {
                for (int i = 0; i < Combination.SIZE; i++) {
                    if (field_7761.get(i) instanceof MatchTemplateSlot matchTemplateSlot
                            && !matchTemplateSlot.method_7681()
                            && matchTemplateSlot.method_7680(clickedSlotStack)) {
                        matchTemplateSlot.method_32756(clickedSlotStack.method_7971(1));
                        break;
                    }
                }
            }
        }
        return class_1799.field_8037;
    }

    @Override
    public void method_7595(class_1657 player) {
        if (!player.method_37908().field_9236) {
            for (int i = 0; i < keyContainer.method_5439(); i++) {
                class_1799 item = keyContainer.method_5438(i);
                if (!item.method_7960()) {
                    if (!player.method_7270(item)) {
                        player.method_7328(item, false);
                    }
                    keyContainer.method_5447(i, class_1799.field_8037); // Just to be sure.
                }
            }
        }

        super.method_7595(player);
    }

    // Called server-side.
    @Override
    public boolean method_7597(class_1657 player) {
        return blockEntity.getLock().isLocked() && !blockEntity.getLock().isUnlocking() && blockEntity.method_5443(player);
    }

    @Override
    public void method_7635(class_1703 containerToSend, int slotIndex, class_1799 stack) {
        if (slotIndex >= 0 && slotIndex < Combination.SIZE && getCombination().matches(slotIndex, stack)) {
            blockEntity.playSoundAtDoor(Monobank.SoundEvents.MONOBANK_CLICK.get());
        }

        if (getCombination().matches(keyContainer)) {
            blockEntity.startUnlocking(player);
            if (player instanceof class_3222 serverPlayer) {
                Monobank.CriteriaTriggers.MONOBANK_UNLOCKED.get().trigger(serverPlayer, blockEntity);
            }
        }
    }

    @Override
    public void method_7633(class_1703 containerMenu, int dataSlotIndex, int value) { }
}
