package io.github.mortuusars.monobank.world.block.monobank.component;

import org.jetbrains.annotations.NotNull;

import java.util.*;
import java.util.stream.Collectors;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_3542;

public class Owner {
    private static final String TYPE_NBT_KEY = "Type";
    private static final String UUID_NBT_KEY = "UUID";

    private UUID uuid;
    private Type type;

    public Owner(UUID uuid, Type type) {
        this.uuid = uuid;
        this.type = type;
    }

    public Owner(class_1657 player) {
        this.uuid = player.method_5667();
        this.type = Type.PLAYER;
    }

    public static Owner none() {
        return new Owner(class_156.field_25140, Type.NONE);
    }

    public void setOwner(class_1657 player) {
        Objects.requireNonNull(player);
        uuid = player.method_5667();
        type = Type.PLAYER;
    }

    public void setOwner(Type type) {
        if (type == Type.PLAYER)
            throw new IllegalArgumentException("Cannot set owner to 'Type.PLAYER' without setting UUID. Use setOwner(Player player) overload.");
        this.type = type;
        this.uuid = class_156.field_25140;
    }

    public Type getType() {
        return type;
    }

    public UUID getUuid() {
        return uuid;
    }

    public boolean hasOwner() {
        return type == Type.PLAYER || type == Type.NPC;
    }

    public boolean isPlayerOwned() {
        return type == Type.PLAYER && !uuid.equals(class_156.field_25140);
    }

    public boolean isNpcOwned() {
        return type == Type.NPC;
    }

    public boolean isOwnedBy(class_1657 player) {
        return isPlayerOwned() && uuid.equals(player.method_5667());
    }

    public class_2487 serializeNBT() {
        class_2487 tag = new class_2487();
        if (type != Type.NONE) {
            tag.method_10582(TYPE_NBT_KEY, type.method_15434());
            if (isPlayerOwned())
                tag.method_25927(UUID_NBT_KEY, uuid);
        }
        return tag;
    }

    public void deserializeNBT(class_2487 tag) {
        if (tag.method_10545(TYPE_NBT_KEY)) {
            type = Type.byName(tag.method_10558(TYPE_NBT_KEY));
            if (tag.method_10545(UUID_NBT_KEY))
                uuid = tag.method_25926(UUID_NBT_KEY);
        }
    }

    public enum Type implements class_3542 {
        NONE("none"),
        PLAYER("player"),
        NPC("npc");

        private final String name;
        private static final Map<String, Type> BY_NAME = Arrays.stream(values())
                .collect(Collectors.toMap(Type::method_15434, ownershipType -> ownershipType));

        Type(String name) {
            this.name = name;
        }

        public static Type byName(String name) {
            if (name == null)
                throw new IllegalArgumentException("'name' cannot be null.");
            return BY_NAME.get(name.toLowerCase(Locale.ROOT));
        }

        @Override
        public @NotNull String method_15434() {
            return name;
        }
    }
}
