package io.github.mortuusars.monobank.advancement.trigger;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_2048;
import net.minecraft.class_2090;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public class MonobankUnlockedTrigger extends class_4558<MonobankUnlockedTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player, MonobankBlockEntity blockEntity) {
        this.method_22510(player, triggerInstance -> triggerInstance.matches(player, blockEntity));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  Optional<class_2090> location) implements class_4558.class_8788 {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                        class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::comp_2029),
                        class_2090.field_45760.optionalFieldOf("location").forGetter(TriggerInstance::location))
                .apply(instance, TriggerInstance::new));

        public boolean matches(class_3222 player, MonobankBlockEntity blockEntity) {
            if (location.isEmpty()) return true;
            class_2338 pos = blockEntity.method_11016();
            return location.get().method_9018(player.method_51469(), pos.method_10263(), pos.method_10264(), pos.method_10260());
        }
    }
}