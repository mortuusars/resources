package io.github.mortuusars.monobank.world.block.monobank;

import com.google.common.base.Preconditions;
import io.github.mortuusars.monobank.Config;
import io.github.mortuusars.monobank.Monobank;
import io.github.mortuusars.monobank.PlatformHelper;
import io.github.mortuusars.monobank.integration.Mods;
import io.github.mortuusars.monobank.integration.thief.ThiefIntegration;
import io.github.mortuusars.monobank.world.inventory.menu.MonobankMenu;
import io.github.mortuusars.monobank.world.inventory.menu.CombinationMenu;
import io.github.mortuusars.monobank.world.block.monobank.component.*;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1275;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2618;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3908;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5561;
import net.minecraft.class_7225;
import net.minecraft.class_8934;
import net.minecraft.class_9279;
import net.minecraft.class_9323;
import net.minecraft.class_9334;
import net.minecraft.world.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class MonobankBlockEntity extends class_2586 implements class_1275, class_2618, class_8934 {
    public static final String ITEM_TAG = "Item";
    public static final String ITEM_COUNT_TAG = "ItemCount";
    public static final String LOCK_TAG = "Lock";
    public static final String OWNER_TAG = "Owner";
    public static final String WARNINGS_SEEN_COUNT_TAG = "WarningsSeenCount";
    public static final String BREAK_IN_SUCCEEDED_TAG = "BreakInSucceeded";
    public static final String BREAK_IN_ATTEMPTED_TAG = "BreakInAttempted";
    public static final String CUSTOM_NAME_TAG = "CustomName";

    protected static final int UPDATE_DOOR_EVENT_ID = 1;

    protected final class_5561 openersCounter = new MonobankOpenersCounter(this);
    protected final DoorOpennessController doorOpennessController = new DoorOpennessController(0.5f,
            0.35f, 0.6f, 0.65f, 0.36f);

    protected class_1799 item;

    protected @Nullable class_5321<class_52> lootTable;
    protected long lootTableSeed = 0L;

    protected final Lock lock;
    protected Owner owner;
    protected int warningsSeenCount;
    protected boolean breakInAttempted, breakInSucceeded;
    protected @Nullable class_2561 customName;

    protected float fullness = -1;

    public MonobankBlockEntity(class_2338 pos, class_2680 state) {
        super(Monobank.BlockEntityTypes.MONOBANK.get(), pos, state);
        this.item = class_1799.field_8037;
        this.lock = new Lock(this::onLockedChanged);
        this.owner = Owner.none();
    }

    // -- Tick

    public static <T extends class_2586> void clientTick(class_1937 level, class_2338 blockPos, class_2680 blockState, T blockEntity) {
        if (blockEntity instanceof MonobankBlockEntity monobankEntity) {
            monobankEntity.doorOpennessController.tickDoor();
        }
    }

    public static <T extends class_2586> void serverTick(class_1937 level, class_2338 blockPos, class_2680 blockState, T blockEntity) {
        if (level instanceof class_3218 serverLevel && blockEntity instanceof MonobankBlockEntity monobankEntity) {
            monobankEntity.tick(serverLevel);
        }
    }

    public void tick(class_3218 serverLevel) {
        getLock().tick(serverLevel, this);

        if (!getLock().isLocked() && method_54869() != null) {
            method_54873(null);
            method_5431();
        }
    }

    // --

    public int getCapacity() {
        return Config.Server.MONOBANK_CAPACITY.get();
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    public boolean canReplaceLock(class_1657 player) {
        if (getLock().isLocked()) return false;
        if (!getOwner().isPlayerOwned()) return true;
        if (getOwner().isOwnedBy(player)) return true;
        return Config.Server.CAN_REPLACE_OTHER_PLAYERS_LOCKS.get();
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return class_1263.method_49105(this, player);
    }

    // -- Lock

    public Lock getLock() {
        return lock;
    }

    public boolean replaceLock(class_1657 player, Combination combination) {
        if (!canReplaceLock(player)) return false;

        getLock().setCombination(combination);
        setOwner(player);
        playSoundAtDoor(Monobank.SoundEvents.MONOBANK_CLICK.get()); // TODO: Lock Replacement Sound

        if (player instanceof class_3222 serverPlayer) {
            Monobank.CriteriaTriggers.MONOBANK_LOCK_REPLACED.get().trigger(serverPlayer, this);
        }

        method_5431();

        return true;
    }

    /**
     * Starts the countdown after which Monobank will unlock.
     */
    public void startUnlocking(class_1657 player) {
        if (field_11863 == null) return;
        startUnlocking(player, field_11863.method_8409().method_43051(20, 61));
    }

    /**
     * Starts the countdown for specified amount of ticks after which Monobank will unlock.
     */
    public void startUnlocking(class_1657 player, int ticks) {
        if (getLock().isUnlocking()) return;

        if (Mods.THIEF.isLoaded() && player instanceof class_3222 serverPlayer) {
            ThiefIntegration.unlocked(serverPlayer, this);
        }

        if (getOwner().isPlayerOwned() && !getOwner().isOwnedBy(player)) {
            breakInSucceeded = true;
        }

        getLock().startUnlocking(ticks);

        method_5431();
    }

    protected void onLockedChanged() {
        boolean isLocked = getLock().isLocked();
        doorOpennessController.setLocked(isLocked);

        if (field_11863 != null && !field_11863.field_9236) {
            class_3414 sound = isLocked ? Monobank.SoundEvents.MONOBANK_LOCK.get() : Monobank.SoundEvents.MONOBANK_UNLOCK.get();
            playSoundAtDoor(sound);
        }

        method_5431();
    }

    // -- Ownership

    public Owner getOwner() {
        return owner;
    }

    public void setOwner(Owner owner) {
        this.owner = owner;
        method_5431();
    }

    public void setOwner(class_1657 player) {
        setOwner(new Owner(player));
    }

    public void onSetPlacedBy(@Nullable class_1309 placer, class_1799 stack) {
        if (placer instanceof class_1657 player && !player.method_37908().field_9236) {
            if (getOwner().getType() == Owner.Type.NONE) {
                setOwner(player);
            }

            if (!getLock().hasCombination()) {
                getLock().setCombinationTable(Monobank.LootTables.COMBINATION_DEFAULT);
            }

            method_5431();
        }
    }

    // -- GUI

    public void openUnlockingGui(class_3222 player) {
        if (!getLock().isLocked()) {
            return;
        }

        getLock().unpackCombinationTableIfNeeded(player.method_51469(), method_11016());

        if (getLock().getCombination().isEmpty()) {
            startUnlocking(player);
        } else {
            if (Mods.THIEF.isLoaded()) {
                ThiefIntegration.unlockingGuiOpened(player, this);
            }

            if (getOwner().isPlayerOwned() && !getOwner().isOwnedBy(player)) {
                breakInAttempted = true;
                method_5431();
            }

            PlatformHelper.openMenu(player, new class_3908() {
                @Override
                public @NotNull class_2561 method_5476() {
                    return class_2561.method_43469("monobank.gui.monobank.unlocking", MonobankBlockEntity.this.method_5477());
                }

                @Override
                public @NotNull class_1703 createMenu(int containerID, class_1661 playerInventory, class_1657 player1) {
                    return new CombinationMenu(containerID, playerInventory, MonobankBlockEntity.this,
                            MonobankBlockEntity.this.getLock().getCombination());
                }
            }, buffer -> {
                buffer.method_10807(field_11867);
                getLock().getCombination().toBuffer(buffer);
            });
        }
    }

    public void open(class_3222 player) {
        if (Mods.THIEF.isLoaded() && player instanceof class_3222 serverPlayer) {
            ThiefIntegration.opened(serverPlayer, this);
        }

        PlatformHelper.openMenu(player, new class_3908() {
            @Override
            public @NotNull class_2561 method_5476() {
                return MonobankBlockEntity.this.method_5477();
            }

            @Override
            public @NotNull class_1703 createMenu(int containerID, class_1661 playerInventory, class_1657 player1) {
                return new MonobankMenu(containerID, playerInventory, MonobankBlockEntity.this,
                        MonobankBlockEntity.this.getExtraInfo(player1));
            }
        }, buffer -> {
            buffer.method_10807(field_11867);
            getExtraInfo(player).toBuffer(buffer);
        });
    }

    /**
     * Used to provide gui with extra info.
     */
    public MonobankExtraInfo getExtraInfo(class_1657 player) {
        return new MonobankExtraInfo(getOwner().isOwnedBy(player), breakInAttempted, breakInSucceeded);
    }

    @Override
    public void method_11012() {
        super.method_11012();
    }

    public void inventoryChanged() {
        updateFullness();
        method_5431();
        // Advancement
        if (field_11863 != null && !field_11863.field_9236 && field_11863.method_8503() != null && getOwner().isPlayerOwned()) {
            @Nullable class_3222 player = field_11863.method_8503().method_3760().method_14602(getOwner().getUuid());
            if (player != null) {
                Monobank.CriteriaTriggers.MONOBANK_INVENTORY_CHANGED.get().trigger(player, this, getItem());
            }
        }
    }

    @Override
    public boolean method_11004(int id, int param) {
        if (id == UPDATE_DOOR_EVENT_ID) {
            this.doorOpennessController.shouldBeOpen(param > 0);
            return true;
        } else {
            return super.method_11004(id, param);
        }
    }

    // -- Openers Counter

    public void method_5435(class_1657 player) {
        if (field_11863 != null && !this.field_11865 && !player.method_7325()) {
            this.openersCounter.method_31684(player, field_11863, this.method_11016(), this.method_11010());
        }
    }

    public void method_5432(class_1657 player) {
        if (field_11863 != null && !this.field_11865 && !player.method_7325()) {
            this.openersCounter.method_31685(player, field_11863, this.method_11016(), this.method_11010());

            if (getOwner().isOwnedBy(player)) {
                if (breakInAttempted || breakInSucceeded) {
                    warningsSeenCount++;
                }

                if (warningsSeenCount >= 3) {
                    breakInAttempted = false;
                    breakInSucceeded = false;
                    warningsSeenCount = 0;
                }
            }
        }
    }

    public void recheckOpen() {
        if (field_11863 != null && !this.field_11865) {
            this.openersCounter.method_31686(field_11863, this.method_11016(), this.method_11010());
        }
    }

    @Override
    public float method_11274(float partialTicks) {
        return this.doorOpennessController.getOpenness(partialTicks);
    }

    // -- Name

    @Override
    public @NotNull class_2561 method_5476() {
        return method_5477();
    }

    public @NotNull class_2561 method_5477() {
        return this.customName != null ? this.customName : class_2561.method_43471("monobank.gui.monobank");
    }

    public void setCustomName(@Nullable class_2561 customName) {
        this.customName = customName;
    }

    // -- Inventory


    @Override
    public int method_5444() {
        return getCapacity();
    }

    public class_1799 getItem() {
        return item;
    }

    public float getFullness() {
        return fullness;
    }

    public void updateFullness() {
        fullness = class_3532.method_15363(getItem().method_7947() / (float) getCapacity(), 0.0f, 1.0f);
    }

    @Override
    public int method_5439() {
        return 1;
    }

    @Override
    public boolean method_5442() {
        return getItem().method_7960();
    }

    @Override
    public @NotNull class_1799 method_5438(int slot) {
        checkSlotIndex(slot);
        return item;
    }

    @Override
    public @NotNull class_1799 method_5434(int slot, int amount) {
        checkSlotIndex(slot);
        class_1799 stack = item.method_7971(Math.min(item.method_7947(), amount));

        if (item.method_7960()) {
            item = class_1799.field_8037;
        }

        inventoryChanged();
        return stack;
    }

    @Override
    public @NotNull class_1799 method_5441(int slot) {
        checkSlotIndex(slot);
        class_1799 stack = item.method_7972();
        item = class_1799.field_8037;
        return stack;
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        checkSlotIndex(slot);
        item = stack;
        inventoryChanged();
    }

    @Override
    public void method_5448() {
        item = class_1799.field_8037;
        inventoryChanged();
    }

    protected void checkSlotIndex(int slot) {
        Preconditions.checkElementIndex(slot, 1);
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return !Config.Server.LOCK_PREVENTS_ITEM_INSERTION.get() || !getLock().isLocked();
    }

    @Override
    public boolean method_49104(class_1263 target, int slot, class_1799 stack) {
        return !Config.Server.LOCK_PREVENTS_ITEM_EXTRACTION.get() || !getLock().isLocked();
    }

    // -- Loot Table

    @Override
    public @Nullable class_5321<class_52> method_54869() {
        return lootTable;
    }

    @Override
    public void method_11285(@Nullable class_5321<class_52> lootTable) {
        this.lootTable = lootTable;
    }

    @Override
    public long method_54870() {
        return lootTableSeed;
    }

    @Override
    public void method_54866(long seed) {
        this.lootTableSeed = seed;
    }

    // -- Save / Load

    @Override
    protected void method_57567(class_9323.class_9324 components) {
        if (field_11863 != null) {
            components.method_57840(class_9334.field_49611, class_9279.method_57456(method_38243(field_11863.method_30349())));
        }
    }

    @Override
    protected void method_57568(class_9473 componentInput) {
        super.method_57568(componentInput);
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        if (!method_54872(tag) && !item.method_7960()) {
            class_1799 savedStack = item.method_7972();
            savedStack.method_7939(1);
            class_2520 itemTag = savedStack.method_57358(registries);

            tag.method_10566(ITEM_TAG, itemTag);
            tag.method_10569(ITEM_COUNT_TAG, item.method_7947());
        }
        tag.method_10566(LOCK_TAG, lock.save());
        if (owner.getType() != Owner.Type.NONE) {
            tag.method_10566(OWNER_TAG, owner.serializeNBT());
        }
        if (this.customName != null) {
            tag.method_10582(CUSTOM_NAME_TAG, class_2561.class_2562.method_10867(this.customName, registries));
        }

        if (getOwner().isPlayerOwned()) {
            if (warningsSeenCount > 0) {
                tag.method_10569(WARNINGS_SEEN_COUNT_TAG, warningsSeenCount);
            }
            if (breakInAttempted) {
                tag.method_10556(BREAK_IN_ATTEMPTED_TAG, true);
            }
            if (breakInSucceeded) {
                tag.method_10556(BREAK_IN_SUCCEEDED_TAG, true);
            }
        }
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        if (!method_54871(tag)) {
            class_2487 itemTag = tag.method_10562(ITEM_TAG);
            if (itemTag.method_33133()) {
                item = class_1799.field_8037;
            } else {
                class_1799.method_57360(registries, itemTag).ifPresent(stack -> {
                    item = stack;
                    stack.method_7939(tag.method_10550(ITEM_COUNT_TAG));
                });
            }
        }
        lock.load(tag.method_10562(LOCK_TAG));
        if (tag.method_10573(OWNER_TAG, class_2487.field_33260)) {
            owner.deserializeNBT(tag.method_10562(OWNER_TAG));
        }
        if (tag.method_10573(CUSTOM_NAME_TAG, class_2487.field_33258)) {
            this.customName = class_2561.class_2562.method_10877(tag.method_10558(CUSTOM_NAME_TAG), registries);
        }
        warningsSeenCount = tag.method_10550(WARNINGS_SEEN_COUNT_TAG);
        breakInSucceeded = tag.method_10577(BREAK_IN_SUCCEEDED_TAG);
        breakInAttempted = tag.method_10577(BREAK_IN_ATTEMPTED_TAG);
        updateFullness();
        doorOpennessController.setLocked(lock.isLocked());
    }

    @Override
    public void method_5431() {
        super.method_5431();
        if (field_11863 != null && !field_11863.field_9236) {
            field_11863.method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31028);
        }
    }

    // -- Sync

    @Override
    @Nullable
    public class_2622 method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public @NotNull class_2487 method_16887(class_7225.class_7874 registries) {
        return method_38244(registries);
    }

    // -- Util

    public void dropItemsAtDoor(List<class_1799> items) {
        class_2382 facingNormal = method_11010().method_11654(MonobankBlock.FACING).method_10163();
        double x = field_11867.method_10263() + 0.5D + (facingNormal.method_10263() * 0.6D);
        double y = field_11867.method_10264() + 0.5D;
        double z = field_11867.method_10260() + 0.5D + (facingNormal.method_10260() * 0.6D);
        for (class_1799 stack : items) {
            assert field_11863 != null;
            class_1264.method_5449(field_11863, x, y, z, stack);
        }
    }

    public void playSoundAtDoor(class_3414 sound) {
        playSoundAtDoor(sound, 1f, 1f);
    }

    public void playSoundAtDoor(class_3414 sound, float volume, float pitch) {
        playSoundAtDoor(null, sound, volume, pitch);
    }

    public void playSoundAtDoor(@Nullable class_1657 player, class_3414 sound) {
        playSoundAtDoor(player, sound, 1f, 1f);
    }

    public void playSoundAtDoor(@Nullable class_1657 player, class_3414 sound, float volume, float pitch) {
        if (field_11863 == null) return;

        // Offset sound source to door pos:
        class_2382 facingNormal = method_11010().method_11654(MonobankBlock.FACING).method_10163();
        class_2338 pos = method_11016();
        double x = pos.method_10263() + 0.5D + (facingNormal.method_10263() * 0.5D);
        double y = pos.method_10264() + 0.5D;
        double z = pos.method_10260() + 0.5D + (facingNormal.method_10260() * 0.5D);

        field_11863.method_43128(player, x, y, z, sound, class_3419.field_15245, volume, pitch);
    }
}
