package io.github.mortuusars.monobank.client.gui.rendering;

import net.minecraft.class_1087;
import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_1309;
import net.minecraft.class_148;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4608;
import net.minecraft.class_746;
import net.minecraft.class_765;
import net.minecraft.class_811;
import org.jetbrains.annotations.Nullable;

/**
 * Contains modified copies of GuiGraphics methods with the ability to render slots bigger than 16px.
 */
public class ExtendedSlotRenderer {
    public static void renderFakeItem(class_332 guiGraphics, class_1799 stack, int x, int y,
                                      int seed, int zOffset, int packedLight, float width, float height) {
        renderItem(guiGraphics, null, class_310.method_1551().field_1687, stack, x, y, seed, zOffset, packedLight, width, height);
    }

    public static void renderFakeItem(class_332 guiGraphics, class_1799 stack, int x, int y,
                                  int seed, int zOffset, float width, float height) {
        renderItem(guiGraphics, null, class_310.method_1551().field_1687, stack, x, y, seed, zOffset, class_765.field_32767, width, height);
    }

    public static void renderItem(class_332 guiGraphics, class_1799 stack, int x, int y,
                                  int seed, int zOffset, float width, float height) {
        renderItem(guiGraphics, class_310.method_1551().field_1724, class_310.method_1551().field_1687, stack, x, y, seed, zOffset, class_765.field_32767, width, height);
    }

    public static void renderItem(class_332 guiGraphics, @Nullable class_1309 entity, @Nullable class_1937 level,
                                  class_1799 stack, int x, int y, int seed, int zOffset, int packedLight, float width, float height) {
        if (stack.method_7960()) return;

        class_1087 model = class_310.method_1551().method_1480().method_4019(stack, level, entity, seed);
        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(x + width / 2, y + height / 2, (float)(150 + (model.method_4712() ? zOffset : 0)));

        try {
            guiGraphics.method_51448().method_22905(width, -height, width);
            boolean useFlatLighting = !model.method_24304();
            if (useFlatLighting) {
                class_308.method_24210();
            }

            class_310.method_1551().method_1480().method_23179(stack, class_811.field_4317, false,
                    guiGraphics.method_51448(), guiGraphics.method_51450(), packedLight, class_4608.field_21444, model);

            guiGraphics.method_51452();

            if (useFlatLighting) {
                class_308.method_24211();
            }
        } catch (Throwable var12) {
            class_128 crashreport = class_128.method_560(var12, "Rendering item");
            class_129 crashreportcategory = crashreport.method_562("Item being rendered");
            crashreportcategory.method_577("Item Type", () -> String.valueOf(stack.method_7909()));
            crashreportcategory.method_577("Item Components", () -> String.valueOf(stack.method_57353()));
            crashreportcategory.method_577("Item Foil", () -> String.valueOf(stack.method_7958()));
            throw new class_148(crashreport);
        }

        guiGraphics.method_51448().method_22909();
    }

    public static void renderItemDecorations(class_332 guiGraphics, class_327 font, class_1799 stack, int x, int y, @Nullable String count, int width, int height) {
        if (stack.method_7960()) return;

        renderDurabilityBar(guiGraphics, stack, x, y, width, height);
        renderCount(guiGraphics, font, stack, x, y, count, width, height);
        renderCooldownOverlay(guiGraphics, stack, x, y, width, height);
    }

    private static void renderDurabilityBar(class_332 guiGraphics, class_1799 stack, int x, int y, int width, int height) {
        if (!stack.method_31578()) return;

        int leftRightPadding = (int) (2 / 16.0f * width);
        int bottomPadding = (int) (3 / 16.0f * height);

        int filledBarWidth = (int) (stack.method_31579() / 16f * width);
        int barColor = stack.method_31580();

        int barStartX = x + leftRightPadding;
        int barStartY = y + height - bottomPadding;

        int barThickness = Math.max(2, (int) (2 / 16.0f * height));
        int filledBarThickness = Math.max(1, (int) (1 / 16.0f * height));

        guiGraphics.method_48196(class_1921.method_51785(), barStartX, barStartY, barStartX + filledBarWidth, barStartY + barThickness, 100, 0xFF000000);
        guiGraphics.method_48196(class_1921.method_51785(), barStartX, barStartY, barStartX + filledBarWidth, barStartY + filledBarThickness, 110, barColor | 0xFF000000);
    }

    public static void renderCount(class_332 guiGraphics, class_327 font, class_1799 stack, int x, int y, @Nullable String count, int width, int height) {
        if (stack.method_7947() <= 1 && count == null) return;

        String countStr = count == null ? String.valueOf(stack.method_7947()) : count;

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_22904(0.0D, 0.0D, 200.0F);

        float startX = x + width + (1 / 16f * width) - font.method_1727(countStr);
        float startY = y + height + (2 / 16f * height) - font.field_2000;

        guiGraphics.method_51433(font, countStr, (int)startX, (int)startY, 0xFFFFFFFF, true);
        guiGraphics.method_51448().method_22909();
    }

    public static void renderCooldownOverlay(class_332 guiGraphics, class_1799 stack, int x, int y, int width, int height) {
        class_746 player = class_310.method_1551().field_1724;
        float cooldownPercent = player == null ? 0.0F : player.method_7357().method_7905(stack.method_7909(), class_310.method_1551().method_60646().method_60637(true));
        if (cooldownPercent > 0.0F) {
            guiGraphics.method_51739(class_1921.method_51785(), x, y + class_3532.method_15375(height * (1.0F - cooldownPercent)), width, class_3532.method_15386(height * cooldownPercent), 0x7FFFFFFF);
        }
    }
}
