package io.github.mortuusars.monobank.integration.thief;

import io.github.mortuusars.monobank.Config;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import io.github.mortuusars.thief.world.Crime;
import java.util.Optional;
import net.minecraft.class_3222;

public class ThiefIntegration {
    public static void unlockingGuiOpened(class_3222 player, MonobankBlockEntity blockEntity) {
        convertCrime(Config.Server.THIEF_CRIME_FOR_UNLOCKING_ATTEMPT.get()).ifPresent(crime ->
                crime.commit(player.method_51469(), player, blockEntity.method_11016()));
    }

    public static void unlocked(class_3222 player, MonobankBlockEntity blockEntity) {
        convertCrime(Config.Server.THIEF_CRIME_FOR_UNLOCKING.get()).ifPresent(crime ->
                crime.commit(player.method_51469(), player, blockEntity.method_11016()));
    }

    public static void opened(class_3222 player, MonobankBlockEntity blockEntity) {
        convertCrime(Config.Server.THIEF_CRIME_FOR_OPENING.get()).ifPresent(crime ->
                crime.commit(player.method_51469(), player, blockEntity.method_11016()));
    }

    public static Optional<Crime> convertCrime(ThiefCrime crime) {
        return switch (crime) {
            case NONE -> Optional.empty();
            case LIGHT -> Optional.of(Crime.LIGHT);
            case MEDIUM -> Optional.of(Crime.MEDIUM);
            case HEAVY -> Optional.of(Crime.HEAVY);
        };
    }
}
