package io.github.mortuusars.monobank.world.item;

import io.github.mortuusars.monobank.Monobank;
import io.github.mortuusars.monobank.PlatformHelper;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import io.github.mortuusars.monobank.world.inventory.menu.LockReplacementMenu;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import org.jetbrains.annotations.NotNull;

public class ReplacementLockItem extends class_1792 {
    public ReplacementLockItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_1937 level = context.method_8045();
        class_2338 clickedPos = context.method_8037();

        class_2586 blockEntityAtPos = level.method_8321(clickedPos);

        if (!(blockEntityAtPos instanceof MonobankBlockEntity blockEntity)) {
            return class_1269.field_5811;
        }

        if (!(context.method_8036() instanceof class_3222 player)) {
            return class_1269.method_29236(true);
        }

        if (blockEntity.getLock().isLocked()) {
            player.method_7353(class_2561.method_43471(
                    "monobank.message.replacement_lock.cannot_replace_when_locked"), true);
            blockEntity.playSoundAtDoor(Monobank.SoundEvents.MONOBANK_CLICK.get());
            return class_1269.field_5814;
        }

        if (!blockEntity.canReplaceLock(player)) {
            player.method_7353(class_2561.method_43471(
                    "monobank.message.replacement_lock.cannot_replace_not_owner"), true);
            blockEntity.playSoundAtDoor(Monobank.SoundEvents.MONOBANK_CLICK.get());
            return class_1269.field_5814;
        }

        PlatformHelper.openMenu(player, new class_3908() {
            @Override
            public @NotNull class_2561 method_5476() {
                return class_2561.method_43469("monobank.gui.monobank.lock_replacement", blockEntity.method_5477());
            }

            @Override
            public class_1703 createMenu(int containerId, class_1661 playerInventory, class_1657 player) {
                return new LockReplacementMenu(containerId, playerInventory, blockEntity);
            }
        }, buffer -> buffer.method_10807(clickedPos));

        return class_1269.method_29236(false);
    }
}
