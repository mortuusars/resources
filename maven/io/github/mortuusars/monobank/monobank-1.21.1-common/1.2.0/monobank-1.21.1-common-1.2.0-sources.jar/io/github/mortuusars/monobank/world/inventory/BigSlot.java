package io.github.mortuusars.monobank.world.inventory;

import io.github.mortuusars.monobank.util.NumberFormatter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class BigSlot extends class_1735 implements ResizeableSlot {
    private final int width;
    private final int height;
    private final int capacity;

    public BigSlot(class_1263 container, int index, int x, int y, int width, int height, int capacity) {
        super(container, index, x, y);
        this.width = width;
        this.height = height;
        this.capacity = capacity;
    }

    // Overriden to ignore ItemStack#getMaxCapacity.
    @Override
    public int method_7676(@NotNull class_1799 stack) {
        return capacity;
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    public @Nullable String getCountString() {
        if (!method_7681() || method_7677().method_7947() <= 1) return null;
        return NumberFormatter.shortenWithSuffix(method_7677().method_7947());
    }

    @Override
    public @NotNull Optional<class_1799> method_34264(int count, int decrement, class_1657 player) {
        int amountInSlot = method_7677().method_7947();
        int maxStackSize = method_7677().method_7914();
        // Somewhat stupid way to detect what button was pressed (left or right), it would be hard to do in properly,
        // as this method is called deep in Menu#doClick method.
        // Without this, when monobank slot is clicked, whole stack will be picked up (more than maxStackSize),
        // and it's annoying because it cannot be placed in inventory.
        // This makes picking up items from slot work like in regular inventory, up to 64 max.
        if (maxStackSize < amountInSlot) {
            count = count < amountInSlot
                    ? (maxStackSize + 1) / 2 // Half stack (right click)
                    : maxStackSize; // Full (left click)
        }
        return super.method_34264(count, decrement, player);
    }
}
