package io.github.mortuusars.monobank.world.inventory;

import io.github.mortuusars.monobank.Config;
import io.github.mortuusars.monobank.util.TextObfuscator;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import org.jetbrains.annotations.Nullable;

public class MatchTemplateSlot extends class_1735 {
    protected final class_1799 template;
    protected @Nullable class_2561 templateTooltip;

    public MatchTemplateSlot(class_1263 container, int index, int x, int y, class_1799 template) {
        super(container, index, x, y);
        this.template = template;
    }

    public class_1799 getTemplateItem() {
        return template;
    }

    public class_2561 getTemplateTooltip() {
        if (templateTooltip == null) {
            createTooltip();
        }
        return templateTooltip;
    }

    public boolean containedItemMatches() {
        return getTemplateItem().method_7909().equals(method_7677().method_7909());
    }

    protected void createTooltip() {
        if (getTemplateItem().method_7960()) {
            templateTooltip = class_2561.method_43471("monobank.gui.empty");
            return;
        }

        double obfuscationFactor = Config.Server.COMBINATION_HINT_TOOLTIP_OBFUSCATION.get();
        if (obfuscationFactor > 0) {
            String text = template.method_7964().method_10858(999);
            templateTooltip = TextObfuscator.obfuscate(text, obfuscationFactor, text.hashCode() + field_7874);
            return;
        }

        templateTooltip = class_2561.method_43470(template.method_7964().method_10858(999));
    }

    @Override
    public int method_7675() {
        return 1;
    }
}
