package io.github.mortuusars.monobank.client.renderer;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_918;

public class BlockContentsRenderer {
    protected static final int MAX_BLOCKS_COUNT = 8;

    // Hardcoded random rotations. Should have same size as MAX_BLOCKS_COUNT.
    protected List<Integer> yRotations = List.of(-4, 7, -10, 2, 2, -4, 0, 2);

    /**
     * Renders up to 8 blocks in a 2x2 grid depending on the fullness of the bank.
     * Proper rotation to block facing is expected here.
     */
    public void render(class_1799 stack, float fullness, class_2586 entity, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight, int packedOverlay) {
        class_918 itemRenderer = class_310.method_1551().method_1480();

        float pixel = 1f / 16f;
        float scale = 0.3f;
        float margin = 0.28f;
        int count =  class_3532.method_15340((int)(fullness * MAX_BLOCKS_COUNT), 1, MAX_BLOCKS_COUNT);

        poseStack.method_22903();
        poseStack.method_46416(0.5f, scale / 2 + (pixel * 2), 0.5f); // Position in the center and on the bank floor.
//        poseStack.mulPose(Vector3f.YP.rotationDegrees(90));
        poseStack.method_22905(scale, scale, scale);

        List<Integer> rows = new ArrayList<>();

        // Split by rows of 2:

        for (int i = 0; i < count; i++) {
            rows.add(0);
        }

        int elements = count;
        int row = 0;
        while (elements > 0) {
            if (rows.get(row) != 2) {
                rows.set(row, rows.get(row) + 1);
                elements--;
            }
            else
                row++;
        }

        // Calculate each row's item offsets

        int elementIndex = 0;

        for (int rowIndex = 0; rowIndex < rows.size(); rowIndex++) {
            Integer itemsInRow = rows.get(rowIndex);
            if (itemsInRow == 0)
                break;

            float xOffset = itemsInRow == 2 ? scale + margin : 0f;
            float yOffset = rowIndex >= 2 ? 1f : 0;
            float zOffset = rowIndex % 2 == 0 ? scale + margin : -(scale + margin);

            if (rowIndex % 2 == 0 && (rows.size() <= rowIndex + 1 || (rows.size() > rowIndex + 1 && rows.get(rowIndex + 1) == 0)))
                zOffset = 0f;

            for (int item = 0; item < itemsInRow; item++) {
                float itemXOffset = item == 0 ? -xOffset : xOffset;
                poseStack.method_22903();
                poseStack.method_46416(itemXOffset, yOffset, zOffset);
                poseStack.method_22907(class_7833.field_40716.rotationDegrees(180 + yRotations.get(elementIndex)));
                itemRenderer.method_23178(stack, class_811.field_4315, packedLight,
                        packedOverlay, poseStack, bufferSource, null, (int) entity.method_11016().method_10063());
                poseStack.method_22909();

                elementIndex++;
            }
        }

        poseStack.method_22909();
    }
}
