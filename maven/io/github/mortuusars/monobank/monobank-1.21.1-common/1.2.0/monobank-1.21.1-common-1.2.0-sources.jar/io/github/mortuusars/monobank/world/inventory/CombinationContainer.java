package io.github.mortuusars.monobank.world.inventory;

import io.github.mortuusars.monobank.world.block.monobank.component.Combination;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public class CombinationContainer implements class_1263 {
    private final List<class_1799> items;

    public CombinationContainer() {
        this.items = new ArrayList<>(Combination.SIZE);
        for (int i = 0; i < Combination.SIZE; i++) {
            this.items.add(class_1799.field_8037);
        }
    }

    @Override
    public int method_5439() {
        return Combination.SIZE;
    }

    @Override
    public boolean method_5442() {
        return false;
    }

    @Override
    public @NotNull class_1799 method_5438(int slot) {
        return items.get(slot);
    }

    @Override
    public @NotNull class_1799 method_5434(int slot, int amount) {
        items.set(slot, class_1799.field_8037);
        return method_5438(slot);
    }

    @Override
    public @NotNull class_1799 method_5441(int slot) {
        return method_5434(slot, 1);
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        items.set(slot, stack);
    }

    @Override
    public void method_5431() {

    }

    @Override
    public int method_5444() {
        return 1;
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return true;
    }

    @Override
    public void method_5448() {
        for (int i = 0; i < Combination.SIZE; i++) {
            items.set(i, class_1799.field_8037);
        }
    }
}
