package io.github.mortuusars.monobank.world.inventory.menu;

import io.github.mortuusars.monobank.Monobank;
import io.github.mortuusars.monobank.world.block.monobank.component.MonobankExtraInfo;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import io.github.mortuusars.monobank.world.inventory.BigSlot;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import org.jetbrains.annotations.NotNull;

public class MonobankMenu extends class_1703 {
    public static final int MONOBANK_SLOT_INDEX = 0;
    public static final int MONOBANK_SLOT_X = 71;
    public static final int MONOBANK_SLOT_Y = 26;
    public static final int MONOBANK_SLOT_SIZE = 34;

    public static final int TRANSFER_SINGLE_BUTTON_ID = -101;
    public static final int TRANSFER_ALL_BUTTON_ID = -102;

    public final MonobankBlockEntity blockEntity;
    public MonobankExtraInfo extraInfo;
    protected final class_1937 level;

    public MonobankMenu(int containerID, class_1661 playerInventory, MonobankBlockEntity blockEntity, MonobankExtraInfo extraInfo) {
        super(Monobank.MenuTypes.MONOBANK.get(), containerID);
        this.blockEntity = blockEntity;
        this.level = playerInventory.field_7546.method_37908();
        this.extraInfo = extraInfo;

        blockEntity.method_5435(playerInventory.field_7546);

        // Monobank slot
        method_7621(new BigSlot(blockEntity, 0, MONOBANK_SLOT_X, MONOBANK_SLOT_Y,
                MONOBANK_SLOT_SIZE, MONOBANK_SLOT_SIZE, blockEntity.getCapacity()));

        // Player hotbar slots
        for(int k = 0; k < 9; ++k) {
            method_7621(new class_1735(playerInventory, k, 8 + k * 18, 142));
        }

        // Player inventory slots
        for(int i = 0; i < 3; ++i) {
            for(int j = 0; j < 9; ++j) {
                method_7621(new class_1735(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
    }

    public static MonobankMenu fromBuffer(int containerID, class_1661 playerInventory, class_2540 buffer) {
        class_2338 pos = buffer.method_10811();
        class_2586 blockEntityAtPos = playerInventory.field_7546.method_37908().method_8321(pos);
        if (blockEntityAtPos instanceof MonobankBlockEntity blockEntity) {
            return new MonobankMenu(containerID, playerInventory, blockEntity, MonobankExtraInfo.fromBuffer(buffer));
        } else {
            throw new IllegalStateException("Block entity at pos '" + pos + "' is not MonobankBlockEntity, but " + blockEntityAtPos);
        }
    }

    public MonobankBlockEntity getBlockEntity() {
        return blockEntity;
    }

    /**
     * Handles QuickMove with modifiers from bank slot.
     * Uses (hopefully) unused button ids to differentiate between actions.
     */
    @Override
    public void method_7593(int slotId, int button, class_1713 clickType, class_1657 player) {
        if (clickType != class_1713.field_7794) {
            super.method_7593(slotId, button, clickType, player);
            return;
        }

        if (button == TRANSFER_SINGLE_BUTTON_ID) {
            class_1799 item = blockEntity.method_5441(0);
            class_1799 split = item.method_7971(1);
            if (!player.method_7270(split)) {
                item.method_7933(1);
            }
            blockEntity.method_5447(0, item);
        }
        else if (button == TRANSFER_ALL_BUTTON_ID) {
            class_1799 item = blockEntity.method_5441(0);
            while (!item.method_7960()) {
                if (!player.method_7270(item)) {
                    break;
                }
            }
            if (!item.method_7960()) {
                blockEntity.method_5447(0, item); // Insert remainder back
            }
        }
        else {
            super.method_7593(slotId, button, clickType, player);
        }
    }

    /**
     * If ItemStack#EMPTY is returned - repeated insertions will be stopped.
     */
    @Override
    public @NotNull class_1799 method_7601(class_1657 pPlayer, int index) {
        class_1735 clickedSlot = this.field_7761.get(index);
        if (!clickedSlot.method_7681()) return class_1799.field_8037;

        class_1799 clickedSlotItemStack = clickedSlot.method_7677();

        if (index == MONOBANK_SLOT_INDEX) { // From Monobank
            // Remove proper portion of a stack (stack size or amount available - whatever is smaller)
            // getMaxStackSize is called on the ItemStack - and it will return vanilla stack size instead of the bank size.
            class_1799 removedStack = clickedSlot.method_7671(clickedSlotItemStack.method_7914());

            // Try to insert removed portion into player's inventory.
            // Stack's count will be decreased by the amount inserted.
            this.method_7616(removedStack, 1, this.field_7761.size(), false);

            // Insert remainder back into the bank:
            if (!removedStack.method_7960()) {
                clickedSlot.method_32756(removedStack);
            }
        }
        else { // To Monobank:
            class_1735 monobankSlot = this.field_7761.getFirst();
            if (!monobankSlot.method_7681() || class_1799.method_31577(monobankSlot.method_7677(), clickedSlotItemStack)) {
                class_1799 remainder = monobankSlot.method_32756(clickedSlotItemStack);

                // Insert remainder back into the inventory:
                if (!remainder.method_7960()) {
                    clickedSlot.method_32756(remainder);
                }
            }
        }

        return class_1799.field_8037;
    }

    // Called server-side.
    @Override
    public boolean method_7597(class_1657 player) {
        return !blockEntity.getLock().isLocked() && blockEntity.method_5443(player);
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        /*
            When opening other UI over ours (such as JEI),
            'removed' is called only client-side (server-side it's still open), when it probably shouldn't.
            This causes door to close while still in the menu, and not update its openness properly.
            So we are closing only server-side - which is then synchronized to client in OpenersCounter via block update.
         */
        if (!player.method_37908().field_9236) {
            this.blockEntity.method_5432(player);
        }
    }
}
