package io.github.mortuusars.monobank.client.renderer;

import io.github.mortuusars.monobank.MonobankClient;
import io.github.mortuusars.monobank.PlatformHelperClient;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2281;
import net.minecraft.class_2586;
import net.minecraft.class_2618;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_827;

/**
 * Renders Monobank animated door and stored items inside.
 */
public class MonobankRenderer <T extends class_2586 & class_2618> implements class_827<T> {
    protected BlockContentsRenderer blocksRenderer;
    protected ItemContentsRenderer itemsRenderer;

    public MonobankRenderer(class_5614.class_5615 ignoredContext) {
        blocksRenderer = new BlockContentsRenderer();
        itemsRenderer = new ItemContentsRenderer();
    }

    @Override
    public void method_3569(T blockEntity, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight, int packedOverlay) {
        if (!(blockEntity instanceof MonobankBlockEntity monobankEntity))
            return;

        float pixel = 1f / 16f;
        class_2680 blockState = blockEntity.method_11010();

        // Rotate in facing direction:
        float facingYRotation = blockState.method_11654(class_2281.field_10768).method_10153().method_10144();
        poseStack.method_22904(0.5D, 0.5D, 0.5D);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-facingYRotation));
        poseStack.method_22904(-0.5D, -0.5D, -0.5D);

        // Rotate door around the hinge:
        poseStack.method_22903();
        poseStack.method_46416(pixel * 2, 0f, 0f); // Shift X by 2 pixels to place at the center.

        float openness = blockEntity.method_11274(partialTick); // Get how much door is open. From 0 to 1.
        openness = openness < 0.5 ? 4 * openness * openness * openness : (float) (1 - Math.pow(-2 * openness + 2, 3) / 2); // CubicInOut easing:
        float opennessRotation = openness * 112.5f; // 112.5 is the max door opening rotation degrees.
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(opennessRotation));

        class_1087 model = PlatformHelperClient.getModel(MonobankClient.Models.MONOBANK_DOOR);
        class_310.method_1551().method_1541().method_3350().method_3367(poseStack.method_23760(),
                bufferSource.getBuffer(class_1921.method_23577()), null, model, 1f, 1f, 1f, packedLight, packedOverlay);

        poseStack.method_22909();

        // Render insides:
        if (openness > 0.0f) { // Do not render if door is closed.
            renderContents(monobankEntity, partialTick, poseStack, bufferSource, packedLight, packedOverlay);
        }
    }

    public void renderContents(MonobankBlockEntity monobankEntity, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight, int packedOverlay) {
        class_1799 stack = monobankEntity.getItem();

        if (stack.method_7960()) return;

        boolean renderedAsBlock = class_310.method_1551()
                .method_1480()
                        .method_4019(stack, monobankEntity.method_10997(), null, 0)
                        .method_4712();

        float fullness = monobankEntity.getFullness();

        if (renderedAsBlock) {
            blocksRenderer.render(stack, fullness, monobankEntity, partialTick, poseStack, bufferSource, packedLight, packedOverlay);
        } else {
            itemsRenderer.render(stack, fullness, monobankEntity, partialTick, poseStack, bufferSource, packedLight, packedOverlay);
        }
    }
}
