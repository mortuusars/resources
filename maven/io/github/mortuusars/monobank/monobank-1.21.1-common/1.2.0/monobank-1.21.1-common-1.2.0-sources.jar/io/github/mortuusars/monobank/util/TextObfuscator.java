package io.github.mortuusars.monobank.util;

import java.util.Random;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3532;
import net.minecraft.class_5250;

public class TextObfuscator {
    public static class_5250 obfuscate(String text, double obfuscationChance, long seed) {
        if (text.isEmpty()) {
            return class_2561.method_43470("");
        }

        obfuscationChance = class_3532.method_15350(obfuscationChance, 0.0, 1.0);

        // Split to words by white space
        String[] split = text.split("\\s+");
        // Creating random with seed to make obfuscation consistent (it should stay the same when obfuscated again, to avoid cheesing)
        Random random = new Random(seed);

        class_5250 result = class_2561.method_43473();

        for (int wordIndex = 0; wordIndex < split.length; wordIndex++) {
            String word = split[wordIndex];

            if (word.isEmpty()) {
                continue;
            }

            for (int charIndex = 0; charIndex < word.length(); charIndex++) {
                class_5250 character = class_2561.method_43470(word.charAt(charIndex) + "");

                if (random.nextDouble() <= obfuscationChance) {
                    character = character.method_27692(class_124.field_1051).method_27692(class_124.field_1080);
                }

                result.method_10852(character);
            }

            if (wordIndex != split.length - 1) {
                result.method_27693(" ");
            }
        }

        return result;
    }
}
