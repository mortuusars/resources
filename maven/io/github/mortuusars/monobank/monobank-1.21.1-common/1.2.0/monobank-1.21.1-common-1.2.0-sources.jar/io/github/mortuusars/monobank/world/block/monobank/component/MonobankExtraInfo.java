package io.github.mortuusars.monobank.world.block.monobank.component;

import net.minecraft.class_2540;

public class MonobankExtraInfo {
    public boolean isOwner, breakInAttempted, breakInSucceeded;

    public MonobankExtraInfo(boolean isOwner, boolean breakInAttempted, boolean breakInSucceeded) {
        this.isOwner = isOwner;
        this.breakInAttempted = breakInAttempted;
        this.breakInSucceeded = breakInSucceeded;
    }

    public boolean hasWarning() {
        return breakInAttempted || breakInSucceeded;
    }

    public void toBuffer(class_2540 buffer) {
        buffer.method_52964(isOwner);
        buffer.method_52964(breakInAttempted);
        buffer.method_52964(breakInSucceeded);
    }

    public static MonobankExtraInfo fromBuffer(class_2540 buffer) {
        return new MonobankExtraInfo(buffer.readBoolean(), buffer.readBoolean(), buffer.readBoolean());
    }
}
