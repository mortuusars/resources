package io.github.mortuusars.monobank.world.inventory;

import java.util.function.Predicate;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class GhostSlot extends class_1735 {
    protected final Predicate<class_1799> mayPlace;

    public GhostSlot(class_1263 container, int index, int x, int y, Predicate<class_1799> mayPlace) {
        super(container, index, x, y);
        this.mayPlace = mayPlace;
    }

    public GhostSlot(class_1263 container, int index, int x, int y) {
        this(container, index, x, y, stack -> true);
    }

    @Override
    public int method_7675() {
        return 1;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return mayPlace.test(stack);
    }
}
