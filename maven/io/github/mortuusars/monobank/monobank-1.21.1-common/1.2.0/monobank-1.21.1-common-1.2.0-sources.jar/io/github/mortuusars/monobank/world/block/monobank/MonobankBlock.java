package io.github.mortuusars.monobank.world.block.monobank;

import com.mojang.authlib.GameProfile;
import io.github.mortuusars.monobank.Config;
import io.github.mortuusars.monobank.Monobank;
import io.github.mortuusars.monobank.PlatformHelper;
import io.github.mortuusars.monobank.world.block.monobank.component.Lock;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;

public class MonobankBlock extends class_2248 implements class_2343 {
    public static final class_2753 FACING = class_2741.field_12481;

    public MonobankBlock(class_2251 properties) {
        super(properties);
        method_9590(this.method_9595().method_11664().method_11657(FACING, class_2350.field_11043));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    // --

    public boolean canUnlockWithCombination(class_1657 player, MonobankBlockEntity blockEntity) {
        if (!blockEntity.getOwner().isPlayerOwned()) return true;
        if (blockEntity.getOwner().isOwnedBy(player)) return true;
        return Config.Server.PLAYER_UNLOCKING.get();
    }

    public boolean canUnlockWithoutCombination(class_1657 player, MonobankBlockEntity blockEntity) {
        if (!Config.Server.COMBINATION_ENABLED.get()) return true;
        if (blockEntity.getOwner().isNpcOwned()) return Config.Server.SKIP_COMBINATION_FOR_NPC_OWNED.get();
        if (blockEntity.getOwner().isOwnedBy(player)) return Config.Server.SKIP_COMBINATION_IF_OWNER.get();
        return Config.Server.SKIP_COMBINATION_IF_NOT_OWNER.get();
    }

    public boolean canBreak(class_1657 player, MonobankBlockEntity blockEntity) {
        if (Config.Server.CAN_RELOCATE_OTHER_PLAYERS_MONOBANK.get()) return true;
        return blockEntity.getOwner().isNpcOwned() || blockEntity.getOwner().isOwnedBy(player);
    }

    // -- Use

    @Override
    protected @NotNull class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
        if (!(level.method_8321(pos) instanceof MonobankBlockEntity blockEntity)) {
            return class_1269.field_5814;
        }

        if (PlatformHelper.isInDevEnv()) {
            class_1269 result = handleDevEnvUse(level, pos, player, blockEntity);
            if (result != class_1269.field_5811) {
                return result;
            }
        }

        if (player.method_21823()) {
            return blockEntity.getLock().isLocked()
                    ? tryUnlock(player, blockEntity)
                    : lock(player, blockEntity);
        }

        return tryOpen(player, blockEntity);
    }

    private class_1269 handleDevEnvUse(class_1937 level, class_2338 pos, class_1657 player, MonobankBlockEntity blockEntity) {
        if (player.method_5998(class_1268.field_5808).method_31574(class_1802.field_8647)) {
            blockEntity.breakInAttempted = true;
            return class_1269.method_29236(level.field_9236);
        }

        if (player.method_5998(class_1268.field_5808).method_31574(class_1802.field_8403)) {
            blockEntity.breakInSucceeded = true;
            return class_1269.method_29236(level.field_9236);
        }

        if (player.method_5998(class_1268.field_5808).method_31574(class_1802.field_8103)) {
            blockEntity.setOwner(new class_1657(level, pos, 0, new GameProfile(UUID.randomUUID(), "John")) {
                @Override
                public boolean method_7325() {
                    return false;
                }

                @Override
                public boolean method_7337() {
                    return false;
                }
            });

            return class_1269.method_29236(level.field_9236);
        }

        return class_1269.field_5811;
    }

    protected class_1269 tryUnlock(class_1657 player, MonobankBlockEntity blockEntity) {
        if (!blockEntity.getLock().isLocked()) return class_1269.field_5814;
        if (player.method_37908().field_9236) return class_1269.field_5812;

        if (blockEntity.getLock().isUnlocking()) {
            player.method_7353(class_2561.method_43471("monobank.message.monobank.already_unlocking"), true);
            return class_1269.field_5812;
        }

        if (canUnlockWithoutCombination(player, blockEntity)) {
            blockEntity.startUnlocking(player);
            return class_1269.field_5812;
        }

        if (!canUnlockWithCombination(player, blockEntity)) {
            player.method_7353(class_2561.method_43471("monobank.message.monobank.cannot_unlock"), true);
            return class_1269.field_5812;
        }

        if (player instanceof class_3222 serverPlayer) {
            blockEntity.openUnlockingGui(serverPlayer);
            blockEntity.playSoundAtDoor(Monobank.SoundEvents.MONOBANK_CLICK.get());
        }
        return class_1269.field_5812;
    }

    protected class_1269 lock(class_1657 player, MonobankBlockEntity blockEntity) {
        blockEntity.getLock().setLocked(true);
        blockEntity.playSoundAtDoor(Monobank.SoundEvents.MONOBANK_CLICK.get());
        return class_1269.field_5812;
    }

    protected class_1269 tryOpen(class_1657 player, MonobankBlockEntity blockEntity) {
        if (blockEntity.getLock().isLocked()) {
            if (player.method_37908().field_9236) {
                player.method_7353(class_2561.method_43471(
                        "monobank.message.monobank.monobank_is_locked"), true);
            } else {
                blockEntity.playSoundAtDoor(Monobank.SoundEvents.MONOBANK_CLICK.get());
            }
            return class_1269.field_5812;
        }

        if (player instanceof class_3222 serverPlayer) {
            blockEntity.open(serverPlayer);
        }

        return class_1269.field_5812;
    }

    // -- Block Entity

    @Nullable
    @Override
    public class_2586 method_10123(@NotNull class_2338 pos, @NotNull class_2680 state) {
        return Monobank.BlockEntityTypes.MONOBANK.get().method_11032(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> entityType) {
        return entityType.equals(Monobank.BlockEntityTypes.MONOBANK.get()) && level.field_9236
                ? MonobankBlockEntity::clientTick
                : MonobankBlockEntity::serverTick;
    }

    // --

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        return method_9564().method_11657(FACING, context.method_8042().method_10153());
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        if (!(level.method_8321(pos) instanceof MonobankBlockEntity monobankBlockEntity))
            return;

        if (stack.method_57353().method_57829(class_9334.field_49631) != null) {
            monobankBlockEntity.setCustomName(stack.method_7964());
        }

        monobankBlockEntity.onSetPlacedBy(placer, stack);
    }

    @Override
    public float method_9594(class_2680 state, class_1657 player, class_1922 level, class_2338 pos) {
        if (level.method_8321(pos) instanceof MonobankBlockEntity blockEntity && !canBreak(player, blockEntity)) {
            return 0f; // Indestructible
        }
        return super.method_9594(state, player, level, pos);
    }

    // -- State

    @Override
    public @NotNull class_2464 method_9604(class_2680 pState) {
        return class_2464.field_11458;
    }

    @Override
    public @NotNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public @NotNull class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_11657(FACING, mirror.method_10343(state.method_11654(FACING)));
    }

    // -- Redstone

    @Override
    public boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    public int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        if (level.method_8321(pos) instanceof MonobankBlockEntity monobankEntity && !monobankEntity.getLock().isLocked()) {
            float fullness = monobankEntity.getFullness();
            return class_3532.method_15340((int) Math.floor(fullness * 14.0f), 0, 14) + (fullness > 0.0f ? 1 : 0);
        }
        return 0;
    }

    // --

    @SuppressWarnings("deprecation")
    @Override
    public void method_9568(class_1799 stack, class_1792.class_9635 context, List<class_2561> components, class_1836 flag) {
        class_9279 tag = stack.method_57825(class_9334.field_49611, class_9279.field_49302);
        if (tag.method_57463().method_10573(MonobankBlockEntity.LOCK_TAG, class_2520.field_33260)) {
            class_2487 lockTag = tag.method_57463().method_10562(MonobankBlockEntity.LOCK_TAG);
            if (lockTag.method_10577(Lock.LOCKED_TAG)) {
                components.add(class_2561.method_43471("monobank.tooltip.locked"));
            }

            if (flag.method_8035()) {
                if (tag.method_57463().method_10573(MonobankBlockEntity.field_47154, class_2520.field_33258)) {
                    String lootTable = tag.method_57463().method_10558(MonobankBlockEntity.field_47154);
                    components.add(class_2561.method_43469("monobank.tooltip.loot_table", lootTable));
                }

                if (lockTag.method_10573("CombinationTable", class_2487.field_33258)) {
                    components.add(class_2561.method_43469("monobank.tooltip.combination_table",
                            lockTag.method_10558("CombinationTable")));
                }
            }
        }
    }

    @Override
    protected boolean method_9592(class_2680 state, class_1937 level, class_2338 pos, int id, int param) {
        super.method_9592(state, level, pos, id, param);
        // Trigger door openers counter to recheck:
        class_2586 blockentity = level.method_8321(pos);
        return blockentity != null && blockentity.method_11004(id, param);
    }
}
