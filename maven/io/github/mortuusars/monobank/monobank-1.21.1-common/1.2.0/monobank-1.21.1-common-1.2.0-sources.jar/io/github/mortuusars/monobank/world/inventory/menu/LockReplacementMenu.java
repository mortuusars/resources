package io.github.mortuusars.monobank.world.inventory.menu;

import io.github.mortuusars.monobank.Monobank;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlock;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import io.github.mortuusars.monobank.world.block.monobank.component.Combination;
import io.github.mortuusars.monobank.world.inventory.CombinationContainer;
import io.github.mortuusars.monobank.world.inventory.GhostSlot;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import org.jetbrains.annotations.NotNull;

public class LockReplacementMenu extends class_1703 {
    public static final int CONFIRM_BUTTON_ID = 0;

    protected final MonobankBlockEntity monobankEntity;
    protected final CombinationContainer combinationContainer;

    public LockReplacementMenu(final int containerID, final class_1661 playerInventory,
                               final MonobankBlockEntity monobankEntity) {
        super(Monobank.MenuTypes.MONOBANK_LOCK_REPLACEMENT.get(), containerID);
        this.monobankEntity = monobankEntity;

        this.combinationContainer = new CombinationContainer();

        this.method_7621(new GhostSlot(combinationContainer, 0, 59, 35));
        this.method_7621(new GhostSlot(combinationContainer, 1, 80, 35));
        this.method_7621(new GhostSlot(combinationContainer, 2, 101, 35));

        // Player hotbar slots
        for(int column = 0; column < 9; ++column) {
            this.method_7621(new class_1735(playerInventory, column, 8 + column * 18, 142));
        }

        // Player inventory slots
        for(int row = 0; row < 3; ++row) {
            for(int column = 0; column < 9; ++column) {
                this.method_7621(new class_1735(playerInventory, column + row * 9 + 9, 8 + column * 18, 84 + row * 18));
            }
        }
    }

    public static LockReplacementMenu fromBuffer(int containerID, class_1661 playerInventory, class_2540 buffer) {
        MonobankBlockEntity result;
        final class_2586 blockEntityAtPos = playerInventory.field_7546.method_37908().method_8321(buffer.method_10811());
        if (blockEntityAtPos instanceof MonobankBlockEntity monobankBlockEntity) {
            result = monobankBlockEntity;
        } else {
            throw new IllegalStateException("Block entity is not correct! " + blockEntityAtPos);
        }
        return new LockReplacementMenu(containerID, playerInventory, result);
    }

    @Override
    public @NotNull class_1799 method_7601(class_1657 player, int index) {
        if (index < 3) { // Remove key
            this.field_7761.get(index).method_7673(class_1799.field_8037);
        }
        else if (index < this.field_7761.size()) {
            class_1735 clickedSlot = this.field_7761.get(index);
            if (clickedSlot.method_7681()) {
                class_1799 clickedItemStack = clickedSlot.method_7677();
                for (int i = 0; i < 3; i++) {
                    class_1735 combinationSlot = this.field_7761.get(i);
                    if (combinationSlot.method_7677().method_7960() && combinationSlot.method_7680(clickedItemStack)) {
                        combinationSlot.method_7673(new class_1799(clickedItemStack.method_7909()));
                        break;
                    }
                }
            }
        }

        return class_1799.field_8037;
    }

    @Override
    public void method_7593(int slotId, int button, class_1713 clickType, class_1657 player) {
        if (slotId >= Combination.SIZE || slotId < 0) {
            super.method_7593(slotId, button, clickType, player);
            return;
        }

        class_1735 combinationSlot = this.field_7761.get(slotId);

        if (!method_34255().method_7960()) {
            combinationSlot.method_7673(new class_1799(method_34255().method_7909()));
        } else {
            combinationSlot.method_7673(class_1799.field_8037);
        }
    }

    @Override
    public boolean method_7604(class_1657 player, int buttonID) {
        if (buttonID != CONFIRM_BUTTON_ID) return false;

        if (field_7761.stream().limit(3).anyMatch(s -> s.method_7677().method_31573(Monobank.Tags.Items.LOCK_BLACKLIST))) {
            return true;
        }

        Combination newCombination = new Combination(field_7761.get(0).method_7677(), field_7761.get(1).method_7677(), field_7761.get(2).method_7677());
        if (monobankEntity.replaceLock(player, newCombination)) {
            player.method_7353(class_2561.method_43471("monobank.message.replacement_lock.replaced"), true);

            // Consume item:
            class_1799 itemInHand = player.method_5998(class_1268.field_5808);
            if (itemInHand.method_31574(Monobank.Items.REPLACEMENT_LOCK.get()))
                itemInHand.method_7934(1);
            else {
                itemInHand = player.method_5998(class_1268.field_5810);
                if (itemInHand.method_31574(Monobank.Items.REPLACEMENT_LOCK.get()))
                    itemInHand.method_7934(1);
            }

            player.method_7346();
            return true;
        }

        Monobank.LOGGER.info("Lock in monobank at {} has not been replaced.", monobankEntity.method_11016());

        return false;
    }

    // Called server-side.
    @Override
    public boolean method_7597(class_1657 player) {
        return (!monobankEntity.getOwner().isPlayerOwned() || monobankEntity.getOwner().isOwnedBy(player)) &&
                (player.method_5998(class_1268.field_5808).method_31574(Monobank.Items.REPLACEMENT_LOCK.get()) ||
                        player.method_5998(class_1268.field_5810).method_31574(Monobank.Items.REPLACEMENT_LOCK.get())) &&
                monobankEntity.method_5443(player);
    }
}
