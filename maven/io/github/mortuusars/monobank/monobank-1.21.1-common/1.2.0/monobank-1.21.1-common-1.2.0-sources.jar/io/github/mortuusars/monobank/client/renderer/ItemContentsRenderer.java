package io.github.mortuusars.monobank.client.renderer;

import org.joml.Vector3f;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_918;

public class ItemContentsRenderer {

    protected static final int MAX_ITEMS_COUNT = 8;

    protected List<Vector3f> layout = List.of(
            new Vector3f(0.05f, 0.0f, -0.06f),
            new Vector3f(0.28f, 0.36f, -0.11f),
            new Vector3f(-0.05f, 0.40f, -0.01f),
            new Vector3f(0.39f, 0.18f, -0.43f),
            new Vector3f(-0.44f, 0.01f, -0.44f),
            new Vector3f(-0.29f, 0.12f, 0.38f),
            new Vector3f(0.07f, 0.19f, -0.48f),
            new Vector3f(-0.20f, 0.34f, 0.42f));

    /**
     * Renders up to 8 items spread a little from the center.
     * Proper rotation to block facing is expected here.
     */
    public void render(class_1799 stack, float fullness, class_2586 entity, float partialTick, class_4587 poseStack,
                       class_4597 bufferSource, int packedLight, int packedOverlay) {
        class_918 itemRenderer = class_310.method_1551().method_1480();

        float pixel = 1f / 16f;
        float scale = 0.4f;
        int count =  class_3532.method_15340((int)(fullness * MAX_ITEMS_COUNT), 1, MAX_ITEMS_COUNT);

        poseStack.method_22903();

        poseStack.method_46416(0.5f, pixel * 2 + scale / 2, 0.5f);
        poseStack.method_22905(scale, scale, scale);

        for (int i = 0; i < count; i++) {
            Vector3f offset = layout.get(i);
            poseStack.method_22903();
            poseStack.method_46416(offset.x(), offset.y(), offset.z());
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(180));
            itemRenderer.method_23178(stack, class_811.field_4315, packedLight,
                    packedOverlay, poseStack, bufferSource, null, (int) entity.method_11016().method_10063());
            poseStack.method_22909();
        }

        poseStack.method_22909();
    }
}
