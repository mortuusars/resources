package io.github.mortuusars.monobank.world.block.monobank.component;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.monobank.Monobank;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_173;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_181;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8567;

/**
 * Manages Monobank locking and unlocking.
 */
public class Lock {
    public static final String COMBINATION_TABLE_TAG = "CombinationTable";
    public static final String COMBINATION_TAG = "Combination";
    public static final String HAS_COMBINATION_TAG = "HasCombination";
    public static final String LOCKED_TAG = "Locked";
    public static final String UNLOCKING_TIME_TAG = "UnlockingTime";
    public static final String UNLOCKING_COUNTDOWN_TAG = "UnlockingCountdown";

    public static final Codec<Lock> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_5321.method_39154(class_7924.field_50079).optionalFieldOf("combination_table", null).forGetter(Lock::getCombinationTable),
            Combination.CODEC.optionalFieldOf("combination", Combination.EMPTY).forGetter(Lock::getCombination),
            Codec.BOOL.optionalFieldOf("has_combination", false).forGetter(Lock::hasCombination),
            Codec.BOOL.optionalFieldOf("locked", false).forGetter(Lock::isLocked),
            Codec.INT.optionalFieldOf("unlocking_time", 0).forGetter(Lock::getUnlockingTime),
            Codec.INT.optionalFieldOf("unlocking_countdown", 0).forGetter(Lock::getUnlockingCountdown)
    ).apply(instance, Lock::new));

    protected @Nullable class_5321<class_52> combinationTable = null; // set to 'null' when unpacked
    protected Combination combination = Combination.EMPTY;
    protected boolean hasCombination = false;
    protected boolean locked = false;
    protected int unlockingTime = 0;
    protected int unlockingCountdown = 0;

    protected Runnable onLockedChanged = () -> {};

    public Lock(@Nullable class_5321<class_52> combinationTable, Combination combination,
                boolean hasCombination, boolean locked, int unlockingTime, int unlockingCountdown) {
        this.combinationTable = combinationTable;
        this.combination = combination;
        this.hasCombination = hasCombination;
        this.locked = locked;
        this.unlockingTime = unlockingTime;
        this.unlockingCountdown = unlockingCountdown;
    }

    public Lock(Runnable onLockChanged) {
        this.onLockedChanged = onLockChanged;
    }

    public @Nullable class_5321<class_52> getCombinationTable() {
        return combinationTable;
    }

    public void setCombinationTable(@NotNull class_5321<class_52> combinationTable) {
        this.combinationTable = combinationTable;
    }

    public Combination getCombination() {
        return combination;
    }

    public void setCombination(Combination combination) {
        this.combination = combination;
        this.combinationTable = null;
        this.hasCombination = true;
    }

    public boolean hasCombination() {
        return hasCombination;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
        onLockedChanged.run();
    }

    public boolean isUnlocking() {
        return unlockingCountdown > 0;
    }

    public int getUnlockingTime() {
        return unlockingTime;
    }

    public int getUnlockingCountdown() {
        return unlockingCountdown;
    }

    public void startUnlocking(int ticks) {
        unlockingTime = ticks;
        unlockingCountdown = ticks;
    }

    public Lock setOnLockedChanged(Runnable onLockedChanged) {
        this.onLockedChanged = onLockedChanged;
        return this;
    }

    // -- Tick

    public void tick(class_3218 level, MonobankBlockEntity blockEntity) {
        if (unlockingCountdown > 0) {
            // Calculating frequency of clicks (closer to unlocking -> more time between clicks):
            int max = (int) Math.ceil(Math.log(unlockingTime)) + 1;
            int current = (int) Math.ceil(Math.log(unlockingCountdown));
            int freq = max - current;
            if (unlockingCountdown % freq == 0) {
                blockEntity.playSoundAtDoor(Monobank.SoundEvents.MONOBANK_CLICK.get(),
                        0.5f, level.field_9229.method_43057() * 0.1f + 0.95f);
            }

            unlockingCountdown--;

            if (unlockingCountdown <= 0) {
                setLocked(false);
                unlockingTime = 0;
                unlockingCountdown = 0;
            }
        }
    }

    // -- Save

    public class_2487 save() {
        class_2487 tag = new class_2487();
        if (combinationTable != null) {
            tag.method_10582(COMBINATION_TABLE_TAG, combinationTable.method_29177().toString());
        }
        tag.method_10566(COMBINATION_TAG, combination.save());
        if (hasCombination) {
            tag.method_10556(HAS_COMBINATION_TAG, true);
        }
        if (locked) {
            tag.method_10556(LOCKED_TAG, true);
        }
        if (unlockingTime > 0) {
            tag.method_10569(UNLOCKING_TIME_TAG, unlockingTime);
        }
        if (unlockingCountdown > 0) {
            tag.method_10569(UNLOCKING_COUNTDOWN_TAG, unlockingCountdown);
        }
        return tag;
    }

    public void load(class_2487 tag) {
        if (tag.method_33133()) return;

        if (tag.method_10573(COMBINATION_TABLE_TAG, class_2487.field_33258)) {
            class_2960 location = class_2960.method_60654(tag.method_10558(COMBINATION_TABLE_TAG));
            combinationTable = class_5321.method_29179(class_7924.field_50079, location);
        }

        if (tag.method_10573(COMBINATION_TAG, class_2487.field_33259)) {
            combination = Combination.load(tag.method_10554(COMBINATION_TAG, class_2487.field_33258));
        }
        hasCombination = tag.method_10577(HAS_COMBINATION_TAG);
        locked = tag.method_10577(LOCKED_TAG);
        unlockingTime = tag.method_10550(UNLOCKING_TIME_TAG);
        unlockingCountdown = tag.method_10550(UNLOCKING_COUNTDOWN_TAG);
    }

    // -- Loot Table

    @SuppressWarnings("UnusedReturnValue")
    public boolean unpackCombinationTableIfNeeded(class_3218 level, class_2338 pos) {
        if (!hasCombination && combinationTable != null) {
            return tryUnpackCombinationTable(level, pos);
        }
        return false;
    }

    public boolean tryUnpackCombinationTable(class_3218 level, class_2338 pos) {
        List<class_1799> items = getItemsFromLootTable(level, pos, combinationTable);

        ArrayList<class_1792> newCombination = new ArrayList<>();
        for (int i = 0; i < Combination.SIZE; i++) {
            class_1792 item = items.size() <= i ? class_1802.field_8162 : items.get(i).method_7909();
            newCombination.add(item);
        }
        Collections.shuffle(newCombination);

        class_1792 first = !items.isEmpty() ? items.get(0).method_7909() : class_1802.field_8162;
        class_1792 second = items.size() >= 2 ? items.get(1).method_7909() : class_1802.field_8162;
        class_1792 third = items.size() >= 3 ? items.get(2).method_7909() : class_1802.field_8162;

        this.combination = new Combination(first, second, third);
        this.combinationTable = null;
        hasCombination = true;

        if (level.method_8321(pos) instanceof MonobankBlockEntity monobankBlockEntity) {
            monobankBlockEntity.method_5431();
        }

        return true;
    }

    protected @NotNull List<class_1799> getItemsFromLootTable(class_3218 level, class_2338 pos, class_5321<class_52> lootTable) {
        class_8567 lootParams = new class_8567.class_8568(level)
                .method_51874(class_181.field_24424, class_243.method_24953(pos))
                .method_51875(class_173.field_1179);
        class_52 table = level.method_8503().method_58576().method_58295(lootTable);
        return table.method_51878(lootParams);
    }
}
