package io.github.mortuusars.monobank.client.gui.screen;

import io.github.mortuusars.monobank.Monobank;
import io.github.mortuusars.monobank.world.inventory.GhostSlot;
import io.github.mortuusars.monobank.world.inventory.menu.LockReplacementMenu;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_7919;
import net.minecraft.class_8666;

public class LockReplacementScreen extends class_465<LockReplacementMenu> {
    public static final class_2960 TEXTURE = Monobank.resource("textures/gui/monobank_lock_replacement.png");
    public static final class_8666 CONFIRM_SPRITES = new class_8666(Monobank.resource("confirm_button"),
            Monobank.resource("confirm_button_disabled"),
            Monobank.resource("confirm_button_highlighted"));

    protected class_344 confirmButton;

    public LockReplacementScreen(LockReplacementMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        confirmButton = new class_344(field_2776 + 128, field_2800 + 34, 18, 18,
                CONFIRM_SPRITES, this::onConfirmButtonPress, class_2561.method_43471("monobank.gui.monobank.lock_replacement.confirm.tooltip"));
        confirmButton.method_47400(class_7919.method_47407(class_2561.method_43471("monobank.gui.monobank.lock_replacement.confirm.tooltip")));
        this.method_37063(confirmButton);
    }

    protected void onConfirmButtonPress(class_4185 button) {
        if (class_310.method_1551().field_1761 != null) {
            class_310.method_1551().field_1761.method_2900(method_17577().field_7763, LockReplacementMenu.CONFIRM_BUTTON_ID);
        }
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        confirmButton.field_22763 = method_17577().field_7761.stream().limit(3).noneMatch(s -> s.method_7677().method_31573(Monobank.Tags.Items.LOCK_BLACKLIST));
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        method_2380(graphics, mouseX, mouseY);
    }

    @Override
    protected void method_2385(class_332 guiGraphics, class_1735 slot) {
        super.method_2385(guiGraphics, slot);
        if (slot instanceof GhostSlot ghostSlot) {
            if (ghostSlot.method_7677().method_31573(Monobank.Tags.Items.LOCK_BLACKLIST)) {
                int x = slot.field_7873;
                int y = slot.field_7872;
                guiGraphics.method_48196(class_1921.method_51785(), x, y, x + 16, y + 16, 5, 0x66FF5A4D);
            }
        }
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTick, int mouseX, int mouseY) {
        graphics.method_25302(TEXTURE, this.field_2776, this.field_2800, 0, 0, this.field_2792, this.field_2779);
    }
}
