package io.github.mortuusars.monobank.fabric.mixin.hopper_insert_fix;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.monobank.world.block.monobank.MonobankBlockEntity;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2614;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2614.class)
public abstract class HopperBlockEntityMixin {
    @Shadow
    private static boolean canPlaceItemInContainer(class_1263 container, class_1799 stack, int slot, class_2350 direction) {
        return false;
    }

    @ModifyReturnValue(method = "isFullContainer", at = @At("RETURN"))
    private static boolean isFull(boolean original, @Local(argsOnly = true) class_1263 container) {
        return container instanceof MonobankBlockEntity monobankBlockEntity
                ? monobankBlockEntity.getItem().getCount() >= monobankBlockEntity.getCapacity()
                : original;
    }

    @Inject(method = "tryMoveInItem", at = @At(value = "HEAD"), cancellable = true)
    private static void tryMoveInItem(class_1263 source, class_1263 destination, class_1799 insertedStack, int slot, class_2350 direction, CallbackInfoReturnable<class_1799> cir) {
        if (!(destination instanceof MonobankBlockEntity monobankBlockEntity)) return;
        if (!canPlaceItemInContainer(destination, insertedStack, slot, direction)) return;

        class_1799 existingItem = destination.method_5438(slot);
        boolean isInserted = false;

        if (existingItem.method_7960()) {
            destination.method_5447(slot, insertedStack);
            insertedStack = class_1799.field_8037;
            isInserted = true;
        } else if (insertedStack.method_7947() <= monobankBlockEntity.getCapacity() && class_1799.method_31577(existingItem, insertedStack)) {
            int amount = monobankBlockEntity.getCapacity() - existingItem.method_7947();
            int insertedAmount = Math.min(insertedStack.method_7947(), amount);
            insertedStack.method_7934(insertedAmount);
            existingItem.method_7933(insertedAmount);
            isInserted = insertedAmount > 0;
        }

        if (isInserted) {
            destination.method_5431();
        }

        cir.setReturnValue(insertedStack);
    }
}
