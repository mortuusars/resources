package io.github.mortuusars.monobank.fabric;

import fuzs.forgeconfigapiport.fabric.api.neoforge.v4.client.ConfigScreenFactoryRegistry;
import io.github.mortuusars.monobank.Monobank;
import io.github.mortuusars.monobank.MonobankClient;
import io.github.mortuusars.monobank.client.gui.tooltip.CombinationTooltip;
import io.github.mortuusars.monobank.client.gui.screen.MonobankScreen;
import io.github.mortuusars.monobank.client.gui.screen.LockReplacementScreen;
import io.github.mortuusars.monobank.client.renderer.MonobankRenderer;
import io.github.mortuusars.monobank.client.gui.screen.CombinationScreen;
import io.github.mortuusars.monobank.network.fabric.FabricS2CPacketHandler;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.rendering.v1.TooltipComponentCallback;
import net.minecraft.class_3929;
import net.minecraft.class_5616;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;

public class MonobankFabricClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        MonobankClient.init();

        ConfigScreenFactoryRegistry.INSTANCE.register(Monobank.ID, ConfigurationScreen::new);

        class_3929.method_17542(Monobank.MenuTypes.MONOBANK.get(), MonobankScreen::new);
        class_3929.method_17542(Monobank.MenuTypes.MONOBANK_COMBINATION.get(), CombinationScreen::new);
        class_3929.method_17542(Monobank.MenuTypes.MONOBANK_LOCK_REPLACEMENT.get(), LockReplacementScreen::new);

        ModelLoadingPlugin.register(pluginContext -> pluginContext.addModels(MonobankClient.Models.MONOBANK_DOOR.id()));

        class_5616.method_32144(Monobank.BlockEntityTypes.MONOBANK.get(), MonobankRenderer::new);

        TooltipComponentCallback.EVENT.register(data -> data instanceof CombinationTooltip combinationTooltip
                ? combinationTooltip : null);

        FabricS2CPacketHandler.register();
    }
}
