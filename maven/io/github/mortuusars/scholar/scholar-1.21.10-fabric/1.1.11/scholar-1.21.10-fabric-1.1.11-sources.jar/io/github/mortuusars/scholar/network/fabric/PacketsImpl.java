package io.github.mortuusars.scholar.network.fabric;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.fabric.ScholarFabric;
import io.github.mortuusars.scholar.network.packet.Packet;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;

public class PacketsImpl {
    public static void sendToServer(Packet packet) {
        FabricC2SPackets.sendToServer(packet);
    }

    public static void sendToClient(Packet packet, class_3222 player) {
        ServerPlayNetworking.send(player, packet);
    }

    public static void sendToClients(Packet packet, Predicate<class_3222> filter) {
        if (ScholarFabric.server == null) {
            Scholar.LOGGER.error("Cannot send a packet to players. Server is not available.");
            return;
        }

        for (class_3222 player : ScholarFabric.server.method_3760().method_14571()) {
            if (filter.test(player)) {
                sendToClient(packet, player);
            }
        }
    }

    public static void sendToAllClients(Packet packet) {
        if (ScholarFabric.server == null) {
            Scholar.LOGGER.error("Cannot send a packet to all players. Server is not available.");
            return;
        }

        for (class_3222 player : ScholarFabric.server.method_3760().method_14571()) {
            sendToClient(packet, player);
        }
    }

    public static void sendToPlayersNear(Packet packet, @NotNull class_3218 level, @Nullable class_3222 excludedPlayer,
                                         double x, double y, double z, double radius) {
        sendToClients(packet, player -> {
            if (player != excludedPlayer && player.method_51469().method_27983() == level.method_27983()) {
                double d0 = x - player.method_23317();
                double d1 = y - player.method_23318();
                double d2 = z - player.method_23321();
                return d0 * d0 + d1 * d1 + d2 * d2 < radius * radius;
            }

            return false;
        });
    }
}
