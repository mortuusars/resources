package io.github.mortuusars.scholar.mixin.chiseled_bookshelf;

import net.minecraft.class_1262;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_7716;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

/**
 * Sends stored items to client, so it can tint book properly and display bookshelf contents in a tooltip.
 */
@Mixin(class_7716.class)
public abstract class ChiseledBookShelfBlockEntityMixin extends BlockEntityParentMixin {
    @Shadow
    @Final
    private class_2371<class_1799> items;

    @Override
    protected class_2596<class_2602> onGetUpdatePacket(@Nullable class_2596<class_2602> packet) {
        return class_2622.method_38585((class_7716) (Object) this);
    }

    @Override
    protected class_2487 onGetUpdateTag(class_2487 tag) {
        if (level != null) {
            class_1262.method_5426(tag, this.items, level.method_30349());
        }

        return tag;
    }
}
