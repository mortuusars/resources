package io.github.mortuusars.scholar.client.gui.screen.view;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1840;
import net.minecraft.class_1843;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5348;
import net.minecraft.class_9301;
import net.minecraft.class_9302;
import net.minecraft.class_9334;

public interface BookViewAccess {
    BookViewAccess EMPTY = new BookViewAccess() {
        public int getPageCount() {
            return 0;
        }

        public class_5348 getPageRaw(int i) {
            return class_5348.field_25310;
        }
    };

    int getPageCount();
    class_5348 getPageRaw(int pageIndex);

    default class_5348 getPage(int pageIndex) {
        return pageIndex >= 0 && pageIndex < getPageCount() ? getPageRaw(pageIndex) : class_5348.field_25310;
    }

    static BookViewAccess fromItem(class_1799 itemStack) {
        if (itemStack.method_7909() instanceof class_1843) {
            return new WrittenBookAccess(itemStack);
        } else if (itemStack.method_7909() instanceof class_1840) {
            return new WritableBookAccess(itemStack);
        } else {
            return EMPTY;
        }
    }

    class WritableBookAccess implements BookViewAccess {
        private final List<String> pages;

        public WritableBookAccess(class_1799 itemStack) {
            this.pages = readPages(itemStack);
        }

        private static List<String> readPages(class_1799 itemStack) {
            class_9301 content = itemStack.method_58695(class_9334.field_49653, class_9301.field_49369);
            return content.method_57517(class_310.method_1551().method_33883()).toList();
        }

        public int getPageCount() {
            return 100;
        }

        public class_5348 getPageRaw(int i) {
            return i >= pages.size() ? class_5348.field_25310 : class_5348.method_29430(this.pages.get(i));
        }
    }

    class WrittenBookAccess implements BookViewAccess {
        private final List<class_2561> pages;

        public WrittenBookAccess(class_1799 itemStack) {
            this.pages = readPages(itemStack);
        }

        private static List<class_2561> readPages(class_1799 itemStack) {
            class_9302 content = itemStack.method_58695(class_9334.field_49606, class_9302.field_49829);
            return content.method_57525(class_310.method_1551().method_33883());
        }

        public int getPageCount() {
            return this.pages.size();
        }

        public @NotNull class_5348 getPageRaw(int i) {
            return pages.get(i);
        }
    }
}
