package io.github.mortuusars.scholar.client.gui.screen.view;

import com.mojang.datafixers.util.Pair;
import io.github.mortuusars.scholar.client.gui.screen.SpreadBookScreen;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_2558;
import net.minecraft.class_2583;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

public class SpreadBookViewScreen extends SpreadBookScreen {
    protected BookViewAccess bookAccess;
    protected Pair<List<class_5481>, List<class_5481>> cachedPageComponents;
    protected int cachedSpread;

    public SpreadBookViewScreen(BookViewAccess bookAccess, int bookColor) {
        super(bookColor);
        this.bookAccess = bookAccess;
        this.cachedPageComponents = Pair.of(Collections.emptyList(), Collections.emptyList());
        this.cachedSpread = -1;
    }

    public BookViewAccess getBookAccess() {
        return bookAccess;
    }

    public void setBookAccess(BookViewAccess bookViewAccess) {
        this.bookAccess = bookViewAccess;
        this.currentSpread = class_3532.method_15340(this.currentSpread, 0, getSpreadCount());
        this.cachedSpread = -1; // Forces cache update
    }

    @Override
    public int getPageCount() {
        return getBookAccess().getPageCount();
    }

    public boolean setPage(int pageIndex) {
        pageIndex = class_3532.method_15340(pageIndex, 0, getBookAccess().getPageCount() - 1);
        int spreadIndex = (int)(pageIndex / 2f);
        if (spreadIndex != this.currentSpread) {
            this.currentSpread = spreadIndex;
            this.cachedSpread = -1;
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtonVisibility();

        method_52752(guiGraphics);
        renderBook(guiGraphics, mouseX, mouseY, partialTick);
        renderPageNumbers(guiGraphics, mouseX, mouseY, partialTick, currentSpread);
        renderTools(guiGraphics, mouseX, mouseY, partialTick);

        updateAndCacheContentsIfNeeded();

        renderPageContents(guiGraphics, cachedPageComponents.getFirst(), leftPos + TEXT_LEFT_X, topPos + TEXT_Y);
        renderPageContents(guiGraphics, cachedPageComponents.getSecond(), leftPos + TEXT_RIGHT_X, topPos + TEXT_Y);

        class_2583 style = getClickedComponentStyleAt(mouseX, mouseY);
        if (style != null) {
            guiGraphics.method_51441(field_22793, style, mouseX, mouseY);
        }

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        // Stops blur from rendering
    }

    protected void updateAndCacheContentsIfNeeded() {
        if (cachedSpread != currentSpread) {
            class_5348 leftFormattedText = getBookAccess().getPage(currentSpread * 2);
            class_5348 rightFormattedText = getBookAccess().getPageCount() > currentSpread * 2 + 1 ?
                    getBookAccess().getPage(currentSpread * 2 + 1) : class_5348.field_25310;

            cachedPageComponents = Pair.of(
                    field_22793.method_1728(leftFormattedText, TEXT_WIDTH),
                    field_22793.method_1728(rightFormattedText, TEXT_WIDTH));

            cachedSpread = currentSpread;
        }
    }

    protected void renderPageContents(class_332 guiGraphics, List<class_5481> lines, int x, int y) {
        int maxLines = Math.min(TEXT_HEIGHT / field_22793.field_2000, lines.size());
        for (int i = 0; i < maxLines; ++i) {
            class_5481 text = lines.get(i);
            guiGraphics.method_51430(field_22793, text, x, y + i * field_22793.field_2000, textColor, false);
        }
    }

    // --

    public boolean method_25402(double x, double y, int button) {
        if (button == 0) {
            class_2583 style = this.getClickedComponentStyleAt(x, y);
            if (style != null && this.method_25430(style)) {
                return true;
            }
        }

        return super.method_25402(x, y, button);
    }

    public boolean method_25430(class_2583 style) {
        if (style == null)
            return false;

        class_2558 clickEvent = style.method_10970();
        if (clickEvent == null)
            return false;

        if (clickEvent instanceof class_2558.class_10605 changePage) {
            int pageIndex = changePage.comp_3502();
            boolean pageChanged = this.setPage(pageIndex);
            if (pageChanged) {
                playPageTurnSound();
            }
            return pageChanged;
        } else {
            boolean handled = super.method_25430(style);
            if (handled && clickEvent.method_10845() == class_2558.class_2559.field_11750) {
                this.method_25419();
            }

            return handled;
        }
    }

    @Nullable
    public class_2583 getClickedComponentStyleAt(double mouseX, double mouseY) {
        if (mouseY < topPos + TEXT_Y || mouseY >= topPos + TEXT_Y + TEXT_HEIGHT)
            return null;

        boolean isOverRightPage;
        if (mouseX >= leftPos + TEXT_RIGHT_X && mouseX < leftPos + TEXT_RIGHT_X + TEXT_WIDTH) {
            isOverRightPage = true;
        } else if (mouseX >= leftPos + TEXT_LEFT_X && mouseX < leftPos + TEXT_LEFT_X + TEXT_WIDTH) {
            isOverRightPage = false;
        } else {
            return null;
        }

        List<class_5481> pageContents = isOverRightPage ? this.cachedPageComponents.getSecond() : this.cachedPageComponents.getFirst();

        if (pageContents.isEmpty()) {
            return null;
        }

        int x = (int)mouseX - (leftPos + (isOverRightPage ? TEXT_RIGHT_X : TEXT_LEFT_X));
        int y = (int)mouseY - (topPos + TEXT_Y);

        int linesCount = Math.min(TEXT_HEIGHT / field_22793.field_2000, pageContents.size());
        if (y < field_22793.field_2000 * linesCount + linesCount) {
            int clickedLine = y / field_22793.field_2000;
            if (clickedLine >= 0 && clickedLine < pageContents.size()) {
                class_5481 text = pageContents.get(clickedLine);
                return field_22793.method_27527().method_30876(text, x);
            }

            return null;
        }

        return null;
    }
}