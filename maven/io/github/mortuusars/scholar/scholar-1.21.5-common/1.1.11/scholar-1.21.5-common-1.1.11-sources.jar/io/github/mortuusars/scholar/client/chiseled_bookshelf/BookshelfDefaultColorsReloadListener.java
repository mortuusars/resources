package io.github.mortuusars.scholar.client.chiseled_bookshelf;

import com.mojang.serialization.Codec;
import io.github.mortuusars.scholar.Scholar;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4309;
import net.minecraft.class_7654;

public class BookshelfDefaultColorsReloadListener extends class_4309<Map<class_2960, BookshelfDefaultColors>> {
    public static final class_2960 ID = Scholar.resource("bookshelf_default_colors");

    public BookshelfDefaultColorsReloadListener() {
        super(Codec.unboundedMap(class_2960.field_25139, BookshelfDefaultColors.CODEC),
              class_7654.method_45114("chiseled_bookshelf/default_colors"));
    }

    @Override
    protected void apply(Map<class_2960, Map<class_2960, BookshelfDefaultColors>> map,
                         class_3300 resourceManager, class_3695 profiler) {
        Map<class_2960, BookshelfDefaultColors> result = new HashMap<>();

        for (Map<class_2960, BookshelfDefaultColors> value : map.values()) {
            result.putAll(value);
        }

        ChiseledBookshelfColors.DEFAULT_SLOT_COLORS = result;
    }
}