package io.github.mortuusars.scholar.client.gui.screen;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookSignature;
import io.github.mortuusars.scholar.client.gui.screen.edit.SpreadBookEditScreen;
import io.github.mortuusars.scholar.client.gui.widget.textbox.display.HorizontalAlignment;
import io.github.mortuusars.scholar.client.gui.widget.textbox.text.FormattedString;
import io.github.mortuusars.scholar.client.gui.widget.textbox.TextBox;
import io.github.mortuusars.scholar.client.util.RenderUtil;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;

public class BookSigningScreen extends Screen {
    public static final ResourceLocation TEXTURE = Scholar.resource("textures/gui/book_signing.png");
    public static final ResourceLocation TEXTURE_GOLDEN = Scholar.resource("textures/gui/book_signing_golden.png");

    @NotNull
    protected final Minecraft minecraft;
    @NotNull
    protected final Player player;

    protected final SpreadBookEditScreen parentScreen;
    protected final int bookColor;
    protected final Consumer<BookSignature> onSign;

    protected int textColor;
    protected int selectionColor;
    protected int selectionUnfocusedColor;
    protected int enterBookTitleFontColor;
    protected int byAuthorFontColor;

    protected int imageWidth, imageHeight, leftPos, topPos, textureWidth, textureHeight;

    protected TextBox titleTextBox;
    protected TextBox authorTextBox;
    protected ImageButton signButton;
    protected ImageButton cancelSigningButton;

    protected String titleText = "";
    protected String authorText = Objects.requireNonNull(Minecraft.m_91087_().f_91074_).m_6302_();

    public BookSigningScreen(SpreadBookEditScreen parentScreen, int bookColor, Consumer<BookSignature> onSign) {
        super(Component.m_237119_());
        this.parentScreen = parentScreen;
        this.bookColor = bookColor;
        this.onSign = onSign;

        this.textColor = Config.Client.getColor(Config.Client.TEXT_COLOR);
        this.selectionColor = Config.Client.getColor(Config.Client.SELECTION_COLOR);
        this.selectionUnfocusedColor = Config.Client.getColor(Config.Client.SELECTION_UNFOCUSED_COLOR);
        this.enterBookTitleFontColor = Config.Client.getColor(Config.Client.ENTER_TITLE_COLOR);
        this.byAuthorFontColor = Config.Client.getColor(Config.Client.BY_AUTHOR_COLOR);

        this.f_96541_ = Minecraft.m_91087_();
        this.player = Objects.requireNonNull(f_96541_.f_91074_);
        this.textureWidth = 256;
        this.textureHeight = 256;
    }

    @Override
    public boolean m_7043_() {
        return Config.Common.BOOK_SCREEN_PAUSE.get();
    }

    @Override
    protected void m_7856_() {
        this.imageWidth = 149;
        this.imageHeight = 180;
        this.leftPos = (this.f_96543_ - this.imageWidth) / 2;
        this.topPos = (this.f_96544_ - this.imageHeight) / 2;

        // TITLE
        titleTextBox = new TextBox(f_96547_, leftPos + 21, topPos + 71, 108, 9)
              .setFontColor(textColor)
              .setFontUnfocusedColor(textColor)
              .setSelectionColor(selectionColor)
              .setSelectionUnfocusedColor(selectionUnfocusedColor)
              .setHorizontalAlignment(HorizontalAlignment.CENTER)
              .setOnTextChanged(this::setTitleText)
              .setTextValidator(text -> text != null && text.length() <= 32
                    && f_96547_.m_92920_(text, 108) <= 9 && !text.contains("\n"));
        m_142416_(titleTextBox);

        authorTextBox = new TextBox(f_96547_, leftPos + 33, topPos + 81, 100, 9)
              .setText(FormattedString.parse(authorText))
              .setFontColor(byAuthorFontColor)
              .setFontUnfocusedColor(byAuthorFontColor)
              .setSelectionColor(0xFF9271dc)
              .setSelectionUnfocusedColor(0xFFc6b2f2)
              .setHorizontalAlignment(HorizontalAlignment.CENTER)
              .setOnTextChanged(this::setAuthorText)
              .setTextValidator(text -> text != null && text.length() <= 32
                    && f_96547_.m_92920_(text, 100) <= 9 && !text.contains("\n"));
        authorTextBox.getEditor().setCursorToEnd(false);
        m_142416_(authorTextBox);

        // SIGN
        signButton = new ImageButton(leftPos + 46, topPos + 109, 22, 22, 149, 0,
              22, TEXTURE, textureWidth, textureHeight,
              b -> sign(), Component.m_237115_("book.finalizeButton"));
        MutableComponent component = Component.m_237115_("book.finalizeButton")
              .m_130946_("\n").m_7220_(Component.m_237115_("book.finalizeWarning").m_130940_(ChatFormatting.GRAY));
        signButton.m_257544_(Tooltip.m_257550_(component));
        m_142416_(signButton);

        // CANCEL
        cancelSigningButton = new ImageButton(leftPos + 82, topPos + 108, 22, 22, 171, 0,
              22, TEXTURE, textureWidth, textureHeight,
              b -> cancelSigning(), CommonComponents.f_130656_);
        cancelSigningButton.m_257544_(Tooltip.m_257550_(CommonComponents.f_130656_));
        m_142416_(cancelSigningButton);

        m_264313_(titleTextBox);
    }

    protected void setTitleText(FormattedString text) {
        titleText = text.toString();
        updateButtons();
    }

    protected void setAuthorText(FormattedString text) {
        authorText = text.toString();
        updateButtons();
    }

    protected void updateButtons() {
        signButton.f_93623_ = canSign();
        authorTextBox.f_93624_ = Config.Common.BOOK_CHANGEABLE_AUTHOR.get();
        authorTextBox.f_93623_ = Config.Common.BOOK_CHANGEABLE_AUTHOR.get();

        boolean canSign = canSign();

        signButton.f_93623_ = canSign;

        MutableComponent component = Component.m_237115_("book.finalizeButton")
              .m_7220_(CommonComponents.f_178388_)
              .m_7220_(Component.m_237115_("book.finalizeWarning").m_130940_(ChatFormatting.GRAY));
        if (!canSign && titleText.length() > 32) {
            component.m_7220_(CommonComponents.f_178388_);
            component.m_7220_(Component.m_237115_("scholar.book_singing.error_title_too_long").m_130940_(ChatFormatting.RED));
        }

        signButton.m_257544_(Tooltip.m_257550_(component));
    }

    protected boolean canSign() {
        return !titleText.isBlank();
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();

        m_280273_(guiGraphics);

        if (parentScreen.isGolden()) {
            guiGraphics.m_280398_(TEXTURE_GOLDEN, leftPos, topPos, 0, 0, 0,
                  imageWidth, imageHeight, textureWidth, textureHeight);
        } else {
            RenderUtil.withColorMultiplied(bookColor, () -> {
                guiGraphics.m_280398_(TEXTURE, leftPos, topPos, 0, 0, 0,
                      imageWidth, imageHeight, textureWidth, textureHeight);
            });
        }

        guiGraphics.m_280398_(TEXTURE, leftPos, topPos + 31, 0, 0, 180,
              imageWidth, 76, textureWidth, textureHeight);

        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);

        renderLabels(guiGraphics);
    }

    protected void renderLabels(GuiGraphics guiGraphics) {
        MutableComponent component = Component.m_237115_("book.editTitle");
        guiGraphics.m_280614_(f_96547_, component, leftPos + 149 / 2 - f_96547_.m_92852_(component) / 2, topPos + 51,
              enterBookTitleFontColor, false);

        if (!Config.Common.BOOK_CHANGEABLE_AUTHOR.get()) {
            component = Component.m_237110_("book.byAuthor", player.m_7755_());
            guiGraphics.m_280614_(f_96547_, component, leftPos + 149 / 2 - f_96547_.m_92852_(component) / 2, topPos + 81,
                  byAuthorFontColor, false);
        } else {
            component = Component.m_237119_()
                  .m_130946_(authorText.equals(Objects.requireNonNull(f_96541_.f_91074_).m_6302_()) ? "✎ " : "")
                  .m_7220_(Component.m_237110_("book.byAuthor", ""));
            int width = f_96547_.m_92852_(component);
            int authorWidth = f_96547_.m_92895_(authorTextBox.getEditor().getString().toString());
            int x = (authorTextBox.m_252754_() + authorTextBox.m_5711_() / 2) - (authorWidth / 2) - width;
            guiGraphics.m_280614_(f_96547_, component, x, topPos + 81,
                  byAuthorFontColor, false);
        }
    }

    protected void sign() {
        /*if (canSign()) {
            onSign.accept(titleText.trim());
            minecraft.getSoundManager().play(
                  SimpleSoundInstance.forUI(Scholar.SoundEvents.BOOK_SIGNED.get(), 1f, 0.8f));
            onClose();
        }*/
        if (canSign()) {
            Optional<String> author = Optional.of(authorText)
                  .filter(a -> Config.Common.BOOK_CHANGEABLE_AUTHOR.get()
                        && !a.equals(Objects.requireNonNull(f_96541_.f_91074_).m_6302_()));
            onSign.accept(new BookSignature(titleText.trim(), author));
            f_96541_.m_91106_().m_120367_(
                  SimpleSoundInstance.m_119755_(Scholar.SoundEvents.BOOK_SIGNED.get(), 1f, 0.8f));
            m_7379_();
        }
    }

    protected void cancelSigning() {
        f_96541_.m_91152_(parentScreen);
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (keyCode == InputConstants.f_166305_) {
            cancelSigning();
            return true;
        }

        return super.m_7933_(keyCode, scanCode, modifiers);
    }
}
