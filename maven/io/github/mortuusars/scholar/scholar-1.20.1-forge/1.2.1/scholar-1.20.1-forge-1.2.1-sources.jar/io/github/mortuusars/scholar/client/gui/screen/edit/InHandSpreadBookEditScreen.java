package io.github.mortuusars.scholar.client.gui.screen.edit;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookSignature;
import io.github.mortuusars.scholar.client.gui.widget.BookmarkButton;
import io.github.mortuusars.scholar.client.gui.widget.textbox.TextBox;
import io.github.mortuusars.scholar.network.Packets;
import io.github.mortuusars.scholar.network.packet.serverbound.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundEditBookPacket;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;

public class InHandSpreadBookEditScreen extends SpreadBookEditScreen {
    protected final InteractionHand hand;

    protected BookmarkButton bookmarkButton;

    public InHandSpreadBookEditScreen(ItemStack bookStack, InteractionHand hand) {
        super(bookStack);
        this.hand = hand;
        int bookmarkedPage = bookStack.m_41783_() != null ? bookStack.m_41783_().m_128451_(Scholar.NBT.BOOKMARK) : 0;
        setPage(bookmarkedPage);
        Packets.sendToServer(new StartedReadingInHandC2SP(getBookSlot()));
        Minecraft.m_91087_().f_91073_.m_6269_(player, player, SoundEvents.f_11713_, SoundSource.PLAYERS, 1, 1);
    }

    @Override
    protected void sendGoldenSkinChange(boolean golden) {
        Packets.sendToServer(new SetGoldenSkinInHandC2SP(getBookSlot(), golden));
    }

    protected int getBookSlot() {
        return hand == InteractionHand.MAIN_HAND ? player.m_150109_().f_35977_ : Inventory.f_150066_;
    }

    @Override
    protected void createExtraToolsButtons() {
        super.createExtraToolsButtons();
        bookmarkButton = m_142416_(new BookmarkButton(leftPos + 118, topPos + 2, 20, 20,
              423, 0, 60, 512, 512, TEXTURE,
              this::pressBookmarkButton,
              Component.m_237115_("gui.scholar.bookmark")));
    }

    @Override
    protected void updateButtons() {
        super.updateButtons();
        int bookmarkedSpread = bookStack.m_41783_() != null ? bookStack.m_41783_().m_128451_(Scholar.NBT.BOOKMARK) / 2 : 0;
        bookmarkButton.f_93624_ = currentSpread != 0 || bookmarkedSpread != 0;
        if (bookmarkButton.f_93624_) {
            boolean isAtBookmarkedSpread = bookmarkedSpread == currentSpread;
            bookmarkButton.setExpanded(isAtBookmarkedSpread);

            if (m_7222_() instanceof TextBox textBox && textBox.getFormattingToolbar().shouldShow()) {
                // Crude fix to prevent two tooltips rendering at the same time.
                bookmarkButton.m_257544_(Tooltip.m_257550_(Component.m_237119_()));
            } else {
                bookmarkButton.m_257544_(Tooltip.m_257550_(
                  Component.m_237115_("gui.scholar.bookmark." + (isAtBookmarkedSpread ? "remove" : "set"))));
            }
        }
    }

    protected void pressBookmarkButton(Button button) {
        int bookmarkedSpread = bookStack.m_41783_() != null ? bookStack.m_41783_().m_128451_(Scholar.NBT.BOOKMARK) / 2 : 0;

        int newBookmarkedPage;

        if (bookmarkedSpread == currentSpread) {
            if (currentSpread == 0) {
                return;
            }
            newBookmarkedPage = 0;
        } else {
            newBookmarkedPage = currentSpread * 2;
        }

        if (newBookmarkedPage == 0) {
            if (bookStack.m_41783_() != null) {
                bookStack.m_41783_().m_128473_(Scholar.NBT.BOOKMARK);
            }
        } else {
            bookStack.m_41784_().m_128405_(Scholar.NBT.BOOKMARK, newBookmarkedPage);
        }

        int slot = getBookSlot();
        Packets.sendToServer(new SetBookmarkC2SP(slot, newBookmarkedPage));
    }

    @Override
    protected void sendChanges(@Nullable String title) {
        int slot = getBookSlot();
        Objects.requireNonNull(f_96541_.m_91403_()).m_104955_(
              new ServerboundEditBookPacket(slot, this.pages, Optional.ofNullable(title)));
    }

    @Override
    protected void signBook(BookSignature signature) {
        saveChanges(true, signature.title());
        signature.customAuthor().ifPresent(customAuthor ->
              Packets.sendToServer(new SetCustomAuthorInHandC2SP(getBookSlot(), customAuthor)));
    }

    @Override
    public void m_7379_() {
        super.m_7379_();
        Packets.sendToServer(new StoppedReadingInHandC2SP(getBookSlot()));
    }
}
