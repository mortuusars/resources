package io.github.mortuusars.scholar.client.gui.screen.edit;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.client.gui.screen.SpreadBookScreen;
import io.github.mortuusars.scholar.menu.LecternSpreadBookEditMenu;
import io.github.mortuusars.scholar.network.Packets;
import io.github.mortuusars.scholar.network.packet.server.LecternEditBookC2SP;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.inventory.MenuAccess;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Optional;

public class LecternSpreadBookEditScreen extends SpreadBookEditScreen implements MenuAccess<LecternSpreadBookEditMenu> {
    protected final LecternSpreadBookEditMenu menu;
    protected final ContainerListener listener = new ContainerListener() {
        @Override
        public void m_7934_(AbstractContainerMenu menu, int dataSlotIndex, ItemStack stack) {
            LecternSpreadBookEditScreen.this.bookChanged(stack);
        }

        @Override
        public void m_142153_(AbstractContainerMenu menu, int dataSlotIndex, int pageIndex) {
            if (dataSlotIndex == 0) {
                LecternSpreadBookEditScreen.this.updatePage(pageIndex);
            }
        }
    };

    public LecternSpreadBookEditScreen(LecternSpreadBookEditMenu lecternSpreadMenu, Inventory inventory, Component component) {
        super(lecternSpreadMenu.m_39835_(), InteractionHand.MAIN_HAND);
        this.menu = lecternSpreadMenu;
    }

    @Override
    public @NotNull LecternSpreadBookEditMenu m_6262_() {
        return menu;
    }

    @Override
    protected void m_7856_() {
        super.m_7856_();
        m_6262_().m_38893_(listener);
    }

    @Override
    protected void createBottomButtons() {
        if (player.m_36326_()) {
            if (Config.Client.SHOW_DONE_BUTTON.get()) {
                this.m_142416_(Button.m_253074_(CommonComponents.f_130655_,
                        button -> this.m_7379_()).m_252987_(this.f_96543_ / 2 - 100, topPos + SpreadBookScreen.BOOK_HEIGHT + 12, 98, 20).m_253136_());
                this.m_142416_(Button.m_253074_(Component.m_237115_("lectern.take_book"),
                        button -> this.sendButtonClick(3)).m_252987_(this.f_96543_ / 2 + 2, topPos + SpreadBookScreen.BOOK_HEIGHT + 12, 98, 20).m_253136_());
            } else {
                this.m_142416_(Button.m_253074_(Component.m_237115_("lectern.take_book"),
                        (button) -> this.sendButtonClick(3)).m_252987_(this.f_96543_ / 2 - 60, topPos + SpreadBookScreen.BOOK_HEIGHT + 12, 120, 20).m_253136_());
            }
        } else {
            super.createBottomButtons();
        }
    }

    @Override
    protected boolean pageBack() {
        this.sendButtonClick(LecternMenu.f_150606_);

        getHistory().add(() -> this.sendButtonClick(LecternMenu.f_150606_), () -> this.sendButtonClick(LecternMenu.f_150607_)
        );

        return true;
    }

    @Override
    protected boolean pageForward() {
        this.sendButtonClick(LecternMenu.f_150607_);

        getHistory().add(() -> this.sendButtonClick(LecternMenu.f_150607_), () -> this.sendButtonClick(LecternMenu.f_150606_)
        );

        return true;
    }

    protected void bookChanged(ItemStack stack) {
        bookColor = BookColor.of(stack);
        setupPages(stack);
    }

    protected void updatePage(int pageIndex) {
        int newSpreadIndex = pageIndex / 2;
        if (currentSpread != newSpreadIndex) {
            currentSpread = newSpreadIndex;

            // Ensure we have pages to display:
            while (this.pages.size() < (currentSpread + 1) * 2) {
                appendEmptyPage();
            }

            setTextBoxes();
            updateButtonVisibility();
        }
        saveChanges(false, null);
    }

    @Override
    protected void sendChanges(@Nullable String title) {
        removeEmptyTrailingPages();
        // Copying 'pages' list to not cause ConcurrentModificationException when packet is encoded:
        Packets.sendToServer(new LecternEditBookC2SP(m_6262_().getLecternPos(), new ArrayList<>(pages), Optional.ofNullable(title)));
    }

    // --

    @Override
    public void m_88315_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
        renderPageTooltip(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void renderLeftPageNumber(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread, int color) {
        if (isRightPage(m_6262_().m_39836_()) && isHoveringOverLeftPageNumber(mouseX, mouseY)) {
            color = textColor;
        }
        super.renderLeftPageNumber(guiGraphics, mouseX, mouseY, partialTick, currentSpread, color);
    }

    @Override
    protected void renderRightPageNumber(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread, int color) {
        if (isLeftPage(m_6262_().m_39836_()) && isHoveringOverRightPageNumber(mouseX, mouseY)) {
            color = textColor;
        }
        super.renderRightPageNumber(guiGraphics, mouseX, mouseY, partialTick, currentSpread, color);
    }

    protected void renderPageTooltip(GuiGraphics guiGraphics, int x, int y) {
        int page = m_6262_().m_39836_();

        if ((isRightPage(page) && isHoveringOverLeftPageNumber(x, y))
                || (isLeftPage(page) && isHoveringOverRightPageNumber(x, y))) {
            guiGraphics.m_280557_(f_96547_, Component.m_237115_("gui.scholar.lectern.set_current_page"), x, y);
        }
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        int page = m_6262_().m_39836_();
        if (isRightPage(page) && isHoveringOverLeftPageNumber(mouseX, mouseY)) {
            sendButtonClick(LecternMenu.f_150609_ + page - 1);
        } else if (isLeftPage(page) && isHoveringOverRightPageNumber(mouseX, mouseY)) {
            sendButtonClick(LecternMenu.f_150609_ + page + 1);
        }

        return super.m_6375_(mouseX, mouseY, button);
    }

    // --


    @Override
    public void m_7522_(@Nullable GuiEventListener focused) {
        super.m_7522_(focused);
        saveChanges(false, null);
    }

    @Override
    public void m_7861_() {
        super.m_7861_();
        m_6262_().m_38943_(listener);
    }

    @Override
    public void m_7379_() {
        super.m_7379_();
        player.m_6915_();
    }

    // --

    protected void sendButtonClick(int buttonId) {
        if (Minecraft.m_91087_().f_91072_ != null) {
            saveChanges(false, null);
            Minecraft.m_91087_().f_91072_.m_105208_(this.menu.f_38840_, buttonId);
        }
    }
}
