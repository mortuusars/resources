package io.github.mortuusars.scholar.client.render;

import io.github.mortuusars.scholar.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.tooltip.TooltipRenderUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.ChiseledBookShelfBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChiseledBookShelfBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec2;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class ChiseledBookShelfOverlay {
    public static void render(GuiGraphics guiGraphics, float partialTick) {
        if (!Config.Common.CHISELED_BOOKSHELF_TOOLTIP.get()) {
            return;
        }

        Minecraft minecraft = Minecraft.m_91087_();

        if (minecraft.f_91073_ == null || minecraft.f_91074_ == null || minecraft.f_91080_ != null
                || !(minecraft.f_91077_ instanceof BlockHitResult blockHitResult)) {
            return;
        }

        BlockPos hitPos = blockHitResult.m_82425_();
        BlockState blockState = minecraft.f_91073_.m_8055_(hitPos);

        if (!(blockState.m_60734_() instanceof ChiseledBookShelfBlock)) {
            return;
        }

        @Nullable BlockEntity blockEntity = minecraft.f_91073_.m_7702_(hitPos);

        if (!(blockEntity instanceof ChiseledBookShelfBlockEntity chiseledBookShelfBlockEntity)) {
            return;
        }

        Optional<Vec2> blockHitPos = ChiseledBookShelfBlock.m_260871_(blockHitResult,
                blockState.m_61143_(HorizontalDirectionalBlock.f_54117_));
        if (blockHitPos.isEmpty()) {
            return;
        }

        int hitSlot = ChiseledBookShelfBlock.m_261279_(blockHitPos.get());

        ItemStack bookStack = chiseledBookShelfBlockEntity.m_8020_(hitSlot);
        if (bookStack.m_41619_()) {
            return;
        }

        int x = minecraft.m_91268_().m_85445_() / 2 + 16;
        int y = minecraft.m_91268_().m_85446_() / 2 - 9;

        TooltipRenderUtil.m_280205_(guiGraphics, x, y, 18, 18, 400);
//        guiGraphics.drawManaged(() -> TooltipRenderUtil.renderTooltipBackground(guiGraphics, x, y, 18, 18, 400));
        guiGraphics.m_280168_().m_85836_();
        guiGraphics.m_280168_().m_252880_(0, 0, 400);
        guiGraphics.m_280480_(bookStack, x + 1, y + 1);
        guiGraphics.m_280168_().m_85849_();

        guiGraphics.m_280153_(minecraft.f_91062_, bookStack, x + 16, y + 12);
    }
}
