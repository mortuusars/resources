package io.github.mortuusars.scholar.world.entity;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import net.minecraft.Util;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;

import java.util.List;

public class LiterateMobs {
    public static void populateEquipmentSlots(RandomSource random, DifficultyInstance difficulty, Mob mob) {
        if (mob.m_9236_() instanceof ServerLevel serverLevel
              && mob.m_6095_().m_204039_(Scholar.Tags.EntityTypes.LITERATE)
              && random.m_188500_() < Config.Common.LITERATE_MOBS_BOOK_SPAWN_CHANCE.get()) {
            double dropChance = Config.Common.LITERATE_MOBS_BOOK_DROP_CHANCE.get();

            ResourceLocation lootTableId = Scholar.LootTables.LITERATE_MOB_BOOK;
            LootTable lootTable = serverLevel.m_7654_().m_278653_().m_278676_(lootTableId);
            LootParams.Builder builder = (new LootParams.Builder(serverLevel))
                  .m_287286_(LootContextParams.f_81455_, mob)
                  .m_287286_(LootContextParams.f_81460_, mob.m_20182_());

            LootParams lootParams = builder.m_287235_(LootContextParamSets.f_81411_);
            List<ItemStack> items = lootTable.m_287214_(lootParams, mob.m_287233_());

            if (!items.isEmpty()) {
                ItemStack item = Util.m_214621_(items, mob.m_217043_());
                mob.m_8061_(EquipmentSlot.MAINHAND, item);
                mob.m_21409_(EquipmentSlot.MAINHAND, (float) dropChance);
            }
        }
    }
}
