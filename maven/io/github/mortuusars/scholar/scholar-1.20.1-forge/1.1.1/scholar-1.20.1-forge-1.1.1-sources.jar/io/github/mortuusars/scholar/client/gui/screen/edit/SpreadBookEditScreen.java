package io.github.mortuusars.scholar.client.gui.screen.edit;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.platform.InputConstants;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.ScholarClient;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.book.Spread;
import io.github.mortuusars.scholar.client.gui.screen.BookSigningScreen;
import io.github.mortuusars.scholar.client.gui.screen.SpreadBookScreen;
import io.github.mortuusars.scholar.client.gui.widget.textbox.TextBox;
import io.github.mortuusars.scholar.client.gui.widget.textbox.text.FormattedString;
import io.github.mortuusars.scholar.client.gui.widget.textbox.text.FormattedStringEditor;
import io.github.mortuusars.scholar.util.Change;
import io.github.mortuusars.scholar.client.util.FileDialogs;
import io.github.mortuusars.scholar.util.History;
import io.github.mortuusars.scholar.client.util.RenderUtil;
import io.netty.util.internal.StringUtil;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.BookViewScreen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.*;
import net.minecraft.network.protocol.game.ServerboundEditBookPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Predicate;

public class SpreadBookEditScreen extends SpreadBookScreen {
    protected final ItemStack bookStack;
    protected final InteractionHand hand;

    protected final List<String> pages = new ArrayList<>();

    protected final History history = new History();

    protected TextBox rightPageTextBox;
    protected TextBox leftPageTextBox;

    protected ImageButton insertEmptyPageLeftButton;
    protected ImageButton removePageLeftButton;
    protected ImageButton insertEmptyPageRightButton;
    protected ImageButton removePageRightButton;
    protected ImageButton exportBookButton;
    protected ImageButton importBookButton;

    protected boolean bookModified;

    public SpreadBookEditScreen(ItemStack bookStack, InteractionHand hand) {
        super(BookColor.of(bookStack));
        this.bookStack = bookStack;
        this.hand = hand;
    }

    public History getHistory() {
        return history;
    }

    protected void setupPages(ItemStack bookStack) {
        pages.clear();
        CompoundTag compoundtag = bookStack.m_41783_();
        if (compoundtag != null) {
            BookViewScreen.m_169696_(compoundtag, this.pages::add);
        }

        while (this.pages.size() < 2) {
            this.pages.add("");
        }

        setTextBoxes(false);
    }

    @Override
    protected void createWidgets() {
        leftPageTextBox = new TextBox(f_96547_, leftPos + TEXT_LEFT_X, topPos + TEXT_Y, TEXT_WIDTH, TEXT_HEIGHT)
                .setFontColor(textColor)
                .setFontUnfocusedColor(textColor)
                .setSelectionColor(selectionColor)
                .setSelectionUnfocusedColor(selectionUnfocusedColor)
                .setText(FormattedString.parse(getPageText(Spread.Side.LEFT)))
                .setOnTextChanged(text -> setPageText(Spread.Side.LEFT, text.toString()));
        m_142416_(leftPageTextBox);

        rightPageTextBox = new TextBox(f_96547_, leftPos + TEXT_RIGHT_X, topPos + TEXT_Y, TEXT_WIDTH, TEXT_HEIGHT)
                .setFontColor(textColor)
                .setFontUnfocusedColor(textColor)
                .setSelectionColor(selectionColor)
                .setSelectionUnfocusedColor(selectionUnfocusedColor)
                .setText(FormattedString.parse(getPageText(Spread.Side.RIGHT)))
                .setOnTextChanged(text -> setPageText(Spread.Side.RIGHT, text.toString()));
        m_142416_(rightPageTextBox);

        setupPages(bookStack);

        createPageToolButtons();

        createPrevPageButton();
        createNextPageButton();

        createImportExportButtons();

        ImageButton enterSignModeButton = new ImageButton(leftPos - 24, topPos + 18, 22, 22, 321, 0,
                22, TEXTURE, 512, 512,
                b -> enterSignMode(), Component.m_237115_("book.signButton"));
        enterSignModeButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("book.signButton")));
        m_142416_(enterSignModeButton);

        createBottomButtons();
    }

    protected void createPageToolButtons() {
        insertEmptyPageLeftButton = new ImageButton(leftPos + 112, topPos + 154, 13, 13, 343, 0,
                13, TEXTURE, 512, 512,
                b -> insertEmptyPage(Spread.Side.LEFT), Component.m_237115_("gui.scholar.insert_empty_page"));
        insertEmptyPageLeftButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.scholar.insert_empty_page")
                .m_130946_(" ").m_7220_(Component.m_237115_("gui.scholar.insert_empty_page_left.hotkey"))));
        m_142416_(insertEmptyPageLeftButton);

        removePageLeftButton = new ImageButton(leftPos + 126, topPos + 154, 13, 13, 356, 0,
                13, TEXTURE, 512, 512,
                b -> removePage(Spread.Side.LEFT), Component.m_237115_("gui.scholar.remove_page"));
        removePageLeftButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.scholar.remove_page")
                .m_130946_(" ").m_7220_(Component.m_237115_("gui.scholar.remove_page_left.hotkey"))));
        m_142416_(removePageLeftButton);

        insertEmptyPageRightButton = new ImageButton(leftPos + 156, topPos + 154, 13, 13, 343, 0,
                13, TEXTURE, 512, 512,
                b -> insertEmptyPage(Spread.Side.RIGHT), Component.m_237115_("gui.scholar.insert_empty_page"));
        insertEmptyPageRightButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.scholar.insert_empty_page")
                .m_130946_(" ").m_7220_(Component.m_237115_("gui.scholar.insert_empty_page_right.hotkey"))));
        m_142416_(insertEmptyPageRightButton);

        removePageRightButton = new ImageButton(leftPos + 170, topPos + 154, 13, 13, 356, 0,
                13, TEXTURE, 512, 512,
                b -> removePage(Spread.Side.RIGHT), Component.m_237115_("gui.scholar.remove_page"));
        removePageRightButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.scholar.remove_page")
                .m_130946_(" ").m_7220_(Component.m_237115_("gui.scholar.remove_page_right.hotkey"))));
        m_142416_(removePageRightButton);
    }

    protected void createImportExportButtons() {
        importBookButton = new ImageButton(leftPos + 297, topPos + 16, 18, 18, 387, 0,
                18, TEXTURE, 512, 512,
                b -> importBook(Screen.m_96638_()), Component.m_237115_("gui.scholar.import_book"));
        importBookButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.scholar.import_book")
                .m_7220_(ScholarClient.KeyMappings.componentForTooltip(ScholarClient.KeyMappings.importBook))
                .m_7220_(CommonComponents.f_178388_)
                .m_7220_(Component.m_237115_("gui.scholar.import_book.tooltip"))));
        m_142416_(importBookButton);

        exportBookButton = new ImageButton(leftPos + 297, topPos + 41, 18, 18, 369, 0,
                18, TEXTURE, 512, 512,
                b -> exportBook(Screen.m_96638_()), Component.m_237115_("gui.scholar.export_book"));
        exportBookButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.scholar.export_book")
                .m_7220_(ScholarClient.KeyMappings.componentForTooltip(ScholarClient.KeyMappings.exportBook))
                .m_7220_(CommonComponents.f_178388_)
                .m_7220_(Component.m_237115_("gui.scholar.export_book.tooltip"))));
        m_142416_(exportBookButton);
    }

    @Override
    protected void toggleBookTools() {
        super.toggleBookTools();
        playButtonClickSound();
    }

    @Override
    protected void updateButtonVisibility() {
        super.updateButtonVisibility();

        insertEmptyPageLeftButton.f_93624_ = isToolsVisible();
        insertEmptyPageLeftButton.f_93623_ = canInsertEmptyPage(Spread.Side.LEFT);
        insertEmptyPageRightButton.f_93624_ = isToolsVisible();
        insertEmptyPageRightButton.f_93623_ = canInsertEmptyPage(Spread.Side.RIGHT);

        removePageLeftButton.f_93624_ = isToolsVisible();
        removePageLeftButton.f_93623_ = canRemovePage(Spread.Side.LEFT);
        removePageRightButton.f_93624_ = isToolsVisible();
        removePageRightButton.f_93623_ = canRemovePage(Spread.Side.RIGHT);

        exportBookButton.f_93624_ = isToolsVisible();
        exportBookButton.f_93623_ = pages.stream().anyMatch(p -> !p.isEmpty());
        importBookButton.f_93624_ = isToolsVisible();
    }

    // -- Render

    @Override
    public void m_88315_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtonVisibility();

        m_280273_(guiGraphics);
        renderBook(guiGraphics, mouseX, mouseY, partialTick);
        renderPageNumbers(guiGraphics, mouseX, mouseY, partialTick, currentSpread);
        renderTools(guiGraphics, mouseX, mouseY, partialTick);
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    protected void renderBook(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        RenderUtil.withColorMultiplied(bookColor, () -> {
            if (isToolsVisible()) {
                // Import/Export buttons BG
                guiGraphics.m_280163_(TEXTURE, leftPos + 295, topPos + 14, 0, 388,
                        23, 48, 512, 512);
            }

            // Cover
            guiGraphics.m_280411_(TEXTURE, (f_96543_ - BOOK_WIDTH) / 2, (f_96544_ - BOOK_HEIGHT) / 2, BOOK_WIDTH, BOOK_HEIGHT,
                    0, 0, BOOK_WIDTH, BOOK_HEIGHT, 512, 512);

            // Enter Sign Mode button BG
            guiGraphics.m_280163_(TEXTURE, leftPos - 29, topPos + 14, 0, 360,
                    29, 28, 512, 512);
        });

        // Paper
        guiGraphics.m_280411_(TEXTURE, (f_96543_ - BOOK_WIDTH) / 2, (f_96544_ - BOOK_HEIGHT) / 2, BOOK_WIDTH, BOOK_HEIGHT,
                0, 180, BOOK_WIDTH, BOOK_HEIGHT, 512, 512);
    }

    @Override
    protected void renderTools(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        int x = f_96543_ - 12;
        int y = 6;
        guiGraphics.m_280488_(f_96547_, "?", x, y, 0xFFAAAAAA);

        if (mouseX >= x - 3 && mouseX < x + 12 + 3 && mouseY >= y - 3 && mouseY < y + 12) {
            List<Component> tooltip = new ArrayList<>();
            tooltip.add(Component.m_237115_("gui.scholar.tools.toggle")
                    .m_7220_(ScholarClient.KeyMappings.componentForTooltip(ScholarClient.KeyMappings.toggleBookTools)));
            tooltip.add(Component.m_237115_("gui.scholar.tools.tooltip.copy_with_formatting"));
            tooltip.add(Component.m_237115_("gui.scholar.tools.tooltip.paste_with_formatting"));
            tooltip.add(Component.m_237115_("gui.scholar.tools.tooltip.undo"));
            tooltip.add(Component.m_237115_("gui.scholar.tools.tooltip.redo"));
            guiGraphics.m_280677_(f_96547_, tooltip, Optional.empty(), mouseX, mouseY + 20);
        }
    }

    // -- Input

    @Override
    public boolean m_7933_(int key, int scanCode, int modifiers) {
        if (ScholarClient.KeyMappings.importBook.m_90832_(key, scanCode)) {
            playButtonClickSound();
            importBook(Screen.m_96638_());
            return true;
        }

        if (ScholarClient.KeyMappings.exportBook.m_90832_(key, scanCode)) {
            playButtonClickSound();
            exportBook(Screen.m_96638_());
            return true;
        }

        if (Screen.m_96637_() && key == InputConstants.f_166262_ && !Screen.m_96639_()) {
            @Nullable Change change;
            float pitch;

            if (Screen.m_96638_()) {
                change = getHistory().redo();
                pitch = change == null ? 1.4f : 0.8f;
            } else {
                change = getHistory().undo();
                pitch = change == null ? 1.8f : 0.95f;
            }

            playButtonClickSound(pitch);
            return true;
        }

        if ((!(m_7222_() instanceof TextBox textBox) || !textBox.getEditor().isSelecting())
                && key == InputConstants.f_166365_ && Screen.m_96637_() && !Screen.m_96639_()) {
            String bookContents = getBookContents(Screen.m_96638_());
            Minecraft.m_91087_().f_91068_.m_90911_(bookContents);
            return true;
        }

        if (Screen.m_96637_() && Screen.m_96638_() && key == InputConstants.f_166337_) {
            insertEmptyPage(Screen.m_96639_() ? Spread.Side.RIGHT : Spread.Side.LEFT);
            return true;
        }

        if (Screen.m_96637_() && Screen.m_96638_() && key == InputConstants.f_166334_) {
            removePage(Screen.m_96639_() ? Spread.Side.RIGHT : Spread.Side.LEFT);
            return true;
        }

        return super.m_7933_(key, scanCode, modifiers);
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        int x = f_96543_ - 12;
        int y = 6;
        if (mouseX >= x - 3 && mouseX < x + 12 + 3 && mouseY >= y - 3 && mouseY < y + 12) {
            toggleBookTools();
            return true;
        }

        return super.m_6375_(mouseX, mouseY, button);
    }

    // --

    @Override
    protected boolean pageForward() {
        if (super.pageForward()) {
            // Ensure we have pages to display:
            while (this.pages.size() < (currentSpread + 1) * 2) {
                appendEmptyPage();
            }

            setTextBoxes();

            getHistory().add(() -> {
                super.pageForward();
                setTextBoxes();
            }, () -> {
                super.pageBack();
                setTextBoxes();
            });

            return true;
        }
        return false;
    }

    @Override
    protected boolean pageBack() {
        if (super.pageBack()) {
            setTextBoxes();
            getHistory().add(() -> {
                super.pageBack();
                setTextBoxes();
            }, () -> {
                super.pageForward();
                setTextBoxes();
            });
            return true;
        }
        return false;
    }

    protected void setTextBoxes() {
        setTextBoxes(true);
    }

    protected void setTextBoxes(boolean resetCursor) {
        FormattedString leftString = FormattedString.parse(getPageText(Spread.Side.LEFT));
        if (!leftString.equals(leftPageTextBox.getEditor().getString())) {
            leftPageTextBox.getEditor().setString(leftString);
            int leftCursorPos = resetCursor ? 0 : leftPageTextBox.getEditor().getCursorPos();
            leftPageTextBox.getEditor().setCursorPos(leftCursorPos, false);
        }
        leftPageTextBox.getDisplayCache().scheduleUpdate();

        FormattedString rightString = FormattedString.parse(getPageText(Spread.Side.RIGHT));
        if (!rightString.equals(rightPageTextBox.getEditor().getString())) {
            rightPageTextBox.getEditor().setString(rightString);
            int rightCursorPos = resetCursor ? 0 : rightPageTextBox.getEditor().getCursorPos();
            rightPageTextBox.getEditor().setCursorPos(rightCursorPos, false);
        }
        rightPageTextBox.getDisplayCache().scheduleUpdate();
    }

    protected void enterSignMode() {
        saveChanges(false, null);
        f_96541_.m_91152_(new BookSigningScreen(this, bookColor, title -> saveChanges(true, title)));
    }

    // --

    protected String getPageText(Spread.Side side) {
        int pageIndex = side.getPageIndexFromSpread(currentSpread);
        return pageIndex >= 0 && pageIndex < this.pages.size() ? this.pages.get(pageIndex) : "";
    }

    protected void setPageText(Spread.Side side, String text) {
        int pageIndex = side.getPageIndexFromSpread(currentSpread);
        if (pageIndex >= 0 && pageIndex < this.pages.size()) {

            String currentText = getPageText(side);
            getHistory().add(() -> {
                pages.set(pageIndex, text);
                this.bookModified = true;
                setTextBoxes(false);

            }, () -> {
                pages.set(pageIndex, currentText);
                this.bookModified = true;
                setTextBoxes(false);
            });

            this.pages.set(pageIndex, text);
            this.bookModified = true;
        }
    }

    protected void appendEmptyPage() {
        if (this.pages.size() < 100) {
            this.pages.add("");
        }
    }

    protected void insertEmptyPage(Spread.Side side) {
        if (!canInsertEmptyPage(side)) {
            Objects.requireNonNull(Minecraft.m_91087_().f_91074_).m_5661_(
                    Component.m_237115_("gui.scholar.cannot_insert_page"), false);
            return;
        }

        int pageIndex = side.getPageIndexFromSpread(currentSpread);

        Change change = Change.create(() -> {
            pages.add(pageIndex, "");
            while (pages.size() >= 100) {
                pages.remove(pages.size() - 1);
            }
            setTextBoxes();
            bookModified = true;
            playPageTurnSound(1f, 0.6f);
        }, () -> {
            pages.remove(pageIndex);
            setTextBoxes();
            bookModified = true;
            playPageTurnSound(1f, 0.8f);
        });

        change.apply();
        getHistory().add(change);
    }

    protected void removePage(Spread.Side side) {
        int pageIndex = side.getPageIndexFromSpread(currentSpread);
        String pageContent = pages.get(pageIndex);

        Change change = Change.create(() -> {
            pages.remove(pageIndex);
            while (this.pages.size() < Spread.Side.RIGHT.getPageIndexFromSpread(currentSpread) + 1) {
                this.pages.add("");
            }
            setTextBoxes();
            bookModified = true;
            playPageTurnSound(0.85f, 0.6f);
        }, () -> {
            pages.add(pageIndex, pageContent);
            setTextBoxes();
            bookModified = true;
            playPageTurnSound(0.85f, 0.8f);
        });

        change.apply();
        getHistory().add(change);
    }

    protected void saveChanges(boolean sign, @Nullable String title) {
        if (bookModified || sign) {
            if (!sign) {
                title = null;
            }
            removeEmptyTrailingPages();
            updateLocalCopy(sign, title);

            sendChanges(title);
        }
    }

    protected void sendChanges(@Nullable String title) {
        int slotId = hand == InteractionHand.MAIN_HAND ? player.m_150109_().f_35977_ : 40;
        Objects.requireNonNull(f_96541_.m_91403_()).m_104955_(
                new ServerboundEditBookPacket(slotId, this.pages, Optional.ofNullable(title)));
    }

    protected void removeEmptyTrailingPages() {
        ListIterator<String> iterator = this.pages.listIterator(this.pages.size());
        while (iterator.hasPrevious() && iterator.previous().isEmpty()) {
            iterator.remove();
        }
    }

    protected void updateLocalCopy(boolean sign, @Nullable String title) {
        ListTag listTag = new ListTag();
        this.pages.stream().map(StringTag::m_129297_).forEach(listTag::add);
        if (!this.pages.isEmpty()) {
            this.bookStack.m_41700_("pages", listTag);
        }

        if (sign) {
            Preconditions.checkState(!StringUtil.isNullOrEmpty(title), "Title cannot be null or empty when signing a book.");
            this.bookStack.m_41700_("author", StringTag.m_129297_(player.m_36316_().getName()));
            this.bookStack.m_41700_("title", StringTag.m_129297_(title));
        }
    }

    // --

    protected boolean canInsertEmptyPage(Spread.Side side) {
        int pageIndex = side.getPageIndexFromSpread(currentSpread);
        int lastPageWithContent = getLastPageWithContent().orElse(-1);
        return lastPageWithContent < 99 && pageIndex <= lastPageWithContent;
    }

    protected boolean canRemovePage(Spread.Side side) {
        return containsContentAfter(side.getPageIndexFromSpread(currentSpread));
    }

    protected OptionalInt getLastPageWithContent() {
        for (int i = pages.size() - 1; i >= 0; i--) {
            if (!pages.get(i).isEmpty()) return OptionalInt.of(i);
        }
        return OptionalInt.empty();
    }

    protected boolean containsContentAfter(int pageIndex) {
        return pages.stream().skip(pageIndex).anyMatch(p -> !p.isEmpty());
    }

    public String getBookContents(boolean withFormatting) {
        String contents = String.join("\n", pages);
        if (!withFormatting) {
            ChatFormatting.m_126649_(contents);
        }
        return contents;
    }

    public void setBookContents(String contents, boolean withFormatting) {
        List<String> oldPages = new ArrayList<>(pages);
        pages.clear();

        contents = contents.replaceAll("\\r", "");
        if (!withFormatting) {
            contents = ChatFormatting.m_126649_(contents);
            assert contents != null;
        }
        String[] pages = contents.split("\f");

        Predicate<String> validator = FormattedStringEditor.Validator.fitInDimensions(f_96547_, leftPageTextBox.m_5711_(), leftPageTextBox.m_93694_());

        for (String pageContent : pages) {
            if (pageContent.isEmpty()) {
                this.pages.add("");
                continue;
            }

            FormattedString string = FormattedString.parse(pageContent);

            int currentChar = 0;
            FormattedString currentString = new FormattedString();
            String lastValidString = "";

            while (currentChar < string.length()) {
                currentString.add(string.get(currentChar));
                currentChar++;
                String str = currentString.toString();

                if (!validator.test(str)) {
                    this.pages.add(lastValidString);

                    if (this.pages.size() >= 100) {
                        lastValidString = "";
                        break;
                    }

                    currentChar--;
                    currentString.clear();
                    continue;
                }

                lastValidString = str;
            }

            if (!lastValidString.isEmpty() && this.pages.size() <= 100) {
                this.pages.add(lastValidString);
            }
        }

        bookModified = true;
        setTextBoxes();

        List<String> newPages = new ArrayList<>(this.pages);

        getHistory().add(() -> {
            this.pages.clear();
            this.pages.addAll(newPages);
            bookModified = true;
            setTextBoxes();
        }, () -> {
            this.pages.clear();
            this.pages.addAll(oldPages);
            bookModified = true;
            setTextBoxes();
        });
    }

    public void importBook(boolean withFormatting) {
        CompletableFuture.runAsync(() -> {
            String defaultDirectory = Minecraft.m_91087_().f_91069_.toPath().toAbsolutePath().normalize().toString();
            if (!defaultDirectory.endsWith(File.separator)) {
                defaultDirectory = defaultDirectory + File.separator;
            }
            String title = Component.m_237115_("gui.scholar.import_book").getString();

            FileDialogs.loadFile(defaultDirectory, title, "Text Files (.txt)", false, "*.txt").ifPresent(filePath -> {
                try {
                    String content = Files.readString(Path.of(filePath));
                    Minecraft.m_91087_().execute(() -> {
                        setBookContents(content, withFormatting);
                    });
                } catch (IOException e) {
                    Minecraft.m_91087_().execute(() -> player.m_5661_(
                            Component.m_237115_("gui.scholar.import_book.failure"), false));
                    Scholar.LOGGER.error("Failed to import book: ", e);
                }
            });
        }).exceptionally(e -> {
            Minecraft.m_91087_().execute(() -> player.m_5661_(
                    Component.m_237115_("gui.scholar.import_book.failure"), false));
            Scholar.LOGGER.error("Failed to import book: ", e);
            return null;
        });
    }

    public void exportBook(boolean withFormatting) {
        String content = withFormatting
                ? String.join("\f", pages)
                : ChatFormatting.m_126649_(String.join("\f", pages));
        assert content != null;

        CompletableFuture.runAsync(() -> {
            String defaultDirectory = Minecraft.m_91087_().f_91069_.toPath().toAbsolutePath().normalize().toString();
            if (!defaultDirectory.endsWith(File.separator)) {
                defaultDirectory = defaultDirectory + File.separator;
            }
            String title = Component.m_237115_("gui.scholar.export_book").getString();

            FileDialogs.saveFile(defaultDirectory, title, "Text Files (.txt)", "*.txt").ifPresent(filePath -> {
                try {
                    Files.writeString(Path.of(filePath), content, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                    MutableComponent filePathComponent = Component.m_237113_(filePath).m_130948_(Style.f_131099_
                            .m_131162_(true)
                            .m_131142_(new ClickEvent(ClickEvent.Action.OPEN_FILE, filePath)));
                    Minecraft.m_91087_().execute(() -> player.m_5661_(
                            Component.m_237115_("gui.scholar.export_book.success")
                                    .m_7220_(filePathComponent), false));
                } catch (IOException e) {
                    Minecraft.m_91087_().execute(() -> player.m_5661_(
                            Component.m_237115_("gui.scholar.export_book.failure"), false));
                    Scholar.LOGGER.error("Failed to export book: ", e);
                }
            });
        }).exceptionally(e -> {
            Minecraft.m_91087_().execute(() -> player.m_5661_(
                    Component.m_237115_("gui.scholar.export_book.failure"), false));
            Scholar.LOGGER.error("Failed to export book: ", e);
            return null;
        });
    }

    // --

    @Override
    public void m_7379_() {
        saveChanges(false, null);
        super.m_7379_();
    }
}
