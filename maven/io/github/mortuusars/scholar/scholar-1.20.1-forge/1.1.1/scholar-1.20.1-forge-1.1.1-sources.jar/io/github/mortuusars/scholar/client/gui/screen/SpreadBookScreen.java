package io.github.mortuusars.scholar.client.gui.screen;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.ScholarClient;
import io.github.mortuusars.scholar.client.gui.widget.textbox.TextBox;
import io.github.mortuusars.scholar.client.util.RenderUtil;
import net.minecraft.client.GameNarrator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public abstract class SpreadBookScreen extends Screen {
    public static final ResourceLocation TEXTURE = Scholar.resource("textures/gui/book.png");
    public static final int BOOK_WIDTH = 295;
    public static final int BOOK_HEIGHT = 180;
    public static final int TEXT_LEFT_X = 22;
    public static final int TEXT_RIGHT_X = 159;
    public static final int TEXT_Y = 21;
    public static final int TEXT_WIDTH = 114;
    public static final int TEXT_HEIGHT = 128;

    @NotNull
    protected final Minecraft f_96541_;
    @NotNull
    protected final LocalPlayer player;

    protected int bookColor;
    protected int textColor;
    protected int pageNumbersColor;
    protected int selectionColor;
    protected int selectionUnfocusedColor;

    protected int leftPos;
    protected int topPos;
    protected Button prevPageButton;
    protected Button nextPageButton;

    protected int currentSpread;

    public SpreadBookScreen(int bookColor) {
        super(GameNarrator.f_93310_);
        this.f_96541_ = Minecraft.m_91087_();
        this.player = Objects.requireNonNull(f_96541_.f_91074_);
        this.bookColor = bookColor;
        this.textColor = Config.Client.getColor(Config.Client.TEXT_COLOR);
        this.pageNumbersColor = Config.Client.getColor(Config.Client.PAGE_NUMBERS_COLOR);
        this.selectionColor = Config.Client.getColor(Config.Client.SELECTION_COLOR);
        this.selectionUnfocusedColor = Config.Client.getColor(Config.Client.SELECTION_UNFOCUSED_COLOR);
    }

    @Override
    public boolean m_7043_() {
        return Config.Client.SCREEN_PAUSE.get();
    }

    protected void m_7856_() {
        this.leftPos = (this.f_96543_ - BOOK_WIDTH) / 2;
        this.topPos = (this.f_96544_ - BOOK_HEIGHT) / 2;

        createWidgets();
    }

    protected void createWidgets() {
        createPrevPageButton();
        createNextPageButton();
        createBottomButtons();
    }

    protected void createNextPageButton() {
        ImageButton nextPageButton = new ImageButton(leftPos + 270, topPos + 156, 13, 15,
                308, 0, 15, TEXTURE, 512, 512,
                (button) -> pageForward());
        nextPageButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("spectatorMenu.next_page")));
        this.nextPageButton = m_142416_(nextPageButton);
    }

    protected void createPrevPageButton() {
        ImageButton prevPageButton = new ImageButton(leftPos + 12, topPos + 156, 13, 15,
                295, 0, 15, TEXTURE, 512, 512,
                (button) -> pageBack());
        prevPageButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("spectatorMenu.previous_page")));
        this.prevPageButton = m_142416_(prevPageButton);
    }

    protected void createBottomButtons() {
        if (Config.Client.SHOW_DONE_BUTTON.get()) {
            m_142416_(Button.m_253074_(CommonComponents.f_130655_, (button) -> m_7379_())
                    .m_252987_(this.f_96543_ / 2 - 60, topPos + BOOK_HEIGHT + 12, 120, 20)
                    .m_253136_());
        }
    }

    protected void updateButtonVisibility() {
        prevPageButton.f_93624_ = currentSpread > 0;
        nextPageButton.f_93624_ = currentSpread < getSpreadCount() - 1;
    }

    protected void toggleBookTools() {
        boolean currentValue = Config.Client.EDIT_SCREEN_SHOW_EXTRA_TOOLS.get();
        Config.Client.EDIT_SCREEN_SHOW_EXTRA_TOOLS.set(!currentValue);
        Config.Client.EDIT_SCREEN_SHOW_EXTRA_TOOLS.save();
        // Implemented in base screen in case some extra functionality would be added in the future.
        // Does nothing in this class currently. Should be implemented in child classes.
    }

    public boolean isToolsVisible() {
        return Config.Client.EDIT_SCREEN_SHOW_EXTRA_TOOLS.get();
    }

    // -- Book

    public int getPageCount() {
        return 100;
    }

    public int getSpreadCount() {
        return (int)Math.ceil(getPageCount() / 2.0);
    }

    protected boolean pageBack() {
        if (currentSpread > 0) {
            currentSpread--;
            playPageTurnSound(0.8f);
            return true;
        }
        return false;
    }

    protected boolean pageForward() {
        if (currentSpread < getSpreadCount() - 1) {
            currentSpread++;
            playPageTurnSound(1f);
            return true;
        }
        return false;
    }

    // -- Render

    protected void renderBook(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        RenderUtil.withColorMultiplied(bookColor, () -> {
            // Cover
            guiGraphics.m_280411_(TEXTURE, leftPos, topPos, BOOK_WIDTH, BOOK_HEIGHT,
                    0, 0, BOOK_WIDTH, BOOK_HEIGHT, 512, 512);
        });

        // Paper
        guiGraphics.m_280411_(TEXTURE, leftPos, topPos, BOOK_WIDTH, BOOK_HEIGHT,
                0, BOOK_HEIGHT, BOOK_WIDTH, BOOK_HEIGHT, 512, 512);
    }

    protected void renderPageNumbers(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread) {
        renderLeftPageNumber(guiGraphics, mouseX, mouseY, partialTick, currentSpread, pageNumbersColor);
        renderRightPageNumber(guiGraphics, mouseX, mouseY, partialTick, currentSpread, pageNumbersColor);
    }

    protected void renderLeftPageNumber(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread, int color) {
        String leftPageNumber = Integer.toString(currentSpread * 2 + 1);
        guiGraphics.m_280056_(f_96547_, leftPageNumber, leftPos + 69 + (8 - f_96547_.m_92895_(leftPageNumber) / 2),
                topPos + 157, color, false);
    }

    protected void renderRightPageNumber(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread, int color) {
        String rightPageNumber = Integer.toString(currentSpread * 2 + 2);
        guiGraphics.m_280056_(f_96547_, rightPageNumber, leftPos + 208 + (8 - f_96547_.m_92895_(rightPageNumber) / 2),
                topPos + 157, color, false);
    }

    protected void renderTools(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
    }

    // -- Input

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (ScholarClient.KeyMappings.toggleBookTools.m_90832_(keyCode, scanCode)) {
            toggleBookTools();
            return true;
        }

        if (!(m_7222_() instanceof TextBox)) {
            if (Minecraft.m_91087_().f_91066_.f_92092_.m_90832_(keyCode, scanCode)) {
                this.m_7379_();
                return true;
            }

            if (keyCode == InputConstants.f_166330_ || keyCode == InputConstants.f_166339_ || Minecraft.m_91087_().f_91066_.f_92086_.m_90832_(keyCode, scanCode)) {
                pageBack();
                return true;
            }

            if (keyCode == InputConstants.f_166331_ || keyCode == InputConstants.f_166338_ || Minecraft.m_91087_().f_91066_.f_92088_.m_90832_(keyCode, scanCode)) {
                pageForward();
                return true;
            }
        }

        return super.m_7933_(keyCode, scanCode, modifiers);
    }

    // --

    protected boolean isHovering(int x, int y, int width, int height, double mouseX, double mouseY) {
        mouseX -= this.leftPos;
        mouseY -= this.topPos;
        return mouseX >= (double)(x - 1) && mouseX < (double)(x + width + 1) && mouseY >= (double)(y - 1) && mouseY < (double)(y + height + 1);
    }

    protected boolean isHoveringOverRightPageNumber(double mouseX, double mouseY) {
        return isHovering(206, 157, 17, 7, mouseX, mouseY);
    }

    protected boolean isHoveringOverLeftPageNumber(double mouseX, double mouseY) {
        return isHovering(66, 157, 17, 7, mouseX, mouseY);
    }

    protected boolean isLeftPage(int pageIndex) {
        return pageIndex % 2 == 0;
    }

    protected boolean isRightPage(int pageIndex) {
        return pageIndex % 2 == 1;
    }

    protected void playButtonClickSound(float volume, float pitch) {
        Minecraft.m_91087_().m_91106_().m_120367_(
                SimpleSoundInstance.m_119755_(SoundEvents.f_12490_.m_203334_(), pitch, volume));
    }

    protected void playButtonClickSound(float pitch) {
        Minecraft.m_91087_().m_91106_().m_120367_(
                SimpleSoundInstance.m_119755_(SoundEvents.f_12490_.m_203334_(), pitch, 0.3f));
    }

    protected void playButtonClickSound() {
        Minecraft.m_91087_().m_91106_().m_120367_(
                SimpleSoundInstance.m_119755_(SoundEvents.f_12490_.m_203334_(), 1, 0.3f));
    }

    protected void playPageTurnSound(float volume, float pitch) {
        Minecraft.m_91087_().m_91106_().m_120367_(SimpleSoundInstance.m_119755_(SoundEvents.f_11713_, pitch, volume));
    }

    protected void playPageTurnSound(float pitch) {
        Minecraft.m_91087_().m_91106_().m_120367_(SimpleSoundInstance.m_119755_(SoundEvents.f_11713_, pitch, 1f));
    }

    protected void playPageTurnSound() {
        Minecraft.m_91087_().m_91106_().m_120367_(SimpleSoundInstance.m_119755_(SoundEvents.f_11713_, 1f, 1f));
    }
}