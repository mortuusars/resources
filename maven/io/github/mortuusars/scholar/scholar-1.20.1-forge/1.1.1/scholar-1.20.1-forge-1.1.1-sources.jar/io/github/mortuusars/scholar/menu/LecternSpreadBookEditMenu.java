package io.github.mortuusars.scholar.menu;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.Spread;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.WritableBookItem;
import net.minecraft.world.level.block.entity.LecternBlockEntity;
import org.jetbrains.annotations.NotNull;

public class LecternSpreadBookEditMenu extends LecternSpreadMenu {
    public LecternSpreadBookEditMenu(int containerId, Container lectern, ContainerData lecternData, BlockPos lecternPos) {
        super(containerId, lectern, lecternData, lecternPos);
    }

    public static LecternSpreadBookEditMenu fromBuffer(int containerId, Inventory inventory, FriendlyByteBuf buffer) {
        return new LecternSpreadBookEditMenu(containerId, new SimpleContainer(buffer.m_130267_()),
                new SimpleContainerData(1), buffer.m_130135_());
    }

    @Override
    public @NotNull MenuType<?> m_6772_() {
        return Scholar.MenuTypes.LECTERN_SPREAD_BOOK_EDIT.get();
    }

    @Override
    protected int getPageCount() {
        return 100;
    }

    @Override
    protected int getSpreadCount() {
        return 50;
    }

    @Override
    public boolean m_6366_(Player player, int buttonId) {
        if (buttonId == f_150606_ || buttonId == f_150607_) {
            int currentSpreadIndex = getCurrentSpread();
            int newSpreadIndex = currentSpreadIndex + (buttonId == f_150606_ ? -1 : 1);

            if (newSpreadIndex < 0 || newSpreadIndex > getSpreadCount() - 1) {
                return true;
            }

            int newPageIndex = Spread.Side.LEFT.getPageIndexFromSpread(newSpreadIndex);

            // Update pageCount for correct analog redstone output:
            if (player.m_9236_().m_7702_(getLecternPos()) instanceof LecternBlockEntity lecternBlockEntity) {
                lecternBlockEntity.f_59529_ = Math.min(100, Spread.Side.RIGHT.getPageIndexFromSpread(newSpreadIndex) + 2);
            }

            this.m_7511_(0, newPageIndex);
            return true;
        }

        return super.m_6366_(player, buttonId);
    }

    @Override
    public void m_6877_(Player player) {
        super.m_6877_(player);

        // If another player(s) is viewing the same lectern - transfer editing mode to him.
        // If Writable Book is signed, other players would not have their screens closed, however.
        // But that's not a problem, they can't screw up anything anyway.
        // Their view will be the same as if they'd opened Written Book.

        if (player instanceof ServerPlayer serverPlayer
                && player.m_9236_().m_7702_(getLecternPos()) instanceof LecternBlockEntity be
                && be.m_59567_()) {
            serverPlayer.m_284548_().m_6907_().stream()
                    .filter(pl -> !pl.equals(serverPlayer)
                            && pl.f_36096_ instanceof LecternSpreadMenu lecternMenu
                            && lecternMenu.getLecternPos().equals(getLecternPos()))
                    .findFirst()
                    .ifPresent(pl -> {
                        pl.m_6915_();
                        if (be.m_59566_().m_41720_() instanceof WritableBookItem) {
                            Lectern.openBookEditMenu(pl, be, be.m_59566_());
                        }
                    });
        }
    }
}