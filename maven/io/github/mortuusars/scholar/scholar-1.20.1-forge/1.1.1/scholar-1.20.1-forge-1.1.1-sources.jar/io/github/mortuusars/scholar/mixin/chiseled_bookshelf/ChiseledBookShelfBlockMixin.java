package io.github.mortuusars.scholar.mixin.chiseled_bookshelf;

import io.github.mortuusars.scholar.Config;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.ChiseledBookShelfBlock;
import net.minecraft.world.level.block.entity.ChiseledBookShelfBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Purpose of this mixin is to update bookshelf immediately on the client,
 * because due to some weird order of updates (probably), tint colors are updated earlier than items are synched -
 * thus color of the new placed book will not be correct.
 */
@Mixin(ChiseledBookShelfBlock.class)
public abstract class ChiseledBookShelfBlockMixin {
    @Inject(method = "addBook", at = @At(value = "RETURN"))
    private static void onAddBook(Level level, BlockPos pos, Player player, ChiseledBookShelfBlockEntity blockEntity,
                                  ItemStack bookStack, int slot, CallbackInfo ci) {
        if (Config.Common.CHISELED_BOOKSHELF_COLORS.get() && level.f_46443_) {
            blockEntity.m_6836_(slot, bookStack.m_41620_(1));
            if (player.m_7500_()) {
                bookStack.m_41769_(1);
            }
        }
    }
}
