package io.github.mortuusars.scholar.recipe;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import io.github.mortuusars.scholar.Scholar;
import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class NbtTransferringRecipe extends CustomRecipe {
    private final ItemStack result;
    private final Ingredient transferIngredient;
    private final NonNullList<Ingredient> ingredients;

    public NbtTransferringRecipe(ResourceLocation id, Ingredient transferIngredient, NonNullList<Ingredient> ingredients, ItemStack result) {
        super(id, CraftingBookCategory.MISC);
        this.transferIngredient = transferIngredient;
        this.ingredients = ingredients;
        this.result = result;
    }

    public @NotNull Ingredient getTransferIngredient() {
        return transferIngredient;
    }

    @Override
    public @NotNull NonNullList<Ingredient> m_7527_() {
        return ingredients;
    }

    @Override
    public @NotNull RecipeSerializer<?> m_7707_() {
        return Scholar.RecipeSerializers.NBT_TRANSFERRING.get();
    }

    @Override
    public @NotNull ItemStack m_8043_(RegistryAccess registryAccess) {
        return getResult();
    }

    public @NotNull ItemStack getResult() {
        return result;
    }

    @Override
    public boolean matches(CraftingContainer container, Level level) {
        if (getTransferIngredient().m_43947_() || ingredients.isEmpty())
            return false;

        List<Ingredient> unmatchedIngredients = new ArrayList<>(ingredients);
        unmatchedIngredients.add(0, getTransferIngredient());

        int itemsInCraftingGrid = 0;

        for (int i = 0; i < container.m_6643_(); i++) {
            ItemStack stack = container.m_8020_(i);
            if (!stack.m_41619_())
                itemsInCraftingGrid++;

            if (itemsInCraftingGrid > ingredients.size() + 1)
                return false;

            if (!unmatchedIngredients.isEmpty()) {
                for (int j = 0; j < unmatchedIngredients.size(); j++) {
                    if (unmatchedIngredients.get(j).test(stack)) {
                        unmatchedIngredients.remove(j);
                        break;
                    }
                }
            }
        }

        return unmatchedIngredients.isEmpty() && itemsInCraftingGrid == ingredients.size() + 1;
    }

    @Override
    public @NotNull ItemStack assemble(CraftingContainer container, @NotNull RegistryAccess registryAccess) {
        for (int index = 0; index < container.m_6643_(); index++) {
            ItemStack itemStack = container.m_8020_(index);

            if (getTransferIngredient().test(itemStack)) {
                return transferNbt(itemStack, m_8043_(registryAccess).m_41777_());
            }
        }

        return m_8043_(registryAccess);
    }

    public @NotNull ItemStack transferNbt(ItemStack transferIngredientStack, ItemStack recipeResultStack) {
        @Nullable CompoundTag transferTag = transferIngredientStack.m_41783_();
        if (transferTag != null) {
            if (recipeResultStack.m_41783_() != null)
                recipeResultStack.m_41783_().m_128391_(transferTag);
            else
                recipeResultStack.m_41751_(transferTag.m_6426_());
        }
        return recipeResultStack;
    }

    @Override
    public boolean m_8004_(int width, int height) {
        return ingredients.size() <= width * height;
    }

    public static class Serializer implements RecipeSerializer<NbtTransferringRecipe> {
        @Override
        public @NotNull NbtTransferringRecipe m_6729_(ResourceLocation recipeId, JsonObject serializedRecipe) {
            Ingredient sourceIngredient = Ingredient.m_43917_(GsonHelper.m_289747_(serializedRecipe, "source"));
            NonNullList<Ingredient> ingredients = getIngredients(GsonHelper.m_13933_(serializedRecipe, "ingredients"));
            ItemStack result = ShapedRecipe.m_151274_(GsonHelper.m_13930_(serializedRecipe, "result"));

            if (sourceIngredient.m_43947_())
                throw new JsonParseException("Recipe should have 'source' ingredient.");

            return new NbtTransferringRecipe(recipeId, sourceIngredient, ingredients, result);
        }

        @Override
        public @NotNull NbtTransferringRecipe m_8005_(ResourceLocation recipeId, FriendlyByteBuf buffer) {
            Ingredient transferredIngredient = Ingredient.m_43940_(buffer);
            int ingredientsCount = buffer.m_130242_();
            NonNullList<Ingredient> ingredients = NonNullList.m_122780_(ingredientsCount, Ingredient.f_43901_);
            ingredients.replaceAll(ignored -> Ingredient.m_43940_(buffer));
            ItemStack result = buffer.m_130267_();

            return new NbtTransferringRecipe(recipeId, transferredIngredient, ingredients, result);
        }

        @Override
        public void toNetwork(FriendlyByteBuf buffer, NbtTransferringRecipe recipe) {
            recipe.getTransferIngredient().m_43923_(buffer);
            buffer.m_130130_(recipe.m_7527_().size());
            for (Ingredient ingredient : recipe.m_7527_()) {
                ingredient.m_43923_(buffer);
            }
            buffer.m_130055_(recipe.getResult());
        }

        private NonNullList<Ingredient> getIngredients(JsonArray jsonArray) {
            NonNullList<Ingredient> ingredients = NonNullList.m_122779_();

            for (int i = 0; i < jsonArray.size(); ++i) {
                Ingredient ingredient = Ingredient.m_43917_(jsonArray.get(i));
                if (!ingredient.m_43947_())
                    ingredients.add(ingredient);
            }

            if (ingredients.isEmpty())
                throw new JsonParseException("No ingredients for a recipe.");
            else if (ingredients.size() > 3 * 3)
                throw new JsonParseException("Too many ingredients for a recipe. The maximum is 9.");
            return ingredients;
        }
    }
}
