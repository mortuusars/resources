package io.github.mortuusars.scholar.client.gui.widget.textbox;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.scholar.client.gui.widget.textbox.display.FormattedStringDisplayCache;
import io.github.mortuusars.scholar.client.gui.widget.textbox.display.FormattingToolbar;
import io.github.mortuusars.scholar.client.gui.widget.textbox.display.HorizontalAlignment;
import io.github.mortuusars.scholar.client.gui.widget.textbox.display.Line;
import io.github.mortuusars.scholar.client.gui.widget.textbox.text.FormattedString;
import io.github.mortuusars.scholar.client.gui.widget.textbox.text.FormattedStringEditor;
import io.github.mortuusars.scholar.client.gui.widget.textbox.text.Formatting;
import io.github.mortuusars.scholar.client.util.Pos2i;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class TextBox extends AbstractWidget {
    protected final Font font;

    protected FormattedStringEditor editor = new FormattedStringEditor(() ->
            FormattedStringEditor.Validator.fitInDimensions(getFont(), m_5711_(), m_93694_()));
    protected FormattedStringDisplayCache displayCache = new FormattedStringDisplayCache(editor);

    protected HorizontalAlignment horizontalAlignment = HorizontalAlignment.LEFT;
    protected int fontColor = 0xFF000000;
    protected int fontUnfocusedColor = 0xFF000000;
    protected int selectionColor = 0xFF0000FF;
    protected int selectionUnfocusedColor = 0x880000FF;
    protected Consumer<FormattedString> onTextChanged = text -> { };

    protected FormattingToolbar formattingToolbar = new FormattingToolbar(this);

    protected Pos2i lastClickPos = new Pos2i(0, 0);
    protected long lastActionTime;
    protected boolean canDrag;

    public TextBox(int x, int y, int width, int height) {
        this(Minecraft.m_91087_().f_91062_, x, y, width, height);
    }

    public TextBox(Font font, int x, int y, int width, int height) {
        super(x, y, width, height, Component.m_237119_());
        this.font = font;
    }

    public Font getFont() {
        return font;
    }

    public FormattedStringEditor getEditor() {
        return editor;
    }

    public FormattedStringDisplayCache getDisplayCache() {
        if (displayCache.shouldUpdate()) {
            displayCache.update(getFont(), m_5711_(), m_93694_(), getHorizontalAlignment());
        }

        return displayCache;
    }

    public FormattingToolbar getFormattingToolbar() {
        if (formattingToolbar.shouldUpdate()) {
            formattingToolbar.update();
        }
        return formattingToolbar;
    }

    public TextBox setFormattingToolbar(FormattingToolbar formattingToolbar) {
        this.formattingToolbar = formattingToolbar;
        this.formattingToolbar.scheduleUpdate();
        return this;
    }

    public HorizontalAlignment getHorizontalAlignment() {
        return horizontalAlignment;
    }

    public TextBox setHorizontalAlignment(HorizontalAlignment horizontalAlignment) {
        this.horizontalAlignment = horizontalAlignment;
        refreshDisplayCache();
        return this;
    }

    public int getFontColor() {
        return fontColor;
    }

    public TextBox setFontColor(int fontColor) {
        this.fontColor = fontColor;
        refreshDisplayCache();
        return this;
    }

    public int getFontUnfocusedColor() {
        return fontUnfocusedColor;
    }

    public TextBox setFontUnfocusedColor(int fontUnfocusedColor) {
        this.fontUnfocusedColor = fontUnfocusedColor;
        refreshDisplayCache();
        return this;
    }

    public int getSelectionColor() {
        return selectionColor;
    }

    public TextBox setSelectionColor(int selectionColor) {
        this.selectionColor = selectionColor;
        refreshDisplayCache();
        return this;
    }

    public int getSelectionUnfocusedColor() {
        return selectionUnfocusedColor;
    }

    public TextBox setSelectionUnfocusedColor(int selectionUnfocusedColor) {
        this.selectionUnfocusedColor = selectionUnfocusedColor;
        refreshDisplayCache();
        return this;
    }

    public int getCurrentFontColor() {
        return m_93696_() ? fontColor : fontUnfocusedColor;
    }

    public int getCurrentSelectionColor() {
        return m_93696_() ? selectionColor : selectionUnfocusedColor;
    }

    public TextBox setTextValidator(Predicate<String> validator) {
        getEditor().setValidator(validator);
        return this;
    }

    public Consumer<FormattedString> onTextChanged() {
        return onTextChanged;
    }

    public TextBox setOnTextChanged(Consumer<FormattedString> onTextChanged) {
        this.onTextChanged = onTextChanged;
        return this;
    }

    public TextBox setText(FormattedString text) {
        getEditor().setString(text);
        return this;
    }

    // -- Render

    @Override
    protected void m_87963_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        FormattedStringDisplayCache displayCache = getDisplayCache();

        renderLines(guiGraphics, mouseX, mouseY, partialTick, displayCache.getLines(), getCurrentFontColor());

        int cursorColor = getCurrentFontColor();
        Formatting currentFormatting = getEditor().getFormattingAtCursor();
        if (currentFormatting.color() != null) {
            //noinspection DataFlowIssue
            cursorColor = currentFormatting.color().asChatFormatting().m_126665_() | 0xFF000000;
        }

        renderCursor(guiGraphics, mouseX, mouseY, partialTick, getEditor(), displayCache.getCursor(), cursorColor);
        renderSelection(guiGraphics, mouseX, mouseY, partialTick, displayCache.getSelection(), getCurrentSelectionColor());

        getFormattingToolbar().render(guiGraphics, mouseX, mouseY, partialTick);
    }

    public void renderLines(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, List<Line> lines, int color) {
        for (Line line : lines) {
            guiGraphics.m_280056_(font, line.renderedString(), m_252754_() + line.x(), m_252907_() + line.y(), color, false);
        }
    }

    public void renderSelection(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, List<Rect2i> selection, int color) {
        for (Rect2i rect : selection) {
            int x0 = m_252754_() + rect.m_110085_();
            int y0 = m_252907_() + rect.m_110086_();
            int x1 = x0 + rect.m_110090_();
            int y1 = y0 + rect.m_110091_();
            guiGraphics.m_285944_(RenderType.m_285783_(), x0, y0, x1, y1, color);
        }
    }

    public void renderCursor(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, FormattedStringEditor editor, Pos2i cursor, int color) {
        if (!m_93696_()) return;
        if (editor.isSelecting()) return;
        if (System.currentTimeMillis() - lastActionTime > 200 && (System.currentTimeMillis() - lastActionTime) % 600 > 300) // Blinking
            return;

        if (editor.isCursorAtEnd()) {
            Line line = getDisplayCache().getLine(getDisplayCache().getLines().size() - 1);
            if (cursor.y + font.f_92710_ > m_93694_()) {
                int x = line.x() + line.width();
                int y = line.y();
                guiGraphics.m_280056_(getFont(), "<", m_252754_() + x, m_252907_() + y,
                        color, false);
            } else {
                guiGraphics.m_280056_(getFont(), "_", m_252754_() + cursor.x, m_252907_() + cursor.y,
                        color, false);
            }
        } else {
            guiGraphics.m_280168_().m_85836_();
            guiGraphics.m_280168_().m_252880_(0, 0, 50);
            RenderSystem.disableBlend();
            guiGraphics.m_280509_(
                    m_252754_() + cursor.x,
                    m_252907_() + cursor.y - 1,
                    m_252754_() + cursor.x + 1,
                    m_252907_() + cursor.y + font.f_92710_,
                    color);
            guiGraphics.m_280168_().m_85849_();
        }
    }

    protected void refreshDisplayCache() {
        displayCache.scheduleUpdate();
        formattingToolbar.scheduleUpdate();
    }

    // -- Input

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (!m_93696_() || !m_142518_() || !f_93624_) return false;

        if (handleKeyPressed(keyCode, scanCode, modifiers)) {
            lastActionTime = System.currentTimeMillis();
            onTextChanged().accept(getEditor().getString());
            refreshDisplayCache();
            return true;
        }

        return false;
    }

    protected boolean handleKeyPressed(int keyCode, int scanCode, int modifiers) {
        if (getFormattingToolbar().keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        } else if (keyCode == InputConstants.f_166280_) {
            changeLine(-1);
            return true;
        } else if (keyCode == InputConstants.f_166329_) {
            changeLine(1);
            return true;
        } else if (keyCode == InputConstants.f_166336_) {
            keyHome();
            return true;
        } else if (keyCode == InputConstants.f_166335_) {
            keyEnd();
            return true;
        }

        return getEditor().keyPressed(keyCode);
    }

    public boolean m_5534_(char codePoint, int modifiers) {
        if (m_93696_() && getEditor().charTyped(codePoint)) {
            lastActionTime = System.currentTimeMillis();
            onTextChanged().accept(getEditor().getString());
            refreshDisplayCache();
            return true;
        }

        return false;
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        if (!m_142518_() || !f_93624_) return false;

        if (getFormattingToolbar().mouseClicked(mouseX, mouseY, button)) {
            refreshDisplayCache();
            onTextChanged().accept(getEditor().getString());
            canDrag = false;
            return true;
        }

        if (f_93622_ && button == InputConstants.f_166347_) {
            long currentTime = System.currentTimeMillis();
            FormattedStringDisplayCache display = getDisplayCache();

            int indexAtMousePos = display.getCharIndexAtPosition(font, (int) (mouseX - m_252754_()), (int) (mouseY - m_252907_()));

            if (Math.abs(lastClickPos.x - (int) mouseX) < 4 && Math.abs(lastClickPos.y - (int) mouseY) < 4 && currentTime - lastActionTime < 250L) {
                if (!getEditor().isSelecting()) {
                    getEditor().selectWord(indexAtMousePos);
                } else {
                    getEditor().selectAll();
                }
            } else {
                getEditor().setCursorPos(indexAtMousePos, Screen.m_96638_());
            }

            refreshDisplayCache();

            lastClickPos = new Pos2i((int) mouseX, (int) mouseY);
            lastActionTime = currentTime;
            canDrag = true;
            return true;
        }

        return false;
    }

    @Override
    public boolean m_7979_(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (button == 0 && canDrag) {
            FormattedStringDisplayCache display = getDisplayCache();
            int indexAtMousePos = display.getCharIndexAtPosition(font, (int) (mouseX - m_252754_()), (int) (mouseY - m_252907_()));
            getEditor().setCursorPos(indexAtMousePos, true);
            refreshDisplayCache();
            return true;
        }
        return false;
    }

    // --

    public void changeLine(int yChange) {
        Pos2i cursor = getDisplayCache().getCursor();
        int x = cursor.x;
        int y = cursor.y + (font.f_92710_ * yChange);
        int index = getDisplayCache().getCharIndexAtPosition(font, x, y);

        getEditor().setCursorPos(index, Screen.m_96638_());
    }

    public void keyHome() {
        if (Screen.m_96637_()) {
            getEditor().setCursorToStart(Screen.m_96638_());
        } else {
            int cursorPos = getEditor().getCursorPos();
            int lineIndex = getDisplayCache().findLineIndexByCharIndex(cursorPos);
            Line line = getDisplayCache().getLine(lineIndex);
            getEditor().setCursorPos(line.firstCharIndex(), Screen.m_96638_());
        }
    }

    public void keyEnd() {
        if (Screen.m_96637_()) {
            getEditor().setCursorToEnd(Screen.m_96638_());
        } else {
            int cursorPos = getEditor().getCursorPos();
            int lineIndex = getDisplayCache().findLineIndexByCharIndex(cursorPos);
            Line line = getDisplayCache().getLine(lineIndex);
            getEditor().setCursorPos(line.lastCharIndex() + 1, Screen.m_96638_());
        }
    }

    // --

    @Override
    public @NotNull Component m_6035_() {
        return Component.m_237113_(getEditor().getString().toStringWithoutFormatting());
    }

    @Override
    protected void m_168797_(NarrationElementOutput narrationElementOutput) {
        narrationElementOutput.m_169146_(NarratedElementType.TITLE, m_5646_());
    }
}
