package io.github.mortuusars.scholar.client.gui.screen.view;

import com.google.common.collect.ImmutableList;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.WritableBookItem;
import net.minecraft.world.item.WrittenBookItem;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.IntFunction;

public interface BookViewAccess {
    BookViewAccess EMPTY = new BookViewAccess() {
        public int getPageCount() {
            return 0;
        }

        public FormattedText getPageRaw(int i) {
            return FormattedText.f_130760_;
        }
    };

    int getPageCount();
    FormattedText getPageRaw(int pageIndex);

    default FormattedText getPage(int pageIndex) {
        return pageIndex >= 0 && pageIndex < getPageCount() ? getPageRaw(pageIndex) : FormattedText.f_130760_;
    }

    static BookViewAccess fromItem(ItemStack itemStack) {
        if (itemStack.m_41720_() instanceof WrittenBookItem) {
            return new WrittenBookAccess(itemStack);
        } else if (itemStack.m_41720_() instanceof WritableBookItem) {
            return new WritableBookAccess(itemStack);
        } else {
            return EMPTY;
        }
    }

    static List<String> loadPages(CompoundTag compoundTag) {
        ImmutableList.Builder<String> builder = ImmutableList.builder();
        Objects.requireNonNull(builder);
        loadPages(compoundTag, builder::add);
        return builder.build();
    }

    static void loadPages(CompoundTag compoundTag, Consumer<String> consumer) {
        ListTag listTag = compoundTag.m_128437_("pages", 8).m_6426_();
        IntFunction<String> intFunction;
        if (Minecraft.m_91087_().m_167974_() && compoundTag.m_128425_("filtered_pages", 10)) {
            CompoundTag compoundTag2 = compoundTag.m_128469_("filtered_pages");
            intFunction = (ix) -> {
                String string = String.valueOf(ix);
                return compoundTag2.m_128441_(string) ? compoundTag2.m_128461_(string) : listTag.m_128778_(ix);
            };
        } else {
            Objects.requireNonNull(listTag);
            intFunction = listTag::m_128778_;
        }

        for (int i = 0; i < listTag.size(); ++i) {
            consumer.accept(intFunction.apply(i));
        }
    }

    class WritableBookAccess implements BookViewAccess {
        private final List<String> pages;

        public WritableBookAccess(ItemStack itemStack) {
            this.pages = readPages(itemStack);
        }

        private static List<String> readPages(ItemStack itemStack) {
            CompoundTag compoundTag = itemStack.m_41783_();
            return (compoundTag != null ? loadPages(compoundTag) : ImmutableList.of());
        }

        public int getPageCount() {
            return 100;
        }

        public FormattedText getPageRaw(int i) {
            return i >= pages.size() ? FormattedText.f_130760_ : FormattedText.m_130775_(this.pages.get(i));
        }
    }

    class WrittenBookAccess implements BookViewAccess {
        private final List<String> pages;

        public WrittenBookAccess(ItemStack itemStack) {
            this.pages = readPages(itemStack);
        }

        private static List<String> readPages(ItemStack itemStack) {
            CompoundTag compoundTag = itemStack.m_41783_();
            return (WrittenBookItem.m_43471_(compoundTag) ?
                    loadPages(compoundTag) :
                    ImmutableList.of(Component.Serializer.m_130703_(Component.m_237115_("book.invalid.tag")
                            .m_130940_(ChatFormatting.DARK_RED))));
        }

        public int getPageCount() {
            return this.pages.size();
        }

        public @NotNull FormattedText getPageRaw(int i) {
            String string = this.pages.get(i);

            try {
                FormattedText formattedText = Component.Serializer.m_130701_(string);
                if (formattedText != null) {
                    return formattedText;
                }
            } catch (Exception ignored) {
            }

            return FormattedText.m_130775_(string);
        }
    }
}
