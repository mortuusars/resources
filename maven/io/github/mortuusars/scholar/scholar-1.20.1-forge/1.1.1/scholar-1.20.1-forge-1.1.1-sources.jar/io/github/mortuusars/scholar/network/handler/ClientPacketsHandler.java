package io.github.mortuusars.scholar.network.handler;

import net.minecraft.client.Minecraft;

public class ClientPacketsHandler {
    private static void executeOnMainThread(Runnable runnable) {
        Minecraft.m_91087_().execute(runnable);
    }
}
