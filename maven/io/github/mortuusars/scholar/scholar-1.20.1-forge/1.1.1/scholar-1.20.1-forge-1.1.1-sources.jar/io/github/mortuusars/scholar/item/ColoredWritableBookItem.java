package io.github.mortuusars.scholar.item;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookColor;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

@Deprecated(forRemoval = true)
public class ColoredWritableBookItem extends WritableBookItem implements IColoredBook {
    private final DyeColor color;

    public ColoredWritableBookItem(DyeColor color, Properties properties) {
        super(properties);
        this.color = color;
    }

    @Override
    public DyeColor getColor() {
        return color;
    }

    @Override
    public void m_7373_(ItemStack stack, @Nullable Level level, List<Component> tooltipComponents, TooltipFlag isAdvanced) {
        tooltipComponents.add(Component.m_237115_("item.scholar.deprecated_book_message").m_130940_(ChatFormatting.RED));
        tooltipComponents.add(Component.m_237115_("item.scholar.convert_book_message").m_130940_(ChatFormatting.RED));
        super.m_7373_(stack, level, tooltipComponents, isAdvanced);
    }

    @Override
    public @NotNull InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand usedHand) {
        ItemStack deprecatedStack = player.m_21120_(usedHand);

        ItemStack correctStack = new ItemStack(Items.f_42614_);
        correctStack.m_41751_(deprecatedStack.m_41783_());

        BookColor color = BookColor.COLORS.stream()
                .filter(c -> c.getDyeColor()
                        .map(dye -> dye.equals(getColor()))
                        .orElse(false))
                .findFirst()
                .orElse(BookColor.DEFAULT);

        BookColor.set(correctStack, color);

        player.m_5496_(Scholar.SoundEvents.BOOK_SIGNED.get(), 1f, 1f);

        return InteractionResultHolder.m_19090_(correctStack);
    }
}
