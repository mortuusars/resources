package io.github.mortuusars.scholar;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.awt.*;
import java.util.Comparator;
import java.util.function.Consumer;

public class ScholarClient {
    public static void init() {
    }

    public static class KeyMappings {
        public static KeyMapping toggleBookTools = new KeyMapping("key.scholar.toggle_book_tools",
                InputConstants.f_166263_, "key.scholar.categories.scholar");

        public static KeyMapping importBook = new KeyMapping("key.scholar.import_book",
                InputConstants.f_166268_, "key.scholar.categories.scholar");

        public static KeyMapping exportBook = new KeyMapping("key.scholar.export_book",
                InputConstants.f_166269_, "key.scholar.categories.scholar");

        public static void register(Consumer<KeyMapping> registerFunction) {
            registerFunction.accept(toggleBookTools);
            registerFunction.accept(importBook);
            registerFunction.accept(exportBook);
        }

        public static MutableComponent componentForTooltip(KeyMapping keyMapping) {
            return componentForTooltip(keyMapping, ChatFormatting.DARK_GRAY);
        }

        public static MutableComponent componentForTooltip(KeyMapping keyMapping, ChatFormatting formatting) {
            return Component.m_237113_(" " + keyMapping.m_90863_().getString()).m_130940_(formatting);
        }
    }
}
