package io.github.mortuusars.scholar.client.render;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.book.BookColor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.tooltip.TooltipRenderUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.WritableBookItem;
import net.minecraft.world.item.WrittenBookItem;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.ChiseledBookShelfBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChiseledBookShelfBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec2;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class ChiseledBookShelf {
    public static final int DEFAULT_TINT_SLOT_0 = 0xFF1AB8BC;
    public static final int DEFAULT_TINT_SLOT_1 = 0xFF78B140;
    public static final int DEFAULT_TINT_SLOT_2 = 0xFFA743E5;
    public static final int DEFAULT_TINT_SLOT_3 = 0xFFD44A6E;
    public static final int DEFAULT_TINT_SLOT_4 = 0xFFD57856;
    public static final int DEFAULT_TINT_SLOT_5 = 0xFF2F6BC6;

    public static final Map<ResourceLocation, Integer> CUSTOM_COLORS = new HashMap<>();

    static {
        CUSTOM_COLORS.put(new ResourceLocation("minecraft:book"), 0xFF9C763E);
        CUSTOM_COLORS.put(new ResourceLocation("exposure:album"), 0xFFA43E2C);
        CUSTOM_COLORS.put(new ResourceLocation("exposure:signed_album"), 0xFFA43E2C);
    }

    public static int getSlotTintColor(BlockState state, @Nullable BlockAndTintGetter blockGetter,
                                       @Nullable BlockPos pos, int tintIndex) {
        if (!Config.Common.CHISELED_BOOKSHELF_COLORS.get()) {
            return getDefaultTintColorForSlot(tintIndex);
        }

        if (blockGetter == null || pos == null || tintIndex < 0 || tintIndex > 5
                || !(blockGetter.m_7702_(pos) instanceof ChiseledBookShelfBlockEntity blockEntity)) {
            return getDefaultTintColorForSlot(tintIndex);
        }

        ItemStack stackInSlot = blockEntity.m_8020_(tintIndex);
        if (stackInSlot.m_41619_()) return -1;

        if (stackInSlot.m_41720_() instanceof WrittenBookItem || stackInSlot.m_41720_() instanceof WritableBookItem) {
            return BookColor.of(stackInSlot);
        }

        return CUSTOM_COLORS.getOrDefault(BuiltInRegistries.f_257033_.m_7981_(stackInSlot.m_41720_()), getDefaultTintColorForSlot(tintIndex));
    }

    public static int getDefaultTintColorForSlot(int slot) {
        return switch (slot) {
            case 1 -> DEFAULT_TINT_SLOT_1;
            case 2 -> DEFAULT_TINT_SLOT_2;
            case 3 -> DEFAULT_TINT_SLOT_3;
            case 4 -> DEFAULT_TINT_SLOT_4;
            case 5 -> DEFAULT_TINT_SLOT_5;
            default -> DEFAULT_TINT_SLOT_0;
        };
    }

    public static void renderSlotTooltip(GuiGraphics guiGraphics, float partialTick) {
        if (!Config.Common.CHISELED_BOOKSHELF_TOOLTIP.get()) {
            return;
        }

        Minecraft minecraft = Minecraft.m_91087_();

        if (minecraft.f_91073_ == null || minecraft.f_91074_ == null || minecraft.f_91080_ != null
                || !(minecraft.f_91077_ instanceof BlockHitResult blockHitResult)) {
            return;
        }

        BlockPos hitPos = blockHitResult.m_82425_();
        BlockState blockState = minecraft.f_91073_.m_8055_(hitPos);

        if (!(blockState.m_60734_() instanceof ChiseledBookShelfBlock)) {
            return;
        }

        @Nullable BlockEntity blockEntity = minecraft.f_91073_.m_7702_(hitPos);

        if (!(blockEntity instanceof ChiseledBookShelfBlockEntity chiseledBookShelfBlockEntity)) {
            return;
        }

        Optional<Vec2> blockHitPos = ChiseledBookShelfBlock.m_260871_(blockHitResult,
                blockState.m_61143_(HorizontalDirectionalBlock.f_54117_));
        if (blockHitPos.isEmpty()) {
            return;
        }

        int hitSlot = ChiseledBookShelfBlock.m_261279_(blockHitPos.get());

        ItemStack bookStack = chiseledBookShelfBlockEntity.m_8020_(hitSlot);
        if (bookStack.m_41619_()) {
            return;
        }

        int x = minecraft.m_91268_().m_85445_() / 2 + 16;
        int y = minecraft.m_91268_().m_85446_() / 2 - 9;

        TooltipRenderUtil.m_280205_(guiGraphics, x, y, 18, 18, 400);

        guiGraphics.m_280168_().m_85836_();
        guiGraphics.m_280168_().m_252880_(0, 0, 400);
        guiGraphics.m_280480_(bookStack, x + 1, y + 1);
        guiGraphics.m_280168_().m_85849_();

        guiGraphics.m_280153_(minecraft.f_91062_, bookStack, x + 16, y + 12);
    }
}
