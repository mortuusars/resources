package io.github.mortuusars.scholar.client.gui.widget.textbox.text;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.mortuusars.scholar.Scholar;
import net.minecraft.ChatFormatting;
import net.minecraft.SharedConstants;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.StringSplitter;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class FormattedStringEditor {
    protected FormattedString string = new FormattedString();
    protected int cursorPos;
    protected int selectionAnchor;
    protected Predicate<String> validator;

    public FormattedStringEditor(Predicate<String> validator) {
        this.validator = validator;
    }

    public FormattedStringEditor(Supplier<Predicate<String>> stringValidator) {
        this.validator = str -> stringValidator.get().test(str);
    }

    public FormattedString getString() {
        return string;
    }

    public void setString(FormattedString string) {
        this.string = string;
    }

    public int getCursorPos() {
        return cursorPos;
    }

    public int getSelectionAnchor() {
        return selectionAnchor;
    }

    public Predicate<String> getValidator() {
        return validator;
    }

    public void setValidator(Predicate<String> validator) {
        this.validator = validator;
    }

    // -- String

    public int length() {
        return getString().size();
    }

    public List<Char> getSpan(int start, int end) {
        return getString().subList(start, end);
    }

    public List<Char> getSelectedSpan() {
        return getSpan(getSelectionStart(), getSelectionEnd());
    }

    // -- Cursor

    public boolean isCursorAtStart() {
        return getCursorPos() == 0;
    }

    public boolean isCursorAtEnd() {
        return getCursorPos() == length();
    }

    public void setCursorPos(int index) {
        setCursorPos(index, true);
    }

    public void setCursorPos(int index, boolean keepSelection) {
        cursorPos = clampIndex(index);
        resetSelectionIfNeeded(keepSelection);
    }

    public void setCursorToStart(boolean keepSelection) {
        setCursorPos(0, keepSelection);
    }

    public void setCursorToEnd(boolean keepSelection) {
        setCursorPos(length(), keepSelection);
    }

    public void moveCursorBy(int direction, boolean keepSelection, CursorStep cursorStep) {
        switch (cursorStep) {
            case CHARACTER -> this.moveCursorByChars(direction, keepSelection);
            case WORD -> this.moveCursorByWords(direction, keepSelection);
        }
    }

    public void moveCursorByChars(int direction, boolean keepSelection) {
        if (!keepSelection && isSelecting()) {
            setCursorPos(direction < 0 ? getSelectionStart() : getSelectionEnd(), false);
        } else {
            setCursorPos(Util.m_137479_(getString().toStringWithoutFormatting(), getCursorPos(), direction), keepSelection);
        }
    }

    public void moveCursorByWords(int direction, boolean keepSelection) {
        if (!keepSelection && isSelecting()) {
            setCursorPos(direction < 0 ? getSelectionStart() : getSelectionEnd(), false);
        } else {
            setCursorPos(StringSplitter.m_92355_(getString().toStringWithoutFormatting(), direction, getCursorPos(), true), keepSelection);
        }
    }

    public Formatting getFormattingAtCursor() {
        int charBeforeCursor = getCursorPos() - 1;
        if (charBeforeCursor >= 0 && charBeforeCursor < length()) {
            return getString().get(charBeforeCursor).formatting();
        }
        return Formatting.EMPTY;
    }

    // -- Selection

    public boolean isSelecting() {
        return getCursorPos() != getSelectionAnchor();
    }

    public int getSelectionStart() {
        return Math.min(getCursorPos(), getSelectionAnchor());
    }

    public int getSelectionEnd() {
        return Math.max(getCursorPos(), getSelectionAnchor());
    }

    public void setSelectionAnchor(int index) {
        selectionAnchor = clampIndex(index);
    }

    public void setSelectionRange(int start, int end) {
        setSelectionAnchor(start);
        setCursorPos(end, true);
    }

    public void selectWord(int index) {
        setSelectionRange(
                StringSplitter.m_92355_(getString().toStringWithoutFormatting(), -1, index, false),
                StringSplitter.m_92355_(getString().toStringWithoutFormatting(), 1, index, false));
    }

    public String getSelectedString(boolean withFormatting) {
        if (!isSelecting()) return "";
        FormattedString selectedString = getString().subString(getSelectionStart(), getSelectionEnd());
        return withFormatting ? selectedString.toString() : selectedString.toStringWithoutFormatting();
    }

    // --

    private boolean suppressNextCharTyped = false;

    public boolean keyPressed(int key) {
        if (onKeyPressed(key)) {
            suppressNextCharTyped = true;
            return true;
        }
        suppressNextCharTyped = false;
        return false;
    }

    private boolean onKeyPressed(int key) {
        if (Screen.m_96634_(key)) {
            selectAll();
            return true;
        }
        if (key == InputConstants.f_166365_ && Screen.m_96637_() && !Screen.m_96639_()) {
            copy(Screen.m_96638_());
            return true;
        }
        if (key == InputConstants.f_166258_ && Screen.m_96637_() && !Screen.m_96639_()) {
            paste(Screen.m_96638_());
            return true;
        }
        if (key == InputConstants.f_166260_ && Screen.m_96637_() && !Screen.m_96639_()) {
            cut(Screen.m_96638_());
            return true;
        }
        CursorStep cursorStep = Screen.m_96637_() ? CursorStep.WORD : CursorStep.CHARACTER;
        if (key == InputConstants.f_166333_) {
            removeFromCursor(-1, cursorStep);
            return true;
        }
        if (key == InputConstants.f_166334_) {
            removeFromCursor(1, cursorStep);
            return true;
        }
        if (key == InputConstants.f_166330_) {
            moveCursorBy(-1, Screen.m_96638_(), cursorStep);
            return true;
        }
        if (key == InputConstants.f_166331_) {
            moveCursorBy(1, Screen.m_96638_(), cursorStep);
            return true;
        }
        if (key == InputConstants.f_166336_) {
            setCursorToStart(Screen.m_96638_());
            return true;
        }
        if (key == InputConstants.f_166335_) {
            setCursorToEnd(Screen.m_96638_());
            return true;
        }
        if (key == InputConstants.f_166304_ || key == InputConstants.f_166327_) {
            insertTextAtCursor("\n");
            return true;
        }

        @Nullable Formatting formatting = handleFormattingKeys(key);
        if (formatting != null) {
            applyFormatting(formatting);
            return true;
        }

        return false;
    }

    protected Formatting handleFormattingKeys(int key) {
        if (Screen.m_96637_() && !Screen.m_96638_() && !Screen.m_96639_()) {
            return switch (key) {
                case InputConstants.f_166332_ -> Formatting.of(Formatting.Color.BLACK);
                case InputConstants.f_166355_ -> Formatting.of(Formatting.Color.DARK_BLUE);
                case InputConstants.f_166356_ -> Formatting.of(Formatting.Color.DARK_GREEN);
                case InputConstants.f_166357_ -> Formatting.of(Formatting.Color.DARK_AQUA);
                case InputConstants.f_166358_ -> Formatting.of(Formatting.Color.DARK_RED);
                case InputConstants.f_166359_ -> Formatting.of(Formatting.Color.DARK_PURPLE);
                case InputConstants.f_166360_ -> Formatting.of(Formatting.Color.GOLD);
                case InputConstants.f_166361_ -> Formatting.of(Formatting.Color.GRAY);
                // --
                case InputConstants.f_166373_ -> Formatting.of(Formatting.Format.OBFUSCATED);
                case InputConstants.f_166374_ -> Formatting.of(Formatting.Format.BOLD);
                case InputConstants.f_166375_ -> Formatting.of(Formatting.Format.STRIKETHROUGH);
                case InputConstants.f_166376_ -> Formatting.of(Formatting.Format.UNDERLINE);
                case InputConstants.f_166377_ -> Formatting.of(Formatting.Format.ITALIC);
                case InputConstants.f_166254_ -> Formatting.EMPTY;
                default -> null;
            };
        }

        if (Screen.m_96637_() && Screen.m_96638_() && !Screen.m_96639_()) {
            return switch (key) {
                case InputConstants.f_166332_ -> Formatting.of(Formatting.Color.DARK_GRAY);
                case InputConstants.f_166355_ -> Formatting.of(Formatting.Color.BLUE);
                case InputConstants.f_166356_ -> Formatting.of(Formatting.Color.GREEN);
                case InputConstants.f_166357_ -> Formatting.of(Formatting.Color.AQUA);
                case InputConstants.f_166358_ -> Formatting.of(Formatting.Color.RED);
                case InputConstants.f_166359_ -> Formatting.of(Formatting.Color.LIGHT_PURPLE);
                case InputConstants.f_166360_ -> Formatting.of(Formatting.Color.YELLOW);
                case InputConstants.f_166361_ -> Formatting.of(Formatting.Color.WHITE);
                default -> null;
            };
        }

        return null;
    }

    public void applyFormatting(Formatting formatting) {
        // Prevents applying bold formatting if the text would overflow available space due to extra width:
        if (formatting.format().contains(Formatting.Format.BOLD)) {
            FormattedString string = new FormattedString(getString().stream().map(c -> new Char(c.character(), c.formatting().copy())).toList());
            List<Char> chars = string.subList(getSelectionStart(), getSelectionEnd());
            chars.replaceAll(c -> c.flipFormatting(formatting));

            if (!validator.test(string.toString())) {
                return;
            }
        }

        if (isSelecting()) {
            getSelectedSpan().replaceAll(c -> c.flipFormatting(formatting));
        } else if (formatting == Formatting.EMPTY) {
            getString().replaceAll(c -> c.withFormatting(Formatting.EMPTY));
        }
    }

    public boolean charTyped(char character) {
        return !suppressNextCharTyped
                && SharedConstants.m_136188_(character)
                && insertTextAtCursor(Character.toString(character));
    }

    public void cut(boolean withFormatting) {
        copy(withFormatting);
        removeSelectedText();
    }

    public void paste(boolean keepFormatting) {
        try {
            String text = Minecraft.m_91087_().f_91068_.m_90876_();
            if (!keepFormatting) {
                text = ChatFormatting.m_126649_(text);
            }
            insertTextAtCursor(Objects.requireNonNull(text).replaceAll("\\r", ""));
        } catch (Exception e) {
            Scholar.LOGGER.error("Text Paste error: ", e);
        }
    }

    public void copy(boolean withFormatting) {
        Minecraft.m_91087_().f_91068_.m_90911_(getSelectedString(withFormatting));
    }

    public void selectAll() {
        setSelectionAnchor(0);
        setCursorPos(length(), true);
    }

    // --

    public boolean insertTextAtCursor(String text) {
        if (isSelecting()) {
            removeSelectedText();
        }

        FormattedString insertedString = FormattedString.parse(text);
        insertedString.replaceAll(c -> {
            if (!c.hasFormatting()) {
                return c.withFormatting(getFormattingAtCursor());
            }
            return c;
        });

        FormattedString newString = new FormattedString(getString());
        newString.addAll(getCursorPos(), insertedString);

        String string = newString.toStringWithoutFormatting();
        if (validator.test(string)) {
            this.string = newString;
            setCursorPos(getCursorPos() + insertedString.length(), false);
            return true;
        }

        return false;
    }

    public void removeFromCursor(int direction, CursorStep step) {
        switch (step) {
            case CHARACTER: {
                this.removeCharsFromCursor(direction);
                break;
            }
            case WORD: {
                this.removeWordsFromCursor(direction);
            }
        }
    }

    public void removeWordsFromCursor(int direction) {
        int charsCount = StringSplitter.m_92355_(getString().toStringWithoutFormatting(), direction, this.cursorPos, true);
        this.removeCharsFromCursor(charsCount - this.cursorPos);
    }

    public void removeCharsFromCursor(int direction) {
        String string = getString().toStringWithoutFormatting();
        if (!string.isEmpty()) {
            if (isSelecting()) {
                removeSelectedText();
            } else {
                int cursor = getCursorPos();
                int removePos = Util.m_137479_(string, cursor, direction);
                int start = Math.min(removePos, cursor);
                int end = Math.max(removePos, cursor);

                getSpan(start, end).clear();
                setCursorPos(start, false);
            }
        }
    }

    public void removeSelectedText() {
        if (!isSelecting()) return;

        int start = getSelectionStart();
        int end = getSelectionEnd();

        getSpan(start, end).clear();
        setCursorPos(start, false);
    }

    // --

    protected void resetSelectionIfNeeded(boolean keepSelection) {
        if (!keepSelection) {
            setSelectionAnchor(getCursorPos());
        }
    }

    protected int clampIndex(int index) {
        return Mth.m_14045_(index, 0, length());
    }

    public enum CursorStep {
        CHARACTER,
        WORD;
    }

    public interface Validator {
        static Predicate<String> fitInDimensions(Font font, int width, int height) {
            return string -> string.length() < 1024 && font.m_92920_(string, width) + (string.endsWith("\n") ? font.f_92710_ : 0) <= height;
        }
    }
}
