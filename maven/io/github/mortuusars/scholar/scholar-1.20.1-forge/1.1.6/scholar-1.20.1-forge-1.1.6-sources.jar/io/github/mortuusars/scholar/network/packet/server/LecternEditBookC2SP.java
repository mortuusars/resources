package io.github.mortuusars.scholar.network.packet.server;

import com.google.common.collect.Lists;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.PacketDirection;
import io.github.mortuusars.scholar.network.packet.IPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.FilteredText;
import net.minecraft.server.network.TextFilter;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.LecternBlockEntity;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;

/**
 * Similar to {@link net.minecraft.network.protocol.game.ServerboundEditBookPacket} but for lecterns.
 * Contains logic copied from {@link net.minecraft.server.network.ServerGamePacketListenerImpl}, which is not ideal, but hopefully it'll not cause any issues.
 */
public record LecternEditBookC2SP(BlockPos lecternPos, List<String> pages, Optional<String> title) implements IPacket {
    public static final ResourceLocation ID = Scholar.resource("lectern_edit_book");

    private static final int TITLE_MAX_CHARS = 128;
    private static final int PAGE_MAX_CHARS = 8192;
    private static final int MAX_PAGES_COUNT = 200;

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    public static LecternEditBookC2SP fromBuffer(FriendlyByteBuf buffer) {
        return new LecternEditBookC2SP(
                buffer.m_130135_(),
                buffer.m_236838_(FriendlyByteBuf.m_182695_(Lists::newArrayListWithCapacity, MAX_PAGES_COUNT),
                        friendlyByteBuf -> friendlyByteBuf.m_130136_(PAGE_MAX_CHARS)),
                buffer.m_236860_(friendlyByteBuf -> friendlyByteBuf.m_130136_(TITLE_MAX_CHARS)));
    }

    @Override
    public FriendlyByteBuf toBuffer(FriendlyByteBuf buffer) {
        buffer.m_130064_(lecternPos);
        buffer.m_236828_(pages, (friendlyByteBuf, string) -> friendlyByteBuf.m_130072_(string, PAGE_MAX_CHARS));
        buffer.m_236835_(title, (friendlyByteBuf, string) -> friendlyByteBuf.m_130072_(string, TITLE_MAX_CHARS));
        return buffer;
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable Player player) {
        if (!(player instanceof ServerPlayer serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", getId());
            return true;
        }

        if (!(player.m_9236_().m_7702_(lecternPos) instanceof LecternBlockEntity lecternBlockEntity)) {
            Scholar.LOGGER.error("Cannot update lectern book: no lectern block entity at lecternPos '{}'", lecternPos);
            return false;
        }

        ArrayList<String> bookPages = new ArrayList<>();
        Optional<String> title = title();
        title.ifPresent(bookPages::add);
        pages().stream().limit(100L).forEach(bookPages::add);
        Consumer<List<FilteredText>> consumer = title.isPresent()
                ? list -> signBook(serverPlayer, list.get(0), list.subList(1, list.size()), lecternBlockEntity)
                : list -> updateBookContents(serverPlayer, list, lecternBlockEntity);
        this.filterTextPacket(serverPlayer,bookPages).thenAccept(consumer);

        return true;
    }

    private void updateBookContents(ServerPlayer player, List<FilteredText> pages, LecternBlockEntity lecternBlockEntity) {
        ItemStack itemStack = lecternBlockEntity.m_59566_();
        if (!itemStack.m_150930_(Items.f_42614_)) return;
        updateBookPages(player, pages, UnaryOperator.identity(), itemStack, lecternBlockEntity);
    }

    private void signBook(ServerPlayer player, FilteredText title, List<FilteredText> pages, LecternBlockEntity lecternBlockEntity) {
        ItemStack itemStack = lecternBlockEntity.m_59566_();

        if (!itemStack.m_150930_(Items.f_42614_)) return;

        ItemStack writtenBookStack = new ItemStack(Items.f_42615_);
        CompoundTag compoundTag = itemStack.m_41783_();
        if (compoundTag != null) {
            writtenBookStack.m_41751_(compoundTag.m_6426_());
        }
        writtenBookStack.m_41700_("author", StringTag.m_129297_(player.m_7755_().getString()));
        if (player.m_143387_()) {
            writtenBookStack.m_41700_("title", StringTag.m_129297_(title.m_243113_()));
        } else {
            writtenBookStack.m_41700_("filtered_title", StringTag.m_129297_(title.m_243113_()));
            writtenBookStack.m_41700_("title", StringTag.m_129297_(title.f_215168_()));
        }

        this.updateBookPages(player, pages, string -> Component.Serializer.m_130703_(Component.m_237113_(string)), writtenBookStack, lecternBlockEntity);

        lecternBlockEntity.m_59538_(writtenBookStack, player);
    }

    private void updateBookPages(ServerPlayer player, List<FilteredText> pages, UnaryOperator<String> updater, ItemStack book, LecternBlockEntity lecternBlockEntity) {
        ListTag listTag = new ListTag();
        if (player.m_143387_()) {
            pages.stream().map(filteredText -> StringTag.m_129297_(updater.apply(filteredText.m_243113_()))).forEach(listTag::add);
        } else {
            CompoundTag compoundTag = new CompoundTag();
            int j = pages.size();
            for (int i = 0; i < j; ++i) {
                FilteredText filteredText2 = pages.get(i);
                String string = filteredText2.f_215168_();
                listTag.add(StringTag.m_129297_(updater.apply(string)));
                if (!filteredText2.m_215174_()) continue;
                compoundTag.m_128359_(String.valueOf(i), updater.apply(filteredText2.m_243113_()));
            }
            if (!compoundTag.m_128456_()) {
                book.m_41700_("filtered_pages", compoundTag);
            }
        }
        book.m_41700_("pages", listTag);
    }

    private <T, R> CompletableFuture<R> filterTextPacket(ServerPlayer player, T message, BiFunction<TextFilter, T, CompletableFuture<R>> processor) {
        return processor.apply(player.m_8967_(), message).thenApply(object -> {
            if (!player.f_8906_.m_6198_()) {
                Scholar.LOGGER.debug("Ignoring packet due to disconnection");
                throw new CancellationException("disconnected");
            }
            return object;
        });
    }

    private CompletableFuture<List<FilteredText>> filterTextPacket(ServerPlayer player, List<String> texts) {
        return this.filterTextPacket(player, texts, TextFilter::m_5925_);
    }
}
