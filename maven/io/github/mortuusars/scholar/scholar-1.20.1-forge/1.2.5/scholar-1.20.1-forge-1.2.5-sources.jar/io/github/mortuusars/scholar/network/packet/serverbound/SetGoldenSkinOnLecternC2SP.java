package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.PacketDirection;
import io.github.mortuusars.scholar.network.packet.Packet;
import io.github.mortuusars.scholar.util.supporter.Supporters;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.LecternBlockEntity;

public record SetGoldenSkinOnLecternC2SP(BlockPos lecternPos, boolean golden) implements Packet {
    public static final ResourceLocation ID = Scholar.resource("set_golden_skin_on_lectern");

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    public static SetGoldenSkinOnLecternC2SP fromBuffer(FriendlyByteBuf buffer) {
        return new SetGoldenSkinOnLecternC2SP(buffer.m_130135_(), buffer.readBoolean());
    }

    @Override
    public FriendlyByteBuf toBuffer(FriendlyByteBuf buffer) {
        buffer.m_130064_(lecternPos);
        buffer.writeBoolean(golden);
        return buffer;
    }

    @Override
    public boolean handle(PacketDirection direction, Player player) {
        if (!(player instanceof ServerPlayer serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (!(serverPlayer.m_9236_().m_7702_(lecternPos) instanceof LecternBlockEntity lecternBlockEntity)) {
            Scholar.LOGGER.error("Cannot update lectern book: no lectern block entity at [{}]", lecternPos.m_123344_());
            return false;
        }

        ItemStack book = lecternBlockEntity.m_59566_();

        if (book.m_150930_(Items.f_42614_) && Supporters.hasAccessToGoldenSkin(player.m_20148_())) {
            if (!golden) {
                if (book.m_41783_() != null) {
                    book.m_41783_().m_128473_(Scholar.NBT.BOOK_GOLDEN);
                }
            } else {
                book.m_41784_().m_128379_(Scholar.NBT.BOOK_GOLDEN, true);
            }
            lecternBlockEntity.m_6596_();

            // Manually sending the block data to clients because it doesn't happen when block is changed for some reason
            if (Config.Common.LECTERN_TOOLTIP.get()) {
                var bePacket = lecternBlockEntity.m_58483_();
                serverPlayer.m_284548_().m_6907_().forEach(pl -> {
                    if (lecternPos.m_123331_(pl.m_20183_()) < 128) {
                        pl.f_8906_.m_9829_(bePacket);
                    }
                });
            }
        }

        return true;
    }
}
