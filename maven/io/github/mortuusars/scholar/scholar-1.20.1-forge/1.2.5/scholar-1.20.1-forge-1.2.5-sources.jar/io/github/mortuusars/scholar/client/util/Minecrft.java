package io.github.mortuusars.scholar.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.RegistryAccess;

import java.util.Objects;

public class Minecrft {
    public static Minecraft get() {
        return Minecraft.m_91087_();
    }

    public static LocalPlayer player() {
        return Objects.requireNonNull(get().f_91074_, "Player is not available.");
    }

    public static ClientLevel level() {
        return Objects.requireNonNull(get().f_91073_, "Level is not available.");
    }

    public static RegistryAccess registryAccess() {
        return level().m_9598_();
    }

    public static MultiPlayerGameMode gameMode() {
        return Objects.requireNonNull(get().f_91072_, "GameMode is not available.");
    }

    public static Options options() {
        return get().f_91066_;
    }

    public static void execute(Runnable runnable) {
        get().execute(runnable);
    }

    public static void releaseUseButton() {
        options().f_92095_.m_7249_(false);
    }

    public static void stopPlayerMovement() {
        // Stop player moving if movement key is held
        Minecrft.player().f_20900_ = 0;
        Minecrft.player().f_20901_ = 0;
        Minecrft.player().f_20902_ = 0;
        Minecrft.player().m_6862_(false);
        options().f_92085_.m_7249_(false);
        options().f_92087_.m_7249_(false);
        options().f_92086_.m_7249_(false);
        options().f_92088_.m_7249_(false);
        options().f_92089_.m_7249_(false);
    }
}
