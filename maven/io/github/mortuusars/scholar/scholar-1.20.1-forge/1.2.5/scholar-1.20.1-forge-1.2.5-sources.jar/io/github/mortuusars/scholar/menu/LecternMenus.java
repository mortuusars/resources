package io.github.mortuusars.scholar.menu;

import io.github.mortuusars.scholar.PlatformHelper;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.LecternBlockEntity;
import org.jetbrains.annotations.NotNull;

public class LecternMenus {
    public static void openBookViewMenu(ServerPlayer player, LecternBlockEntity lecternBlockEntity, ItemStack bookStack) {
        MenuProvider menuProvider = new MenuProvider() {
            @Override
            public @NotNull Component m_5446_() {
                return bookStack.m_41786_();
            }

            @Override
            public @NotNull AbstractContainerMenu m_7208_(int containerId, @NotNull Inventory playerInventory, @NotNull Player player) {
                Container bookAccess = lecternBlockEntity.f_59525_;
                ContainerData dataAccess = lecternBlockEntity.f_59526_;
                return new LecternSpreadMenu(containerId, bookAccess, dataAccess, lecternBlockEntity.m_58899_());
            }
        };

        PlatformHelper.openMenu(player, menuProvider, buffer -> {
            buffer.m_130055_(bookStack);
            buffer.m_130064_(lecternBlockEntity.m_58899_());
        });
    }

    public static void openBookEditMenu(ServerPlayer player, LecternBlockEntity lecternBlockEntity, ItemStack bookStack) {
        MenuProvider menuProvider = new MenuProvider() {
            @Override
            public @NotNull Component m_5446_() {
                return bookStack.m_41786_();
            }

            @Override
            public @NotNull AbstractContainerMenu m_7208_(int containerId, @NotNull Inventory playerInventory, @NotNull Player player) {
                Container bookAccess = lecternBlockEntity.f_59525_;
                ContainerData dataAccess = lecternBlockEntity.f_59526_;
                return new LecternSpreadBookEditMenu(containerId, bookAccess, dataAccess, lecternBlockEntity.m_58899_());
            }
        };

        PlatformHelper.openMenu(player, menuProvider, buffer -> {
            buffer.m_130055_(bookStack);
            buffer.m_130064_(lecternBlockEntity.m_58899_());
        });
    }
}
