package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.PacketDirection;
import io.github.mortuusars.scholar.network.packet.Packet;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public record SetBookmarkC2SP(int slot, int page) implements Packet {
    public static final ResourceLocation ID = Scholar.resource("set_bookmark");

    @Override
    public FriendlyByteBuf toBuffer(FriendlyByteBuf buffer) {
        buffer.writeInt(slot);
        buffer.writeInt(page);
        return buffer;
    }

    public static SetBookmarkC2SP fromBuffer(FriendlyByteBuf buffer) {
        return new SetBookmarkC2SP(buffer.readInt(), buffer.readInt());
    }

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable Player player) {
        if (!(player instanceof ServerPlayer serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (Inventory.m_36045_(slot) || slot == Inventory.f_150066_) {
            ItemStack stack = serverPlayer.m_150109_().m_8020_(slot);
            if (page == 0) {
                if (stack.m_41783_() != null) {
                    stack.m_41783_().m_128473_(Scholar.NBT.BOOKMARK);
                }
            } else {
                stack.m_41784_().m_128405_(Scholar.NBT.BOOKMARK, page);
            }
            return true;
        }

        return true;
    }
}
