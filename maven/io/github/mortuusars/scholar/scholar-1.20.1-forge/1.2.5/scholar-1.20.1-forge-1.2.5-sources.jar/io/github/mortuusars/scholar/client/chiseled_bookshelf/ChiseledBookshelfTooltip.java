package io.github.mortuusars.scholar.client.chiseled_bookshelf;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.client.gui.InWorldTooltip;
import io.github.mortuusars.scholar.integration.Mods;
import io.github.mortuusars.scholar.integration.woodworks.WoodworksIntegration;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.ChiseledBookShelfBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChiseledBookShelfBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec2;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.OptionalInt;

public class ChiseledBookshelfTooltip {
    public static boolean render(GuiGraphics guiGraphics, float partialTicks) {
        if (!Config.Common.CHISELED_BOOKSHELF_TOOLTIP.get()) {
            return false;
        }

        Minecraft minecraft = Minecraft.m_91087_();

        if (minecraft.f_91073_ == null || minecraft.f_91074_ == null || minecraft.f_91080_ != null
              || !(minecraft.f_91077_ instanceof BlockHitResult blockHitResult)) {
            return false;
        }

        if (Config.Common.TOOLTIP_REQUIRES_SNEAK.get() && !minecraft.f_91074_.m_36341_()) {
            return false;
        }

        BlockPos hitPos = blockHitResult.m_82425_();
        BlockState blockState = minecraft.f_91073_.m_8055_(hitPos);

        if (!(blockState.m_60734_() instanceof ChiseledBookShelfBlock chiseledBookShelfBlock)) {
            return false;
        }

        @Nullable BlockEntity blockEntity = minecraft.f_91073_.m_7702_(hitPos);

        if (!(blockEntity instanceof ChiseledBookShelfBlockEntity chiseledBookShelfBlockEntity)) {
            return false;
        }

        Optional<Vec2> blockHitPos = ChiseledBookShelfBlock.m_260871_(blockHitResult,
              blockState.m_61143_(HorizontalDirectionalBlock.f_54117_));
        if (blockHitPos.isEmpty()) {
            return false;
        }

        int hitSlot = getHitSlot(blockState, blockHitPos.get());

        ItemStack bookStack = chiseledBookShelfBlockEntity.m_8020_(hitSlot);
        if (bookStack.m_41619_()) {
            return false;
        }

        InWorldTooltip.renderItemTooltip(guiGraphics, partialTicks, bookStack);
        return true;
    }

    private static int getHitSlot(BlockState state, Vec2 hitPos) {
        if (Mods.WOODWORKS.isLoaded()) {
            OptionalInt slot = WoodworksIntegration.getHitSlot(state, hitPos);
            if (slot.isPresent()) {
                return slot.getAsInt();
            }
        }

        return ChiseledBookShelfBlock.m_261279_(hitPos);
    }
}
