package io.github.mortuusars.scholar.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.client.animation.ReadingAnimation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.*;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.Material;
import net.minecraft.util.FastColor;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.WritableBookItem;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.entity.LecternBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.NotNull;

public class ColoredBookModel {
    public static final Material BOOK_COVER_LOCATION =
          new Material(InventoryMenu.f_39692_, Scholar.resource("block/book_cover"));
    public static final Material BOOK_COVER_GOLDEN_LOCATION =
          new Material(InventoryMenu.f_39692_, Scholar.resource("block/book_cover_golden"));
    public static final Material BOOK_PAGES_LOCATION =
          new Material(InventoryMenu.f_39692_, Scholar.resource("block/book_pages"));

    public static void renderOnLectern(BlockState blockState, LecternBlockEntity blockEntity, float partialTick, PoseStack poseStack,
                                       MultiBufferSource buffer, int packedLight, int packedOverlay, BookModel bookModel) {
        ItemStack book = blockEntity.m_59566_();
        if (!book.m_41619_()) {
            poseStack.m_85836_();
            poseStack.m_252880_(0.5F, 1.0625F, 0.5F);
            float f = blockState.m_61143_(LecternBlock.f_54465_).m_122427_().m_122435_();
            poseStack.m_252781_(Axis.f_252436_.m_252977_(-f));
            poseStack.m_252781_(Axis.f_252403_.m_252977_(67.5F));
            poseStack.m_252880_(0.0F, -0.125F, 0.0F);
            bookModel.m_102292_(0.0F, 0.1F, 0.9F, 1.2F);
            if (book.m_41783_() != null && book.m_41783_().m_128471_(Scholar.NBT.BOOK_GOLDEN)) {
                VertexConsumer coverVertexConsumer = getBookCoverGoldenLocation(book).m_119194_(buffer, RenderType::m_110452_);
                bookModel.m_102316_(poseStack, coverVertexConsumer, packedLight, packedOverlay, 1, 1, 1, 1);
            } else {
                VertexConsumer coverVertexConsumer = getBookCoverLocation(book).m_119194_(buffer, RenderType::m_110452_);
                int color = BookColor.of(book);
                bookModel.m_102316_(poseStack, coverVertexConsumer, packedLight, packedOverlay,
                      FastColor.ARGB32.m_13665_(color) / 255f,
                      FastColor.ARGB32.m_13667_(color) / 255f,
                      FastColor.ARGB32.m_13669_(color) / 255f,
                      1);
            }
            VertexConsumer pagesVertexConsumer = getBookPagesLocation(book).m_119194_(buffer, RenderType::m_110452_);
            bookModel.m_102316_(poseStack, pagesVertexConsumer, packedLight, packedOverlay, 1, 1, 1, 1);
            poseStack.m_85849_();
        }
    }

    public static <M extends EntityModel<?> & ArmedModel> void renderInHand(LivingEntity entity, ItemStack book, HumanoidArm arm,
                                                                            PoseStack poseStack, MultiBufferSource buffer,
                                                                            int packedLight, M entityModel, BookModel bookModel) {
        poseStack.m_85836_();

        // We attach the book to the left hand, to use the right hand for page flipping animation (to not move the book with the arm).
        // Unless the entity is currently swinging - in that case we still use original arm for it, to "open" the book in the correct hand.
        if (entity.f_20911_) {
            entityModel.m_6002_(arm, poseStack);
            poseStack.m_85837_(arm == HumanoidArm.LEFT ? -0.285F : 0.285F, 0.625, -0.38);
        } else {
            entityModel.m_6002_(HumanoidArm.LEFT, poseStack);
            poseStack.m_85837_(-0.285F, 0.625, -0.38);
        }

        poseStack.m_252781_(Axis.f_252436_.m_252977_(-90));
        poseStack.m_252781_(Axis.f_252403_.m_252977_(-90));

        ReadingAnimation.poseBook(entity, book, arm, entityModel, bookModel);

        if (book.m_41783_() != null && book.m_41783_().m_128471_(Scholar.NBT.BOOK_GOLDEN)) {
            VertexConsumer coverVertexConsumer = getBookCoverGoldenLocation(book).m_119194_(buffer, RenderType::m_110452_);
            bookModel.m_102316_(poseStack, coverVertexConsumer, packedLight, OverlayTexture.f_118083_, 1, 1, 1, 1);
        } else {
            VertexConsumer coverVertexConsumer = getBookCoverLocation(book).m_119194_(buffer, RenderType::m_110452_);
            int color = BookColor.of(book);
            bookModel.m_102316_(poseStack, coverVertexConsumer, packedLight, OverlayTexture.f_118083_,
                  FastColor.ARGB32.m_13665_(color) / 255f,
                  FastColor.ARGB32.m_13667_(color) / 255f,
                  FastColor.ARGB32.m_13669_(color) / 255f,
                  1);
        }
        VertexConsumer pagesVertexConsumer = getBookPagesLocation(book).m_119194_(buffer, RenderType::m_110452_);
        bookModel.m_102316_(poseStack, pagesVertexConsumer, packedLight, OverlayTexture.f_118083_, 1, 1, 1, 1);

        poseStack.m_85849_();

        if (book.m_41720_() instanceof WritableBookItem) {
            HumanoidArm mainArm = entity.m_5737_();
            boolean isLeftArm = mainArm == HumanoidArm.LEFT;

            poseStack.m_85836_();
            entityModel.m_6002_(mainArm, poseStack);
            poseStack.m_85837_((float) (isLeftArm ? -1 : 1) / 16.0F - 0.05, 0.5F,
                  entityModel instanceof SkeletonModel<?> ? -0.15F : -0.22F);
            poseStack.m_252781_(Axis.f_252529_.m_252977_(150.0F));
            poseStack.m_252781_(Axis.f_252403_.m_252977_(40.0F));
            poseStack.m_252781_(Axis.f_252436_.m_252977_(-90));
            poseStack.m_85841_(0.8f, 0.8f, 0.8f);

            ItemDisplayContext context = mainArm == HumanoidArm.LEFT
                  ? ItemDisplayContext.THIRD_PERSON_LEFT_HAND
                  : ItemDisplayContext.THIRD_PERSON_RIGHT_HAND;
            Minecraft.m_91087_().m_91290_().m_234586_()
                  .m_269530_(entity, new ItemStack(Items.f_42402_), context, isLeftArm, poseStack, buffer, packedLight);
            poseStack.m_85849_();
        }
    }

    public static void renderInFirstpersonHand(LivingEntity entity, ItemStack book, ItemDisplayContext displayContext, boolean leftHand,
                                               PoseStack poseStack, MultiBufferSource buffer, int packedLight, BookModel bookModel) {
        poseStack.m_85836_();

        if (leftHand) {
            poseStack.m_252781_(Axis.f_252436_.m_252977_(135));
            poseStack.m_252781_(Axis.f_252403_.m_252977_(135));
        } else {
            poseStack.m_252781_(Axis.f_252436_.m_252977_(45));
            poseStack.m_252781_(Axis.f_252403_.m_252977_(135));
        }

        bookModel.m_102292_(0.0F, 0.1F, 0.9F, 1.2F);

        if (book.m_41783_() != null && book.m_41783_().m_128471_(Scholar.NBT.BOOK_GOLDEN)) {
            VertexConsumer coverVertexConsumer = getBookCoverGoldenLocation(book).m_119194_(buffer, RenderType::m_110452_);
            bookModel.m_102316_(poseStack, coverVertexConsumer, packedLight, OverlayTexture.f_118083_, 1, 1, 1, 1);
        } else {
            VertexConsumer coverVertexConsumer = getBookCoverLocation(book).m_119194_(buffer, RenderType::m_110452_);
            int color = BookColor.of(book);
            bookModel.m_102316_(poseStack, coverVertexConsumer, packedLight, OverlayTexture.f_118083_,
                  FastColor.ARGB32.m_13665_(color) / 255f,
                  FastColor.ARGB32.m_13667_(color) / 255f,
                  FastColor.ARGB32.m_13669_(color) / 255f,
                  1);
        }
        VertexConsumer pagesVertexConsumer = getBookPagesLocation(book).m_119194_(buffer, RenderType::m_110452_);
        bookModel.m_102316_(poseStack, pagesVertexConsumer, packedLight, OverlayTexture.f_118083_, 1, 1, 1, 1);
        poseStack.m_85849_();
    }

    public static @NotNull Material getBookCoverLocation(ItemStack book) {
        return ColoredBookModel.BOOK_COVER_LOCATION;
    }

    public static @NotNull Material getBookPagesLocation(ItemStack stack) {
        return ColoredBookModel.BOOK_PAGES_LOCATION;
    }

    public static @NotNull Material getBookCoverGoldenLocation(ItemStack stack) {
        return ColoredBookModel.BOOK_COVER_GOLDEN_LOCATION;
    }
}
