package io.github.mortuusars.scholar.world.entity;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class ReadBookGoal extends Goal {
    private final Mob mob;
    private int readingTime;
    private int readingDuration;

    public ReadBookGoal(Mob mob) {
        this.mob = mob;
    }

    @Override
    public boolean m_183429_() {
        return true;
    }

    @Override
    public boolean m_8036_() {
        if (Reading.getOpenedBookHand(mob) != null) {
            m_8041_(); // Closes the book properly after world reload or something.
        }
        return canRead() && mob.m_217043_().m_188501_() < Config.Common.LITERATE_MOBS_BOOK_READING_CHANCE.get();
    }

    public boolean canRead() {
        return mob.m_6095_().m_204039_(Scholar.Tags.EntityTypes.LITERATE)
              && mob.m_5448_() == null
              && !mob.m_20070_()
              && !mob.m_21573_().m_26572_()
              && !mob.m_6060_()
              && isReadableBook(mob.m_21205_());
    }

    @Override
    public boolean m_8045_() {
        return readingTime < readingDuration && canRead();
    }

    @Override
    public void m_8056_() {
        mob.m_21205_().m_41784_().m_128379_(Scholar.NBT.BOOK_OPEN, true);
        mob.m_5496_(SoundEvents.f_11713_, 0.6f, 1.1f);
        mob.m_6674_(InteractionHand.MAIN_HAND);
        readingTime = 0;
        readingDuration = 300 + mob.m_217043_().m_188503_(10) * 20;
    }

    @Override
    public void m_8037_() {
        readingTime++;
    }

    @Override
    public void m_8041_() {
        if (mob.m_21205_().m_41783_() != null) {
            mob.m_21205_().m_41783_().m_128473_(Scholar.NBT.BOOK_OPEN);
        }
        mob.m_5496_(SoundEvents.f_11713_, 0.6f, 0.75f);
        mob.m_6674_(InteractionHand.MAIN_HAND);
    }

    // --

    public static boolean isReadableBook(ItemStack stack) {
        return stack.m_150930_(Items.f_42517_) || stack.m_150930_(Items.f_42615_) || stack.m_150930_(Items.f_42614_);
    }

    public static int getPriority(Mob mob) {
        return 7;
    }
}
