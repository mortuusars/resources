package io.github.mortuusars.scholar.client.resource;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.integration.Mods;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

public class BuiltInResourcePacks {
    public static List<Pack> get() {
        List<Pack> packs = new java.util.ArrayList<>();

        packs.add(new Pack(
                Scholar.resource("colored_books"),
                Component.m_237115_("resourcepack.scholar.colored_books.name"),
                new Activation(ActivationType.DEFAULT_ENABLED)));
        packs.add(new Pack(
                Scholar.resource("chiseled_bookshelf_colored_books"),
                Component.m_237115_("resourcepack.scholar.chiseled_bookshelf_colored_books.name"),
                new Activation(ActivationType.DEFAULT_ENABLED)));

        if (Mods.MCBV.isLoading()) {
            packs.add(new Pack(
                    Scholar.resource("chiseled_bookshelf_colored_books_lolmcbv_compat"),
                    Component.m_237115_("resourcepack.scholar.chiseled_bookshelf_colored_books_lolmcbv_compat.name"),
                    new Activation(ActivationType.DEFAULT_ENABLED)));
        }

        if (Mods.WOODWORKS.isLoading()) {
            packs.add(new Pack(
                    Scholar.resource("chiseled_bookshelf_colored_books_abnww_compat"),
                    Component.m_237115_("resourcepack.scholar.chiseled_bookshelf_colored_books_abnww_compat.name"),
                    new Activation(ActivationType.DEFAULT_ENABLED)));
        }

        return packs;
    }

    public record Pack(ResourceLocation id, Component name, Activation activation) {}

    public record Activation(ActivationType fabric, ActivationType forge) {
        public Activation(ActivationType type) {
            this(type, type);
        }
    }

    public enum ActivationType {
        DEFAULT_DISABLED,
        DEFAULT_ENABLED,
        ALWAYS_ENABLED;
    }
}
