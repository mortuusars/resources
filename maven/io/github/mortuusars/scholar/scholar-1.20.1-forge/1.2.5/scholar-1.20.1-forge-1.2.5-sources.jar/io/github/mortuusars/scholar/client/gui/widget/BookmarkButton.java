package io.github.mortuusars.scholar.client.gui.widget;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class BookmarkButton extends ImageButton {
    protected int expandedVOffset;
    protected final ResourceLocation texture;
    protected boolean expanded;

    public BookmarkButton(int x, int y, int width, int height, int u, int v, int expandedVOffset,
                          int textureWidth, int textureHeight, ResourceLocation texture, OnPress onPress, Component message) {
        super(x, y, width, height, u, v, height, texture, textureWidth, textureHeight, onPress, message);
        this.expandedVOffset = expandedVOffset;
        this.texture = texture;
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    @Override
    public void m_87963_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        m_280322_(guiGraphics, texture, m_252754_(), m_252907_(), f_94224_, f_94225_ + (isExpanded() ? expandedVOffset : 0), f_94226_,
              f_93618_, f_93619_, f_94227_, f_94228_);
    }
}
