package io.github.mortuusars.scholar.mixin;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.client.gui.screen.view.BookViewAccess;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.client.gui.screen.view.InHandSpreadBookViewScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundOpenBookPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerMixin {
    @Inject(method = "handleOpenBook", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/player/LocalPlayer;getItemInHand(Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/item/ItemStack;"),
            cancellable = true)
    private void handleOpenBook(ClientboundOpenBookPacket packet, CallbackInfo ci) {
        if (Minecraft.m_91087_().f_91074_ == null) return;
        if (!Config.Common.IN_HAND_TWO_PAGE_BOOK_SCREEN.get()) return;
        if (Config.Common.SNEAKING_OPENS_VANILLA_BOOK_SCREEN.get() && Minecraft.m_91087_().f_91074_.m_36341_()) return;

        InteractionHand hand = packet.m_132608_();
        ItemStack stack = Minecraft.m_91087_().f_91074_.m_21120_(hand);

        if (!stack.m_150930_(Items.f_42615_)) return;

        Minecraft.m_91087_().m_91152_(new InHandSpreadBookViewScreen(
              BookViewAccess.fromItem(stack),
              BookColor.of(stack),
              packet.m_132608_()));

        ci.cancel();
    }
}