package io.github.mortuusars.scholar.client.gui;

import io.github.mortuusars.scholar.client.chiseled_bookshelf.ChiseledBookshelfTooltip;
import io.github.mortuusars.scholar.client.lectern.LecternTooltip;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.tooltip.TooltipRenderUtil;
import net.minecraft.world.item.ItemStack;

public class InWorldTooltip {
    public static boolean render(GuiGraphics guiGraphics, float partialTicks) {
        if (Minecraft.m_91087_().f_91066_.f_92062_) {
            return false;
        }
        return ChiseledBookshelfTooltip.render(guiGraphics, partialTicks)
              || LecternTooltip.render(guiGraphics, partialTicks);
    }

    public static void renderItemTooltip(GuiGraphics guiGraphics, float partialTicks, ItemStack stack) {
        int x = Minecraft.m_91087_().m_91268_().m_85445_() / 2 + 16;
        int y = Minecraft.m_91087_().m_91268_().m_85446_() / 2 - 9;

        TooltipRenderUtil.m_280205_(guiGraphics, x, y, 18, 18, 400);

        guiGraphics.m_280168_().m_85836_();
        guiGraphics.m_280168_().m_252880_(0, 0, 400);
        guiGraphics.m_280480_(stack, x + 1, y + 1);
        guiGraphics.m_280168_().m_85849_();

        guiGraphics.m_280153_(Minecraft.m_91087_().f_91062_, stack, x + 16, y + 12);
    }
}
