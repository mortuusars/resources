package io.github.mortuusars.scholar.client.lectern;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.client.gui.InWorldTooltip;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.LecternBlockEntity;
import net.minecraft.world.phys.BlockHitResult;

public class LecternTooltip {
    public static boolean render(GuiGraphics guiGraphics, float partialTicks) {
        if (!Config.Common.LECTERN_TOOLTIP.get()) {
            return false;
        }

        Minecraft minecraft = Minecraft.m_91087_();

        if (minecraft.f_91073_ == null || minecraft.f_91074_ == null || minecraft.f_91080_ != null
              || !(minecraft.f_91077_ instanceof BlockHitResult blockHitResult)
              || !(minecraft.f_91073_.m_7702_(blockHitResult.m_82425_()) instanceof LecternBlockEntity lecternBlockEntity)) {
            return false;
        }

        if (Config.Common.TOOLTIP_REQUIRES_SNEAK.get() && !minecraft.f_91074_.m_36341_()) {
            return false;
        }

        ItemStack bookStack = lecternBlockEntity.m_59566_();
        if (bookStack.m_41619_()) {
            return false;
        }

        InWorldTooltip.renderItemTooltip(guiGraphics, partialTicks, bookStack);
        return true;
    }
}
