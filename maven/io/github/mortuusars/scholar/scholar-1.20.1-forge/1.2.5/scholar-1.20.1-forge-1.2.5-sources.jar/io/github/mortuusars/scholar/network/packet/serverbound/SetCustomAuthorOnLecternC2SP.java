package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.PacketDirection;
import io.github.mortuusars.scholar.network.packet.Packet;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.LecternBlockEntity;
import org.jetbrains.annotations.Nullable;

public record SetCustomAuthorOnLecternC2SP(BlockPos lecternPos, String author) implements Packet {
    public static final ResourceLocation ID = Scholar.resource("set_custom_author_on_lectern");

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    public static SetCustomAuthorOnLecternC2SP fromBuffer(FriendlyByteBuf buffer) {
        return new SetCustomAuthorOnLecternC2SP(buffer.m_130135_(), buffer.m_130277_());
    }

    @Override
    public FriendlyByteBuf toBuffer(FriendlyByteBuf buffer) {
        buffer.m_130064_(lecternPos);
        buffer.m_130070_(author);
        return buffer;
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable Player player) {
        if (!(player instanceof ServerPlayer serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (!Config.Common.BOOK_CHANGEABLE_AUTHOR.get()) {
            return true;
        }

        if (!(player.m_9236_().m_7702_(lecternPos) instanceof LecternBlockEntity lecternBlockEntity)) {
            Scholar.LOGGER.error("Cannot update lectern book: no lectern block entity at [{}]", lecternPos.m_123344_());
            return false;
        }

        if (author.length() > 128) {
            Scholar.LOGGER.error("Cannot handle {} packet: player {} sent author string that's too long: {}. Max 128..", ID, player, author.length());
            return true;
        }

        ItemStack book = lecternBlockEntity.m_59566_();
        if (!book.m_150930_(Items.f_42615_)) {
            Scholar.LOGGER.error("Cannot set signing author on a lectern book at [{}]: book is not a written book but '{}'",
                  lecternPos.m_123344_(), book);
            return false;
        }

        book.m_41784_().m_128359_("author", author);
        lecternBlockEntity.m_6596_();

        // Manually sending the block data to clients because it doesn't happen when block is changed for some reason
        if (Config.Common.LECTERN_TOOLTIP.get()) {
            var bePacket = lecternBlockEntity.m_58483_();
            serverPlayer.m_284548_().m_6907_().forEach(pl -> {
                if (lecternPos.m_123331_(pl.m_20183_()) < 128) {
                    pl.f_8906_.m_9829_(bePacket);
                }
            });
        }

        return true;
    }
}