package io.github.mortuusars.scholar.forge;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.client.settings.KeyModifier;

public class PlatformHelperClientImpl {
    public static KeyMapping createInsertEmptyPageLeftKeyMapping() {
        return new KeyMapping("key.scholar.insert_empty_page_left",
              KeyConflictContext.GUI,
              KeyModifier.SHIFT,
              InputConstants.Type.KEYSYM.m_84895_(InputConstants.f_166337_),
              "key.scholar.categories.scholar");
    }

    public static KeyMapping createRemovePageLeftKeyMapping() {
        return new KeyMapping("key.scholar.remove_page_left",
              KeyConflictContext.GUI,
              KeyModifier.SHIFT,
              InputConstants.Type.KEYSYM.m_84895_(InputConstants.f_166334_),
              "key.scholar.categories.scholar");
    }

    public static KeyMapping createInsertEmptyPageRightKeyMapping() {
        return new KeyMapping("key.scholar.insert_empty_page_right",
              KeyConflictContext.GUI,
              KeyModifier.ALT,
              InputConstants.Type.KEYSYM.m_84895_(InputConstants.f_166337_),
              "key.scholar.categories.scholar");
    }

    public static KeyMapping createRemovePageRightKeyMapping() {
        return new KeyMapping("key.scholar.remove_page_right",
              KeyConflictContext.GUI,
              KeyModifier.ALT,
              InputConstants.Type.KEYSYM.m_84895_(InputConstants.f_166334_),
              "key.scholar.categories.scholar");
    }

    public static boolean matchesWithModifiers(KeyMapping keyMapping, int keyCode, int scancode, int modifiers) {
        return keyMapping.m_90832_(keyCode, scancode) && keyMapping.isConflictContextAndModifierActive();
    }
}
