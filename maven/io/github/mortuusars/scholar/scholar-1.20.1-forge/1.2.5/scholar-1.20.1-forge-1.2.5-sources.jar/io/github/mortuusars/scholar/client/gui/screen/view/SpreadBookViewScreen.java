package io.github.mortuusars.scholar.client.gui.screen.view;

import com.mojang.datafixers.util.Pair;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.ScholarClient;
import io.github.mortuusars.scholar.client.gui.screen.SpreadBookScreen;
import io.github.mortuusars.scholar.client.util.FileDialogs;
import io.github.mortuusars.scholar.client.util.RenderUtil;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.*;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.IntStream;

public abstract class SpreadBookViewScreen extends SpreadBookScreen {
    protected BookViewAccess bookAccess;
    protected Pair<List<FormattedCharSequence>, List<FormattedCharSequence>> cachedPageComponents;
    protected int cachedSpread;

    protected ImageButton exportBookButton;

    public SpreadBookViewScreen(BookViewAccess bookAccess, int bookColor) {
        super(bookColor);
        this.bookAccess = bookAccess;
        this.cachedPageComponents = Pair.of(Collections.emptyList(), Collections.emptyList());
        this.cachedSpread = -1;
    }

    @Override
    public boolean isGolden() {
        return getBookAccess().isGolden();
    }

    @Override
    protected void createWidgets() {
        super.createWidgets();
        exportBookButton = new ImageButton(leftPos + 297, topPos + 16, 18, 18, 369, 0,
              18, TEXTURE, 512, 512,
              b -> exportBook(!Screen.m_96638_()), Component.m_237115_("gui.scholar.export_book"));
        exportBookButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.scholar.export_book")
              .m_7220_(ScholarClient.KeyMappings.componentForTooltip(ScholarClient.KeyMappings.exportBook))
              .m_7220_(CommonComponents.f_178388_)
              .m_7220_(Component.m_237115_("gui.scholar.export_book.tooltip"))));
        m_142416_(exportBookButton);
    }

    @Override
    protected void updateButtons() {
        super.updateButtons();
        exportBookButton.f_93624_ = isToolsVisible();
        exportBookButton.f_93623_ = IntStream.range(0, getBookAccess().getPageCount())
              .mapToObj(getBookAccess()::getPage)
              .anyMatch(text -> !text.getString().isEmpty());
    }

    public BookViewAccess getBookAccess() {
        return bookAccess;
    }

    public void setBookAccess(BookViewAccess bookViewAccess) {
        this.bookAccess = bookViewAccess;
        this.currentSpread = Mth.m_14045_(this.currentSpread, 0, getSpreadCount());
        this.cachedSpread = -1; // Forces cache update
    }

    @Override
    public int getPageCount() {
        return getBookAccess().getPageCount();
    }

    @Override
    public int getLastPage() {
        return Math.max(getPageCount() - 1, 0);
    }

    @Override
    protected int getFirstPageWithContent() {
        for (int i = 0; i < getPageCount(); i++) {
            if (!getBookAccess().getPage(i).getString().isEmpty()) {
                return i;
            }
        }
        return 0;
    }

    @Override
    protected int getLastPageWithContent() {
        for (int i = getPageCount() - 1; i >= 0; i--) {
            if (!getBookAccess().getPage(i).getString().isEmpty()) {
                return i;
            }
        }
        return 0;
    }

    @Override
    public boolean setPage(int pageIndex) {
        if (super.setPage(pageIndex)) {
            this.cachedSpread = -1;
            return true;
        }
        return false;
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();

        m_280273_(guiGraphics);
        renderBook(guiGraphics, mouseX, mouseY, partialTick);
        renderPageNumbers(guiGraphics, mouseX, mouseY, partialTick, currentSpread);
        renderTools(guiGraphics, mouseX, mouseY, partialTick);

        updateAndCacheContentsIfNeeded();

        renderPageContents(guiGraphics, cachedPageComponents.getFirst(), leftPos + TEXT_LEFT_X, topPos + TEXT_Y);
        renderPageContents(guiGraphics, cachedPageComponents.getSecond(), leftPos + TEXT_RIGHT_X, topPos + TEXT_Y);

        Style style = getClickedComponentStyleAt(mouseX, mouseY);
        if (style != null) {
            guiGraphics.m_280304_(f_96547_, style, mouseX, mouseY);
        }

        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    protected void renderBook(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.renderBook(guiGraphics, mouseX, mouseY, partialTick);
        if (isToolsVisible()) {
            RenderUtil.withColorMultiplied(bookColor, () -> {
                // Export button BG
                guiGraphics.m_280163_(TEXTURE, leftPos + 295, topPos + 14, 0, 388, 23, 24, 512, 512);
            });
        }
    }

    protected void updateAndCacheContentsIfNeeded() {
        if (cachedSpread != currentSpread) {
            FormattedText leftFormattedText = getBookAccess().getPage(currentSpread * 2);
            FormattedText rightFormattedText = getBookAccess().getPageCount() > currentSpread * 2 + 1 ?
                  getBookAccess().getPage(currentSpread * 2 + 1) : FormattedText.f_130760_;

            cachedPageComponents = Pair.of(
                  f_96547_.m_92923_(leftFormattedText, TEXT_WIDTH),
                  f_96547_.m_92923_(rightFormattedText, TEXT_WIDTH));

            cachedSpread = currentSpread;
        }
    }

    protected void renderPageContents(GuiGraphics guiGraphics, List<FormattedCharSequence> lines, int x, int y) {
        int maxLines = Math.min(TEXT_HEIGHT / f_96547_.f_92710_, lines.size());
        for (int i = 0; i < maxLines; ++i) {
            FormattedCharSequence text = lines.get(i);
            guiGraphics.m_280649_(f_96547_, text, x, y + i * f_96547_.f_92710_, textColor, false);
        }
    }

    // --

    public boolean m_6375_(double x, double y, int button) {
        if (button == 0) {
            Style style = this.getClickedComponentStyleAt(x, y);
            if (style != null && this.m_5561_(style)) {
                return true;
            }
        }

        return super.m_6375_(x, y, button);
    }

    public boolean m_5561_(Style style) {
        if (style == null)
            return false;

        ClickEvent clickEvent = style.m_131182_();
        if (clickEvent == null)
            return false;

        if (clickEvent.m_130622_() == ClickEvent.Action.CHANGE_PAGE) {
            String pageNumber = clickEvent.m_130623_();

            try {
                int pageIndex = Integer.parseInt(pageNumber) - 1;
                boolean pageChanged = this.setPage(pageIndex);
                if (pageChanged) {
                    playPageTurnSound();
                }
                return pageChanged;
            } catch (Exception var5) {
                return false;
            }
        } else {
            boolean handled = super.m_5561_(style);
            if (handled && clickEvent.m_130622_() == ClickEvent.Action.RUN_COMMAND) {
                this.m_7379_();
            }

            return handled;
        }
    }

    @Nullable
    public Style getClickedComponentStyleAt(double mouseX, double mouseY) {
        if (mouseY < topPos + TEXT_Y || mouseY >= topPos + TEXT_Y + TEXT_HEIGHT)
            return null;

        boolean isOverRightPage;
        if (mouseX >= leftPos + TEXT_RIGHT_X && mouseX < leftPos + TEXT_RIGHT_X + TEXT_WIDTH) {
            isOverRightPage = true;
        } else if (mouseX >= leftPos + TEXT_LEFT_X && mouseX < leftPos + TEXT_LEFT_X + TEXT_WIDTH) {
            isOverRightPage = false;
        } else {
            return null;
        }

        List<FormattedCharSequence> pageContents = isOverRightPage ? this.cachedPageComponents.getSecond() : this.cachedPageComponents.getFirst();

        if (pageContents.isEmpty()) {
            return null;
        }

        int x = (int) mouseX - (leftPos + (isOverRightPage ? TEXT_RIGHT_X : TEXT_LEFT_X));
        int y = (int) mouseY - (topPos + TEXT_Y);

        int linesCount = Math.min(TEXT_HEIGHT / f_96547_.f_92710_, pageContents.size());
        if (y < f_96547_.f_92710_ * linesCount + linesCount) {
            int clickedLine = y / f_96547_.f_92710_;
            if (clickedLine >= 0 && clickedLine < pageContents.size()) {
                FormattedCharSequence text = pageContents.get(clickedLine);
                return f_96547_.m_92865_().m_92338_(text, x);
            }

            return null;
        }

        return null;
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (ScholarClient.KeyMappings.exportBook.m_90832_(keyCode, scanCode)) {
            playButtonClickSound();
            exportBook(!Screen.m_96638_());
            return true;
        }

        return super.m_7933_(keyCode, scanCode, modifiers);
    }

    // --

    public void exportBook(boolean withFormatting) {
        List<String> pages = new ArrayList<>();
        for (int i = 0; i < getBookAccess().getPageCount(); i++) {
            String text = getBookAccess().getPage(i).getString();
            pages.add(text);
        }

        String content = withFormatting
              ? String.join("\f", pages)
              : ChatFormatting.m_126649_(String.join("\f", pages));

        CompletableFuture.runAsync(() -> {
            String defaultDirectory = Minecraft.m_91087_().f_91069_.toPath().toAbsolutePath().normalize().toString();
            if (!defaultDirectory.endsWith(File.separator)) {
                defaultDirectory = defaultDirectory + File.separator;
            }
            String title = Component.m_237115_("gui.scholar.export_book").getString();

            FileDialogs.saveFile(defaultDirectory, title, "Text Files (.txt)", "*.txt").ifPresent(filePath -> {
                try {
                    Files.writeString(Path.of(filePath), content, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                    MutableComponent filePathComponent = Component.m_237113_(filePath).m_130948_(Style.f_131099_
                          .m_131162_(true)
                          .m_131142_(new ClickEvent(ClickEvent.Action.OPEN_FILE, filePath)));
                    Minecraft.m_91087_().execute(() -> player.m_5661_(
                          Component.m_237115_("gui.scholar.export_book.success")
                                .m_7220_(filePathComponent), false));
                } catch (IOException e) {
                    Minecraft.m_91087_().execute(() -> player.m_5661_(
                          Component.m_237115_("gui.scholar.export_book.failure"), false));
                    Scholar.LOGGER.error("Failed to export book: ", e);
                }
            });
        }).exceptionally(e -> {
            Minecraft.m_91087_().execute(() -> player.m_5661_(
                  Component.m_237115_("gui.scholar.export_book.failure"), false));
            Scholar.LOGGER.error("Failed to export book: ", e);
            return null;
        });
    }
}