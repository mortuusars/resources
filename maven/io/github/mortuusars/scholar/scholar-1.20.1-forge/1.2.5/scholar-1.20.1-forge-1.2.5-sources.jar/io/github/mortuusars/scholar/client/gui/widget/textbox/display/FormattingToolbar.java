package io.github.mortuusars.scholar.client.gui.widget.textbox.display;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.client.gui.widget.textbox.TextBox;
import io.github.mortuusars.scholar.client.gui.widget.textbox.text.Formatting;
import io.github.mortuusars.scholar.client.util.Pos2i;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public class FormattingToolbar {
    public static final ResourceLocation TEXTURE = Scholar.resource("textures/gui/formatting_toolbar.png");

    public static final Map<Character, String> HOTKEYS = new HashMap<>();

    protected final TextBox textBox;
    protected Positioner positioner = Positioner.ABOVE_SELECTION;
    protected int width, height, x, y;
    protected boolean visible = true;
    protected boolean shouldUpdate = true;

    protected final List<FormattingButton> buttons = new ArrayList<>();

    static {
        HOTKEYS.put(Formatting.Format.OBFUSCATED.getChar(), "Ctrl+K");
        HOTKEYS.put(Formatting.Format.BOLD.getChar(), "Ctrl+L");
        HOTKEYS.put(Formatting.Format.STRIKETHROUGH.getChar(), "Ctrl+M");
        HOTKEYS.put(Formatting.Format.UNDERLINE.getChar(), "Ctrl+N");
        HOTKEYS.put(Formatting.Format.ITALIC.getChar(), "Ctrl+O");
        HOTKEYS.put(Formatting.RESET.getChar(), "Ctrl+R");

        HOTKEYS.put(Formatting.Color.BLACK.getChar(), "Ctrl+1");
        HOTKEYS.put(Formatting.Color.DARK_BLUE.getChar(), "Ctrl+2");
        HOTKEYS.put(Formatting.Color.DARK_GREEN.getChar(), "Ctrl+3");
        HOTKEYS.put(Formatting.Color.DARK_AQUA.getChar(), "Ctrl+4");
        HOTKEYS.put(Formatting.Color.DARK_RED.getChar(), "Ctrl+5");
        HOTKEYS.put(Formatting.Color.DARK_PURPLE.getChar(), "Ctrl+6");
        HOTKEYS.put(Formatting.Color.GOLD.getChar(), "Ctrl+7");
        HOTKEYS.put(Formatting.Color.GRAY.getChar(), "Ctrl+8");
        HOTKEYS.put(Formatting.Color.DARK_GRAY.getChar(), "Ctrl+Shift+1");
        HOTKEYS.put(Formatting.Color.BLUE.getChar(), "Ctrl+Shift+2");
        HOTKEYS.put(Formatting.Color.GREEN.getChar(), "Ctrl+Shift+3");
        HOTKEYS.put(Formatting.Color.AQUA.getChar(), "Ctrl+Shift+4");
        HOTKEYS.put(Formatting.Color.RED.getChar(), "Ctrl+Shift+5");
        HOTKEYS.put(Formatting.Color.LIGHT_PURPLE.getChar(), "Ctrl+Shift+6");
        HOTKEYS.put(Formatting.Color.YELLOW.getChar(), "Ctrl+Shift+7");
        HOTKEYS.put(Formatting.Color.WHITE.getChar(), "Ctrl+Shift+8");
    }

    public FormattingToolbar(TextBox textBox) {
        this.textBox = textBox;
        setup();
    }

    protected void setup() {
        buttons.clear();

        int x = 0;

        buttons.add(new FormattingButton(Formatting.Format.BOLD, new Rect2i(x, 0, 12, 15), new Pos2i(x, 0)));
        x += 11;
        buttons.add(new FormattingButton(Formatting.Format.ITALIC, new Rect2i(x, 0, 12, 15), new Pos2i(x, 0)));
        x += 11;
        buttons.add(new FormattingButton(Formatting.Format.UNDERLINE, new Rect2i(x, 0, 12, 15), new Pos2i(x, 0)));
        x += 11;
        buttons.add(new FormattingButton(Formatting.Format.STRIKETHROUGH, new Rect2i(x, 0, 12, 15), new Pos2i(x, 0)));
        x += 11;
        buttons.add(new FormattingButton(Formatting.Format.OBFUSCATED, new Rect2i(x, 0, 12, 15), new Pos2i(x, 0)));
        x += 12;

        buttons.add(new FormattingButton(Formatting.RESET, new Rect2i(x - 8, -13, 19, 28), new Pos2i(x, 0)));

        x += 11;

        for (Formatting.Color color : Arrays.stream(Formatting.Color.values()).limit(8).toList()) {
            buttons.add(new FormattingButton(color, new Rect2i(x, 0, 7, 7), new Pos2i(x + 8, 0)));
            x += 6;
        }

        x += 1;

        for (Formatting.Color color : Arrays.stream(Formatting.Color.values()).skip(8).toList()) {
            buttons.add(new FormattingButton(color, new Rect2i(x - 49, 6, 7, 9), new Pos2i(x + 8, 0)));
            x += 6;
        }

        width = buttons.stream().mapToInt(button -> button.area().m_110085_() + button.area.m_110090_()).max().orElse(0);
        height = buttons.stream().mapToInt(button -> button.area().m_110086_() + button.area.m_110091_()).max().orElse(0);
    }

    // --

    public TextBox getTextBox() {
        return textBox;
    }

    public Positioner getPositioner() {
        return positioner;
    }

    public FormattingToolbar setPositioner(Positioner positioner) {
        this.positioner = positioner;
        return this;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public boolean isVisible() {
        return visible;
    }

    public FormattingToolbar setVisible(boolean visible) {
        this.visible = visible;
        return this;
    }

    // --

    public boolean shouldUpdate() {
        return shouldUpdate;
    }

    public void scheduleUpdate() {
        shouldUpdate = true;
    }

    public void update() {
        Pos2i pos = positioner.position(this, getTextBox());
        x = pos.x;
        y = pos.y;

        for (FormattingButton button : buttons) {
            if (button.formatting() == Formatting.RESET) continue;
            button.highlighted = getTextBox().getEditor().getSelectedSpan().stream()
                    .allMatch(c -> c.hasFormatting(button.formatting()));
        }

        this.shouldUpdate = false;
    }

    // -- Render

    public boolean shouldShow() {
        return getTextBox().m_93696_() && getTextBox().getEditor().isSelecting();
    }

    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (!isVisible() || !shouldShow()) return;

        guiGraphics.m_280168_().m_85836_();
        guiGraphics.m_280168_().m_252880_(0, 0, 500);

        @Nullable FormattingButton hoveredButton = null;

        for (FormattingButton button : buttons) {
            int vOffset = 0;
            if (button.disabled()) {
                vOffset = button.area.m_110091_() * 2;
            } else if (button.highlighted()) {
                vOffset = button.area.m_110091_();
            }

            if (hoveredButton == null && button.isHovering(mouseX - x, mouseY - y)) {
                hoveredButton = button;

                if (!button.disabled()) {
                    vOffset = button.area.m_110091_();
                }
            }

            guiGraphics.m_280218_(TEXTURE, x + button.area.m_110085_(), y + button.area.m_110086_(),
                    button.uv.x, button.uv.y + vOffset, button.area.m_110090_(), button.area.m_110091_());
        }

        if (hoveredButton != null) {
            MutableComponent component = Component.m_237115_(
                            "gui.scholar.formatting." + hoveredButton.formatting.getName())
                    .m_130946_(" §8" + HOTKEYS.getOrDefault(hoveredButton.formatting.getChar(), ""));
            guiGraphics.m_280557_(Minecraft.m_91087_().f_91062_, component, mouseX, mouseY + 20);
        }

        guiGraphics.m_280168_().m_85849_();
    }

    // -- Input

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return false;
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (isVisible() && shouldShow() && button == InputConstants.f_166347_) {
            for (FormattingButton formattingButton : buttons) {
                if (formattingButton.isHovering((int) (mouseX - x), (int) (mouseY - y))) {
                    Minecraft.m_91087_().m_91106_().m_120367_(
                            SimpleSoundInstance.m_119755_(SoundEvents.f_12490_.m_203334_(), 1, 0.1f));

                    if (getTextBox().getEditor().applyFormatting(Formatting.of(formattingButton.formatting()))) {
                        SoundEvent sound = formattingButton.formatting().isColor()
                              ? Scholar.SoundEvents.INK.get()
                              : Scholar.SoundEvents.SCRIBBLE.get();
                        Minecraft.m_91087_().m_91106_().m_120367_(SimpleSoundInstance.m_119755_(sound, 1, 0.3f));
                    }

                    return true;
                }
            }
        }

        return false;
    }

    public interface Positioner {
        Pos2i position(FormattingToolbar toolbar, TextBox textBox);

        Positioner ABOVE_SELECTION = (toolbar, textBox) -> {
            int selectionStartY = textBox.getDisplayCache()
                    .getSelection()
                    .stream()
                    .mapToInt(Rect2i::m_110086_)
                    .min()
                    .orElse(0);

            int x = textBox.m_252754_() + HorizontalAlignment.CENTER.align(textBox.m_5711_(), toolbar.getWidth());
            int y = textBox.m_252907_() + selectionStartY - textBox.getFont().f_92710_ - toolbar.getHeight();
            return new Pos2i(x, y);
        };
    }

    public static class FormattingButton {
        private final Formatting.Type formatting;
        private final Rect2i area;
        private final Pos2i uv;
        private boolean disabled;
        private boolean highlighted;

        public FormattingButton(Formatting.Type formatting, Rect2i area, Pos2i uv) {
            this.formatting = formatting;
            this.area = area;
            this.uv = uv;
        }

        public Formatting.Type formatting() {
            return formatting;
        }

        public Rect2i area() {
            return area;
        }

        public Pos2i uv() {
            return uv;
        }

        public boolean disabled() {
            return disabled;
        }

        public boolean highlighted() {
            return highlighted;
        }

        public boolean isHovering(int mouseX, int mouseY) {
            return (mouseX >= area.m_110085_() && mouseX < area.m_110085_() + area.m_110090_())
                    && (mouseY >= area.m_110086_() && mouseY < area.m_110086_() + area.m_110091_());
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) return true;
            if (obj == null || obj.getClass() != this.getClass()) return false;
            var that = (FormattingButton) obj;
            return Objects.equals(this.formatting, that.formatting) &&
                    Objects.equals(this.area, that.area) &&
                    Objects.equals(this.uv, that.uv) &&
                    this.disabled == that.disabled &&
                    this.highlighted == that.highlighted;
        }

        @Override
        public int hashCode() {
            return Objects.hash(formatting, area, uv, disabled, highlighted);
        }

        @Override
        public String toString() {
            return "FormattingButton[" +
                    "formatting=" + formatting + ", " +
                    "area=" + area + ", " +
                    "uv=" + uv + ", " +
                    "disabled=" + disabled + ", " +
                    "highlighted=" + highlighted + ']';
        }
    }
}
