package io.github.mortuusars.scholar.mixin;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookColor;
import net.minecraft.core.RegistryAccess;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.WrittenBookItem;
import net.minecraft.world.item.crafting.BookCloningRecipe;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BookCloningRecipe.class)
public class BookCloningRecipeMixin {
    // 'BookCloningRecipe#matches' may need to be changed as well. But it seems to work fine without it.

    /**
     * Purpose of this mixin is to disallow writable books of different colors to be in a craft.
     * And set the color of a result book to color of writable book.
     * -
     * This mixin basically overrides whole method which may cause compatibility issues. But it would require more mixins to change it in specific parts.
     * Mods that modify this recipe should be very rare anyway.
     */
    @Inject(method = "assemble(Lnet/minecraft/world/inventory/CraftingContainer;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/world/item/ItemStack;",
          at = @At("HEAD"), cancellable = true)
    private void onAssemble(CraftingContainer container, RegistryAccess registryAccess, CallbackInfoReturnable<ItemStack> cir) {
        ItemStack inputBook = ItemStack.f_41583_;
        @Nullable Integer resultColor = null;
        int copies = 0;

        for (int slot = 0; slot < container.m_6643_(); ++slot) {
            ItemStack stack = container.m_8020_(slot);
            if (stack.m_41619_()) {
                continue;
            }

            if (stack.m_150930_(Items.f_42615_)) {
                if (!inputBook.m_41619_()) {
                    cir.setReturnValue(ItemStack.f_41583_);
                    return; // multiple written books as inputs are not allowed
                }

                inputBook = stack;
                continue;
            }

            if (stack.m_150930_(Items.f_42614_)) {
                // Since result book will get writable book color - books of different colors are not allowed.
                int color = BookColor.of(stack);
                if (resultColor == null) {
                    resultColor = color;
                }
                else if (resultColor != color) {
                    cir.setReturnValue(ItemStack.f_41583_);
                    return;
                }

                ++copies;
                continue;
            }
            cir.setReturnValue(ItemStack.f_41583_);
            return;
        }

        if (inputBook.m_41619_() || inputBook.m_41783_() == null || copies < 1 || WrittenBookItem.m_43473_(inputBook) >= 2) {
            cir.setReturnValue(ItemStack.f_41583_);
            return; // Cannot be copied
        }

        ItemStack resultStack = new ItemStack(Items.f_42615_, copies);
        CompoundTag inputBookTag = inputBook.m_41783_().m_6426_();
        inputBookTag.m_128405_("generation", WrittenBookItem.m_43473_(inputBook) + 1);
        inputBookTag.m_128473_(Scholar.NBT.BOOK_GOLDEN);
        resultStack.m_41751_(inputBookTag);
        if (resultColor != BookColor.DEFAULT) {
            BookColor.set(resultStack, resultColor);
        }
        cir.setReturnValue(resultStack);
    }
}
