package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.PacketDirection;
import io.github.mortuusars.scholar.network.packet.Packet;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.WritableBookItem;
import net.minecraft.world.item.WrittenBookItem;

public record StartedReadingInHandC2SP(int slot) implements Packet {
    public static final ResourceLocation ID = Scholar.resource("started_reading_in_hand");

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    @Override
    public FriendlyByteBuf toBuffer(FriendlyByteBuf buffer) {
        buffer.writeInt(slot);
        return buffer;
    }

    public static StartedReadingInHandC2SP fromBuffer(FriendlyByteBuf buffer) {
        return new StartedReadingInHandC2SP(buffer.readInt());
    }

    @Override
    public boolean handle(PacketDirection direction, Player player) {
        if (!(player instanceof ServerPlayer serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (Inventory.m_36045_(slot) || slot == Inventory.f_150066_) {
            ItemStack stack = serverPlayer.m_150109_().m_8020_(slot);
            if (stack.m_41720_() instanceof WritableBookItem || stack.m_41720_() instanceof WrittenBookItem) {
                stack.m_41784_().m_128379_(Scholar.NBT.BOOK_OPEN, true);
                serverPlayer.m_9236_().m_6269_(player, player, SoundEvents.f_11713_, SoundSource.PLAYERS, 1, 1);
            }
            return true;
        }

        return true;
    }
}
