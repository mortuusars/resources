package io.github.mortuusars.scholar;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.item.Items;

import java.util.function.Consumer;

public class ScholarClient {
    public static void init() {
        registerItemModelProperties();
    }

    private static void registerItemModelProperties() {
        ItemProperties.m_174570_(Items.f_42614_, Scholar.resource("book_golden"),
              (stack, level, entity, seed) -> stack.m_41783_() != null && stack.m_41783_().m_128471_(Scholar.NBT.BOOK_GOLDEN) ? 1 : 0);
        ItemProperties.m_174570_(Items.f_42615_, Scholar.resource("book_golden"),
              (stack, level, entity, seed) -> stack.m_41783_() != null && stack.m_41783_().m_128471_(Scholar.NBT.BOOK_GOLDEN) ? 1 : 0);
    }

    public static class KeyMappings {
        public static KeyMapping toggleBookTools = new KeyMapping("key.scholar.toggle_book_tools",
              InputConstants.f_166263_, "key.scholar.categories.scholar");
        public static KeyMapping importBook = new KeyMapping("key.scholar.import_book",
              InputConstants.f_166268_, "key.scholar.categories.scholar");
        public static KeyMapping exportBook = new KeyMapping("key.scholar.export_book",
              InputConstants.f_166269_, "key.scholar.categories.scholar");
        public static KeyMapping insertEmptyPageLeft = PlatformHelperClient.createInsertEmptyPageLeftKeyMapping();
        public static KeyMapping removePageLeft = PlatformHelperClient.createRemovePageLeftKeyMapping();
        public static KeyMapping insertEmptyPageRight = PlatformHelperClient.createInsertEmptyPageRightKeyMapping();
        public static KeyMapping removePageRight = PlatformHelperClient.createRemovePageRightKeyMapping();

        public static void register(Consumer<KeyMapping> registerFunction) {
            registerFunction.accept(toggleBookTools);
            registerFunction.accept(importBook);
            registerFunction.accept(exportBook);
            registerFunction.accept(insertEmptyPageLeft);
            registerFunction.accept(removePageLeft);
            registerFunction.accept(insertEmptyPageRight);
            registerFunction.accept(removePageRight);
        }

        public static MutableComponent componentForTooltip(KeyMapping keyMapping) {
            return componentForTooltip(keyMapping, ChatFormatting.DARK_GRAY);
        }

        public static MutableComponent componentForTooltip(KeyMapping keyMapping, ChatFormatting formatting) {
            return Component.m_237113_(" " + keyMapping.m_90863_().getString()).m_130940_(formatting);
        }
    }
}
