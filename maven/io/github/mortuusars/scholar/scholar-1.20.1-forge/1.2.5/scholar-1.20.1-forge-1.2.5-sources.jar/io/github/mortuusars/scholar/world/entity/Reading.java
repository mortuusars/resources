package io.github.mortuusars.scholar.world.entity;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.item.WritableBookItem;
import net.minecraft.world.item.WrittenBookItem;
import org.jetbrains.annotations.Nullable;

public class Reading {
    public static @Nullable InteractionHand getOpenedBookHand(LivingEntity entity) {
        if (!Config.Common.BOOK_READING_ANIMATION.get()) return null;
        if (entity instanceof EnderMan) return null; // They cannot hold items as other mobs do.
        if (entity.m_21205_().m_41783_() != null && entity.m_21205_().m_41783_().m_128471_(Scholar.NBT.BOOK_OPEN)) return InteractionHand.MAIN_HAND;
        if (entity.m_21206_().m_41783_() != null && entity.m_21206_().m_41783_().m_128471_(Scholar.NBT.BOOK_OPEN)) return InteractionHand.OFF_HAND;
        return null;
    }

    public static void closeAllBooksInInventory(ServerPlayer player) {
        player.m_150109_().f_35974_.forEach(stack -> {
            if (stack.m_41783_() != null && (stack.m_41720_() instanceof WritableBookItem || stack.m_41720_() instanceof WrittenBookItem)) {
                stack.m_41783_().m_128473_(Scholar.NBT.BOOK_OPEN);
            }
        });
    }
}
