package io.github.mortuusars.scholar.mixin.literate_mobs;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.world.entity.Reading;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(RandomStrollGoal.class)
public abstract class RandomStrollGoalMixin extends Goal {
    @Shadow
    @Final
    protected PathfinderMob mob;

    @Inject(method = "canUse", at = @At("HEAD"), cancellable = true)
    private void onCanUse(CallbackInfoReturnable<Boolean> cir) {
        if (mob.m_6095_().m_204039_(Scholar.Tags.EntityTypes.LITERATE)
              && Reading.getOpenedBookHand(mob) != null
              && mob.m_217043_().m_188501_() > 0.05) {
            cir.setReturnValue(false); // Prevent moving when reading
        }
    }
}
