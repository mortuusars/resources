package io.github.mortuusars.scholar.client.gui.screen.view;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.menu.LecternSpreadMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.MenuAccess;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerListener;
import net.minecraft.world.inventory.LecternMenu;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

public class LecternSpreadBookViewScreen extends SpreadBookViewScreen implements MenuAccess<LecternSpreadMenu> {
    protected final LecternSpreadMenu menu;
    protected final ContainerListener listener = new ContainerListener() {
        @Override
        public void m_7934_(AbstractContainerMenu menu, int dataSlotIndex, ItemStack stack) {
            LecternSpreadBookViewScreen.this.bookChanged(stack);
        }

        @Override
        public void m_142153_(AbstractContainerMenu menu, int dataSlotIndex, int pageIndex) {
            if (dataSlotIndex == 0) {
                LecternSpreadBookViewScreen.this.updatePage(pageIndex);
            }
        }
    };

    public LecternSpreadBookViewScreen(LecternSpreadMenu lecternSpreadMenu, Inventory inventory, Component component) {
        super(BookViewAccess.fromItem(lecternSpreadMenu.m_39835_()), BookColor.of(lecternSpreadMenu.m_39835_()));
        this.menu = lecternSpreadMenu;
    }

    @Override
    public @NotNull LecternSpreadMenu m_6262_() {
        return menu;
    }

    @Override
    protected void m_7856_() {
        super.m_7856_();
        m_6262_().m_38893_(listener);
    }

    @Override
    protected void createBottomButtons() {
        if (player.m_36326_()) {
            if (Config.Common.BOOK_SCREEN_SHOW_DONE_BUTTON.get()) {
                this.m_142416_(Button.m_253074_(CommonComponents.f_130655_,
                        button -> this.m_7379_()).m_252987_(this.f_96543_ / 2 - 100, topPos + BOOK_HEIGHT + 12, 98, 20).m_253136_());
                this.m_142416_(Button.m_253074_(Component.m_237115_("lectern.take_book"),
                        button -> this.sendButtonClick(3)).m_252987_(this.f_96543_ / 2 + 2, topPos + BOOK_HEIGHT + 12, 98, 20).m_253136_());
            } else {
                this.m_142416_(Button.m_253074_(Component.m_237115_("lectern.take_book"),
                        (button) -> this.sendButtonClick(3)).m_252987_(this.f_96543_ / 2 - 60, topPos + BOOK_HEIGHT + 12, 120, 20).m_253136_());
            }
        } else {
            super.createBottomButtons();
        }
    }

    @Override
    protected boolean pageBack() {
        this.sendButtonClick(LecternMenu.f_150606_);
        return true;
    }

    @Override
    protected boolean pageForward() {
        this.sendButtonClick(LecternMenu.f_150607_);
        return true;
    }

    @Override
    public boolean setPage(int pageIndex) {
        if (pageIndex != m_6262_().m_39836_()) {
            sendPageIndex(pageIndex);
            return true;
        }
        return false;
    }

    protected void bookChanged(ItemStack stack) {
        this.setBookAccess(BookViewAccess.fromItem(stack));
    }

    protected void updatePage(int pageIndex) {
        super.setPage(pageIndex);
    }

    // --

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
        renderPageTooltip(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void renderLeftPageNumber(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread, int color) {
        if (isRightPage(m_6262_().m_39836_()) && isHoveringOverLeftPageNumber(mouseX, mouseY)) {
            color = textColor;
        }
        super.renderLeftPageNumber(guiGraphics, mouseX, mouseY, partialTick, currentSpread, color);
    }

    @Override
    protected void renderRightPageNumber(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread, int color) {
        int page = m_6262_().m_39836_();
        if (page < getPageCount() - 1 && isLeftPage(page) && isHoveringOverRightPageNumber(mouseX, mouseY)) {
            color = textColor;
        }
        super.renderRightPageNumber(guiGraphics, mouseX, mouseY, partialTick, currentSpread, color);
    }

    protected void renderPageTooltip(GuiGraphics guiGraphics, int x, int y) {
        int page = m_6262_().m_39836_();
        if ((isRightPage(page) && isHoveringOverLeftPageNumber(x, y))
                || (page < getPageCount() - 1 && isLeftPage(page) && isHoveringOverRightPageNumber(x, y))) {
            guiGraphics.m_280557_(f_96547_, Component.m_237115_("gui.scholar.lectern.set_current_page"), x, y);
        }
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        int page = m_6262_().m_39836_();
        if (isRightPage(page) && isHoveringOverLeftPageNumber(mouseX, mouseY)) {
            sendButtonClick(LecternMenu.f_150609_ + page - 1);
        } else if (page < getPageCount() - 1 && isLeftPage(page) && isHoveringOverRightPageNumber(mouseX, mouseY)) {
            sendButtonClick(LecternMenu.f_150609_ + page + 1);
        }

        return super.m_6375_(mouseX, mouseY, button);
    }

    // --

    @Override
    public void m_7861_() {
        super.m_7861_();
        m_6262_().m_38943_(listener);
    }

    @Override
    public void m_7379_() {
        player.m_6915_();
        super.m_7379_();
    }

    // --

    protected void sendPageIndex(int pageIndex) {
        sendButtonClick(100 + pageIndex);
    }

    protected void sendButtonClick(int buttonId) {
        if (Minecraft.m_91087_().f_91072_ != null) {
            Minecraft.m_91087_().f_91072_.m_105208_(this.menu.f_38840_, buttonId);
        }
    }
}
