package io.github.mortuusars.scholar.client.gui.widget.textbox.text;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.mortuusars.scholar.Scholar;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.StringSplitter;
import net.minecraft.client.gui.Font;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class FormattedStringEditor {
    protected FormattedString string = new FormattedString();
    protected int cursorPos;
    protected int selectionAnchor;
    protected Predicate<String> validator;

    public FormattedStringEditor(Predicate<String> validator) {
        this.validator = validator;
    }

    public FormattedStringEditor(Supplier<Predicate<String>> stringValidator) {
        this.validator = str -> stringValidator.get().test(str);
    }

    public FormattedString getString() {
        return string;
    }

    public void setString(FormattedString string) {
        this.string = string;
    }

    public int getCursorPos() {
        return cursorPos;
    }

    public int getSelectionAnchor() {
        return selectionAnchor;
    }

    public Predicate<String> getValidator() {
        return validator;
    }

    public void setValidator(Predicate<String> validator) {
        this.validator = validator;
    }

    // -- String

    public int length() {
        return getString().size();
    }

    public List<Char> getSpan(int start, int end) {
        return getString().subList(start, end);
    }

    public List<Char> getSelectedSpan() {
        return getSpan(getSelectionStart(), getSelectionEnd());
    }

    // -- Cursor

    public boolean isCursorAtStart() {
        return getCursorPos() == 0;
    }

    public boolean isCursorAtEnd() {
        return getCursorPos() == length();
    }

    public void setCursorPos(int index) {
        setCursorPos(index, true);
    }

    public void setCursorPos(int index, boolean keepSelection) {
        cursorPos = clampIndex(index);
        resetSelectionIfNeeded(keepSelection);
    }

    public void setCursorToStart(boolean keepSelection) {
        setCursorPos(0, keepSelection);
    }

    public void setCursorToEnd(boolean keepSelection) {
        setCursorPos(length(), keepSelection);
    }

    public void moveCursorBy(int direction, boolean keepSelection, CursorStep cursorStep) {
        switch (cursorStep) {
            case CHARACTER -> this.moveCursorByChars(direction, keepSelection);
            case WORD -> this.moveCursorByWords(direction, keepSelection);
        }
    }

    public void moveCursorByChars(int direction, boolean keepSelection) {
        if (!keepSelection && isSelecting()) {
            setCursorPos(direction < 0 ? getSelectionStart() : getSelectionEnd(), false);
        } else {
            setCursorPos(getCursorPos() + direction, keepSelection);
        }
    }

    public void moveCursorByWords(int direction, boolean keepSelection) {
        if (!keepSelection && isSelecting()) {
            setCursorPos(direction < 0 ? getSelectionStart() : getSelectionEnd(), false);
        } else {
            setCursorPos(getWordPosition(direction, true), keepSelection);
        }
    }

    public int getWordPosition(int skipCount, boolean includeWhitespace) {
        int i = getCursorPos();

        boolean backwards = skipCount < 0;
        int count = Math.abs(skipCount);

        for (int k = 0; k < count; k++) {
            if (backwards) {
                while (includeWhitespace && i > 0 && isWhitespace(getString().get(i - 1).codepoint())) {
                    i--;
                }
                while (i > 0 && !isWhitespace(getString().get(i - 1).codepoint())) {
                    i--;
                }

            } else {
                int size = getString().size();
                while (i < size && !isWhitespace(getString().get(i).codepoint())) {
                    i++;
                }
                while (includeWhitespace && i < size && isWhitespace(getString().get(i).codepoint())) {
                    i++;
                }
            }
        }

        return i;
    }

    private static boolean isWhitespace(int cp) {
        return cp == ' '
              || cp == '\n';
    }

    public Formatting getFormattingAtCursor() {
        int charBeforeCursor = getCursorPos() - 1;
        if (charBeforeCursor >= 0 && charBeforeCursor < length()) {
            return getString().get(charBeforeCursor).formatting();
        }
        return Formatting.EMPTY;
    }

    // -- Selection

    public boolean isSelecting() {
        return getCursorPos() != getSelectionAnchor();
    }

    public int getSelectionStart() {
        return Math.min(getCursorPos(), getSelectionAnchor());
    }

    public int getSelectionEnd() {
        return Math.max(getCursorPos(), getSelectionAnchor());
    }

    public void setSelectionAnchor(int index) {
        selectionAnchor = clampIndex(index);
    }

    public void setSelectionRange(int start, int end) {
        setSelectionAnchor(start);
        setCursorPos(end, true);
    }

    public void selectWord(int index) {
        setSelectionRange(
              StringSplitter.getWordPosition(getString().toStringWithoutFormatting(), -1, index, false),
              StringSplitter.getWordPosition(getString().toStringWithoutFormatting(), 1, index, false));
    }

    public String getSelectedString(boolean withFormatting) {
        if (!isSelecting()) return "";
        FormattedString selectedString = getString().subString(getSelectionStart(), getSelectionEnd());
        return withFormatting ? selectedString.toString() : selectedString.toStringWithoutFormatting();
    }

    // --

    public boolean keyPressed(KeyEvent event) {
        if (event.isSelectAll()) {
            selectAll();
            return true;
        }
        if (event.key() == InputConstants.KEY_C && event.hasControlDown() && !event.hasAltDown()) {
            copy(!event.hasShiftDown());
            return true;
        }
        if (event.key() == InputConstants.KEY_V && event.hasControlDown() && !event.hasAltDown()) {
            paste(!event.hasShiftDown());
            return true;
        }
        if (event.key() == InputConstants.KEY_X && event.hasControlDown() && !event.hasAltDown()) {
            cut(!event.hasShiftDown());
            return true;
        }
        CursorStep cursorStep = event.hasControlDown() ? CursorStep.WORD : CursorStep.CHARACTER;
        if (event.key() == InputConstants.KEY_BACKSPACE) {
            removeFromCursor(-1, cursorStep);
            return true;
        }
        if (event.key() == InputConstants.KEY_DELETE) {
            removeFromCursor(1, cursorStep);
            return true;
        }
        if (event.key() == InputConstants.KEY_LEFT) {
            moveCursorBy(-1, event.hasShiftDown(), cursorStep);
            return true;
        }
        if (event.key() == InputConstants.KEY_RIGHT) {
            moveCursorBy(1, event.hasShiftDown(), cursorStep);
            return true;
        }
        if (event.key() == InputConstants.KEY_HOME) {
            setCursorToStart(event.hasShiftDown());
            return true;
        }
        if (event.key() == InputConstants.KEY_END) {
            setCursorToEnd(event.hasShiftDown());
            return true;
        }
        if (event.key() == InputConstants.KEY_RETURN || event.key() == InputConstants.KEY_NUMPADENTER) {
            insertTextAtCursor("\n");
            return true;
        }

        @Nullable Formatting formatting = handleFormattingKeys(event);
        if (formatting != null) {
            if (applyFormatting(formatting)) {
                SoundEvent sound = formatting.color() != null
                      ? Scholar.SoundEvents.INK.get()
                      : Scholar.SoundEvents.SCRIBBLE.get();
                Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(sound, 1, 0.3f));
            }
            return true;
        }

        return false;
    }

    protected Formatting handleFormattingKeys(KeyEvent event) {
        if (event.hasControlDown() && !event.hasShiftDown() && !event.hasAltDown()) {
            return switch (event.key()) {
                case InputConstants.KEY_1 -> Formatting.of(Formatting.Color.BLACK);
                case InputConstants.KEY_2 -> Formatting.of(Formatting.Color.DARK_BLUE);
                case InputConstants.KEY_3 -> Formatting.of(Formatting.Color.DARK_GREEN);
                case InputConstants.KEY_4 -> Formatting.of(Formatting.Color.DARK_AQUA);
                case InputConstants.KEY_5 -> Formatting.of(Formatting.Color.DARK_RED);
                case InputConstants.KEY_6 -> Formatting.of(Formatting.Color.DARK_PURPLE);
                case InputConstants.KEY_7 -> Formatting.of(Formatting.Color.GOLD);
                case InputConstants.KEY_8 -> Formatting.of(Formatting.Color.GRAY);
                // --
                case InputConstants.KEY_K -> Formatting.of(Formatting.Format.OBFUSCATED);
                case InputConstants.KEY_L -> Formatting.of(Formatting.Format.BOLD);
                case InputConstants.KEY_M -> Formatting.of(Formatting.Format.STRIKETHROUGH);
                case InputConstants.KEY_N -> Formatting.of(Formatting.Format.UNDERLINE);
                case InputConstants.KEY_O -> Formatting.of(Formatting.Format.ITALIC);
                case InputConstants.KEY_R -> Formatting.EMPTY;
                default -> null;
            };
        }

        if (event.hasControlDown() && event.hasShiftDown() && !event.hasAltDown()) {
            return switch (event.key()) {
                case InputConstants.KEY_1 -> Formatting.of(Formatting.Color.DARK_GRAY);
                case InputConstants.KEY_2 -> Formatting.of(Formatting.Color.BLUE);
                case InputConstants.KEY_3 -> Formatting.of(Formatting.Color.GREEN);
                case InputConstants.KEY_4 -> Formatting.of(Formatting.Color.AQUA);
                case InputConstants.KEY_5 -> Formatting.of(Formatting.Color.RED);
                case InputConstants.KEY_6 -> Formatting.of(Formatting.Color.LIGHT_PURPLE);
                case InputConstants.KEY_7 -> Formatting.of(Formatting.Color.YELLOW);
                case InputConstants.KEY_8 -> Formatting.of(Formatting.Color.WHITE);
                default -> null;
            };
        }

        return null;
    }

    public boolean applyFormatting(Formatting formatting) {
        // Prevents applying bold formatting if the text would overflow available space due to extra width:
        if (formatting.format().contains(Formatting.Format.BOLD)) {
            FormattedString string = new FormattedString(getString().stream().map(c -> new Char(c.codepoint(), c.formatting().copy())).toList());
            List<Char> chars = string.subList(getSelectionStart(), getSelectionEnd());
            chars.replaceAll(c -> c.flipFormatting(formatting));

            if (!validator.test(string.toString())) {
                return false;
            }
        }

        if (isSelecting()) {
            getSelectedSpan().replaceAll(c -> c.flipFormatting(formatting));
        } else if (formatting.isEmpty()) {
            getString().replaceAll(c -> c.withFormatting(Formatting.EMPTY));
        } else {
            return false; // Nothing to format
        }

        return true;
    }

    public boolean charTyped(CharacterEvent event) {
        return event.isAllowedChatCharacter() && insertTextAtCursor(event.codepointAsString());
    }

    public void cut(boolean withFormatting) {
        copy(withFormatting);
        removeSelectedText();
    }

    public void paste(boolean withFormatting) {
        try {
            String text = Minecraft.getInstance().keyboardHandler.getClipboard();
            if (!withFormatting) {
                text = ChatFormatting.stripFormatting(text);
            }
            insertTextAtCursor(Objects.requireNonNull(text).replaceAll("\\r", ""));
        } catch (Exception e) {
            Scholar.LOGGER.error("Text Paste error: ", e);
        }
    }

    public void copy(boolean withFormatting) {
        Minecraft.getInstance().keyboardHandler.setClipboard(getSelectedString(withFormatting));
    }

    public void selectAll() {
        setSelectionAnchor(0);
        setCursorPos(length(), true);
    }

    // --

    public boolean insertTextAtCursor(String text) {
        if (isSelecting()) {
            removeSelectedText();
        }

        FormattedString insertedString = FormattedString.parse(text);
        insertedString.replaceAll(c -> {
            if (!c.hasFormatting()) {
                return c.withFormatting(getFormattingAtCursor());
            }
            return c;
        });

        FormattedString newString = new FormattedString(getString());
        newString.addAll(getCursorPos(), insertedString);

        String string = newString.toStringWithoutFormatting();
        if (validator.test(string)) {
            this.string = newString;
            setCursorPos(getCursorPos() + insertedString.length(), false);
            return true;
        }

        return false;
    }

    public void removeFromCursor(int direction, CursorStep step) {
        switch (step) {
            case CHARACTER: {
                this.removeCharsFromCursor(direction);
                break;
            }
            case WORD: {
                this.removeWordsFromCursor(direction);
            }
        }
    }

    public void removeWordsFromCursor(int direction) {
        int charsCount = StringSplitter.getWordPosition(getString().toStringWithoutFormatting(), direction, this.cursorPos, true);
        this.removeCharsFromCursor(charsCount - this.cursorPos);
    }

    public void removeCharsFromCursor(int direction) {
        String string = getString().toStringWithoutFormatting();
        if (!string.isEmpty()) {
            if (isSelecting()) {
                removeSelectedText();
            } else {
                int cursor = getCursorPos();
                int removePos = cursor + direction;
                int start = clampIndex(Math.min(removePos, cursor));
                int end = clampIndex(Math.max(removePos, cursor));

                getSpan(start, end).clear();
                setCursorPos(start, false);
            }
        }
    }

    public void removeSelectedText() {
        if (!isSelecting()) return;

        int start = getSelectionStart();
        int end = getSelectionEnd();

        getSpan(start, end).clear();
        setCursorPos(start, false);
    }

    // --

    protected void resetSelectionIfNeeded(boolean keepSelection) {
        if (!keepSelection) {
            setSelectionAnchor(getCursorPos());
        }
    }

    protected int clampIndex(int index) {
        return Mth.clamp(index, 0, length());
    }

    public enum CursorStep {
        CHARACTER,
        WORD
    }

    public interface Validator {
        static Predicate<String> fitInDimensions(Font font, int width, int height) {
            return string -> string.length() < 1024 && font.wordWrapHeight(FormattedText.of(string), width) + (string.endsWith("\n") ? font.lineHeight : 0) <= height;
        }
    }
}
