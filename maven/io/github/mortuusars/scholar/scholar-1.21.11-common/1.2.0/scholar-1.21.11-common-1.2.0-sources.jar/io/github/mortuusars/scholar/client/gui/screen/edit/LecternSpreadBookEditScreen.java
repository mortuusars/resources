package io.github.mortuusars.scholar.client.gui.screen.edit;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.book.BookSignature;
import io.github.mortuusars.scholar.client.gui.screen.SpreadBookScreen;
import io.github.mortuusars.scholar.menu.LecternSpreadBookEditMenu;
import io.github.mortuusars.scholar.network.Packets;
import io.github.mortuusars.scholar.network.packet.serverbound.LecternEditBookC2SP;
import io.github.mortuusars.scholar.network.packet.serverbound.SetCustomAuthorOnLecternC2SP;
import io.github.mortuusars.scholar.network.packet.serverbound.SetGoldenSkinOnLecternC2SP;
import net.minecraft.class_11909;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1712;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_3916;
import net.minecraft.class_3936;
import net.minecraft.class_4185;
import net.minecraft.class_5244;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Optional;

public class LecternSpreadBookEditScreen extends SpreadBookEditScreen implements class_3936<LecternSpreadBookEditMenu> {
    protected final LecternSpreadBookEditMenu menu;
    protected final class_1712 listener = new class_1712() {
        @Override
        public void method_7635(class_1703 menu, int dataSlotIndex, class_1799 stack) {
            LecternSpreadBookEditScreen.this.bookChanged(stack);
        }

        @Override
        public void method_7633(class_1703 menu, int dataSlotIndex, int pageIndex) {
            if (dataSlotIndex == 0) {
                LecternSpreadBookEditScreen.this.updatePage(pageIndex);
            }
        }
    };

    public LecternSpreadBookEditScreen(LecternSpreadBookEditMenu lecternSpreadMenu, class_1661 inventory, class_2561 component) {
        super(lecternSpreadMenu.method_17418());
        this.menu = lecternSpreadMenu;
    }

    @Override
    public @NotNull LecternSpreadBookEditMenu method_17577() {
        return menu;
    }

    @Override
    protected void sendGoldenSkinChange(boolean golden) {
        Packets.sendToServer(new SetGoldenSkinOnLecternC2SP(method_17577().getLecternPos(), golden));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        method_17577().method_7596(listener);
    }

    @Override
    protected void createBottomButtons() {
        if (player.method_7294()) {
            if (Config.Common.BOOK_SCREEN_SHOW_DONE_BUTTON.get()) {
                this.method_37063(class_4185.method_46430(class_5244.field_24334,
                        button -> this.method_25419()).method_46434(this.field_22789 / 2 - 100, topPos + SpreadBookScreen.BOOK_HEIGHT + 12, 98, 20).method_46431());
                this.method_37063(class_4185.method_46430(class_2561.method_43471("lectern.take_book"),
                        button -> this.sendButtonClick(3)).method_46434(this.field_22789 / 2 + 2, topPos + SpreadBookScreen.BOOK_HEIGHT + 12, 98, 20).method_46431());
            } else {
                this.method_37063(class_4185.method_46430(class_2561.method_43471("lectern.take_book"),
                        (button) -> this.sendButtonClick(3)).method_46434(this.field_22789 / 2 - 60, topPos + SpreadBookScreen.BOOK_HEIGHT + 12, 120, 20).method_46431());
            }
        } else {
            super.createBottomButtons();
        }
    }

    @Override
    protected boolean pageBack() {
        this.sendButtonClick(class_3916.field_30820);

        getHistory().add(
              () -> this.sendButtonClick(class_3916.field_30820),
              () -> this.sendButtonClick(class_3916.field_30821)
        );

        return true;
    }

    @Override
    protected boolean pageForward() {
        this.sendButtonClick(class_3916.field_30821);

        getHistory().add(
              () -> this.sendButtonClick(class_3916.field_30821),
              () -> this.sendButtonClick(class_3916.field_30820)
        );

        return true;
    }

    protected void bookChanged(class_1799 stack) {
        bookColor = BookColor.of(stack);
        setupPages(stack);
    }

    protected void updatePage(int pageIndex) {
        int newSpreadIndex = pageIndex / 2;
        if (currentSpread != newSpreadIndex) {
            currentSpread = newSpreadIndex;

            // Ensure we have pages to display:
            while (this.pages.size() < (currentSpread + 1) * 2) {
                appendEmptyPage();
            }

            setTextBoxes();
            updateButtons();
        }
        saveChanges(false, null);
    }

    @Override
    protected void sendChanges(@Nullable String title) {
        removeEmptyTrailingPages();
        // Copying 'pages' list to not cause ConcurrentModificationException when packet is encoded:
        Packets.sendToServer(new LecternEditBookC2SP(method_17577().getLecternPos(), new ArrayList<>(pages), Optional.ofNullable(title)));
    }

    @Override
    protected void signBook(BookSignature signature) {
        saveChanges(true, signature.title());
        signature.customAuthor().ifPresent(customAuthor ->
              Packets.sendToServer(new SetCustomAuthorOnLecternC2SP(method_17577().getLecternPos(), customAuthor)));
    }

    // --

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        renderPageTooltip(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void renderLeftPageNumber(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread, int color) {
        if (isRightPage(method_17577().method_17419()) && isHoveringOverLeftPageNumber(mouseX, mouseY)) {
            color = textColor;
        }
        super.renderLeftPageNumber(guiGraphics, mouseX, mouseY, partialTick, currentSpread, color);
    }

    @Override
    protected void renderRightPageNumber(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread, int color) {
        if (isLeftPage(method_17577().method_17419()) && isHoveringOverRightPageNumber(mouseX, mouseY)) {
            color = textColor;
        }
        super.renderRightPageNumber(guiGraphics, mouseX, mouseY, partialTick, currentSpread, color);
    }

    protected void renderPageTooltip(class_332 guiGraphics, int x, int y) {
        int page = method_17577().method_17419();

        if ((isRightPage(page) && isHoveringOverLeftPageNumber(x, y))
                || (isLeftPage(page) && isHoveringOverRightPageNumber(x, y))) {
            guiGraphics.method_51438(field_22793, class_2561.method_43471("gui.scholar.lectern.set_current_page"), x, y);
        }
    }

    @Override
    public boolean method_25402(class_11909 event, boolean isDoubleClick) {
        int page = method_17577().method_17419();
        if (isRightPage(page) && isHoveringOverLeftPageNumber(event.comp_4798(), event.comp_4799())) {
            sendButtonClick(class_3916.field_30823 + page - 1);
        } else if (isLeftPage(page) && isHoveringOverRightPageNumber(event.comp_4798(), event.comp_4799())) {
            sendButtonClick(class_3916.field_30823 + page + 1);
        }

        return super.method_25402(event, isDoubleClick);
    }

    // --

    @Override
    public void method_25395(@Nullable class_364 focused) {
        super.method_25395(focused);
        saveChanges(false, null);
    }

    @Override
    public void method_25432() {
        super.method_25432();
        method_17577().method_7603(listener);
    }

    @Override
    public void method_25419() {
        super.method_25419();
        player.method_7346();
    }

    // --

    protected void sendButtonClick(int buttonId) {
        if (class_310.method_1551().field_1761 != null) {
            saveChanges(false, null);
            class_310.method_1551().field_1761.method_2900(this.menu.field_7763, buttonId);
        }
    }
}
