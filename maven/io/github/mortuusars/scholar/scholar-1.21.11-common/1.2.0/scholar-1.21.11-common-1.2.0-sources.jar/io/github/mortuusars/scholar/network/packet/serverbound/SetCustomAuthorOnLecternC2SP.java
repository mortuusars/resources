package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3722;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9302;
import net.minecraft.class_9334;

public record SetCustomAuthorOnLecternC2SP(class_2338 lecternPos, String author) implements Packet {
    public static final class_2960 ID = Scholar.resource("set_custom_author_on_lectern");
    public static final class_9154<SetCustomAuthorOnLecternC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, SetCustomAuthorOnLecternC2SP> STREAM_CODEC = class_9139.method_56435(
          class_2338.field_48404, SetCustomAuthorOnLecternC2SP::lecternPos,
          class_9135.method_56364(128), SetCustomAuthorOnLecternC2SP::author,
          SetCustomAuthorOnLecternC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (!(player.method_73183().method_8321(lecternPos) instanceof class_3722 lecternBlockEntity)) {
            Scholar.LOGGER.error("Cannot update lectern book: no lectern block entity at [{}]", lecternPos.method_23854());
            return false;
        }

        if (!Config.Common.BOOK_CHANGEABLE_AUTHOR.get()) {
            return true;
        }

        class_1799 book = lecternBlockEntity.method_17520();
        if (!book.method_31574(class_1802.field_8360)) {
            Scholar.LOGGER.error("Cannot set signing author on a lectern book at [{}]: book is not a written book but '{}'",
                  lecternPos.method_23854(), book);
            return false;
        }

        if (book.method_58694(class_9334.field_49606) instanceof class_9302 content) {
            book.method_57379(class_9334.field_49606, new class_9302(content.comp_2419(),
                  author, content.comp_2421(), content.comp_2422(), content.comp_2423()));
            lecternBlockEntity.method_5431();

            // Manually sending the block data to clients because it doesn't happen when block is changed for some reason
            if (Config.Common.LECTERN_TOOLTIP.get() && player instanceof class_3222 serverPlayer) {
                List<class_3222> players = serverPlayer.method_51469().method_18456();
                var packet = lecternBlockEntity.method_38235();
                if (packet != null) {
                    players.forEach(pl -> pl.field_13987.method_14364(packet));
                }
            }
        }

        return true;
    }
}
