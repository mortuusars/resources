package io.github.mortuusars.scholar.mixin.reading;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.scholar.world.entity.Reading;
import net.minecraft.class_10054;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_4840;
import net.minecraft.class_630;
import net.minecraft.class_9939;
import net.minecraft.client.model.*;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_4840.class)
public abstract class PiglinModelMixin extends class_9939<class_10054> {
    public PiglinModelMixin(class_630 modelPart) {
        super(modelPart);
    }

    @WrapOperation(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/PiglinRenderState;)V",
          at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/monster/piglin/PiglinModel;holdWeaponHigh(Lnet/minecraft/client/renderer/entity/state/PiglinRenderState;)V"))
    private void onSetupAnim(class_4840 instance, class_10054 renderState, Operation<Void> original) {
        @Nullable class_1268 openedBookHand = Reading.getOpenedBookHand(renderState.field_63602,
              renderState.field_63601,
              renderState.field_55303 == class_1306.field_6183);
        if (openedBookHand != null) {
            return; // Stop arms animation, so it wouldn't override ours.
        }

        original.call(instance, renderState);
    }
}
