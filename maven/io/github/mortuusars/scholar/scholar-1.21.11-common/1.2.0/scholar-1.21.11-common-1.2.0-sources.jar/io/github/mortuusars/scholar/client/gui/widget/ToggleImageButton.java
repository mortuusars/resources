package io.github.mortuusars.scholar.client.gui.widget;

import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_10799;
import net.minecraft.class_11907;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_8666;

public class ToggleImageButton extends class_344 {
    protected final class_8666 onSprites;
    protected final Consumer<Boolean> onToggled;
    protected boolean state;

    public ToggleImageButton(int x, int y, int width, int height, class_8666 offSprites, class_8666 onSprites,
                             Consumer<Boolean> onToggled) {
        super(x, y, width, height, offSprites, b -> {});
        this.onSprites = onSprites;
        this.onToggled = onToggled;
    }

    public boolean isOn() {
        return state;
    }

    public boolean isOff() {
        return !isOn();
    }

    public void toggle() {
        this.state = !state;
        onToggled.accept(this.state);
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public <T> T mapState(Function<Boolean, T> mappingFunction) {
        return mappingFunction.apply(state);
    }

    @Override
    public void method_25306(class_11907 input) {
        toggle();
    }

    @Override
    public void method_75752(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        class_8666 sprites = isOn() ? onSprites : this.field_45356;
        class_2960 identifier = sprites.method_52729(method_37303(), method_25367());
        guiGraphics.method_52706(class_10799.field_56883, identifier, method_46426(), method_46427(), field_22758, field_22759);
    }
}
