package io.github.mortuusars.scholar.client.gui.screen.view;

import com.mojang.datafixers.util.Pair;
import io.github.mortuusars.scholar.book.Spread;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.ScholarClient;
import io.github.mortuusars.scholar.client.gui.screen.SpreadBookScreen;
import io.github.mortuusars.scholar.client.gui.screen.edit.SpreadBookEditScreen;
import io.github.mortuusars.scholar.client.util.FileDialogs;
import net.minecraft.class_10799;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_12225;
import net.minecraft.class_124;
import net.minecraft.class_2477;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_3532;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_746;
import net.minecraft.class_7919;
import net.minecraft.network.chat.*;
import net.minecraft.network.chat.*;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.IntStream;

public abstract class SpreadBookViewScreen extends SpreadBookScreen {
    protected BookViewAccess bookAccess;
    protected class_2583 pageTextStyle;
    protected Pair<List<class_5481>, List<class_5481>> cachedPageComponents;
    protected int cachedSpread;

    protected class_344 exportBookButton;

    public SpreadBookViewScreen(BookViewAccess bookAccess, int bookColor) {
        super(bookColor);
        this.bookAccess = bookAccess;
        this.cachedPageComponents = Pair.of(Collections.emptyList(), Collections.emptyList());
        this.cachedSpread = -1;
        this.pageTextStyle = class_2583.field_24360.method_75861().method_36139(textColor);
    }

    @Override
    public boolean isGolden() {
        return getBookAccess().isGolden();
    }

    @Override
    protected void createWidgets() {
        super.createWidgets();
        exportBookButton = new class_344(leftPos + 297, topPos + 16, 18, 18, SpreadBookEditScreen.EXPORT_BOOK_SPRITES,
              b -> exportBook(!class_310.method_1551().method_74187()), class_2561.method_43471("gui.scholar.export_book"));
        exportBookButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.scholar.export_book")
              .method_10852(ScholarClient.KeyMappings.componentForTooltip(ScholarClient.KeyMappings.exportBook))
              .method_10852(class_5244.field_33849)
              .method_10852(class_2561.method_43471("gui.scholar.export_book.tooltip"))));
        method_37063(exportBookButton);
    }

    @Override
    protected void updateButtons() {
        super.updateButtons();
        exportBookButton.field_22764 = isToolsVisible();
        exportBookButton.field_22763 = IntStream.range(0, getBookAccess().getPageCount())
              .mapToObj(getBookAccess()::getPage)
              .anyMatch(text -> !text.getString().isEmpty());
    }

    public BookViewAccess getBookAccess() {
        return bookAccess;
    }

    public void setBookAccess(BookViewAccess bookViewAccess) {
        this.bookAccess = bookViewAccess;
        this.currentSpread = class_3532.method_15340(this.currentSpread, 0, getSpreadCount());
        this.cachedSpread = -1; // Forces cache update
    }

    @Override
    public int getPageCount() {
        return getBookAccess().getPageCount();
    }

    @Override
    public int getLastPage() {
        return Math.max(getPageCount() - 1, 0);
    }

    @Override
    protected int getFirstPageWithContent() {
        for (int i = 0; i < getPageCount(); i++) {
            if (!getBookAccess().getPage(i).getString().isEmpty()) {
                return i;
            }
        }
        return 0;
    }

    @Override
    protected int getLastPageWithContent() {
        for (int i = getPageCount() - 1; i >= 0; i--) {
            if (!getBookAccess().getPage(i).getString().isEmpty()) {
                return i;
            }
        }
        return 0;
    }

    @Override
    public boolean setPage(int pageIndex) {
        if (super.setPage(pageIndex)) {
            this.cachedSpread = -1;
            return true;
        }
        return false;
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        visitText(guiGraphics.method_75785(class_332.class_12228.field_63852), Spread.Side.LEFT);
        visitText(guiGraphics.method_75785(class_332.class_12228.field_63852), Spread.Side.RIGHT);
    }

    @Override
    public void method_25420(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25420(guiGraphics, mouseX, mouseY, partialTick);
        renderBook(guiGraphics, mouseX, mouseY, partialTick);
        renderPageNumbers(guiGraphics, mouseX, mouseY, partialTick, currentSpread);
        renderTools(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    protected void renderBook(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.renderBook(guiGraphics, mouseX, mouseY, partialTick);
        if (isToolsVisible()) {
            // Export button BG
            guiGraphics.method_25291(class_10799.field_56883, getTexture(), leftPos + 295, topPos + 14,
                  0, 388, 23, 24, 512, 512, getTintColor());
        }
    }

    protected void updateAndCacheContentsIfNeeded() {
        if (cachedSpread != currentSpread) {
            class_2561 leftComponent = class_2564.method_75859(getBookAccess().getPage(currentSpread * 2), pageTextStyle);
            class_2561 rightComponent = class_2564.method_75859(getBookAccess().getPage(currentSpread * 2 + 1), pageTextStyle);

            // Can't use font#split here, because we need to provide a default style.
            // Without default style text after '§r' will be displayed as white with shadow.
            cachedPageComponents = Pair.of(
                  class_2477.method_10517().method_30933(field_22793.method_27527().method_27495(leftComponent, TEXT_WIDTH, pageTextStyle)),
                  class_2477.method_10517().method_30933(field_22793.method_27527().method_27495(rightComponent, TEXT_WIDTH, pageTextStyle)));

            cachedSpread = currentSpread;
        }
    }

    // --

    @Override
    public boolean method_25402(class_11909 event, boolean isDoubleClick) {
        if (event.method_74245() == 0 && handleTextClick(event, isDoubleClick)) {
            return true;
        }

        return super.method_25402(event, isDoubleClick);
    }

    protected @NotNull Boolean handleTextClick(class_11909 event, boolean isDoubleClick) {
        return getTextSideUnderMouse(event.comp_4798(), event.comp_4799())
              .map(side -> {
                  var clickableStyleFinder = new class_12225.class_12226(field_22793, (int) event.comp_4798(), (int) event.comp_4799());
                  visitText(clickableStyleFinder, side);
                  class_2583 style = clickableStyleFinder.method_75777();
                  return style != null && style.method_10970() != null && handleTextClickEvent(style.method_10970());
              })
              .orElse(false);
    }

    protected boolean handleTextClickEvent(@NotNull class_2558 clickEvent) {
        class_746 localPlayer = Objects.requireNonNull(field_22787.field_1724, "Player not available");
        switch (clickEvent) {
            case class_2558.class_10605(int pageIndex):
                boolean pageChanged = this.setPage(pageIndex);
                if (pageChanged) {
                    playPageTurnSound();
                }
                break;
            case class_2558.class_10609(String command):
                this.method_25419();
                method_71844(localPlayer, command, null);
                break;
            default:
                method_71999(clickEvent, field_22787, this);
        }

        return true;
    }

    protected void visitText(class_12225 collector, Spread.Side side) {
        updateAndCacheContentsIfNeeded();

        List<class_5481> lines = side == Spread.Side.LEFT
              ? cachedPageComponents.getFirst()
              : cachedPageComponents.getSecond();
        int x = leftPos + (side == Spread.Side.LEFT ? TEXT_LEFT_X : TEXT_RIGHT_X);
        int y = topPos + TEXT_Y;

        int maxLines = Math.min(TEXT_HEIGHT / field_22793.field_2000, lines.size());
        for (int i = 0; i < maxLines; i++) {
            class_5481 line = lines.get(i);
            collector.method_75762(x, y + i * field_22793.field_2000, line);
        }
    }

    public Optional<Spread.Side> getTextSideUnderMouse(double mouseX, double mouseY) {
        if (mouseY >= topPos + TEXT_Y && mouseY < topPos + TEXT_Y + TEXT_HEIGHT) {
            if (mouseX >= leftPos + TEXT_LEFT_X && mouseX < leftPos + TEXT_LEFT_X + TEXT_WIDTH) {
                return Optional.of(Spread.Side.LEFT);
            }
            if (mouseX >= leftPos + TEXT_RIGHT_X && mouseX < leftPos + TEXT_RIGHT_X + TEXT_WIDTH) {
                return Optional.of(Spread.Side.RIGHT);
            }
        }
        return Optional.empty();
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (ScholarClient.KeyMappings.exportBook.method_1417(event)) {
            playButtonClickSound();
            exportBook(!event.method_74239());
            return true;
        }

        return super.method_25404(event);
    }

    // --

    public void exportBook(boolean withFormatting) {
        List<String> pages = new ArrayList<>();
        for (int i = 0; i < getBookAccess().getPageCount(); i++) {
            String text = getBookAccess().getPage(i).getString();
            pages.add(text);
        }

        String content = withFormatting
              ? String.join("\f", pages)
              : class_124.method_539(String.join("\f", pages));

        CompletableFuture.runAsync(() -> {
            String defaultDirectory = class_310.method_1551().field_1697.toPath().toAbsolutePath().normalize().toString();
            if (!defaultDirectory.endsWith(File.separator)) {
                defaultDirectory = defaultDirectory + File.separator;
            }
            String title = class_2561.method_43471("gui.scholar.export_book").getString();

            FileDialogs.saveFile(defaultDirectory, title, "Text Files (.txt)", "*.txt").ifPresent(filePath -> {
                try {
                    Files.writeString(Path.of(filePath), content, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                    class_5250 filePathComponent = class_2561.method_43470(filePath).method_27696(class_2583.field_24360
                          .method_30938(true)
                          .method_10958(new class_2558.class_10607(filePath)));
                    class_310.method_1551().execute(() -> player.method_7353(
                          class_2561.method_43471("gui.scholar.export_book.success")
                                .method_10852(filePathComponent), false));
                } catch (IOException e) {
                    class_310.method_1551().execute(() -> player.method_7353(
                          class_2561.method_43471("gui.scholar.export_book.failure"), false));
                    Scholar.LOGGER.error("Failed to export book: ", e);
                }
            });
        }).exceptionally(e -> {
            class_310.method_1551().execute(() -> player.method_7353(
                  class_2561.method_43471("gui.scholar.export_book.failure"), false));
            Scholar.LOGGER.error("Failed to export book: ", e);
            return null;
        });
    }
}