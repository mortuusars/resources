package io.github.mortuusars.scholar.book;

import com.google.common.collect.ImmutableMap;
import com.mojang.serialization.Codec;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.client.util.HexColor;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4309;
import net.minecraft.class_7654;

public class BookItemColorsReloadListener extends class_4309<Map<class_2960, Integer>> {
    public static final class_2960 ID = Scholar.resource("book_item_colors_reload_listener");

    public BookItemColorsReloadListener() {
        super(Codec.unboundedMap(class_2960.field_25139, HexColor.CODEC), class_7654.method_45114("book/item_colors"));
    }

    @Override
    protected void apply(Map<class_2960, Map<class_2960, Integer>> map, class_3300 resourceManager, class_3695 profiler) {
        Map<class_2960, Integer> result = new HashMap<>();

        for (Map<class_2960, Integer> value : map.values()) {
            result.putAll(value);
        }

        BookColor.ITEM_COLORS = ImmutableMap.copyOf(result);
    }
}