package io.github.mortuusars.scholar.mixin.reading;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.world.entity.Reading;
import net.minecraft.class_10086;
import net.minecraft.class_12159;
import net.minecraft.class_3968;
import net.minecraft.class_572;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_3968.class)
public abstract class AbstractZombieModelMixin<S extends class_10086> extends class_572<S> {
    public AbstractZombieModelMixin(class_630 root) {
        super(root);
    }

    @WrapOperation(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/ZombieRenderState;)V",
          at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/AnimationUtils;animateZombieArms(Lnet/minecraft/client/model/geom/ModelPart;Lnet/minecraft/client/model/geom/ModelPart;ZLnet/minecraft/client/renderer/entity/state/UndeadRenderState;)V"))
    private void onSetupAnim(class_630 leftArm, class_630 rightArm, boolean isAggressive, class_12159 renderState, Operation<Void> original) {
        if (renderState.method_75467().method_57826(Scholar.DataComponents.BOOK_OPEN)) {
            return; // Stop zombie arms animation, so it wouldn't override ours.
        }

        original.call(leftArm, rightArm, isAggressive, renderState);
    }
}
