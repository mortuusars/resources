package io.github.mortuusars.scholar.client.gui;

import io.github.mortuusars.scholar.client.chiseled_bookshelf.ChiseledBookshelfTooltip;
import io.github.mortuusars.scholar.client.lectern.LecternTooltip;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_8002;
import net.minecraft.class_9779;

public class InWorldTooltip {
    public static boolean render(class_332 guiGraphics, class_9779 deltaTracker) {
        if (class_310.method_1551().field_1690.field_1842) {
            return false;
        }
        return ChiseledBookshelfTooltip.render(guiGraphics, deltaTracker)
              || LecternTooltip.render(guiGraphics, deltaTracker);
    }

    public static void renderItemTooltip(class_332 guiGraphics, class_9779 deltaTracker, class_1799 stack) {
        int x = class_310.method_1551().method_22683().method_4486() / 2 + 16;
        int y = class_310.method_1551().method_22683().method_4502() / 2 - 9;

        class_8002.method_47946(guiGraphics, x, y, 18, 18, null);
        guiGraphics.method_51427(stack, x + 1, y + 1);

        guiGraphics.method_51446(class_310.method_1551().field_1772, stack, x + 16, y + 12);
        guiGraphics.method_73199();
    }
}
