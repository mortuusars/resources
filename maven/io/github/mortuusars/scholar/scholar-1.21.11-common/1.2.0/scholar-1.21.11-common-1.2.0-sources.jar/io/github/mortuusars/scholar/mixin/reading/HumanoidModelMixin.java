package io.github.mortuusars.scholar.mixin.reading;

import io.github.mortuusars.scholar.client.animation.ReadingAnimation;
import io.github.mortuusars.scholar.world.entity.Reading;
import net.minecraft.class_10034;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_310;
import net.minecraft.class_3881;
import net.minecraft.class_3882;
import net.minecraft.class_5498;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_630;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_572.class)
public abstract class HumanoidModelMixin<T extends class_10034> extends class_583<T> implements class_3881<T>, class_3882 {
    @Shadow
    @Final
    public class_630 leftArm;
    @Shadow
    @Final
    public class_630 rightArm;
    @Shadow
    @Final
    public class_630 head;
    @Shadow
    @Final
    public class_630 body;

    protected HumanoidModelMixin(class_630 root) {
        super(root);
    }

    @Inject(method = "poseLeftArm", at = @At("HEAD"), cancellable = true)
    private void poseLeftArm(T renderState, CallbackInfo ci) {
        if (class_310.method_1551().field_1690.method_31044() == class_5498.field_26664
              && class_310.method_1551().method_1560() != null
              && class_310.method_1551().method_1560().method_5628() == ReadingAnimation.getEntityId(renderState)) {
            return;
        }

        @Nullable class_1268 openedBookHand = Reading.getOpenedBookHand(renderState.field_63602,
              renderState.field_63601,
              renderState.field_55303 == class_1306.field_6183);
        if (openedBookHand == null) {
            return;
        }

        ReadingAnimation.poseLeftArm(renderState, leftArm);
        ci.cancel();
    }

    @Inject(method = "poseRightArm", at = @At("HEAD"), cancellable = true)
    private void poseRightArm(T renderState, CallbackInfo ci) {
        if (class_310.method_1551().field_1690.method_31044() == class_5498.field_26664
              && class_310.method_1551().method_1560() != null
              && class_310.method_1551().method_1560().method_5628() == ReadingAnimation.getEntityId(renderState)) {
            return;
        }

        @Nullable class_1268 openedBookHand = Reading.getOpenedBookHand(renderState.field_63602,
              renderState.field_63601,
              renderState.field_55303 == class_1306.field_6183);
        if (openedBookHand == null) {
            return;
        }

        ReadingAnimation.poseRightArm(renderState, rightArm);
        ci.cancel();
    }

    @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/HumanoidRenderState;)V",
          at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/HumanoidModel;setupAttackAnimation(Lnet/minecraft/client/renderer/entity/state/HumanoidRenderState;)V"))
    void onSetupAnim(T renderState, CallbackInfo ci) {
        @Nullable class_1268 openedBookHand = Reading.getOpenedBookHand(renderState.field_63602,
              renderState.field_63601,
              renderState.field_55303 == class_1306.field_6183);
        if (openedBookHand == null) {
            return;
        }

        ReadingAnimation.poseHead(renderState, body, head);
    }
}