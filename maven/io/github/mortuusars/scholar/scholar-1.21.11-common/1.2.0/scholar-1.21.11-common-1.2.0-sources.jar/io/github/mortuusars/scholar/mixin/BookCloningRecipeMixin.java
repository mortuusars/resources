package io.github.mortuusars.scholar.mixin;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookColor;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1850;
import net.minecraft.class_7225;
import net.minecraft.class_9302;
import net.minecraft.class_9334;
import net.minecraft.class_9694;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1850.class)
public class BookCloningRecipeMixin {
    // 'BookCloningRecipe#matches' may need to be changed as well. But it seems to work fine without it.

    /**
     * Purpose of this mixin is to disallow writable books of different colors to be in a craft.
     * And set the color of a result book to color of writable book.
     * -
     * This mixin basically overrides whole method which may cause compatibility issues. But it would require more mixins to change it in specific parts.
     * Mods that modify this recipe should be very rare anyway.
     */
    @Inject(method = "assemble(Lnet/minecraft/world/item/crafting/CraftingInput;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/world/item/ItemStack;",
            at = @At("HEAD"), cancellable = true)
    private void onAssemble(class_9694 input, class_7225.class_7874 registries, CallbackInfoReturnable<class_1799> cir) {
        class_1799 inputBook = class_1799.field_8037;
        @Nullable Integer resultColor = null;
        int copies = 0;

        for (int slot = 0; slot < input.method_59983(); ++slot) {
            class_1799 stack = input.method_59984(slot);
            if (stack.method_7960()) {
                continue;
            }

            if (stack.method_31574(class_1802.field_8360)) {
                if (!inputBook.method_7960()) {
                    cir.setReturnValue(class_1799.field_8037);
                    return; // multiple written books as inputs are not allowed
                }

                inputBook = stack;
                continue;
            }

            if (stack.method_31574(class_1802.field_8674)) {
                // Since result book will get writable book color - books of different colors are not allowed.
                int color = BookColor.of(stack);
                if (resultColor == null) {
                    resultColor = color;
                }
                else if (resultColor != color) {
                    cir.setReturnValue(class_1799.field_8037);
                    return;
                }

                ++copies;
                continue;
            }
            cir.setReturnValue(class_1799.field_8037);
            return;
        }

        if (inputBook.method_7960() || copies < 1) {
            cir.setReturnValue(class_1799.field_8037);
            return; // Cannot be copied
        }

        @Nullable class_9302 content = inputBook.method_58695(class_9334.field_49606, class_9302.field_49829).method_57519();
        if (content == null) {
            cir.setReturnValue(class_1799.field_8037);
            return; // Cannot be copied
        }

        class_1799 resultStack = inputBook.method_46651(copies);
        resultStack.method_57379(class_9334.field_49606, content);
        resultStack.method_57381(Scholar.DataComponents.BOOK_GOLDEN);
        BookColor.set(resultStack, resultColor);
        cir.setReturnValue(resultStack);
    }
}
