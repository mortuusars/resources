package io.github.mortuusars.scholar.client.chiseled_bookshelf;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.client.gui.InWorldTooltip;
import org.jetbrains.annotations.Nullable;

import java.util.OptionalInt;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_7714;
import net.minecraft.class_7716;
import net.minecraft.class_9779;

public class ChiseledBookshelfTooltip {
    public static boolean render(class_332 guiGraphics, class_9779 deltaTracker) {
        if (!Config.Common.CHISELED_BOOKSHELF_TOOLTIP.get()) {
            return false;
        }

        class_310 minecraft = class_310.method_1551();

        if (minecraft.field_1687 == null || minecraft.field_1724 == null || minecraft.field_1755 != null
              || !(minecraft.field_1765 instanceof class_3965 blockHitResult)) {
            return false;
        }

        if (Config.Common.TOOLTIP_REQUIRES_SNEAK.get() && !minecraft.field_1724.method_21823()) {
            return false;
        }

        class_2338 hitPos = blockHitResult.method_17777();
        class_2680 blockState = minecraft.field_1687.method_8320(hitPos);

        if (!(blockState.method_26204() instanceof class_7714 chiseledBookShelfBlock)) {
            return false;
        }

        @Nullable class_2586 blockEntity = minecraft.field_1687.method_8321(hitPos);

        if (!(blockEntity instanceof class_7716 chiseledBookShelfBlockEntity)) {
            return false;
        }

        OptionalInt hitSlot = chiseledBookShelfBlock.method_72611(blockHitResult, blockState.method_11654(class_7714.field_61990));

        if (hitSlot.isEmpty()) return false;

        class_1799 bookStack = chiseledBookShelfBlockEntity.method_5438(hitSlot.getAsInt());
        if (bookStack.method_7960()) {
            return false;
        }

        InWorldTooltip.renderItemTooltip(guiGraphics, deltaTracker, bookStack);
        return true;
    }
}
