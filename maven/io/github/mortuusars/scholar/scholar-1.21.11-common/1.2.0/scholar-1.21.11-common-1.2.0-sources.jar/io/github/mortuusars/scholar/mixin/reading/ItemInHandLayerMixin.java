package io.github.mortuusars.scholar.mixin.reading;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.client.BookRenderState;
import io.github.mortuusars.scholar.client.ColoredBookModel;
import io.github.mortuusars.scholar.client.lectern.ScholarBookHolderRenderState;
import net.minecraft.class_10034;
import net.minecraft.class_10426;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3881;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_557;
import net.minecraft.class_5602;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_989;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings("rawtypes")
@Mixin(class_989.class)
public abstract class ItemInHandLayerMixin<S extends class_10426, M extends class_583<S> & class_3881> extends class_3887<S, M> {
    @Unique
    private class_557 scholar$bookModel;

    public ItemInHandLayerMixin(class_3883<S, M> renderer) {
        super(renderer);
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInit(class_3883<S, M> renderLayerParent, CallbackInfo ci) {
        scholar$bookModel = new class_557(class_310.method_1551().method_31974().method_32072(class_5602.field_27685));
    }

    @Inject(method = "submitArmWithItem", at = @At("HEAD"), cancellable = true)
    private void onRenderArmWithItem(S entityRenderState, class_10444 stackRenderState, class_1799 stack,
                                     class_1306 arm, class_4587 poseStack, class_11659 submitNodeCollector,
                                     int packedLight, CallbackInfo ci) {
        if (Config.Common.BOOK_READING_ANIMATION.get()
              && entityRenderState instanceof class_10034 humanoidRenderState
              && method_17165() instanceof class_572<?> humanoidModel) {
            if (stack.method_57826(Scholar.DataComponents.BOOK_OPEN)) {
                BookRenderState bookRenderState = new BookRenderState(stack.method_57826(Scholar.DataComponents.BOOK_GOLDEN), BookColor.of(stack));
                ColoredBookModel.submitInHand(humanoidRenderState, bookRenderState,
                      stackRenderState, stack, arm, poseStack, submitNodeCollector, packedLight, humanoidModel, scholar$bookModel);
                ci.cancel();
            } else if (Config.Common.BOOK_READING_HIDE_OFFHAND_ITEM.get()) {
                boolean isInLeftHand = arm == class_1306.field_6182;
                class_1799 otherHandStack = isInLeftHand
                      ? entityRenderState.field_63601
                      : entityRenderState.field_63602;

                if (otherHandStack.method_57826(Scholar.DataComponents.BOOK_OPEN)) {
                    ci.cancel(); // Do not render item in hand if a book is held in another
                }
            }
        }
    }
}
