package io.github.mortuusars.scholar.mixin.reading;

import io.github.mortuusars.scholar.client.animation.ReadingAnimation;
import io.github.mortuusars.scholar.world.entity.Reading;
import net.minecraft.class_10035;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1543;
import net.minecraft.class_3881;
import net.minecraft.class_3882;
import net.minecraft.class_575;
import net.minecraft.class_583;
import net.minecraft.class_630;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_575.class)
public abstract class IllagerModelMixin<S extends class_10035> extends class_583<S> implements class_3881<S>, class_3882 {
    @Shadow
    @Final
    private class_630 leftArm;

    @Shadow
    @Final
    private class_630 rightArm;

    @Shadow
    @Final
    private class_630 head;

    protected IllagerModelMixin(class_630 root) {
        super(root);
    }

    @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/IllagerRenderState;)V", at = @At("RETURN"))
    private void onSetupAnim(S renderState, CallbackInfo ci) {
        @Nullable class_1268 openedBookHand = Reading.getOpenedBookHand(renderState.field_63602,
              renderState.field_63601,
              renderState.field_53423 == class_1306.field_6183);
        if (openedBookHand != null && renderState.field_53424 != class_1543.class_1544.field_7207) {
            ReadingAnimation.poseLeftArm(renderState, leftArm);
            ReadingAnimation.poseRightArm(renderState, rightArm);
            ReadingAnimation.poseHead(renderState, field_54014.method_32086("body"), head);
        }
    }
}
