package io.github.mortuusars.scholar.mixin.lectern;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.client.BookRenderState;
import io.github.mortuusars.scholar.client.ColoredBookModel;
import io.github.mortuusars.scholar.client.lectern.ScholarBookHolderRenderState;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_11701;
import net.minecraft.class_11967;
import net.minecraft.class_12075;
import net.minecraft.class_243;
import net.minecraft.class_3722;
import net.minecraft.class_3942;
import net.minecraft.class_4587;
import net.minecraft.class_557;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3942.class)
public class LecternRendererMixin {
    @Shadow
    @Final
    private class_557 bookModel;

    @Shadow
    @Final
    private class_11701 materials;

    @Shadow
    @Final
    private class_557.class_11650 bookState;

    @Inject(method = "extractRenderState(Lnet/minecraft/world/level/block/entity/LecternBlockEntity;Lnet/minecraft/client/renderer/blockentity/state/LecternRenderState;FLnet/minecraft/world/phys/Vec3;Lnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)V",
          at = @At("RETURN"))
    private void onExtractRenderState(class_3722 lecternBlockEntity, class_11967 lecternRenderState, float partialTick, class_243 cameraPos, class_11683.class_11792 crumblingOverlay, CallbackInfo ci) {
        if (lecternRenderState instanceof ScholarBookHolderRenderState state) {
            if (Config.Common.LECTERN_COLORED_BOOK_MODEL.get() && !lecternBlockEntity.method_17520().method_7960()) {
                state.scholar$setBookRenderState(new BookRenderState(
                      lecternBlockEntity.method_17520().method_57826(Scholar.DataComponents.BOOK_GOLDEN),
                      BookColor.of(lecternBlockEntity.method_17520())));
            } else {
                state.scholar$setBookRenderState(BookRenderState.NO_BOOK);
            }
        }
    }

    @Inject(method = "submit(Lnet/minecraft/client/renderer/blockentity/state/LecternRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
          at = @At("HEAD"),
          cancellable = true)
    private void onSubmit(class_11967 lecternRenderState, class_4587 poseStack, class_11659 submitNodeCollector,
                          class_12075 cameraRenderState, CallbackInfo ci) {
        if (Config.Common.LECTERN_COLORED_BOOK_MODEL.get()) {
            ColoredBookModel.submitOnLectern(lecternRenderState, poseStack, submitNodeCollector, cameraRenderState, materials, bookModel, bookState);
            ci.cancel();
        }
    }
}
