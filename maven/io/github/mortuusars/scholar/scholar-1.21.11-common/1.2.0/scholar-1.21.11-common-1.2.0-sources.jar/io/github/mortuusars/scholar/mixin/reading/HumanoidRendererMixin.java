package io.github.mortuusars.scholar.mixin.reading;

import io.github.mortuusars.scholar.client.ScholarHumanoidRenderState;
import net.minecraft.class_10034;
import net.minecraft.class_1308;
import net.minecraft.class_5617;
import net.minecraft.class_572;
import net.minecraft.class_909;
import net.minecraft.class_9990;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings("deprecation")
@Mixin(class_909.class)
public abstract class HumanoidRendererMixin <T extends class_1308, S extends class_10034, M extends class_572<S>> extends class_9990<T, S, M> {
    public HumanoidRendererMixin(class_5617.class_5618 context, M adultModel, M babyModel, float scale) {
        super(context, adultModel, babyModel, scale);
    }

    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/Mob;Lnet/minecraft/client/renderer/entity/state/HumanoidRenderState;F)V",
    at = @At("RETURN"))
    private void onExtractRenderState(T mob, S humanoidRenderState, float f, CallbackInfo ci) {
        if (humanoidRenderState instanceof ScholarHumanoidRenderState state) {
            state.scholar$setEntityId(mob.method_5628());
        }
    }
}
