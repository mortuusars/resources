package io.github.mortuusars.scholar.client.gui.widget;

import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_8666;

public class BookmarkButton extends class_344 {
    protected final class_8666 expandedSprites;
    protected boolean expanded;

    public BookmarkButton(int x, int y, int width, int height, class_8666 defaultSprites, class_8666 expandedSprites, class_4241 onPress, class_2561 message) {
        super(x, y, width, height, defaultSprites, onPress, message);
        this.expandedSprites = expandedSprites;
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    @Override
    public void method_75752(class_332 guiGraphics, int i, int j, float f) {
        class_8666 sprites = expanded ? expandedSprites : this.field_45356;
        class_2960 sprite = sprites.method_52729(method_37303(), method_25367());
        guiGraphics.method_52706(class_10799.field_56883, sprite, method_46426(), method_46427(), field_22758, field_22759);
    }
}
