package io.github.mortuusars.scholar.client.animation;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.client.ScholarHumanoidRenderState;
import net.minecraft.class_10034;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_1840;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3881;
import net.minecraft.class_4896;
import net.minecraft.class_557;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class ReadingAnimation {
    public static final class_557.class_11650 BOOK_OPEN_STATE = new class_557.class_11650(0.0F, 0.1F, 0.9F, 1.2F);

    public static <T extends class_10034> void poseLeftArm(T renderState, class_630 part) {
        part.field_3654 = part.field_3654 * 0.5F - (float) (Math.PI / 5);
        part.field_3675 = 0F;
        // Undo most of the bobbing:
        class_4896.method_29350(part, renderState.field_53328, 0.8F);
    }

    public static <T extends class_10034> void poseRightArm(T renderState, class_630 part) {
        part.field_3654 = part.field_3654 * 0.5F - (float) (Math.PI / 5);
        part.field_3675 = 0F;

        // Undo original bobbing:
        class_4896.method_29350(part, renderState.field_53328, -1F);
        // Apply bobbing in the opposite direction to match left arm:
        class_4896.method_29350(part, renderState.field_53328, -0.2F);

        int entityId = getEntityId(renderState);

        // Page flip animation
        int perEntityOffset = 42 * entityId;
        float ageInTicks = renderState.field_53328 + perEntityOffset;
        int lineDuration = getLineDuration(renderState);
        int spreadDuration = lineDuration * getLinesPerPage() * 2;
        float spreadProgress = ageInTicks % spreadDuration;
        float returnDuration = lineDuration * (1 - getForwardToReturnRatio());
        float timeUntilLastReturn = spreadDuration - returnDuration;
        if (spreadProgress > timeUntilLastReturn) {
            float progress = spreadProgress - timeUntilLastReturn;
            float anim = easeInOutSine(progress / returnDuration);
            if (anim > 0.5) {
                anim = 1 - anim;
            }

            part.field_3675 -= anim * 2;
            part.field_3674 += anim * 2;
            part.field_3654 -= anim * 2;
        }

//
//
//        @Nullable InteractionHand openedBookHand = Reading.getOpenedBookHand(renderState.leftHandItemStack,
//              renderState.rightHandItemStack,
//              renderState.mainArm == HumanoidArm.RIGHT);
//        if (openedBookHand == null) {
//            return;
//        }

        boolean isWriting = (renderState.field_63601.method_57826(Scholar.DataComponents.BOOK_OPEN) && renderState.field_63601.method_7909() instanceof class_1840)
                || (renderState.field_63602.method_57826(Scholar.DataComponents.BOOK_OPEN) && renderState.field_63602.method_7909() instanceof class_1840);

        // Writing animation
        if (isWriting) {
            // Up/down
            float anim = (ageInTicks % 6) / 3;
            if (anim > 1) {
                anim = 2 - anim;
            }
            anim = easeInOutSine(anim);
            part.field_3654 -= 0.5f + anim * 0.01f;

            // Side to side
            float scanningForwardDuration = lineDuration * getForwardToReturnRatio();
            float scanningReturnDuration = lineDuration - scanningForwardDuration;
            float time = ageInTicks % lineDuration;
            boolean isReturning = time >= scanningForwardDuration;
            anim = isReturning
                  ? 1f - ((time - scanningForwardDuration) / scanningReturnDuration)
                  : time / scanningForwardDuration;
            anim = easeInOutSine(anim);
            part.field_3675 -= 0.5f - anim * 0.5f;
            part.field_3674 -= anim * 0.1f;
        }
    }

    /**
     * Time it takes to "read" the line and return back.
     * <br>
     * Each entity has slightly different time to read.
     */
    public static <T extends class_10034> int getLineDuration(T renderState) {
        int entityId = getEntityId(renderState);
        return 30 + ((entityId % 5) * 5);
    }

    public static int getLinesPerPage() {
        return 5;
    }

    /**
     * Percentage of time that would be spent "reading" the line versus going back to the beginning of a new line.
     */
    public static float getForwardToReturnRatio() {
        return 0.8f;
    }

    public static <T extends class_10034> void poseHead(T renderState, class_630 body, class_630 head) {
        float amplitude = 0.25f; // How much head turns when reading the line
        float forwardToReturnRatio = getForwardToReturnRatio();
        float turnOffset = 0.05f; // Slight head rotation towards the current book side
        float pitchPerLine = 0.1f;

        int lineDuration = getLineDuration(renderState);
        int lines = getLinesPerPage();
        int pageDuration = lineDuration * lines;
        int spreadDuration = pageDuration * 2;

        int entityId = getEntityId(renderState);

        double age = renderState.field_53328 + entityId * 42.0; // Animations should be unique per entity. Age would be similar after world load.
        float spreadTime = (float) (age % spreadDuration);
        float pageTime = spreadTime % pageDuration;
        float lineTime = pageTime % lineDuration;
        float forwardDuration = lineDuration * forwardToReturnRatio;
        float returnDuration = lineDuration - forwardDuration;

        // Yaw
        boolean isOnTheRightPage = spreadTime >= pageDuration;
        boolean isOnTheLastLine = pageTime >= pageDuration - lineDuration;
        boolean isReturning = lineTime >= forwardDuration;

        float scanningAnim = isReturning
              ? 1f - ((lineTime - forwardDuration) / returnDuration)
              : lineTime / forwardDuration;

        if (!isOnTheRightPage) {
            scanningAnim = 1 - scanningAnim;
        }

        scanningAnim = easeInOutSine(scanningAnim);

        float turn = isOnTheRightPage
              ? turnOffset + scanningAnim * amplitude
              : -turnOffset + -scanningAnim * amplitude;

        // Fixes jumping when transitioning to the other book side
        if (isReturning && isOnTheLastLine) {
            float target = isOnTheRightPage ? -turnOffset - amplitude : turnOffset;
            turn = class_3532.method_16439(isOnTheRightPage ? 1 - scanningAnim : scanningAnim, turn, target);
        }

        if (renderState.field_63604 > 0) {
            float anim = easeInOutSine(renderState.field_63604);
            head.field_3675 = class_3532.method_16439(anim, head.field_3675, body.field_3675 + turn);
        } else {
            head.field_3675 = body.field_3675 + turn;
        }

        // Pitch
        // Purpose of this is to pitch the head down after each line has been read, and return back to top.
        float min = 0.5f;
        float transitionPart = 1 - forwardToReturnRatio;

        float linesPassed = pageTime / lineDuration;

        int current = (int) linesPassed % lines;
        int next = (current + 1) % lines;

        float lineProgress = linesPassed - (int) linesPassed;

        float currentPitch = min + current * pitchPerLine;
        float nextPitch = min + next * pitchPerLine;

        float pitch;

        if (lineProgress < 1.0 - transitionPart) {
            pitch = currentPitch;
        } else {
            float t = easeInOutSine((lineProgress - (1f - transitionPart)) / transitionPart);
            pitch = class_3532.method_16439(t, currentPitch, nextPitch);
        }

        if (renderState.field_63604 > 0) {
            float anim = easeInOutSine(renderState.field_63604);
            head.field_3654 = class_3532.method_16439(anim, head.field_3675, pitch);
        } else {
            head.field_3654 = pitch;
        }
    }

    public static <S extends class_10034> class_557.class_11650 createBookRenderState(S renderState, class_1799 stack,
                                                                                        class_1306 arm, class_557 bookModel) {
        int perEntityOffset = 42 * getEntityId(renderState);
        float ageInTicks = renderState.field_53328 + perEntityOffset;
        int lineDuration = getLineDuration(renderState);
        int spreadDuration = lineDuration * getLinesPerPage() * 2;
        float spreadProgress = ageInTicks % spreadDuration;
        float returnDuration = lineDuration * (1 - getForwardToReturnRatio());
        float timeUntilLastReturn = spreadDuration - returnDuration;

        // Flip the page on the last return
        if (spreadProgress > timeUntilLastReturn) {
            float progress = spreadProgress - timeUntilLastReturn;
            float anim = easeInOutSine(progress / returnDuration);
            float flip = anim < 0.9f
                  ? 0.9F - anim * 0.9f
                  : 0.9f + (1f - anim);
            return new class_557.class_11650(0.0F, 0.1F, flip, 1.2F);
        } else {
            return BOOK_OPEN_STATE;
        }
    }

    @SuppressWarnings("rawtypes")
    public static <S extends class_10034, M extends class_583<?> & class_3881> void poseBook(S renderState, class_1799 stack,
                                                                                                       class_1306 arm, M entityModel, class_557 bookModel) {
        int perEntityOffset = 42 * getEntityId(renderState);
        float ageInTicks = renderState.field_53328 + perEntityOffset;
        int lineDuration = getLineDuration(renderState);
        int spreadDuration = lineDuration * getLinesPerPage() * 2;
        float spreadProgress = ageInTicks % spreadDuration;
        float returnDuration = lineDuration * (1 - getForwardToReturnRatio());
        float timeUntilLastReturn = spreadDuration - returnDuration;

        // Flip the page on the last return
        if (spreadProgress > timeUntilLastReturn) {
            float progress = spreadProgress - timeUntilLastReturn;
            float anim = easeInOutSine(progress / returnDuration);
            float flip = anim < 0.9f
                  ? 0.9F - anim * 0.9f
                  : 0.9f + (1f - anim);
            bookModel.method_17073(new class_557.class_11650(0.0F, 0.1F, flip, 1.2F));
        } else {
            bookModel.method_17073(BOOK_OPEN_STATE);
        }
    }

    public static float easeInOutSine(float x) {
        return (float) (-(Math.cos(Math.PI * x) - 1) / 2);
    }

    public static float getPartialTick() {
        return class_310.method_1551().method_61966().method_60637(false);
    }

    public static <T extends class_10034> int getEntityId(T renderState) {
        return renderState instanceof ScholarHumanoidRenderState state ? state.scholar$getEntityId() : 0;
    }
}
