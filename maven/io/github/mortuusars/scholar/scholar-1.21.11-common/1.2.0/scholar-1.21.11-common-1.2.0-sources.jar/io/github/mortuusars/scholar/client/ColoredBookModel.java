package io.github.mortuusars.scholar.client;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.client.animation.ReadingAnimation;
import io.github.mortuusars.scholar.client.lectern.ScholarBookHolderRenderState;
import net.minecraft.class_10034;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_11701;
import net.minecraft.class_11967;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1840;
import net.minecraft.class_310;
import net.minecraft.class_3881;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_4730;
import net.minecraft.class_557;
import net.minecraft.class_572;
import net.minecraft.class_606;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.client.model.*;
import org.jetbrains.annotations.NotNull;

public class ColoredBookModel {
    public static final class_4730 BOOK_COVER_LOCATION = class_4722.field_61760.method_67273(Scholar.resource("book_cover"));
    public static final class_4730 BOOK_COVER_GOLDEN_LOCATION = class_4722.field_61760.method_67273(Scholar.resource("book_cover_golden"));
    public static final class_4730 BOOK_PAGES_LOCATION = class_4722.field_61760.method_67273(Scholar.resource("book_pages"));

    public static void submitOnLectern(class_11967 lecternRenderState, class_4587 poseStack, class_11659 submitNodeCollector,
                                       class_12075 cameraRenderState, class_11701 materials, class_557 bookModel, class_557.class_11650 bookState) {
        if (lecternRenderState instanceof ScholarBookHolderRenderState state && state.scholar$getBookRenderState().hasBook()) {
            poseStack.method_22903();
            poseStack.method_46416(0.5F, 1.0625F, 0.5F);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(-lecternRenderState.field_62728));
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(67.5F));
            poseStack.method_46416(0.0F, -0.125F, 0.0F);

            class_4730 coverMaterial = getBookCoverMaterial(state.scholar$getBookRenderState());
            submitNodeCollector.method_73490(bookModel, bookState, poseStack,
                  coverMaterial.method_24146(class_12249::method_75990),
                  lecternRenderState.field_62676,
                  class_4608.field_21444,
                  state.scholar$getBookRenderState().coverTintColor(),
                  materials.method_73030(coverMaterial),
                  0,
                  lecternRenderState.field_62677
            );

            class_4730 pagesMaterial = getBookPagesMaterial(state.scholar$getBookRenderState());
            submitNodeCollector.method_73490(bookModel, bookState, poseStack,
                  pagesMaterial.method_24146(class_12249::method_75990),
                  lecternRenderState.field_62676,
                  class_4608.field_21444,
                  0xFFFFFFFF,
                  materials.method_73030(pagesMaterial),
                  0,
                  lecternRenderState.field_62677
            );

            poseStack.method_22909();
        }
    }

    @SuppressWarnings("rawtypes")
    public static <S extends class_10034, M extends class_572 & class_3881> void submitInHand(
          S humanoidRenderState, BookRenderState bookRenderState, class_10444 stackRenderState, class_1799 stack, class_1306 arm, class_4587 poseStack,
          class_11659 submitNodeCollector, int packedLight, M entityModel, class_557 bookModel) {
        poseStack.method_22903();

        // We attach the book to the left hand, to use the right hand for page flipping animation (to not move the book with the arm).
        // Unless the entity is currently swinging - in that case we still use original arm for it, to "open" the book in the correct hand.
        if (humanoidRenderState.field_63604 > 0) {
            entityModel.method_72852(humanoidRenderState, arm, poseStack);
            poseStack.method_22904(arm == class_1306.field_6182 ? -0.285F : 0.285F, 0.625, -0.38);
        } else {
            entityModel.method_72852(humanoidRenderState, class_1306.field_6182, poseStack);
            poseStack.method_22904(-0.285F, 0.625, -0.38);
        }

        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-90));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(-90));

        class_557.class_11650 bookState = ReadingAnimation.createBookRenderState(humanoidRenderState, stack, arm, bookModel);

        ReadingAnimation.poseBook(humanoidRenderState, stack, arm, entityModel, bookModel);

        class_4730 coverMaterial = getBookCoverMaterial(bookRenderState);
        submitNodeCollector.method_73490(bookModel, bookState, poseStack,
              coverMaterial.method_24146(class_12249::method_75990),
              packedLight,
              class_4608.field_21444,
              bookRenderState.coverTintColor(),
              class_310.method_1551().method_72703().method_73030(coverMaterial),
              0,
              null
        );

        class_4730 pagesMaterial = getBookPagesMaterial(bookRenderState);
        submitNodeCollector.method_73490(bookModel, bookState, poseStack,
              pagesMaterial.method_24146(class_12249::method_75990),
              packedLight,
              class_4608.field_21444,
              0xFFFFFFFF,
              class_310.method_1551().method_72703().method_73030(pagesMaterial),
              0,
              null
        );

        poseStack.method_22909();

        if (stack.method_7909() instanceof class_1840) {
            class_1306 mainArm = humanoidRenderState.field_55303;
            boolean isLeftArm = mainArm == class_1306.field_6182;

            poseStack.method_22903();
            entityModel.method_72852(humanoidRenderState, class_1306.field_6183, poseStack);
            poseStack.method_22904((float) (isLeftArm ? -1 : 1) / 16.0F - 0.05, 0.5F,
                  entityModel instanceof class_606<?> ? -0.15F : -0.22F);
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(150.0F));
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(40.0F));
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(-90));
            poseStack.method_22905(0.8f, 0.8f, 0.8f);

            class_811 context = mainArm == class_1306.field_6182
                  ? class_811.field_4323
                  : class_811.field_4320;

            class_10444 itemStackRenderState = new class_10444();
            class_310.method_1551().method_65386().method_65598(itemStackRenderState,
                  new class_1799(class_1802.field_8153), context, null, null, 0);
            itemStackRenderState.method_65604(poseStack, submitNodeCollector, packedLight, class_4608.field_21444, 0);

            poseStack.method_22909();
        }
    }

    public static void renderInFirstpersonHand(class_1309 entity, class_1799 stack, class_811 context, class_4587 poseStack,
                                               class_11659 submitNodeCollector, int packedLight, class_557 bookModel) {
        poseStack.method_22903();

        boolean isInMainHand = entity.method_6047() == stack;
        class_1306 arm = isInMainHand
              ? entity.method_6068()
              : entity.method_6068().method_5928();

        if (arm == class_1306.field_6182) {
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(135));
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(135));
        } else {
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(45));
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(135));
        }

        BookRenderState bookRenderState = new BookRenderState(stack.method_57826(Scholar.DataComponents.BOOK_GOLDEN), BookColor.of(stack));

        class_4730 coverMaterial = getBookCoverMaterial(bookRenderState);
        submitNodeCollector.method_73490(bookModel, ReadingAnimation.BOOK_OPEN_STATE, poseStack,
              coverMaterial.method_24146(class_12249::method_75990),
              packedLight,
              class_4608.field_21444,
              bookRenderState.coverTintColor(),
              class_310.method_1551().method_72703().method_73030(coverMaterial),
              0,
              null
        );

        class_4730 pagesMaterial = getBookPagesMaterial(bookRenderState);
        submitNodeCollector.method_73490(bookModel, ReadingAnimation.BOOK_OPEN_STATE, poseStack,
              pagesMaterial.method_24146(class_12249::method_75990),
              packedLight,
              class_4608.field_21444,
              0xFFFFFFFF,
              class_310.method_1551().method_72703().method_73030(pagesMaterial),
              0,
              null
        );

        poseStack.method_22909();
    }

    public static @NotNull class_4730 getBookCoverMaterial(BookRenderState renderState) {
        return renderState.isGolden()
              ? BOOK_COVER_GOLDEN_LOCATION
              : BOOK_COVER_LOCATION;
    }

    public static @NotNull class_4730 getBookPagesMaterial(BookRenderState renderState) {
        return ColoredBookModel.BOOK_PAGES_LOCATION;
    }
}
