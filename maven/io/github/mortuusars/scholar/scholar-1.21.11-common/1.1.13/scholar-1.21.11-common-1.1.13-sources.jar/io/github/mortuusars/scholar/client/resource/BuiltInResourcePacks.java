package io.github.mortuusars.scholar.client.resource;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.integration.Mods;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public class BuiltInResourcePacks {
    public static List<Pack> get() {
        List<Pack> packs = new java.util.ArrayList<>();

        packs.add(new Pack(
                Scholar.resource("colored_books"),
                class_2561.method_43471("resourcepack.scholar.colored_books.name"),
                new Activation(ActivationType.DEFAULT_ENABLED)));
        packs.add(new Pack(
                Scholar.resource("chiseled_bookshelf_colored_books"),
                class_2561.method_43471("resourcepack.scholar.chiseled_bookshelf_colored_books.name"),
                new Activation(ActivationType.DEFAULT_ENABLED)));

        if (Mods.MCBV.isLoading()) {
            packs.add(new Pack(
                    Scholar.resource("chiseled_bookshelf_colored_books_lolmcbv_compat"),
                    class_2561.method_43471("resourcepack.scholar.chiseled_bookshelf_colored_books_lolmcbv_compat.name"),
                    new Activation(ActivationType.DEFAULT_ENABLED)));
        }

        if (Mods.WOODWORKS.isLoading()) {
            packs.add(new Pack(
                    Scholar.resource("chiseled_bookshelf_colored_books_abnww_compat"),
                    class_2561.method_43471("resourcepack.scholar.chiseled_bookshelf_colored_books_abnww_compat.name"),
                    new Activation(ActivationType.DEFAULT_ENABLED)));
        }

        if (Mods.WOODSTER.isLoading()) {
            packs.add(new Pack(
                    Scholar.resource("chiseled_bookshelf_colored_books_woodster_compat"),
                    class_2561.method_43471("resourcepack.scholar.chiseled_bookshelf_colored_books_woodster_compat.name"),
                    new Activation(ActivationType.DEFAULT_ENABLED)));
        }

        return packs;
    }

    public record Pack(class_2960 id, class_2561 name, Activation activation) {}

    public record Activation(ActivationType fabric, ActivationType neoforge) {
        public Activation(ActivationType type) {
            this(type, type);
        }
    }

    public enum ActivationType {
        DEFAULT_DISABLED,
        DEFAULT_ENABLED,
        ALWAYS_ENABLED;
    }
}
