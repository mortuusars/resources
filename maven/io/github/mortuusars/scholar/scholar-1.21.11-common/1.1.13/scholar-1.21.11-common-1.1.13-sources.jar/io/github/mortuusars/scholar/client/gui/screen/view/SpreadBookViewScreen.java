package io.github.mortuusars.scholar.client.gui.screen.view;

import com.mojang.datafixers.util.Pair;
import io.github.mortuusars.scholar.book.Spread;
import io.github.mortuusars.scholar.client.gui.screen.SpreadBookScreen;
import net.minecraft.class_11909;
import net.minecraft.class_12225;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_2583;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_5481;
import net.minecraft.class_746;
import net.minecraft.network.chat.*;
import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class SpreadBookViewScreen extends SpreadBookScreen {
    protected BookViewAccess bookAccess;
    protected class_2583 pageTextStyle;
    protected Pair<List<class_5481>, List<class_5481>> cachedPageComponents;
    protected int cachedSpread;

    public SpreadBookViewScreen(BookViewAccess bookAccess, int bookColor) {
        super(bookColor);
        this.bookAccess = bookAccess;
        this.cachedPageComponents = Pair.of(Collections.emptyList(), Collections.emptyList());
        this.cachedSpread = -1;
        this.pageTextStyle = class_2583.field_24360.method_75861().method_36139(textColor);
    }

    public BookViewAccess getBookAccess() {
        return bookAccess;
    }

    public void setBookAccess(BookViewAccess bookViewAccess) {
        this.bookAccess = bookViewAccess;
        this.currentSpread = class_3532.method_15340(this.currentSpread, 0, getSpreadCount());
        this.cachedSpread = -1; // Forces cache update
    }

    @Override
    public int getPageCount() {
        return getBookAccess().getPageCount();
    }

    public boolean setPage(int pageIndex) {
        pageIndex = class_3532.method_15340(pageIndex, 0, getBookAccess().getPageCount() - 1);
        int spreadIndex = (int) (pageIndex / 2f);
        if (spreadIndex != this.currentSpread) {
            this.currentSpread = spreadIndex;
            this.cachedSpread = -1;
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtonVisibility();
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        visitText(guiGraphics.method_75785(class_332.class_12228.field_63852), Spread.Side.LEFT);
        visitText(guiGraphics.method_75785(class_332.class_12228.field_63852), Spread.Side.RIGHT);
    }

    @Override
    public void method_25420(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25420(guiGraphics, mouseX, mouseY, partialTick);
        renderBook(guiGraphics, mouseX, mouseY, partialTick);
        renderPageNumbers(guiGraphics, mouseX, mouseY, partialTick, currentSpread);
        renderTools(guiGraphics, mouseX, mouseY, partialTick);
    }

    protected void updateAndCacheContentsIfNeeded() {
        if (cachedSpread != currentSpread) {
            class_2561 leftComponent = class_2564.method_75859(getBookAccess().getPage(currentSpread * 2), pageTextStyle);
            class_2561 rightComponent = class_2564.method_75859(getBookAccess().getPage(currentSpread * 2 + 1), pageTextStyle);

            cachedPageComponents = Pair.of(
                  field_22793.method_1728(leftComponent, TEXT_WIDTH),
                  field_22793.method_1728(rightComponent, TEXT_WIDTH));

            cachedSpread = currentSpread;
        }
    }

    // --

    @Override
    public boolean method_25402(class_11909 event, boolean isDoubleClick) {
        if (event.method_74245() == 0 && handleTextClick(event, isDoubleClick)) {
            return true;
        }

        return super.method_25402(event, isDoubleClick);
    }

    protected @NotNull Boolean handleTextClick(class_11909 event, boolean isDoubleClick) {
        return getTextSideUnderMouse(event.comp_4798(), event.comp_4799())
              .map(side -> {
                  var clickableStyleFinder = new class_12225.class_12226(field_22793, (int) event.comp_4798(), (int) event.comp_4799());
                  visitText(clickableStyleFinder, side);
                  class_2583 style = clickableStyleFinder.method_75777();
                  return style != null && style.method_10970() != null && handleTextClickEvent(style.method_10970());
              })
              .orElse(false);
    }

    protected boolean handleTextClickEvent(@NotNull class_2558 clickEvent) {
        class_746 localPlayer = Objects.requireNonNull(field_22787.field_1724, "Player not available");
        switch (clickEvent) {
            case class_2558.class_10605(int pageIndex):
                boolean pageChanged = this.setPage(pageIndex);
                if (pageChanged) {
                    playPageTurnSound();
                }
                break;
            case class_2558.class_10609(String command):
                this.method_25419();
                method_71844(localPlayer, command, null);
                break;
            default:
                method_71999(clickEvent, field_22787, this);
        }

        return true;
    }

    protected void visitText(class_12225 collector, Spread.Side side) {
        updateAndCacheContentsIfNeeded();

        List<class_5481> lines = side == Spread.Side.LEFT
              ? cachedPageComponents.getFirst()
              : cachedPageComponents.getSecond();
        int x = leftPos + (side == Spread.Side.LEFT ? TEXT_LEFT_X : TEXT_RIGHT_X);
        int y = topPos + TEXT_Y;

        int maxLines = Math.min(TEXT_HEIGHT / field_22793.field_2000, lines.size());
        for (int i = 0; i < maxLines; i++) {
            class_5481 line = lines.get(i);
            collector.method_75762(x, y + i * field_22793.field_2000, line);
        }
    }

    public Optional<Spread.Side> getTextSideUnderMouse(double mouseX, double mouseY) {
        if (mouseY >= topPos + TEXT_Y && mouseY < topPos + TEXT_Y + TEXT_HEIGHT) {
            if (mouseX >= leftPos + TEXT_LEFT_X && mouseX < leftPos + TEXT_LEFT_X + TEXT_WIDTH) {
                return Optional.of(Spread.Side.LEFT);
            }
            if (mouseX >= leftPos + TEXT_RIGHT_X && mouseX < leftPos + TEXT_RIGHT_X + TEXT_WIDTH) {
                return Optional.of(Spread.Side.RIGHT);
            }
        }
        return Optional.empty();
    }
}