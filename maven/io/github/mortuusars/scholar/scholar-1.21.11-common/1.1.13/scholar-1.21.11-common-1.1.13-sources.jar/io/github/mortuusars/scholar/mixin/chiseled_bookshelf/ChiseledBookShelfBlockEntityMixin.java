package io.github.mortuusars.scholar.mixin.chiseled_bookshelf;

import net.minecraft.class_11362;
import net.minecraft.class_1262;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_7225;
import net.minecraft.class_7716;
import net.minecraft.class_8942;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

/**
 * Sends stored items to client, so it can tint book properly and display bookshelf contents in a tooltip.
 */
@Mixin(class_7716.class)
public abstract class ChiseledBookShelfBlockEntityMixin extends BlockEntityParentMixin {
    @Shadow
    @Final
    private class_2371<class_1799> items;

    @Override
    protected class_2596<class_2602> onGetUpdatePacket(@Nullable class_2596<class_2602> packet) {
        return class_2622.method_38585((class_7716) (Object) this);
    }

    @Override
    protected class_2487 onGetUpdateTag(class_2487 tag, class_7225.class_7874 registries) {
        class_11362 output = class_11362.method_71459(class_8942.field_60348, registries);
        class_1262.method_5427(output, this.items, true);
        return output.method_71475();
    }
}
