package io.github.mortuusars.scholar.network.fabric;

import io.github.mortuusars.scholar.network.packet.C2SPackets;
import io.github.mortuusars.scholar.network.packet.CommonPackets;
import io.github.mortuusars.scholar.network.packet.Packet;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public class FabricC2SPackets {
    @SuppressWarnings("unchecked")
    public static void register() {
        // This monstrosity is to avoid having to define packets for forge and fabric separately.
        for (var definition : C2SPackets.getDefinitions()) {
            PayloadTypeRegistry.playC2S().register(
                    (class_8710.class_9154<class_8710>) definition.type(),
                    (class_9139<class_2540, class_8710>) definition.codec().cast());
            ServerPlayNetworking.registerGlobalReceiver((class_8710.class_9154<Packet>) definition.type(), FabricC2SPackets::handleServerboundPacket);
        }

        for (var definition : CommonPackets.getDefinitions()) {
            PayloadTypeRegistry.playC2S().register(
                    (class_8710.class_9154<class_8710>) definition.type(),
                    (class_9139<class_2540, class_8710>) definition.codec().cast());
            ServerPlayNetworking.registerGlobalReceiver((class_8710.class_9154<Packet>) definition.type(), FabricC2SPackets::handleServerboundPacket);
        }
    }

    private static <T extends Packet> void handleServerboundPacket(T payload, ServerPlayNetworking.Context context) {
        payload.handle(class_2598.field_11941, context.player());
    }

    public static void sendToServer(Packet packet) {
        ClientPlayNetworking.send(packet);
    }
}
