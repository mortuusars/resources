package io.github.mortuusars.scholar.fabric;

import io.netty.buffer.ByteBufUtil;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_9129;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;

public class PlatformHelperImpl {
    public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_9129> extraDataWriter) {
        ExtendedScreenHandlerFactory<byte[]> extendedScreenHandlerFactory = new ExtendedScreenHandlerFactory<byte[]>() {
            @Override
            public byte[] getScreenOpeningData(class_3222 player) {
                class_9129 buffer = new class_9129(PacketByteBufs.create(), player.method_56673());
                extraDataWriter.accept(buffer);
                byte[] bytes = ByteBufUtil.getBytes(buffer);
                buffer.release();
                return bytes;
            }

            @Nullable
            @Override
            public class_1703 createMenu(int i, @NotNull class_1661 inventory, @NotNull class_1657 player) {
                return menuProvider.createMenu(i, inventory, player);
            }

            @Override
            public @NotNull class_2561 getDisplayName() {
                return menuProvider.method_5476();
            }
        };

        serverPlayer.method_17355(extendedScreenHandlerFactory);
    }

    public static boolean isModLoaded(String modId) {
        return FabricLoader.getInstance().isModLoaded(modId);
    }
}
