package io.github.mortuusars.scholar.fabric;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.client.chiseled_bookshelf.BookshelfItemColorsReloadListener;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2960;

public class BookshelfItemColorsReloadListenerFabric extends BookshelfItemColorsReloadListener implements IdentifiableResourceReloadListener {
    public static final class_2960 ID = Scholar.resource("bookshelf_item_colors_reload_listener");
    @Override
    public class_2960 getFabricId() {
        return ID;
    }
}
