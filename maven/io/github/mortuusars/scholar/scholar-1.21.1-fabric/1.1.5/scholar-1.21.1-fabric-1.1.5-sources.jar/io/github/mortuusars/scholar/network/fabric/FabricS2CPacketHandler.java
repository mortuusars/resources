package io.github.mortuusars.scholar.network.fabric;

import io.github.mortuusars.scholar.network.packet.CommonPackets;
import io.github.mortuusars.scholar.network.packet.Packet;
import io.github.mortuusars.scholar.network.packet.S2CPackets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2598;
import net.minecraft.class_8710;

public class FabricS2CPacketHandler {
    @SuppressWarnings("unchecked")
    public static void register() {
        for (var definition : S2CPackets.getDefinitions()) {
            ClientPlayNetworking.registerGlobalReceiver(
                    (class_8710.class_9154<Packet>) definition.type(), FabricS2CPacketHandler::handleClientboundPacket);
        }

        for (var definition : CommonPackets.getDefinitions()) {
            ClientPlayNetworking.registerGlobalReceiver(
                    (class_8710.class_9154<Packet>) definition.type(), FabricS2CPacketHandler::handleClientboundPacket);
        }
    }

    private static <T extends Packet> void handleClientboundPacket(T payload, ClientPlayNetworking.Context context) {
        payload.handle(class_2598.field_11942, context.player());
    }
}
