package io.github.mortuusars.scholar.fabric;

import io.github.mortuusars.scholar.client.chiseled_bookshelf.BookshelfItemColorsReloadListener;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2960;

public class BookshelfItemColorsReloadListenerFabric extends BookshelfItemColorsReloadListener implements IdentifiableResourceReloadListener {
    @Override
    public class_2960 getFabricId() {
        return ID;
    }
}
