package io.github.mortuusars.scholar.mixin;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.client.gui.screen.view.BookViewAccess;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.client.gui.screen.view.InHandSpreadBookViewScreen;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_3895;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class HandleOpenBookClientPacketListenerMixin {
    @Inject(method = "handleOpenBook", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/player/LocalPlayer;getItemInHand(Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/item/ItemStack;"),
            cancellable = true)
    private void handleOpenBook(class_3895 packet, CallbackInfo ci) {
        if (class_310.method_1551().field_1724 == null) return;
        if (!Config.Common.IN_HAND_TWO_PAGE_BOOK_SCREEN.get()) return;
        if (Config.Common.SNEAKING_OPENS_VANILLA_BOOK_SCREEN.get() && class_310.method_1551().field_1724.method_21823()) return;

        class_1268 hand = packet.method_17188();
        class_1799 stack = class_310.method_1551().field_1724.method_5998(hand);

        if (!stack.method_31574(class_1802.field_8360)) return;

        class_310.method_1551().method_1507(new InHandSpreadBookViewScreen(
              BookViewAccess.fromItem(stack),
              BookColor.of(stack),
              packet.method_17188()));

        ci.cancel();
    }
}