package io.github.mortuusars.scholar.network.handler;

import net.minecraft.class_310;

public class ClientPacketsHandler {
    private static void executeOnMainThread(Runnable runnable) {
        class_310.method_1551().execute(runnable);
    }
}
