package io.github.mortuusars.scholar.mixin.chiseled_bookshelf;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

/**
 * This class is used so child classes {@link ChiseledBookShelfBlockEntityMixin}
 * could modify methods in a (hopefully) more compatible with other mods way.
 */
@Mixin(class_2586.class)
public class BlockEntityParentMixin {
    @Shadow @Nullable protected class_1937 level;

    @ModifyReturnValue(method = "getUpdatePacket", at = @At("RETURN"))
    protected @Nullable class_2596<class_2602> onGetUpdatePacket(@Nullable class_2596<class_2602> original) {
        return original;
    }

    @ModifyReturnValue(method = "getUpdateTag", at = @At("RETURN"))
    protected class_2487 onGetUpdateTag(class_2487 original) {
        return original;
    }
}
