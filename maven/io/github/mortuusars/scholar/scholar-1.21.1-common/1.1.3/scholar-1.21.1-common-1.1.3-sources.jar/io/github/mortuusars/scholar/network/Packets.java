package io.github.mortuusars.scholar.network;

import dev.architectury.injectables.annotations.ExpectPlatform;
import io.github.mortuusars.scholar.network.packet.Packet;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class Packets {
    @ExpectPlatform
    public static void sendToServer(Packet packet) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToClient(Packet packet, class_3222 player) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToClients(Packet packet, Predicate<class_3222> filter) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToAllClients(Packet packet) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToPlayersNear(Packet packet, class_3218 level, @Nullable class_3222 excluded,
                                         double x, double y, double z, double radius) {
        throw new AssertionError();
    }

    // --

    public static void sendToOtherClients(@NotNull class_3222 except, Packet packet) {
        except.field_13995.method_3760().method_14571().forEach(player -> {
            if (!player.equals(except)) {
                sendToClient(packet, player);
            }
        });
    }

    public static void sendToPlayersNear(Packet packet, class_3218 level, @Nullable class_3222 excluded,
                                         class_1297 entity, double radius) {
        sendToPlayersNear(packet, level, excluded, entity.method_23317(), entity.method_23318(), entity.method_23321(), radius);
    }
}