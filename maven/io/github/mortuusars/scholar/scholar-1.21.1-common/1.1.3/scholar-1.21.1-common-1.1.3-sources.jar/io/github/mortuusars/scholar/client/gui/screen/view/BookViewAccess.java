package io.github.mortuusars.scholar.client.gui.screen.view;

import com.google.common.collect.ImmutableList;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.IntFunction;
import net.minecraft.class_1799;
import net.minecraft.class_1840;
import net.minecraft.class_1843;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5348;
import net.minecraft.class_9301;
import net.minecraft.class_9302;
import net.minecraft.class_9334;

public interface BookViewAccess {
    BookViewAccess EMPTY = new BookViewAccess() {
        public int getPageCount() {
            return 0;
        }

        public class_5348 getPageRaw(int i) {
            return class_5348.field_25310;
        }
    };

    int getPageCount();
    class_5348 getPageRaw(int pageIndex);

    default class_5348 getPage(int pageIndex) {
        return pageIndex >= 0 && pageIndex < getPageCount() ? getPageRaw(pageIndex) : class_5348.field_25310;
    }

    static BookViewAccess fromItem(class_1799 itemStack) {
        if (itemStack.method_7909() instanceof class_1843) {
            return new WrittenBookAccess(itemStack);
        } else if (itemStack.method_7909() instanceof class_1840) {
            return new WritableBookAccess(itemStack);
        } else {
            return EMPTY;
        }
    }

    static List<String> loadPages(class_2487 compoundTag) {
        ImmutableList.Builder<String> builder = ImmutableList.builder();
        Objects.requireNonNull(builder);
        loadPages(compoundTag, builder::add);
        return builder.build();
    }

    static void loadPages(class_2487 compoundTag, Consumer<String> consumer) {
        class_2499 listTag = compoundTag.method_10554("pages", 8).method_10612();
        IntFunction<String> intFunction;
        if (class_310.method_1551().method_33883() && compoundTag.method_10573("filtered_pages", 10)) {
            class_2487 compoundTag2 = compoundTag.method_10562("filtered_pages");
            intFunction = (ix) -> {
                String string = String.valueOf(ix);
                return compoundTag2.method_10545(string) ? compoundTag2.method_10558(string) : listTag.method_10608(ix);
            };
        } else {
            Objects.requireNonNull(listTag);
            intFunction = listTag::method_10608;
        }

        for (int i = 0; i < listTag.size(); ++i) {
            consumer.accept(intFunction.apply(i));
        }
    }

    class WritableBookAccess implements BookViewAccess {
        private final List<String> pages;

        public WritableBookAccess(class_1799 itemStack) {
            this.pages = readPages(itemStack);
        }

        private static List<String> readPages(class_1799 itemStack) {
            class_9301 content = itemStack.method_57825(class_9334.field_49653, class_9301.field_49369);
            return content.method_57517(class_310.method_1551().method_33883()).toList();
        }

        public int getPageCount() {
            return 100;
        }

        public class_5348 getPageRaw(int i) {
            return i >= pages.size() ? class_5348.field_25310 : class_5348.method_29430(this.pages.get(i));
        }
    }

    class WrittenBookAccess implements BookViewAccess {
        private final List<class_2561> pages;

        public WrittenBookAccess(class_1799 itemStack) {
            this.pages = readPages(itemStack);
        }

        private static List<class_2561> readPages(class_1799 itemStack) {
            class_9302 content = itemStack.method_57825(class_9334.field_49606, class_9302.field_49829);
            return content.method_57525(class_310.method_1551().method_33883());
        }

        public int getPageCount() {
            return this.pages.size();
        }

        public @NotNull class_5348 getPageRaw(int i) {
            return pages.get(i);
        }
    }
}
