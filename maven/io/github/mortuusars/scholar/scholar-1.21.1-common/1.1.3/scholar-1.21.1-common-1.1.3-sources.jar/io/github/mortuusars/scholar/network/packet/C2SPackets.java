package io.github.mortuusars.scholar.network.packet;

import io.github.mortuusars.scholar.network.packet.server.LecternEditBookC2SP;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class C2SPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
                new class_8710.class_9155<>(LecternEditBookC2SP.TYPE, LecternEditBookC2SP.STREAM_CODEC)
        );
    }
}
