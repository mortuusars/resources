package io.github.mortuusars.scholar.client.gui;

import io.github.mortuusars.scholar.Scholar;
import net.minecraft.class_2960;
import net.minecraft.class_8666;

public class Widgets {
    public static final class_8666 PREVIOUS_PAGE_SPRITES =
            threeStateSprites(Scholar.resource("book/previous_page"));
    public static final class_8666 NEXT_PAGE_SPRITES =
            threeStateSprites(Scholar.resource("book/next_page"));

    public static class_8666 threeStateSprites(class_2960 base) {
        return new class_8666(base,
                class_2960.method_60655(base.method_12836(), base.method_12832() + "_disabled"),
                class_2960.method_60655(base.method_12836(), base.method_12832() + "_highlighted"));
    }

    public static class_8666 normalAndHighlightedSprites(class_2960 base) {
        return new class_8666(base, base,
                class_2960.method_60655(base.method_12836(), base.method_12832() + "_highlighted"));
    }
}