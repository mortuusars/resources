package io.github.mortuusars.scholar.mixin;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.menu.Lectern;
import io.github.mortuusars.scholar.menu.LecternSpreadBookEditMenu;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.class_3715;
import net.minecraft.class_3722;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Bumped priority to override Amendments lectern screen. If player has installed Scholar, they probably want it everywhere anyway.
 * If not - it can be disabled in config.
 */
@Mixin(value = class_3715.class, priority = 990)
public abstract class LecternBlockMixin {
    @Inject(method = "openScreen", at = @At(value = "HEAD"), cancellable = true)
    private void openScreen(class_1937 level, class_2338 pos, class_1657 player, CallbackInfo ci) {
        if (!(player instanceof class_3222 serverPlayer)) return;
        if (!(level.method_8321(pos) instanceof class_3722 lecternBlockEntity)) return;
        if (!Config.Common.LECTERN_TWO_PAGE_BOOK_SCREEN.get()) return;
        if (Config.Common.SNEAK_OPENS_VANILLA_BOOK_SCREEN.get() && player.method_21823()) return;

        class_1799 bookStack = lecternBlockEntity.method_17520();

        if (bookStack.method_31574(class_1802.field_8674)) {
            boolean hasPlayerEditing = serverPlayer.method_51469().method_18456().stream()
                    .anyMatch(pl -> pl.field_7512 instanceof LecternSpreadBookEditMenu lecternMenu
                            && lecternMenu.getLecternPos().equals(pos));

            if (hasPlayerEditing) {
                Lectern.openBookViewMenu(serverPlayer, lecternBlockEntity, bookStack);
            } else {
                Lectern.openBookEditMenu(serverPlayer, lecternBlockEntity, bookStack);
            }

            player.method_7281(class_3468.field_17485);
            ci.cancel();
        }

        if (bookStack.method_31574(class_1802.field_8360)) {
            Lectern.openBookViewMenu(serverPlayer, lecternBlockEntity, bookStack);
            player.method_7281(class_3468.field_17485);
            ci.cancel();
        }
    }
}
