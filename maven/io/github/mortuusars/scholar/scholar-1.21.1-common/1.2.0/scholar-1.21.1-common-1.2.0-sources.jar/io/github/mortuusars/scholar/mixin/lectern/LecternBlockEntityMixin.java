package io.github.mortuusars.scholar.mixin.lectern;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.mixin.BlockEntityParentMixin;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_3722;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

/**
 * Sends stored book to clients, so it can be displayed in a tooltip.
 */
@Mixin(class_3722.class)
public abstract class LecternBlockEntityMixin extends BlockEntityParentMixin {
    @Shadow
    class_1799 book;

    @Override
    protected class_2596<class_2602> onGetUpdatePacket(@Nullable class_2596<class_2602> packet) {
        return Config.Common.LECTERN_TOOLTIP.get()
              ? class_2622.method_38585((class_3722) (Object) this)
              : super.onGetUpdatePacket(packet);
    }

    @Override
    protected class_2487 onGetUpdateTag(class_2487 tag, class_7225.class_7874 registries) {
        if (Config.Common.LECTERN_TOOLTIP.get()) {
            class_2487 data = saveCustomOnly(registries);
            if (book.method_7960()) {
                // Empty tag (if book is removed) does not trigger the loadAdditional method on the client block entity,
                // and thus the tooltip shows the book even if it's no longer there. So we add placeholder data to trigger an update.
                data.method_10556("BookIsRemoved", true);
            }
            return data;
        }

        return tag;
    }
}
