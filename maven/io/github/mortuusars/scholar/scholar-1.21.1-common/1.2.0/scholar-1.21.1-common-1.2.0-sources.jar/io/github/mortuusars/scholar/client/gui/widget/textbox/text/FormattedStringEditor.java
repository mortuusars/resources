package io.github.mortuusars.scholar.client.gui.widget.textbox.text;

import io.github.mortuusars.scholar.Scholar;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_1109;
import net.minecraft.class_124;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3414;
import net.minecraft.class_3532;
import net.minecraft.class_3544;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_5225;

public class FormattedStringEditor {
    protected FormattedString string = new FormattedString();
    protected int cursorPos;
    protected int selectionAnchor;
    protected Predicate<String> validator;

    public FormattedStringEditor(Predicate<String> validator) {
        this.validator = validator;
    }

    public FormattedStringEditor(Supplier<Predicate<String>> stringValidator) {
        this.validator = str -> stringValidator.get().test(str);
    }

    public FormattedString getString() {
        return string;
    }

    public void setString(FormattedString string) {
        this.string = string;
    }

    public int getCursorPos() {
        return cursorPos;
    }

    public int getSelectionAnchor() {
        return selectionAnchor;
    }

    public Predicate<String> getValidator() {
        return validator;
    }

    public void setValidator(Predicate<String> validator) {
        this.validator = validator;
    }

    // -- String

    public int length() {
        return getString().size();
    }

    public List<Char> getSpan(int start, int end) {
        return getString().subList(start, end);
    }

    public List<Char> getSelectedSpan() {
        return getSpan(getSelectionStart(), getSelectionEnd());
    }

    // -- Cursor

    public boolean isCursorAtStart() {
        return getCursorPos() == 0;
    }

    public boolean isCursorAtEnd() {
        return getCursorPos() == length();
    }

    public void setCursorPos(int index) {
        setCursorPos(index, true);
    }

    public void setCursorPos(int index, boolean keepSelection) {
        cursorPos = clampIndex(index);
        resetSelectionIfNeeded(keepSelection);
    }

    public void setCursorToStart(boolean keepSelection) {
        setCursorPos(0, keepSelection);
    }

    public void setCursorToEnd(boolean keepSelection) {
        setCursorPos(length(), keepSelection);
    }

    public void moveCursorBy(int direction, boolean keepSelection, CursorStep cursorStep) {
        switch (cursorStep) {
            case CHARACTER -> this.moveCursorByChars(direction, keepSelection);
            case WORD -> this.moveCursorByWords(direction, keepSelection);
        }
    }

    public void moveCursorByChars(int direction, boolean keepSelection) {
        if (!keepSelection && isSelecting()) {
            setCursorPos(direction < 0 ? getSelectionStart() : getSelectionEnd(), false);
        } else {
            setCursorPos(getCursorPos() + direction, keepSelection);
        }
    }

    public void moveCursorByWords(int direction, boolean keepSelection) {
        if (!keepSelection && isSelecting()) {
            setCursorPos(direction < 0 ? getSelectionStart() : getSelectionEnd(), false);
        } else {
            setCursorPos(getWordPosition(direction, true), keepSelection);
        }
    }

    public int getWordPosition(int skipCount, boolean includeWhitespace) {
        int i = getCursorPos();

        boolean backwards = skipCount < 0;
        int count = Math.abs(skipCount);

        for (int k = 0; k < count; k++) {
            if (backwards) {
                while (includeWhitespace && i > 0 && isWhitespace(getString().get(i - 1).codepoint())) {
                    i--;
                }
                while (i > 0 && !isWhitespace(getString().get(i - 1).codepoint())) {
                    i--;
                }

            } else {
                int size = getString().size();
                while (i < size && !isWhitespace(getString().get(i).codepoint())) {
                    i++;
                }
                while (includeWhitespace && i < size && isWhitespace(getString().get(i).codepoint())) {
                    i++;
                }
            }
        }

        return i;
    }

    private static boolean isWhitespace(int cp) {
        return cp == ' '
              || cp == '\n';
    }

    public Formatting getFormattingAtCursor() {
        int charBeforeCursor = getCursorPos() - 1;
        if (charBeforeCursor >= 0 && charBeforeCursor < length()) {
            return getString().get(charBeforeCursor).formatting();
        }
        return Formatting.EMPTY;
    }

    // -- Selection

    public boolean isSelecting() {
        return getCursorPos() != getSelectionAnchor();
    }

    public int getSelectionStart() {
        return Math.min(getCursorPos(), getSelectionAnchor());
    }

    public int getSelectionEnd() {
        return Math.max(getCursorPos(), getSelectionAnchor());
    }

    public void setSelectionAnchor(int index) {
        selectionAnchor = clampIndex(index);
    }

    public void setSelectionRange(int start, int end) {
        setSelectionAnchor(start);
        setCursorPos(end, true);
    }

    public void selectWord(int index) {
        setSelectionRange(
                class_5225.method_27483(getString().toStringWithoutFormatting(), -1, index, false),
                class_5225.method_27483(getString().toStringWithoutFormatting(), 1, index, false));
    }

    public String getSelectedString(boolean withFormatting) {
        if (!isSelecting()) return "";
        FormattedString selectedString = getString().subString(getSelectionStart(), getSelectionEnd());
        return withFormatting ? selectedString.toString() : selectedString.toStringWithoutFormatting();
    }

    // --

    public boolean keyPressed(int key) {
        if (class_437.method_25439(key)) {
            selectAll();
            return true;
        }
        if (key == class_3675.field_32017 && class_437.method_25441() && !class_437.method_25443()) {
            copy(!class_437.method_25442());
            return true;
        }
        if (key == class_3675.field_31911 && class_437.method_25441() && !class_437.method_25443()) {
            paste(!class_437.method_25442());
            return true;
        }
        if (key == class_3675.field_31913 && class_437.method_25441() && !class_437.method_25443()) {
            cut(!class_437.method_25442());
            return true;
        }
        CursorStep cursorStep = class_437.method_25441() ? CursorStep.WORD : CursorStep.CHARACTER;
        if (key == class_3675.field_31986) {
            removeFromCursor(-1, cursorStep);
            return true;
        }
        if (key == class_3675.field_31987) {
            removeFromCursor(1, cursorStep);
            return true;
        }
        if (key == class_3675.field_31983) {
            moveCursorBy(-1, class_437.method_25442(), cursorStep);
            return true;
        }
        if (key == class_3675.field_31984) {
            moveCursorBy(1, class_437.method_25442(), cursorStep);
            return true;
        }
        if (key == class_3675.field_31989) {
            setCursorToStart(class_437.method_25442());
            return true;
        }
        if (key == class_3675.field_31988) {
            setCursorToEnd(class_437.method_25442());
            return true;
        }
        if (key == class_3675.field_31957 || key == class_3675.field_31980) {
            insertTextAtCursor("\n");
            return true;
        }

        @Nullable Formatting formatting = handleFormattingKeys(key);
        if (formatting != null) {
            if (applyFormatting(formatting)) {
                class_3414 sound = formatting.color() != null
                      ? Scholar.SoundEvents.INK.get()
                      : Scholar.SoundEvents.SCRIBBLE.get();
                class_310.method_1551().method_1483().method_4873(class_1109.method_4757(sound, 1, 0.3f));
            }
            return true;
        }

        return false;
    }

    protected @Nullable Formatting handleFormattingKeys(int key) {
        if (class_437.method_25441() && !class_437.method_25442() && !class_437.method_25443()) {
            return switch (key) {
                case class_3675.field_31985 -> Formatting.of(Formatting.Color.BLACK);
                case class_3675.field_32007 -> Formatting.of(Formatting.Color.DARK_BLUE);
                case class_3675.field_32008 -> Formatting.of(Formatting.Color.DARK_GREEN);
                case class_3675.field_32009 -> Formatting.of(Formatting.Color.DARK_AQUA);
                case class_3675.field_32010 -> Formatting.of(Formatting.Color.DARK_RED);
                case class_3675.field_32011 -> Formatting.of(Formatting.Color.DARK_PURPLE);
                case class_3675.field_32012 -> Formatting.of(Formatting.Color.GOLD);
                case class_3675.field_32013 -> Formatting.of(Formatting.Color.GRAY);
                // --
                case class_3675.field_32025 -> Formatting.of(Formatting.Format.OBFUSCATED);
                case class_3675.field_32026 -> Formatting.of(Formatting.Format.BOLD);
                case class_3675.field_32027 -> Formatting.of(Formatting.Format.STRIKETHROUGH);
                case class_3675.field_32028 -> Formatting.of(Formatting.Format.UNDERLINE);
                case class_3675.field_32029 -> Formatting.of(Formatting.Format.ITALIC);
                case class_3675.field_31907 -> Formatting.EMPTY;
                default -> null;
            };
        }

        if (class_437.method_25441() && class_437.method_25442() && !class_437.method_25443()) {
            return switch (key) {
                case class_3675.field_31985 -> Formatting.of(Formatting.Color.DARK_GRAY);
                case class_3675.field_32007 -> Formatting.of(Formatting.Color.BLUE);
                case class_3675.field_32008 -> Formatting.of(Formatting.Color.GREEN);
                case class_3675.field_32009 -> Formatting.of(Formatting.Color.AQUA);
                case class_3675.field_32010 -> Formatting.of(Formatting.Color.RED);
                case class_3675.field_32011 -> Formatting.of(Formatting.Color.LIGHT_PURPLE);
                case class_3675.field_32012 -> Formatting.of(Formatting.Color.YELLOW);
                case class_3675.field_32013 -> Formatting.of(Formatting.Color.WHITE);
                default -> null;
            };
        }

        return null;
    }

    public boolean applyFormatting(Formatting formatting) {
        // Prevents applying bold formatting if the text would overflow available space due to extra width:
        if (formatting.format().contains(Formatting.Format.BOLD)) {
            FormattedString string = new FormattedString(getString().stream().map(c -> new Char(c.codepoint(), c.formatting().copy())).toList());
            List<Char> chars = string.subList(getSelectionStart(), getSelectionEnd());
            chars.replaceAll(c -> c.flipFormatting(formatting));

            if (!validator.test(string.toString())) {
                return false;
            }
        }

        if (isSelecting()) {
            getSelectedSpan().replaceAll(c -> c.flipFormatting(formatting));
        } else if (formatting.isEmpty()) {
            getString().replaceAll(c -> c.withFormatting(Formatting.EMPTY));
        } else {
            return false; // Nothing to format
        }

        return true;
    }

    public boolean charTyped(char character) {
        return class_3544.method_57175(character)
                && insertTextAtCursor(Character.toString(character));
    }

    public void cut(boolean withFormatting) {
        copy(withFormatting);
        removeSelectedText();
    }

    public void paste(boolean withFormatting) {
        try {
            String text = class_310.method_1551().field_1774.method_1460();
            if (!withFormatting) {
                text = class_124.method_539(text);
            }
            insertTextAtCursor(Objects.requireNonNull(text).replaceAll("\\r", ""));
        } catch (Exception e) {
            Scholar.LOGGER.error("Text Paste error: ", e);
        }
    }

    public void copy(boolean withFormatting) {
        class_310.method_1551().field_1774.method_1455(getSelectedString(withFormatting));
    }

    public void selectAll() {
        setSelectionAnchor(0);
        setCursorPos(length(), true);
    }

    // --

    public boolean insertTextAtCursor(String text) {
        if (isSelecting()) {
            removeSelectedText();
        }

        FormattedString insertedString = FormattedString.parse(text);
        insertedString.replaceAll(c -> {
            if (!c.hasFormatting()) {
                return c.withFormatting(getFormattingAtCursor());
            }
            return c;
        });

        FormattedString newString = new FormattedString(getString());
        newString.addAll(getCursorPos(), insertedString);

        String string = newString.toStringWithoutFormatting();
        if (validator.test(string)) {
            this.string = newString;
            setCursorPos(getCursorPos() + insertedString.length(), false);
            return true;
        }

        return false;
    }

    public void removeFromCursor(int direction, CursorStep step) {
        switch (step) {
            case CHARACTER: {
                this.removeCharsFromCursor(direction);
                break;
            }
            case WORD: {
                this.removeWordsFromCursor(direction);
            }
        }
    }

    public void removeWordsFromCursor(int direction) {
        int charsCount = class_5225.method_27483(getString().toStringWithoutFormatting(), direction, this.cursorPos, true);
        this.removeCharsFromCursor(charsCount - this.cursorPos);
    }

    public void removeCharsFromCursor(int direction) {
        String string = getString().toStringWithoutFormatting();
        if (!string.isEmpty()) {
            if (isSelecting()) {
                removeSelectedText();
            } else {
                int cursor = getCursorPos();
                int removePos = cursor + direction;
                int start = Math.min(removePos, cursor);
                int end = Math.max(removePos, cursor);

                getSpan(start, end).clear();
                setCursorPos(start, false);
            }
        }
    }

    public void removeSelectedText() {
        if (!isSelecting()) return;

        int start = getSelectionStart();
        int end = getSelectionEnd();

        getSpan(start, end).clear();
        setCursorPos(start, false);
    }

    // --

    protected void resetSelectionIfNeeded(boolean keepSelection) {
        if (!keepSelection) {
            setSelectionAnchor(getCursorPos());
        }
    }

    protected int clampIndex(int index) {
        return class_3532.method_15340(index, 0, length());
    }

    public enum CursorStep {
        CHARACTER,
        WORD;
    }

    public interface Validator {
        static Predicate<String> fitInDimensions(class_327 font, int width, int height) {
            return string -> string.length() < 1024 && font.method_1713(string, width) + (string.endsWith("\n") ? font.field_2000 : 0) <= height;
        }
    }
}
