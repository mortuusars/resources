package io.github.mortuusars.scholar.mixin.golden;

import io.github.mortuusars.scholar.Scholar;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_9299;
import net.minecraft.class_9322;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

@Mixin(class_1799.class)
public abstract class ItemStackMixin implements class_9322 {
    @Inject(method = "addToTooltip", at = @At("HEAD"), cancellable = true)
    private <T extends class_9299> void onAddToTooltip(class_9331<T> component, class_1792.class_9635 context,
                                                            Consumer<class_2561> tooltipAdder, class_1836 tooltipFlag, CallbackInfo ci) {
        if (component == class_9334.field_49644 && method_57826(Scholar.DataComponents.BOOK_GOLDEN)) {
            tooltipAdder.accept(class_2561.method_43471("gui.scholar.golden").method_27692(class_124.field_1080));
            ci.cancel();
        }
    }
}
