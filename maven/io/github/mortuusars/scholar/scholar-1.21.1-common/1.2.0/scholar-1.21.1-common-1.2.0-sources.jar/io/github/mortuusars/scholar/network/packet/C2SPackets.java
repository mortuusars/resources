package io.github.mortuusars.scholar.network.packet;

import io.github.mortuusars.scholar.network.packet.serverbound.*;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class C2SPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
                new class_8710.class_9155<>(LecternEditBookC2SP.TYPE, LecternEditBookC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(SetBookmarkC2SP.TYPE, SetBookmarkC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(SetCustomAuthorInHandC2SP.TYPE, SetCustomAuthorInHandC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(SetCustomAuthorOnLecternC2SP.TYPE, SetCustomAuthorOnLecternC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(StartedReadingInHandC2SP.TYPE, StartedReadingInHandC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(StoppedReadingInHandC2SP.TYPE, StoppedReadingInHandC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(SetGoldenSkinInHandC2SP.TYPE, SetGoldenSkinInHandC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(SetGoldenSkinOnLecternC2SP.TYPE, SetGoldenSkinOnLecternC2SP.STREAM_CODEC)
        );
    }
}
