package io.github.mortuusars.scholar.mixin.literate_mobs;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.scholar.Scholar;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1297.class)
public class EntityMixin {
    @ModifyReturnValue(method = "spawnAtLocation(Lnet/minecraft/world/item/ItemStack;F)Lnet/minecraft/world/entity/item/ItemEntity;",
          at = @At("RETURN"))
    private class_1542 onSpawnAtLocation(class_1542 original) {
        if (original != null) {
            original.method_6983().method_57381(Scholar.DataComponents.BOOK_OPEN);
        }
        return original;
    }
}
