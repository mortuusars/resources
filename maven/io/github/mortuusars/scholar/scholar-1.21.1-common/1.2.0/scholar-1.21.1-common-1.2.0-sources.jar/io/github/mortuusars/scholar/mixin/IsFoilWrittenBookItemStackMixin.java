package io.github.mortuusars.scholar.mixin;

import io.github.mortuusars.scholar.Config;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public abstract class IsFoilWrittenBookItemStackMixin {
    @Shadow public abstract boolean is(class_1792 item);
    @Shadow public abstract class_1792 getItem();

    @Inject(method = "hasFoil", at = @At("HEAD"), cancellable = true)
    private void onHasFoil(CallbackInfoReturnable<Boolean> cir) {
        if (is(class_1802.field_8360) && Config.Common.WRITTEN_BOOK_ENCHANTMENT_GLINT.isFalse()) {
            cir.setReturnValue(getItem().method_7886((class_1799)(Object)this));
        }
    }
}
