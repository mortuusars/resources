package io.github.mortuusars.scholar.integration.jei;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.constants.RecipeTypes;
import mezz.jei.api.registration.*;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1840;
import net.minecraft.class_1843;
import net.minecraft.class_1856;
import net.minecraft.class_1867;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_3955;
import net.minecraft.class_6880;
import net.minecraft.class_7710;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import net.minecraft.class_9282;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

@JeiPlugin
public class ScholarJeiPlugin implements IModPlugin {
    private static final class_2960 ID = Scholar.resource("jei_plugin");

    @Override
    public @NotNull class_2960 getPluginUid() {
        return ID;
    }

    @Override
    public void registerRecipes(@NotNull IRecipeRegistration registration) {
        if (!Config.Common.JEI_DYEING_RECIPES.get()) {
            return;
        }

        List<class_8786<class_3955>> recipes = new ArrayList<>();

        for (class_1767 color : class_1767.values()) {
            for (class_6880<class_1792> itemHolder : class_7923.field_41178.method_40286(class_3489.field_48803)) {
                if (Config.Common.JEI_DYEING_RECIPES_ONLY_BOOKS.get()
                      && !(itemHolder.comp_349() instanceof class_1840)
                      && !(itemHolder.comp_349() instanceof class_1843)) {
                    continue;
                }

                class_1769 dye = class_1769.method_7803(color);
                class_2371<class_1856> inputs = class_2371.method_10212(class_1856.field_9017,
                      class_1856.method_8091(itemHolder.comp_349()),
                      class_1856.method_8091(dye));
                class_1799 result = class_9282.method_57471(new class_1799(itemHolder), List.of(dye));
                String id = "dyeing_" + itemHolder.comp_349().toString().replace(':', '_') + "_with_" + color.method_7792();
                class_1867 recipe = new class_1867("dyeing_" + color.method_7792(),
                      class_7710.field_40251, result, inputs);
                recipes.add(new class_8786<>(class_2960.method_60656(id), recipe));
            }
        }

        if (!recipes.isEmpty()) {
            registration.addRecipes(RecipeTypes.CRAFTING, recipes);
        }
    }
}