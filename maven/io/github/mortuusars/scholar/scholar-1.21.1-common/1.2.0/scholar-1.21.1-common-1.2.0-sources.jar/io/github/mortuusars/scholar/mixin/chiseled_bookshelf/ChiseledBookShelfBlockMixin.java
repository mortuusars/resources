package io.github.mortuusars.scholar.mixin.chiseled_bookshelf;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_7714;
import net.minecraft.class_7716;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Purpose of this mixin is to update bookshelf immediately on the client,
 * because due to some weird order of updates (probably), tint colors are updated earlier than items are synched -
 * thus color of the new placed book will not be correct.
 */
@Mixin(class_7714.class)
public abstract class ChiseledBookShelfBlockMixin {
    @Inject(method = "addBook", at = @At(value = "RETURN"))
    private static void onAddBook(class_1937 level, class_2338 pos, class_1657 player, class_7716 blockEntity,
                                  class_1799 bookStack, int slot, CallbackInfo ci) {
        if (level.method_8608()) {
            blockEntity.method_5447(slot, bookStack.method_7971(1));
            if (player.method_7337()) {
                bookStack.method_7933(1);
            }
        }
    }
}
