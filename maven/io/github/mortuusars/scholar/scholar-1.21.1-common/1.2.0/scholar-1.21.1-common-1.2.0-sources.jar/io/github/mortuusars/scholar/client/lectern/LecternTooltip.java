package io.github.mortuusars.scholar.client.lectern;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.client.gui.InWorldTooltip;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3722;
import net.minecraft.class_3965;
import net.minecraft.class_9779;

public class LecternTooltip {
    public static boolean render(class_332 guiGraphics, class_9779 deltaTracker) {
        if (!Config.Common.LECTERN_TOOLTIP.get()) {
            return false;
        }

        class_310 minecraft = class_310.method_1551();

        if (minecraft.field_1687 == null || minecraft.field_1724 == null || minecraft.field_1755 != null
              || !(minecraft.field_1765 instanceof class_3965 blockHitResult)
              || !(minecraft.field_1687.method_8321(blockHitResult.method_17777()) instanceof class_3722 lecternBlockEntity)) {
            return false;
        }

        if (Config.Common.TOOLTIP_REQUIRES_SNEAK.get() && !minecraft.field_1724.method_21823()) {
            return false;
        }

        class_1799 bookStack = lecternBlockEntity.method_17520();
        if (bookStack.method_7960()) {
            return false;
        }

        InWorldTooltip.renderItemTooltip(guiGraphics, deltaTracker, bookStack);
        return true;
    }
}
