package io.github.mortuusars.scholar.mixin;

import com.mojang.authlib.GameProfile;
import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.client.gui.screen.edit.InHandSpreadBookEditScreen;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public abstract class OpenWritableBookGuiLocalPlayerMixin extends class_1657 {
    public OpenWritableBookGuiLocalPlayerMixin(class_1937 pLevel, class_2338 pPos, float pYRot, GameProfile pGameProfile) {
        super(pLevel, pPos, pYRot, pGameProfile);
    }

    @Inject(method = "openItemGui", at = @At("HEAD"), cancellable = true)
    private void onOpenItemGui(class_1799 stack, class_1268 hand, CallbackInfo ci) {
        if (!Config.Common.IN_HAND_TWO_PAGE_BOOK_SCREEN.get()) return;
        if (!stack.method_31574(class_1802.field_8674)) return;
        if (Config.Common.SNEAKING_OPENS_VANILLA_BOOK_SCREEN.get() && method_21823()) return;

        class_310.method_1551().method_1507(new InHandSpreadBookEditScreen(stack, hand));
        ci.cancel();
    }
}
