package io.github.mortuusars.scholar;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.scholar.menu.LecternSpreadBookEditMenu;
import io.github.mortuusars.scholar.menu.LecternSpreadMenu;
import io.github.mortuusars.scholar.util.supporter.Supporters;
import org.slf4j.Logger;

import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3902;
import net.minecraft.class_3917;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5699;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9331;

public class Scholar {
    public static final String ID = "scholar";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static class_2960 resource(String path) {
        return class_2960.method_60655(Scholar.ID, path);
    }

    public static void init() {
        DataComponents.init();
        MenuTypes.init();
        RecipeSerializers.init();
        SoundEvents.init();

        // Query supporters early, so it will be available right away when needed
        Supporters.query();
    }

    public static class DataComponents {
        public static final class_9331<Integer> BOOKMARK = Register.dataComponentType("bookmark",
              b -> b.method_57881(class_5699.field_33441).method_57882(class_9135.field_49675));
        public static final class_9331<class_3902> BOOK_OPEN = Register.dataComponentType("book_open",
              b -> b.method_57881(class_3902.field_51563).method_57882(class_9139.method_56431(class_3902.field_17274)));
        public static final class_9331<class_3902> BOOK_GOLDEN = Register.dataComponentType("book_golden",
              b -> b.method_57881(class_3902.field_51563).method_57882(class_9139.method_56431(class_3902.field_17274)));

        static void init() { }
    }

    public static class MenuTypes {
        public static final Supplier<class_3917<LecternSpreadMenu>> LECTERN_SPREAD_BOOK_VIEW =
                Register.menuType("lectern_spread_book_view", LecternSpreadMenu::fromBuffer);
        public static final Supplier<class_3917<LecternSpreadBookEditMenu>> LECTERN_SPREAD_BOOK_EDIT =
                Register.menuType("lectern_spread_book_edit", LecternSpreadBookEditMenu::fromBuffer);

        static void init() { }
    }

    public static class RecipeSerializers {
        static void init() { }
    }

    public static class SoundEvents {
        public static final Supplier<class_3414> BOOK_SIGNED = register("ui", "book_signed");
        public static final Supplier<class_3414> SCRIBBLE = register("ui", "scribble");
        public static final Supplier<class_3414> INK = register("ui", "ink");

        @SuppressWarnings("SameParameterValue")
        private static Supplier<class_3414> register(String category, String key) {
            Preconditions.checkState(category != null && !category.isEmpty(), "'category' should not be empty.");
            Preconditions.checkState(key != null && !key.isEmpty(), "'key' should not be empty.");
            String path = category + "." + key;
            return Register.soundEvent(path, () -> class_3414.method_47908(Scholar.resource(path)));
        }

        static void init() {}
    }

    public static class Tags {
        public static class EntityTypes {
            public static final class_6862<class_1299<?>> LITERATE = class_6862.method_40092(class_7924.field_41266, resource("literate"));
        }
    }

    public static class LootTables {
        public static final class_5321<class_52> LITERATE_MOB_BOOK = class_5321.method_29179(class_7924.field_50079, resource("entities/literate_mob_book"));
    }
}