package io.github.mortuusars.scholar.book;

import io.github.mortuusars.scholar.Scholar;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9282;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import java.util.Collections;
import java.util.Map;

public class BookColor {
    public static Map<class_2960, Integer> ITEM_COLORS = Collections.emptyMap();
    public static final int DEFAULT = 0xFF99452E;

    public static int of(class_1799 stack, int fallback) {
        if (stack.method_57826(Scholar.DataComponents.BOOK_GOLDEN)) {
            return 0xFFFFB83C;
        }
        return class_9282.method_57470(stack, getDefaultColor(stack, fallback));
    }

    public static int of(class_1799 stack) {
        return of(stack, DEFAULT);
    }

    public static int getDefaultColor(class_1799 stack, int fallback) {
        class_2960 itemId = class_7923.field_41178.method_10221(stack.method_7909());
        return ITEM_COLORS.getOrDefault(itemId, fallback);
    }

    public static int getDefaultColor(class_1799 stack) {
        return getDefaultColor(stack, DEFAULT);
    }

    public static int getItemTintColor(class_1799 stack, int tintIndex) {
        if (tintIndex == 1) {
            return of(stack);
        }

        return -1;
    }

    public static void set(class_1799 stack, int color) {
        stack.method_57379(class_9334.field_49644, new class_9282(color, color != DEFAULT));
    }
}