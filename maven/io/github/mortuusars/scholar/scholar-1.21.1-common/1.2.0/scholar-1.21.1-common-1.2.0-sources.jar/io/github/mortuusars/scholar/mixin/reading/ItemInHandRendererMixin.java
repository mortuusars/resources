package io.github.mortuusars.scholar.mixin.reading;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.client.ColoredBookModel;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_557;
import net.minecraft.class_5602;
import net.minecraft.class_759;
import net.minecraft.class_811;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public abstract class ItemInHandRendererMixin {
    @Unique
    private @Nullable class_557 scholar$bookModel;

    @Inject(method = "renderItem", at = @At("HEAD"), cancellable = true)
    private void renderItem(class_1309 entity, class_1799 stack, class_811 displayContext, boolean leftHand,
                            class_4587 poseStack, class_4597 buffer, int seed, CallbackInfo ci) {
        if (Config.Common.BOOK_READING_ANIMATION.get() && stack.method_57826(Scholar.DataComponents.BOOK_OPEN) && displayContext.method_29998()) {
            // Cannot use constructor to initialize book model due to
            // (my guess) entity models not being available at the time of initialization.
            if (scholar$bookModel == null) {
                scholar$bookModel = new class_557(class_310.method_1551().method_31974().method_32072(class_5602.field_27685));
            }
            ColoredBookModel.renderInFirstpersonHand(entity, stack, displayContext, leftHand, poseStack, buffer, seed, scholar$bookModel);
            ci.cancel();
        }
    }
}
