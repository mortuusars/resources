package io.github.mortuusars.scholar.mixin.reading;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.scholar.Scholar;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1657.class)
public class PlayerMixin {
    @ModifyReturnValue(method = "drop(Lnet/minecraft/world/item/ItemStack;ZZ)Lnet/minecraft/world/entity/item/ItemEntity;", at = @At("RETURN"))
    private class_1542 onDrop(@Nullable class_1542 original) {
        if (original != null) {
            original.method_6983().method_57381(Scholar.DataComponents.BOOK_OPEN);
        }
        return original;
    }
}
