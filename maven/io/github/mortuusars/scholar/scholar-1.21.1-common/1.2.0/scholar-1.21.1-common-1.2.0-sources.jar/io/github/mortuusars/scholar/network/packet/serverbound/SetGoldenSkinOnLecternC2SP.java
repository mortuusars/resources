package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.packet.Packet;
import io.github.mortuusars.scholar.util.supporter.Supporters;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3722;
import net.minecraft.class_3902;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SetGoldenSkinOnLecternC2SP(class_2338 lecternPos, boolean golden) implements Packet {
    public static final class_2960 ID = Scholar.resource("set_golden_skin_on_lectern");
    public static final class_9154<SetGoldenSkinOnLecternC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, SetGoldenSkinOnLecternC2SP> STREAM_CODEC = class_9139.method_56435(
          class_2338.field_48404, SetGoldenSkinOnLecternC2SP::lecternPos,
          class_9135.field_48547, SetGoldenSkinOnLecternC2SP::golden,
          SetGoldenSkinOnLecternC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (!(player.method_37908().method_8321(lecternPos) instanceof class_3722 lecternBlockEntity)) {
            Scholar.LOGGER.error("Cannot update lectern book: no lectern block entity at [{}]", lecternPos.method_23854());
            return false;
        }

        class_1799 book = lecternBlockEntity.method_17520();
        if (book.method_31574(class_1802.field_8674) && Supporters.hasAccessToGoldenSkin(player.method_5667())) {
            book.method_57379(Scholar.DataComponents.BOOK_GOLDEN, golden ? class_3902.field_17274 : null);
            lecternBlockEntity.method_5431();

            if (Config.Common.LECTERN_TOOLTIP.get()) {
                List<class_3222> players = serverPlayer.method_51469().method_18456();
                var packet = lecternBlockEntity.method_38235();
                if (packet != null) {
                    players.forEach(pl -> pl.field_13987.method_14364(packet));
                }
            }
        }

        return true;
    }
}
