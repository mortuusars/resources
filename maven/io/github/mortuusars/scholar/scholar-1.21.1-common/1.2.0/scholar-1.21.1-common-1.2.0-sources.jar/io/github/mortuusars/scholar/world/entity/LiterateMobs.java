package io.github.mortuusars.scholar.world.entity;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import java.util.Map;
import net.minecraft.class_1266;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_5819;
import net.minecraft.class_9652;

public class LiterateMobs {
    public static void populateEquipmentSlots(class_5819 random, class_1266 difficulty, class_1308 mob) {
        if (mob.method_5864().method_20210(Scholar.Tags.EntityTypes.LITERATE)
              && random.method_43058() < Config.Common.LITERATE_MOBS_BOOK_SPAWN_CHANCE.get()) {
            float dropChance = (float) Config.Common.LITERATE_MOBS_BOOK_DROP_CHANCE.getAsDouble();
            mob.method_58634(new class_9652(Scholar.LootTables.LITERATE_MOB_BOOK,
                  Map.of(class_1304.field_6173, dropChance, class_1304.field_6171, dropChance)));
        }
    }
}
