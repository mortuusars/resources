package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9302;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;

public record SetCustomAuthorInHandC2SP(int slot, String author) implements Packet {
    public static final class_2960 ID = Scholar.resource("set_custom_author_in_hand");
    public static final class_9154<SetCustomAuthorInHandC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, SetCustomAuthorInHandC2SP> STREAM_CODEC = class_9139.method_56435(
          class_9135.field_48550, SetCustomAuthorInHandC2SP::slot,
          class_9135.method_56364(128), SetCustomAuthorInHandC2SP::author,
          SetCustomAuthorInHandC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (!Config.Common.BOOK_CHANGEABLE_AUTHOR.get()) {
            return true;
        }

        if (class_1661.method_7380(slot) || slot == class_1661.field_30639) {
            class_1799 stack = serverPlayer.method_31548().method_5438(slot);
            if (stack.method_57824(class_9334.field_49606) instanceof class_9302 content) {
                stack.method_57379(class_9334.field_49606, new class_9302(content.comp_2419(),
                      author, content.comp_2421(), content.comp_2422(), content.comp_2423()));
            }
            return true;
        }

        return true;
    }
}
