package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record SetBookmarkC2SP(int slot, int page) implements Packet {
    public static final class_2960 ID = Scholar.resource("set_bookmark");
    public static final class_9154<SetBookmarkC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, SetBookmarkC2SP> STREAM_CODEC = class_9139.method_56435(
          class_9135.field_48550, SetBookmarkC2SP::slot,
          class_9135.field_48550, SetBookmarkC2SP::page,
          SetBookmarkC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (class_1661.method_7380(slot) || slot == class_1661.field_30639) {
            class_1799 stack = serverPlayer.method_31548().method_5438(slot);
            if (page == 0) {
                stack.method_57381(Scholar.DataComponents.BOOKMARK);
            } else {
                stack.method_57379(Scholar.DataComponents.BOOKMARK, page);
            }
            return true;
        }

        return true;
    }
}
