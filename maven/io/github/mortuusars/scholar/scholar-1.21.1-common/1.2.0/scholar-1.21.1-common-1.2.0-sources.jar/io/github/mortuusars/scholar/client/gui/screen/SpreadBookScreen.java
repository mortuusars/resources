package io.github.mortuusars.scholar.client.gui.screen;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.ScholarClient;
import io.github.mortuusars.scholar.client.gui.Widgets;
import io.github.mortuusars.scholar.client.gui.widget.textbox.TextBox;
import io.github.mortuusars.scholar.client.util.RenderUtil;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import net.minecraft.class_1109;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_333;
import net.minecraft.class_3417;
import net.minecraft.class_344;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_746;
import net.minecraft.class_7919;

public abstract class SpreadBookScreen extends class_437 {
    public static final class_2960 TEXTURE = Scholar.resource("textures/gui/book.png");
    public static final class_2960 TEXTURE_GOLDEN = Scholar.resource("textures/gui/book_golden.png");
    public static final int BOOK_WIDTH = 295;
    public static final int BOOK_HEIGHT = 180;
    public static final int TEXT_LEFT_X = 22;
    public static final int TEXT_RIGHT_X = 159;
    public static final int TEXT_Y = 21;
    public static final int TEXT_WIDTH = 114;
    public static final int TEXT_HEIGHT = 128;

    @NotNull
    protected final class_310 field_22787;
    @NotNull
    protected final class_746 player;

    protected int bookColor;
    protected int textColor;
    protected int pageNumbersColor;
    protected int selectionColor;
    protected int selectionUnfocusedColor;

    protected int leftPos;
    protected int topPos;
    protected class_4185 prevPageButton;
    protected class_4185 nextPageButton;

    protected int currentSpread;

    public SpreadBookScreen(int bookColor) {
        super(class_333.field_18967);
        this.field_22787 = class_310.method_1551();
        this.player = Objects.requireNonNull(field_22787.field_1724);
        this.bookColor = bookColor;
        this.textColor = Config.Client.getColor(Config.Client.TEXT_COLOR);
        this.pageNumbersColor = Config.Client.getColor(Config.Client.PAGE_NUMBERS_COLOR);
        this.selectionColor = Config.Client.getColor(Config.Client.SELECTION_COLOR);
        this.selectionUnfocusedColor = Config.Client.getColor(Config.Client.SELECTION_UNFOCUSED_COLOR);
    }

    public abstract boolean isGolden();

    @Override
    public boolean method_25421() {
        return Config.Common.BOOK_SCREEN_PAUSE.get();
    }

    protected void method_25426() {
        this.leftPos = (this.field_22789 - BOOK_WIDTH) / 2;
        this.topPos = (this.field_22790 - BOOK_HEIGHT) / 2;

        createWidgets();
    }

    protected void createWidgets() {
        createPrevPageButton();
        createNextPageButton();
        createBottomButtons();
    }

    protected void createPrevPageButton() {
        class_344 prevPageButton = new class_344(leftPos + 12, topPos + 156, 13, 15,
              Widgets.PREVIOUS_PAGE_SPRITES,
              (button) -> {
                  if (class_437.method_25442()) {
                      pageToStart();
                  } else {
                      pageBack();
                  }
              });
        prevPageButton.method_47400(class_7919.method_47407(class_2561.method_43471("spectatorMenu.previous_page")
              .method_10852(class_5244.field_33849)
              .method_10852(class_2561.method_43471("gui.scholar.shift_jump_to_start"))));
        this.prevPageButton = method_37063(prevPageButton);
    }

    protected void createNextPageButton() {
        class_344 nextPageButton = new class_344(leftPos + 270, topPos + 156, 13, 15,
              Widgets.NEXT_PAGE_SPRITES, (button) -> {
            if (class_437.method_25442()) {
                pageToEnd();
            } else {
                pageForward();
            }
        });
        nextPageButton.method_47400(class_7919.method_47407(class_2561.method_43471("spectatorMenu.next_page")
              .method_10852(class_5244.field_33849)
              .method_10852(class_2561.method_43471("gui.scholar.shift_jump_to_end"))));
        this.nextPageButton = method_37063(nextPageButton);
    }

    protected void createBottomButtons() {
        if (Config.Common.BOOK_SCREEN_SHOW_DONE_BUTTON.get()) {
            method_37063(class_4185.method_46430(class_5244.field_24334, (button) -> method_25419())
                  .method_46434(this.field_22789 / 2 - 60, topPos + BOOK_HEIGHT + 12, 120, 20)
                  .method_46431());
        }
    }

    protected void updateButtons() {
        prevPageButton.field_22764 = currentSpread > 0;
        nextPageButton.field_22764 = currentSpread < getSpreadCount() - 1;
    }

    protected void toggleBookTools() {
        boolean currentValue = Config.Common.EDIT_SCREEN_SHOW_EXTRA_TOOLS.get();
        Config.Common.EDIT_SCREEN_SHOW_EXTRA_TOOLS.set(!currentValue);
        Config.Common.EDIT_SCREEN_SHOW_EXTRA_TOOLS.save();
        Config.Client.TUTORIAL_EXTRA_TOOLS.set(false);
        Config.Client.TUTORIAL_EXTRA_TOOLS.save();
        playButtonClickSound();
        // Implemented in base screen in case some extra functionality would be added in the future.
        // Does nothing in this class currently. Should be implemented in child classes.
    }

    public boolean isToolsVisible() {
        return Config.Common.EDIT_SCREEN_SHOW_EXTRA_TOOLS.get();
    }

    // -- Book

    public int getPageCount() {
        return 100;
    }

    public int getSpreadCount() {
        return (int) Math.ceil(getPageCount() / 2.0);
    }

    public abstract int getLastPage();

    protected abstract int getFirstPageWithContent();

    protected abstract int getLastPageWithContent();

    protected boolean pageBack() {
        if (currentSpread > 0) {
            currentSpread--;
            playPageTurnSound(0.8f);
            return true;
        }
        return false;
    }

    protected boolean pageToStart() {
        if (currentSpread > 0) {
            int firstPageWithContent = getFirstPageWithContent();
            int firstSpreadWithContent = firstPageWithContent / 2;
            setSpread(firstSpreadWithContent < currentSpread ? firstSpreadWithContent : 0);
            playPageTurnSound(0.8f);
            return true;
        }
        return false;
    }

    protected boolean pageForward() {
        if (currentSpread < getSpreadCount() - 1) {
            currentSpread++;
            playPageTurnSound(1f);
            return true;
        }
        return false;
    }

    protected boolean pageToEnd() {
        if (currentSpread < getLastPage() / 2) {
            int lastPageWithContent = getLastPageWithContent();
            int lastSpreadWithContent = lastPageWithContent / 2;
            setSpread(lastSpreadWithContent > currentSpread ? lastSpreadWithContent : getLastPage() / 2);
            playPageTurnSound(1f);
            return true;
        }
        return false;
    }

    public boolean setPage(int pageIndex) {
        pageIndex = class_3532.method_15340(pageIndex, 0, Math.max(0, getPageCount() - 1));
        int spreadIndex = pageIndex / 2;
        return setSpread(spreadIndex);
    }

    public boolean setSpread(int spreadIndex) {
        spreadIndex = class_3532.method_15340(spreadIndex, 0, Math.max(0, getSpreadCount() - 1));
        if (spreadIndex != this.currentSpread) {
            this.currentSpread = spreadIndex;
            return true;
        } else {
            return false;
        }
    }

    // -- Render

    protected void renderBook(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (isGolden()) {
            // Cover
            guiGraphics.method_25293(TEXTURE_GOLDEN, leftPos, topPos, BOOK_WIDTH, BOOK_HEIGHT,
                  0, 0, BOOK_WIDTH, BOOK_HEIGHT, 512, 512);
        } else {
            RenderUtil.withColorMultiplied(bookColor, () -> {
                // Cover
                guiGraphics.method_25293(TEXTURE, leftPos, topPos, BOOK_WIDTH, BOOK_HEIGHT,
                      0, 0, BOOK_WIDTH, BOOK_HEIGHT, 512, 512);
            });
        }

        // Paper
        guiGraphics.method_25293(TEXTURE, leftPos, topPos, BOOK_WIDTH, BOOK_HEIGHT,
              0, BOOK_HEIGHT, BOOK_WIDTH, BOOK_HEIGHT, 512, 512);
    }

    protected void renderPageNumbers(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread) {
        renderLeftPageNumber(guiGraphics, mouseX, mouseY, partialTick, currentSpread, pageNumbersColor);
        renderRightPageNumber(guiGraphics, mouseX, mouseY, partialTick, currentSpread, pageNumbersColor);
    }

    protected void renderLeftPageNumber(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread, int color) {
        String leftPageNumber = Integer.toString(currentSpread * 2 + 1);
        guiGraphics.method_51433(field_22793, leftPageNumber, leftPos + 71 + (8 - field_22793.method_1727(leftPageNumber) / 2),
              topPos + 157, color, false);
    }

    protected void renderRightPageNumber(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread, int color) {
        String rightPageNumber = Integer.toString(currentSpread * 2 + 2);
        guiGraphics.method_51433(field_22793, rightPageNumber, leftPos + 209 + (8 - field_22793.method_1727(rightPageNumber) / 2),
              topPos + 157, color, false);
    }

    protected void renderTools(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
    }

    // -- Input

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (ScholarClient.KeyMappings.toggleBookTools.method_1417(keyCode, scanCode)) {
            toggleBookTools();
            return true;
        }

        if (!(method_25399() instanceof TextBox)) {
            if (class_310.method_1551().field_1690.field_1822.method_1417(keyCode, scanCode)) {
                this.method_25419();
                return true;
            }

            if (keyCode == class_3675.field_31983
                  || keyCode == class_3675.field_31992
                  || class_310.method_1551().field_1690.field_1913.method_1417(keyCode, scanCode)) {
                if (class_437.method_25442()) {
                    pageToStart();
                } else {
                    pageBack();
                }
                return true;
            }

            if (keyCode == class_3675.field_31984
                  || keyCode == class_3675.field_31991
                  || class_310.method_1551().field_1690.field_1849.method_1417(keyCode, scanCode)) {
                if (class_437.method_25442()) {
                    pageToEnd();
                } else {
                    pageForward();
                }
                return true;
            }
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (super.method_25401(mouseX, mouseY, scrollX, scrollY)) {
            return true;
        }

        if (scrollY > 0) {
            if (class_437.method_25442()) {
                pageToStart();
            } else {
                pageBack();
            }
            return true;
        }

        if (scrollY < 0) {
            if (class_437.method_25442()) {
                pageToEnd();
            } else {
                pageForward();
            }
            return true;
        }

        return false;
    }

    // --

    protected boolean isHovering(int x, int y, int width, int height, double mouseX, double mouseY) {
        mouseX -= this.leftPos;
        mouseY -= this.topPos;
        return mouseX >= (double) (x - 1) && mouseX < (double) (x + width + 1) && mouseY >= (double) (y - 1) && mouseY < (double) (y + height + 1);
    }

    protected boolean isHoveringOverRightPageNumber(double mouseX, double mouseY) {
        return isHovering(206, 157, 17, 7, mouseX, mouseY);
    }

    protected boolean isHoveringOverLeftPageNumber(double mouseX, double mouseY) {
        return isHovering(66, 157, 17, 7, mouseX, mouseY);
    }

    protected boolean isLeftPage(int pageIndex) {
        return pageIndex % 2 == 0;
    }

    protected boolean isRightPage(int pageIndex) {
        return pageIndex % 2 == 1;
    }

    protected void playButtonClickSound(float volume, float pitch) {
        class_310.method_1551().method_1483().method_4873(
              class_1109.method_4757(class_3417.field_15015.comp_349(), pitch, volume));
    }

    protected void playButtonClickSound(float pitch) {
        class_310.method_1551().method_1483().method_4873(
              class_1109.method_4757(class_3417.field_15015.comp_349(), pitch, 0.3f));
    }

    protected void playButtonClickSound() {
        class_310.method_1551().method_1483().method_4873(
              class_1109.method_4757(class_3417.field_15015.comp_349(), 1, 0.3f));
    }

    protected void playPageTurnSound(float volume, float pitch) {
        class_310.method_1551().method_1483().method_4873(class_1109.method_4757(class_3417.field_17481, pitch, volume));
    }

    protected void playPageTurnSound(float pitch) {
        class_310.method_1551().method_1483().method_4873(class_1109.method_4757(class_3417.field_17481, pitch, 1f));
    }

    protected void playPageTurnSound() {
        class_310.method_1551().method_1483().method_4873(class_1109.method_4757(class_3417.field_17481, 1f, 1f));
    }
}