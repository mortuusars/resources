package io.github.mortuusars.scholar.client.gui.screen.edit;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookSignature;
import io.github.mortuusars.scholar.client.gui.Widgets;
import io.github.mortuusars.scholar.client.gui.widget.BookmarkButton;
import io.github.mortuusars.scholar.client.gui.widget.textbox.TextBox;
import io.github.mortuusars.scholar.network.Packets;
import io.github.mortuusars.scholar.network.packet.serverbound.*;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2820;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4185;
import net.minecraft.class_7919;

public class InHandSpreadBookEditScreen extends SpreadBookEditScreen {
    protected final class_1268 hand;

    protected BookmarkButton bookmarkButton;

    public InHandSpreadBookEditScreen(class_1799 bookStack, class_1268 hand) {
        super(bookStack);
        this.hand = hand;
        int bookmarkedPage = bookStack.method_57825(Scholar.DataComponents.BOOKMARK, 0);
        setPage(bookmarkedPage);
        Packets.sendToServer(new StartedReadingInHandC2SP(getBookSlot()));
        class_310.method_1551().field_1687.method_43129(player, player, class_3417.field_17481, class_3419.field_15248, 1, 1);
    }

    @Override
    protected void sendGoldenSkinChange(boolean golden) {
        Packets.sendToServer(new SetGoldenSkinInHandC2SP(getBookSlot(), golden));
    }

    protected int getBookSlot() {
        return hand == class_1268.field_5808 ? player.method_31548().field_7545 : class_1661.field_30639;
    }

    @Override
    protected void createExtraToolsButtons() {
        super.createExtraToolsButtons();
        bookmarkButton = method_37063(new BookmarkButton(leftPos + 118, topPos + 2, 20, 20,
              Widgets.threeStateSprites(Scholar.resource("book/bookmark_button_inactive")),
              Widgets.threeStateSprites(Scholar.resource("book/bookmark_button_active")),
              this::pressBookmarkButton,
              class_2561.method_43471("gui.scholar.bookmark")));
    }

    @Override
    protected void updateButtons() {
        super.updateButtons();
        int bookmarkedSpread = bookStack.method_57825(Scholar.DataComponents.BOOKMARK, 0) / 2;
        bookmarkButton.field_22764 = currentSpread != 0 || bookmarkedSpread != 0;
        if (bookmarkButton.field_22764) {
            boolean isAtBookmarkedSpread = bookmarkedSpread == currentSpread;
            bookmarkButton.setExpanded(isAtBookmarkedSpread);

            if (method_25399() instanceof TextBox textBox && textBox.getFormattingToolbar().shouldShow()) {
                // Crude fix to prevent two tooltips rendering at the same time.
                bookmarkButton.method_47400(class_7919.method_47407(class_2561.method_43473()));
            } else {
                bookmarkButton.method_47400(class_7919.method_47407(
                  class_2561.method_43471("gui.scholar.bookmark." + (isAtBookmarkedSpread ? "remove" : "set"))));
            }
        }
    }

    protected void pressBookmarkButton(class_4185 button) {
        int bookmarkedSpread = bookStack.method_57825(Scholar.DataComponents.BOOKMARK, 0) / 2;

        int newBookmarkedPage;

        if (bookmarkedSpread == currentSpread) {
            if (currentSpread == 0) {
                return;
            }
            newBookmarkedPage = 0;
        } else {
            newBookmarkedPage = currentSpread * 2;
        }

        if (newBookmarkedPage == 0) {
            bookStack.method_57381(Scholar.DataComponents.BOOKMARK);
        } else {
            bookStack.method_57379(Scholar.DataComponents.BOOKMARK, newBookmarkedPage);
        }

        int slot = getBookSlot();
        Packets.sendToServer(new SetBookmarkC2SP(slot, newBookmarkedPage));
    }

    @Override
    protected void sendChanges(@Nullable String title) {
        int slot = getBookSlot();
        Objects.requireNonNull(field_22787.method_1562()).method_52787(
              new class_2820(slot, this.pages, Optional.ofNullable(title)));
    }

    @Override
    protected void signBook(BookSignature signature) {
        saveChanges(true, signature.title());
        signature.customAuthor().ifPresent(customAuthor ->
              Packets.sendToServer(new SetCustomAuthorInHandC2SP(getBookSlot(), customAuthor)));
        Packets.sendToServer(new StoppedReadingInHandC2SP(getBookSlot()));
    }

    @Override
    public void method_25419() {
        super.method_25419();
        Packets.sendToServer(new StoppedReadingInHandC2SP(getBookSlot()));
    }
}
