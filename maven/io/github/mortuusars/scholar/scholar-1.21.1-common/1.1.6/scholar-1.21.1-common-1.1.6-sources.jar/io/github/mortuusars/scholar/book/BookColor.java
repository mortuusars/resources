package io.github.mortuusars.scholar.book;

import net.minecraft.class_1799;
import net.minecraft.class_9282;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;

public class BookColor {
    public static final int DEFAULT = 0xFF99452E;

    public static int of(class_1799 stack) {
        return class_9282.method_57470(stack, DEFAULT);
    }

    public static int getItemTintColor(class_1799 stack, int tintIndex) {
        if (tintIndex == 1) {
            return of(stack);
        }

        return -1;
    }

    public static void set(class_1799 stack, int color) {
        stack.method_57379(class_9334.field_49644, new class_9282(color, color != DEFAULT));
    }
}