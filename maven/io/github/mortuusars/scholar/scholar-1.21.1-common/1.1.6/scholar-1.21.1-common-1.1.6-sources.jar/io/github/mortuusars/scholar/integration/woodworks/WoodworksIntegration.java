package io.github.mortuusars.scholar.integration.woodworks;

import dev.architectury.injectables.annotations.ExpectPlatform;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.client.render.ChiseledBookShelf;
import java.util.List;
import java.util.OptionalInt;
import java.util.function.BiConsumer;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_322;

public class WoodworksIntegration {
    public static void registerBlockColors(BiConsumer<class_322, class_2248> consumer) {
        Scholar.LOGGER.info("Registering chiseled bookshelf block colors to 'Woodworks'. " +
                "If Woodworks bookshelves displaying wrongly - try without Scholar installed, and if incompatibility " +
                "is confirmed - report to Scholar github.");

        getChiseledBookshelves().forEach(block -> {
            consumer.accept(ChiseledBookShelf::getSlotTintColor, block);
        });
    }

    public static void setRenderLayer(BiConsumer<class_2248, class_1921> consumer) {
        Scholar.LOGGER.info("Setting 'cutout' render type for 'Woodworks'. " +
                "If Woodworks bookshelves displaying wrongly - try without Scholar installed, and if incompatibility " +
                "is confirmed - report to Scholar github.");

        getChiseledBookshelves().forEach(block -> {
            consumer.accept(block, class_1921.method_23581());
        });
    }

    @ExpectPlatform
    public static List<class_2248> getChiseledBookshelves() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static OptionalInt getDefaultTintColor(class_2680 state, int slot) {
        throw new AssertionError();
    }
//
//    public static OptionalInt getHitSlot(BlockState state, Vec2 hitPos) {
//        if (state.getBlock() instanceof BlueprintChiseledBookShelfBlock block) {
//            return OptionalInt.of(block.m_261279_(hitPos));
//        }
//        return OptionalInt.empty();
//    }
}
