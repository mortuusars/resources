package io.github.mortuusars.scholar.integration.mcbv;

import de.pnku.mcbv.init.McbvBlockInit;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.client.render.ChiseledBookShelf;
import java.util.function.BiConsumer;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_322;

public class MoreChiseledBookshelfVariantsIntegration {
    public static void registerBlockColors(BiConsumer<class_322, class_2248> consumer) {
        Scholar.LOGGER.info("Registering chiseled bookshelf block colors to 'More Chiseled Bookshelf Variants (lolmcbv)'. " +
                "If MCBV bookshelves displaying wrongly - try without Scholar installed, and if incompatibility " +
                "is confirmed - report to Scholar github.");
        consumer.accept(ChiseledBookShelf::getSlotTintColor, McbvBlockInit.SPRUCE_CHISELED_BOOKSHELF);
        consumer.accept(ChiseledBookShelf::getSlotTintColor, McbvBlockInit.BIRCH_CHISELED_BOOKSHELF);
        consumer.accept(ChiseledBookShelf::getSlotTintColor, McbvBlockInit.JUNGLE_CHISELED_BOOKSHELF);
        consumer.accept(ChiseledBookShelf::getSlotTintColor, McbvBlockInit.ACACIA_CHISELED_BOOKSHELF);
        consumer.accept(ChiseledBookShelf::getSlotTintColor, McbvBlockInit.DARK_OAK_CHISELED_BOOKSHELF);
        consumer.accept(ChiseledBookShelf::getSlotTintColor, McbvBlockInit.MANGROVE_CHISELED_BOOKSHELF);
        consumer.accept(ChiseledBookShelf::getSlotTintColor, McbvBlockInit.CHERRY_CHISELED_BOOKSHELF);
        consumer.accept(ChiseledBookShelf::getSlotTintColor, McbvBlockInit.BAMBOO_CHISELED_BOOKSHELF);
        consumer.accept(ChiseledBookShelf::getSlotTintColor, McbvBlockInit.CRIMSON_CHISELED_BOOKSHELF);
        consumer.accept(ChiseledBookShelf::getSlotTintColor, McbvBlockInit.WARPED_CHISELED_BOOKSHELF);
    }

    public static void setRenderLayer(BiConsumer<class_2248, class_1921> consumer) {
        Scholar.LOGGER.info("Setting 'cutout' render type for 'More Chiseled Bookshelf Variants (lolmcbv)'. " +
                "If MCBV bookshelves displaying wrongly - try without Scholar installed, and if incompatibility " +
                "is confirmed - report to Scholar github.");
        consumer.accept(McbvBlockInit.SPRUCE_CHISELED_BOOKSHELF, class_1921.method_23581());
        consumer.accept(McbvBlockInit.BIRCH_CHISELED_BOOKSHELF, class_1921.method_23581());
        consumer.accept(McbvBlockInit.JUNGLE_CHISELED_BOOKSHELF, class_1921.method_23581());
        consumer.accept(McbvBlockInit.ACACIA_CHISELED_BOOKSHELF, class_1921.method_23581());
        consumer.accept(McbvBlockInit.DARK_OAK_CHISELED_BOOKSHELF, class_1921.method_23581());
        consumer.accept(McbvBlockInit.MANGROVE_CHISELED_BOOKSHELF, class_1921.method_23581());
        consumer.accept(McbvBlockInit.CHERRY_CHISELED_BOOKSHELF, class_1921.method_23581());
        consumer.accept(McbvBlockInit.BAMBOO_CHISELED_BOOKSHELF, class_1921.method_23581());
        consumer.accept(McbvBlockInit.CRIMSON_CHISELED_BOOKSHELF, class_1921.method_23581());
        consumer.accept(McbvBlockInit.WARPED_CHISELED_BOOKSHELF, class_1921.method_23581());
    }
}