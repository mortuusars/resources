package io.github.mortuusars.scholar.client.gui.screen.edit;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.ScholarClient;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.book.Spread;
import io.github.mortuusars.scholar.client.gui.Widgets;
import io.github.mortuusars.scholar.client.gui.screen.BookSigningScreen;
import io.github.mortuusars.scholar.client.gui.screen.SpreadBookScreen;
import io.github.mortuusars.scholar.client.gui.widget.textbox.TextBox;
import io.github.mortuusars.scholar.client.gui.widget.textbox.text.FormattedString;
import io.github.mortuusars.scholar.client.gui.widget.textbox.text.FormattedStringEditor;
import io.github.mortuusars.scholar.util.Change;
import io.github.mortuusars.scholar.client.util.FileDialogs;
import io.github.mortuusars.scholar.util.History;
import io.github.mortuusars.scholar.client.util.RenderUtil;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2820;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_7919;
import net.minecraft.class_8666;
import net.minecraft.class_9262;
import net.minecraft.class_9301;
import net.minecraft.class_9302;
import net.minecraft.class_9334;
import net.minecraft.network.chat.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Predicate;

public class SpreadBookEditScreen extends SpreadBookScreen {
    public static final class_8666 ENTER_SIGN_MODE_SPRITES = Widgets.threeStateSprites(Scholar.resource("book/sign_button"));
    public static final class_8666 INSERT_EMPTY_PAGE_SPRITES = Widgets.threeStateSprites(Scholar.resource("book/insert_empty_page_button"));
    public static final class_8666 REMOVE_PAGE_SPRITES = Widgets.threeStateSprites(Scholar.resource("book/remove_page_button"));
    public static final class_8666 IMPORT_BOOK_SPRITES = Widgets.threeStateSprites(Scholar.resource("book/import_book_button"));
    public static final class_8666 EXPORT_BOOK_SPRITES = Widgets.threeStateSprites(Scholar.resource("book/export_book_button"));

    public static final int AUTOMATIC_SAVE_INTERVAL_MS = 60000;

    protected final class_1799 bookStack;
    protected final class_1268 hand;

    protected final List<String> pages = new ArrayList<>();

    protected final History history = new History();

    protected TextBox leftPageTextBox;
    protected TextBox rightPageTextBox;

    protected class_344 insertEmptyPageLeftButton;
    protected class_344 removePageLeftButton;
    protected class_344 insertEmptyPageRightButton;
    protected class_344 removePageRightButton;
    protected class_344 exportBookButton;
    protected class_344 importBookButton;

    protected boolean bookModified;
    protected long lastAutomaticSave = -1;

    public SpreadBookEditScreen(class_1799 bookStack, class_1268 hand) {
        super(BookColor.of(bookStack));
        this.bookStack = bookStack;
        this.hand = hand;
    }

    public History getHistory() {
        return history;
    }

    protected void setupPages(class_1799 bookStack) {
        pages.clear();

        @Nullable class_9301 content = bookStack.method_57824(class_9334.field_49653);
        if (content != null) {
            content.method_57517(class_310.method_1551().method_33883()).forEach(this.pages::add);
        }

        while (this.pages.size() < 2) {
            this.pages.add("");
        }

        setTextBoxes(false);
    }

    @Override
    protected void createWidgets() {
        leftPageTextBox = new TextBox(field_22793, leftPos + TEXT_LEFT_X, topPos + TEXT_Y, TEXT_WIDTH, TEXT_HEIGHT)
                .setFontColor(textColor)
                .setFontUnfocusedColor(textColor)
                .setSelectionColor(selectionColor)
                .setSelectionUnfocusedColor(selectionUnfocusedColor)
                .setText(FormattedString.parse(getPageText(Spread.Side.LEFT)))
                .setOnTextChanged(text -> setPageText(Spread.Side.LEFT, text.toString()));
        method_37063(leftPageTextBox);

        rightPageTextBox = new TextBox(field_22793, leftPos + TEXT_RIGHT_X, topPos + TEXT_Y, TEXT_WIDTH, TEXT_HEIGHT)
                .setFontColor(textColor)
                .setFontUnfocusedColor(textColor)
                .setSelectionColor(selectionColor)
                .setSelectionUnfocusedColor(selectionUnfocusedColor)
                .setText(FormattedString.parse(getPageText(Spread.Side.RIGHT)))
                .setOnTextChanged(text -> setPageText(Spread.Side.RIGHT, text.toString()));
        method_37063(rightPageTextBox);

        setupPages(bookStack);

        createPageToolButtons();

        createPrevPageButton();
        createNextPageButton();

        createImportExportButtons();

        class_344 enterSignModeButton = new class_344(leftPos - 24, topPos + 18, 22, 22,
                ENTER_SIGN_MODE_SPRITES, b -> enterSignMode(), class_2561.method_43471("book.signButton"));
        enterSignModeButton.method_47400(class_7919.method_47407(class_2561.method_43471("book.signButton")));
        method_37063(enterSignModeButton);

        createBottomButtons();
    }

    protected void createPageToolButtons() {
        insertEmptyPageLeftButton = new class_344(leftPos + 112, topPos + 154, 13, 13,
                INSERT_EMPTY_PAGE_SPRITES, b -> insertEmptyPage(Spread.Side.LEFT), class_2561.method_43471("gui.scholar.insert_empty_page"));
        insertEmptyPageLeftButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.scholar.insert_empty_page")
                .method_27693(" ").method_10852(class_2561.method_43471("gui.scholar.insert_empty_page_left.hotkey"))));
        method_37063(insertEmptyPageLeftButton);

        removePageLeftButton = new class_344(leftPos + 126, topPos + 154, 13, 13,
                REMOVE_PAGE_SPRITES, b -> removePage(Spread.Side.LEFT), class_2561.method_43471("gui.scholar.remove_page"));
        removePageLeftButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.scholar.remove_page")
                .method_27693(" ").method_10852(class_2561.method_43471("gui.scholar.remove_page_left.hotkey"))));
        method_37063(removePageLeftButton);

        insertEmptyPageRightButton = new class_344(leftPos + 156, topPos + 154, 13, 13,
                INSERT_EMPTY_PAGE_SPRITES, b -> insertEmptyPage(Spread.Side.RIGHT), class_2561.method_43471("gui.scholar.insert_empty_page"));
        insertEmptyPageRightButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.scholar.insert_empty_page")
                .method_27693(" ").method_10852(class_2561.method_43471("gui.scholar.insert_empty_page_right.hotkey"))));
        method_37063(insertEmptyPageRightButton);

        removePageRightButton = new class_344(leftPos + 170, topPos + 154, 13, 13,
                REMOVE_PAGE_SPRITES, b -> removePage(Spread.Side.RIGHT), class_2561.method_43471("gui.scholar.remove_page"));
        removePageRightButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.scholar.remove_page")
                .method_27693(" ").method_10852(class_2561.method_43471("gui.scholar.remove_page_right.hotkey"))));
        method_37063(removePageRightButton);
    }

    protected void createImportExportButtons() {
        importBookButton = new class_344(leftPos + 297, topPos + 16, 18, 18, IMPORT_BOOK_SPRITES,
                b -> importBook(class_437.method_25442()), class_2561.method_43471("gui.scholar.import_book"));
        importBookButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.scholar.import_book")
                .method_10852(ScholarClient.KeyMappings.componentForTooltip(ScholarClient.KeyMappings.importBook))
                .method_10852(class_5244.field_33849)
                .method_10852(class_2561.method_43471("gui.scholar.import_book.tooltip"))));
        method_37063(importBookButton);

        exportBookButton = new class_344(leftPos + 297, topPos + 41, 18, 18, EXPORT_BOOK_SPRITES,
                b -> exportBook(class_437.method_25442()), class_2561.method_43471("gui.scholar.export_book"));
        exportBookButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.scholar.export_book")
                .method_10852(ScholarClient.KeyMappings.componentForTooltip(ScholarClient.KeyMappings.exportBook))
                .method_10852(class_5244.field_33849)
                .method_10852(class_2561.method_43471("gui.scholar.export_book.tooltip"))));
        method_37063(exportBookButton);
    }

    @Override
    protected void toggleBookTools() {
        super.toggleBookTools();
        playButtonClickSound();
    }

    @Override
    protected void updateButtonVisibility() {
        super.updateButtonVisibility();

        insertEmptyPageLeftButton.field_22764 = isToolsVisible();
        insertEmptyPageLeftButton.field_22763 = canInsertEmptyPage(Spread.Side.LEFT);
        insertEmptyPageRightButton.field_22764 = isToolsVisible();
        insertEmptyPageRightButton.field_22763 = canInsertEmptyPage(Spread.Side.RIGHT);

        removePageLeftButton.field_22764 = isToolsVisible();
        removePageLeftButton.field_22763 = canRemovePage(Spread.Side.LEFT);
        removePageRightButton.field_22764 = isToolsVisible();
        removePageRightButton.field_22763 = canRemovePage(Spread.Side.RIGHT);

        exportBookButton.field_22764 = isToolsVisible();
        exportBookButton.field_22763 = pages.stream().anyMatch(p -> !p.isEmpty());
        importBookButton.field_22764 = isToolsVisible();
    }

    @Override
    public void method_25410(class_310 minecraft, int width, int height) {
        FormattedString leftString = leftPageTextBox.getEditor().getString();
        FormattedString rightString = rightPageTextBox.getEditor().getString();
        super.method_25410(minecraft, width, height);
        leftPageTextBox.getEditor().setString(leftString);
        rightPageTextBox.getEditor().setString(rightString);
    }

    @Override
    public void method_25393() {
        if (!bookModified) {
            return;
        }

        long currentTime = class_156.method_658();
        if (currentTime - lastAutomaticSave > AUTOMATIC_SAVE_INTERVAL_MS) {
            saveChanges(false, null);
            lastAutomaticSave = currentTime;
        }
    }

    // -- Render

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtonVisibility();

        method_52752(guiGraphics);
        renderBook(guiGraphics, mouseX, mouseY, partialTick);
        renderPageNumbers(guiGraphics, mouseX, mouseY, partialTick, currentSpread);
        renderTools(guiGraphics, mouseX, mouseY, partialTick);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        // Stops blur from rendering
    }

    @Override
    protected void renderBook(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        RenderUtil.withColorMultiplied(bookColor, () -> {
            if (isToolsVisible()) {
                // Import/Export buttons BG
                guiGraphics.method_25290(TEXTURE, leftPos + 295, topPos + 14, 0, 388,
                        23, 48, 512, 512);
            }

            // Cover
            guiGraphics.method_25293(TEXTURE, (field_22789 - BOOK_WIDTH) / 2, (field_22790 - BOOK_HEIGHT) / 2, BOOK_WIDTH, BOOK_HEIGHT,
                    0, 0, BOOK_WIDTH, BOOK_HEIGHT, 512, 512);

            // Enter Sign Mode button BG
            guiGraphics.method_25290(TEXTURE, leftPos - 29, topPos + 14, 0, 360,
                    29, 28, 512, 512);
        });

        // Paper
        guiGraphics.method_25293(TEXTURE, (field_22789 - BOOK_WIDTH) / 2, (field_22790 - BOOK_HEIGHT) / 2, BOOK_WIDTH, BOOK_HEIGHT,
                0, 180, BOOK_WIDTH, BOOK_HEIGHT, 512, 512);
    }

    @Override
    protected void renderTools(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int x = field_22789 - 12;
        int y = 6;
        guiGraphics.method_25303(field_22793, "?", x, y, 0xFFAAAAAA);

        if (mouseX >= x - 3 && mouseX < x + 12 + 3 && mouseY >= y - 3 && mouseY < y + 12) {
            List<class_2561> tooltip = new ArrayList<>();
            tooltip.add(class_2561.method_43471("gui.scholar.tools.toggle")
                    .method_10852(ScholarClient.KeyMappings.componentForTooltip(ScholarClient.KeyMappings.toggleBookTools)));
            tooltip.add(class_2561.method_43471("gui.scholar.tools.tooltip.copy_with_formatting"));
            tooltip.add(class_2561.method_43471("gui.scholar.tools.tooltip.paste_with_formatting"));
            tooltip.add(class_2561.method_43471("gui.scholar.tools.tooltip.undo"));
            tooltip.add(class_2561.method_43471("gui.scholar.tools.tooltip.redo"));
            guiGraphics.method_51437(field_22793, tooltip, Optional.empty(), mouseX, mouseY + 20);
        }
    }

    // -- Input

    @Override
    public boolean method_25404(int key, int scanCode, int modifiers) {
        if (ScholarClient.KeyMappings.importBook.method_1417(key, scanCode)) {
            playButtonClickSound();
            importBook(class_437.method_25442());
            return true;
        }

        if (ScholarClient.KeyMappings.exportBook.method_1417(key, scanCode)) {
            playButtonClickSound();
            exportBook(class_437.method_25442());
            return true;
        }

        if (class_437.method_25441() && key == class_3675.field_31915 && !class_437.method_25443()) {
            @Nullable Change change;
            float pitch;

            if (class_437.method_25442()) {
                change = getHistory().redo();
                pitch = change == null ? 1.4f : 0.8f;
            } else {
                change = getHistory().undo();
                pitch = change == null ? 1.8f : 0.95f;
            }

            playButtonClickSound(pitch);
            return true;
        }

        if ((!(method_25399() instanceof TextBox textBox) || !textBox.getEditor().isSelecting())
                && key == class_3675.field_32017 && class_437.method_25441() && !class_437.method_25443()) {
            String bookContents = getBookContents(class_437.method_25442());
            class_310.method_1551().field_1774.method_1455(bookContents);
            return true;
        }

        if (class_437.method_25441() && class_437.method_25442() && key == class_3675.field_31990) {
            insertEmptyPage(class_437.method_25443() ? Spread.Side.RIGHT : Spread.Side.LEFT);
            return true;
        }

        if (class_437.method_25441() && class_437.method_25442() && key == class_3675.field_31987) {
            removePage(class_437.method_25443() ? Spread.Side.RIGHT : Spread.Side.LEFT);
            return true;
        }

        return super.method_25404(key, scanCode, modifiers);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int x = field_22789 - 12;
        int y = 6;
        if (mouseX >= x - 3 && mouseX < x + 12 + 3 && mouseY >= y - 3 && mouseY < y + 12) {
            toggleBookTools();
            return true;
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    // --

    @Override
    protected boolean pageForward() {
        if (super.pageForward()) {
            // Ensure we have pages to display:
            while (this.pages.size() < (currentSpread + 1) * 2) {
                appendEmptyPage();
            }

            setTextBoxes();

            getHistory().add(() -> {
                super.pageForward();
                setTextBoxes();
            }, () -> {
                super.pageBack();
                setTextBoxes();
            });

            return true;
        }
        return false;
    }

    @Override
    protected boolean pageBack() {
        if (super.pageBack()) {
            setTextBoxes();
            getHistory().add(() -> {
                super.pageBack();
                setTextBoxes();
            }, () -> {
                super.pageForward();
                setTextBoxes();
            });
            return true;
        }
        return false;
    }

    protected void setTextBoxes() {
        setTextBoxes(true);
    }

    protected void setTextBoxes(boolean resetCursor) {
        FormattedString leftString = FormattedString.parse(getPageText(Spread.Side.LEFT));
        if (!leftString.equals(leftPageTextBox.getEditor().getString())) {
            leftPageTextBox.getEditor().setString(leftString);
            int leftCursorPos = resetCursor ? 0 : leftPageTextBox.getEditor().getCursorPos();
            leftPageTextBox.getEditor().setCursorPos(leftCursorPos, false);
        }
        leftPageTextBox.getDisplayCache().scheduleUpdate();

        FormattedString rightString = FormattedString.parse(getPageText(Spread.Side.RIGHT));
        if (!rightString.equals(rightPageTextBox.getEditor().getString())) {
            rightPageTextBox.getEditor().setString(rightString);
            int rightCursorPos = resetCursor ? 0 : rightPageTextBox.getEditor().getCursorPos();
            rightPageTextBox.getEditor().setCursorPos(rightCursorPos, false);
        }
        rightPageTextBox.getDisplayCache().scheduleUpdate();
    }

    protected void enterSignMode() {
        saveChanges(false, null);
        field_22787.execute(() ->
            field_22787.method_1507(new BookSigningScreen(this, bookColor, title -> saveChanges(true, title))));
    }

    // --

    protected String getPageText(Spread.Side side) {
        int pageIndex = side.getPageIndexFromSpread(currentSpread);
        return pageIndex >= 0 && pageIndex < this.pages.size() ? this.pages.get(pageIndex) : "";
    }

    protected void setPageText(Spread.Side side, String text) {
        int pageIndex = side.getPageIndexFromSpread(currentSpread);

        // Add empty pages until current page index
        while (pageIndex > pages.size() - 1 && pageIndex < getPageCount()) {
            appendEmptyPage();
        }

        if (pageIndex >= 0 && pageIndex < this.pages.size()) {
            String currentText = getPageText(side);
            getHistory().add(() -> {
                pages.set(pageIndex, text);
                this.bookModified = true;
                setTextBoxes(false);

            }, () -> {
                pages.set(pageIndex, currentText);
                this.bookModified = true;
                setTextBoxes(false);
            });

            this.pages.set(pageIndex, text);
            this.bookModified = true;
        }
    }

    protected void appendEmptyPage() {
        if (this.pages.size() < 100) {
            this.pages.add("");
        }
    }

    protected void insertEmptyPage(Spread.Side side) {
        if (!canInsertEmptyPage(side)) {
            Objects.requireNonNull(class_310.method_1551().field_1724).method_7353(
                    class_2561.method_43471("gui.scholar.cannot_insert_page"), false);
            return;
        }

        int pageIndex = side.getPageIndexFromSpread(currentSpread);

        Change change = Change.create(() -> {
            pages.add(pageIndex, "");
            while (pages.size() >= 100) {
                pages.removeLast();
            }
            setTextBoxes();
            bookModified = true;
            playPageTurnSound(1f, 0.6f);
        }, () -> {
            pages.remove(pageIndex);
            setTextBoxes();
            bookModified = true;
            playPageTurnSound(1f, 0.8f);
        });

        change.apply();
        getHistory().add(change);
    }

    protected void removePage(Spread.Side side) {
        int pageIndex = side.getPageIndexFromSpread(currentSpread);
        String pageContent = pages.get(pageIndex);

        Change change = Change.create(() -> {
            pages.remove(pageIndex);
            while (this.pages.size() < Spread.Side.RIGHT.getPageIndexFromSpread(currentSpread) + 1) {
                this.pages.add("");
            }
            setTextBoxes();
            bookModified = true;
            playPageTurnSound(0.85f, 0.6f);
        }, () -> {
            pages.add(pageIndex, pageContent);
            setTextBoxes();
            bookModified = true;
            playPageTurnSound(0.85f, 0.8f);
        });

        change.apply();
        getHistory().add(change);
    }

    protected void saveChanges(boolean sign, @Nullable String title) {
        if (bookModified || sign) {
            if (!sign) {
                title = null;
            }

            if (title != null && title.length() > class_9302.field_49378) {
                title = title.substring(class_9302.field_49378);
            }

            removeEmptyTrailingPages();
            updateLocalCopy();

            sendChanges(title);
            bookModified = false;
        }
    }

    protected void sendChanges(@Nullable String title) {
        int slotId = hand == class_1268.field_5808 ? player.method_31548().field_7545 : 40;
        Objects.requireNonNull(field_22787.method_1562()).method_52787(
                new class_2820(slotId, this.pages, Optional.ofNullable(title)));
    }

    protected void removeEmptyTrailingPages() {
        ListIterator<String> iterator = this.pages.listIterator(this.pages.size());
        while (iterator.hasPrevious() && iterator.previous().isEmpty()) {
            iterator.remove();
        }
    }

    protected void updateLocalCopy() {
        bookStack.method_57379(class_9334.field_49653,
                new class_9301(this.pages.stream().map(class_9262::method_57137).toList()));
    }

    // --

    protected boolean canInsertEmptyPage(Spread.Side side) {
        int pageIndex = side.getPageIndexFromSpread(currentSpread);
        int lastPageWithContent = getLastPageWithContent().orElse(-1);
        return lastPageWithContent < 99 && pageIndex <= lastPageWithContent;
    }

    protected boolean canRemovePage(Spread.Side side) {
        return containsContentAfter(side.getPageIndexFromSpread(currentSpread));
    }

    protected OptionalInt getLastPageWithContent() {
        for (int i = pages.size() - 1; i >= 0; i--) {
            if (!pages.get(i).isEmpty()) return OptionalInt.of(i);
        }
        return OptionalInt.empty();
    }

    protected boolean containsContentAfter(int pageIndex) {
        return pages.stream().skip(pageIndex).anyMatch(p -> !p.isEmpty());
    }

    public String getBookContents(boolean withFormatting) {
        String contents = String.join("\n", pages);
        if (!withFormatting) {
            class_124.method_539(contents);
        }
        return contents;
    }

    public void setBookContents(String contents, boolean withFormatting) {
        List<String> oldPages = new ArrayList<>(pages);
        pages.clear();

        contents = contents.replaceAll("\\r", "");
        if (!withFormatting) {
            contents = class_124.method_539(contents);
        }
        String[] pages = contents.split("\f");

        Predicate<String> validator = FormattedStringEditor.Validator.fitInDimensions(field_22793, leftPageTextBox.method_25368(), leftPageTextBox.method_25364());

        for (String pageContent : pages) {
            if (pageContent.isEmpty()) {
                this.pages.add("");
                continue;
            }

            FormattedString string = FormattedString.parse(pageContent);

            int currentChar = 0;
            FormattedString currentString = new FormattedString();
            String lastValidString = "";

            while (currentChar < string.length()) {
                currentString.add(string.get(currentChar));
                currentChar++;
                String str = currentString.toString();

                if (!validator.test(str)) {
                    this.pages.add(lastValidString);

                    if (this.pages.size() >= 100) {
                        lastValidString = "";
                        break;
                    }

                    currentChar--;
                    currentString.clear();
                    continue;
                }

                lastValidString = str;
            }

            if (!lastValidString.isEmpty() && this.pages.size() <= 100) {
                this.pages.add(lastValidString);
            }
        }

        bookModified = true;
        setTextBoxes();

        List<String> newPages = new ArrayList<>(this.pages);

        getHistory().add(() -> {
            this.pages.clear();
            this.pages.addAll(newPages);
            bookModified = true;
            setTextBoxes();
        }, () -> {
            this.pages.clear();
            this.pages.addAll(oldPages);
            bookModified = true;
            setTextBoxes();
        });
    }

    public void importBook(boolean withFormatting) {
        CompletableFuture.runAsync(() -> {
            String defaultDirectory = class_310.method_1551().field_1697.toPath().toAbsolutePath().normalize().toString();
            if (!defaultDirectory.endsWith(File.separator)) {
                defaultDirectory = defaultDirectory + File.separator;
            }
            String title = class_2561.method_43471("gui.scholar.import_book").getString();

            FileDialogs.loadFile(defaultDirectory, title, "Text Files (.txt)", false, "*.txt").ifPresent(filePath -> {
                try {
                    String content = Files.readString(Path.of(filePath));
                    class_310.method_1551().execute(() -> setBookContents(content, withFormatting));
                } catch (IOException e) {
                    class_310.method_1551().execute(() -> player.method_7353(
                            class_2561.method_43471("gui.scholar.import_book.failure"), false));
                    Scholar.LOGGER.error("Failed to import book: ", e);
                }
            });
        }).exceptionally(e -> {
            class_310.method_1551().execute(() -> player.method_7353(
                    class_2561.method_43471("gui.scholar.import_book.failure"), false));
            Scholar.LOGGER.error("Failed to import book: ", e);
            return null;
        });
    }

    public void exportBook(boolean withFormatting) {
        String content = withFormatting
                ? String.join("\f", pages)
                : class_124.method_539(String.join("\f", pages));

        CompletableFuture.runAsync(() -> {
            String defaultDirectory = class_310.method_1551().field_1697.toPath().toAbsolutePath().normalize().toString();
            if (!defaultDirectory.endsWith(File.separator)) {
                defaultDirectory = defaultDirectory + File.separator;
            }
            String title = class_2561.method_43471("gui.scholar.export_book").getString();

            FileDialogs.saveFile(defaultDirectory, title, "Text Files (.txt)", "*.txt").ifPresent(filePath -> {
                try {
                    Files.writeString(Path.of(filePath), content, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                    class_5250 filePathComponent = class_2561.method_43470(filePath).method_27696(class_2583.field_24360
                            .method_30938(true)
                            .method_10958(new class_2558(class_2558.class_2559.field_11746, filePath)));
                    class_310.method_1551().execute(() -> player.method_7353(
                            class_2561.method_43471("gui.scholar.export_book.success")
                                    .method_10852(filePathComponent), false));
                } catch (IOException e) {
                    class_310.method_1551().execute(() -> player.method_7353(
                            class_2561.method_43471("gui.scholar.export_book.failure"), false));
                    Scholar.LOGGER.error("Failed to export book: ", e);
                }
            });
        }).exceptionally(e -> {
            class_310.method_1551().execute(() -> player.method_7353(
                    class_2561.method_43471("gui.scholar.export_book.failure"), false));
            Scholar.LOGGER.error("Failed to export book: ", e);
            return null;
        });
    }

    // --

    @Override
    public void method_25419() {
        saveChanges(false, null);
        super.method_25419();
    }
}
