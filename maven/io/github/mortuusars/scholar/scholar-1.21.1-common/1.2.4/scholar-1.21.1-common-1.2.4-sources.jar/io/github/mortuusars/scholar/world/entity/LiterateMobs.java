package io.github.mortuusars.scholar.world.entity;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1266;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_173;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_3218;
import net.minecraft.class_39;
import net.minecraft.class_47;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_8567;

public class LiterateMobs {
    public static void populateEquipmentSlots(class_5819 random, class_1266 difficulty, class_1308 mob) {
        if (mob.method_37908() instanceof class_3218 serverLevel
              && mob.method_5864().method_20210(Scholar.Tags.EntityTypes.LITERATE)
              && random.method_43058() < Config.Common.LITERATE_MOBS_BOOK_SPAWN_CHANCE.get()) {
            float dropChance = (float) Config.Common.LITERATE_MOBS_BOOK_DROP_CHANCE.getAsDouble();
            class_8567 params = new class_8567.class_8568(serverLevel).method_51874(class_181.field_24424, mob.method_19538()).method_51874(class_181.field_1226, mob).method_51875(class_173.field_50217);
            equip(mob, random,
                  Scholar.LootTables.LITERATE_MOB_BOOK, Map.of(class_1304.field_6173, dropChance, class_1304.field_6171, dropChance),
                  params);
        }
    }

    private static void equip(class_1308 mob, class_5819 random, class_5321<class_52> table, Map<class_1304, Float> slotDropChances, class_8567 params) {
        if (table.equals(class_39.field_844)) return;

        class_52 lootTable = params.method_51863().method_8503().method_58576().method_58295(table);
        if (lootTable == class_52.field_948) return;

        List<class_1799> list = new ArrayList<>();
        lootTable.method_320(new class_47.class_48(params).method_60568(random).method_309(Optional.empty()), list::add);
        List<class_1304> excludedSlots = new ArrayList<>();

        for (class_1799 itemStack : list) {
            class_1304 equipmentSlot = mob.method_58633(itemStack, excludedSlots);
            if (equipmentSlot != null) {
                class_1799 itemStack2 = equipmentSlot.method_60610(itemStack);
                mob.method_5673(equipmentSlot, itemStack2);
                @Nullable Float chance = slotDropChances.get(equipmentSlot);
                if (chance != null) {
                    mob.method_5946(equipmentSlot, chance);
                }

                excludedSlots.add(equipmentSlot);
            }
        }
    }
}
