package io.github.mortuusars.scholar.fabric;

import io.github.mortuusars.scholar.PlatformHelper;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.ScholarClient;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.client.gui.screen.edit.LecternSpreadBookEditScreen;
import io.github.mortuusars.scholar.client.gui.screen.view.LecternSpreadBookViewScreen;
import io.github.mortuusars.scholar.client.render.ChiseledBookShelf;
import io.github.mortuusars.scholar.client.resource.BuiltInResourcePacks;
import io.github.mortuusars.scholar.fabric.integration.MoreChiseledBookshelfVariantsCompat;
import io.github.mortuusars.scholar.network.fabric.PacketsImpl;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_3929;

public class ScholarFabricClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlock(class_2246.field_40276, class_1921.method_23581());
        ColorProviderRegistry.BLOCK.register(ChiseledBookShelf::getSlotTintColor, class_2246.field_40276);
        if (PlatformHelper.isModLoaded("lolmcbv")) {
            MoreChiseledBookshelfVariantsCompat.initClient();
        }

        FabricLoader.getInstance().getModContainer(Scholar.ID).ifPresent(container -> {
            for (BuiltInResourcePacks.Pack pack : BuiltInResourcePacks.get()) {
                ResourcePackActivationType activationType = switch (pack.activation().fabric()) {
                    case DEFAULT_DISABLED -> ResourcePackActivationType.NORMAL;
                    case DEFAULT_ENABLED -> ResourcePackActivationType.DEFAULT_ENABLED;
                    case ALWAYS_ENABLED -> ResourcePackActivationType.ALWAYS_ENABLED;
                };
                ResourceManagerHelper.registerBuiltinResourcePack(pack.id(), container, pack.name(), activationType);
            }
        });

        ColorProviderRegistry.ITEM.register(BookColor::getItemTintColor, class_1802.field_8674);
        ColorProviderRegistry.ITEM.register(BookColor::getItemTintColor, class_1802.field_8360);

        ScholarClient.KeyMappings.register(KeyBindingHelper::registerKeyBinding);

        class_3929.method_17542(Scholar.MenuTypes.LECTERN_SPREAD_BOOK_VIEW.get(), LecternSpreadBookViewScreen::new);
        class_3929.method_17542(Scholar.MenuTypes.LECTERN_SPREAD_BOOK_EDIT.get(), LecternSpreadBookEditScreen::new);

        HudRenderCallback.EVENT.register(ChiseledBookShelf::renderSlotTooltip);

        PacketsImpl.registerS2CPackets();
    }
}
