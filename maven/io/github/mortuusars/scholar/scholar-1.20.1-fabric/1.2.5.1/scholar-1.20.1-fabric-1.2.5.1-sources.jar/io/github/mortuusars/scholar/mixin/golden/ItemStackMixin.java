package io.github.mortuusars.scholar.mixin.golden;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.scholar.Scholar;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2487;
import net.minecraft.class_2561;

@Mixin(class_1799.class)
public abstract class ItemStackMixin {
    @Shadow
    @Nullable
    public abstract class_2487 getTag();

    @Inject(method = "getTooltipLines", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getHideFlags()I"))
    private void onGetTooltipLines(class_1657 player, class_1836 isAdvanced, CallbackInfoReturnable<List<class_2561>> cir, @Local List<class_2561> lines) {
        if (getTag() != null && getTag().method_10577(Scholar.NBT.BOOK_GOLDEN)) {
            lines.add(class_2561.method_43471("gui.scholar.golden").method_27692(class_124.field_1080));
        }
    }

    @WrapOperation(method = "getTooltipLines", at = @At(value = "INVOKE",
          target = "Lnet/minecraft/world/item/ItemStack;shouldShowInTooltip(ILnet/minecraft/world/item/ItemStack$TooltipPart;)Z"))
    private boolean onShouldShowInTooltip(int hideFlags, class_1799.class_5422 part, Operation<Boolean> original, @Local List<class_2561> lines) {
        if (part == class_1799.class_5422.field_25774 && getTag() != null && getTag().method_10577(Scholar.NBT.BOOK_GOLDEN)) {
            return false;
        }

        return original.call(hideFlags, part);
    }
}
