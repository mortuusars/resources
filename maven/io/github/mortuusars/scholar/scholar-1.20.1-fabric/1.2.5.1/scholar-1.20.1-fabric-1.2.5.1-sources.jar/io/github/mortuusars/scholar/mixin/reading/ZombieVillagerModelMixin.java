package io.github.mortuusars.scholar.mixin.reading;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.scholar.world.entity.Reading;
import net.minecraft.class_1642;
import net.minecraft.class_3884;
import net.minecraft.class_572;
import net.minecraft.class_619;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_619.class)
public abstract class ZombieVillagerModelMixin<T extends class_1642> extends class_572<T> implements class_3884 {
    public ZombieVillagerModelMixin(class_630 root) {
        super(root);
    }

    @WrapOperation(method = "setupAnim(Lnet/minecraft/world/entity/monster/Zombie;FFFFF)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/AnimationUtils;animateZombieArms(Lnet/minecraft/client/model/geom/ModelPart;Lnet/minecraft/client/model/geom/ModelPart;ZFF)V"))
    private void onSetupAnim(class_630 leftArm, class_630 rightArm, boolean isAggressive,
                             float attackTime, float ageInTicks, Operation<Void> original, @Local(argsOnly = true) T entity) {
        if (Reading.getOpenedBookHand(entity) != null) {
            return; // Stop zombie arms animation, so it wouldn't override ours.
        }

        original.call(leftArm, rightArm, isAggressive, attackTime, ageInTicks);
    }
}
