package io.github.mortuusars.scholar.mixin;

import io.github.mortuusars.scholar.Config;
import net.minecraft.class_1768;
import net.minecraft.class_1799;
import net.minecraft.class_1843;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Adds DyeableLeatherItem interface to written books. This makes it handle most of the coloring stuff automatically.
 * But can potentially introduce unwanted behavior for mods that extend WrittenBookItem for their items.
 */
@Mixin(class_1843.class)
public abstract class WrittenBookItemMixin implements class_1768 {
    @Inject(method = "isFoil", at = @At("HEAD"), cancellable = true)
    private void onIsFoil(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
        if (!Config.Common.WRITTEN_BOOK_ENCHANTMENT_GLINT.get()) {
            cir.setReturnValue(false);
        }
    }
}
