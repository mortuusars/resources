package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.PacketDirection;
import io.github.mortuusars.scholar.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3722;
import org.jetbrains.annotations.Nullable;

public record SetCustomAuthorOnLecternC2SP(class_2338 lecternPos, String author) implements Packet {
    public static final class_2960 ID = Scholar.resource("set_custom_author_on_lectern");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public static SetCustomAuthorOnLecternC2SP fromBuffer(class_2540 buffer) {
        return new SetCustomAuthorOnLecternC2SP(buffer.method_10811(), buffer.method_19772());
    }

    @Override
    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10807(lecternPos);
        buffer.method_10814(author);
        return buffer;
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (!Config.Common.BOOK_CHANGEABLE_AUTHOR.get()) {
            return true;
        }

        if (!(player.method_37908().method_8321(lecternPos) instanceof class_3722 lecternBlockEntity)) {
            Scholar.LOGGER.error("Cannot update lectern book: no lectern block entity at [{}]", lecternPos.method_23854());
            return false;
        }

        if (author.length() > 128) {
            Scholar.LOGGER.error("Cannot handle {} packet: player {} sent author string that's too long: {}. Max 128..", ID, player, author.length());
            return true;
        }

        class_1799 book = lecternBlockEntity.method_17520();
        if (!book.method_31574(class_1802.field_8360)) {
            Scholar.LOGGER.error("Cannot set signing author on a lectern book at [{}]: book is not a written book but '{}'",
                  lecternPos.method_23854(), book);
            return false;
        }

        book.method_7948().method_10582("author", author);
        lecternBlockEntity.method_5431();

        // Manually sending the block data to clients because it doesn't happen when block is changed for some reason
        if (Config.Common.LECTERN_TOOLTIP.get()) {
            var bePacket = lecternBlockEntity.method_38235();
            serverPlayer.method_51469().method_18456().forEach(pl -> {
                if (lecternPos.method_10262(pl.method_24515()) < 128) {
                    pl.field_13987.method_14364(bePacket);
                }
            });
        }

        return true;
    }
}