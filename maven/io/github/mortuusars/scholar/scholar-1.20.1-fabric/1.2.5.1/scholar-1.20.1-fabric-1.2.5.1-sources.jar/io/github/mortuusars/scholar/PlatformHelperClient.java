package io.github.mortuusars.scholar;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_304;

public class PlatformHelperClient {
    @ExpectPlatform
    public static class_304 createInsertEmptyPageLeftKeyMapping() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static class_304 createRemovePageLeftKeyMapping() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static class_304 createInsertEmptyPageRightKeyMapping() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static class_304 createRemovePageRightKeyMapping() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean matchesWithModifiers(class_304 keyMapping, int keyCode, int scancode, int modifiers) {
        throw new AssertionError();
    }
}
