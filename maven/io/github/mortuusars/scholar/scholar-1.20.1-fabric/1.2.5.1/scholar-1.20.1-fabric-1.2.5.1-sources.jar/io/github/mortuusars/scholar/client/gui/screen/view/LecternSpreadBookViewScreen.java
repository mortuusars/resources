package io.github.mortuusars.scholar.client.gui.screen.view;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.menu.LecternSpreadMenu;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1712;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3916;
import net.minecraft.class_3936;
import net.minecraft.class_4185;
import net.minecraft.class_5244;
import org.jetbrains.annotations.NotNull;

public class LecternSpreadBookViewScreen extends SpreadBookViewScreen implements class_3936<LecternSpreadMenu> {
    protected final LecternSpreadMenu menu;
    protected final class_1712 listener = new class_1712() {
        @Override
        public void method_7635(class_1703 menu, int dataSlotIndex, class_1799 stack) {
            LecternSpreadBookViewScreen.this.bookChanged(stack);
        }

        @Override
        public void method_7633(class_1703 menu, int dataSlotIndex, int pageIndex) {
            if (dataSlotIndex == 0) {
                LecternSpreadBookViewScreen.this.updatePage(pageIndex);
            }
        }
    };

    public LecternSpreadBookViewScreen(LecternSpreadMenu lecternSpreadMenu, class_1661 inventory, class_2561 component) {
        super(BookViewAccess.fromItem(lecternSpreadMenu.method_17418()), BookColor.of(lecternSpreadMenu.method_17418()));
        this.menu = lecternSpreadMenu;
    }

    @Override
    public @NotNull LecternSpreadMenu method_17577() {
        return menu;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        method_17577().method_7596(listener);
    }

    @Override
    protected void createBottomButtons() {
        if (player.method_7294()) {
            if (Config.Common.BOOK_SCREEN_SHOW_DONE_BUTTON.get()) {
                this.method_37063(class_4185.method_46430(class_5244.field_24334,
                        button -> this.method_25419()).method_46434(this.field_22789 / 2 - 100, topPos + BOOK_HEIGHT + 12, 98, 20).method_46431());
                this.method_37063(class_4185.method_46430(class_2561.method_43471("lectern.take_book"),
                        button -> this.sendButtonClick(3)).method_46434(this.field_22789 / 2 + 2, topPos + BOOK_HEIGHT + 12, 98, 20).method_46431());
            } else {
                this.method_37063(class_4185.method_46430(class_2561.method_43471("lectern.take_book"),
                        (button) -> this.sendButtonClick(3)).method_46434(this.field_22789 / 2 - 60, topPos + BOOK_HEIGHT + 12, 120, 20).method_46431());
            }
        } else {
            super.createBottomButtons();
        }
    }

    @Override
    protected boolean pageBack() {
        this.sendButtonClick(class_3916.field_30820);
        return true;
    }

    @Override
    protected boolean pageForward() {
        this.sendButtonClick(class_3916.field_30821);
        return true;
    }

    @Override
    public boolean setPage(int pageIndex) {
        if (pageIndex != method_17577().method_17419()) {
            sendPageIndex(pageIndex);
            return true;
        }
        return false;
    }

    protected void bookChanged(class_1799 stack) {
        this.setBookAccess(BookViewAccess.fromItem(stack));
    }

    protected void updatePage(int pageIndex) {
        super.setPage(pageIndex);
    }

    // --

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        renderPageTooltip(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void renderLeftPageNumber(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread, int color) {
        if (isRightPage(method_17577().method_17419()) && isHoveringOverLeftPageNumber(mouseX, mouseY)) {
            color = textColor;
        }
        super.renderLeftPageNumber(guiGraphics, mouseX, mouseY, partialTick, currentSpread, color);
    }

    @Override
    protected void renderRightPageNumber(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int currentSpread, int color) {
        int page = method_17577().method_17419();
        if (page < getPageCount() - 1 && isLeftPage(page) && isHoveringOverRightPageNumber(mouseX, mouseY)) {
            color = textColor;
        }
        super.renderRightPageNumber(guiGraphics, mouseX, mouseY, partialTick, currentSpread, color);
    }

    protected void renderPageTooltip(class_332 guiGraphics, int x, int y) {
        int page = method_17577().method_17419();
        if ((isRightPage(page) && isHoveringOverLeftPageNumber(x, y))
                || (page < getPageCount() - 1 && isLeftPage(page) && isHoveringOverRightPageNumber(x, y))) {
            guiGraphics.method_51438(field_22793, class_2561.method_43471("gui.scholar.lectern.set_current_page"), x, y);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int page = method_17577().method_17419();
        if (isRightPage(page) && isHoveringOverLeftPageNumber(mouseX, mouseY)) {
            sendButtonClick(class_3916.field_30823 + page - 1);
        } else if (page < getPageCount() - 1 && isLeftPage(page) && isHoveringOverRightPageNumber(mouseX, mouseY)) {
            sendButtonClick(class_3916.field_30823 + page + 1);
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    // --

    @Override
    public void method_25432() {
        super.method_25432();
        method_17577().method_7603(listener);
    }

    @Override
    public void method_25419() {
        player.method_7346();
        super.method_25419();
    }

    // --

    protected void sendPageIndex(int pageIndex) {
        sendButtonClick(100 + pageIndex);
    }

    protected void sendButtonClick(int buttonId) {
        if (class_310.method_1551().field_1761 != null) {
            class_310.method_1551().field_1761.method_2900(this.menu.field_7763, buttonId);
        }
    }
}
