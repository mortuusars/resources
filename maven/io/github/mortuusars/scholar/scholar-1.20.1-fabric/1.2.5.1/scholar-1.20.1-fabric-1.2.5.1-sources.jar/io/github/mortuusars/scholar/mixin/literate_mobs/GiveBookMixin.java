package io.github.mortuusars.scholar.mixin.literate_mobs;

import io.github.mortuusars.scholar.world.entity.LiterateMobs;
import net.minecraft.class_1266;
import net.minecraft.class_1308;
import net.minecraft.class_1547;
import net.minecraft.class_1590;
import net.minecraft.class_1604;
import net.minecraft.class_1642;
import net.minecraft.class_4836;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = {class_1642.class, class_1547.class, class_4836.class, class_1590.class, class_1604.class})
public class GiveBookMixin {
    @Inject(method = "populateDefaultEquipmentSlots", at = @At("RETURN"))
    private void onPopulateDefaultEquipmentSlots(class_5819 random, class_1266 difficulty, CallbackInfo ci) {
        LiterateMobs.populateEquipmentSlots(random, difficulty, (class_1308) (Object) this);
    }
}
