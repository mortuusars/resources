package io.github.mortuusars.scholar.world.entity;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import net.minecraft.class_1268;
import net.minecraft.class_1308;
import net.minecraft.class_1352;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3417;

public class ReadBookGoal extends class_1352 {
    private final class_1308 mob;
    private int readingTime;
    private int readingDuration;

    public ReadBookGoal(class_1308 mob) {
        this.mob = mob;
    }

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public boolean method_6264() {
        if (Reading.getOpenedBookHand(mob) != null) {
            method_6270(); // Closes the book properly after world reload or something.
        }
        return canRead() && mob.method_6051().method_43057() < Config.Common.LITERATE_MOBS_BOOK_READING_CHANCE.get();
    }

    public boolean canRead() {
        return mob.method_5864().method_20210(Scholar.Tags.EntityTypes.LITERATE)
              && mob.method_5968() == null
              && !mob.method_5721()
              && !mob.method_5942().method_23966()
              && !mob.method_5809()
              && isReadableBook(mob.method_6047());
    }

    @Override
    public boolean method_6266() {
        return readingTime < readingDuration && canRead();
    }

    @Override
    public void method_6269() {
        mob.method_6047().method_7948().method_10556(Scholar.NBT.BOOK_OPEN, true);
        mob.method_5783(class_3417.field_17481, 0.6f, 1.1f);
        mob.method_6104(class_1268.field_5808);
        readingTime = 0;
        readingDuration = 300 + mob.method_6051().method_43048(10) * 20;
    }

    @Override
    public void method_6268() {
        readingTime++;
    }

    @Override
    public void method_6270() {
        if (mob.method_6047().method_7969() != null) {
            mob.method_6047().method_7969().method_10551(Scholar.NBT.BOOK_OPEN);
        }
        mob.method_5783(class_3417.field_17481, 0.6f, 0.75f);
        mob.method_6104(class_1268.field_5808);
    }

    // --

    public static boolean isReadableBook(class_1799 stack) {
        return stack.method_31574(class_1802.field_8529) || stack.method_31574(class_1802.field_8360) || stack.method_31574(class_1802.field_8674);
    }

    public static int getPriority(class_1308 mob) {
        return 7;
    }
}
