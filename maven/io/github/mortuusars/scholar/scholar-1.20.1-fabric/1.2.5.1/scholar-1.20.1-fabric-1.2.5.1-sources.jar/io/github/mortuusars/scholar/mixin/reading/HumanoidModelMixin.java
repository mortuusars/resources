package io.github.mortuusars.scholar.mixin.reading;

import io.github.mortuusars.scholar.client.animation.ReadingAnimation;
import io.github.mortuusars.scholar.world.entity.Reading;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_4592;
import net.minecraft.class_5498;
import net.minecraft.class_572;
import net.minecraft.class_630;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_572.class)
public abstract class HumanoidModelMixin<T extends class_1309> extends class_4592<T> {
    @Shadow
    @Final
    public class_630 leftArm;
    @Shadow
    @Final
    public class_630 rightArm;

    @Shadow
    @Final
    public class_630 head;

    @Shadow
    @Final
    public class_630 body;

    @Inject(method = "poseLeftArm", at = @At("HEAD"), cancellable = true)
    private void poseLeftArm(T entity, CallbackInfo ci) {
        if (entity == class_310.method_1551().field_1719
              && class_310.method_1551().field_1690.method_31044() == class_5498.field_26664) {
            return;
        }

        @Nullable class_1268 openedBookHand = Reading.getOpenedBookHand(entity);
        if (openedBookHand == null) {
            return;
        }

        class_1306 openedBookArm = openedBookHand == class_1268.field_5808
              ? entity.method_6068()
              : entity.method_6068().method_5928();
        boolean isHoldingArm = openedBookArm == class_1306.field_6182;
        ReadingAnimation.poseLeftArm(entity, leftArm, isHoldingArm);
        ci.cancel();
    }

    @Inject(method = "poseRightArm", at = @At("HEAD"), cancellable = true)
    private void poseRightArm(T entity, CallbackInfo ci) {
        if (entity == class_310.method_1551().field_1719
              && class_310.method_1551().field_1690.method_31044() == class_5498.field_26664) {
            return;
        }

        @Nullable class_1268 openedBookHand = Reading.getOpenedBookHand(entity);
        if (openedBookHand == null) {
            return;
        }

        class_1306 openedBookArm = openedBookHand == class_1268.field_5808
              ? entity.method_6068()
              : entity.method_6068().method_5928();
        boolean isHoldingArm = openedBookArm == class_1306.field_6183;
        ReadingAnimation.poseRightArm(entity, rightArm, isHoldingArm);
        ci.cancel();
    }

    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/HumanoidModel;setupAttackAnimation(Lnet/minecraft/world/entity/LivingEntity;F)V"))
    void onSetupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci) {
        @Nullable class_1268 openedBookHand = Reading.getOpenedBookHand(entity);
        if (openedBookHand == null) {
            return;
        }

        ReadingAnimation.poseHead(entity, ageInTicks, headPitch, openedBookHand, body, head);
    }
}