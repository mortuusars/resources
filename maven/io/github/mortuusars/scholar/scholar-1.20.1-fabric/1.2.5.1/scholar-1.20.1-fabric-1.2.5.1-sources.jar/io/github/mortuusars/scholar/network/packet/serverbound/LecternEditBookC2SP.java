package io.github.mortuusars.scholar.network.packet.serverbound;

import com.google.common.collect.Lists;
import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.PacketDirection;
import io.github.mortuusars.scholar.network.packet.Packet;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3722;
import net.minecraft.class_5513;
import net.minecraft.class_5837;

/**
 * Similar to {@link net.minecraft.class_2820} but for lecterns.
 * Contains logic copied from {@link net.minecraft.class_3244}, which is not ideal, but hopefully it'll not cause any issues.
 */
public record LecternEditBookC2SP(class_2338 lecternPos, List<String> pages, Optional<String> title) implements Packet {
    public static final class_2960 ID = Scholar.resource("lectern_edit_book");

    private static final int TITLE_MAX_CHARS = 128;
    private static final int PAGE_MAX_CHARS = 8192;
    private static final int MAX_PAGES_COUNT = 200;

    @Override
    public class_2960 getId() {
        return ID;
    }

    public static LecternEditBookC2SP fromBuffer(class_2540 buffer) {
        return new LecternEditBookC2SP(
                buffer.method_10811(),
                buffer.method_34068(class_2540.method_37453(Lists::newArrayListWithCapacity, MAX_PAGES_COUNT),
                        friendlyByteBuf -> friendlyByteBuf.method_10800(PAGE_MAX_CHARS)),
                buffer.method_37436(friendlyByteBuf -> friendlyByteBuf.method_10800(TITLE_MAX_CHARS)));
    }

    @Override
    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10807(lecternPos);
        buffer.method_34062(pages, (friendlyByteBuf, string) -> friendlyByteBuf.method_10788(string, PAGE_MAX_CHARS));
        buffer.method_37435(title, (friendlyByteBuf, string) -> friendlyByteBuf.method_10788(string, TITLE_MAX_CHARS));
        return buffer;
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", getId());
            return true;
        }

        if (!(player.method_37908().method_8321(lecternPos) instanceof class_3722 lecternBlockEntity)) {
            Scholar.LOGGER.error("Cannot update lectern book: no lectern block entity at lecternPos '{}'", lecternPos);
            return false;
        }

        ArrayList<String> bookPages = new ArrayList<>();
        Optional<String> title = title();
        title.ifPresent(bookPages::add);
        pages().stream().limit(100L).forEach(bookPages::add);
        Consumer<List<class_5837>> consumer = title.isPresent()
              ? list -> signBook(serverPlayer, list.get(0), list.subList(1, list.size()), lecternBlockEntity)
              : list -> updateBookContents(serverPlayer, list, lecternBlockEntity);
        this.filterTextPacket(serverPlayer,bookPages).thenAccept(consumer);

        return true;
    }

    private void updateBookContents(class_3222 player, List<class_5837> pages, class_3722 lecternBlockEntity) {
        class_1799 itemStack = lecternBlockEntity.method_17520();
        if (!itemStack.method_31574(class_1802.field_8674)) return;
        updateBookPages(player, pages, UnaryOperator.identity(), itemStack, lecternBlockEntity);
    }

    private void signBook(class_3222 player, class_5837 title, List<class_5837> pages, class_3722 lecternBlockEntity) {
        class_1799 itemStack = lecternBlockEntity.method_17520();

        if (!itemStack.method_31574(class_1802.field_8674)) return;

        class_1799 writtenBookStack = new class_1799(class_1802.field_8360);
        class_2487 compoundTag = itemStack.method_7969();
        if (compoundTag != null) {
            writtenBookStack.method_7980(compoundTag.method_10553());
        }
        writtenBookStack.method_7959("author", class_2519.method_23256(player.method_5477().getString()));
        if (player.method_33793()) {
            writtenBookStack.method_7959("title", class_2519.method_23256(title.method_45061()));
        } else {
            writtenBookStack.method_7959("filtered_title", class_2519.method_23256(title.method_45061()));
            writtenBookStack.method_7959("title", class_2519.method_23256(title.comp_841()));
        }

        this.updateBookPages(player, pages, string -> class_2561.class_2562.method_10867(class_2561.method_43470(string)), writtenBookStack, lecternBlockEntity);

        lecternBlockEntity.method_17514(writtenBookStack, player);

        if (Config.Common.LECTERN_TOOLTIP.get()) {
            // Wanna hear about how frustrating minecraft is sometimes?
            // Without this sh*t block entity just refuses to update no matter what I try.
            // blockEntity.setChanged, level.sendBlockUpdated, level.setBlock - nothing works.
            // And because of that the old book is still showing in the tooltip.
            // 40 minutes of my life has been broadcasted down the drain.
            List<class_3222> players = player.method_51469().method_18456();
            net.minecraft.class_2596<?> packet = lecternBlockEntity.method_38235();
            if (packet != null) {
                players.forEach(serverPlayer -> serverPlayer.field_13987.method_14364(packet));
            }
        }
    }

    private void updateBookPages(class_3222 player, List<class_5837> pages, UnaryOperator<String> updater, class_1799 book, class_3722 lecternBlockEntity) {
        class_2499 listTag = new class_2499();
        if (player.method_33793()) {
            pages.stream().map(filteredText -> class_2519.method_23256(updater.apply(filteredText.method_45061()))).forEach(listTag::add);
        } else {
            class_2487 compoundTag = new class_2487();
            int j = pages.size();
            for (int i = 0; i < j; ++i) {
                class_5837 filteredText2 = pages.get(i);
                String string = filteredText2.comp_841();
                listTag.add(class_2519.method_23256(updater.apply(string)));
                if (!filteredText2.method_45063()) continue;
                compoundTag.method_10582(String.valueOf(i), updater.apply(filteredText2.method_45061()));
            }
            if (!compoundTag.method_33133()) {
                book.method_7959("filtered_pages", compoundTag);
            }
        }
        book.method_7959("pages", listTag);
    }

    private <T, R> CompletableFuture<R> filterTextPacket(class_3222 player, T message, BiFunction<class_5513, T, CompletableFuture<R>> processor) {
        return processor.apply(player.method_31273(), message).thenApply(object -> {
            if (!player.field_13987.method_48106()) {
                Scholar.LOGGER.debug("Ignoring packet due to disconnection");
                throw new CancellationException("disconnected");
            }
            return object;
        });
    }

    private CompletableFuture<List<class_5837>> filterTextPacket(class_3222 player, List<String> texts) {
        return this.filterTextPacket(player, texts, class_5513::method_31289);
    }
}
