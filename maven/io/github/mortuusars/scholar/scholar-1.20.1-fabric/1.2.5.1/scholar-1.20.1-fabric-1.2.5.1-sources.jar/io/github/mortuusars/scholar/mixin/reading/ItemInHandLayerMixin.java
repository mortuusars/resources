package io.github.mortuusars.scholar.mixin.reading;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.client.ColoredBookModel;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3881;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_557;
import net.minecraft.class_5602;
import net.minecraft.class_583;
import net.minecraft.class_759;
import net.minecraft.class_811;
import net.minecraft.class_989;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_989.class)
public abstract class ItemInHandLayerMixin<T extends class_1309, M extends class_583<T> & class_3881> extends class_3887<T, M> {
    @Unique
    private class_557 scholar$bookModel;

    public ItemInHandLayerMixin(class_3883<T, M> renderer) {
        super(renderer);
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInit(class_3883<T, M> renderer, class_759 itemInHandRenderer, CallbackInfo ci) {
        scholar$bookModel = new class_557(class_310.method_1551().method_31974().method_32072(class_5602.field_27685));
    }

    @Inject(method = "renderArmWithItem", at = @At("HEAD"), cancellable = true)
    private void onRenderArmWithItem(class_1309 entity, class_1799 stack, class_811 displayContext,
                                     class_1306 arm, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
        if (Config.Common.BOOK_READING_ANIMATION.get()) {
            if (stack.method_7969() != null && stack.method_7969().method_10577(Scholar.NBT.BOOK_OPEN)) {
                M parentModel = method_17165();
                ColoredBookModel.renderInHand(entity, stack, arm, poseStack, buffer, packedLight, parentModel, scholar$bookModel);
                ci.cancel();
            }

            if (Config.Common.BOOK_READING_HIDE_OFFHAND_ITEM.get()) {
                boolean isMainArm = arm == entity.method_6068();
                class_1799 otherHandStack = isMainArm
                      ? entity.method_6079()
                      : entity.method_6047();

                if (otherHandStack.method_7969() != null && otherHandStack.method_7969().method_10577(Scholar.NBT.BOOK_OPEN)) {
                    ci.cancel(); // Do not render item in hand if a book is held in another
                }
            }
        }
    }
}
