package io.github.mortuusars.scholar;

import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_5250;
import net.minecraft.class_5272;

public class ScholarClient {
    public static void init() {
        registerItemModelProperties();
    }

    private static void registerItemModelProperties() {
        class_5272.method_27879(class_1802.field_8674, Scholar.resource("book_golden"),
              (stack, level, entity, seed) -> stack.method_7969() != null && stack.method_7969().method_10577(Scholar.NBT.BOOK_GOLDEN) ? 1 : 0);
        class_5272.method_27879(class_1802.field_8360, Scholar.resource("book_golden"),
              (stack, level, entity, seed) -> stack.method_7969() != null && stack.method_7969().method_10577(Scholar.NBT.BOOK_GOLDEN) ? 1 : 0);
    }

    public static class KeyMappings {
        public static class_304 toggleBookTools = new class_304("key.scholar.toggle_book_tools",
              class_3675.field_31916, "key.scholar.categories.scholar");
        public static class_304 importBook = new class_304("key.scholar.import_book",
              class_3675.field_31921, "key.scholar.categories.scholar");
        public static class_304 exportBook = new class_304("key.scholar.export_book",
              class_3675.field_31922, "key.scholar.categories.scholar");
        public static class_304 insertEmptyPageLeft = PlatformHelperClient.createInsertEmptyPageLeftKeyMapping();
        public static class_304 removePageLeft = PlatformHelperClient.createRemovePageLeftKeyMapping();
        public static class_304 insertEmptyPageRight = PlatformHelperClient.createInsertEmptyPageRightKeyMapping();
        public static class_304 removePageRight = PlatformHelperClient.createRemovePageRightKeyMapping();

        public static void register(Consumer<class_304> registerFunction) {
            registerFunction.accept(toggleBookTools);
            registerFunction.accept(importBook);
            registerFunction.accept(exportBook);
            registerFunction.accept(insertEmptyPageLeft);
            registerFunction.accept(removePageLeft);
            registerFunction.accept(insertEmptyPageRight);
            registerFunction.accept(removePageRight);
        }

        public static class_5250 componentForTooltip(class_304 keyMapping) {
            return componentForTooltip(keyMapping, class_124.field_1063);
        }

        public static class_5250 componentForTooltip(class_304 keyMapping, class_124 formatting) {
            return class_2561.method_43470(" " + keyMapping.method_16007().getString()).method_27692(formatting);
        }
    }
}
