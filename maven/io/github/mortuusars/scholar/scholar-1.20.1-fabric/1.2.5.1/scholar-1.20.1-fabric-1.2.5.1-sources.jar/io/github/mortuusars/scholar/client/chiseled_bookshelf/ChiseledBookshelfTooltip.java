package io.github.mortuusars.scholar.client.chiseled_bookshelf;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.client.gui.InWorldTooltip;
import io.github.mortuusars.scholar.integration.Mods;
import io.github.mortuusars.scholar.integration.woodworks.WoodworksIntegration;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.OptionalInt;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2383;
import net.minecraft.class_241;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_7714;
import net.minecraft.class_7716;

public class ChiseledBookshelfTooltip {
    public static boolean render(class_332 guiGraphics, float partialTicks) {
        if (!Config.Common.CHISELED_BOOKSHELF_TOOLTIP.get()) {
            return false;
        }

        class_310 minecraft = class_310.method_1551();

        if (minecraft.field_1687 == null || minecraft.field_1724 == null || minecraft.field_1755 != null
              || !(minecraft.field_1765 instanceof class_3965 blockHitResult)) {
            return false;
        }

        if (Config.Common.TOOLTIP_REQUIRES_SNEAK.get() && !minecraft.field_1724.method_21823()) {
            return false;
        }

        class_2338 hitPos = blockHitResult.method_17777();
        class_2680 blockState = minecraft.field_1687.method_8320(hitPos);

        if (!(blockState.method_26204() instanceof class_7714 chiseledBookShelfBlock)) {
            return false;
        }

        @Nullable class_2586 blockEntity = minecraft.field_1687.method_8321(hitPos);

        if (!(blockEntity instanceof class_7716 chiseledBookShelfBlockEntity)) {
            return false;
        }

        Optional<class_241> blockHitPos = class_7714.method_47579(blockHitResult,
              blockState.method_11654(class_2383.field_11177));
        if (blockHitPos.isEmpty()) {
            return false;
        }

        int hitSlot = getHitSlot(blockState, blockHitPos.get());

        class_1799 bookStack = chiseledBookShelfBlockEntity.method_5438(hitSlot);
        if (bookStack.method_7960()) {
            return false;
        }

        InWorldTooltip.renderItemTooltip(guiGraphics, partialTicks, bookStack);
        return true;
    }

    private static int getHitSlot(class_2680 state, class_241 hitPos) {
        if (Mods.WOODWORKS.isLoaded()) {
            OptionalInt slot = WoodworksIntegration.getHitSlot(state, hitPos);
            if (slot.isPresent()) {
                return slot.getAsInt();
            }
        }

        return class_7714.method_47580(hitPos);
    }
}
