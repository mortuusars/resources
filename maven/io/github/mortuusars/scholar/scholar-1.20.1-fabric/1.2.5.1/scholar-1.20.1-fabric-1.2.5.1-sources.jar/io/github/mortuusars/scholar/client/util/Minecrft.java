package io.github.mortuusars.scholar.client.util;

import java.util.Objects;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_5455;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;

public class Minecrft {
    public static class_310 get() {
        return class_310.method_1551();
    }

    public static class_746 player() {
        return Objects.requireNonNull(get().field_1724, "Player is not available.");
    }

    public static class_638 level() {
        return Objects.requireNonNull(get().field_1687, "Level is not available.");
    }

    public static class_5455 registryAccess() {
        return level().method_30349();
    }

    public static class_636 gameMode() {
        return Objects.requireNonNull(get().field_1761, "GameMode is not available.");
    }

    public static class_315 options() {
        return get().field_1690;
    }

    public static void execute(Runnable runnable) {
        get().execute(runnable);
    }

    public static void releaseUseButton() {
        options().field_1904.method_23481(false);
    }

    public static void stopPlayerMovement() {
        // Stop player moving if movement key is held
        Minecrft.player().field_6212 = 0;
        Minecrft.player().field_6227 = 0;
        Minecrft.player().field_6250 = 0;
        Minecrft.player().method_6100(false);
        options().field_1894.method_23481(false);
        options().field_1881.method_23481(false);
        options().field_1913.method_23481(false);
        options().field_1849.method_23481(false);
        options().field_1903.method_23481(false);
    }
}
