package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.PacketDirection;
import io.github.mortuusars.scholar.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

public record SetCustomAuthorInHandC2SP(int slot, String author) implements Packet {
    public static final class_2960 ID = Scholar.resource("set_custom_author_in_hand");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public static SetCustomAuthorInHandC2SP fromBuffer(class_2540 buffer) {
        return new SetCustomAuthorInHandC2SP(buffer.readInt(), buffer.method_19772());
    }

    @Override
    public class_2540 toBuffer(class_2540 buffer) {
        buffer.writeInt(slot);
        buffer.method_10814(author);
        return buffer;
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (!Config.Common.BOOK_CHANGEABLE_AUTHOR.get()) {
            return true;
        }

        if (author.length() > 128) {
            Scholar.LOGGER.error("Cannot handle {} packet: player {} sent author string that's too long: {}. Max 128..", ID, player, author.length());
            return true;
        }

        if (class_1661.method_7380(slot) || slot == class_1661.field_30639) {
            class_1799 stack = serverPlayer.method_31548().method_5438(slot);
            stack.method_7948().method_10582("author", author);
            return true;
        }

        return true;
    }
}
