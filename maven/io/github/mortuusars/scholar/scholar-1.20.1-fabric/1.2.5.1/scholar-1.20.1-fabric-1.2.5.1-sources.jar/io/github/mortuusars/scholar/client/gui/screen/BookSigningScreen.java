package io.github.mortuusars.scholar.client.gui.screen;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookSignature;
import io.github.mortuusars.scholar.client.gui.screen.edit.SpreadBookEditScreen;
import io.github.mortuusars.scholar.client.gui.widget.textbox.display.HorizontalAlignment;
import io.github.mortuusars.scholar.client.gui.widget.textbox.text.FormattedString;
import io.github.mortuusars.scholar.client.gui.widget.textbox.TextBox;
import io.github.mortuusars.scholar.client.util.RenderUtil;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_1109;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_7919;

public class BookSigningScreen extends class_437 {
    public static final class_2960 TEXTURE = Scholar.resource("textures/gui/book_signing.png");
    public static final class_2960 TEXTURE_GOLDEN = Scholar.resource("textures/gui/book_signing_golden.png");

    @NotNull
    protected final class_310 field_22787;
    @NotNull
    protected final class_1657 player;

    protected final SpreadBookEditScreen parentScreen;
    protected final int bookColor;
    protected final Consumer<BookSignature> onSign;

    protected int textColor;
    protected int selectionColor;
    protected int selectionUnfocusedColor;
    protected int enterBookTitleFontColor;
    protected int byAuthorFontColor;

    protected int imageWidth, imageHeight, leftPos, topPos, textureWidth, textureHeight;

    protected TextBox titleTextBox;
    protected TextBox authorTextBox;
    protected class_344 signButton;
    protected class_344 cancelSigningButton;

    protected String titleText = "";
    protected String authorText = Objects.requireNonNull(class_310.method_1551().field_1724).method_5820();

    public BookSigningScreen(SpreadBookEditScreen parentScreen, int bookColor, Consumer<BookSignature> onSign) {
        super(class_2561.method_43473());
        this.parentScreen = parentScreen;
        this.bookColor = bookColor;
        this.onSign = onSign;

        this.textColor = Config.Client.getColor(Config.Client.TEXT_COLOR);
        this.selectionColor = Config.Client.getColor(Config.Client.SELECTION_COLOR);
        this.selectionUnfocusedColor = Config.Client.getColor(Config.Client.SELECTION_UNFOCUSED_COLOR);
        this.enterBookTitleFontColor = Config.Client.getColor(Config.Client.ENTER_TITLE_COLOR);
        this.byAuthorFontColor = Config.Client.getColor(Config.Client.BY_AUTHOR_COLOR);

        this.field_22787 = class_310.method_1551();
        this.player = Objects.requireNonNull(field_22787.field_1724);
        this.textureWidth = 256;
        this.textureHeight = 256;
    }

    @Override
    public boolean method_25421() {
        return Config.Common.BOOK_SCREEN_PAUSE.get();
    }

    @Override
    protected void method_25426() {
        this.imageWidth = 149;
        this.imageHeight = 180;
        this.leftPos = (this.field_22789 - this.imageWidth) / 2;
        this.topPos = (this.field_22790 - this.imageHeight) / 2;

        // TITLE
        titleTextBox = new TextBox(field_22793, leftPos + 21, topPos + 71, 108, 9)
              .setFontColor(textColor)
              .setFontUnfocusedColor(textColor)
              .setSelectionColor(selectionColor)
              .setSelectionUnfocusedColor(selectionUnfocusedColor)
              .setHorizontalAlignment(HorizontalAlignment.CENTER)
              .setOnTextChanged(this::setTitleText)
              .setTextValidator(text -> text != null && text.length() <= 32
                    && field_22793.method_1713(text, 108) <= 9 && !text.contains("\n"));
        method_37063(titleTextBox);

        authorTextBox = new TextBox(field_22793, leftPos + 33, topPos + 81, 100, 9)
              .setText(FormattedString.parse(authorText))
              .setFontColor(byAuthorFontColor)
              .setFontUnfocusedColor(byAuthorFontColor)
              .setSelectionColor(0xFF9271dc)
              .setSelectionUnfocusedColor(0xFFc6b2f2)
              .setHorizontalAlignment(HorizontalAlignment.CENTER)
              .setOnTextChanged(this::setAuthorText)
              .setTextValidator(text -> text != null && text.length() <= 32
                    && field_22793.method_1713(text, 100) <= 9 && !text.contains("\n"));
        authorTextBox.getEditor().setCursorToEnd(false);
        method_37063(authorTextBox);

        // SIGN
        signButton = new class_344(leftPos + 46, topPos + 109, 22, 22, 149, 0,
              22, TEXTURE, textureWidth, textureHeight,
              b -> sign(), class_2561.method_43471("book.finalizeButton"));
        class_5250 component = class_2561.method_43471("book.finalizeButton")
              .method_27693("\n").method_10852(class_2561.method_43471("book.finalizeWarning").method_27692(class_124.field_1080));
        signButton.method_47400(class_7919.method_47407(component));
        method_37063(signButton);

        // CANCEL
        cancelSigningButton = new class_344(leftPos + 82, topPos + 108, 22, 22, 171, 0,
              22, TEXTURE, textureWidth, textureHeight,
              b -> cancelSigning(), class_5244.field_24335);
        cancelSigningButton.method_47400(class_7919.method_47407(class_5244.field_24335));
        method_37063(cancelSigningButton);

        method_48265(titleTextBox);
    }

    protected void setTitleText(FormattedString text) {
        titleText = text.toString();
        updateButtons();
    }

    protected void setAuthorText(FormattedString text) {
        authorText = text.toString();
        updateButtons();
    }

    protected void updateButtons() {
        signButton.field_22763 = canSign();
        authorTextBox.field_22764 = Config.Common.BOOK_CHANGEABLE_AUTHOR.get();
        authorTextBox.field_22763 = Config.Common.BOOK_CHANGEABLE_AUTHOR.get();

        boolean canSign = canSign();

        signButton.field_22763 = canSign;

        class_5250 component = class_2561.method_43471("book.finalizeButton")
              .method_10852(class_5244.field_33849)
              .method_10852(class_2561.method_43471("book.finalizeWarning").method_27692(class_124.field_1080));
        if (!canSign && titleText.length() > 32) {
            component.method_10852(class_5244.field_33849);
            component.method_10852(class_2561.method_43471("scholar.book_singing.error_title_too_long").method_27692(class_124.field_1061));
        }

        signButton.method_47400(class_7919.method_47407(component));
    }

    protected boolean canSign() {
        return !titleText.isBlank();
    }

    @Override
    public void method_25410(class_310 minecraft, int width, int height) {
        FormattedString titleString = titleTextBox.getEditor().getString();
        FormattedString authorString = authorTextBox.getEditor().getString();
        super.method_25410(minecraft, width, height);
        titleTextBox.getEditor().setString(titleString);
        authorTextBox.getEditor().setString(authorString);
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();

        method_25420(guiGraphics);

        if (parentScreen.isGolden()) {
            guiGraphics.method_25291(TEXTURE_GOLDEN, leftPos, topPos, 0, 0, 0,
                  imageWidth, imageHeight, textureWidth, textureHeight);
        } else {
            RenderUtil.withColorMultiplied(bookColor, () -> {
                guiGraphics.method_25291(TEXTURE, leftPos, topPos, 0, 0, 0,
                      imageWidth, imageHeight, textureWidth, textureHeight);
            });
        }

        guiGraphics.method_25291(TEXTURE, leftPos, topPos + 31, 0, 0, 180,
              imageWidth, 76, textureWidth, textureHeight);

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        renderLabels(guiGraphics);
    }

    protected void renderLabels(class_332 guiGraphics) {
        class_5250 component = class_2561.method_43471("book.editTitle");
        guiGraphics.method_51439(field_22793, component, leftPos + 149 / 2 - field_22793.method_27525(component) / 2, topPos + 51,
              enterBookTitleFontColor, false);

        if (!Config.Common.BOOK_CHANGEABLE_AUTHOR.get()) {
            component = class_2561.method_43469("book.byAuthor", player.method_5477());
            guiGraphics.method_51439(field_22793, component, leftPos + 149 / 2 - field_22793.method_27525(component) / 2, topPos + 81,
                  byAuthorFontColor, false);
        } else {
            component = class_2561.method_43473()
                  .method_27693(authorText.equals(Objects.requireNonNull(field_22787.field_1724).method_5820()) ? "✎ " : "")
                  .method_10852(class_2561.method_43469("book.byAuthor", ""));
            int width = field_22793.method_27525(component);
            int authorWidth = field_22793.method_1727(authorTextBox.getEditor().getString().toString());
            int x = (authorTextBox.method_46426() + authorTextBox.method_25368() / 2) - (authorWidth / 2) - width;
            guiGraphics.method_51439(field_22793, component, x, topPos + 81,
                  byAuthorFontColor, false);
        }
    }

    protected void sign() {
        if (canSign()) {
            Optional<String> author = Optional.of(authorText)
                  .filter(a -> Config.Common.BOOK_CHANGEABLE_AUTHOR.get()
                        && !a.equals(Objects.requireNonNull(field_22787.field_1724).method_5820()));
            onSign.accept(new BookSignature(titleText.trim(), author));
            field_22787.method_1483().method_4873(
                  class_1109.method_4757(Scholar.SoundEvents.BOOK_SIGNED.get(), 1f, 0.8f));
            method_25419();
        }
    }

    protected void cancelSigning() {
        field_22787.method_1507(parentScreen);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == class_3675.field_31958) {
            cancelSigning();
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }
}
