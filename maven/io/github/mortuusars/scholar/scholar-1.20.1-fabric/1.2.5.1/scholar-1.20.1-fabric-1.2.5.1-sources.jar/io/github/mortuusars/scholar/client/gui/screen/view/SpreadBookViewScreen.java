package io.github.mortuusars.scholar.client.gui.screen.view;

import com.mojang.datafixers.util.Pair;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.ScholarClient;
import io.github.mortuusars.scholar.client.gui.screen.SpreadBookScreen;
import io.github.mortuusars.scholar.client.util.FileDialogs;
import io.github.mortuusars.scholar.client.util.RenderUtil;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import net.minecraft.class_7919;
import net.minecraft.network.chat.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.IntStream;

public abstract class SpreadBookViewScreen extends SpreadBookScreen {
    protected BookViewAccess bookAccess;
    protected Pair<List<class_5481>, List<class_5481>> cachedPageComponents;
    protected int cachedSpread;

    protected class_344 exportBookButton;

    public SpreadBookViewScreen(BookViewAccess bookAccess, int bookColor) {
        super(bookColor);
        this.bookAccess = bookAccess;
        this.cachedPageComponents = Pair.of(Collections.emptyList(), Collections.emptyList());
        this.cachedSpread = -1;
    }

    @Override
    public boolean isGolden() {
        return getBookAccess().isGolden();
    }

    @Override
    protected void createWidgets() {
        super.createWidgets();
        exportBookButton = new class_344(leftPos + 297, topPos + 16, 18, 18, 369, 0,
              18, TEXTURE, 512, 512,
              b -> exportBook(!class_437.method_25442()), class_2561.method_43471("gui.scholar.export_book"));
        exportBookButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.scholar.export_book")
              .method_10852(ScholarClient.KeyMappings.componentForTooltip(ScholarClient.KeyMappings.exportBook))
              .method_10852(class_5244.field_33849)
              .method_10852(class_2561.method_43471("gui.scholar.export_book.tooltip"))));
        method_37063(exportBookButton);
    }

    @Override
    protected void updateButtons() {
        super.updateButtons();
        exportBookButton.field_22764 = isToolsVisible();
        exportBookButton.field_22763 = IntStream.range(0, getBookAccess().getPageCount())
              .mapToObj(getBookAccess()::getPage)
              .anyMatch(text -> !text.getString().isEmpty());
    }

    public BookViewAccess getBookAccess() {
        return bookAccess;
    }

    public void setBookAccess(BookViewAccess bookViewAccess) {
        this.bookAccess = bookViewAccess;
        this.currentSpread = class_3532.method_15340(this.currentSpread, 0, getSpreadCount());
        this.cachedSpread = -1; // Forces cache update
    }

    @Override
    public int getPageCount() {
        return getBookAccess().getPageCount();
    }

    @Override
    public int getLastPage() {
        return Math.max(getPageCount() - 1, 0);
    }

    @Override
    protected int getFirstPageWithContent() {
        for (int i = 0; i < getPageCount(); i++) {
            if (!getBookAccess().getPage(i).getString().isEmpty()) {
                return i;
            }
        }
        return 0;
    }

    @Override
    protected int getLastPageWithContent() {
        for (int i = getPageCount() - 1; i >= 0; i--) {
            if (!getBookAccess().getPage(i).getString().isEmpty()) {
                return i;
            }
        }
        return 0;
    }

    @Override
    public boolean setPage(int pageIndex) {
        if (super.setPage(pageIndex)) {
            this.cachedSpread = -1;
            return true;
        }
        return false;
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();

        method_25420(guiGraphics);
        renderBook(guiGraphics, mouseX, mouseY, partialTick);
        renderPageNumbers(guiGraphics, mouseX, mouseY, partialTick, currentSpread);
        renderTools(guiGraphics, mouseX, mouseY, partialTick);

        updateAndCacheContentsIfNeeded();

        renderPageContents(guiGraphics, cachedPageComponents.getFirst(), leftPos + TEXT_LEFT_X, topPos + TEXT_Y);
        renderPageContents(guiGraphics, cachedPageComponents.getSecond(), leftPos + TEXT_RIGHT_X, topPos + TEXT_Y);

        class_2583 style = getClickedComponentStyleAt(mouseX, mouseY);
        if (style != null) {
            guiGraphics.method_51441(field_22793, style, mouseX, mouseY);
        }

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    protected void renderBook(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.renderBook(guiGraphics, mouseX, mouseY, partialTick);
        if (isToolsVisible()) {
            RenderUtil.withColorMultiplied(bookColor, () -> {
                // Export button BG
                guiGraphics.method_25290(TEXTURE, leftPos + 295, topPos + 14, 0, 388, 23, 24, 512, 512);
            });
        }
    }

    protected void updateAndCacheContentsIfNeeded() {
        if (cachedSpread != currentSpread) {
            class_5348 leftFormattedText = getBookAccess().getPage(currentSpread * 2);
            class_5348 rightFormattedText = getBookAccess().getPageCount() > currentSpread * 2 + 1 ?
                  getBookAccess().getPage(currentSpread * 2 + 1) : class_5348.field_25310;

            cachedPageComponents = Pair.of(
                  field_22793.method_1728(leftFormattedText, TEXT_WIDTH),
                  field_22793.method_1728(rightFormattedText, TEXT_WIDTH));

            cachedSpread = currentSpread;
        }
    }

    protected void renderPageContents(class_332 guiGraphics, List<class_5481> lines, int x, int y) {
        int maxLines = Math.min(TEXT_HEIGHT / field_22793.field_2000, lines.size());
        for (int i = 0; i < maxLines; ++i) {
            class_5481 text = lines.get(i);
            guiGraphics.method_51430(field_22793, text, x, y + i * field_22793.field_2000, textColor, false);
        }
    }

    // --

    public boolean method_25402(double x, double y, int button) {
        if (button == 0) {
            class_2583 style = this.getClickedComponentStyleAt(x, y);
            if (style != null && this.method_25430(style)) {
                return true;
            }
        }

        return super.method_25402(x, y, button);
    }

    public boolean method_25430(class_2583 style) {
        if (style == null)
            return false;

        class_2558 clickEvent = style.method_10970();
        if (clickEvent == null)
            return false;

        if (clickEvent.method_10845() == class_2558.class_2559.field_11748) {
            String pageNumber = clickEvent.method_10844();

            try {
                int pageIndex = Integer.parseInt(pageNumber) - 1;
                boolean pageChanged = this.setPage(pageIndex);
                if (pageChanged) {
                    playPageTurnSound();
                }
                return pageChanged;
            } catch (Exception var5) {
                return false;
            }
        } else {
            boolean handled = super.method_25430(style);
            if (handled && clickEvent.method_10845() == class_2558.class_2559.field_11750) {
                this.method_25419();
            }

            return handled;
        }
    }

    @Nullable
    public class_2583 getClickedComponentStyleAt(double mouseX, double mouseY) {
        if (mouseY < topPos + TEXT_Y || mouseY >= topPos + TEXT_Y + TEXT_HEIGHT)
            return null;

        boolean isOverRightPage;
        if (mouseX >= leftPos + TEXT_RIGHT_X && mouseX < leftPos + TEXT_RIGHT_X + TEXT_WIDTH) {
            isOverRightPage = true;
        } else if (mouseX >= leftPos + TEXT_LEFT_X && mouseX < leftPos + TEXT_LEFT_X + TEXT_WIDTH) {
            isOverRightPage = false;
        } else {
            return null;
        }

        List<class_5481> pageContents = isOverRightPage ? this.cachedPageComponents.getSecond() : this.cachedPageComponents.getFirst();

        if (pageContents.isEmpty()) {
            return null;
        }

        int x = (int) mouseX - (leftPos + (isOverRightPage ? TEXT_RIGHT_X : TEXT_LEFT_X));
        int y = (int) mouseY - (topPos + TEXT_Y);

        int linesCount = Math.min(TEXT_HEIGHT / field_22793.field_2000, pageContents.size());
        if (y < field_22793.field_2000 * linesCount + linesCount) {
            int clickedLine = y / field_22793.field_2000;
            if (clickedLine >= 0 && clickedLine < pageContents.size()) {
                class_5481 text = pageContents.get(clickedLine);
                return field_22793.method_27527().method_30876(text, x);
            }

            return null;
        }

        return null;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (ScholarClient.KeyMappings.exportBook.method_1417(keyCode, scanCode)) {
            playButtonClickSound();
            exportBook(!class_437.method_25442());
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    // --

    public void exportBook(boolean withFormatting) {
        List<String> pages = new ArrayList<>();
        for (int i = 0; i < getBookAccess().getPageCount(); i++) {
            String text = getBookAccess().getPage(i).getString();
            pages.add(text);
        }

        String content = withFormatting
              ? String.join("\f", pages)
              : class_124.method_539(String.join("\f", pages));

        CompletableFuture.runAsync(() -> {
            String defaultDirectory = class_310.method_1551().field_1697.toPath().toAbsolutePath().normalize().toString();
            if (!defaultDirectory.endsWith(File.separator)) {
                defaultDirectory = defaultDirectory + File.separator;
            }
            String title = class_2561.method_43471("gui.scholar.export_book").getString();

            FileDialogs.saveFile(defaultDirectory, title, "Text Files (.txt)", "*.txt").ifPresent(filePath -> {
                try {
                    Files.writeString(Path.of(filePath), content, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                    class_5250 filePathComponent = class_2561.method_43470(filePath).method_27696(class_2583.field_24360
                          .method_30938(true)
                          .method_10958(new class_2558(class_2558.class_2559.field_11746, filePath)));
                    class_310.method_1551().execute(() -> player.method_7353(
                          class_2561.method_43471("gui.scholar.export_book.success")
                                .method_10852(filePathComponent), false));
                } catch (IOException e) {
                    class_310.method_1551().execute(() -> player.method_7353(
                          class_2561.method_43471("gui.scholar.export_book.failure"), false));
                    Scholar.LOGGER.error("Failed to export book: ", e);
                }
            });
        }).exceptionally(e -> {
            class_310.method_1551().execute(() -> player.method_7353(
                  class_2561.method_43471("gui.scholar.export_book.failure"), false));
            Scholar.LOGGER.error("Failed to export book: ", e);
            return null;
        });
    }
}