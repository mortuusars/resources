package io.github.mortuusars.scholar.client.gui.screen.view;

import io.github.mortuusars.scholar.client.gui.widget.BookmarkButton;
import io.github.mortuusars.scholar.network.Packets;
import io.github.mortuusars.scholar.network.packet.serverbound.SetBookmarkC2SP;
import io.github.mortuusars.scholar.network.packet.serverbound.StartedReadingInHandC2SP;
import io.github.mortuusars.scholar.network.packet.serverbound.StoppedReadingInHandC2SP;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4185;
import net.minecraft.class_7919;

public class InHandSpreadBookViewScreen extends SpreadBookViewScreen {
    protected final class_1268 hand;
    protected BookmarkButton bookmarkButton;

    public InHandSpreadBookViewScreen(BookViewAccess bookAccess, int bookColor, class_1268 hand) {
        super(bookAccess, bookColor);
        this.hand = hand;
        setPage(getBookAccess().getBookmarkedPage());
        Packets.sendToServer(new StartedReadingInHandC2SP(getBookSlot()));
        class_310.method_1551().field_1687.method_43129(player, player, class_3417.field_17481, class_3419.field_15248, 1, 1);
    }

    protected int getBookSlot() {
        return hand == class_1268.field_5808 ? player.method_31548().field_7545 : class_1661.field_30639;
    }

    @Override
    protected void createWidgets() {
        super.createWidgets();
        bookmarkButton = method_37063(new BookmarkButton(leftPos + 118, topPos + 2, 20, 20,
              423, 0, 60, 512, 512, TEXTURE,
              this::pressBookmarkButton,
              class_2561.method_43471("gui.scholar.bookmark")));
    }

    @Override
    protected void updateButtons() {
        super.updateButtons();
        int bookmarkedSpread = getBookAccess().getBookmarkedPage() / 2;
        bookmarkButton.field_22764 = currentSpread != 0 || bookmarkedSpread != 0;
        if (bookmarkButton.field_22764) {
            boolean isAtBookmarkedSpread = bookmarkedSpread == currentSpread;
            bookmarkButton.setExpanded(isAtBookmarkedSpread);
            bookmarkButton.method_47400(class_7919.method_47407(
                  class_2561.method_43471("gui.scholar.bookmark." + (isAtBookmarkedSpread ? "remove" : "set"))));
        }
    }

    protected void pressBookmarkButton(class_4185 button) {
        int bookmarkedSpread = getBookAccess().getBookmarkedPage() / 2;

        int newBookmarkedPage;

        if (bookmarkedSpread == currentSpread) {
            if (currentSpread == 0) {
                return;
            }
            newBookmarkedPage = 0;
        } else {
            newBookmarkedPage = currentSpread * 2;
        }

        if (newBookmarkedPage == 0) {
            getBookAccess().setBookmarkedPage(null);
        } else {
            getBookAccess().setBookmarkedPage(newBookmarkedPage);
        }

        int slot = hand == class_1268.field_5808 ? player.method_31548().field_7545 : class_1661.field_30639;
        Packets.sendToServer(new SetBookmarkC2SP(slot, newBookmarkedPage));
    }

    @Override
    public void method_25419() {
        super.method_25419();
        Packets.sendToServer(new StoppedReadingInHandC2SP(getBookSlot()));
    }
}
