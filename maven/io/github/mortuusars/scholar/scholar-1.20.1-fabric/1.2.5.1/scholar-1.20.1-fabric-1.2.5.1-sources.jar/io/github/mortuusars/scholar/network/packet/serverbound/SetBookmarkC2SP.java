package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.PacketDirection;
import io.github.mortuusars.scholar.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

public record SetBookmarkC2SP(int slot, int page) implements Packet {
    public static final class_2960 ID = Scholar.resource("set_bookmark");

    @Override
    public class_2540 toBuffer(class_2540 buffer) {
        buffer.writeInt(slot);
        buffer.writeInt(page);
        return buffer;
    }

    public static SetBookmarkC2SP fromBuffer(class_2540 buffer) {
        return new SetBookmarkC2SP(buffer.readInt(), buffer.readInt());
    }

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (class_1661.method_7380(slot) || slot == class_1661.field_30639) {
            class_1799 stack = serverPlayer.method_31548().method_5438(slot);
            if (page == 0) {
                if (stack.method_7969() != null) {
                    stack.method_7969().method_10551(Scholar.NBT.BOOKMARK);
                }
            } else {
                stack.method_7948().method_10569(Scholar.NBT.BOOKMARK, page);
            }
            return true;
        }

        return true;
    }
}
