package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.PacketDirection;
import io.github.mortuusars.scholar.network.packet.Packet;
import io.github.mortuusars.scholar.util.supporter.Supporters;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3722;

public record SetGoldenSkinOnLecternC2SP(class_2338 lecternPos, boolean golden) implements Packet {
    public static final class_2960 ID = Scholar.resource("set_golden_skin_on_lectern");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public static SetGoldenSkinOnLecternC2SP fromBuffer(class_2540 buffer) {
        return new SetGoldenSkinOnLecternC2SP(buffer.method_10811(), buffer.readBoolean());
    }

    @Override
    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10807(lecternPos);
        buffer.writeBoolean(golden);
        return buffer;
    }

    @Override
    public boolean handle(PacketDirection direction, class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (!(serverPlayer.method_37908().method_8321(lecternPos) instanceof class_3722 lecternBlockEntity)) {
            Scholar.LOGGER.error("Cannot update lectern book: no lectern block entity at [{}]", lecternPos.method_23854());
            return false;
        }

        class_1799 book = lecternBlockEntity.method_17520();

        if (book.method_31574(class_1802.field_8674) && Supporters.hasAccessToGoldenSkin(player.method_5667())) {
            if (!golden) {
                if (book.method_7969() != null) {
                    book.method_7969().method_10551(Scholar.NBT.BOOK_GOLDEN);
                }
            } else {
                book.method_7948().method_10556(Scholar.NBT.BOOK_GOLDEN, true);
            }
            lecternBlockEntity.method_5431();

            // Manually sending the block data to clients because it doesn't happen when block is changed for some reason
            if (Config.Common.LECTERN_TOOLTIP.get()) {
                var bePacket = lecternBlockEntity.method_38235();
                serverPlayer.method_51469().method_18456().forEach(pl -> {
                    if (lecternPos.method_10262(pl.method_24515()) < 128) {
                        pl.field_13987.method_14364(bePacket);
                    }
                });
            }
        }

        return true;
    }
}
