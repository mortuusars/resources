package io.github.mortuusars.scholar.client.gui.widget;

import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;

public class ToggleImageButton extends class_344 {
    protected final int onVOffset;
    protected final class_2960 texture;
    protected final Consumer<Boolean> onToggled;
    protected boolean state;

    public ToggleImageButton(int x, int y, int width, int height, int u, int v, int onVOffset, class_2960 texture,
                             int textureWidth, int textureHeight, Consumer<Boolean> onToggled) {
        super(x, y, width, height, u, v, height, texture, textureWidth, textureHeight, b -> {});
        this.onVOffset = onVOffset;
        this.texture = texture;
        this.onToggled = onToggled;
    }

    public boolean isOn() {
        return state;
    }

    public boolean isOff() {
        return !isOn();
    }

    public void toggle() {
        this.state = !state;
        onToggled.accept(this.state);
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public <T> T mapState(Function<Boolean, T> mappingFunction) {
        return mappingFunction.apply(state);
    }

    @Override
    public void method_25306() {
        toggle();
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        method_48588(guiGraphics, texture, method_46426(), method_46427(), field_2126,
              field_2125 + (state ? onVOffset : 0), field_19079, field_22758, field_22759, field_2124, field_19080);
    }
}
