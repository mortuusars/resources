package io.github.mortuusars.scholar.mixin.lectern;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.client.ColoredBookModel;
import net.minecraft.class_3722;
import net.minecraft.class_3942;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_557;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3942.class)
public class LecternRendererMixin {
    @Shadow
    @Final
    private class_557 bookModel;

    @Inject(method = "render(Lnet/minecraft/world/level/block/entity/LecternBlockEntity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;II)V",
          at = @At("HEAD"),
          cancellable = true)
    private void onRender(class_3722 blockEntity, float partialTick, class_4587 poseStack,
                          class_4597 bufferSource, int packedLight, int packedOverlay, CallbackInfo ci) {
        if (Config.Common.LECTERN_COLORED_BOOK_MODEL.get()) {
            ColoredBookModel.renderOnLectern(blockEntity.method_11010(), blockEntity, partialTick, poseStack, bufferSource, packedLight, packedOverlay, bookModel);
            ci.cancel();
        }
    }
}
