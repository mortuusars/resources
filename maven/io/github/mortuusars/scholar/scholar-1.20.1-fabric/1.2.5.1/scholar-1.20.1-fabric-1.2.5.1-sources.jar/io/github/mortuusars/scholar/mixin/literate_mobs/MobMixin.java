package io.github.mortuusars.scholar.mixin.literate_mobs;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.world.entity.ReadBookGoal;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1355;
import net.minecraft.class_1588;
import net.minecraft.class_1937;
import net.minecraft.class_8152;
import net.minecraft.world.entity.*;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1308.class)
public abstract class MobMixin extends class_1309 implements class_8152 {
    @Shadow
    @Final
    protected class_1355 goalSelector;

    protected MobMixin(class_1299<? extends class_1588> entityType, class_1937 level) {
        super(entityType, level);
    }

    @WrapOperation(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Mob;registerGoals()V"))
    private void onRegisterGoals(class_1308 instance, Operation<Void> original) {
        original.call(instance);
        if (method_5864().method_20210(Scholar.Tags.EntityTypes.LITERATE)) {
            goalSelector.method_6277(ReadBookGoal.getPriority(instance), new ReadBookGoal((class_1308) (Object) this));
        }
    }
}
