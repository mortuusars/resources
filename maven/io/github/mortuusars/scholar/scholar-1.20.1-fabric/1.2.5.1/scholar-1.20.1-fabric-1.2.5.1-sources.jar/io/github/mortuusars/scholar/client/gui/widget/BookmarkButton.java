package io.github.mortuusars.scholar.client.gui.widget;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;

public class BookmarkButton extends class_344 {
    protected int expandedVOffset;
    protected final class_2960 texture;
    protected boolean expanded;

    public BookmarkButton(int x, int y, int width, int height, int u, int v, int expandedVOffset,
                          int textureWidth, int textureHeight, class_2960 texture, class_4241 onPress, class_2561 message) {
        super(x, y, width, height, u, v, height, texture, textureWidth, textureHeight, onPress, message);
        this.expandedVOffset = expandedVOffset;
        this.texture = texture;
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        method_48588(guiGraphics, texture, method_46426(), method_46427(), field_2126, field_2125 + (isExpanded() ? expandedVOffset : 0), field_19079,
              field_22758, field_22759, field_2124, field_19080);
    }
}
