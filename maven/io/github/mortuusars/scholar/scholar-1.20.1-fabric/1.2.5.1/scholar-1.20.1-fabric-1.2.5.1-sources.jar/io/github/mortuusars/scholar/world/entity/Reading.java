package io.github.mortuusars.scholar.world.entity;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1560;
import net.minecraft.class_1840;
import net.minecraft.class_1843;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

public class Reading {
    public static @Nullable class_1268 getOpenedBookHand(class_1309 entity) {
        if (!Config.Common.BOOK_READING_ANIMATION.get()) return null;
        if (entity instanceof class_1560) return null; // They cannot hold items as other mobs do.
        if (entity.method_6047().method_7969() != null && entity.method_6047().method_7969().method_10577(Scholar.NBT.BOOK_OPEN)) return class_1268.field_5808;
        if (entity.method_6079().method_7969() != null && entity.method_6079().method_7969().method_10577(Scholar.NBT.BOOK_OPEN)) return class_1268.field_5810;
        return null;
    }

    public static void closeAllBooksInInventory(class_3222 player) {
        player.method_31548().field_7547.forEach(stack -> {
            if (stack.method_7969() != null && (stack.method_7909() instanceof class_1840 || stack.method_7909() instanceof class_1843)) {
                stack.method_7969().method_10551(Scholar.NBT.BOOK_OPEN);
            }
        });
    }
}
