package io.github.mortuusars.scholar.client.gui;

import io.github.mortuusars.scholar.client.chiseled_bookshelf.ChiseledBookshelfTooltip;
import io.github.mortuusars.scholar.client.lectern.LecternTooltip;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_8002;

public class InWorldTooltip {
    public static boolean render(class_332 guiGraphics, float partialTicks) {
        if (class_310.method_1551().field_1690.field_1842) {
            return false;
        }
        return ChiseledBookshelfTooltip.render(guiGraphics, partialTicks)
              || LecternTooltip.render(guiGraphics, partialTicks);
    }

    public static void renderItemTooltip(class_332 guiGraphics, float partialTicks, class_1799 stack) {
        int x = class_310.method_1551().method_22683().method_4486() / 2 + 16;
        int y = class_310.method_1551().method_22683().method_4502() / 2 - 9;

        class_8002.method_47946(guiGraphics, x, y, 18, 18, 400);

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(0, 0, 400);
        guiGraphics.method_51427(stack, x + 1, y + 1);
        guiGraphics.method_51448().method_22909();

        guiGraphics.method_51446(class_310.method_1551().field_1772, stack, x + 16, y + 12);
    }
}
