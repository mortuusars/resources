package io.github.mortuusars.scholar;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.scholar.menu.LecternSpreadBookEditMenu;
import io.github.mortuusars.scholar.menu.LecternSpreadMenu;
import io.github.mortuusars.scholar.util.supporter.Supporters;
import io.github.mortuusars.scholar.recipe.NbtTransferringRecipe;
import org.slf4j.Logger;

import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3917;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class Scholar {
    public static final String ID = "scholar";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static class_2960 resource(String path) {
        return new class_2960(Scholar.ID, path);
    }

    public static void init() {
        MenuTypes.init();
        RecipeSerializers.init();
        SoundEvents.init();

        // Query supporters early, so it will be available right away when needed
        Supporters.query();
    }

    public static class NBT {
        public static final String BOOKMARK = "ScholarBookmark";
        public static final String BOOK_OPEN = "ScholarBookOpen";
        public static final String BOOK_GOLDEN = "ScholarBookGolden";
    }

    public static class MenuTypes {
        public static final Supplier<class_3917<LecternSpreadMenu>> LECTERN_SPREAD_BOOK_VIEW =
                Register.menuType("lectern_spread_book_view", LecternSpreadMenu::fromBuffer);
        public static final Supplier<class_3917<LecternSpreadBookEditMenu>> LECTERN_SPREAD_BOOK_EDIT =
                Register.menuType("lectern_spread_book_edit", LecternSpreadBookEditMenu::fromBuffer);

        static void init() { }
    }

    public static class RecipeSerializers {
        public static final Supplier<class_1865<?>> NBT_TRANSFERRING = Register.recipeSerializer("nbt_transferring",
                NbtTransferringRecipe.Serializer::new);
        static void init() { }
    }

    public static class SoundEvents {
        public static final Supplier<class_3414> BOOK_SIGNED = register("ui", "book_signed");
        public static final Supplier<class_3414> SCRIBBLE = register("ui", "scribble");
        public static final Supplier<class_3414> INK = register("ui", "ink");

        @SuppressWarnings("SameParameterValue")
        private static Supplier<class_3414> register(String category, String key) {
            Preconditions.checkState(category != null && !category.isEmpty(), "'category' should not be empty.");
            Preconditions.checkState(key != null && !key.isEmpty(), "'key' should not be empty.");
            String path = category + "." + key;
            return Register.soundEvent(path, () -> class_3414.method_47908(Scholar.resource(path)));
        }

        static void init() {}
    }

    public static class Tags {
        public static class EntityTypes {
            public static final class_6862<class_1299<?>> LITERATE = class_6862.method_40092(class_7924.field_41266, resource("literate"));
        }
    }

    public static class LootTables {
        public static final class_2960 LITERATE_MOB_BOOK = resource("entities/literate_mob_book");
    }
}