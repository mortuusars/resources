package io.github.mortuusars.scholar.mixin.reading;

import io.github.mortuusars.scholar.client.animation.ReadingAnimation;
import io.github.mortuusars.scholar.world.entity.Reading;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1543;
import net.minecraft.class_3881;
import net.minecraft.class_3882;
import net.minecraft.class_5597;
import net.minecraft.class_575;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_575.class)
public abstract class IllagerModelMixin<T extends class_1543> extends class_5597<T> implements class_3881, class_3882 {
    @Shadow
    @Final
    private class_630 leftArm;

    @Shadow
    @Final
    private class_630 rightArm;

    @Shadow
    @Final
    private class_630 root;

    @Shadow
    @Final
    private class_630 head;

    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/monster/AbstractIllager;FFFFF)V", at = @At("RETURN"))
    private void onSetupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci) {
        class_1268 hand = Reading.getOpenedBookHand(entity);
        if (hand != null && entity.method_6990() != class_1543.class_1544.field_7207) {
            class_1306 openedBookArm = hand == class_1268.field_5808
                  ? entity.method_6068()
                  : entity.method_6068().method_5928();
            ReadingAnimation.poseLeftArm(entity, leftArm, openedBookArm == class_1306.field_6182);
            ReadingAnimation.poseRightArm(entity, rightArm, openedBookArm == class_1306.field_6182);
            ReadingAnimation.poseHead(entity, ageInTicks, headPitch, hand, root, head);
        }
    }
}
