package io.github.mortuusars.scholar.client;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.client.animation.ReadingAnimation;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1840;
import net.minecraft.class_1921;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3715;
import net.minecraft.class_3722;
import net.minecraft.class_3881;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4730;
import net.minecraft.class_5253;
import net.minecraft.class_557;
import net.minecraft.class_583;
import net.minecraft.class_606;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.client.model.*;
import org.jetbrains.annotations.NotNull;

public class ColoredBookModel {
    public static final class_4730 BOOK_COVER_LOCATION =
          new class_4730(class_1723.field_21668, Scholar.resource("block/book_cover"));
    public static final class_4730 BOOK_COVER_GOLDEN_LOCATION =
          new class_4730(class_1723.field_21668, Scholar.resource("block/book_cover_golden"));
    public static final class_4730 BOOK_PAGES_LOCATION =
          new class_4730(class_1723.field_21668, Scholar.resource("block/book_pages"));

    public static void renderOnLectern(class_2680 blockState, class_3722 blockEntity, float partialTick, class_4587 poseStack,
                                       class_4597 buffer, int packedLight, int packedOverlay, class_557 bookModel) {
        class_1799 book = blockEntity.method_17520();
        if (!book.method_7960()) {
            poseStack.method_22903();
            poseStack.method_46416(0.5F, 1.0625F, 0.5F);
            float f = blockState.method_11654(class_3715.field_16404).method_10170().method_10144();
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(-f));
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(67.5F));
            poseStack.method_46416(0.0F, -0.125F, 0.0F);
            bookModel.method_17073(0.0F, 0.1F, 0.9F, 1.2F);
            if (book.method_7969() != null && book.method_7969().method_10577(Scholar.NBT.BOOK_GOLDEN)) {
                class_4588 coverVertexConsumer = getBookCoverGoldenLocation(book).method_24145(buffer, class_1921::method_23576);
                bookModel.method_24184(poseStack, coverVertexConsumer, packedLight, packedOverlay, 1, 1, 1, 1);
            } else {
                class_4588 coverVertexConsumer = getBookCoverLocation(book).method_24145(buffer, class_1921::method_23576);
                int color = BookColor.of(book);
                bookModel.method_24184(poseStack, coverVertexConsumer, packedLight, packedOverlay,
                      class_5253.class_5254.method_27765(color) / 255f,
                      class_5253.class_5254.method_27766(color) / 255f,
                      class_5253.class_5254.method_27767(color) / 255f,
                      1);
            }
            class_4588 pagesVertexConsumer = getBookPagesLocation(book).method_24145(buffer, class_1921::method_23576);
            bookModel.method_24184(poseStack, pagesVertexConsumer, packedLight, packedOverlay, 1, 1, 1, 1);
            poseStack.method_22909();
        }
    }

    public static <M extends class_583<?> & class_3881> void renderInHand(class_1309 entity, class_1799 book, class_1306 arm,
                                                                            class_4587 poseStack, class_4597 buffer,
                                                                            int packedLight, M entityModel, class_557 bookModel) {
        poseStack.method_22903();

        // We attach the book to the left hand, to use the right hand for page flipping animation (to not move the book with the arm).
        // Unless the entity is currently swinging - in that case we still use original arm for it, to "open" the book in the correct hand.
        if (entity.field_6252) {
            entityModel.method_2803(arm, poseStack);
            poseStack.method_22904(arm == class_1306.field_6182 ? -0.285F : 0.285F, 0.625, -0.38);
        } else {
            entityModel.method_2803(class_1306.field_6182, poseStack);
            poseStack.method_22904(-0.285F, 0.625, -0.38);
        }

        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-90));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(-90));

        ReadingAnimation.poseBook(entity, book, arm, entityModel, bookModel);

        if (book.method_7969() != null && book.method_7969().method_10577(Scholar.NBT.BOOK_GOLDEN)) {
            class_4588 coverVertexConsumer = getBookCoverGoldenLocation(book).method_24145(buffer, class_1921::method_23576);
            bookModel.method_24184(poseStack, coverVertexConsumer, packedLight, class_4608.field_21444, 1, 1, 1, 1);
        } else {
            class_4588 coverVertexConsumer = getBookCoverLocation(book).method_24145(buffer, class_1921::method_23576);
            int color = BookColor.of(book);
            bookModel.method_24184(poseStack, coverVertexConsumer, packedLight, class_4608.field_21444,
                  class_5253.class_5254.method_27765(color) / 255f,
                  class_5253.class_5254.method_27766(color) / 255f,
                  class_5253.class_5254.method_27767(color) / 255f,
                  1);
        }
        class_4588 pagesVertexConsumer = getBookPagesLocation(book).method_24145(buffer, class_1921::method_23576);
        bookModel.method_24184(poseStack, pagesVertexConsumer, packedLight, class_4608.field_21444, 1, 1, 1, 1);

        poseStack.method_22909();

        if (book.method_7909() instanceof class_1840) {
            class_1306 mainArm = entity.method_6068();
            boolean isLeftArm = mainArm == class_1306.field_6182;

            poseStack.method_22903();
            entityModel.method_2803(mainArm, poseStack);
            poseStack.method_22904((float) (isLeftArm ? -1 : 1) / 16.0F - 0.05, 0.5F,
                  entityModel instanceof class_606<?> ? -0.15F : -0.22F);
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(150.0F));
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(40.0F));
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(-90));
            poseStack.method_22905(0.8f, 0.8f, 0.8f);

            class_811 context = mainArm == class_1306.field_6182
                  ? class_811.field_4323
                  : class_811.field_4320;
            class_310.method_1551().method_1561().method_43336()
                  .method_3233(entity, new class_1799(class_1802.field_8153), context, isLeftArm, poseStack, buffer, packedLight);
            poseStack.method_22909();
        }
    }

    public static void renderInFirstpersonHand(class_1309 entity, class_1799 book, class_811 displayContext, boolean leftHand,
                                               class_4587 poseStack, class_4597 buffer, int packedLight, class_557 bookModel) {
        poseStack.method_22903();

        if (leftHand) {
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(135));
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(135));
        } else {
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(45));
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(135));
        }

        bookModel.method_17073(0.0F, 0.1F, 0.9F, 1.2F);

        if (book.method_7969() != null && book.method_7969().method_10577(Scholar.NBT.BOOK_GOLDEN)) {
            class_4588 coverVertexConsumer = getBookCoverGoldenLocation(book).method_24145(buffer, class_1921::method_23576);
            bookModel.method_24184(poseStack, coverVertexConsumer, packedLight, class_4608.field_21444, 1, 1, 1, 1);
        } else {
            class_4588 coverVertexConsumer = getBookCoverLocation(book).method_24145(buffer, class_1921::method_23576);
            int color = BookColor.of(book);
            bookModel.method_24184(poseStack, coverVertexConsumer, packedLight, class_4608.field_21444,
                  class_5253.class_5254.method_27765(color) / 255f,
                  class_5253.class_5254.method_27766(color) / 255f,
                  class_5253.class_5254.method_27767(color) / 255f,
                  1);
        }
        class_4588 pagesVertexConsumer = getBookPagesLocation(book).method_24145(buffer, class_1921::method_23576);
        bookModel.method_24184(poseStack, pagesVertexConsumer, packedLight, class_4608.field_21444, 1, 1, 1, 1);
        poseStack.method_22909();
    }

    public static @NotNull class_4730 getBookCoverLocation(class_1799 book) {
        return ColoredBookModel.BOOK_COVER_LOCATION;
    }

    public static @NotNull class_4730 getBookPagesLocation(class_1799 stack) {
        return ColoredBookModel.BOOK_PAGES_LOCATION;
    }

    public static @NotNull class_4730 getBookCoverGoldenLocation(class_1799 stack) {
        return ColoredBookModel.BOOK_COVER_GOLDEN_LOCATION;
    }
}
