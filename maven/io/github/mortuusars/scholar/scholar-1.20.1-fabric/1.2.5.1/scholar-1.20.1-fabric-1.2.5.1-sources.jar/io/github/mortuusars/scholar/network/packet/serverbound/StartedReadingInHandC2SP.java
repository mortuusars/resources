package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.PacketDirection;
import io.github.mortuusars.scholar.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1840;
import net.minecraft.class_1843;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public record StartedReadingInHandC2SP(int slot) implements Packet {
    public static final class_2960 ID = Scholar.resource("started_reading_in_hand");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public class_2540 toBuffer(class_2540 buffer) {
        buffer.writeInt(slot);
        return buffer;
    }

    public static StartedReadingInHandC2SP fromBuffer(class_2540 buffer) {
        return new StartedReadingInHandC2SP(buffer.readInt());
    }

    @Override
    public boolean handle(PacketDirection direction, class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (class_1661.method_7380(slot) || slot == class_1661.field_30639) {
            class_1799 stack = serverPlayer.method_31548().method_5438(slot);
            if (stack.method_7909() instanceof class_1840 || stack.method_7909() instanceof class_1843) {
                stack.method_7948().method_10556(Scholar.NBT.BOOK_OPEN, true);
                serverPlayer.method_37908().method_43129(player, player, class_3417.field_17481, class_3419.field_15248, 1, 1);
            }
            return true;
        }

        return true;
    }
}
