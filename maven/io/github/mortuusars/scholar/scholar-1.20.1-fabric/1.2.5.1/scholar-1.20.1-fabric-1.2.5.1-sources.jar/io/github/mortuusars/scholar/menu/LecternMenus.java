package io.github.mortuusars.scholar.menu;

import io.github.mortuusars.scholar.PlatformHelper;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3722;
import net.minecraft.class_3908;
import net.minecraft.class_3913;
import org.jetbrains.annotations.NotNull;

public class LecternMenus {
    public static void openBookViewMenu(class_3222 player, class_3722 lecternBlockEntity, class_1799 bookStack) {
        class_3908 menuProvider = new class_3908() {
            @Override
            public @NotNull class_2561 method_5476() {
                return bookStack.method_7964();
            }

            @Override
            public @NotNull class_1703 createMenu(int containerId, @NotNull class_1661 playerInventory, @NotNull class_1657 player) {
                class_1263 bookAccess = lecternBlockEntity.field_17386;
                class_3913 dataAccess = lecternBlockEntity.field_17387;
                return new LecternSpreadMenu(containerId, bookAccess, dataAccess, lecternBlockEntity.method_11016());
            }
        };

        PlatformHelper.openMenu(player, menuProvider, buffer -> {
            buffer.method_10793(bookStack);
            buffer.method_10807(lecternBlockEntity.method_11016());
        });
    }

    public static void openBookEditMenu(class_3222 player, class_3722 lecternBlockEntity, class_1799 bookStack) {
        class_3908 menuProvider = new class_3908() {
            @Override
            public @NotNull class_2561 method_5476() {
                return bookStack.method_7964();
            }

            @Override
            public @NotNull class_1703 createMenu(int containerId, @NotNull class_1661 playerInventory, @NotNull class_1657 player) {
                class_1263 bookAccess = lecternBlockEntity.field_17386;
                class_3913 dataAccess = lecternBlockEntity.field_17387;
                return new LecternSpreadBookEditMenu(containerId, bookAccess, dataAccess, lecternBlockEntity.method_11016());
            }
        };

        PlatformHelper.openMenu(player, menuProvider, buffer -> {
            buffer.method_10793(bookStack);
            buffer.method_10807(lecternBlockEntity.method_11016());
        });
    }
}
