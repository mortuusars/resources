package io.github.mortuusars.scholar.mixin.literate_mobs;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.world.entity.Reading;
import net.minecraft.class_1314;
import net.minecraft.class_1352;
import net.minecraft.class_1379;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1379.class)
public abstract class RandomStrollGoalMixin extends class_1352 {
    @Shadow
    @Final
    protected class_1314 mob;

    @Inject(method = "canUse", at = @At("HEAD"), cancellable = true)
    private void onCanUse(CallbackInfoReturnable<Boolean> cir) {
        if (mob.method_5864().method_20210(Scholar.Tags.EntityTypes.LITERATE)
              && Reading.getOpenedBookHand(mob) != null
              && mob.method_6051().method_43057() > 0.05) {
            cir.setReturnValue(false); // Prevent moving when reading
        }
    }
}
