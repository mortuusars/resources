package io.github.mortuusars.scholar.network.packet.serverbound;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.PacketDirection;
import io.github.mortuusars.scholar.network.packet.Packet;
import io.github.mortuusars.scholar.util.supporter.Supporters;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

public record SetGoldenSkinInHandC2SP(int slot, boolean golden) implements Packet {
    public static final class_2960 ID = Scholar.resource("set_golden_skin_in_hand");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public static SetGoldenSkinInHandC2SP fromBuffer(class_2540 buffer) {
        return new SetGoldenSkinInHandC2SP(buffer.readInt(), buffer.readBoolean());
    }

    @Override
    public class_2540 toBuffer(class_2540 buffer) {
        buffer.writeInt(slot);
        buffer.writeBoolean(golden);
        return buffer;
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Scholar.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return true;
        }

        if (class_1661.method_7380(slot) || slot == class_1661.field_30639) {
            class_1799 stack = serverPlayer.method_31548().method_5438(slot);
            if (stack.method_31574(class_1802.field_8674) && Supporters.hasAccessToGoldenSkin(player.method_5667())) {
                if (!golden) {
                    if (stack.method_7969() != null) {
                        stack.method_7969().method_10551(Scholar.NBT.BOOK_GOLDEN);
                    }
                } else {
                    stack.method_7948().method_10556(Scholar.NBT.BOOK_GOLDEN, true);
                }
            }
            return true;
        }

        return true;
    }
}
