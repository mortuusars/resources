package io.github.mortuusars.scholar.world.entity;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import java.util.List;
import net.minecraft.class_1266;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_156;
import net.minecraft.class_173;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_52;
import net.minecraft.class_5819;
import net.minecraft.class_8567;

public class LiterateMobs {
    public static void populateEquipmentSlots(class_5819 random, class_1266 difficulty, class_1308 mob) {
        if (mob.method_37908() instanceof class_3218 serverLevel
              && mob.method_5864().method_20210(Scholar.Tags.EntityTypes.LITERATE)
              && random.method_43058() < Config.Common.LITERATE_MOBS_BOOK_SPAWN_CHANCE.get()) {
            double dropChance = Config.Common.LITERATE_MOBS_BOOK_DROP_CHANCE.get();

            class_2960 lootTableId = Scholar.LootTables.LITERATE_MOB_BOOK;
            class_52 lootTable = serverLevel.method_8503().method_3857().getLootTable(lootTableId);
            class_8567.class_8568 builder = (new class_8567.class_8568(serverLevel))
                  .method_51874(class_181.field_1226, mob)
                  .method_51874(class_181.field_24424, mob.method_19538());

            class_8567 lootParams = builder.method_51875(class_173.field_1179);
            List<class_1799> items = lootTable.method_51879(lootParams, mob.method_51851());

            if (!items.isEmpty()) {
                class_1799 item = class_156.method_32309(items, mob.method_6051());
                mob.method_5673(class_1304.field_6173, item);
                mob.method_5946(class_1304.field_6173, (float) dropChance);
            }
        }
    }
}
