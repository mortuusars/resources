package io.github.mortuusars.scholar.client.gui.screen.view;

import com.google.common.collect.ImmutableList;
import io.github.mortuusars.scholar.Scholar;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.IntFunction;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1840;
import net.minecraft.class_1843;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5348;

public interface BookViewAccess {
    BookViewAccess EMPTY = new BookViewAccess() {
        public int getPageCount() {
            return 0;
        }

        public class_5348 getPageRaw(int i) {
            return class_5348.field_25310;
        }

        @Override
        public boolean isGolden() {
            return false;
        }
    };

    boolean isGolden();
    int getPageCount();
    class_5348 getPageRaw(int pageIndex);
    default int getBookmarkedPage() {
        return 0;
    }
    default void setBookmarkedPage(@Nullable Integer page) {}

    default class_5348 getPage(int pageIndex) {
        return pageIndex >= 0 && pageIndex < getPageCount() ? getPageRaw(pageIndex) : class_5348.field_25310;
    }

    static BookViewAccess fromItem(class_1799 itemStack) {
        if (itemStack.method_7909() instanceof class_1843) {
            return new WrittenBookAccess(itemStack);
        } else if (itemStack.method_7909() instanceof class_1840) {
            return new WritableBookAccess(itemStack);
        } else {
            return EMPTY;
        }
    }

    static List<String> loadPages(class_2487 compoundTag) {
        ImmutableList.Builder<String> builder = ImmutableList.builder();
        Objects.requireNonNull(builder);
        loadPages(compoundTag, builder::add);
        return builder.build();
    }

    static void loadPages(class_2487 compoundTag, Consumer<String> consumer) {
        class_2499 listTag = compoundTag.method_10554("pages", 8).method_10612();
        IntFunction<String> intFunction;
        if (class_310.method_1551().method_33883() && compoundTag.method_10573("filtered_pages", 10)) {
            class_2487 compoundTag2 = compoundTag.method_10562("filtered_pages");
            intFunction = (ix) -> {
                String string = String.valueOf(ix);
                return compoundTag2.method_10545(string) ? compoundTag2.method_10558(string) : listTag.method_10608(ix);
            };
        } else {
            Objects.requireNonNull(listTag);
            intFunction = listTag::method_10608;
        }

        for (int i = 0; i < listTag.size(); ++i) {
            consumer.accept(intFunction.apply(i));
        }
    }

    class WritableBookAccess implements BookViewAccess {
        private final List<String> pages;
        private final class_1799 bookStack;

        public WritableBookAccess(class_1799 itemStack) {
            this.pages = readPages(itemStack);
            this.bookStack = itemStack;
        }

        @Override
        public boolean isGolden() {
            return bookStack.method_7969() != null && bookStack.method_7969().method_10577(Scholar.NBT.BOOK_GOLDEN);
        }

        private static List<String> readPages(class_1799 itemStack) {
            class_2487 compoundTag = itemStack.method_7969();
            return (class_1843.method_8053(compoundTag) ?
                  loadPages(compoundTag) :
                  ImmutableList.of(class_2561.class_2562.method_10867(class_2561.method_43471("book.invalid.tag")
                        .method_27692(class_124.field_1079))));
        }

        public int getPageCount() {
            return 100;
        }

        public class_5348 getPageRaw(int i) {
            return i >= pages.size() ? class_5348.field_25310 : class_5348.method_29430(this.pages.get(i));
        }

        @Override
        public int getBookmarkedPage() {
            return bookStack.method_7969() != null ? bookStack.method_7969().method_10550(Scholar.NBT.BOOKMARK) : 0;
        }

        @Override
        public void setBookmarkedPage(@Nullable Integer page) {
            if (page == null) {
                if (bookStack.method_7969() != null) {
                    bookStack.method_7969().method_10551(Scholar.NBT.BOOKMARK);
                }
            } else {
                bookStack.method_7948().method_10569(Scholar.NBT.BOOKMARK, page);
            }
        }
    }

    class WrittenBookAccess implements BookViewAccess {
        private final List<String> pages;
        private final class_1799 bookStack;

        public WrittenBookAccess(class_1799 bookStack) {
            this.pages = readPages(bookStack);
            this.bookStack = bookStack;
        }

        @Override
        public boolean isGolden() {
            return bookStack.method_7969() != null && bookStack.method_7969().method_10577(Scholar.NBT.BOOK_GOLDEN);
        }

        private static List<String> readPages(class_1799 itemStack) {
            class_2487 compoundTag = itemStack.method_7969();
            return (class_1843.method_8053(compoundTag) ?
                  loadPages(compoundTag) :
                  ImmutableList.of(class_2561.class_2562.method_10867(class_2561.method_43471("book.invalid.tag")
                        .method_27692(class_124.field_1079))));
        }

        public int getPageCount() {
            return this.pages.size();
        }

        public @NotNull class_5348 getPageRaw(int i) {
            String string = this.pages.get(i);

            try {
                class_5348 formattedText = class_2561.class_2562.method_10877(string);
                if (formattedText != null) {
                    return formattedText;
                }
            } catch (Exception ignored) {
            }

            return class_5348.method_29430(string);
        }

        @Override
        public int getBookmarkedPage() {
            return bookStack.method_7969() != null ? bookStack.method_7969().method_10550(Scholar.NBT.BOOKMARK) : 0;
        }

        @Override
        public void setBookmarkedPage(@Nullable Integer page) {
            if (page == null) {
                if (bookStack.method_7969() != null) {
                    bookStack.method_7969().method_10551(Scholar.NBT.BOOKMARK);
                }
            } else {
                bookStack.method_7948().method_10569(Scholar.NBT.BOOKMARK, page);
            }
        }
    }
}
