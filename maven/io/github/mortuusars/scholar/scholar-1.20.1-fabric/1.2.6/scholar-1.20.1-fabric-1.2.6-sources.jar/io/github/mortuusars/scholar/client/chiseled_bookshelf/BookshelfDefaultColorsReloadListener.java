package io.github.mortuusars.scholar.client.chiseled_bookshelf;

import com.google.common.collect.ImmutableMap;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4309;

public class BookshelfDefaultColorsReloadListener extends class_4309 {
    private static final Logger LOGGER = LogUtils.getLogger();

    public static final Codec<Map<class_2960, BookshelfDefaultColors>> CODEC =
          Codec.unboundedMap(class_2960.field_25139, BookshelfDefaultColors.CODEC);

    public BookshelfDefaultColorsReloadListener() {
        super(new Gson(), "chiseled_bookshelf/default_colors");
    }

    @Override
    protected void apply(Map<class_2960, JsonElement> map, class_3300 resourceManager, class_3695 profiler) {
        Map<class_2960, BookshelfDefaultColors> bookshelfColors = new HashMap<>();

        for (Map.Entry<class_2960, JsonElement> entry : map.entrySet()) {
            class_2960 location = entry.getKey();
            if (!location.method_12836().equals("scholar")) {
                LOGGER.info("Ignoring chiseled bookshelf default color definition '{}' because it's not in Scholar namespace.", location);
                continue;
            }

            CODEC.decode(JsonOps.INSTANCE, entry.getValue())
                  .resultOrPartial(err -> LOGGER.error("Contents of '{}' cannot be parsed as a valid id to color list map: {}", location, err))
                  .ifPresent(data -> bookshelfColors.putAll(data.getFirst()));
        }

        ChiseledBookshelfColors.DEFAULT_SLOT_COLORS = ImmutableMap.copyOf(bookshelfColors);
    }
}