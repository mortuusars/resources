package io.github.mortuusars.scholar.fabric;

import fuzs.forgeconfigapiport.api.config.v2.ForgeConfigRegistry;
import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.network.fabric.PacketsImpl;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.class_1802;
import net.minecraft.class_5620;
import net.minecraft.world.item.*;
import net.minecraftforge.fml.config.ModConfig;

public class ScholarFabric implements ModInitializer {
    @Override
    public void onInitialize() {
        ForgeConfigRegistry.INSTANCE.register(Scholar.ID, ModConfig.Type.COMMON, Config.Common.SPEC);
        ForgeConfigRegistry.INSTANCE.register(Scholar.ID, ModConfig.Type.CLIENT, Config.Client.SPEC);

        Scholar.init();

        if (Config.Common.WRITABLE_BOOK_COLORING.get()) {
            class_5620.field_27776.put(class_1802.field_8674, class_5620.field_27782);
        }

        if (Config.Common.WRITTEN_BOOK_COLORING.get()) {
            class_5620.field_27776.put(class_1802.field_8360, class_5620.field_27782);
        }

        ServerLifecycleEvents.SERVER_STARTING.register(PacketsImpl::onServerStarting);
        ServerLifecycleEvents.SERVER_STOPPED.register(PacketsImpl::onServerStopped);
        PacketsImpl.registerC2SPackets();
    }
}