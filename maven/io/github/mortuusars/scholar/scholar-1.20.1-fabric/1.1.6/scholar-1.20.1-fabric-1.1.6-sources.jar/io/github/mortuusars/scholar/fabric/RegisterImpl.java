package io.github.mortuusars.scholar.fabric;

import io.github.mortuusars.scholar.Register;
import io.github.mortuusars.scholar.Scholar;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1865;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_3414;
import net.minecraft.class_3917;
import net.minecraft.class_4048;
import net.minecraft.class_7923;
import java.util.function.Supplier;

public class RegisterImpl {
    public static <T extends class_2248> Supplier<T> block(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41175, Scholar.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_2591<E>, E extends class_2586> Supplier<T> blockEntityType(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41181, Scholar.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_2586> class_2591<T> newBlockEntityType(Register.BlockEntitySupplier<T> blockEntitySupplier, class_2248... validBlocks) {
        return FabricBlockEntityTypeBuilder.create(blockEntitySupplier::create, validBlocks).build();
    }

    public static <T extends class_1792> Supplier<T> item(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41178, Scholar.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_1297> Supplier<class_1299<T>> entityType(String id, class_1299.class_4049<T> factory,
                                                                        class_1311 category, float width, float height,
                                                                        int clientTrackingRange, boolean velocityUpdates, int updateInterval) {
        class_1299<T> type = class_2378.method_10230(class_7923.field_41177, Scholar.resource(id),
                FabricEntityTypeBuilder.create(category, factory)
                        .dimensions(class_4048.method_18385(width, height))
                        .trackRangeBlocks(clientTrackingRange)
                        .forceTrackedVelocityUpdates(velocityUpdates)
                        .trackedUpdateRate(updateInterval)
                        .build());
        return () -> type;
    }

    public static <T extends class_3414> Supplier<T> soundEvent(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41172, Scholar.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_3917<E>, E extends class_1703> Supplier<class_3917<E>> menuType(String id, Register.MenuTypeSupplier<E> supplier) {
        ExtendedScreenHandlerType<E> type = class_2378.method_10230(class_7923.field_41187, Scholar.resource(id),
                new ExtendedScreenHandlerType<>(supplier::create));
        return () -> type;
    }

    public static Supplier<class_1865<?>> recipeSerializer(String id, Supplier<class_1865<?>> supplier) {
        class_1865<?> obj = class_2378.method_10230(class_7923.field_41189, Scholar.resource(id), supplier.get());
        return () -> obj;
    }
}
