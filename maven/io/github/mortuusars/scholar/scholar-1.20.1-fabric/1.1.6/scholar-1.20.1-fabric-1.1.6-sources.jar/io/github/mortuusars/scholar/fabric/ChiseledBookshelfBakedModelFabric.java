package io.github.mortuusars.scholar.fabric;

import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.fabricmc.fabric.impl.renderer.VanillaModelEncoder;
import net.minecraft.class_1087;
import net.minecraft.class_156;
import net.minecraft.class_1802;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_5819;
import net.minecraft.class_7716;
import net.minecraft.class_777;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/**
 * A wrapper for chiseled bookshelf baked models that removes tinted quads when the corresponding chiseled bookshelf
 * slot contains an untinted item, allowing the vanilla book slot texture to show.
 */
public class ChiseledBookshelfBakedModelFabric extends ForwardingBakedModel {
    public static final Object2IntMap<class_2960> CHISELED_BOOKSHELF_OCCUPIED_SLOTS = class_156.method_654(new Object2IntArrayMap<>(),
            map -> {
                map.put(new class_2960("block/chiseled_bookshelf_occupied_slot_top_left"), 0);
                map.put(new class_2960("block/chiseled_bookshelf_occupied_slot_top_mid"), 1);
                map.put(new class_2960("block/chiseled_bookshelf_occupied_slot_top_right"), 2);
                map.put(new class_2960("block/chiseled_bookshelf_occupied_slot_bottom_left"), 3);
                map.put(new class_2960("block/chiseled_bookshelf_occupied_slot_bottom_mid"), 4);
                map.put(new class_2960("block/chiseled_bookshelf_occupied_slot_bottom_right"), 5);
            });

    private final Map<class_2350, List<class_777>> quadMap;
    private final int slot;

    public ChiseledBookshelfBakedModelFabric(class_1087 bakedModel, Map<class_2350, List<class_777>> quadMap, int slot) {
        this.wrapped = bakedModel;
        this.quadMap = quadMap;
        this.slot = slot;
    }

    public static class_1087 modifyModelAfterBake(@Nullable class_1087 bakedModel, ModelModifier.AfterBake.Context context) {
        if (bakedModel != null && CHISELED_BOOKSHELF_OCCUPIED_SLOTS.containsKey(context.id())) {
            Map<class_2350, List<class_777>> quadMap = new HashMap<>();
            getUntintedQuads(bakedModel, null, quadMap);
            for (class_2350 direction : class_2350.values()) {
                getUntintedQuads(bakedModel, direction, quadMap);
            }
            return new ChiseledBookshelfBakedModelFabric(bakedModel,
                    quadMap,
                    CHISELED_BOOKSHELF_OCCUPIED_SLOTS.getInt(context.id()));
        } else {
            return bakedModel;
        }
    }

    static void getUntintedQuads(class_1087 bakedModel, @Nullable class_2350 direction, Map<class_2350, List<class_777>> quadMap) {
        List<class_777> quads = new ArrayList<>(bakedModel.method_4707(null, direction, class_5819.method_43047()));
        quads.removeIf(class_777::method_3360);
        quadMap.put(direction, quads);
    }

    @Override
    public List<class_777> getQuads(class_2680 blockState, class_2350 face, class_5819 rand) {
        return this.quadMap.get(face);
    }

    @Override
    public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
        if (blockView.method_8321(pos) instanceof class_7716 blockEntity &&
                (blockEntity.method_5438(this.slot).method_31574(class_1802.field_8674) ||  blockEntity.method_5438(this.slot).method_31574(class_1802.field_8360))) {
            super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
        } else {
            VanillaModelEncoder.emitBlockQuads(this, state, randomSupplier, context, context.getEmitter());
        }
    }
}
