package io.github.mortuusars.scholar.client.render;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.book.BookColor;
import io.github.mortuusars.scholar.integration.Mods;
import io.github.mortuusars.scholar.integration.mcbv.MoreChiseledBookshelfVariantsIntegration;
import io.github.mortuusars.scholar.integration.woodworks.WoodworksIntegration;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.function.BiConsumer;
import net.minecraft.class_1799;
import net.minecraft.class_1840;
import net.minecraft.class_1843;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2383;
import net.minecraft.class_241;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_322;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_7714;
import net.minecraft.class_7716;
import net.minecraft.class_7923;
import net.minecraft.class_8002;

public class ChiseledBookShelf {
    public static final int DEFAULT_TINT_SLOT_0 = 0xFF1AB8BC;
    public static final int DEFAULT_TINT_SLOT_1 = 0xFF78B140;
    public static final int DEFAULT_TINT_SLOT_2 = 0xFFA743E5;
    public static final int DEFAULT_TINT_SLOT_3 = 0xFFD44A6E;
    public static final int DEFAULT_TINT_SLOT_4 = 0xFFD57856;
    public static final int DEFAULT_TINT_SLOT_5 = 0xFF2F6BC6;

    public static final Map<class_2960, Integer> CUSTOM_COLORS = new HashMap<>();

    static {
        CUSTOM_COLORS.put(new class_2960("minecraft:book"), 0xFF9C763E);
        CUSTOM_COLORS.put(new class_2960("exposure:album"), 0xFFA43E2C);
        CUSTOM_COLORS.put(new class_2960("exposure:signed_album"), 0xFFA43E2C);
    }

    public static int getSlotTintColor(class_2680 state, @Nullable class_1920 blockGetter,
                                       @Nullable class_2338 pos, int tintIndex) {
        if (!Config.Common.CHISELED_BOOKSHELF_COLORS.get()) {
            return getDefaultTintColorForSlot(state, tintIndex);
        }

        if (blockGetter == null || pos == null || tintIndex < 0 || tintIndex > 5
                || !(blockGetter.method_8321(pos) instanceof class_7716 blockEntity)) {
            return getDefaultTintColorForSlot(state, tintIndex);
        }

        class_1799 stackInSlot = blockEntity.method_5438(tintIndex);
        if (stackInSlot.method_7960()) return -1;

        if (stackInSlot.method_7909() instanceof class_1843 || stackInSlot.method_7909() instanceof class_1840) {
            return BookColor.of(stackInSlot);
        }

        return CUSTOM_COLORS.getOrDefault(class_7923.field_41178.method_10221(stackInSlot.method_7909()), getDefaultTintColorForSlot(state, tintIndex));
    }

    public static int getDefaultTintColorForSlot(class_2680 state, int slot) {
        if (Mods.WOODWORKS.isLoaded()) {
            OptionalInt color = WoodworksIntegration.getDefaultTintColor(state, slot);
            if (color.isPresent()) {
                return color.getAsInt();
            }
        }

        return switch (slot) {
            case 1 -> DEFAULT_TINT_SLOT_1;
            case 2 -> DEFAULT_TINT_SLOT_2;
            case 3 -> DEFAULT_TINT_SLOT_3;
            case 4 -> DEFAULT_TINT_SLOT_4;
            case 5 -> DEFAULT_TINT_SLOT_5;
            default -> DEFAULT_TINT_SLOT_0;
        };
    }

    public static void renderSlotTooltip(class_332 guiGraphics, float partialTick) {
        if (!Config.Common.CHISELED_BOOKSHELF_TOOLTIP.get()) {
            return;
        }

        class_310 minecraft = class_310.method_1551();

        if (minecraft.field_1687 == null || minecraft.field_1724 == null || minecraft.field_1755 != null
                || !(minecraft.field_1765 instanceof class_3965 blockHitResult)) {
            return;
        }

        class_2338 hitPos = blockHitResult.method_17777();
        class_2680 blockState = minecraft.field_1687.method_8320(hitPos);

        if (!(blockState.method_26204() instanceof class_7714)) {
            return;
        }

        @Nullable class_2586 blockEntity = minecraft.field_1687.method_8321(hitPos);

        if (!(blockEntity instanceof class_7716 chiseledBookShelfBlockEntity)) {
            return;
        }

        Optional<class_241> blockHitPos = class_7714.method_47579(blockHitResult,
                blockState.method_11654(class_2383.field_11177));
        if (blockHitPos.isEmpty()) {
            return;
        }

        int hitSlot = getHitSlot(blockState, blockHitPos.get());

        class_1799 bookStack = chiseledBookShelfBlockEntity.method_5438(hitSlot);
        if (bookStack.method_7960()) {
            return;
        }

        int x = minecraft.method_22683().method_4486() / 2 + 16;
        int y = minecraft.method_22683().method_4502() / 2 - 9;

        class_8002.method_47946(guiGraphics, x, y, 18, 18, 400);

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(0, 0, 400);
        guiGraphics.method_51427(bookStack, x + 1, y + 1);
        guiGraphics.method_51448().method_22909();

        guiGraphics.method_51446(minecraft.field_1772, bookStack, x + 16, y + 12);
    }

    public static int getHitSlot(class_2680 state, class_241 hitPos) {
        if (Mods.WOODWORKS.isLoaded()) {
            OptionalInt slot = WoodworksIntegration.getHitSlot(state, hitPos);
            if (slot.isPresent()) {
                return slot.getAsInt();
            }
        }

        return class_7714.method_47580(hitPos);
    }

    // --

    public static void registerBookshelfBlockColors(BiConsumer<class_322, class_2248> consumer) {
        consumer.accept(ChiseledBookShelf::getSlotTintColor, class_2246.field_40276);

        if (Mods.MCBV.isLoading()) MoreChiseledBookshelfVariantsIntegration.registerBlockColors(consumer);
        if (Mods.WOODWORKS.isLoading()) WoodworksIntegration.registerBlockColors(consumer);
    }

    public static void setBookshelfRenderLayer(BiConsumer<class_2248, class_1921> consumer) {
        consumer.accept(class_2246.field_40276, class_1921.method_23581());

        if (Mods.MCBV.isLoading()) MoreChiseledBookshelfVariantsIntegration.setRenderLayer(consumer);
        if (Mods.WOODWORKS.isLoading()) WoodworksIntegration.setRenderLayer(consumer);
    }
}
