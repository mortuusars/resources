package io.github.mortuusars.scholar.book;

import net.minecraft.class_1767;
import net.minecraft.class_1768;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class BookColor {
    public static final BookColor DEFAULT = new BookColor(0xFF99452E, null);
    private final int color;
    @Nullable
    private final class_1767 dyeColor;

    public BookColor(int color, @Nullable class_1767 dyeColor) {
        this.color = color;
        this.dyeColor = dyeColor;
    }

    public int getValue() {
        return color;
    }

    public Optional<class_1767> getDyeColor() {
        return Optional.ofNullable(dyeColor);
    }

    public class_1799 createWritableBook() {
        class_1799 itemStack = new class_1799(class_1802.field_8674);
        set(itemStack, this);
        return itemStack;
    }

    public static final List<BookColor> COLORS = Collections.synchronizedList(new ArrayList<>());

    static {
        COLORS.add(new BookColor(0xFAFEFF, class_1767.field_7952));
        COLORS.add(new BookColor(0xCCCCC8, class_1767.field_7967));
        COLORS.add(new BookColor(0x898D8F, class_1767.field_7944));
        COLORS.add(new BookColor(0x424244, class_1767.field_7963));
        COLORS.add(new BookColor(0x875734, class_1767.field_7957));
        COLORS.add(new BookColor(0xCF443C, class_1767.field_7964));
        COLORS.add(new BookColor(0xF38B35, class_1767.field_7946));
        COLORS.add(new BookColor(0xF4D146, class_1767.field_7947));
        COLORS.add(new BookColor(0x98D840, class_1767.field_7961));
        COLORS.add(new BookColor(0x61951E, class_1767.field_7942));
        COLORS.add(new BookColor(0x309E9D, class_1767.field_7955));
        COLORS.add(new BookColor(0x71CCEA, class_1767.field_7951));
        COLORS.add(new BookColor(0x4B52B0, class_1767.field_7966));
        COLORS.add(new BookColor(0x8B35B9, class_1767.field_7945));
        COLORS.add(new BookColor(0xC65FBD, class_1767.field_7958));
        COLORS.add(new BookColor(0xF588A7, class_1767.field_7954));
    }

    public static final String TAG_COLOR = "color";
    public static final String TAG_DISPLAY = "display";

    public static int of(class_1799 stack) {
        // Cannot use DyeableLeatherItem#getColor because it has different default color.
        class_2487 compoundTag = stack.method_7941(TAG_DISPLAY);
        if (compoundTag != null && compoundTag.method_10573(TAG_COLOR, class_2520.field_33263)) {
            return compoundTag.method_10550(TAG_COLOR);
        }
        return DEFAULT.getValue();
    }

    public static int getItemTintColor(class_1799 stack, int tintIndex) {
        if (tintIndex == 0) {
            return of(stack);
        }

        return -1;
    }

    public static boolean hasCustomColor(class_1799 stack) {
        return stack.method_7909() instanceof class_1768 dyeableLeatherItem && dyeableLeatherItem.method_7801(stack);
    }

    public static void clear(class_1799 stack) {
        if (stack.method_7909() instanceof class_1768 dyeableLeatherItem) {
            dyeableLeatherItem.method_7798(stack);
        }
    }

    public static void set(class_1799 stack, BookColor color) {
        set(stack, color.getValue());
    }

    public static void set(class_1799 stack, int color) {
        if (stack.method_7909() instanceof class_1768 dyeableLeatherItem) {
            dyeableLeatherItem.method_7799(stack, color);
        }
    }
}
