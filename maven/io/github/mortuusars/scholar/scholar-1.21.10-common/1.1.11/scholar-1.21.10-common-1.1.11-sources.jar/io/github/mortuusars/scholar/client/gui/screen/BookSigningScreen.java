package io.github.mortuusars.scholar.client.gui.screen;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.client.gui.Widgets;
import io.github.mortuusars.scholar.client.gui.widget.textbox.display.HorizontalAlignment;
import io.github.mortuusars.scholar.client.gui.widget.textbox.text.FormattedString;
import io.github.mortuusars.scholar.client.gui.widget.textbox.TextBox;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_10799;
import net.minecraft.class_1109;
import net.minecraft.class_11908;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_7919;
import net.minecraft.class_8666;

public class BookSigningScreen extends class_437 {
    public static final class_2960 TEXTURE = Scholar.resource("textures/gui/book_signing.png");

    public static final class_8666 SIGN_BUTTON_SPRITES = Widgets.threeStateSprites(Scholar.resource("signing/sign_button"));
    public static final class_8666 CANCEL_BUTTON_SPRITES = Widgets.threeStateSprites(Scholar.resource("signing/cancel_button"));

    @NotNull
    protected final class_310 minecraft;
    @NotNull
    protected final class_1657 player;

    protected final class_437 parentScreen;
    protected final int bookColor;
    protected final Consumer<String> onSign;

    protected int textColor;
    protected int selectionColor;
    protected int selectionUnfocusedColor;
    protected int enterBookTitleFontColor;
    protected int byAuthorFontColor;

    protected int imageWidth, imageHeight, leftPos, topPos, textureWidth, textureHeight;

    protected TextBox titleTextBox;
    protected class_344 signButton;
    protected class_344 cancelSigningButton;

    protected String titleText = "";

    public BookSigningScreen(class_437 parentScreen, int bookColor, Consumer<String> onSign) {
        super(class_2561.method_43473());
        this.parentScreen = parentScreen;
        this.bookColor = bookColor;
        this.onSign = onSign;

        this.textColor = Config.Client.getColor(Config.Client.TEXT_COLOR);
        this.selectionColor = Config.Client.getColor(Config.Client.SELECTION_COLOR);
        this.selectionUnfocusedColor = Config.Client.getColor(Config.Client.SELECTION_UNFOCUSED_COLOR);
        this.enterBookTitleFontColor = Config.Client.getColor(Config.Client.ENTER_TITLE_COLOR);
        this.byAuthorFontColor = Config.Client.getColor(Config.Client.BY_AUTHOR_COLOR);

        this.field_22787 = class_310.method_1551();
        this.player = Objects.requireNonNull(field_22787.field_1724);
        this.textureWidth = 256;
        this.textureHeight = 256;
    }

    @Override
    public boolean method_25421() {
        return Config.Client.SCREEN_PAUSE.get();
    }

    @Override
    protected void method_25426() {
        this.imageWidth = 149;
        this.imageHeight = 180;
        this.leftPos = (this.field_22789 - this.imageWidth) / 2;
        this.topPos = (this.field_22790 - this.imageHeight) / 2;

        // TITLE
        titleTextBox = new TextBox(field_22793, leftPos + 21, topPos + 71, 108, 9)
              .setFontColor(textColor)
              .setFontUnfocusedColor(textColor)
              .setSelectionColor(selectionColor)
              .setSelectionUnfocusedColor(selectionUnfocusedColor)
              .setHorizontalAlignment(HorizontalAlignment.CENTER)
              .setOnTextChanged(this::setTitleText)
              .setTextValidator(text -> text != null && field_22793.method_1713(text, 108) <= 9 && !text.contains("\n"));
        method_37063(titleTextBox);

        // SIGN
        signButton = new class_344(leftPos + 46, topPos + 108, 22, 22,
              SIGN_BUTTON_SPRITES, b -> signAlbum(), class_2561.method_43471("book.finalizeButton"));
        class_5250 component = class_2561.method_43471("book.finalizeButton")
              .method_27693("\n").method_10852(class_2561.method_43471("book.finalizeWarning").method_27692(class_124.field_1080));
        signButton.method_47400(class_7919.method_47407(component));
        method_37063(signButton);

        // CANCEL
        cancelSigningButton = new class_344(leftPos + 83, topPos + 108, 22, 22,
              CANCEL_BUTTON_SPRITES, b -> cancelSigning(), class_5244.field_24335);
        cancelSigningButton.method_47400(class_7919.method_47407(class_5244.field_24335));
        method_37063(cancelSigningButton);

        method_48265(titleTextBox);
    }

    protected void setTitleText(FormattedString text) {
        titleText = text.toString();
        updateButtons();
    }

    protected void updateButtons() {
        signButton.field_22763 = canSign();
    }

    protected boolean canSign() {
        return !titleText.isBlank();
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();

        method_52752(guiGraphics);

        // Cover
        guiGraphics.method_25291(class_10799.field_56883, TEXTURE, leftPos, topPos,
              0, 0, imageWidth, imageHeight, textureWidth, textureHeight, bookColor);

        // Label
        guiGraphics.method_25290(class_10799.field_56883, TEXTURE, leftPos, topPos + 31,
              0, 180, imageWidth, 76, textureWidth, textureHeight);

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        renderLabels(guiGraphics);
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        // Stops blur from rendering
    }

    protected void renderLabels(class_332 guiGraphics) {
        class_5250 component = class_2561.method_43471("book.editTitle");
        guiGraphics.method_51439(field_22793, component, leftPos + 149 / 2 - field_22793.method_27525(component) / 2, topPos + 51,
              enterBookTitleFontColor, false);

        component = class_2561.method_43469("book.byAuthor", player.method_5477());
        guiGraphics.method_51439(field_22793, component, leftPos + 149 / 2 - field_22793.method_27525(component) / 2, topPos + 81,
              byAuthorFontColor, false);
    }

    protected void signAlbum() {
        if (canSign()) {
            onSign.accept(titleText.trim());
            field_22787.method_1483().method_4873(
                  class_1109.method_4757(Scholar.SoundEvents.BOOK_SIGNED.get(), 1f, 0.8f));
            method_25419();
        }
    }

    protected void cancelSigning() {
        field_22787.method_1507(parentScreen);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (event.method_74231()) {
            cancelSigning();
            return true;
        }

        return super.method_25404(event);
    }
}
