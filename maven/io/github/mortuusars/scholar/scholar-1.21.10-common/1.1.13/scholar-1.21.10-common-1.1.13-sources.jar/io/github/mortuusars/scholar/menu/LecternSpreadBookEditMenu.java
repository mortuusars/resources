package io.github.mortuusars.scholar.menu;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.Spread;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1840;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_3722;
import net.minecraft.class_3913;
import net.minecraft.class_3917;
import net.minecraft.class_3919;
import net.minecraft.class_9129;
import org.jetbrains.annotations.NotNull;

public class LecternSpreadBookEditMenu extends LecternSpreadMenu {
    public LecternSpreadBookEditMenu(int containerId, class_1263 lectern, class_3913 lecternData, class_2338 lecternPos) {
        super(containerId, lectern, lecternData, lecternPos);
    }

    public static LecternSpreadBookEditMenu fromBuffer(int containerId, class_1661 inventory, class_9129 buffer) {
        return new LecternSpreadBookEditMenu(containerId, new class_1277(class_1799.field_48349.decode(buffer)),
                new class_3919(1), buffer.method_10811());
    }

    @Override
    public @NotNull class_3917<?> method_17358() {
        return Scholar.MenuTypes.LECTERN_SPREAD_BOOK_EDIT.get();
    }

    @Override
    protected int getPageCount() {
        return 100;
    }

    @Override
    protected int getSpreadCount() {
        return 50;
    }

    @Override
    public boolean method_7604(class_1657 player, int buttonId) {
        if (buttonId == field_30820 || buttonId == field_30821) {
            int currentSpreadIndex = getCurrentSpread();
            int newSpreadIndex = currentSpreadIndex + (buttonId == field_30820 ? -1 : 1);

            if (newSpreadIndex < 0 || newSpreadIndex > getSpreadCount() - 1) {
                return true;
            }

            int newPageIndex = Spread.Side.LEFT.getPageIndexFromSpread(newSpreadIndex);

            // Update pageCount for correct analog redstone output:
            if (player.method_73183().method_8321(getLecternPos()) instanceof class_3722 lecternBlockEntity) {
                lecternBlockEntity.field_17390 = Math.min(100, Spread.Side.RIGHT.getPageIndexFromSpread(newSpreadIndex) + 2);
            }

            this.method_7606(0, newPageIndex);
            return true;
        }

        return super.method_7604(player, buttonId);
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);

        // If another player(s) is viewing the same lectern - transfer editing mode to him.
        // If Writable Book is signed, other players would not have their screens closed, however.
        // But that's not a problem, they can't screw up anything anyway.
        // Their view will be the same as if they'd opened Written Book.

        if (player instanceof class_3222 serverPlayer
                && player.method_73183().method_8321(getLecternPos()) instanceof class_3722 be
                && be.method_17522()) {
            serverPlayer.method_51469().method_18456().stream()
                    .filter(pl -> !pl.equals(serverPlayer)
                            && pl.field_7512 instanceof LecternSpreadMenu lecternMenu
                            && lecternMenu.getLecternPos().equals(getLecternPos()))
                    .findFirst()
                    .ifPresent(pl -> {
                        pl.method_7346();
                        if (be.method_17520().method_7909() instanceof class_1840) {
                            Lectern.openBookEditMenu(pl, be, be.method_17520());
                        }
                    });
        }
    }
}