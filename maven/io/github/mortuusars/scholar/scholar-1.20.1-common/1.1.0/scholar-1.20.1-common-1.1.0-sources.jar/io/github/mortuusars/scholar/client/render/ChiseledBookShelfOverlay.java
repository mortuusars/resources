package io.github.mortuusars.scholar.client.render;

import io.github.mortuusars.scholar.Config;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2383;
import net.minecraft.class_241;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_7714;
import net.minecraft.class_7716;
import net.minecraft.class_8002;

public class ChiseledBookShelfOverlay {
    public static void render(class_332 guiGraphics, float partialTick) {
        if (!Config.Common.CHISELED_BOOKSHELF_TOOLTIP.get()) {
            return;
        }

        class_310 minecraft = class_310.method_1551();

        if (minecraft.field_1687 == null || minecraft.field_1724 == null || minecraft.field_1755 != null
                || !(minecraft.field_1765 instanceof class_3965 blockHitResult)) {
            return;
        }

        class_2338 hitPos = blockHitResult.method_17777();
        class_2680 blockState = minecraft.field_1687.method_8320(hitPos);

        if (!(blockState.method_26204() instanceof class_7714)) {
            return;
        }

        @Nullable class_2586 blockEntity = minecraft.field_1687.method_8321(hitPos);

        if (!(blockEntity instanceof class_7716 chiseledBookShelfBlockEntity)) {
            return;
        }

        Optional<class_241> blockHitPos = class_7714.method_47579(blockHitResult,
                blockState.method_11654(class_2383.field_11177));
        if (blockHitPos.isEmpty()) {
            return;
        }

        int hitSlot = class_7714.method_47580(blockHitPos.get());

        class_1799 bookStack = chiseledBookShelfBlockEntity.method_5438(hitSlot);
        if (bookStack.method_7960()) {
            return;
        }

        int x = minecraft.method_22683().method_4486() / 2 + 16;
        int y = minecraft.method_22683().method_4502() / 2 - 9;

        class_8002.method_47946(guiGraphics, x, y, 18, 18, 400);
//        guiGraphics.drawManaged(() -> TooltipRenderUtil.renderTooltipBackground(guiGraphics, x, y, 18, 18, 400));
        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(0, 0, 400);
        guiGraphics.method_51427(bookStack, x + 1, y + 1);
        guiGraphics.method_51448().method_22909();

        guiGraphics.method_51446(minecraft.field_1772, bookStack, x + 16, y + 12);
    }
}
