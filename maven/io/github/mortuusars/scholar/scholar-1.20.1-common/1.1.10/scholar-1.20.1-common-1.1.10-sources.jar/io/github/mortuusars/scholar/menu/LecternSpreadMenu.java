package io.github.mortuusars.scholar.menu;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.Spread;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1843;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_3532;
import net.minecraft.class_3913;
import net.minecraft.class_3916;
import net.minecraft.class_3917;
import net.minecraft.class_3919;
import org.jetbrains.annotations.NotNull;

public class LecternSpreadMenu extends class_3916 {
    protected final class_1263 lecternContainer;
    protected final class_2338 lecternPos;

    public LecternSpreadMenu(int containerId, class_1263 lectern, class_3913 lecternData, class_2338 lecternPos) {
        super(containerId, lectern, lecternData);
        this.lecternContainer = lectern;
        this.lecternPos = lecternPos;
    }

    public static LecternSpreadMenu fromBuffer(int containerId, class_1661 inventory, class_2540 buffer) {
        return new LecternSpreadMenu(containerId, new class_1277(buffer.method_10819()), new class_3919(1), buffer.method_10811());
    }

    @Override
    public @NotNull class_3917<?> method_17358() {
        return Scholar.MenuTypes.LECTERN_SPREAD_BOOK_VIEW.get();
    }

    public class_2338 getLecternPos() {
        return lecternPos;
    }

    protected int getPageCount() {
        return class_1843.method_17443(method_17418());
    }

    protected int getSpreadCount() {
        return class_3532.method_15384(getPageCount() / 2.0);
    }

    protected int getCurrentSpread() {
        return method_17419() / 2;
    }

    @Override
    public boolean method_7604(class_1657 player, int buttonId) {
        if (buttonId == field_30820 || buttonId == field_30821) {
            int currentSpreadIndex = getCurrentSpread();
            int newSpreadIndex = currentSpreadIndex + (buttonId == field_30820 ? -1 : 1);

            if (newSpreadIndex < 0 || newSpreadIndex > getSpreadCount() - 1) {
                return true;
            }

            int newPageIndex = Spread.Side.LEFT.getPageIndexFromSpread(newSpreadIndex);
            this.method_7606(0, newPageIndex);
            return true;
        }

        return super.method_7604(player, buttonId);
    }
}
