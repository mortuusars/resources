package io.github.mortuusars.scholar.network;


import com.google.common.base.Preconditions;
import dev.architectury.injectables.annotations.ExpectPlatform;
import io.github.mortuusars.scholar.network.packet.IPacket;
import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;
import net.minecraft.class_3222;
import net.minecraft.class_3324;

public class Packets {
    @ExpectPlatform
    public static void sendToServer(IPacket packet) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToClient(IPacket packet, class_3222 player) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToAllClients(IPacket packet) {
        throw new AssertionError();
    }

    public static void sendToClients(IPacket packet, class_3324 playerList, @Nullable class_3222 excludedPlayer) {
        for (class_3222 player : playerList.method_14571()) {
            if (player != excludedPlayer)
                sendToClient(packet, player);
        }
    }

    public static void sendToClients(IPacket packet, class_3222 origin, Predicate<class_3222> filter) {
        Preconditions.checkState(origin.method_5682() != null, "Server cannot be null");
        for (class_3222 player : origin.method_5682().method_3760().method_14571()) {
            if (filter.test(player))
                sendToClient(packet, player);
        }
    }

    public static void sendToOtherClients(IPacket packet, class_3222 excludedPlayer) {
        sendToClients(packet, excludedPlayer, serverPlayer -> !serverPlayer.equals(excludedPlayer));
    }

    public static void sendToOtherClients(IPacket packet, class_3222 excludedPlayer, Predicate<class_3222> filter) {
        sendToClients(packet, excludedPlayer, serverPlayer -> !serverPlayer.equals(excludedPlayer) && filter.test(serverPlayer));
    }
}