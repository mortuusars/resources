package io.github.mortuusars.scholar.integration.woodworks;

import com.teamabnormals.blueprint.common.block.BlueprintChiseledBookShelfBlock;
import java.util.OptionalInt;
import net.minecraft.class_241;
import net.minecraft.class_2680;

public class WoodworksIntegration {
    public static OptionalInt getHitSlot(class_2680 state, class_241 hitPos) {
        if (state.method_26204() instanceof BlueprintChiseledBookShelfBlock block) {
            return OptionalInt.of(block.m_261279_(hitPos));
        }
        return OptionalInt.empty();
    }
}
