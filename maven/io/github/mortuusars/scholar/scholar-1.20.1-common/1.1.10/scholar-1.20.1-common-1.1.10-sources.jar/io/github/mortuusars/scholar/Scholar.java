package io.github.mortuusars.scholar;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.scholar.item.ColoredWritableBookItem;
import io.github.mortuusars.scholar.item.ColoredWrittenBookItem;
import io.github.mortuusars.scholar.menu.LecternSpreadBookEditMenu;
import io.github.mortuusars.scholar.menu.LecternSpreadMenu;
import io.github.mortuusars.scholar.recipe.NbtTransferringRecipe;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3917;

public class Scholar {
    public static final String ID = "scholar";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static class_2960 resource(String path) {
        return new class_2960(Scholar.ID, path);
    }

    public static void init() {
        Items.init();
        MenuTypes.init();
        RecipeSerializers.init();
        SoundEvents.init();
    }

    @SuppressWarnings("removal")
    public static class Items {
        public static final Map<class_1767, Supplier<ColoredWritableBookItem>> COLORED_WRITABLE_BOOKS;
        public static final Map<class_1767, Supplier<ColoredWrittenBookItem>> COLORED_WRITTEN_BOOKS;

        static {
            COLORED_WRITABLE_BOOKS = new HashMap<>();
            for (class_1767 color : class_1767.values()) {
                COLORED_WRITABLE_BOOKS.put(color, Register.item(color.method_15434() + "_writable_book",
                        () -> new ColoredWritableBookItem(color, new class_1792.class_1793().method_7889(1))));
            }

            COLORED_WRITTEN_BOOKS = new HashMap<>();
            for (class_1767 color : class_1767.values()) {
                COLORED_WRITTEN_BOOKS.put(color, Register.item(color.method_15434() + "_written_book",
                        () -> new ColoredWrittenBookItem(color, new class_1792.class_1793().method_7889(16))));
            }
        }

        static void init() { }
    }

    public static class MenuTypes {
        public static final Supplier<class_3917<LecternSpreadMenu>> LECTERN_SPREAD_BOOK_VIEW =
                Register.menuType("lectern_spread_book_view", LecternSpreadMenu::fromBuffer);
        public static final Supplier<class_3917<LecternSpreadBookEditMenu>> LECTERN_SPREAD_BOOK_EDIT =
                Register.menuType("lectern_spread_book_edit", LecternSpreadBookEditMenu::fromBuffer);

        static void init() { }
    }

    public static class RecipeSerializers {
        public static final Supplier<class_1865<?>> NBT_TRANSFERRING = Register.recipeSerializer("nbt_transferring",
                NbtTransferringRecipe.Serializer::new);
        static void init() { }
    }

    public static class SoundEvents {
        public static final Supplier<class_3414> BOOK_SIGNED = register("book", "signed");

        @SuppressWarnings("SameParameterValue")
        private static Supplier<class_3414> register(String category, String key) {
            Preconditions.checkState(category != null && !category.isEmpty(), "'category' should not be empty.");
            Preconditions.checkState(key != null && !key.isEmpty(), "'key' should not be empty.");
            String path = category + "." + key;
            return Register.soundEvent(path, () -> class_3414.method_47908(Scholar.resource(path)));
        }

        static void init() { }
    }
}