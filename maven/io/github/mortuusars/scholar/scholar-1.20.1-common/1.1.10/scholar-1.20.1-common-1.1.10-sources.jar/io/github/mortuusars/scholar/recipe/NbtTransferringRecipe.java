package io.github.mortuusars.scholar.recipe;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import io.github.mortuusars.scholar.Scholar;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class NbtTransferringRecipe extends class_1852 {
    private final class_1799 result;
    private final class_1856 transferIngredient;
    private final class_2371<class_1856> ingredients;

    public NbtTransferringRecipe(class_2960 id, class_1856 transferIngredient, class_2371<class_1856> ingredients, class_1799 result) {
        super(id, class_7710.field_40251);
        this.transferIngredient = transferIngredient;
        this.ingredients = ingredients;
        this.result = result;
    }

    public @NotNull class_1856 getTransferIngredient() {
        return transferIngredient;
    }

    @Override
    public @NotNull class_2371<class_1856> method_8117() {
        return ingredients;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return Scholar.RecipeSerializers.NBT_TRANSFERRING.get();
    }

    @Override
    public @NotNull class_1799 method_8110(class_5455 registryAccess) {
        return getResult();
    }

    public @NotNull class_1799 getResult() {
        return result;
    }

    @Override
    public boolean matches(class_8566 container, class_1937 level) {
        if (getTransferIngredient().method_8103() || ingredients.isEmpty())
            return false;

        List<class_1856> unmatchedIngredients = new ArrayList<>(ingredients);
        unmatchedIngredients.add(0, getTransferIngredient());

        int itemsInCraftingGrid = 0;

        for (int i = 0; i < container.method_5439(); i++) {
            class_1799 stack = container.method_5438(i);
            if (!stack.method_7960())
                itemsInCraftingGrid++;

            if (itemsInCraftingGrid > ingredients.size() + 1)
                return false;

            if (!unmatchedIngredients.isEmpty()) {
                for (int j = 0; j < unmatchedIngredients.size(); j++) {
                    if (unmatchedIngredients.get(j).method_8093(stack)) {
                        unmatchedIngredients.remove(j);
                        break;
                    }
                }
            }
        }

        return unmatchedIngredients.isEmpty() && itemsInCraftingGrid == ingredients.size() + 1;
    }

    @Override
    public @NotNull class_1799 assemble(class_8566 container, @NotNull class_5455 registryAccess) {
        for (int index = 0; index < container.method_5439(); index++) {
            class_1799 itemStack = container.method_5438(index);

            if (getTransferIngredient().method_8093(itemStack)) {
                return transferNbt(itemStack, method_8110(registryAccess).method_7972());
            }
        }

        return method_8110(registryAccess);
    }

    public @NotNull class_1799 transferNbt(class_1799 transferIngredientStack, class_1799 recipeResultStack) {
        @Nullable class_2487 transferTag = transferIngredientStack.method_7969();
        if (transferTag != null) {
            if (recipeResultStack.method_7969() != null)
                recipeResultStack.method_7969().method_10543(transferTag);
            else
                recipeResultStack.method_7980(transferTag.method_10553());
        }
        return recipeResultStack;
    }

    @Override
    public boolean method_8113(int width, int height) {
        return ingredients.size() <= width * height;
    }

    public static class Serializer implements class_1865<NbtTransferringRecipe> {
        @Override
        public @NotNull NbtTransferringRecipe method_8121(class_2960 recipeId, JsonObject serializedRecipe) {
            class_1856 sourceIngredient = class_1856.method_52177(class_3518.method_52226(serializedRecipe, "source"));
            class_2371<class_1856> ingredients = getIngredients(class_3518.method_15261(serializedRecipe, "ingredients"));
            class_1799 result = class_1869.method_35228(class_3518.method_15296(serializedRecipe, "result"));

            if (sourceIngredient.method_8103())
                throw new JsonParseException("Recipe should have 'source' ingredient.");

            return new NbtTransferringRecipe(recipeId, sourceIngredient, ingredients, result);
        }

        @Override
        public @NotNull NbtTransferringRecipe method_8122(class_2960 recipeId, class_2540 buffer) {
            class_1856 transferredIngredient = class_1856.method_8086(buffer);
            int ingredientsCount = buffer.method_10816();
            class_2371<class_1856> ingredients = class_2371.method_10213(ingredientsCount, class_1856.field_9017);
            ingredients.replaceAll(ignored -> class_1856.method_8086(buffer));
            class_1799 result = buffer.method_10819();

            return new NbtTransferringRecipe(recipeId, transferredIngredient, ingredients, result);
        }

        @Override
        public void toNetwork(class_2540 buffer, NbtTransferringRecipe recipe) {
            recipe.getTransferIngredient().method_8088(buffer);
            buffer.method_10804(recipe.method_8117().size());
            for (class_1856 ingredient : recipe.method_8117()) {
                ingredient.method_8088(buffer);
            }
            buffer.method_10793(recipe.getResult());
        }

        private class_2371<class_1856> getIngredients(JsonArray jsonArray) {
            class_2371<class_1856> ingredients = class_2371.method_10211();

            for (int i = 0; i < jsonArray.size(); ++i) {
                class_1856 ingredient = class_1856.method_52177(jsonArray.get(i));
                if (!ingredient.method_8103())
                    ingredients.add(ingredient);
            }

            if (ingredients.isEmpty())
                throw new JsonParseException("No ingredients for a recipe.");
            else if (ingredients.size() > 3 * 3)
                throw new JsonParseException("Too many ingredients for a recipe. The maximum is 9.");
            return ingredients;
        }
    }
}
