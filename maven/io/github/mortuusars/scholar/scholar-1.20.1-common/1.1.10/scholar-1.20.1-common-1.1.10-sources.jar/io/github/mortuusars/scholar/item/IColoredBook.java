package io.github.mortuusars.scholar.item;

import net.minecraft.class_1767;

@Deprecated(forRemoval = true)
public interface IColoredBook {
    class_1767 getColor();
}
