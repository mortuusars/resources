package io.github.mortuusars.scholar.mixin;

import io.github.mortuusars.scholar.book.BookColor;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1843;
import net.minecraft.class_1850;
import net.minecraft.class_2487;
import net.minecraft.class_5455;
import net.minecraft.class_8566;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1850.class)
public class BookCloningRecipeMixin {
    // 'BookCloningRecipe#matches' may need to be changed as well. But it seems to work fine without it.

    /**
     * Purpose of this mixin is to disallow writable books of different colors to be in a craft.
     * And set the color of a result book to color of writable book.
     * -
     * This mixin basically overrides whole method which may cause compatibility issues. But it would require more mixins to change it in specific parts.
     * Mods that modify this recipe should be very rare anyway.
     */
    @Inject(method = "assemble(Lnet/minecraft/world/inventory/CraftingContainer;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/world/item/ItemStack;",
            at = @At("HEAD"), cancellable = true)
    private void onAssemble(class_8566 container, class_5455 registryAccess, CallbackInfoReturnable<class_1799> cir) {
        class_1799 inputBook = class_1799.field_8037;
        @Nullable Integer resultColor = null;
        int copies = 0;

        for (int slot = 0; slot < container.method_5439(); ++slot) {
            class_1799 stack = container.method_5438(slot);
            if (stack.method_7960()) {
                continue;
            }

            if (stack.method_31574(class_1802.field_8360)) {
                if (!inputBook.method_7960()) {
                    cir.setReturnValue(class_1799.field_8037);
                    return; // multiple written books as inputs are not allowed
                }

                inputBook = stack;
                continue;
            }

            if (stack.method_31574(class_1802.field_8674)) {
                // Since result book will get writable book color - books of different colors are not allowed.
                int color = BookColor.of(stack);
                if (resultColor == null) {
                    resultColor = color;
                }
                else if (resultColor != color) {
                    cir.setReturnValue(class_1799.field_8037);
                    return;
                }

                ++copies;
                continue;
            }
            cir.setReturnValue(class_1799.field_8037);
            return;
        }

        if (inputBook.method_7960() || inputBook.method_7969() == null || copies < 1 || class_1843.method_8052(inputBook) >= 2) {
            cir.setReturnValue(class_1799.field_8037);
            return; // Cannot be copied
        }

        class_1799 resultStack = new class_1799(class_1802.field_8360, copies);
        class_2487 inputBookTag = inputBook.method_7969().method_10553();
        inputBookTag.method_10569("generation", class_1843.method_8052(inputBook) + 1);
        resultStack.method_7980(inputBookTag);
        BookColor.set(resultStack, resultColor);
        cir.setReturnValue(resultStack);
    }
}
