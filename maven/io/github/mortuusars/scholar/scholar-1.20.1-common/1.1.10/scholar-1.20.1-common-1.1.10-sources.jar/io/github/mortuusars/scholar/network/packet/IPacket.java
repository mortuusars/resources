package io.github.mortuusars.scholar.network.packet;

import io.github.mortuusars.scholar.network.PacketDirection;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public interface IPacket {
    default class_2540 toBuffer(class_2540 buffer) { return buffer; }
    /**
     * @param player will be null when on the client.
     */
    boolean handle(PacketDirection direction, @Nullable class_1657 player);
    class_2960 getId();
}