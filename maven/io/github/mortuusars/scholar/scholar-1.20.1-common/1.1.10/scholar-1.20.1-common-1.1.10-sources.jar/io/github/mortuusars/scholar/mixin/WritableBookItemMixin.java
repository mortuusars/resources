package io.github.mortuusars.scholar.mixin;

import net.minecraft.class_1768;
import net.minecraft.class_1840;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Adds DyeableLeatherItem interface to writable books. This makes it handle most of the coloring stuff automatically.
 * But can potentially introduce unwanted behaviour for mods that extend WritableBookItem for their items.
 */
@Mixin(class_1840.class)
public abstract class WritableBookItemMixin implements class_1768 {

}
