package io.github.mortuusars.scholar.item;

import io.github.mortuusars.scholar.Scholar;
import io.github.mortuusars.scholar.book.BookColor;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1840;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

@Deprecated(forRemoval = true)
public class ColoredWritableBookItem extends class_1840 implements IColoredBook {
    private final class_1767 color;

    public ColoredWritableBookItem(class_1767 color, class_1793 properties) {
        super(properties);
        this.color = color;
    }

    @Override
    public class_1767 getColor() {
        return color;
    }

    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 level, List<class_2561> tooltipComponents, class_1836 isAdvanced) {
        tooltipComponents.add(class_2561.method_43471("item.scholar.deprecated_book_message").method_27692(class_124.field_1061));
        tooltipComponents.add(class_2561.method_43471("item.scholar.convert_book_message").method_27692(class_124.field_1061));
        super.method_7851(stack, level, tooltipComponents, isAdvanced);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        class_1799 deprecatedStack = player.method_5998(usedHand);

        class_1799 correctStack = new class_1799(class_1802.field_8674);
        correctStack.method_7980(deprecatedStack.method_7969());

        BookColor color = BookColor.COLORS.stream()
                .filter(c -> c.getDyeColor()
                        .map(dye -> dye.equals(getColor()))
                        .orElse(false))
                .findFirst()
                .orElse(BookColor.DEFAULT);

        BookColor.set(correctStack, color);

        player.method_5783(Scholar.SoundEvents.BOOK_SIGNED.get(), 1f, 1f);

        return class_1271.method_22427(correctStack);
    }
}
