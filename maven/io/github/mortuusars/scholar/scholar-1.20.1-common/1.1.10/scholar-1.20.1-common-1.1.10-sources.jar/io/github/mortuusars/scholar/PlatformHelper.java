package io.github.mortuusars.scholar;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3908;

public class PlatformHelper {
    @ExpectPlatform
    public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_2540> extraDataWriter) {
        throw new AssertionError();
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    @ExpectPlatform
    public static boolean isModLoaded(String modId) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isModLoading(String modId) {
        throw new AssertionError();
    }
}
