package io.github.mortuusars.scholar.mixin;

import io.github.mortuusars.scholar.Config;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1849;
import net.minecraft.class_1937;
import net.minecraft.class_5455;
import net.minecraft.class_8566;
import net.minecraft.world.item.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Since we made WritableBookItem and WrittenBookItem to be DyeableLeatherItem, this recipe will automatically match them if crafted.
 * So we need to disable 'matches' and 'assemble' if coloring was disabled in config.
 * Also, all books are now dyeable, not just vanilla ones.
 * This may cause unwanted behaviour for mods that add their variants of Writable and Written books.
 */
@Mixin(class_1849.class)
public class ArmorDyeRecipeMixin {
    @Inject(method = "matches(Lnet/minecraft/world/inventory/CraftingContainer;Lnet/minecraft/world/level/Level;)Z", at = @At("HEAD"), cancellable = true)
    private void onMatches(class_8566 container, class_1937 level, CallbackInfoReturnable<Boolean> cir) {
        for (class_1799 stack : container.method_51305()) {
            if (stack.method_31574(class_1802.field_8674) && !Config.Common.WRITABLE_BOOK_COLORING.get()) {
                cir.setReturnValue(false);
                return;
            }

            if (stack.method_31574(class_1802.field_8360) && !Config.Common.WRITTEN_BOOK_COLORING.get()) {
                cir.setReturnValue(false);
                return;
            }
        }
    }

    @Inject(method = "assemble(Lnet/minecraft/world/inventory/CraftingContainer;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/world/item/ItemStack;", at = @At("HEAD"), cancellable = true)
    private void onAssemble(class_8566 container, class_5455 registryAccess, CallbackInfoReturnable<class_1799> cir) {
        for (class_1799 stack : container.method_51305()) {
            if (stack.method_31574(class_1802.field_8674) && !Config.Common.WRITABLE_BOOK_COLORING.get()) {
                cir.setReturnValue(class_1799.field_8037);
                return;
            }

            if (stack.method_31574(class_1802.field_8360) && !Config.Common.WRITTEN_BOOK_COLORING.get()) {
                cir.setReturnValue(class_1799.field_8037);
                return;
            }
        }
    }
}
