package io.github.mortuusars.scholar.world.entity;

import io.github.mortuusars.scholar.Config;
import io.github.mortuusars.scholar.Scholar;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1560;
import org.jetbrains.annotations.Nullable;

public class Reading {
    public static @Nullable class_1268 getOpenedBookHand(class_1309 entity) {
        if (!Config.Common.BOOK_READING_ANIMATION.get()) return null;
        if (entity instanceof class_1560) return null; // They cannot hold items as other mobs do.
        if (entity.method_6047().method_7969() != null && entity.method_6047().method_7969().method_10577(Scholar.NBT.BOOK_OPEN)) return class_1268.field_5808;
        if (entity.method_6079().method_7969() != null && entity.method_6079().method_7969().method_10577(Scholar.NBT.BOOK_OPEN)) return class_1268.field_5810;
        return null;
    }
}
