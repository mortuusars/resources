package io.github.mortuusars.scholar.fabric;

import io.github.mortuusars.scholar.book.BookItemColorsReloadListener;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2960;

public class BookItemColorsReloadListenerFabric extends BookItemColorsReloadListener implements IdentifiableResourceReloadListener {
    @Override
    public class_2960 getFabricId() {
        return ID;
    }
}
