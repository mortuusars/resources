package io.github.mortuusars.scholar.fabric;

import io.github.mortuusars.scholar.ScholarClient;
import net.minecraft.class_11908;
import net.minecraft.class_304;

public class PlatformHelperClientImpl {
    public static class_304 createInsertEmptyPageLeftKeyMapping() {
        return new class_304("key.scholar.insert_empty_page_left", -1, ScholarClient.KeyMappings.SCHOLAR_CATEGORY);
    }

    public static class_304 createRemovePageLeftKeyMapping() {
        return new class_304("key.scholar.remove_page_left", -1, ScholarClient.KeyMappings.SCHOLAR_CATEGORY);
    }

    public static class_304 createInsertEmptyPageRightKeyMapping() {
        return new class_304("key.scholar.insert_empty_page_right", -1, ScholarClient.KeyMappings.SCHOLAR_CATEGORY);
    }

    public static class_304 createRemovePageRightKeyMapping() {
        return new class_304("key.scholar.remove_page_right", -1, ScholarClient.KeyMappings.SCHOLAR_CATEGORY);
    }

    public static boolean matchesWithModifiers(class_304 keyMapping, class_11908 event) {
        return keyMapping.method_1417(event);
    }
}
