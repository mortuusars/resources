package io.github.mortuusars.chalk.mixin.tooltip;

import io.github.mortuusars.chalk.client.gui.tooltip.ClientChalkBoxTooltip;
import io.github.mortuusars.chalk.world.item.component.ChalkBoxContents;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5684.class)
public interface ClientTooltipComponentMixin {
    @Inject(method = "create(Lnet/minecraft/world/inventory/tooltip/TooltipComponent;)Lnet/minecraft/client/gui/screens/inventory/tooltip/ClientTooltipComponent;",
          at = @At("HEAD"),
          cancellable = true)
    private static void onCreate(class_5632 visualTooltipComponent, CallbackInfoReturnable<class_5684> cir) {
        if (visualTooltipComponent instanceof ChalkBoxContents contents) {
            cir.setReturnValue(new ClientChalkBoxTooltip(contents));
        }
    }
}