package io.github.mortuusars.chalk.mixin.creative_mark_breaking;

import io.github.mortuusars.chalk.client.ClientHelper;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@SuppressWarnings("NameDoesntMatchTargetClass")
@Mixin(class_636.class)
public abstract class MultiPlayerGameModeMixin {
    @Shadow
    private class_1934 localPlayerMode;

    @Shadow
    private int destroyDelay;

    /**
     * Block#attack is not called when player is in creative, so we need this to break only one mark at a time.
     */
    @Inject(method = "startDestroyBlock", at = @At(value = "HEAD"), cancellable = true)
    private void onStartDestroyBlock(class_2338 pos, class_2350 face, CallbackInfoReturnable<Boolean> cir) {
        if (class_310.method_1551().field_1724 != null
              && class_310.method_1551().field_1724.method_7337()
              && ClientHelper.handleCreativeStartDestroyBlock(pos, face, localPlayerMode)) {
            destroyDelay = 5;
            cir.setReturnValue(true);
        }
    }
}
