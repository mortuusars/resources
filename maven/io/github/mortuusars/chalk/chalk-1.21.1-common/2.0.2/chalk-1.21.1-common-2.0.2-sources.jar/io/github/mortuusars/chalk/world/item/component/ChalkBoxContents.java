package io.github.mortuusars.chalk.world.item.component;

import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.Config;
import io.github.mortuusars.chalk.world.item.ChalkItem;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_5632;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * @param items    Readonly list of the items. Use {@link #copyItems()} if modification is needed.
 * @param glow     Remaining glow uses.
 * @param selected Slot selected for drawing. Always points to the slot with item or -1 if Chalk Box is empty.
 */
public record ChalkBoxContents(List<class_1799> items, int glow, int selected) implements class_5632 {
    public static final int SLOTS = 10;
    public static final int CHALK_SLOTS = 9;
    public static final int GLOWINGS_SLOT = SLOTS - 1;

    public static final Codec<ChalkBoxContents> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                class_1799.field_49266.listOf(0, SLOTS)
                      .optionalFieldOf("items", class_2371.method_10213(SLOTS, class_1799.field_8037))
                      .forGetter(ChalkBoxContents::getItemsTrimmed),
                Codec.INT
                      .optionalFieldOf("glow", 0)
                      .forGetter(ChalkBoxContents::glow),
                Codec.INT
                      .optionalFieldOf("selected", -1)
                      .forGetter(ChalkBoxContents::selected))
          .apply(instance, ChalkBoxContents::new));

    public static final class_9139<class_9129, ChalkBoxContents> STREAM_CODEC = class_9139.method_56436(
          class_1799.field_49268.method_56433(class_9135.method_56363()), ChalkBoxContents::items,
          class_9135.field_49675, ChalkBoxContents::glow,
          class_9135.field_49675, ChalkBoxContents::selected,
          ChalkBoxContents::new
    );

    public static final ChalkBoxContents EMPTY = new ChalkBoxContents(Collections.emptyList(), 0, -1);

    public ChalkBoxContents(List<class_1799> items, int glow, int selected) {
        this.items = class_2371.method_10213(SLOTS, class_1799.field_8037);
        for (int i = 0; i < Math.min(items.size(), SLOTS); i++) {
            this.items.set(i, items.get(i));
        }
        this.glow = Math.max(glow, 0);
        this.selected = correctSelected(selected);
    }

    private int correctSelected(int selected) {
        if (!getItem(selected).method_7960() && selected < CHALK_SLOTS) {
            return selected;
        }

        if (selected <= -1) {
            for (int i = 0; i < CHALK_SLOTS; i++) {
                if (!getItem(i).method_7960()) {
                    return i;
                }
            }
            return -1;
        }

        if (selected > CHALK_SLOTS - 1) {
            selected = CHALK_SLOTS - 1;
        }

        for (int index = selected; index < CHALK_SLOTS; index++) {
            if (!getItem(index).method_7960()) {
                return index;
            }
        }

        for (int index = 0; index < selected; index++) {
            if (!getItem(index).method_7960()) {
                return index;
            }
        }

        return -1;
    }

    public ChalkBoxContents(List<class_1799> items, int glow) {
        this(items, glow, 0);
    }

    public static ChalkBoxContents of(class_1799 stack) {
        return stack.method_57825(Chalk.DataComponents.CHALK_BOX_CONTENTS, EMPTY);
    }

    public ChalkBoxContents.Mutable mutable() {
        return new Mutable(this);
    }

    // --

    public boolean isEmpty() {
        return this == EMPTY || items().isEmpty() || items().stream().allMatch(class_1799::method_7960);
    }

    public int size() {
        return items.size();
    }

    public boolean hasChalks() {
        return items().stream().anyMatch(s -> s.method_7909() instanceof ChalkItem);
    }

    public int getChalkCount() {
        int count = 0;
        for (int i = 0; i < CHALK_SLOTS; i++) {
            if (!getItem(i).method_7960()) count++;
        }
        return count;
    }

    /**
     * Items should not be modified. Use {@link ChalkBoxContents#copyItems()} if modification is needed.
     */
    @Override
    public List<class_1799> items() {
        return items;
    }

    /**
     * Items without trailing empty stacks.
     * <br>
     * Items should not be modified. Use {@link ChalkBoxContents#copyItems()} if modification is needed.
     */
    public List<class_1799> getItemsTrimmed() {
        List<class_1799> list = new ArrayList<>(items);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (!list.get(i).method_7960()) {
                break;
            }
            list.remove(i);
        }
        return list;
    }

    /**
     * Item should not be modified. Copy the stack if modification is needed.
     */
    public @NotNull class_1799 getItem(int index) {
        return index >= 0 && index < size() ? items.get(index) : class_1799.field_8037;
    }

    /**
     * Returned item can be modified safely.
     */
    public @NotNull class_1799 copyItem(int index) {
        return getItem(index).method_7972();
    }

    /**
     * Returned items can be modified safely.
     */
    public List<class_1799> copyItems() {
        return Lists.transform(this.items, class_1799::method_7972);
    }

    public class_1799 getSelectedChalk() {
        return getItem(selected);
    }

    // --

    public ChalkBoxContents withGlow(int glow) {
        return new ChalkBoxContents(items, glow, selected);
    }

    public ChalkBoxContents withSelected(int selected) {
        return new ChalkBoxContents(items, glow, selected);
    }

    // --

    @SuppressWarnings("deprecation")
    public boolean equals(Object another) {
        if (this == another) return true;
        return another instanceof ChalkBoxContents anotherContents
              && class_1799.method_57362(this.items, anotherContents.items)
              && glow == anotherContents.glow();
    }

    @SuppressWarnings("deprecation")
    public int hashCode() {
        return class_1799.method_57361(this.items) + glow;
    }

    @Override
    public @NotNull String toString() {
        return "ChalkBoxContents{" +
              "items=" + items +
              ", glow=" + glow +
              ", selected=" + selected +
              '}';
    }

    // --

    public static boolean canHold(int slot, class_1799 stack) {
        if (slot < 0 || slot >= SLOTS) {
            return false;
        } else if (!stack.method_7909().method_31568()) {
            return false;
        } else if (slot == GLOWINGS_SLOT) {
            return Config.Server.GLOWING_ENABLED.get() && Config.Server.CHALK_BOX_GLOWING_ENABLED.get() && stack.method_31573(Chalk.Tags.Items.GLOWINGS);
        } else {
            return stack.method_7909() instanceof ChalkItem;
        }
    }

    public static boolean canHold(class_1799 stack) {
        if (!stack.method_7909().method_31568()) {
            return false;
        }
        return stack.method_7909() instanceof ChalkItem
              || (Config.Server.GLOWING_ENABLED.get()
                  && Config.Server.CHALK_BOX_GLOWING_ENABLED.get()
                  && stack.method_31573(Chalk.Tags.Items.GLOWINGS));
    }

    public static class Mutable {
        private List<class_1799> items;
        private int glow;
        private int selected;

        public Mutable(ChalkBoxContents contents) {
            this.items = new ArrayList<>(contents.copyItems());
            this.glow = contents.glow;
            this.selected = contents.selected;
        }

        public ChalkBoxContents toImmutable() {
            return new ChalkBoxContents(items, glow, selected);
        }

        public class_1799 toImmutable(class_1799 stack) {
            stack.method_57379(Chalk.DataComponents.CHALK_BOX_CONTENTS, new ChalkBoxContents(items, glow, selected));
            return stack;
        }

        public Mutable setItems(class_1263 container) {
            for (int i = 0; i < items.size(); i++) {
                items.set(i, container.method_5438(i));
            }
            return this;
        }

        public Mutable setItems(List<class_1799> items) {
            this.items = items;
            return this;
        }

        public Mutable setItem(int index, class_1799 item) {
            items.set(index, item);
            return this;
        }

        public Mutable consumeGlow() {
            glow -= 1;
            return updateGlow();
        }

        public Mutable updateGlow() {
            if (glow <= 0 && !items.get(GLOWINGS_SLOT).method_7960()) {
                items.get(GLOWINGS_SLOT).method_7934(1);
                glow = Config.Server.CHALK_BOX_GLOWING_AMOUNT_PER_ITEM.get();
            }
            return this;
        }

        public Mutable setSelected(int slot) {
            selected = slot;
            return this;
        }
    }
}
