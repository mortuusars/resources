package io.github.mortuusars.chalk.network.packet.serverbound;

import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.world.block.MarkBlock;
import io.github.mortuusars.mortaar.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record DestroyMarkServerboundPacket(class_2338 pos, class_2350 face) implements Packet {
    public static final class_9154<DestroyMarkServerboundPacket> TYPE = new class_9154<>(Chalk.resource("destroy_mark"));

    public static final class_9139<class_2540, DestroyMarkServerboundPacket> STREAM_CODEC = class_9139.method_56435(
          class_2338.field_48404, DestroyMarkServerboundPacket::pos,
          class_2350.field_48450, DestroyMarkServerboundPacket::face,
          DestroyMarkServerboundPacket::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Chalk.LOGGER.error("Cannot handle {}: player is not ServerPlayer.", TYPE.comp_2242());
            return false;
        }

        if (!player.method_56093(pos, 1.0)) {
            Chalk.LOGGER.error("Cannot handle {}: player is not in range: Player: [{}], Mark: [{}].",
                  TYPE.comp_2242(), player.method_24515().method_23854(), pos.method_23854());
            return false;
        }

        if (player.method_21701(player.method_37908(), pos, serverPlayer.field_13974.method_14257())) {
            Chalk.LOGGER.error("Cannot handle {}: block action restricted: Player: [{}], Mark: [{}].",
                  TYPE.comp_2242(), player.method_24515().method_23854(), pos.method_23854());
            return false;
        }

        if (serverPlayer.method_37908().method_8320(pos).method_26204() instanceof MarkBlock markBlock) {
            markBlock.removeMarkWithEffects(player.method_37908(), pos, face);
        }

        return true;
    }
}