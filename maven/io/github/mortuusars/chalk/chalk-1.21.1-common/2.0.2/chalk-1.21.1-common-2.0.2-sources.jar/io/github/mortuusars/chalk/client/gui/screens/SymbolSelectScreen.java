package io.github.mortuusars.chalk.client.gui.screens;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.Config;
import io.github.mortuusars.chalk.network.packet.serverbound.DrawMarkServerboundPacket;
import io.github.mortuusars.chalk.world.chalk.Mark;
import io.github.mortuusars.chalk.world.chalk.MarkDrawingContext;
import io.github.mortuusars.chalk.world.chalk.symbol.MarkSymbol;
import io.github.mortuusars.chalk.world.item.MarkDrawable;
import org.apache.commons.lang3.text.WordUtils;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.stream.Collectors;
import net.minecraft.class_124;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5253;
import net.minecraft.class_5321;
import net.minecraft.class_5481;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_757;
import net.minecraft.class_765;
import net.minecraft.class_7833;

public class SymbolSelectScreen extends class_437 {
    protected static final class_2960 BORDER_REGULAR_SPRITE = Chalk.resource("symbol_selection/border_regular");
    protected static final class_2960 BORDER_GOLD_SPRITE = Chalk.resource("symbol_selection/border_gold");
    protected static final class_2960 BORDER_HOVERED_SPRITE = Chalk.resource("symbol_selection/border_hovered");

    protected int SYMBOL_SIZE = 32;
    protected int SYMBOL_SPACING = 8;
    protected int SYMBOL_BORDER_THICKNESS = SYMBOL_SIZE / 16;
    protected int GROUP_LABEL_BOTTOM_PADDING = 4;
    protected int DEFAULT_BORDER_COLOR = 0xFF252525;

    protected final class_746 player;
    protected final class_1937 level;
    protected final long openTimestamp;
    protected final long openTimestampMs = System.currentTimeMillis();

    protected final List<class_6880<MarkSymbol>> symbols;
    protected final MarkDrawingContext context;

    protected final int color;
    protected final float r;
    protected final float g;
    protected final float b;
    protected final int hoverBorderColor;
    protected final class_2350 markFacing;
    protected final class_2680 surfaceState;

    protected final List<Mark> marks;
    protected final MarkDrawable drawable;
    protected final class_1799 itemStack;

    protected float openAnimation;
    protected int centerX;
    protected int centerY;

    protected LinkedHashMap<class_2561, List<List<Mark>>> groupsAndRows = new LinkedHashMap<>();
    protected int contentHeight;
    protected int contentY;

    protected double changePerScroll;
    protected double maxScroll = 999999.0;
    protected double scroll = 0;
    protected double currentScroll = 0;
    protected int scrollBarWidth;
    protected int scrollBarX;
    protected int scrollBarYStart;
    protected int scrollBarYEnd;
    protected double scrollThumbY;
    protected int scrollThumbSize;
    protected boolean draggingScrollThumb;
    protected boolean isHoveringOverScrollBar;
    protected boolean isHoveringOverScrollThumb;
    protected double lastScrollingMouseY;

    @Nullable
    protected Mark hoveredMark;
    protected boolean mouseWasReleased;
    protected float edgeMargin = 0.15f;

    public SymbolSelectScreen(List<class_6880<MarkSymbol>> symbols, MarkDrawingContext context) {
        super(class_2561.method_43473());
        this.symbols = symbols;
        this.context = context;

        this.field_22787 = class_310.method_1551();
        this.player = field_22787.field_1724;
        Preconditions.checkArgument(player != null, "Player cannot be null.");
        this.level = player.method_37908();
        this.openTimestamp = level.method_8510();

        itemStack = player.method_5998(context.hand());
        // Screen shouldn't be opened with other items
        drawable = ((MarkDrawable) itemStack.method_7909());

        color = drawable.getMarkDrawingColor(itemStack);
        r = (float) (this.color >> 16 & 255) / 255.0F;
        g = (float) (this.color >> 8 & 255) / 255.0F;
        b = (float) (this.color & 255) / 255.0F;
        hoverBorderColor = class_5253.class_5254.method_48780(0.2f, class_5253.class_5254.method_57174(this.color), 0xFFFFFFFF);

        marks = symbols.stream()
              .map(symbol -> drawable.createMark(player, context, itemStack, symbol))
              .toList();
        markFacing = context.markFacing();

        class_2338 surfacePos = this.context.markPos().method_10093(markFacing.method_10153());
        surfaceState = field_22787.field_1687 != null ? field_22787.field_1687.method_8320(surfacePos) : class_2246.field_10124.method_9564();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25393() {
        if (!drawable.canDrawMark(player, context)) {
            this.method_25419();
        }
    }

    @Override
    protected void method_25426() {
        centerX = field_22789 / 2;
        centerY = field_22790 / 2;
        createGroupsAndRows();

        contentHeight = 0;

        for (Map.Entry<class_2561, List<List<Mark>>> group : groupsAndRows.entrySet()) {
            contentHeight += field_22793.field_2000 + GROUP_LABEL_BOTTOM_PADDING;
            contentHeight += (SYMBOL_SIZE + SYMBOL_SPACING) * group.getValue().size();
        }

        if (contentHeight < field_22790 * (1 - edgeMargin)) {
            maxScroll = 0;
            contentY = field_22790 / 2 - contentHeight / 2;
        } else {
            maxScroll = Math.max(0, field_22790 * edgeMargin + contentHeight - field_22790 * (1 - edgeMargin));
            contentY = (int) (field_22790 * edgeMargin);
        }

        changePerScroll = field_22790 / 8.0;
    }

    protected void createGroupsAndRows() {
        groupsAndRows.clear();

        Map<String, List<class_6880<MarkSymbol>>> groupsAndSymbols = symbols.stream()
              .collect(Collectors.groupingBy(symbol -> symbol.comp_349().group()));

        List<? extends String> groupSorting = Config.Client.SYMBOL_SELECTION_GROUP_SORTING.get();

        List<String> groups = new ArrayList<>();
        groups.addAll(groupSorting.stream()
              .filter(groupsAndSymbols::containsKey)
              .toList());

        groups.addAll(groupsAndSymbols.keySet().stream()
              .filter(group -> !groups.contains(group))
              .sorted()
              .toList());

        for (String group : groups) {
            groupsAndRows.put(class_2561.method_43471("mark_symbol_group.chalk." + group), createRows(groupsAndSymbols.get(group)));
        }
    }

    protected List<List<Mark>> createRows(List<class_6880<MarkSymbol>> symbols) {
        int maxSymbolsInRow = Math.max(1, (int) ((field_22789 * (1f - edgeMargin * 2)) / (SYMBOL_SIZE + SYMBOL_SPACING)));

        List<Mark> marks = symbols.stream()
              .sorted(Comparator.comparingInt(symbol -> symbol.comp_349().groupPriority()))
              .map(symbol -> drawable.createMark(player, context, itemStack, symbol))
              .toList();

        return Lists.partition(marks, maxSymbolsInRow);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        openAnimation = class_3532.method_15363((System.currentTimeMillis() - openTimestampMs) / 500f, 0f, 1f);
        openAnimation = 1f - openAnimation;
        openAnimation *= openAnimation * openAnimation;
        openAnimation = 1f - openAnimation;

        handleScreenEdgeScrolling(mouseY, partialTicks);

        super.method_25394(graphics, mouseX, mouseY, partialTicks);

        try {
            renderMarks(graphics, mouseX, mouseY, partialTicks);
        } catch (Exception e) {
            Chalk.LOGGER.error(e);
        }

        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(0, 0, 200);
        graphics.method_25296(0, 0, field_22789, (int) (field_22790 * 0.08f),
              class_5253.class_5254.method_48780(openAnimation, 0x007F7F7F, 0x44000000), 0x007F7F7F);
        graphics.method_25296(0, (int) (field_22790 * 0.92f), field_22789, field_22790, 0x007F7F7F,
              class_5253.class_5254.method_48780(openAnimation, 0x00000000, 0x44000000));

        if (maxScroll > 0) {
            renderScrollBar(graphics, mouseX, mouseY, partialTicks);
        }

        graphics.method_51448().method_22909();
    }

    public void renderScrollBar(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        scrollBarWidth = 3;
        scrollBarX = (int) (field_22789 - field_22790 * 0.2f);
        scrollBarYStart = (int) (field_22790 * 0.2f);
        scrollBarYEnd = (int) (field_22790 * 0.8f);

        graphics.method_25294(scrollBarX - 1, scrollBarYStart - 1, scrollBarX + scrollBarWidth + 1, scrollBarYEnd + 1, 0x55111111);
        graphics.method_25294(scrollBarX, scrollBarYStart, scrollBarX + scrollBarWidth, scrollBarYEnd, 0x55AAAAAA);

        double progress = currentScroll / maxScroll;
        double thumbRatio = (double) field_22790 * 0.5 / contentHeight;
        int yArea = scrollBarYEnd - scrollBarYStart;
        scrollThumbSize = (int) Math.max(field_22790 * 0.075f, yArea * thumbRatio);
        scrollThumbY = scrollBarYStart + ((yArea - scrollThumbSize) * progress);

        graphics.method_51448().method_22903();
        graphics.method_51448().method_22904(scrollBarX, scrollThumbY, 0);
        isHoveringOverScrollBar = mouseX >= scrollBarX && mouseX < scrollBarX + scrollBarWidth && mouseY >= scrollBarYStart && mouseY < scrollBarYEnd;
        isHoveringOverScrollThumb = isHoveringOverScrollBar && mouseY >= scrollThumbY && mouseY < scrollThumbY + scrollThumbSize;
        int thumbColor = draggingScrollThumb || isHoveringOverScrollThumb ? 0xFFFFFFFF : 0xBBFFFFFF;
        graphics.method_25294(0, 0, scrollBarWidth, scrollThumbSize, thumbColor);
        graphics.method_51448().method_22909();
    }

    protected void handleScreenEdgeScrolling(int mouseY, float partialTicks) {
        if (draggingScrollThumb) {
            return;
        }

        float screenScrollArea = Math.max(20, field_22790 * 0.1f);

        if (mouseY < screenScrollArea) {
            float strength = class_3532.method_15363((screenScrollArea - mouseY) / screenScrollArea, 0, 1);
            scroll(-field_22790 * (0.15f * strength * partialTicks));
        }

        if (mouseY > field_22790 - screenScrollArea) {
            float strength = class_3532.method_15363((mouseY - (field_22790 - screenScrollArea)) / screenScrollArea, 0, 1);
            scroll(field_22790 * (0.15f * strength * partialTicks));
        }
    }

    protected void renderMarks(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        hoveredMark = null;

        // Animates scroll smoothly
        if (Math.abs(currentScroll - scroll) > 0.001f) {
            currentScroll = class_3532.method_16436(Math.min(1, partialTicks), currentScroll, scroll);
        } else {
            currentScroll = scroll;
        }

        graphics.method_51448().method_22903();
        graphics.method_51448().method_22904(0, -class_3532.method_15385(currentScroll), 0);

        int y = contentY - (int) currentScroll;

        for (Map.Entry<class_2561, List<List<Mark>>> group : groupsAndRows.entrySet()) {
            int labelX = field_22789 / 2 - field_22793.method_27525(group.getKey()) / 2;
            int textOutlineColor = class_5253.class_5254.method_48780(openAnimation, 0x22000000, DEFAULT_BORDER_COLOR);
            int textColor = class_5253.class_5254.method_48780(openAnimation, 0x22FFFFFF, 0xFFFFFFFF);
            graphics.method_51439(field_22793, group.getKey(), labelX - 1, y, textOutlineColor, false);
            graphics.method_51439(field_22793, group.getKey(), labelX - 1, y + 1, textOutlineColor, false);
            graphics.method_51439(field_22793, group.getKey(), labelX - 1, y - 1, textOutlineColor, false);
            graphics.method_51439(field_22793, group.getKey(), labelX + 1, y, textOutlineColor, false);
            graphics.method_51439(field_22793, group.getKey(), labelX + 1, y - 1, textOutlineColor, false);
            graphics.method_51439(field_22793, group.getKey(), labelX + 1, y + 1, textOutlineColor, false);
            graphics.method_51439(field_22793, group.getKey(), labelX, y + 1, textOutlineColor, false);
            graphics.method_51439(field_22793, group.getKey(), labelX, y - 1, textOutlineColor, false);
            graphics.method_51439(field_22793, group.getKey(), labelX, y, textColor, false);

            y += field_22793.field_2000 + GROUP_LABEL_BOTTOM_PADDING;

            List<List<Mark>> rows = group.getValue();

            for (List<Mark> marks : rows) {
                int count = marks.size();
                int rowWidth = (SYMBOL_SIZE * count) + (SYMBOL_SPACING * (count - 1));
                int rowX = (field_22789 / 2) - rowWidth / 2;

                for (int markIndex = 0; markIndex < marks.size(); markIndex++) {
                    Mark mark = marks.get(markIndex);
                    int markX = rowX + markIndex * (SYMBOL_SIZE + SYMBOL_SPACING);

                    boolean isHovering = (mouseX >= markX - SYMBOL_BORDER_THICKNESS && mouseX <= markX + SYMBOL_SIZE + SYMBOL_BORDER_THICKNESS)
                          && (mouseY >= y - SYMBOL_BORDER_THICKNESS - class_3532.method_15385(scroll) && mouseY <= y + SYMBOL_SIZE + SYMBOL_BORDER_THICKNESS - class_3532.method_15385(scroll));

                    if (isHovering) {
                        hoveredMark = mark;
                    }

                    renderMarkButton(graphics, mouseX, mouseY, mark, markX, y, isHovering);
                }

                y += SYMBOL_SIZE + SYMBOL_SPACING;
            }
        }

        graphics.method_51448().method_22909();

        if (hoveredMark != null) {
            renderMarkTooltip(graphics, mouseX, mouseY + SYMBOL_SIZE, partialTicks, hoveredMark);
        }
    }

    public void renderMarkTooltip(class_332 graphics, int x, int y, float partialTicks, Mark mark) {
        mark.symbol().method_40230()
              .map(class_5321::method_29177)
              .ifPresent(location -> {
                  List<class_5481> lines = new ArrayList<>();
                  lines.add(class_2561.method_43471(location.method_42093("mark_symbol")).method_30937());

                  if (mark.symbol().comp_349().supporterOnly()) {
                      lines.add(class_2561.method_43471("gui.chalk.mark_symbol.supporter_exclusive").method_27692(class_124.field_1065)
                            .method_30937());
                  }

                  if (player.method_7337() && class_310.method_1551().field_1690.field_1827) {
                      mark.symbol().comp_349().requiredAdvancement().ifPresent(advancementId -> lines.add(
                            class_2561.method_43469("gui.chalk.mark_symbol.unlocked_by",
                                        class_2561.method_43470(advancementId.toString()).method_27692(class_124.field_1063))
                                  .method_27692(class_124.field_1080).method_30937()));
                  }

                  @SuppressWarnings("deprecation")
                  String namespace = WordUtils.capitalizeFully(location.method_12836().replace("_", " "));
                  lines.add(class_2561.method_43470(namespace).method_27696(class_2583.field_24360.method_10977(class_124.field_1078).method_10978(true))
                        .method_30937());

                  graphics.method_51447(field_22793, lines, x, y);
              });
    }

    @Override
    public void method_25420(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        graphics.method_25296(0, 0, field_22789, field_22790,
              class_5253.class_5254.method_48780(openAnimation, 0x00000000, 0x40000000),
              class_5253.class_5254.method_48780(openAnimation, 0x00000000, 0x40000000));
    }

    protected void renderMarkButton(class_332 graphics, int mouseX, int mouseY, Mark mark, int x, int y, boolean isHovering) {
        class_2960 borderSprite = isHovering
              ? BORDER_HOVERED_SPRITE
              : mark.symbol().comp_349().supporterOnly()
              ? BORDER_GOLD_SPRITE
              : BORDER_REGULAR_SPRITE;
        graphics.method_52706(borderSprite, x - SYMBOL_BORDER_THICKNESS, y - SYMBOL_BORDER_THICKNESS,
              SYMBOL_SIZE + SYMBOL_BORDER_THICKNESS * 2, SYMBOL_SIZE + SYMBOL_BORDER_THICKNESS * 2);

        renderBlockSurface(graphics, mouseX, mouseY, x, y);

        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(r, g, b, openAnimation);
        RenderSystem.enableBlend();

        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(x + SYMBOL_SIZE / 2f, y + SYMBOL_SIZE / 2f, 0);

        float rotation = calculateMarkRoration(mark);
        graphics.method_51448().method_22907(class_7833.field_40718.rotationDegrees(rotation));
        graphics.method_51448().method_46416(-x - SYMBOL_SIZE / 2f, -y - SYMBOL_SIZE / 2f, 100);
        graphics.method_25293(mark.symbol().comp_349().texture().method_45138("textures/").method_48331(".png"),
              x, y, SYMBOL_SIZE, SYMBOL_SIZE, 0, 0, 16, 16, 16, 16);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        graphics.method_51448().method_22909();

        // Shadow overlay
        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(0, 0, 100);
        graphics.method_25296(x, y, x + SYMBOL_SIZE, y + SYMBOL_SIZE,
              class_5253.class_5254.method_48780(openAnimation, 0x33000000, 0x00AAAAAA),
              class_5253.class_5254.method_48780(openAnimation, 0x33000000, 0x2F000000));
        graphics.method_51448().method_22909();
    }

    protected float calculateMarkRoration(Mark mark) {
        if (context.markFacing().method_10166().method_10179()) {
            return mark.orientation().getRotation() + mark.symbol().comp_349().rotationOffset();
        } else if (context.markFacing() == class_2350.field_11036) {
            int viewRot = (player.method_5735().method_10161() * 90 + 180) % 360;
            return mark.orientation().getRotation() - viewRot + mark.symbol().comp_349().rotationOffset();
        } else {
            // Down orientation for some symbols is still wrong in some cases.
            // Maybe I'll fix it in the future.
            int viewRot = (player.method_5735().method_10161() * 90) % 360;
            int orientationRot = mark.orientation().getRotation();
            if (mark.symbol().comp_349().orientationBehavior() == MarkSymbol.OrientationBehavior.FULL
                  || mark.symbol().comp_349().orientationBehavior() == MarkSymbol.OrientationBehavior.CARDINAL) {
                orientationRot = (orientationRot + 180) % 360;
            }
            return orientationRot - viewRot + mark.symbol().comp_349().rotationOffset();
        }
    }

    @SuppressWarnings("DataFlowIssue")
    protected void renderBlockSurface(class_332 graphics, int mouseX, int mouseY, int x, int y) {
        RenderSystem.setShaderTexture(0, class_1723.field_21668);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.applyModelViewMatrix();
        class_308.method_24210();

        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(x, y, 0);

        int xRot = 0;
        int yRot = 0;

        if (markFacing == class_2350.field_11036) {
            xRot = -90;
        } else if (markFacing == class_2350.field_11033) {
            xRot = 90;
        } else if (markFacing == class_2350.field_11034) {
            yRot = 270;
        } else if (markFacing == class_2350.field_11043) {
            yRot = 180;
        } else if (markFacing == class_2350.field_11039) {
            yRot = 90;
        }

        if (markFacing == class_2350.field_11036 || markFacing == class_2350.field_11033) {
            yRot = player.method_5735().method_10161() * 90 + 180;
        }

        graphics.method_51448().method_46416(SYMBOL_SIZE / 2f, SYMBOL_SIZE / 2f, SYMBOL_SIZE / 2f);
        graphics.method_51448().method_22907(class_7833.field_40714.rotationDegrees(xRot - 0.1f));
        graphics.method_51448().method_22907(class_7833.field_40716.rotationDegrees(yRot - 0.1f));
        graphics.method_51448().method_46416(-SYMBOL_SIZE / 2f, -SYMBOL_SIZE / 2f, -SYMBOL_SIZE / 2f);

        graphics.method_51448().method_46416(0, SYMBOL_SIZE, 0);
        graphics.method_51448().method_22905(1.0F, -1.0F, 1.0F);
        graphics.method_51448().method_22905(SYMBOL_SIZE, SYMBOL_SIZE, SYMBOL_SIZE);

        class_4597.class_4598 bufferSource = graphics.method_51450();

        field_22787.method_1541().method_3353(surfaceState, graphics.method_51448(), bufferSource,
              class_765.field_32767, class_4608.field_21444);

        bufferSource.method_22993();
        RenderSystem.enableDepthTest();
        class_308.method_24211();
        RenderSystem.applyModelViewMatrix();

        graphics.method_51448().method_22909();
    }

    // -- Input

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (class_310.method_1551().field_1690.field_1822.method_1417(keyCode, scanCode)) {
            this.method_25419();
            return true;
        }

        if (keyCode == class_3675.field_31933 || keyCode == class_3675.field_31937) {
            scroll(changePerScroll);
            return true;
        }

        if (keyCode == 333 /*KEY_SUBTRACT*/ || keyCode == class_3675.field_31941) {
            scroll(-changePerScroll);
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (isHoveringOverScrollThumb) {
            draggingScrollThumb = true;
            lastScrollingMouseY = 0;
            return true;
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (draggingScrollThumb) {
            draggingScrollThumb = false;
            return true;
        }

        if (isHoveringOverScrollBar) {
            if (mouseY < scrollThumbY) {
                scroll(-changePerScroll * 3);
            } else {
                scroll(changePerScroll * 3);
            }
            return true;
        }

        if (!mouseWasReleased && level.method_8510() - openTimestamp < 4) {
            mouseWasReleased = true;
            return true;
        }

        if (button == 0 || !mouseWasReleased) {
            if (hoveredMark != null) {
                tryDrawSymbol(hoveredMark.symbol());
            }
        }

        this.method_25419();
        return true;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (draggingScrollThumb && button == class_3675.field_32000) {
            int scrollBarSize = scrollBarYEnd - scrollBarYStart;
            double value = maxScroll / (scrollBarSize - scrollThumbSize);
            scroll(dragY * value);
            lastScrollingMouseY = mouseY;
            return true;
        }

        return super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (scrollY != 0) {
            scroll(-(scrollY * changePerScroll));
            return true;
        }
        return false;
    }

    protected void tryDrawSymbol(class_6880<MarkSymbol> symbol) {
        new DrawMarkServerboundPacket(symbol, context).sendToServer();
        player.method_6104(context.hand());
    }

    public void scroll(double change) {
        scrollTo(scroll + change);
    }

    public void scrollTo(double position) {
        scroll = class_3532.method_15350(position, 0, maxScroll);
    }
}
