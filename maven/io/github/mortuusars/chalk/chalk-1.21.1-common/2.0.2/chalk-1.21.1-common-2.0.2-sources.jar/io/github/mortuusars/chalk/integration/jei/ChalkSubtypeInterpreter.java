package io.github.mortuusars.chalk.integration.jei;

import mezz.jei.api.ingredients.subtypes.ISubtypeInterpreter;
import mezz.jei.api.ingredients.subtypes.UidContext;
import net.minecraft.class_1799;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public enum ChalkSubtypeInterpreter implements ISubtypeInterpreter<class_1799> {
    INSTANCE;

    @Override
    public @Nullable Object getSubtypeData(class_1799 ingredient, UidContext context) {
        return ingredient.method_57824(class_9334.field_49644);
    }

    @Override
    public @NotNull String getLegacyStringSubtypeInfo(class_1799 ingredient, UidContext context) {
        return "";
    }
}
