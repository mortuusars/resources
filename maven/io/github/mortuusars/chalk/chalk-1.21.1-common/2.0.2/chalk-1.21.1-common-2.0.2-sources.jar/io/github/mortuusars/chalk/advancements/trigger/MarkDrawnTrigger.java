package io.github.mortuusars.chalk.advancements.trigger;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.advancements.predicate.MarkPredicate;
import io.github.mortuusars.chalk.world.chalk.Mark;
import io.github.mortuusars.mortaar.advancement.predicate.MapColorPredicate;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_175;
import net.minecraft.class_1799;
import net.minecraft.class_2048;
import net.minecraft.class_2073;
import net.minecraft.class_2090;
import net.minecraft.class_2338;
import net.minecraft.class_3195;
import net.minecraft.class_3222;
import net.minecraft.class_4550;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class MarkDrawnTrigger extends class_4558<MarkDrawnTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player, class_1799 drawingStack, class_2338 markPos, Mark mark, class_2338 surfacePos) {
        this.method_22510(player, triggerInstance -> triggerInstance.matches(player, drawingStack, markPos, mark, surfacePos));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  Optional<class_2073> item,
                                  Optional<class_2090> location,
                                  Optional<MarkPredicate> mark,
                                  Optional<class_4550> surfaceBlock,
                                  Optional<MapColorPredicate> surfaceColor) implements class_4558.class_8788 {

        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance ->
              instance.group(class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::comp_2029),
                          class_2073.field_45754.optionalFieldOf("item").forGetter(TriggerInstance::item),
                          class_2090.field_45760.optionalFieldOf("location").forGetter(TriggerInstance::location),
                          MarkPredicate.CODEC.optionalFieldOf("mark").forGetter(TriggerInstance::mark),
                          class_4550.field_45723.optionalFieldOf("surface").forGetter(TriggerInstance::surfaceBlock),
                          MapColorPredicate.CODEC.optionalFieldOf("surface_color").forGetter(TriggerInstance::surfaceColor))
                    .apply(instance, TriggerInstance::new));

        public static class_175<MarkDrawnTrigger.TriggerInstance> structure(class_6880<class_3195> structureKey) {
            TriggerInstance instance = new TriggerInstance(class_2048.method_53137(
                  Optional.empty()),
                  Optional.empty(),
                  Optional.of(class_2090.class_2091.method_53183(structureKey).method_9023()),
                  Optional.empty(),
                  Optional.empty(),
                  Optional.empty());
            return Chalk.CriteriaTriggers.MARK_DRAWN.get().method_53699(instance);
        }

        public static class_175<MarkDrawnTrigger.TriggerInstance> structures(class_6885<class_3195> structures) {
            TriggerInstance instance = new TriggerInstance(class_2048.method_53137(
                  Optional.empty()),
                  Optional.empty(),
                  Optional.of(new class_2090(Optional.empty(),
                        Optional.empty(),
                        Optional.of(structures),
                        Optional.empty(),
                        Optional.empty(),
                        Optional.empty(),
                        Optional.empty(),
                        Optional.empty(),
                        Optional.empty())),
                  Optional.empty(),
                  Optional.empty(),
                  Optional.empty());
            return Chalk.CriteriaTriggers.MARK_DRAWN.get().method_53699(instance);
        }

        public boolean matches(class_3222 player, class_1799 item, class_2338 markPos, Mark mark, class_2338 surfacePos) {
            return (this.item.isEmpty() || this.item.get().method_8970(item))
                  && (this.location.isEmpty() || this.location.get().method_9018(player.method_51469(), markPos.method_10263(), markPos.method_10264(), markPos.method_10260()))
                  && (this.mark.isEmpty() || this.mark.get().matches(mark))
                  && (this.surfaceBlock.isEmpty() || this.surfaceBlock.get().method_22454(player.method_51469(), surfacePos))
                  && (this.surfaceColor.isEmpty() || this.surfaceColor.get().matches(
                        player.method_51469().method_8320(surfacePos).method_26205(player.method_51469(), surfacePos)));
        }
    }

    public static class Builder {
        private @Nullable class_5258 player;
        private @Nullable class_2073 item;
        private @Nullable class_2090 location;
        private @Nullable MarkPredicate mark;
        private @Nullable class_4550 surfaceBlock;
        private @Nullable MapColorPredicate surfaceColor;

        public Builder player(@Nullable class_5258 player) {
            this.player = player;
            return this;
        }

        public Builder item(@Nullable class_2073 item) {
            this.item = item;
            return this;
        }

        public Builder location(@Nullable class_2090 location) {
            this.location = location;
            return this;
        }

        public Builder mark(@Nullable MarkPredicate mark) {
            this.mark = mark;
            return this;
        }

        public Builder surfaceBlock(@Nullable class_4550 surfaceBlock) {
            this.surfaceBlock = surfaceBlock;
            return this;
        }

        public Builder surfaceColor(@Nullable MapColorPredicate surfaceColor) {
            this.surfaceColor = surfaceColor;
            return this;
        }

        public MarkDrawnTrigger.TriggerInstance build() {
            return new TriggerInstance(
                  Optional.ofNullable(player),
                  Optional.ofNullable(item),
                  Optional.ofNullable(location),
                  Optional.ofNullable(mark),
                  Optional.ofNullable(surfaceBlock),
                  Optional.ofNullable(surfaceColor)
            );
        }
    }
}

