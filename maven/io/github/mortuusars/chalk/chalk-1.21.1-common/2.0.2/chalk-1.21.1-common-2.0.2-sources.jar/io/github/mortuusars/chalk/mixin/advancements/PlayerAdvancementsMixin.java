package io.github.mortuusars.chalk.mixin.advancements;

import io.github.mortuusars.chalk.event.CommonEvents;
import net.minecraft.class_185;
import net.minecraft.class_2985;
import net.minecraft.class_3222;
import net.minecraft.class_8779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2985.class)
public class PlayerAdvancementsMixin {
    @Shadow
    private class_3222 player;

    // Using mixin instead of events to have the same code for neoforge and fabric
    @Inject(method = "method_53637", at = @At(value = "RETURN"))
    private void onDisplay(class_8779 advancementHolder, class_185 displayInfo, CallbackInfo ci) {
        CommonEvents.onAdvancementAward(player, advancementHolder);
    }
}
