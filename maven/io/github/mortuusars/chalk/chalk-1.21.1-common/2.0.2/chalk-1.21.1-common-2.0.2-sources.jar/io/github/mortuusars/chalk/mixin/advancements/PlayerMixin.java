package io.github.mortuusars.chalk.mixin.advancements;

import io.github.mortuusars.chalk.event.CommonEvents;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1657.class)
public class PlayerMixin {
    // Using mixin instead of events to have the same code for neoforge and fabric
    @Inject(method = "stopSleepInBed", at = @At("HEAD"))
    private void onStopSleeping(boolean wakeImmediately, boolean updateLevelForSleepingPlayers, CallbackInfo ci) {
        if (((class_1657)(Object)this) instanceof class_3222 serverPlayer) {
            CommonEvents.onStoppedSleeping(serverPlayer);
        }
    }
}
