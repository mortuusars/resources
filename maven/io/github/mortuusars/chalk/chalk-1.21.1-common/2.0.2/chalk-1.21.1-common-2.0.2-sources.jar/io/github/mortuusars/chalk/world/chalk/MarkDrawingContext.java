package io.github.mortuusars.chalk.world.chalk;

import io.github.mortuusars.chalk.util.GridCell;
import io.github.mortuusars.mortaar.network.codec.StreamCodecs;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_9139;

public record MarkDrawingContext(class_1268 hand, class_243 clickLocation, class_2338 markPos, class_2350 markFacing) {
    public static final class_9139<class_2540, MarkDrawingContext> STREAM_CODEC = class_9139.method_56905(
          StreamCodecs.INTERACTION_HAND, MarkDrawingContext::hand,
          StreamCodecs.VEC3, MarkDrawingContext::clickLocation,
          class_2338.field_48404, MarkDrawingContext::markPos,
          class_2350.field_48450, MarkDrawingContext::markFacing,
          MarkDrawingContext::new
    );

    public GridCell clickedCell() {
        return GridCell.fromClickLocation(clickLocation, markFacing);
    }

    public class_2338 surfacePos() {
        return markPos.method_10093(markFacing.method_10153());
    }
}
