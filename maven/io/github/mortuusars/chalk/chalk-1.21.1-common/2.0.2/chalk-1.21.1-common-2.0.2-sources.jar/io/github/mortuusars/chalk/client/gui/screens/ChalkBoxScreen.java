package io.github.mortuusars.chalk.client.gui.screens;

import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.world.inventory.ChalkBoxMenu;
import io.github.mortuusars.chalk.world.item.component.ChalkBoxContents;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class ChalkBoxScreen extends AbstractInHandContainerScreen<ChalkBoxMenu> {
    public static final class_2960 TEXTURE = Chalk.resource("textures/gui/container/chalk_box.png");
    public static final class_2960 CHALK_SLOT_PLACEHOLDER_SPRITE = Chalk.resource("chalk_box/chalk_slot_placeholder");
    public static final class_2960 GLOWING_SLOT_PLACEHOLDER_SPRITE = Chalk.resource("chalk_box/glowing_slot_placeholder");
    public static final class_2960 GLOW_BAR_SPRITE = Chalk.resource("chalk_box/glow_bar");
    public static final class_2960 SELECTED_CHALK_SLOT_OVERLAY_SPRITE = Chalk.resource("chalk_box/selected_chalk_slot_overlay");

    public static final int GLOW_BAR_HEIGHT = 18;

    protected final class_1657 player;
    protected int selectedSlot;

    public ChalkBoxScreen(ChalkBoxMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title, TEXTURE);
        this.player = playerInventory.field_7546;
    }

    @Override
    protected void method_25426() {
        this.field_2792 = 176;
        this.field_2779 = 166;
        this.field_25270 = this.field_2779 - 94;
        super.method_25426();
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTick, int mouseX, int mouseY) {
        selectedSlot = method_17577().getSelectedSlot();
        graphics.method_25302(TEXTURE, field_2776, field_2800, 0, 0, field_2792, field_2779);
        if (method_17577().isGlowEnabled()) {
            graphics.method_25302(TEXTURE, field_2776 + 133, field_2800 + 34, field_2792, 0, 25, 18);
            renderGlowingBar(graphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    protected void method_2380(class_332 guiGraphics, int x, int y) {
        if (method_17577().isGlowEnabled()
              && x >= getLeftPos() + 151 && x <= getLeftPos() + 160
              && y >= getTopPos() + 34 && y <= getTopPos() + 51) {
            int glow = method_17577().getGlow();
            class_124 glowAmountColor = glow > 0
                  ? class_124.field_1065
                  : class_124.field_1080;
            guiGraphics.method_51438(field_22793, class_2561.method_43469("item.chalk.chalk_box.tooltip.glow",
                  class_2561.method_43470(Integer.toString(glow)).method_27692(glowAmountColor)), x, y);
            return;
        }

        super.method_2380(guiGraphics, x, y);
    }

    @Override
    protected @NotNull List<class_2561> method_51454(class_1799 stack) {
        List<class_2561> lines = super.method_51454(stack);
        if (field_2787 != null && field_2787.field_7874 < ChalkBoxContents.CHALK_SLOTS && field_2787.method_7677().equals(stack)) {
            lines = new ArrayList<>(lines);
            lines.add(class_2561.method_43471("item.chalk.chalk_box.tooltip.alt_select"));
        }

        return lines;
    }

    protected void renderGlowingBar(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int currentGlow = method_17577().getGlow();
        int maxGlow = method_17577().getMaxGlow();
        int barSize = currentGlow == 0 ? 0
              : currentGlow == maxGlow ? 18
              : 2 + Math.round((currentGlow - 1) * 14f / (maxGlow - 2));
        int glowingBarFillLevel = Math.min(GLOW_BAR_HEIGHT, barSize);
        graphics.method_52708(GLOW_BAR_SPRITE, 5, 18, 0, 18 - glowingBarFillLevel,
              getLeftPos() + 153, getTopPos() + 34 + 18 - glowingBarFillLevel, 5, glowingBarFillLevel);
    }

    @Override
    protected void method_2385(class_332 guiGraphics, class_1735 slot) {
        // renderSlotOverlays renders on top of the durability bar, so we render it before the item
        if (slot.field_7874 == selectedSlot) {
            guiGraphics.method_52706(SELECTED_CHALK_SLOT_OVERLAY_SPRITE, slot.field_7873 - 2, slot.field_7872 - 2, 20, 20);
        }
        super.method_2385(guiGraphics, slot);
    }

    @Override
    protected void renderSlotOverlays(class_332 guiGraphics, class_1735 slot) {
        super.renderSlotOverlays(guiGraphics, slot);
        if (slot.field_7874 < ChalkBoxContents.CHALK_SLOTS) {
            if (!slot.method_7681()) {
                guiGraphics.method_52706(CHALK_SLOT_PLACEHOLDER_SPRITE, slot.field_7873 - 1, slot.field_7872 - 1, 18, 18);
            }
        }
        if (method_17577().isGlowEnabled() && slot.field_7874 == ChalkBoxContents.GLOWINGS_SLOT && !slot.method_7681()) {
            guiGraphics.method_52706(GLOWING_SLOT_PLACEHOLDER_SPRITE, slot.field_7873 - 1, slot.field_7872 - 1, 18, 18);
        }
    }

    @Override
    protected void method_2383(class_1735 slot, int slotId, int mouseButton, class_1713 type) {
        if (class_437.method_25443() && slotId >= 0 && slotId < ChalkBoxContents.CHALK_SLOTS && slot.method_7681()) {
            method_17577().setSelectedSlot(slotId);
            slotId += 100;
            assert field_22787 != null;
            assert field_22787.field_1761 != null;
            field_22787.field_1761.method_2900(method_17577().field_7763, slotId);
            return;
        }
        super.method_2383(slot, slotId, mouseButton, type);
    }
}
