package io.github.mortuusars.chalk.world.chalk.symbol;

import com.mojang.serialization.Codec;
import io.github.mortuusars.chalk.util.Point2d;
import io.github.mortuusars.chalk.util.GridCell;
import io.github.mortuusars.chalk.util.PositionUtils;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_3542;
import net.minecraft.class_7995;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public enum SymbolOrientation implements class_3542 {
    CENTER("center", 0),
    NORTH("north", 0),
    NORTHEAST("northeast", 45),
    EAST("east", 90),
    SOUTHEAST("southeast", 135),
    SOUTH("south", 180),
    SOUTHWEST("southwest", 225),
    WEST("west", 270),
    NORTHWEST("northwest", 315);

    public static final Codec<SymbolOrientation> CODEC = class_3542.method_28140(SymbolOrientation::values);
    public static final class_9139<ByteBuf, SymbolOrientation> STREAM_CODEC = class_9135.method_56375(
          class_7995.method_47914(SymbolOrientation::ordinal, values(), class_7995.class_7996.field_41665), SymbolOrientation::ordinal);

    private final String name;
    private final int rotation;

    SymbolOrientation(String name, int rotation) {
        this.name = name;
        this.rotation = rotation;
    }

    public static SymbolOrientation fromCell(GridCell cell) {
        return switch (cell) {
            case TOP_LEFT -> NORTHWEST;
            case TOP -> NORTH;
            case TOP_RIGHT -> NORTHEAST;
            case LEFT -> WEST;
            case CENTER -> CENTER;
            case RIGHT -> EAST;
            case BOTTOM_LEFT -> SOUTHWEST;
            case BOTTOM -> SOUTH;
            case BOTTOM_RIGHT -> SOUTHEAST;
        };
    }

    public String getName() {
        return name;
    }

    @Override
    public @NotNull String method_15434() {
        return getName();
    }

    public int getRotation() {
        return rotation;
    }

    public SymbolOrientation rotate(class_2470 rotation) {
        int step = switch (rotation) {
            case field_11463 -> 2;
            case field_11464 -> 4;
            case field_11465 -> 6;
            default -> 0;
        };

        return values()[((this.getRotation() / 45 + step) % 8) + 1];
    }

    public static SymbolOrientation fromRotation(int degrees) {
        for (SymbolOrientation orientation : values()) {
            if (orientation == CENTER) continue;

            if (orientation.getRotation() == degrees)
                return orientation;
        }

        return CENTER;
    }

    /**
     * Gets the cardinal direction (NORTH, EAST, SOUTH, WEST) from the click location.
     */
    public static SymbolOrientation fromClickLocationCardinal(class_243 clickLocation, class_2350 face) {
        Point2d coords = PositionUtils.getClickedBlockSpaceCoords(clickLocation, face);

        final double x = 0.5d - coords.x();
        final double y = 0.5d - coords.y();

        final double radians = Math.atan2(y, x);
        double degrees = radians * (180 / Math.PI);
        degrees = (degrees + 270) % 360; // Adjust so the 0 is NORTH.

        int region = (int)((degrees + 45) % 360) / 90;
        return fromRotation(region * 90);
    }
}
