package io.github.mortuusars.chalk.event;

import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.Config;
import io.github.mortuusars.chalk.advancements.PlayerSleepInfo;
import io.github.mortuusars.chalk.world.chalk.symbol.MarkSymbol;
import io.github.mortuusars.mortaar.util.supporter.Supporters;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_5250;
import net.minecraft.class_6880;
import net.minecraft.class_8779;

public class CommonEvents {
    public static void commonSetup() {

    }

    public static void onAdvancementAward(class_3222 player, class_8779 advancement) {
        if (!Config.Server.SYMBOL_UNLOCKING_CHAT_MESSAGE.get()) {
            return;
        }

        List<class_6880<MarkSymbol>> unlockedSymbols = MarkSymbol.getAllHolders(player.method_56673(), Supporters.isEligibleForGoldenRewards(player.method_5667()))
              .filter(symbol -> symbol.comp_349().requiredAdvancement()
                    .map(id -> id.equals(advancement.comp_1919())).orElse(false))
              .toList();

        if (!unlockedSymbols.isEmpty()) {
            if (unlockedSymbols.size() == 1) {
                unlockedSymbols.getFirst().method_40230().ifPresent(key ->
                      player.method_7353(class_2561.method_43469("chat.chalk.symbol_unlocked", class_2561.method_43471(
                            key.method_29177().method_42093("mark_symbol")).method_27696(class_2583.field_24360.method_36139(0x53a5df))), false));
            } else {
                List<class_5250> symbolNames = unlockedSymbols.stream()
                      .filter(s -> s.method_40230().isPresent())
                      .map(s -> class_2561.method_43471(s.method_40230().orElseThrow().method_29177().method_42093("mark_symbol"))
                            .method_27696(class_2583.field_24360.method_36139(0x53a5df)))
                      .toList();

                class_5250 symbolsListComponent = class_2561.method_43473();

                for (int i = 0; i < symbolNames.size(); i++) {
                    if (i != 0) {
                        symbolsListComponent.method_10852(class_2561.method_43470(", "));
                    }
                    symbolsListComponent.method_10852(symbolNames.get(i));
                }

                player.method_7353(class_2561.method_43469("chat.chalk.symbol_unlocked", symbolsListComponent), false);
            }

            player.method_17356(Chalk.SoundEvents.MARK_DRAWN.get(), class_3419.field_15248, 1f, 1f);
        }
    }

    public static void onStoppedSleeping(class_3222 serverPlayer) {
        boolean sleepingLongEnough = serverPlayer.method_7276();
        if (!sleepingLongEnough) {
            return;
        }

        List<String> tags = serverPlayer.method_5752().stream().toList();

        List<class_2338> sleepPositions = new ArrayList<>();

        for (String tag : tags) {
            if (tag.startsWith("ChalkConsecutiveSleepPositions")) {
                serverPlayer.method_5738(tag);

                String dataStr = tag.replace("ChalkConsecutiveSleepPositions", "");
                PlayerSleepInfo sleepInfo = PlayerSleepInfo.deserialize(dataStr);
                sleepPositions = new ArrayList<>(sleepInfo.sleepPositions());
                break;
            }
        }

        Optional<class_2338> sleepingPos = serverPlayer.method_18398();
        if (sleepingPos.isPresent()) {
            if (sleepPositions.size() > 20) {
                sleepPositions.removeFirst();
            }

            sleepPositions.add(sleepingPos.get());

            PlayerSleepInfo sleepInfo = new PlayerSleepInfo(sleepPositions);

            Chalk.CriteriaTriggers.CONSECUTIVE_SLEEPING.get().trigger(serverPlayer, sleepInfo);

            String serializedDataStr = sleepInfo.serialize();
            serverPlayer.method_5780("ChalkConsecutiveSleepPositions" + serializedDataStr);
        }
    }
}
