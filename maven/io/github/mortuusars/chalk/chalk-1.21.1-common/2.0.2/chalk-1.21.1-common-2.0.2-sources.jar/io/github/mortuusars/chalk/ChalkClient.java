package io.github.mortuusars.chalk;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;

public class ChalkClient {
    public static void init() {
        ItemModelOverrides.register();
    }

    // --

    public static class ItemModelOverrides {
        public static final class_2960 GLOWING_PROPERTY = Chalk.resource("glowing");

        public static void register() {
            class_5272.method_27879(Chalk.Items.CHALK_BOX.get(), GLOWING_PROPERTY, ItemModelOverrides::isChalkBoxGlowing);
        }

        public static float isChalkBoxGlowing(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed) {
            return Chalk.Items.CHALK_BOX.get().shouldDrawGlowingMark(stack) ? 1F : 0F;
        }
    }
}
