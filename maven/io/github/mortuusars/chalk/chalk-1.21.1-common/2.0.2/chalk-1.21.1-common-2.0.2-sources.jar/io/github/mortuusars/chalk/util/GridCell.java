package io.github.mortuusars.chalk.util;

import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3542;
import net.minecraft.class_7995;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public enum GridCell implements class_3542 {
    TOP_LEFT("top_left"),
    TOP("top"),
    TOP_RIGHT("top_right"),
    LEFT("left"),
    CENTER("center"),
    RIGHT("right"),
    BOTTOM_LEFT("bottom_left"),
    BOTTOM("bottom"),
    BOTTOM_RIGHT("bottom_right");

    private static final GridCell[] VALUES = values();

    public static final Codec<GridCell> CODEC = class_3542.method_28140(GridCell::values);
    public static final class_9139<ByteBuf, GridCell> STREAM_CODEC = class_9135.method_56375(
          class_7995.method_47914(GridCell::ordinal, values(), class_7995.class_7996.field_41665), GridCell::ordinal);

    private final String name;

    GridCell(String name) {
        this.name = name;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }

    /**
     * Returns the cell of a 3x3 grid depending on where the block was clicked.
     */
    public static GridCell fromClickLocation(class_243 clickLocation, class_2350 face) {
        Point2d coords = PositionUtils.getClickedBlockSpaceCoords(clickLocation, face);
        int x = class_3532.method_15340((int) (coords.x() * 3), 0, 2);
        int y = class_3532.method_15340((int) (coords.y() * 3), 0, 2);
        return VALUES[y * 3 + x];
    }
}
