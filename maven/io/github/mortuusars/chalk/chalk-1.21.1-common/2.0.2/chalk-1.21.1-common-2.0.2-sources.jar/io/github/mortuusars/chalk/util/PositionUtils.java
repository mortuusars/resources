package io.github.mortuusars.chalk.util;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import org.joml.Vector3f;

public class PositionUtils {
    /**
     * Returns coords of a center of BlockPos
     */
    public static Vector3f blockCenter(class_2338 blockPos){
        return new Vector3f(blockPos.method_10263() + 0.5f, blockPos.method_10264() + 0.5f, blockPos.method_10260() + 0.5f);
    }

    /**
     * Returns coords from a center of BlockPos with offset (from center) to one of the faces.
     */
    public static Vector3f blockCenterOffsetToFace(class_2338 blockPos, class_2350 facing, float offset){
        Vector3f vec = blockCenter(blockPos);

        class_2382 normal = facing.method_10163();
        return new Vector3f(vec.x() - (normal.method_10263() * offset), vec.y() - (normal.method_10264() * offset), vec.z() - (normal.method_10260() * offset));
    }

    /**
     * Returns a point representing where on a block face was clicked. 0.0 to 1.0.
     */
    public static Point2d getClickedBlockSpaceCoords(class_243 location, class_2350 face) {
        class_2338 pos = class_2338.method_49638(location);

        final double x = location.field_1352 - pos.method_10263();
        final double y = location.field_1351 - pos.method_10264();
        final double z = location.field_1350 - pos.method_10260();

        return switch (face) {
            case field_11043 -> new Point2d(1d - x, 1d - y);
            case field_11035 -> new Point2d(x, 1d - y);
            case field_11039 -> new Point2d(z, 1d - y);
            case field_11034 -> new Point2d(1d - z, 1d - y);
            default -> new Point2d(x, z);
        };
    }
}
