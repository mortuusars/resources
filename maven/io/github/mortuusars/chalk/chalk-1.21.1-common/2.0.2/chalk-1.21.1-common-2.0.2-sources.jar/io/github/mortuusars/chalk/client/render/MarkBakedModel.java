package io.github.mortuusars.chalk.client.render;

import io.github.mortuusars.chalk.world.chalk.Mark;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1723;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3665;
import net.minecraft.class_4590;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_783;
import net.minecraft.class_787;
import net.minecraft.class_789;
import net.minecraft.class_796;
import net.minecraft.class_806;
import net.minecraft.class_809;
import net.minecraft.client.renderer.block.model.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.List;

/**
 * Baked model is used to programmatically create proper Chalk Mark block model.
 * Based on particular blockstate properties it chooses proper block orientation, texture, texture orientation, glowing.
 */
public class MarkBakedModel implements class_1087 {
    public static final Vector3f ROTATION_ORIGIN = new Vector3f(0.5f, 0.5f, 0.5f);
    public static final class_796 BAKERY = new class_796();
    public static final class_3665 TRANSFORM = new class_3665() {
        @Override
        public @NotNull class_4590 method_3509() {
            return class_4590.method_22931();
        }
    };

    public static final HashMap<class_2350, Vector3f> FROM_COORDS;
    public static final HashMap<class_2350, Vector3f> TO_COORDS;

    private final class_1087 baseModel;

    public MarkBakedModel(class_1087 baseModel){
        this.baseModel = baseModel;
    }

    static {
        FROM_COORDS = new HashMap<>();
        FROM_COORDS.put(class_2350.field_11033, new Vector3f(0, 15.95f, 0));
        FROM_COORDS.put(class_2350.field_11036, new Vector3f(0, 0, 0));
        FROM_COORDS.put(class_2350.field_11043, new Vector3f(0, 0, 15.95f));
        FROM_COORDS.put(class_2350.field_11035, new Vector3f(0, 0, 0));
        FROM_COORDS.put(class_2350.field_11039, new Vector3f(15.95f, 0, 0));
        FROM_COORDS.put(class_2350.field_11034, new Vector3f(0, 0, 0));

        TO_COORDS = new HashMap<>();
        TO_COORDS.put(class_2350.field_11033, new Vector3f(16, 16, 16));
        TO_COORDS.put(class_2350.field_11036, new Vector3f(16, 0.05f, 16));
        TO_COORDS.put(class_2350.field_11043, new Vector3f(16, 16, 16));
        TO_COORDS.put(class_2350.field_11035, new Vector3f(16, 16, 0.05f));
        TO_COORDS.put(class_2350.field_11039, new Vector3f(16, 16, 16));
        TO_COORDS.put(class_2350.field_11034, new Vector3f(0.05f, 16, 16));
    }

    @Override
    public boolean method_4708() {
        return baseModel.method_4708();
    }

    @Override
    public boolean method_4712() {
        return baseModel.method_4712();
    }

    @Override
    public boolean method_24304() {
        return baseModel.method_24304();
    }

    @Override
    public boolean method_4713() {
        return baseModel.method_4713();
    }

    @Override
    public @NotNull class_1058 method_4711() {
        return baseModel.method_4711();
    }

    @Override
    public @NotNull class_809 method_4709() {
        return class_809.field_4301;
    }

    @Override
    public @NotNull class_806 method_4710() {
        return baseModel.method_4710();
    }

    @Override
    public @NotNull List<class_777> method_4707(@Nullable class_2680 state, @Nullable class_2350 direction, class_5819 random) {
        return List.of();
    }

    // --

    public class_777 bakeMarkQuad(class_2350 direction, @NotNull Mark mark) {
        class_1058 texture = class_310.method_1551().method_1549(class_1723.field_21668)
              .apply(mark.symbol().comp_349().texture());

        int tintIndex = direction.method_10146(); // Allow MarkBlockColor to tint each face independently
        class_783 blockPartFace = new class_783(direction, tintIndex, "",
              new class_787(new float[]{0f, 0f, 16f, 16f}, direction == class_2350.field_11033 ? 180 : 0));

        // Rotate the texture
        int rotationOffset = mark.symbol().comp_349().rotationOffset();
        int rotation = (mark.orientation().getRotation() + (direction == class_2350.field_11033 ? -rotationOffset : rotationOffset)) % 360;

        if (direction.method_10171() == class_2350.class_2352.field_11056 || direction.method_10166() == class_2350.class_2351.field_11052) {
            rotation = 360 - rotation;
        }

        class_789 blockPartRotation = new class_789(ROTATION_ORIGIN, direction.method_10166(), rotation, false);

        Vector3f from = FROM_COORDS.get(direction);
        Vector3f to = TO_COORDS.get(direction);
        class_777 bakedQuad = BAKERY.method_3468(from, to, blockPartFace, texture, direction, TRANSFORM, blockPartRotation, !mark.glowing());

        if (mark.glowing()) {
            int[] vertexData = bakedQuad.method_3357();
            int step = vertexData.length / 4;

            // Set lighting to full-bright on all vertices
            vertexData[6] = 0x00F000F0;
            vertexData[6 + step] = 0x00F000F0;
            vertexData[6 + 2 * step] = 0x00F000F0;
            vertexData[6 + 3 * step] = 0x00F000F0;
        }

        return bakedQuad;
    }
}
