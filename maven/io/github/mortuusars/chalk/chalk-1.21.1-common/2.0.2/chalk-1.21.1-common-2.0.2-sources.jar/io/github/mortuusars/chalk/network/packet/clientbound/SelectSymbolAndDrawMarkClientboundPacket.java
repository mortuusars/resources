package io.github.mortuusars.chalk.network.packet.clientbound;

import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.network.handler.ClientPacketHandler;
import io.github.mortuusars.chalk.world.chalk.MarkDrawingContext;
import io.github.mortuusars.chalk.world.chalk.symbol.MarkSymbol;
import io.github.mortuusars.mortaar.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_6880;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SelectSymbolAndDrawMarkClientboundPacket(List<class_6880<MarkSymbol>> availableSymbols, MarkDrawingContext context) implements Packet {
    public static final class_9154<SelectSymbolAndDrawMarkClientboundPacket> TYPE = new class_9154<>(Chalk.resource("select_symbol_and_draw_mark"));

    public static final class_9139<class_9129, SelectSymbolAndDrawMarkClientboundPacket> STREAM_CODEC = class_9139.method_56435(
          class_9135.method_56383(Chalk.Registries.MARK_SYMBOL).method_56433(class_9135.method_56363()), SelectSymbolAndDrawMarkClientboundPacket::availableSymbols,
          MarkDrawingContext.STREAM_CODEC, SelectSymbolAndDrawMarkClientboundPacket::context,
          SelectSymbolAndDrawMarkClientboundPacket::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketHandler.handleSelectSymbolAndDrawMark(this);
        return true;
    }
}
