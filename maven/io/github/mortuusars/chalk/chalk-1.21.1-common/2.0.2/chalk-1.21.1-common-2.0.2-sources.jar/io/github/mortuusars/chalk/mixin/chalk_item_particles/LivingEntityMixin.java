package io.github.mortuusars.chalk.mixin.chalk_item_particles;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.chalk.world.item.ChalkItem;
import io.github.mortuusars.mortaar.util.color.Color;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1309.class)
public class LivingEntityMixin {
    @WrapOperation(method = "spawnItemParticles", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;addParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)V"))
    private void onSpawnItemParticle(class_1937 instance, class_2394 particleData, double x, double y, double z,
                                     double xSpeed, double ySpeed, double zSpeed, Operation<Void> original,
                                     @Local(argsOnly = true) class_1799 stack) {
        if (stack.method_7909() instanceof ChalkItem chalkItem) {
            int color = chalkItem.getTintColor(stack, 0);
            particleData = new class_2390(new Vector3f(Color.redF(color), Color.greenF(color), Color.blueF(color)), 2f);
        }

        original.call(instance, particleData, x, y, z, xSpeed, ySpeed, zSpeed);
    }
}
