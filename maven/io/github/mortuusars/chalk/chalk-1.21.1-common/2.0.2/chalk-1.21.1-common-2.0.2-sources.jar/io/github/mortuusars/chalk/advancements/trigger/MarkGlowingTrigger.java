package io.github.mortuusars.chalk.advancements.trigger;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.chalk.advancements.predicate.MarkPredicate;
import io.github.mortuusars.chalk.world.chalk.Mark;
import io.github.mortuusars.mortaar.advancement.predicate.MapColorPredicate;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_2048;
import net.minecraft.class_2090;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_3620;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public class MarkGlowingTrigger extends class_4558<MarkGlowingTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player, Mark mark, class_2338 markPos, class_3620 surfaceColor) {
        this.method_22510(player, triggerInstance -> triggerInstance.matches(player, mark, markPos, surfaceColor));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  Optional<MarkPredicate> mark,
                                  Optional<class_2090> location,
                                  Optional<MapColorPredicate> surfaceColor) implements SimpleInstance {

        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance ->
              instance.group(class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::player),
                          MarkPredicate.CODEC.optionalFieldOf("mark").forGetter(TriggerInstance::mark),
                          class_2090.field_45760.optionalFieldOf("location").forGetter(TriggerInstance::location),
                          MapColorPredicate.CODEC.optionalFieldOf("surface_color").forGetter(TriggerInstance::surfaceColor))
                    .apply(instance, TriggerInstance::new));

        public boolean matches(class_3222 player, Mark mark, class_2338 markPos, class_3620 surfaceColor) {
            return (this.mark.isEmpty() || this.mark.get().matches(mark))
                  && (this.location.isEmpty() || this.location.get().method_9018(player.method_51469(), markPos.method_10263() + 0.5, markPos.method_10264() + 0.5, markPos.method_10260() + 0.5))
                  && (this.surfaceColor.isEmpty() || this.surfaceColor.get().matches(surfaceColor));
        }
    }
}
