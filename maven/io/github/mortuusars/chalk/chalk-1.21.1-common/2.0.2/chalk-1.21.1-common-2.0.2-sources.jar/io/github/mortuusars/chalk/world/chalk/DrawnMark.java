package io.github.mortuusars.chalk.world.chalk;

import net.minecraft.class_2350;

public record DrawnMark(class_2350 facing, Mark mark) {
}
