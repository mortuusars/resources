package io.github.mortuusars.chalk.network.handler;

import io.github.mortuusars.chalk.client.gui.screens.SymbolSelectScreen;
import io.github.mortuusars.chalk.network.packet.clientbound.SelectSymbolAndDrawMarkClientboundPacket;
import io.github.mortuusars.chalk.world.item.MarkDrawable;
import net.minecraft.class_310;

public class ClientPacketHandler {
    public static void handleSelectSymbolAndDrawMark(SelectSymbolAndDrawMarkClientboundPacket packet) {
        if (class_310.method_1551().field_1724 == null
              || class_310.method_1551().field_1687 == null
              || !(class_310.method_1551().field_1724.method_5998(packet.context().hand()).method_7909() instanceof MarkDrawable)) {
            return;
        }

        SymbolSelectScreen symbolSelectScreen = new SymbolSelectScreen(packet.availableSymbols(), packet.context());
        class_310.method_1551().method_1507(symbolSelectScreen);
    }
}
