package io.github.mortuusars.chalk.client.gui.tooltip;

import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.Config;
import io.github.mortuusars.chalk.client.gui.screens.ChalkBoxScreen;
import io.github.mortuusars.chalk.world.item.component.ChalkBoxContents;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import org.jetbrains.annotations.NotNull;

public class ClientChalkBoxTooltip implements class_5684 {
    public static final class_2960 SLOTS_SPRITE = Chalk.resource("chalk_box/tooltip_slots");
    public static final class_2960 GLOWING_SPRITE = Chalk.resource("chalk_box/tooltip_glowing");

    public static final int ROWS = 3;
    public static final int COLUMNS = 3;

    protected final ChalkBoxContents contents;

    public ClientChalkBoxTooltip(ChalkBoxContents contents) {
        this.contents = contents;
    }

    @Override
    public int method_32664(@NotNull class_327 font) {
        return backgroundWidth();
    }

    @Override
    public int method_32661() {
        return backgroundHeight() + 3;
    }

    protected int backgroundWidth() {
        return shouldShowGlow() ? 86 : 58;
    }

    protected int backgroundHeight() {
        return 60;
    }

    protected boolean shouldShowGlow() {
        return Config.Server.CHALK_BOX_GLOWING_ENABLED.get()
              && (contents.glow() > 0 || !contents.items().get(ChalkBoxContents.GLOWINGS_SLOT).method_7960());
    }

    @Override
    public void method_32666(@NotNull class_327 font, int x, int y, class_332 graphics) {
        graphics.method_52706(SLOTS_SPRITE, x, y, 58, 60);

        int selectedIndex = contents.selected();
        int index = 0;
        for (int column = 0; column < COLUMNS; column++) {
            for (int row = 0; row < ROWS; row++) {
                int slotX = x + row * 18 + 2;
                int slotY = y + column * 18 + 3;

                if (index == selectedIndex) {
                    graphics.method_52706(ChalkBoxScreen.SELECTED_CHALK_SLOT_OVERLAY_SPRITE, slotX - 1, slotY - 1, 20, 20);
                }

                if (contents.getItem(index).method_7960()) {
                    graphics.method_52706(ChalkBoxScreen.CHALK_SLOT_PLACEHOLDER_SPRITE, slotX, slotY, 18, 18);
                }

                renderSlotItem(font, graphics, index, slotX, slotY);

                index++;
            }
        }

        if (shouldShowGlow()) {
            graphics.method_52706(GLOWING_SPRITE, x + 58, y + 18, 28, 24);

            if (contents.getItem(index).method_7960()) {
                graphics.method_52706(ChalkBoxScreen.GLOWING_SLOT_PLACEHOLDER_SPRITE, x + 59, y + 21, 18, 18);
            }

            renderSlotItem(font, graphics, index, x + 59, y + 21);

            if (contents.glow() > 0) {
                int currentGlow = contents.glow();
                int maxGlow = Config.Server.CHALK_BOX_GLOWING_AMOUNT_PER_ITEM.get();
                int barSize = currentGlow == maxGlow ? 18 : 2 + Math.round((currentGlow - 1) * 14f / (maxGlow - 2));
                int glowingBarFillLevel = Math.min(ChalkBoxScreen.GLOW_BAR_HEIGHT, barSize);
                graphics.method_52708(ChalkBoxScreen.GLOW_BAR_SPRITE, 5, 18, 0, 18 - glowingBarFillLevel,
                      x + 79, y + 21 + 18 - glowingBarFillLevel, 5, glowingBarFillLevel);
            }
        }
    }

    protected void renderSlotItem(class_327 font, class_332 graphics, int index, int x, int y) {
        class_1799 itemstack = this.contents.items().get(index);
        graphics.method_51428(itemstack, x + 1, y + 1, index);
        graphics.method_51431(font, itemstack, x + 1, y + 1);
    }
}
