package io.github.mortuusars.chalk.world.inventory;

import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.Config;
import io.github.mortuusars.chalk.world.item.component.ChalkBoxContents;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3419;
import net.minecraft.class_9129;

public class ChalkBoxMenu extends AbstractInHandContainerMenu {
    protected boolean containerInitialized;

    public ChalkBoxMenu(int containerId, class_1661 playerInventory, class_1268 hand) {
        super(Chalk.MenuTypes.CHALK_BOX.get(), containerId, playerInventory, hand);
    }

    @Override
    protected void init() {
        playerSlotsY = 84;
        super.init();
    }

    @Override
    public void method_7610(int stateId, List<class_1799> items, class_1799 carried) {
        super.method_7610(stateId, items, carried);
        containerInitialized = true;
    }

    @Override
    protected class_1263 createContainer() {
        List<class_1799> items = new ArrayList<>(ChalkBoxContents.of(getItemInHand()).copyItems());
        while (items.size() < ChalkBoxContents.SLOTS) {
            items.add(class_1799.field_8037);
        }

        class_1277 container = new class_1277(items.stream().limit(ChalkBoxContents.SLOTS).toArray(class_1799[]::new));
        container.method_5489(this::containerChanged);
        return container;
    }

    protected void containerChanged(class_1263 container) {
        if (!containerInitialized && getPlayer().method_37908().method_8608()) {
            return;
        }

        getContents().mutable()
              .setItems(container)
              .updateGlow()
              .toImmutable(getItemInHand());
    }

    @Override
    protected void addContainerSlots() {
        int chalkSlotsX = 62;
        int chalkSlotsY = 17;

        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 3; column++) {
                int index = column + row * 3;
                int x = chalkSlotsX + column * 18;
                int y = chalkSlotsY + row * 18;

                method_7621(new class_1735(getContainer(), index, x, y) {
                    @Override
                    public boolean method_7680(class_1799 stack) {
                        return ChalkBoxContents.canHold(method_34266(), stack);
                    }
                });
            }
        }

        method_7621(new class_1735(getContainer(), ChalkBoxContents.GLOWINGS_SLOT, 134, 35) {
            @Override
            public boolean method_7680(class_1799 stack) {
                return isGlowEnabled() && ChalkBoxContents.canHold(method_34266(), stack);
            }

            @Override
            public boolean method_7682() {
                return isGlowEnabled();
            }

            @Override
            public void method_7673(@NotNull class_1799 stack) {
                if (getPlayer().method_37908().field_9236 && this.method_7677().method_7960()
                      && getGlow() <= 0 && stack.method_31573(Chalk.Tags.Items.GLOWINGS)) {
                    class_243 pos = getPlayer().method_19538();
                    getPlayer().method_37908().method_43128(getPlayer(), pos.field_1352, pos.field_1351, pos.field_1350, Chalk.SoundEvents.GLOW_APPLIED.get(), class_3419.field_15248, 1f, 1f);
                    getPlayer().method_37908().method_43128(getPlayer(), pos.field_1352, pos.field_1351, pos.field_1350, Chalk.SoundEvents.GLOWING.get(), class_3419.field_15248, 1f, 1f);
                }

                super.method_7673(stack);
            }
        });
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (id >= 100 && id < 100 + ChalkBoxContents.CHALK_SLOTS) {
            setSelectedSlot(id - 100);
            return true;
        }
        return false;
    }

    @Override
    public void method_7595(@NotNull class_1657 player) {
        super.method_7595(player);
        player.method_5783(Chalk.SoundEvents.CHALK_BOX_CLOSE.get(), 0.85f, 0.9f + player.method_37908().method_8409().method_43057() * 0.2f);

        if (player.method_7337() && !player.method_37908().method_8608()) {
            player.method_31548().method_5447(getUsedSlot(), getItemInHand());
        }

        // Fixes inventory not syncing after closing:
        player.field_7498.method_34257();
    }

    public ChalkBoxContents getContents() {
        return ChalkBoxContents.of(getItemInHand());
    }

    public boolean isGlowEnabled() {
        return  Config.Server.GLOWING_ENABLED.get() && Config.Server.CHALK_BOX_GLOWING_ENABLED.get();
    }

    public int getGlow() {
        return getContents().glow();
    }

    public int getMaxGlow() {
        return Config.Server.CHALK_BOX_GLOWING_AMOUNT_PER_ITEM.get();
    }

    public int getSelectedSlot() {
        return getContents().selected();
    }

    public void setSelectedSlot(int slot) {
        if (getContents().selected() != slot) {
            getContents().mutable().setSelected(slot).toImmutable(getItemInHand());
            getPlayer().method_7350();
        }
    }

    public static ChalkBoxMenu fromNetwork(int containerID, class_1661 playerInventory, class_9129 buffer) {
        return new ChalkBoxMenu(containerID, playerInventory, buffer.method_10818(class_1268.class));
    }
}
