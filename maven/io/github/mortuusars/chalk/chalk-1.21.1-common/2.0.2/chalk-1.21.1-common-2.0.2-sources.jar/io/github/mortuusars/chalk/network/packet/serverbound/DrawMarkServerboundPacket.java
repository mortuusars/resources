package io.github.mortuusars.chalk.network.packet.serverbound;

import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.world.chalk.MarkDrawingContext;
import io.github.mortuusars.chalk.world.chalk.symbol.MarkSymbol;
import io.github.mortuusars.chalk.world.item.MarkDrawable;
import io.github.mortuusars.mortaar.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2598;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record DrawMarkServerboundPacket(class_6880<MarkSymbol> symbol, MarkDrawingContext drawingContext) implements Packet {
    public static final class_8710.class_9154<DrawMarkServerboundPacket> TYPE = new class_8710.class_9154<>(Chalk.resource("draw_mark"));

    public static final class_9139<class_9129, DrawMarkServerboundPacket> STREAM_CODEC = class_9139.method_56435(
          class_9135.method_56383(Chalk.Registries.MARK_SYMBOL), DrawMarkServerboundPacket::symbol,
          MarkDrawingContext.STREAM_CODEC, DrawMarkServerboundPacket::drawingContext,
          DrawMarkServerboundPacket::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        class_1799 itemInHand = player.method_5998(drawingContext.hand());
        if (!(itemInHand.method_7909() instanceof MarkDrawable drawable)) {
            Chalk.LOGGER.error("{} is not a drawing tool.", itemInHand);
            return false;
        }

        if (!(player instanceof class_3222 serverPlayer)) {
            Chalk.LOGGER.error("{} is not a server player.", player);
            return false;
        }

        if (!drawable.isSymbolAvailable(serverPlayer, drawingContext, symbol)) {
            Chalk.LOGGER.error("{} tried to draw symbol '{}', but doesn't have it unlocked.", player,
                  symbol.method_40230().map(k -> k.method_29177().toString()).orElse("<unknown symbol>"));
            return false;
        }

        drawable.drawMark(player, drawingContext, drawable.createMark(player, drawingContext, itemInHand, symbol));
        return true;
    }
}