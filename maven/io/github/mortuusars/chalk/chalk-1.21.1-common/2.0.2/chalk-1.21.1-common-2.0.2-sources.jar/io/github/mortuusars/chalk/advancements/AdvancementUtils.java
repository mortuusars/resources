package io.github.mortuusars.chalk.advancements;

import net.minecraft.class_167;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8779;
import org.jetbrains.annotations.Nullable;

public class AdvancementUtils {
    public static boolean hasAdvancement(class_3222 player, class_2960 advancement) {
        @Nullable class_8779 advancementHolder = player.method_51469().method_8503().method_3851().method_12896(advancement);
        if (advancementHolder == null) {
            return false;
        }

        class_167 progress = player.method_14236().method_12882(advancementHolder);
        return progress.method_740();
    }
}
