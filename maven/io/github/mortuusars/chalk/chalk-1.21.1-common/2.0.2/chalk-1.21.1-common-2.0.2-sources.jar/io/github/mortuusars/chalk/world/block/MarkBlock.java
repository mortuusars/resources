package io.github.mortuusars.chalk.world.block;

import com.mojang.serialization.MapCodec;
import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.Config;
import io.github.mortuusars.chalk.client.ClientHelper;
import io.github.mortuusars.chalk.mixin.creative_mark_breaking.MultiPlayerGameModeMixin;
import io.github.mortuusars.chalk.util.ParticleUtils;
import io.github.mortuusars.chalk.util.PositionUtils;
import io.github.mortuusars.chalk.world.chalk.DrawnMark;
import io.github.mortuusars.chalk.world.chalk.Mark;
import io.github.mortuusars.chalk.world.item.ChalkItem;
import io.github.mortuusars.chalk.world.item.MarkDrawable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5253;
import net.minecraft.class_5819;
import net.minecraft.class_9062;

public class MarkBlock extends class_2237 {
    public static final MapCodec<MarkBlock> field_46280 = method_54094(MarkBlock::new);

    public static final class_2746 GLOWING = class_2746.method_11825("glowing");

    public static final class_265 SHAPE_DOWN = class_2248.method_9541(1.5D, 15.5D, 1.5D, 14.5D, 16D, 14.5D);
    public static final class_265 SHAPE_UP = class_2248.method_9541(1.5D, 0D, 1.5D, 14.5D, 0.5D, 14.5D);
    public static final class_265 SHAPE_NORTH = class_2248.method_9541(1.5D, 1.5D, 15.5D, 14.5D, 14.5D, 16D);
    public static final class_265 SHAPE_SOUTH = class_2248.method_9541(1.5D, 1.5D, 0D, 14.5D, 14.5D, 0.5D);
    public static final class_265 SHAPE_WEST = class_2248.method_9541(15.5D, 1.5D, 1.5D, 16D, 14.5D, 14.5D);
    public static final class_265 SHAPE_EAST = class_2248.method_9541(0D, 1.5D, 1.5D, 0.5D, 14.5D, 14.5D);

    public static final class_265[] SHAPES = new class_265[]{
          SHAPE_DOWN,
          SHAPE_UP,
          SHAPE_NORTH,
          SHAPE_SOUTH,
          SHAPE_WEST,
          SHAPE_EAST
    };

    public static final class_265[] COMBINED_SHAPES = class_156.method_654(new class_265[64], shapes -> {
        for (int mask = 0; mask < 64; mask++) {
            class_265 shape = class_259.method_1073();
            for (int i = 0; i < 6; i++) {
                if ((mask & (1 << i)) != 0) {
                    shape = class_259.method_1084(shape, SHAPES[i]);
                }
            }
            shapes[mask] = shape;
        }
    });

    public MarkBlock(class_2251 properties) {
        super(properties);
        method_9590(method_9595().method_11664()
              .method_11657(GLOWING, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(GLOWING);
    }

    @Override
    protected @NotNull MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new MarkBlockEntity(pos, state);
    }

    // --

    @Override
    protected @NotNull class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected boolean method_9579(class_2680 state, class_1922 level, class_2338 pos) {
        return true;
    }

    @Override
    protected @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return level.method_8321(pos) instanceof MarkBlockEntity markBlockEntity
              ? COMBINED_SHAPES[markBlockEntity.getMarks().getMask()]
              : class_259.method_1073();
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        return !(level.method_8321(pos) instanceof MarkBlockEntity markBlockEntity) || !markBlockEntity.getMarks().isEmpty();
    }

    @Override
    public void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 block, class_2338 fromPos, boolean isMoving) {
        super.method_9612(state, level, pos, block, fromPos, isMoving);
        recheckAndUpdate(level, pos);
    }

    public void recheckAndUpdate(class_1937 level, class_2338 pos) {
        if (!(level.method_8321(pos) instanceof MarkBlockEntity blockEntity)) {
            return;
        }

        boolean glowing = false;

        for (int i = 0; i < 6; i++) {
            @Nullable Mark mark = blockEntity.getMarks().get(i);
            if (mark != null) {
                class_2350 facing = class_2350.method_10143(i);
                if (!canMarkSurvive(level, pos, facing)) {
                    removeMarkWithEffects(level, pos, facing);
                } else if (mark.glowing()) {
                    glowing = true;
                }
            }
        }

        if (blockEntity.getMarks().isEmpty()) {
            level.method_8650(pos, false);
        } else {
            class_2680 state = level.method_8320(pos);
            if (state.method_26204() instanceof MarkBlock && state.method_11654(GLOWING) != glowing) {
                level.method_8652(pos, state.method_11657(GLOWING, glowing), field_31022);
            }
        }
    }

    public boolean canMarkSurvive(class_1937 level, class_2338 pos, class_2350 facing) {
        class_2338 surfacePos = pos.method_10093(facing.method_10153());
        class_2680 surfaceBlockState = level.method_8320(surfacePos);
        return !surfaceBlockState.method_26164(Chalk.Tags.Blocks.CHALK_CANNOT_DRAW_ON)
              && surfaceBlockState.method_26206(level, surfacePos, facing);
    }

    @Override
    public void method_9496(class_2680 blockState, class_1937 level, class_2338 pos, class_5819 random) {
        if (Config.Common.GLOWING_MARK_PARTICLES.get() && level.method_8321(pos) instanceof MarkBlockEntity markBlockEntity) {
            markBlockEntity.getMarks().forEach((facing, mark) -> {
                if (mark.glowing() && random.method_43048(90) == 0) {
                    ParticleUtils.spawnParticle(level, class_2398.field_11207, PositionUtils.blockCenterOffsetToFace(pos, facing,
                          0.33f), new Vector3f(0f, facing == class_2350.field_11033 ? -0.005f : 0.015f, 0f), 1);
                }
            });
        }
    }

    // -- Interact

    @Override
    protected @NotNull class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        class_1799 usedStack = player.method_5998(hand);

        if (Config.Server.GLOWING_ENABLED.get()
              && usedStack.method_31573(Chalk.Tags.Items.GLOWINGS)
              && level.method_8321(pos) instanceof MarkBlockEntity blockEntity
              && getMarkAt(level, hitResult.method_17784()) instanceof DrawnMark(class_2350 facing, Mark existingMark)
              && !existingMark.glowing()) {

            if (!player.method_7337()) {
                usedStack.method_7934(1);
            }

            level.method_8396(null, pos, Chalk.SoundEvents.GLOW_APPLIED.get(), class_3419.field_15245, 1f, 1f);
            level.method_8396(null, pos, Chalk.SoundEvents.GLOWING.get(), class_3419.field_15245, 0.8f, 1f);
            ParticleUtils.spawnParticle(level, class_2398.field_11207, PositionUtils.blockCenterOffsetToFace(pos, facing, 0.3f),
                  new Vector3f(0f, 0.03f, 0f), 2);

            Mark mark = existingMark.withGlowing(true);
            blockEntity.getMarks().set(facing, mark);
            blockEntity.marksChanged();

            if (player instanceof class_3222 serverPlayer) {
                class_2338 surfacePos = pos.method_10093(facing.method_10153());
                Chalk.CriteriaTriggers.MARK_GLOWING.get().trigger(
                      serverPlayer, mark, pos, level.method_8320(surfacePos).method_26205(level, pos));
            }

            return class_9062.field_47728;
        }

        return class_9062.field_47731;
    }

    public class_1799 pick(class_1657 player, class_4538 level, class_2338 pos, class_2680 state, class_239 hitResult) {
        return getMarkAt(level, hitResult.method_17784()) instanceof DrawnMark mark
              ? MarkDrawable.findMatching(player.method_31548(), mark.mark().color(), player.method_7337() ?
                  () -> ChalkItem.create(mark.mark().color(), 0)
                  : null)
              : MarkDrawable.findMatching(player.method_31548(), 0x000000);
    }

    public void removeMarkWithEffects(class_1937 level, class_2338 pos, class_2350 facing) {
        if (level.method_8321(pos) instanceof MarkBlockEntity blockEntity
              && blockEntity.getMarks().get(facing) instanceof Mark mark) {

            blockEntity.getMarks().remove(facing);
            blockEntity.marksChanged();

            if (level instanceof class_3218 serverLevel) {
                Vector3f centerOffset = PositionUtils.blockCenterOffsetToFace(pos, facing, 0.25f);
                Vector3f color = new Vector3f(
                      class_5253.class_5254.method_27765(mark.color()) / 255f,
                      class_5253.class_5254.method_27766(mark.color()) / 255f,
                      class_5253.class_5254.method_27767(mark.color()) / 255f);
                serverLevel.method_14199(new class_2390(color, 2f),
                      centerOffset.x(), centerOffset.y(), centerOffset.z(),
                      1, 0.1, 0.1, 0.1, 0.02);

                level.method_8396(null, pos, Chalk.SoundEvents.MARK_REMOVED.get(), class_3419.field_15245,
                      0.5f, level.method_8409().method_43057() * 0.2f + 0.8f);
            }

            if (blockEntity.getMarks().isEmpty()) {
                level.method_8650(pos, false);
            }
        }
    }

    /**
     * Handles mark destroying. One at a time.<br>
     * This method is not called when player is in creative mode, we handle that separately in {@link MultiPlayerGameModeMixin}.
     */
    @Override
    protected void method_9606(class_2680 state, class_1937 level, class_2338 pos, class_1657 player) {
        if (player.method_37908().method_8608()) {
            ClientHelper.attackMarkBlock(pos);
        }
    }

    /**
     * We handle mark destroying in {@link MarkBlock#method_9606}.<br>
     * Returning 0 here prevents usual block behavior.
     */
    @Override
    protected float method_9594(class_2680 state, class_1657 player, class_1922 level, class_2338 pos) {
        return 0;
    }

    // --

    public static @Nullable MarkBlockEntity getExistingOrPlaceNew(class_1937 level, class_2338 pos) {
        if (level.method_8321(pos) instanceof MarkBlockEntity existingBlockEntity) {
            return existingBlockEntity;
        }

        level.method_8652(pos, Chalk.Blocks.MARK.get().method_9564(), field_31022);

        return level.method_8321(pos) instanceof MarkBlockEntity existingBlockEntity
              ? existingBlockEntity
              : null;
    }

    public static @Nullable DrawnMark getMarkAt(class_1922 level, class_243 location) {
        class_2338 pos = class_2338.method_49638(location);

        if (!(level.method_8321(pos) instanceof MarkBlockEntity blockEntity)) {
            return null;
        }

        class_243 localLocation = location.method_1020(class_243.method_24954(pos));

        double closestDistance = Double.MAX_VALUE;
        @Nullable class_2350 closestDirection = null;

        for (int index : blockEntity.getMarks().getIndices()) {
            class_265 shape = SHAPES[index];

            Optional<class_243> closestPoint = shape.method_33661(localLocation);
            if (closestPoint.isEmpty()) {
                continue;
            }

            double distance = closestPoint.get().method_1025(localLocation);

            if (distance < closestDistance) {
                closestDistance = distance;
                closestDirection = class_2350.method_10143(index);
            }
        }

        return closestDirection != null
              ? new DrawnMark(closestDirection, blockEntity.getMarks().get(closestDirection.method_10146()))
              : null;
    }
}
