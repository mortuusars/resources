package io.github.mortuusars.chalk.world.chalk.symbol;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.chalk.Chalk;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3542;
import net.minecraft.class_5321;
import net.minecraft.class_5381;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7891;
import net.minecraft.class_7995;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.core.*;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import java.util.stream.Stream;

import static io.github.mortuusars.chalk.world.chalk.symbol.MarkSymbol.OrientationBehavior.*;

public record MarkSymbol(class_2960 texture, int rotationOffset, OrientationBehavior orientationBehavior,
                         String group, int groupPriority, Optional<class_2960> requiredAdvancement, boolean supporterOnly) {

    public static final String GROUP_PRIMARY = "primary";
    public static final class_5321<MarkSymbol> ARROW =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("arrow"));
    public static final class_5321<MarkSymbol> DOT =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("dot"));
    public static final class_5321<MarkSymbol> BACK =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("back"));

    public static final String GROUP_SYMBOLS = "symbols";
    public static final class_5321<MarkSymbol> CHECK =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("check"));
    public static final class_5321<MarkSymbol> CROSS =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("cross"));
    public static final class_5321<MarkSymbol> HOUSE =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("house"));
    public static final class_5321<MarkSymbol> HOOK =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("hook"));
    public static final class_5321<MarkSymbol> BOTTLE =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("bottle"));
    public static final class_5321<MarkSymbol> HEART =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("heart"));
    public static final class_5321<MarkSymbol> SKULL =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("skull"));
    public static final class_5321<MarkSymbol> FACE =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("face"));
    public static final class_5321<MarkSymbol> NOTE =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("note"));
    public static final class_5321<MarkSymbol> SUN =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("sun"));
    public static final class_5321<MarkSymbol> MOON =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("moon"));
    public static final class_5321<MarkSymbol> STAR =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("star"));
    public static final class_5321<MarkSymbol> GRASS =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("grass"));

    public static final class_5321<MarkSymbol> CAT =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("cat"));
    public static final class_5321<MarkSymbol> DOG =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("dog"));
    public static final class_5321<MarkSymbol> DINO =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("dino"));
    public static final class_5321<MarkSymbol> CROWN =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("crown"));
    public static final class_5321<MarkSymbol> COIN =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("coin"));
    public static final class_5321<MarkSymbol> GEM =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("gem"));
    public static final class_5321<MarkSymbol> CAKE =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("cake"));
    public static final class_5321<MarkSymbol> LAMBDA =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("lambda"));
    public static final class_5321<MarkSymbol> FLAME =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("flame"));
    public static final class_5321<MarkSymbol> SMIRK =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("smirk"));

    public static final String GROUP_TOOLS = "tools";
    public static final class_5321<MarkSymbol> PICKAXE =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("pickaxe"));
    public static final class_5321<MarkSymbol> AXE =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("axe"));
    public static final class_5321<MarkSymbol> SHOVEL =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("shovel"));
    public static final class_5321<MarkSymbol> SWORD =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("sword"));
    public static final class_5321<MarkSymbol> HOE =
          class_5321.method_29179(Chalk.Registries.MARK_SYMBOL, Chalk.resource("hoe"));

    public static final class_5321<MarkSymbol> DEFAULT = DOT;

    // --

    public static final Codec<MarkSymbol> DIRECT_CODEC = RecordCodecBuilder.create(i -> i.group(
          class_2960.field_25139.fieldOf("texture").forGetter(MarkSymbol::texture),
          Codec.intRange(-180, 180).optionalFieldOf("rotation_offset", 0).forGetter(MarkSymbol::rotationOffset),
          OrientationBehavior.CODEC.optionalFieldOf("orientation_behavior", FULL).forGetter(MarkSymbol::orientationBehavior),
          Codec.STRING.optionalFieldOf("group", "symbols").forGetter(MarkSymbol::group),
          Codec.INT.optionalFieldOf("group_priority", 9999).forGetter(MarkSymbol::groupPriority),
          class_2960.field_25139.optionalFieldOf("required_advancement").forGetter(MarkSymbol::requiredAdvancement),
          Codec.BOOL.optionalFieldOf("supporter_only", false).forGetter(MarkSymbol::supporterOnly)
    ).apply(i, MarkSymbol::new));

    public static final class_9139<class_9129, MarkSymbol> DIRECT_STREAM_CODEC = class_9139.method_56437(
          (buffer, symbol) -> {
              class_2960.field_48267.encode(buffer, symbol.texture());
              class_9135.field_49675.encode(buffer, symbol.rotationOffset());
              OrientationBehavior.STREAM_CODEC.encode(buffer, symbol.orientationBehavior());
              class_9135.field_48554.encode(buffer, symbol.group());
              class_9135.field_49675.encode(buffer, symbol.groupPriority());
              class_9135.method_56382(class_2960.field_48267).encode(buffer, symbol.requiredAdvancement());
              class_9135.field_48547.encode(buffer, symbol.supporterOnly());
          },
          buffer -> new MarkSymbol(
                class_2960.field_48267.decode(buffer),
                class_9135.field_49675.decode(buffer),
                OrientationBehavior.STREAM_CODEC.decode(buffer),
                class_9135.field_48554.decode(buffer),
                class_9135.field_49675.decode(buffer),
                class_9135.method_56382(class_2960.field_48267).decode(buffer),
                class_9135.field_48547.decode(buffer)
          )
    );

    public static final Codec<class_6880<MarkSymbol>> CODEC =
          class_5381.method_29749(Chalk.Registries.MARK_SYMBOL, DIRECT_CODEC);

    public static final class_9139<class_9129, class_6880<MarkSymbol>> STREAM_CODEC =
          class_9135.method_56367(Chalk.Registries.MARK_SYMBOL, DIRECT_STREAM_CODEC);

    // --

    public static Optional<class_6880.class_6883<MarkSymbol>> get(class_5455 registryAccess, class_5321<MarkSymbol> key) {
        return registryAccess.method_30530(Chalk.Registries.MARK_SYMBOL).method_40264(key);
    }

    public static class_6880<MarkSymbol> getOrThrow(class_5455 registryAccess, class_5321<MarkSymbol> key) {
        return registryAccess.method_30530(Chalk.Registries.MARK_SYMBOL).method_40290(key);
    }

    public static class_6880<MarkSymbol> withFallback(class_5455 registryAccess, Optional<class_6880<MarkSymbol>> symbol) {
        class_2378<MarkSymbol> registry = registryAccess.method_30530(Chalk.Registries.MARK_SYMBOL);
        return symbol
              .or(() -> registry.method_40264(DEFAULT))
              .or(registry::method_60385)
              .orElseThrow();
    }

    public static Stream<class_6880<MarkSymbol>> getAllHolders(class_7225.class_7874 lookup, boolean includeSupporterOnly) {
        Stream<class_6880<MarkSymbol>> stream = lookup.method_46762(Chalk.Registries.MARK_SYMBOL)
              .method_42017()
              .map(ref -> ref);
        return includeSupporterOnly
              ? stream
              : stream.filter(symbol -> !symbol.comp_349().supporterOnly());
    }

    // --

    public static void bootstrap(class_7891<MarkSymbol> context) {
        register(context, ARROW, 0, FULL, GROUP_PRIMARY, 10, Optional.empty(), false);
        register(context, DOT, 0, FIXED, GROUP_PRIMARY, 20, Optional.empty(), false);
        register(context, BACK, 0, CARDINAL, GROUP_PRIMARY, 30, adv("chalk:adventure/this_way"), false);
        register(context, CHECK, 45, UP_DOWN_CARDINAL, GROUP_PRIMARY, 40, Optional.empty(), false);
        register(context, CROSS, 45, FIXED, GROUP_PRIMARY, 50, Optional.empty(), false);

        register(context, HOUSE, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 100, adv("chalk:adventure/home_is_where_the_bed_is"), false);
        register(context, HEART, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 110, adv("minecraft:husbandry/tame_an_animal"), false);
        register(context, HOOK, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 120, adv("minecraft:husbandry/fishy_business"), false);
        register(context, BOTTLE, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 130, adv("minecraft:nether/brew_potion"), false);
        register(context, SKULL, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 140, adv("minecraft:adventure/sniper_duel"), false);
        register(context, FACE, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 150, adv("minecraft:adventure/summon_iron_golem"), false);
        register(context, NOTE, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 160, adv("minecraft:adventure/play_jukebox_in_meadows"), false);
        register(context, SUN, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 200, adv("chalk:adventure/consumed_by_the_light"), false);
        register(context, MOON, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 210, adv("chalk:adventure/alone_in_the_darkness"), false);
        register(context, STAR, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 220, adv("chalk:adventure/guiding_star"), false);
        register(context, GRASS, 0, CARDINAL, GROUP_SYMBOLS, 230, adv("chalk:adventure/paint_the_grass"), false);

        register(context, CAT, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 910, Optional.empty(), true);
        register(context, DOG, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 920, Optional.empty(), true);
        register(context, DINO, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 930, Optional.empty(), true);
        register(context, CROWN, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 940, Optional.empty(), true);
        register(context, COIN, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 950, Optional.empty(), true);
        register(context, GEM, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 960, Optional.empty(), true);
        register(context, CAKE, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 980, Optional.empty(), true);
        register(context, LAMBDA, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 990, Optional.empty(), true);
        register(context, FLAME, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 1000, Optional.empty(), true);
        register(context, SMIRK, 0, UP_DOWN_CARDINAL, GROUP_SYMBOLS, 1010, Optional.empty(), true);

        register(context, SWORD, 0, CARDINAL, GROUP_TOOLS, 10, adv("minecraft:story/iron_tools"), false);
        register(context, SHOVEL, 0, CARDINAL, GROUP_TOOLS, 20, adv("minecraft:story/iron_tools"), false);
        register(context, PICKAXE, 0, CARDINAL, GROUP_TOOLS, 30, adv("minecraft:story/iron_tools"), false);
        register(context, AXE, 0, CARDINAL, GROUP_TOOLS, 40, adv("minecraft:story/iron_tools"), false);
        register(context, HOE, 0, CARDINAL, GROUP_TOOLS, 50, adv("minecraft:story/iron_tools"), false);
    }

    static Optional<class_2960> adv(String id) {
        return Optional.of(class_2960.method_60654(id));
    }

    static void register(class_7891<MarkSymbol> context, class_5321<MarkSymbol> key,
                         int rotationOffset, OrientationBehavior behavior, String group, int groupPriority,
                         Optional<class_2960> requiredAdvancement, boolean supporterOnly) {
        class_2960 texture = key.method_29177().method_45138("block/mark/");
        context.method_46838(key, new MarkSymbol(texture, rotationOffset, behavior, group, groupPriority, requiredAdvancement, supporterOnly));
    }

    // --

    public enum OrientationBehavior implements class_3542 {
        FIXED("fixed"),
        FULL("full"),
        CARDINAL("cardinal"),
        UP_DOWN_CARDINAL("up_down_cardinal");

        public static final Codec<OrientationBehavior> CODEC = class_3542.method_28140(OrientationBehavior::values);
        public static final class_9139<ByteBuf, OrientationBehavior> STREAM_CODEC = class_9135.method_56375(
              class_7995.method_47914(OrientationBehavior::ordinal, values(), class_7995.class_7996.field_41665), OrientationBehavior::ordinal);

        private final String name;

        OrientationBehavior(String name) {
            this.name = name;
        }

        @Override
        public @NotNull String method_15434() {
            return name;
        }
    }
}

