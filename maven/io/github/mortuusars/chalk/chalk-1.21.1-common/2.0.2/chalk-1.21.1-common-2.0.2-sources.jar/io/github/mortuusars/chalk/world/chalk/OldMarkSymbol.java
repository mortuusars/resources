package io.github.mortuusars.chalk.world.chalk;

import com.mojang.serialization.Codec;
import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.world.chalk.symbol.MarkSymbol;
import io.github.mortuusars.chalk.world.chalk.symbol.SymbolOrientation;
import io.netty.buffer.ByteBuf;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.List;
import java.util.function.IntFunction;
import java.util.stream.Collectors;
import net.minecraft.class_2960;
import net.minecraft.class_3542;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7995;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

@Deprecated(since = "2.0.0", forRemoval = true)
public enum OldMarkSymbol implements class_3542 {
    CENTER("center", false, OrientationBehavior.FIXED, SymbolOrientation.NORTH),
    ARROW("arrow", false, OrientationBehavior.FULL, SymbolOrientation.NORTH),
    CROSS("cross", true, OrientationBehavior.FIXED, SymbolOrientation.NORTH),
    CHECKMARK("check", true, OrientationBehavior.UP_DOWN_CARDINAL, SymbolOrientation.NORTH),
    SKULL("skull", true, OrientationBehavior.UP_DOWN_CARDINAL, SymbolOrientation.NORTH),
    HOUSE("house", true, OrientationBehavior.UP_DOWN_CARDINAL, SymbolOrientation.NORTH),
    HEART("heart", true, OrientationBehavior.UP_DOWN_CARDINAL, SymbolOrientation.NORTH),
    PICKAXE("pickaxe", true, OrientationBehavior.UP_DOWN_CARDINAL, SymbolOrientation.NORTH),;

    public static final Codec<OldMarkSymbol> CODEC = class_3542.method_28140(OldMarkSymbol::values);
    public static final IntFunction<OldMarkSymbol> BY_ID = class_7995.method_47914(OldMarkSymbol::ordinal, values(), class_7995.class_7996.field_41665);
    public static final class_9139<ByteBuf, OldMarkSymbol> STREAM_CODEC = class_9135.method_56375(BY_ID, OldMarkSymbol::ordinal);

    private final String name;
    private final class_2960 textureLocation;
    private final boolean isSpecial;
    private final OrientationBehavior orientationBehavior;
    private final SymbolOrientation defaultOrientation;

    OldMarkSymbol(String name, boolean isSpecial, OrientationBehavior orientationBehavior, SymbolOrientation defaultOrientation) {
        this.name = name;
        this.textureLocation = Chalk.resource("block/mark/" + name);
        this.isSpecial = isSpecial;
        this.orientationBehavior = orientationBehavior;
        this.defaultOrientation = defaultOrientation;
    }

    public static List<OldMarkSymbol> getSpecialSymbols() {
        return Arrays.stream(values()).filter(s -> s.isSpecial).collect(Collectors.toList());
    }

    public static OldMarkSymbol byNameOrDefault(String name) {
        for (OldMarkSymbol symbol : values()) {
            if (symbol.name.equals(name))
                return symbol;
        }

        return CENTER;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }

    public class_2960 getTextureLocation() {
        return textureLocation;
    }

    public boolean isSpecial() {
        return isSpecial;
    }

    public OrientationBehavior getOrientationBehavior() {
        return orientationBehavior;
    }

    public SymbolOrientation getDefaultOrientation() {
        return defaultOrientation;
    }

    public String getTranslationKey() {
        return "gui." + Chalk.ID + ".symbol." + name;
    }

    public enum OrientationBehavior implements class_3542 {
        FIXED("fixed"),
        FULL("full"),
        CARDINAL("cardinal"),
        UP_DOWN_CARDINAL("up_down_cardinal");

        private final String name;

        OrientationBehavior(String name) {
            this.name = name;
        }

        @Override
        public @NotNull String method_15434() {
            return name;
        }
    }
    
    // --
    
    public class_6880<MarkSymbol> convert(class_7225.class_7874 registries) {
        var registry = registries.method_46762(Chalk.Registries.MARK_SYMBOL);

        class_5321<MarkSymbol> key = switch (this) {
            case CENTER -> MarkSymbol.DOT;
            case ARROW -> MarkSymbol.ARROW;
            case CROSS -> MarkSymbol.CROSS;
            case CHECKMARK -> MarkSymbol.CHECK;
            case SKULL -> MarkSymbol.SKULL;
            case HOUSE -> MarkSymbol.HOUSE;
            case HEART -> MarkSymbol.HEART;
            case PICKAXE -> MarkSymbol.PICKAXE;
        };

        return registry.method_46746(key).orElse(registry.method_46747(MarkSymbol.DOT));
    }
}
