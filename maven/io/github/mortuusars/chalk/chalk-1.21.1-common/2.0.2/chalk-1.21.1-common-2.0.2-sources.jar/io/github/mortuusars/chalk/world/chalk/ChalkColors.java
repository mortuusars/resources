package io.github.mortuusars.chalk.world.chalk;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1767;

public class ChalkColors {
    public static final List<class_1767> ORDERED_DYE_COLORS = List.of(
          class_1767.field_7952,
          class_1767.field_7967,
          class_1767.field_7944,
          class_1767.field_7963,
          class_1767.field_7957,
          class_1767.field_7964,
          class_1767.field_7946,
          class_1767.field_7947,
          class_1767.field_7961,
          class_1767.field_7942,
          class_1767.field_7955,
          class_1767.field_7951,
          class_1767.field_7966,
          class_1767.field_7945,
          class_1767.field_7958,
          class_1767.field_7954
    );

    @Deprecated(since = "2.0.0", forRemoval = true)
    public static final Map<class_1767, Integer> COLORS = new LinkedHashMap<>() {{ // LinkedHasMap keeps order
        put(class_1767.field_7952, 0xFFFFFF);
        put(class_1767.field_7967, 0xADADA8);
        put(class_1767.field_7944, 0x606466);
        put(class_1767.field_7963, 0x252525);
        put(class_1767.field_7957, 0x8A522A);
        put(class_1767.field_7964, 0xEB4A39);
        put(class_1767.field_7946, 0xFF8034);
        put(class_1767.field_7947, 0xFFD929);
        put(class_1767.field_7961, 0x9AE437);
        put(class_1767.field_7942, 0x51A80B);
        put(class_1767.field_7955, 0x1DCAC0);
        put(class_1767.field_7951, 0x82DBF8);
        put(class_1767.field_7966, 0x3B50D2);
        put(class_1767.field_7945, 0xA74CD2);
        put(class_1767.field_7958, 0xED60E2);
        put(class_1767.field_7954, 0xEE658E);
    }};

    public static int fromDyeColor(class_1767 color) {
        return COLORS.get(color);
    }
}
