package io.github.mortuusars.chalk.advancements.trigger;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.chalk.advancements.PlayerSleepInfo;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_2025;
import net.minecraft.class_2048;
import net.minecraft.class_2090;
import net.minecraft.class_2096;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;

public class ConsecutiveSleepingTrigger extends class_4558<ConsecutiveSleepingTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player, PlayerSleepInfo sleepInfo) {
        this.method_22510(player, triggerInstance -> triggerInstance.matches(player, sleepInfo));
    }

    public record TriggerInstance(Optional<class_5258> player, Optional<class_2090> location,
                                  class_2096.class_2100 count, class_2025 distance) implements class_4558.class_8788 {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance ->
                instance.group(
                                class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::comp_2029),
                                class_2090.field_45760.optionalFieldOf("location").forGetter(TriggerInstance::location),
                                class_2096.class_2100.field_45763.fieldOf("count").forGetter(TriggerInstance::count),
                                class_2025.field_45728.fieldOf("distance").forGetter(TriggerInstance::distance))
                        .apply(instance, TriggerInstance::new));

        public boolean matches(class_3222 player, PlayerSleepInfo sleepInfo) {
            boolean locationMatches = this.location.map(p ->
                    p.method_9018(player.method_51469(), player.method_23317(), player.method_23318(), player.method_23321())).orElse(true);
            if (!locationMatches) {
                return false;
            }

            List<class_2338> sleepPositions = sleepInfo.sleepPositions();

            if (sleepPositions.isEmpty())
                return false;
            else if (sleepPositions.size() == 1)
                return count.method_9054(1);

            class_2338 lastSleepPos = sleepPositions.getLast();

            int matchedDistanceCount = 1;

            for (int i = sleepPositions.size() - 2; i >= 0; i--) {
                class_2338 pos = sleepPositions.get(i);

                if (distance.method_8859(lastSleepPos.method_10263(), lastSleepPos.method_10264(), lastSleepPos.method_10260(),
                        pos.method_10263(), pos.method_10264(), pos.method_10260()))
                    matchedDistanceCount++;
                else
                    break;
            }

            return count.method_9054(matchedDistanceCount);
        }
    }
}
