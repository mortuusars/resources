package io.github.mortuusars.chalk.mixin.single_mark_outline;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.mortuusars.chalk.world.block.MarkBlock;
import io.github.mortuusars.chalk.world.chalk.DrawnMark;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_761.class)
public abstract class LevelRendererMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @WrapOperation(method = "renderHitOutline", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getShape(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/phys/shapes/CollisionContext;)Lnet/minecraft/world/phys/shapes/VoxelShape;"))
    private class_265 onRenderHitOutline(class_2680 instance, class_1922 blockGetter, class_2338 pos,
                                          class_3726 collisionContext, Operation<class_265> original) {
        if (instance.method_26204() instanceof MarkBlock
              && minecraft.field_1765 instanceof class_3965 hitResult
              && MarkBlock.getMarkAt(blockGetter, hitResult.method_17784()) instanceof DrawnMark mark) {
            return MarkBlock.SHAPES[mark.facing().method_10146()];
        }

        return original.call(instance, blockGetter, pos, collisionContext);
    }
}
