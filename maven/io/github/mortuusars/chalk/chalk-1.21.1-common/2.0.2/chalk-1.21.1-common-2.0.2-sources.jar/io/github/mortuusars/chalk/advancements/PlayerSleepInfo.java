package io.github.mortuusars.chalk.advancements;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.chalk.Chalk;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2338;
import net.minecraft.class_3518;

public record PlayerSleepInfo(List<class_2338> sleepPositions) {
    public static final Codec<PlayerSleepInfo> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.list(class_2338.field_25064).optionalFieldOf("sleep_positions", Collections.emptyList()).forGetter(PlayerSleepInfo::sleepPositions))
        .apply(instance, PlayerSleepInfo::new));

    public static PlayerSleepInfo deserialize(String serialized) {
        JsonObject json = class_3518.method_15285(serialized);
        return CODEC.decode(JsonOps.INSTANCE, json)
                .resultOrPartial(s ->
                        Chalk.LOGGER.error("Failed to deserialize PlayerSleepInfo: {}\nInput: <{}>", s, serialized))
                .orElse(Pair.of(new PlayerSleepInfo(Collections.emptyList()), null)).getFirst();
    }

    public String serialize() {
        Optional<JsonElement> encodedElement = CODEC.encodeStart(JsonOps.INSTANCE, this)
                .resultOrPartial(s -> Chalk.LOGGER.error("Failed to serialize PlayerSleepInfo: {}\nInput: <{}>", s, this.toString()));
        if (encodedElement.isEmpty())
            return "";

        return encodedElement.get().toString();
    }
}
