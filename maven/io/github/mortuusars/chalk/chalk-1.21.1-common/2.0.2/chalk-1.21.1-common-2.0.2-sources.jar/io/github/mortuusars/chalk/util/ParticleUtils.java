package io.github.mortuusars.chalk.util;

import net.minecraft.class_1937;
import net.minecraft.class_2394;
import org.joml.Vector3f;

public class ParticleUtils {
    /**
     * Spawns a particle with slight random offset to each. Includes velocity.
     */
    public static void spawnParticle(class_1937 level, class_2394 particleType, Vector3f position, Vector3f velocity, int count){
        if (!level.method_8608() || count < 1)
            return;

        for (int i=0; i < count; i++ ){
            level.method_8406(particleType,
                    position.x() + ((level.method_8409().method_43057() - 0.5f) * 0.3),
                    position.y() + ((level.method_8409().method_43057() - 0.5f) * 0.3),
                    position.z() + ((level.method_8409().method_43057() - 0.5f) * 0.3),
                    velocity.x(),
                    velocity.y(),
                    velocity.z());
        }
    }
}
