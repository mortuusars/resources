package io.github.mortuusars.chalk.world.item;

import io.github.mortuusars.chalk.Chalk;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_9282;
import net.minecraft.class_9334;

@Deprecated(since = "2.0.0", forRemoval = true)
public class OldChalkItem extends class_1792 {
    private final class_1767 color;

    public OldChalkItem(class_1767 color, class_1793 properties) {
        super(properties);
        this.color = color;
    }

    public class_1767 getColor() {
        return this.color;
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> lines, class_1836 tooltipFlag) {
        lines.add(class_2561.method_43471("item.chalk.chalk.tooltip.deprecated").method_27692(class_124.field_1079));
        lines.add(class_2561.method_43471("item.chalk.chalk.tooltip.deprecated_use_to_convert").method_27692(class_124.field_1079));
    }

    // --

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        class_1799 convertedStack = convert(stack);
        player.method_6122(hand ,convertedStack);
        player.method_43077(Chalk.SoundEvents.MARK_REMOVED.get());
        return class_1271.method_22427(convertedStack);
    }

    public @NotNull class_1799 convert(class_1799 stack) {
        class_1799 convertedStack = stack.method_60503(Chalk.Items.CHALK.get());
        if (getColor() != class_1767.field_7952) {
            class_9282 dyedColor = new class_9282(Chalk.Items.CHALK.get().getColorFromDye(convertedStack, getColor()), true);
            convertedStack.method_57379(class_9334.field_49644, dyedColor);
        }
        return convertedStack;
    }
}
