package io.github.mortuusars.chalk.world.block;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.chalk.Chalk;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.slf4j.Logger;

/*
Dummy block entity to be able to tick a block and convert the old mark.
 */
@SuppressWarnings("removal")
@Deprecated(since = "2.0.0", forRemoval = true)
public class OldMarkBlockEntity extends class_2586 {
    public static final Logger LOGGER = LogUtils.getLogger();

    public OldMarkBlockEntity(class_2338 pos, class_2680 blockState) {
        super(Chalk.BlockEntityTypes.CHALK_MARK.get(), pos, blockState);
    }
}
