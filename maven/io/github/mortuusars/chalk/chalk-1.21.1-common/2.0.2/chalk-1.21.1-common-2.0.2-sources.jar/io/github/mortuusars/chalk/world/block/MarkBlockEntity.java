package io.github.mortuusars.chalk.world.block;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.world.chalk.MarkSet;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class MarkBlockEntity extends class_2586 {
    public static final Logger LOGGER = LogUtils.getLogger();

    protected MarkSet marks = new MarkSet();

    protected MarkBlockEntity(class_2591<?> type, class_2338 pos, class_2680 blockState) {
        super(type, pos, blockState);
    }

    public MarkBlockEntity(class_2338 pos, class_2680 blockState) {
        super(Chalk.BlockEntityTypes.MARK.get(), pos, blockState);
    }

    public MarkSet getMarks() {
        return marks;
    }

    public void marksChanged() {
        if (method_11010().method_26204() instanceof MarkBlock markBlock) {
            assert method_10997() != null;
            markBlock.recheckAndUpdate(method_10997(), method_11016());
        }
        method_5431();
        if (field_11863 != null) {
            // Forces client to update
            field_11863.method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31036);
        }
    }

    @Override
    public @Nullable class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public @NotNull class_2487 method_16887(class_7225.class_7874 registries) {
        class_2487 tag = new class_2487();
        method_11007(tag, registries);
        return tag;
    }

    // --

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        MarkSet.CODEC
              .encodeStart(registries.method_57093(class_2509.field_11560), marks)
              .resultOrPartial(LOGGER::error)
              .ifPresent(result -> tag.method_10566("Marks", result));
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        if (tag.method_10545("Marks")) {
            MarkSet.CODEC.decode(registries.method_57093(class_2509.field_11560), tag.method_10580("Marks"))
                  .resultOrPartial(LOGGER::error)
                  .ifPresent(result -> {
                      marks = result.getFirst();
                      if (field_11863 != null && field_11863.field_9236) {
                          // Updates model on the client
                          field_11863.method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31028);
                      }
                  });
        }
    }
}
