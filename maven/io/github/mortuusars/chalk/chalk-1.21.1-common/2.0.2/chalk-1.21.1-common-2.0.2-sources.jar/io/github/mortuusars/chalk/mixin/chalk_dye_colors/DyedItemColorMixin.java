package io.github.mortuusars.chalk.mixin.chalk_dye_colors;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.chalk.world.item.ChalkItem;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_9282;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_9282.class)
public class DyedItemColorMixin {
    @WrapOperation(method = "applyDyes", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/DyeColor;getTextureDiffuseColor()I"))
    private static int onApplyDyes(class_1767 instance, Operation<Integer> original, @Local(argsOnly = true) class_1799 stack) {
        if (stack.method_7909() instanceof ChalkItem chalkItem) {
            return chalkItem.getColorFromDye(stack, instance);
        }
        return original.call(instance);
    }
}
