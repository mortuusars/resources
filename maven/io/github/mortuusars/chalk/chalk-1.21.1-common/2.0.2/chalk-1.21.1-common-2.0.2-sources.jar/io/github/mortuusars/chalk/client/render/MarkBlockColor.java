package io.github.mortuusars.chalk.client.render;

import io.github.mortuusars.chalk.world.block.MarkBlockEntity;
import io.github.mortuusars.chalk.world.chalk.Mark;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_322;
import org.jetbrains.annotations.Nullable;

public class MarkBlockColor implements class_322 {
    @Override
    public int getColor(class_2680 blockState, @Nullable class_1920 blockAndTintGetter, @Nullable class_2338 pos, int index) {
        if (blockAndTintGetter != null && blockAndTintGetter.method_8321(pos) instanceof MarkBlockEntity blockEntity) {
            @Nullable Mark mark = blockEntity.getMarks().get(index);
            if (mark != null) {
                return mark.color();
            }
        }

        return 0xFFFFFFFF;
    }
}
