package io.github.mortuusars.chalk.world.item;

import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.Config;
import io.github.mortuusars.chalk.world.chalk.Mark;
import io.github.mortuusars.chalk.world.chalk.MarkDrawingContext;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5253;
import net.minecraft.class_9282;
import net.minecraft.class_9334;

public class ChalkItem extends class_1792 implements MarkDrawable {
    public ChalkItem(class_1793 properties) {
        super(properties);
    }

    public int getColorFromDye(class_1799 stack, class_1767 dye) {
        return getColorFromDye(dye);
    }

    @Override
    public int getMarkDrawingColor(class_1799 stack) {
        return class_9282.method_57470(stack, 0xFFFFFF);
    }

    public int getTintColor(class_1799 stack, int index) {
        return class_5253.class_5254.method_57174(getMarkDrawingColor(stack));
    }

    @Override
    public @NotNull String method_7866(class_1799 stack) {
        if (Config.Server.DYED_CHALK_NAMES.get()) {
            if (!(stack.method_57824(class_9334.field_49644) instanceof class_9282 dyedColor)) {
                return "item.chalk.white_chalk";
            }

            if (Config.Server.CHALK_COLORS.inverse().get(dyedColor.comp_2384()) instanceof class_1767 dyeColor) {
                return "item.chalk." + dyeColor.method_7792() + "_chalk";
            }
        }

        return super.method_7866(stack);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        if (!stack.method_57826(class_9334.field_49644)) {
            tooltipComponents.add(class_2561.method_43471("item.chalk.chalk.tooltip.dyeable").method_27692(class_124.field_1080));
        }
    }

    // --

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_1799 stack = context.method_8041();
        class_1657 player = context.method_8036();

        if (player == null) {
            return class_1269.field_5814;
        }

        MarkDrawingContext drawingContext = createMarkDrawingContext(player, context.method_20287(),
              context.method_17698(), context.method_8037(), context.method_8038());

        if (!canDrawMark(player, drawingContext)) {
            return class_1269.field_5814;
        }

        if (player.method_21823()) {
            selectSymbolAndDraw(player, drawingContext);
            return class_1269.field_21466;
        }

        if (drawMark(player, drawingContext, createRegularMark(player, drawingContext, stack))) {
            return class_1269.method_29236(context.method_8045().method_8608());
        }

        return class_1269.field_5814;
    }

    // -- Drawable

    @Override
    public void onMarkDrawn(class_1657 player, MarkDrawingContext context, Mark mark) {
        MarkDrawable.super.onMarkDrawn(player, context, mark);
        class_1799 stack = player.method_5998(context.hand());
        onChalkMarkDrawn(player, context.hand(), stack, context.markPos(), context.markFacing(), mark);
        if (!player.method_7337()) {
            stack.method_7970(1, player, class_1309.method_56079(context.hand()));
        }
    }

    public void onChalkMarkDrawn(class_1657 player, class_1268 hand, class_1799 stack, class_2338 markPos, class_2350 markFacing, Mark mark) {
        if (player instanceof class_3222 serverPlayer) {
            Chalk.CriteriaTriggers.MARK_DRAWN.get().trigger(serverPlayer, stack, markPos, mark, markPos.method_10093(markFacing.method_10153()));
        }
    }

    // --

    public static int getColorFromDye(class_1767 dye) {
        return Config.Server.CHALK_COLORS.getOrDefault(dye, dye.method_7787());
    }

    public static class_1799 create(int color, int damage) {
        class_1799 stack = new class_1799(Chalk.Items.CHALK.get());
        if (color != 0xFFFFFF) stack.method_57379(class_9334.field_49644, new class_9282(color, true));
        if (damage > 0) stack.method_7974(damage);
        return stack;
    }
}
