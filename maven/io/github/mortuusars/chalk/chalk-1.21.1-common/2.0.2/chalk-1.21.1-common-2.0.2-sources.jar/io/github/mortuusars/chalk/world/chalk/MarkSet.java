package io.github.mortuusars.chalk.world.chalk;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.stream.IntStream;
import net.minecraft.class_2350;
import net.minecraft.class_3542;

public class MarkSet {
    public static final Codec<MarkSet> CODEC = Codec.simpleMap(class_2350.field_29502, Mark.CODEC, class_3542.method_28142(class_2350.values())).codec()
          .xmap(map -> {
              Mark[] marks = new Mark[6];
              for (class_2350 direction : class_2350.values()) {
                  marks[direction.method_10146()] = map.get(direction);
              }
              return new MarkSet(marks);
          }, set -> {
              Map<class_2350, Mark> map = new HashMap<>();

              for (class_2350 direction : class_2350.values()) {
                  @Nullable Mark mark = set.get(direction);
                  if (mark != null) {
                      map.put(direction, mark);
                  }
              }

              return map;
          });

    private final Mark[] marks;
    private int mask;

    public MarkSet(Mark[] marks) {
        Preconditions.checkState(marks.length == 6, "MarkSet should always have 6 marks.");
        this.marks = marks;
        mask = 0;
        for (int i = 0; i < 6; i++) {
            if (marks[i] != null) {
                mask |= 1 << i;
            }
        }
    }

    public MarkSet() {
        this(new Mark[6]);
    }

    public @Nullable Mark get(class_2350 face) {
        return marks[face.method_10146()];
    }

    public @Nullable Mark get(int index) {
        if (index < 0 || index >= 6) return null;
        return marks[index];
    }

    public void set(class_2350 face, @NotNull Mark mark) {
        marks[face.method_10146()] = mark;
        mask |= 1 << face.method_10146();
    }

    public void remove(class_2350 face) {
        marks[face.method_10146()] = null;
        mask &= ~(1 << face.method_10146());
    }

    public int[] getIndices() {
        return IntStream.range(0, marks.length)
              .filter(i -> marks[i] != null)
              .toArray();
    }

    public int getMask() {
        return mask;
    }

    public boolean isEmpty() {
        return mask == 0;
    }

    public int getCount() {
        int count = 0;
        for (Mark mark : marks) {
            if (mark != null) {
                count++;
            }
        }
        return count;
    }

    public void forEach(BiConsumer<class_2350, Mark> consumer) {
        for (int i = 0; i < 6; i++) {
            @Nullable Mark mark = marks[i];
            if (mark != null) {
                consumer.accept(class_2350.method_10143(i), mark);
            }
        }
    }

    public Mark[] copyArray() {
        return marks.clone();
    }
}