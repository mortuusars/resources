package io.github.mortuusars.chalk.world.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.world.chalk.OldMarkSymbol;
import io.github.mortuusars.chalk.world.chalk.Mark;
import io.github.mortuusars.chalk.world.chalk.symbol.SymbolOrientation;
import io.github.mortuusars.chalk.world.item.ChalkItem;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("removal")
@Deprecated(since = "2.0.0", forRemoval = true)
public class OldChalkMarkBlock extends class_2237 {
    public static final MapCodec<OldChalkMarkBlock> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
          class_1767.field_41600.fieldOf("color").forGetter(OldChalkMarkBlock::getColor),
          method_54096()
    ).apply(i, OldChalkMarkBlock::new));

    public static final class_2753 FACING = class_2741.field_12525;
    public static final class_2754<OldMarkSymbol> SYMBOL = class_2754.method_11850("symbol", OldMarkSymbol.class);
    public static final class_2754<SymbolOrientation> ORIENTATION = class_2754.method_11850("orientation", SymbolOrientation.class);
    public static final class_2746 GLOWING = class_2746.method_11825("glowing");

    private final class_1767 color;

    public OldChalkMarkBlock(class_1767 dyeColor, class_2251 properties) {
        super(properties);
        this.method_9590(this.method_9595().method_11664()
              .method_11657(FACING, class_2350.field_11043)
              .method_11657(SYMBOL, OldMarkSymbol.CENTER)
              .method_11657(ORIENTATION, SymbolOrientation.NORTH)
              .method_11657(GLOWING, false));
        color = dyeColor;
    }

    public class_1767 getColor() {
        return color;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING).method_11667(ORIENTATION).method_11667(GLOWING).method_11667(SYMBOL);
    }

    @Override
    protected @NotNull MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new OldMarkBlockEntity(pos, state);
    }

    @Override
    public @Nullable <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> blockEntityType) {
        return !level.method_8608()
              ? method_31618(blockEntityType, Chalk.BlockEntityTypes.CHALK_MARK.get(), OldChalkMarkBlock::convertMark)
              : null;
    }

    @Override
    protected void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 neighborBlock, class_2338 neighborPos, boolean movedByPiston) {
        convertMark(level, pos, state);
    }

    @Override
    protected @NotNull class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
        if (level instanceof class_3218 serverLevel) {
            convertMark(serverLevel, pos, state);
        }
        return class_1269.field_51370;
    }

    @Override
    protected void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        convertMark(level, pos, state);
    }

    public static void convertMark(class_1937 level, class_2338 pos, class_2680 state, OldMarkBlockEntity ignored) {
        convertMark(level, pos, state);
    }

    public static void convertMark(class_1937 level, class_2338 pos, class_2680 state) {
        try {
            if (!level.method_8608() && MarkBlock.getExistingOrPlaceNew(level, pos) instanceof MarkBlockEntity blockEntity) {
                Mark mark = new Mark(
                      state.method_11654(SYMBOL).convert(level.method_30349()),
                      ChalkItem.getColorFromDye(((OldChalkMarkBlock) state.method_26204()).getColor()),
                      state.method_11654(ORIENTATION),
                      state.method_11654(GLOWING)
                );
                blockEntity.getMarks().set(state.method_11654(FACING), mark);
                blockEntity.marksChanged();
                return;
            }
        } catch (Exception e) {
            Chalk.LOGGER.error("Failed to convert old chalk mark. Block will be removed.", e);
        }

        level.method_8650(pos, false);
    }
}