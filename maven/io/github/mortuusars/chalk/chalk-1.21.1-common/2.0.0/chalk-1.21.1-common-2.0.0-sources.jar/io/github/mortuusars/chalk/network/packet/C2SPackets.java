package io.github.mortuusars.chalk.network.packet;

import io.github.mortuusars.chalk.network.packet.serverbound.DestroyMarkC2SP;
import io.github.mortuusars.chalk.network.packet.serverbound.DrawMarkC2SP;
import io.github.mortuusars.chalk.network.packet.serverbound.OpenCreativeChalkBoxC2SP;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class C2SPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
                 new class_8710.class_9155<>(DrawMarkC2SP.TYPE, DrawMarkC2SP.STREAM_CODEC),
                 new class_8710.class_9155<>(DestroyMarkC2SP.TYPE, DestroyMarkC2SP.STREAM_CODEC),
                 new class_8710.class_9155<>(OpenCreativeChalkBoxC2SP.TYPE, OpenCreativeChalkBoxC2SP.STREAM_CODEC)
        );
    }
}