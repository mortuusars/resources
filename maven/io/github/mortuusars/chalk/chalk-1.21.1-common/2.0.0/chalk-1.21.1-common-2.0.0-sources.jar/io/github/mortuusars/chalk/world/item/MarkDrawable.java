package io.github.mortuusars.chalk.world.item;

import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.Config;
import io.github.mortuusars.chalk.advancements.AdvancementUtils;
import io.github.mortuusars.chalk.network.Packets;
import io.github.mortuusars.chalk.network.packet.clientbound.SelectSymbolAndDrawMarkS2CP;
import io.github.mortuusars.chalk.util.GridCell;
import io.github.mortuusars.chalk.util.PositionUtils;
import io.github.mortuusars.chalk.world.block.MarkBlock;
import io.github.mortuusars.chalk.world.block.MarkBlockEntity;
import io.github.mortuusars.chalk.world.chalk.DrawnMark;
import io.github.mortuusars.chalk.world.chalk.Mark;
import io.github.mortuusars.chalk.world.chalk.MarkDrawingContext;
import io.github.mortuusars.chalk.world.chalk.symbol.MarkSymbol;
import io.github.mortuusars.chalk.world.chalk.symbol.SymbolOrientation;
import io.github.mortuusars.chalk.world.item.component.ChalkBoxContents;
import io.github.mortuusars.mortaar.util.supporter.Supporter;
import io.github.mortuusars.mortaar.util.supporter.Supporters;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_6880;

public interface MarkDrawable {
    int getMarkDrawingColor(class_1799 stack);

    default boolean shouldDrawGlowingMark(class_1799 stack) {
        return false;
    }

    default MarkDrawingContext createMarkDrawingContext(class_1657 player, class_1268 hand, class_243 clickedLocation,
                                                        class_2338 clickedPos, class_2350 clickedFace) {
        class_2338 markPos = clickedPos;
        class_2350 markFacing = clickedFace;

        if (player.method_37908().method_8320(clickedPos).method_26204() instanceof MarkBlock
              && MarkBlock.getMarkAt(player.method_37908(), clickedLocation) instanceof DrawnMark existingMark) {
            markFacing = existingMark.facing();
        } else {
            markPos = clickedPos.method_10093(clickedFace);
        }

        return new MarkDrawingContext(hand, clickedLocation, markPos, markFacing);
    }

    default Mark createRegularMark(class_1657 player, MarkDrawingContext context, class_1799 stack) {
        class_6880<MarkSymbol> symbol = context.clickedCell() == GridCell.CENTER
              ? MarkSymbol.getOrThrow(player.method_37908().method_30349(), MarkSymbol.DOT)
              : MarkSymbol.getOrThrow(player.method_37908().method_30349(), MarkSymbol.ARROW);
        return createMark(player, context, stack, symbol);
    }

    default Mark createMark(class_1657 player, MarkDrawingContext context, class_1799 stack, class_6880<MarkSymbol> symbol) {
        class_2350 facing = context.markFacing();
        GridCell clickedCell = context.clickedCell();

        MarkSymbol.OrientationBehavior orientationBehavior = symbol.comp_349().orientationBehavior();

        SymbolOrientation orientation = switch (orientationBehavior) {
            case FULL -> SymbolOrientation.fromCell(clickedCell);
            case CARDINAL -> SymbolOrientation.fromClickLocationCardinal(context.clickLocation(), facing);
            case UP_DOWN_CARDINAL -> {
                if (facing != class_2350.field_11036 && facing != class_2350.field_11033) {
                    yield SymbolOrientation.CENTER;
                }

                class_2350 direction = player.method_5735();
                if (facing == class_2350.field_11036) {
                    direction = direction.method_10153();
                }

                yield SymbolOrientation.fromRotation(direction.method_10161() * 90);
            }
            case FIXED -> SymbolOrientation.CENTER;
        };

        return new Mark(symbol, getMarkDrawingColor(stack), orientation, shouldDrawGlowingMark(stack));
    }

    default void selectSymbolAndDraw(class_1657 player, MarkDrawingContext context) {
        if (player instanceof class_3222 serverPlayer) {
            List<class_6880<MarkSymbol>> availableSymbols = MarkSymbol.getAllHolders(
                        serverPlayer.method_56673(), Supporters.isEligibleForGoldenRewards(player.method_5667()))
                  .filter(holder -> isSymbolAvailable(serverPlayer, context, holder))
                  .toList();

            Packets.sendToClient(new SelectSymbolAndDrawMarkS2CP(availableSymbols, context), serverPlayer);
        }
    }

    default boolean isSymbolAvailable(class_3222 player, MarkDrawingContext context, class_6880<MarkSymbol> symbol) {
        return player.method_7337()
              || !Config.Server.SYMBOL_UNLOCKING.get()
              || symbol.comp_349().requiredAdvancement()
              .map(advancement -> AdvancementUtils.hasAdvancement(player, advancement))
              .orElse(true);
    }

    default boolean canDrawMark(class_1657 player, MarkDrawingContext context) {
        class_2680 markPosState = player.method_37908().method_8320(context.markPos());
        if (!markPosState.method_26215() && !(markPosState.method_26204() instanceof MarkBlock)) {
            return false;
        }

        class_2338 surfacePos = context.surfacePos();
        class_2680 surfaceBlockState = player.method_37908().method_8320(surfacePos);

        return class_2248.method_9501(surfaceBlockState.method_26220(player.method_37908(), surfacePos), context.markFacing())
              && !surfaceBlockState.method_26164(Chalk.Tags.Blocks.CHALK_CANNOT_DRAW_ON);
    }

    default @Nullable Mark getExistingMark(class_1937 level, MarkDrawingContext context) {
        return level.method_8321(context.markPos()) instanceof MarkBlockEntity blockEntity
              ? blockEntity.getMarks().get(context.markFacing())
              : null;
    }

    default boolean shouldMarkReplaceAnother(Mark oldMark, Mark newMark) {
        if (!newMark.symbol().equals(oldMark.symbol())) return true;
        if (newMark.orientation() != oldMark.orientation()) return true;
        if (newMark.color() != oldMark.color()) return true;
        return newMark.glowing() && !oldMark.glowing();
    }

    default boolean drawMark(class_1657 player, MarkDrawingContext context, Mark mark) {
        if (getExistingMark(player.method_37908(), context) instanceof Mark existingMark
              && !shouldMarkReplaceAnother(existingMark, mark)) {
            return false;
        }

        if (placeMark(player.method_37908(), context.markPos(), context.markFacing(), mark) instanceof Mark drawnMark) {
            onMarkDrawn(player, context, drawnMark);
            player.method_6104(context.hand());
            return true;
        }

        return false;
    }

    default @Nullable Mark placeMark(class_1937 level, class_2338 markPos, class_2350 markFacing, Mark mark) {
        if (!(MarkBlock.getExistingOrPlaceNew(level, markPos) instanceof MarkBlockEntity blockEntity)) {
            return null;
        }

        @Nullable Mark existingMark = blockEntity.getMarks().get(markFacing);
        if (existingMark != null) {
            mark = calculateNewMark(level, existingMark, mark);
        }

        blockEntity.getMarks().set(markFacing, mark);
        blockEntity.marksChanged();
        return mark;
    }

    default Mark calculateNewMark(class_1937 level, Mark oldMark, Mark newMark) {
        if (oldMark.isSameMarkDifferentColors(newMark)) {
            return newMark
                  .lerpColor(oldMark.color(), 0.5f)
                  .withGlowing(oldMark.glowing() || newMark.glowing());
        }
        return newMark;
    }

    default void onMarkDrawn(class_1657 player, MarkDrawingContext context, Mark mark) {
        if (player instanceof class_3222 serverPlayer) {
            float R = (mark.color() & 0x00FF0000) >> 16;
            float G = (mark.color() & 0x0000FF00) >> 8;
            float B = (mark.color() & 0x000000FF);

            Vector3f pos = PositionUtils.blockCenterOffsetToFace(context.markPos(), context.markFacing(), 0.25f);

            serverPlayer.method_51469().method_14199(new class_2390(new Vector3f(R / 255, G / 255, B / 255), 2f),
                  pos.x(), pos.y(), pos.z(), 1, 0, 0, 0, 0);
            serverPlayer.method_51469().method_43128(null, pos.x(), pos.y(), pos.z(), Chalk.SoundEvents.MARK_DRAWN.get(),
                  class_3419.field_15245, 0.7f, serverPlayer.method_59922().method_43057() * 0.2f + 0.8f);

            if (mark.glowing()) {
                serverPlayer.method_51469().method_8396(null, context.markPos(),
                      Chalk.SoundEvents.GLOWING.get(), class_3419.field_15245, 0.8f, 1f);
                serverPlayer.method_51469().method_14199(class_2398.field_11207, pos.x(), pos.y(), pos.z(), 1, 0, 0, 0, 0);
            }
        }
    }

    // --

    static class_1799 findMatching(class_1661 inventory, int color, @Nullable Supplier<class_1799> fallback) {
        class_1799 anyDrawable = class_1799.field_8037;

        for (class_1799 item : inventory.field_7547) {
            if (!(item.method_7909() instanceof MarkDrawable drawable)) {
                continue;
            }

            if (drawable.getMarkDrawingColor(item) == color) {
                return item;
            }

            ChalkBoxContents chalkBoxContents = ChalkBoxContents.of(item);
            if (!chalkBoxContents.isEmpty() && chalkBoxContents.items().stream()
                  .anyMatch(s -> s.method_7909() instanceof MarkDrawable sDrawable
                        && sDrawable.getMarkDrawingColor(s) == color)) {
                return item;
            }

            if (anyDrawable.method_7960()) {
                anyDrawable = item;
            }
        }

        if (fallback != null) {
            return fallback.get();
        }

        return anyDrawable;
    }

    static class_1799 findMatching(class_1661 inventory, int color) {
        return findMatching(inventory, color, null);
    }
}
