package io.github.mortuusars.chalk.client;

import io.github.mortuusars.chalk.network.Packets;
import io.github.mortuusars.chalk.network.packet.serverbound.DestroyMarkC2SP;
import io.github.mortuusars.chalk.world.block.MarkBlock;
import io.github.mortuusars.chalk.world.chalk.DrawnMark;
import java.util.Objects;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_638;
import net.minecraft.class_746;

public class ClientHelper {
    public static boolean handleCreativeStartDestroyBlock(class_2338 pos, class_2350 face, class_1934 localPlayerMode) {
        class_310 minecraft = class_310.method_1551();
        class_638 level = Objects.requireNonNull(minecraft.field_1687);
        class_746 player = Objects.requireNonNull(minecraft.field_1724);

        if (minecraft.field_1765 instanceof class_3965 hitResult
              && hitResult.method_17783() != class_239.class_240.field_1333
              && !player.method_21701(level, pos, localPlayerMode)
              && level.method_8621().method_11952(pos)
              && level.method_8320(pos).method_26204() instanceof MarkBlock) {
            if (MarkBlock.getMarkAt(level, hitResult.method_17784()) instanceof DrawnMark mark) {
                Packets.sendToServer(new DestroyMarkC2SP(pos, mark.facing()));
            }

            return true;
        }

        return false;
    }

    public static void attackMarkBlock(class_2338 pos) {
        class_310 minecraft = class_310.method_1551();
        class_638 level = Objects.requireNonNull(minecraft.field_1687);

        if (minecraft.field_1765 instanceof class_3965 hitResult
              && hitResult.method_17783() != class_239.class_240.field_1333
              && level.method_8621().method_11952(pos)
              && level.method_8320(pos).method_26204() instanceof MarkBlock
              && MarkBlock.getMarkAt(level, hitResult.method_17784()) instanceof DrawnMark mark) {
            Packets.sendToServer(new DestroyMarkC2SP(pos, mark.facing()));
        }
    }
}
