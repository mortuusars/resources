package io.github.mortuusars.chalk.network.packet.serverbound;

import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.world.item.ChalkBoxItem;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.chalk.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

public record OpenCreativeChalkBoxC2SP(int chalkBoxSlotIndex) implements Packet {
    public static final class_8710.class_9154<OpenCreativeChalkBoxC2SP> TYPE = new class_8710.class_9154<>(Chalk.resource("open_creative_chalk_box"));

    public static final class_9139<class_2540, OpenCreativeChalkBoxC2SP> STREAM_CODEC = class_9139.method_56434(
            class_9135.field_49675, OpenCreativeChalkBoxC2SP::chalkBoxSlotIndex,
            OpenCreativeChalkBoxC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (!player.method_7337()) {
            Chalk.LOGGER.error("Cannot open Chalk Box. Player is not in creative mode.");
            return false;
        }

        if (!(player instanceof class_3222 serverPlayer)) {
            Chalk.LOGGER.error("Cannot open Chalk Box. Player is not ServerPlayer.");
            return false;
        }

        int slotId = chalkBoxSlotIndex();

        class_1799 itemStack = player.method_31548().method_5438(slotId);
        if (itemStack.method_7909() instanceof ChalkBoxItem chalkBoxItem) {
//            chalkBoxItem.openGUI(serverPlayer, itemStack);
        }
        else {
            Chalk.LOGGER.error("Cannot open Chalk Box. Item in slot '{}' is not a ChalkBoxItem but '{}'", slotId, itemStack);
        }

        return true;
    }
}
