package io.github.mortuusars.chalk.world.item;

import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.Platform;
import io.github.mortuusars.chalk.Config;
import io.github.mortuusars.chalk.world.chalk.Mark;
import io.github.mortuusars.chalk.world.chalk.MarkDrawingContext;
import io.github.mortuusars.chalk.world.inventory.ChalkBoxMenu;
import io.github.mortuusars.chalk.world.item.component.ChalkBoxContents;
import io.github.mortuusars.mortaar.world.item.ApplicationTargetItem;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_437;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import net.minecraft.class_5632;
import net.minecraft.class_747;
import net.minecraft.class_9334;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;

public class ChalkBoxItem extends class_1792 implements MarkDrawable, ApplicationTargetItem {
    public ChalkBoxItem(class_1793 properties) {
        super(properties);
    }

    public @NotNull ChalkBoxContents getContents(class_1799 stack) {
        return ChalkBoxContents.of(stack);
    }

    public class_1799 getSelectedChalk(class_1799 stack) {
        return getContents(stack).getSelectedChalk();
    }

    public int getTintColor(class_1799 stack, int index) {
        if (index != 1) {
            return 0xFFFFFFFF;
        }

        class_1799 selectedChalk = getSelectedChalk(stack);
        if (selectedChalk.method_7960() || !(selectedChalk.method_7909() instanceof ChalkItem chalkItem)) {
            return 0x00000000;
        }

        return chalkItem.getTintColor(selectedChalk, 0);
    }

    // -- Tooltip

    @Override
    public @NotNull Optional<class_5632> method_32346(@NotNull class_1799 stack) {
        return Config.Client.CHALK_BOX_TOOLTIP_CONTENTS.get() && !getContents(stack).isEmpty()
              ? Optional.of(getContents(stack)) : Optional.empty();
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @NotNull class_9635 context,
                                @NotNull List<class_2561> tooltipComponents, @NotNull class_1836 tooltipFlag) {
        if (!Config.Client.CHALK_BOX_TOOLTIP_DETAILS.get()) {
            return;
        }

        if (!class_437.method_25442()) {
            tooltipComponents.add(class_2561.method_43471("item.chalk.tooltip.hold_for_details"));
        } else {
            tooltipComponents.add(class_2561.method_43471("item.chalk.chalk_box.tooltip.open"));
            tooltipComponents.add(class_2561.method_43471("item.chalk.chalk_box.tooltip.insert"));
            tooltipComponents.add(class_2561.method_43471("item.chalk.chalk_box.tooltip.remove"));
            tooltipComponents.add(class_2561.method_43471("item.chalk.chalk_box.tooltip.change_selected"));
        }
    }

    @Override
    public boolean shouldRenderSlotTooltipWhileCarrying(class_1937 level, class_1799 carried, class_1799 hovered) {
        return ChalkBoxContents.canHold(carried);
    }

    // -- Bar

    @Override
    public boolean method_31567(class_1799 stack) {
        return Config.Server.CHALK_BOX_SHOW_DURABILITY_BAR.get()
              ? getSelectedChalk(stack).method_31578()
              : super.method_31567(stack);
    }

    @Override
    public int method_31569(class_1799 stack) {
        return getSelectedChalk(stack).method_31579();
    }

    @Override
    public int method_31571(class_1799 stack) {
        return getSelectedChalk(stack).method_31580();
    }

    // --

    @Override
    public boolean method_7870(@NotNull class_1799 stack) {
        return false;
    }

    @Override
    public boolean method_31566(class_1799 stack, class_1799 other, class_1735 slot, class_5536 action, class_1657 player, class_5630 access) {
        if (action != class_5536.field_27014 || !slot.method_32754(player)) {
            return false;
        }

        ChalkBoxContents contents = getContents(stack);

        // Extract selected
        if (other.method_7960()) {
            class_1799 selectedChalk = contents.getSelectedChalk();
            if (!selectedChalk.method_7960()) {
                slot.method_7673(contents.mutable().setItem(contents.selected(), class_1799.field_8037).toImmutable(stack));
                access.method_32332(selectedChalk.method_7972());
                player.method_37908().method_43129(player, player, Chalk.SoundEvents.CHALK_BOX_CHANGE.get(), class_3419.field_15248, 1, 1);
                player.method_7350();
                return true;
            }

            class_1799 glowingItem = contents.getItem(ChalkBoxContents.GLOWINGS_SLOT);
            if (Config.Server.CHALK_BOX_GLOWING_ENABLED.get() && !glowingItem.method_7960()) {
                slot.method_7673(contents.mutable().setItem(ChalkBoxContents.GLOWINGS_SLOT, class_1799.field_8037).toImmutable(stack));
                access.method_32332(glowingItem.method_7972());
                player.method_37908().method_43129(player, player, Chalk.SoundEvents.CHALK_BOX_CHANGE.get(), class_3419.field_15248, 1, 1);
                player.method_7350();
                return true;
            }

            player.method_5783(class_3417.field_15015.comp_349(), 0.6f, 1f);
            return true;
        }

        // Insert chalk
        if (other.method_7909() instanceof ChalkItem) {
            for (int i = 0; i < ChalkBoxContents.CHALK_SLOTS; i++) {
                if (contents.getItem(i).method_7960()) {
                    access.method_32332(class_1799.field_8037);
                    slot.method_7673(contents.mutable().setItem(i, other.method_7972()).toImmutable(stack));
                    player.method_37908().method_43129(player, player, Chalk.SoundEvents.CHALK_BOX_CHANGE.get(), class_3419.field_15248, 1, 1);
                    player.method_7350();
                    return true;
                }
            }

            player.method_5783(class_3417.field_15015.comp_349(), 0.6f, 1f);
            return true;
        }

        // Insert glowing
        if (Config.Server.GLOWING_ENABLED.get() && Config.Server.CHALK_BOX_GLOWING_ENABLED.get() && other.method_31573(Chalk.Tags.Items.GLOWINGS)) {
            class_1799 existing = contents.getItem(ChalkBoxContents.GLOWINGS_SLOT);
            int glowBeforeInsertion = contents.glow();

            if (existing.method_7960()) {
                access.method_32332(class_1799.field_8037);
                slot.method_7673(contents.mutable()
                      .setItem(ChalkBoxContents.GLOWINGS_SLOT, other.method_7972())
                      .updateGlow()
                      .toImmutable(stack));
            } else if (existing.method_7947() >= existing.method_7914() || !class_1799.method_31577(existing, other)) {
                player.method_5783(class_3417.field_15015.comp_349(), 0.6f, 1f);
                return true;
            } else {
                int insertedAmount = Math.min(other.method_7947(), existing.method_7914() - existing.method_7947());
                if (insertedAmount <= 0) {
                    return true;
                }

                existing = existing.method_7972();
                existing.method_7939(existing.method_7947() + insertedAmount);
                slot.method_7673(contents.mutable()
                      .setItem(ChalkBoxContents.GLOWINGS_SLOT, existing)
                      .updateGlow()
                      .toImmutable(stack));

                other.method_7971(insertedAmount);
                access.method_32332(other);
            }

            player.method_37908().method_43129(player, player, Chalk.SoundEvents.CHALK_BOX_CHANGE.get(), class_3419.field_15248, 1, 1);
            player.method_7350();

            if (glowBeforeInsertion < getContents(slot.method_7677()).glow()) {
                player.method_43077(Chalk.SoundEvents.GLOW_APPLIED.get());
                player.method_43077(Chalk.SoundEvents.GLOWING.get());
            }

            return true;
        }

        player.method_5783(class_3417.field_15015.comp_349(), 0.6f, 1f);
        return true;
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_1268 hand = context.method_20287();
        class_1799 stack = context.method_8041();
        class_1657 player = context.method_8036();

        if (player == null) {
            return class_1269.field_5814;
        }

        class_1799 selectedChalk = getSelectedChalk(stack);

        if (selectedChalk.method_7960()) {
            if (player instanceof class_3222 serverPlayer) {
                open(serverPlayer, hand);
            }
            player.method_7350();
            return class_1269.field_5812;
        }

        convertOldChalks(player, hand, stack);

        if (!(selectedChalk.method_7909() instanceof MarkDrawable)) {
            Chalk.LOGGER.error("Cannot draw mark using a Chalk Box: selected chalk is not a drawable item, but {}.", selectedChalk.method_7909());
            player.method_5783(class_3417.field_15015.comp_349(), 0.6f, 1f);
            return class_1269.field_5814;
        }

        MarkDrawingContext drawingContext = createMarkDrawingContext(player, context.method_20287(),
              context.method_17698(), context.method_8037(), context.method_8038());

        if (!canDrawMark(player, drawingContext)) {
            return class_1269.field_5814;
        }

        if (player.method_21823()) {
            selectSymbolAndDraw(player, drawingContext);
            return class_1269.field_21466;
        }

        if (drawMark(player, drawingContext, createRegularMark(player, drawingContext, stack))) {
            return class_1269.method_29236(context.method_8045().method_8608());
        }

        return class_1269.field_5814;
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(@NotNull class_1937 level, class_1657 player, @NotNull class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (player.method_21823()) {
            convertOldChalks(player, hand, stack);

            ChalkBoxContents contents = getContents(stack);
            if (contents.getChalkCount() <= 1) {
                player.method_5783(class_3417.field_15015.comp_349(), 0.6f, 1f);
                return class_1271.method_22431(stack);
            }

            int newSelected = contents.selected() + 1;
            if (newSelected >= ChalkBoxContents.CHALK_SLOTS) {
                newSelected = 0;
            }
            contents.mutable()
                  .setSelected(newSelected)
                  .toImmutable(stack);

            player.method_37908().method_43129(player, player, Chalk.SoundEvents.CHALK_BOX_CHANGE.get(), class_3419.field_15248, 1, 1);
            player.method_7350();

            return class_1271.method_22428(stack);
        }

        if (player instanceof class_3222 serverPlayer) {
            open(serverPlayer, hand);
        }
        player.method_7350();
        return class_1271.method_22428(stack);
    }

    public void open(class_3222 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (!(stack.method_7909() instanceof ChalkBoxItem)) {
            Chalk.LOGGER.error("Cannot open Chalk Box menu: {} is not a ChalkBoxItem.", stack);
            return;
        }

        convertOldChalks(player, hand, stack);

        class_2561 title = stack.method_57826(class_9334.field_49631)
              ? stack.method_7964()
              : class_2561.method_43471("container.chalk.chalk_box");

        class_747 menuProvider = new class_747((containerID, playerInventory, playerEntity) ->
              new ChalkBoxMenu(containerID, playerInventory, hand), title);

        Platform.openMenu(player, menuProvider, buffer -> buffer.method_10817(hand));

        player.method_37908().method_43128(null, player.method_19538().field_1352, player.method_19538().field_1351, player.method_19538().field_1350,
              Chalk.SoundEvents.CHALK_BOX_OPEN.get(), class_3419.field_15248,
              0.9f, 0.9f + player.method_37908().field_9229.method_43057() * 0.2f);
    }

    @SuppressWarnings("removal")
    protected void convertOldChalks(class_1657 player, class_1268 hand, class_1799 stack) {
        ChalkBoxContents contents = getContents(stack);
        if (contents.items().stream().anyMatch(s -> s.method_7909() instanceof OldChalkItem)) {
            List<class_1799> items = contents.copyItems().stream()
                  .map(s -> {
                      if (s.method_7909() instanceof OldChalkItem oldChalkItem) {
                          return oldChalkItem.convert(s);
                      }
                      return s;
                  })
                  .toList();
            player.method_6122(hand, contents.mutable().setItems(items).toImmutable(stack));
        }
    }

    // -- Drawable

    @Override
    public int getMarkDrawingColor(class_1799 chalkBoxStack) {
        class_1799 chalk = getSelectedChalk(chalkBoxStack);
        return chalk.method_7909() instanceof MarkDrawable drawable
              ? drawable.getMarkDrawingColor(chalk)
              : 0xFFFFFFFF;
    }

    @Override
    public boolean shouldDrawGlowingMark(class_1799 chalkBoxStack) {
        return Config.Server.CHALK_BOX_GLOWING_ENABLED.get() && getContents(chalkBoxStack).glow() > 0;
    }

    @Override
    public void onMarkDrawn(class_1657 player, MarkDrawingContext context, Mark mark) {
        MarkDrawable.super.onMarkDrawn(player, context, mark);

        class_1799 chalkBoxStack = player.method_5998(context.hand());
        ChalkBoxContents contents = getContents(chalkBoxStack);
        int selectedChalkIndex = contents.selected();
        if (selectedChalkIndex < 0) {
            Chalk.LOGGER.error("Failed to apply Chalk Box onMarkDrawn side effects: no selected chalk. {}", chalkBoxStack.method_57353());
            return;
        }

        class_1799 selectedChalk = contents.getItem(selectedChalkIndex).method_7972();
        if (selectedChalk.method_7909() instanceof ChalkItem chalk) {
            chalk.onChalkMarkDrawn(player, context.hand(), selectedChalk, context.markPos(), context.markFacing(), mark);
        }

        if (contents.glow() > 0 && player instanceof class_3222 serverPlayer) {
            class_2338 surfacePos = context.surfacePos();
            Chalk.CriteriaTriggers.MARK_GLOWING.get().trigger(
                  serverPlayer, mark, context.markPos(), player.method_37908().method_8320(surfacePos).method_26205(player.method_37908(), surfacePos));
        }

        if (!player.method_7337()) {
            selectedChalk.method_7970(1, player, class_1309.method_56079(context.hand()));

            player.method_6122(context.hand(), contents.mutable()
                  .setItem(selectedChalkIndex, selectedChalk)
                  .consumeGlow()
                  .toImmutable(chalkBoxStack));
        }
    }
}
