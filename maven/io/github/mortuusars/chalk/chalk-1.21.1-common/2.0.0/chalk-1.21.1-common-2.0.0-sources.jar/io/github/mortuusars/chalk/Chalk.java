package io.github.mortuusars.chalk;

import io.github.mortuusars.chalk.advancements.trigger.MarkDrawnTrigger;
import io.github.mortuusars.chalk.advancements.trigger.ConsecutiveSleepingTrigger;
import io.github.mortuusars.chalk.advancements.trigger.MarkGlowingTrigger;
import io.github.mortuusars.chalk.world.block.MarkBlockEntity;
import io.github.mortuusars.chalk.world.block.MarkBlock;
import io.github.mortuusars.chalk.world.block.OldChalkMarkBlock;
import io.github.mortuusars.chalk.world.block.OldMarkBlockEntity;
import io.github.mortuusars.chalk.world.chalk.symbol.MarkSymbol;
import io.github.mortuusars.chalk.world.item.ChalkBoxItem;
import io.github.mortuusars.chalk.world.item.OldChalkItem;
import io.github.mortuusars.chalk.world.inventory.ChalkBoxMenu;
import io.github.mortuusars.chalk.world.chalk.ChalkColors;
import io.github.mortuusars.chalk.world.item.ChalkItem;
import io.github.mortuusars.chalk.world.item.component.ChalkBoxContents;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_156;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3619;
import net.minecraft.class_3917;
import net.minecraft.class_4174;
import net.minecraft.class_4970;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_9331;

public class Chalk {
    public static final String ID = "chalk";
    public static final Logger LOGGER = LogManager.getLogger();

    public static void init() {
        Blocks.init();
        BlockEntityTypes.init();
        Items.init();
        DataComponents.init();
        CriteriaTriggers.init();
        MenuTypes.init();
        SoundEvents.init();
    }

    public static class_2960 resource(String path) {
        return class_2960.method_60655(ID, path);
    }

    public static class Blocks {
        public static final Supplier<MarkBlock> MARK = Register.block("mark",
              () -> new MarkBlock(class_4970.class_2251.method_9637()
                    .method_50012(class_3619.field_15971)
                    .method_51371()
                    .method_9618()
                    .method_22488()
                    .method_9634()
                    .method_45477()
                    .method_9631(state -> state.method_11654(MarkBlock.GLOWING) ? 5 : 0)
                    .method_9626(class_2498.field_17581)));

        @SuppressWarnings("removal")
        @Deprecated(since = "2.0.0", forRemoval = true)
        public static final Map<class_1767, Supplier<OldChalkMarkBlock>> MARKS = class_156.method_654(new LinkedHashMap<>(), map -> {
            for (class_1767 color : ChalkColors.COLORS.keySet()) {
                map.put(color, Register.block(color + "_chalk_mark",
                        () -> new OldChalkMarkBlock(color, class_4970.class_2251.method_9637()
                                .method_51517(color)
                                .method_50012(class_3619.field_15971)
                                .method_9618()
                                .method_22488()
                                .method_9634()
                                .method_9640()
                                .method_9626(class_2498.field_17581))));
            }
        });

        static void init() {
        }
    }

    public static class BlockEntityTypes {
        public static final Supplier<class_2591<MarkBlockEntity>> MARK = Register.blockEntityType("mark",
              () -> Register.newBlockEntityType(MarkBlockEntity::new, Blocks.MARK.get()));
        @SuppressWarnings("removal")
        @Deprecated(since = "2.0.0", forRemoval = true)
        public static final Supplier<class_2591<OldMarkBlockEntity>> CHALK_MARK = Register.blockEntityType("chalk_mark",
              () -> Register.newBlockEntityType(OldMarkBlockEntity::new, Blocks.MARKS.values().stream().map(Supplier::get).toArray(class_2248[]::new)));

        static void init() {
        }
    }

    public static class Foods {
        public static final class_4174 CHALK = new class_4174.class_4175()
              .method_19239(new class_1293(class_1294.field_5910, 600, 0), 1.0F)
              .method_19240()
              .method_19242();
    }

    public static class Items {
        public static final Supplier<ChalkItem> CHALK = Register.item("chalk",
              () -> new ChalkItem(new class_1792.class_1793()
                    .method_7889(1)
                    .method_7895(64)
                    .method_19265(Foods.CHALK)));

        public static final Supplier<ChalkBoxItem> CHALK_BOX = Register.item("chalk_box",
              () -> new ChalkBoxItem(new class_1792.class_1793()
                    .method_7889(1)));

        @SuppressWarnings("removal")
        @Deprecated(since = "2.0.0", forRemoval = true)
        public static Map<class_1767, Supplier<OldChalkItem>> CHALKS = class_156.method_654(new LinkedHashMap<>(), map -> {
            for (class_1767 color : ChalkColors.COLORS.keySet()) {
                map.put(color, Register.item(color + "_chalk", () -> new OldChalkItem(color, new class_1792.class_1793()
                      .method_7889(1)
                      .method_7895(64))));
            }
        });

        static void init() {
        }
    }

    public static class DataComponents {
        public static final class_9331<ChalkBoxContents> CHALK_BOX_CONTENTS = Register.dataComponentType("chalk_box_contents",
              builder -> builder.method_57881(ChalkBoxContents.CODEC).method_57882(ChalkBoxContents.STREAM_CODEC).method_59871());

        static void init() {
        }
    }

    public static class MenuTypes {
        public static final Supplier<class_3917<ChalkBoxMenu>> CHALK_BOX = Register.menuType("chalk_box", ChalkBoxMenu::fromNetwork);

        static void init() {
        }
    }

    public static class CriteriaTriggers {
        public static final Supplier<ConsecutiveSleepingTrigger> CONSECUTIVE_SLEEPING =
              Register.criterionTrigger("consecutive_sleeping", ConsecutiveSleepingTrigger::new);
        public static final Supplier<MarkDrawnTrigger> MARK_DRAWN =
              Register.criterionTrigger("mark_drawn", MarkDrawnTrigger::new);
        public static final Supplier<MarkGlowingTrigger> MARK_GLOWING =
              Register.criterionTrigger("mark_glowing", MarkGlowingTrigger::new);

        static void init() {
        }
    }

    public static class SoundEvents {
        public static final Supplier<class_3414> MARK_DRAWN = Register.soundEvent("item.chalk.draw",
              () -> class_3414.method_47908(Chalk.resource("item.chalk.draw")));
        public static final Supplier<class_3414> MARK_REMOVED = Register.soundEvent("block.mark.removed",
              () -> class_3414.method_47908(Chalk.resource("block.mark.removed")));
        public static final Supplier<class_3414> CHALK_BOX_OPEN = Register.soundEvent("item.chalk_box.open",
              () -> class_3414.method_47908(Chalk.resource("item.chalk_box.open")));
        public static final Supplier<class_3414> CHALK_BOX_CLOSE = Register.soundEvent("item.chalk_box.close",
              () -> class_3414.method_47908(Chalk.resource("item.chalk_box.close")));
        public static final Supplier<class_3414> CHALK_BOX_CHANGE = Register.soundEvent("item.chalk_box.change",
              () -> class_3414.method_47908(Chalk.resource("item.chalk_box.change")));
        public static final Supplier<class_3414> GLOW_APPLIED = Register.soundEvent("item.glow_applied",
              () -> class_3414.method_47908(Chalk.resource("item.glow_applied")));
        public static final Supplier<class_3414> GLOWING = Register.soundEvent("ambient.glowing",
              () -> class_3414.method_47908(Chalk.resource("ambient.glowing")));

        static void init() {
        }
    }

    public static class Registries {
        public static final class_5321<class_2378<MarkSymbol>> MARK_SYMBOL = class_5321.method_29180(resource("mark_symbol"));
    }

    public static class LootTables {
        public static final class_5321<class_52> ABANDONED_MINESHAFT_CHALKS =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Chalk.resource("chests/abandoned_mineshaft_chalks"));
        public static final class_5321<class_52> DESERT_PYRAMID_CHALKS =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Chalk.resource("chests/desert_pyramid_chalks"));
        public static final class_5321<class_52> SIMPLE_DUNGEON_CHALKS =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Chalk.resource("chests/simple_dungeon_chalks"));
        public static final class_5321<class_52> VILLAGE_CHALKS =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Chalk.resource("chests/village_chalks"));
    }

    public static class Tags {
        public static final class Items {
            public static final class_6862<class_1792> GLOWINGS = class_6862.method_40092(net.minecraft.class_7924.field_41197, Chalk.resource("glowings"));
        }

        public static final class Blocks {
            public static final class_6862<class_2248> CHALK_CANNOT_DRAW_ON = class_6862.method_40092(net.minecraft.class_7924.field_41254, Chalk.resource("chalk_cannot_draw_on"));
        }
    }
}
