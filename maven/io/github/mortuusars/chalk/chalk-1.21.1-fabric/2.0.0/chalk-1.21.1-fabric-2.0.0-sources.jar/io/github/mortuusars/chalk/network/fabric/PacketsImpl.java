package io.github.mortuusars.chalk.network.fabric;

import io.github.mortuusars.chalk.network.packet.Packet;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3222;

public class PacketsImpl {
    public static void sendToServer(Packet packet) {
        FabricC2SPackets.sendToServer(packet);
    }

    public static void sendToClient(Packet packet, class_3222 player) {
        ServerPlayNetworking.send(player, packet);
    }
}
