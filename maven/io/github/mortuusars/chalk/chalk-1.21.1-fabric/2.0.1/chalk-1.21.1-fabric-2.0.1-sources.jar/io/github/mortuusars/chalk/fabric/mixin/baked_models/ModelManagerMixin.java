package io.github.mortuusars.chalk.fabric.mixin.baked_models;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.fabric.client.FabricMarkBakedModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1092;
import net.minecraft.class_2680;
import net.minecraft.class_773;

@Mixin(class_1092.class)
public class ModelManagerMixin {
    @WrapOperation(method = "loadModels", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/resources/model/ModelBakery;getBakedTopLevelModels()Ljava/util/Map;"))
    private Map<class_1091, class_1087> onLoadModels(class_1088 instance, Operation<Map<class_1091, class_1087>> original) {
        Map<class_1091, class_1087> models = original.call(instance);

        for (class_2680 blockState : Chalk.Blocks.MARK.get().method_9595().method_11662()) {
            class_1091 variantMRL = class_773.method_3340(blockState);
            class_1087 existingModel = models.get(variantMRL);

            if (existingModel instanceof FabricMarkBakedModel)
                Chalk.LOGGER.warn("Tried to replace {} model twice", blockState);
            else if (existingModel != null) {
                FabricMarkBakedModel customModel = new FabricMarkBakedModel(existingModel);
                models.put(variantMRL, customModel);
            } else
                Chalk.LOGGER.warn("{} model not found. MarkBakedModel would not be added for this blockstate.", variantMRL);
        }

        return models;
    }
}
