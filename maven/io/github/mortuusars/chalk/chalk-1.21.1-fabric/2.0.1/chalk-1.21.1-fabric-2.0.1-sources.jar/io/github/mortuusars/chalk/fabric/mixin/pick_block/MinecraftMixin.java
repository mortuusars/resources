package io.github.mortuusars.chalk.fabric.mixin.pick_block;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.mortuusars.chalk.world.block.MarkBlock;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Shadow
    @Nullable
    public class_239 hitResult;

    @Shadow
    @Nullable
    public class_746 player;

    @WrapOperation(method = "pickBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/Block;getCloneItemStack(Lnet/minecraft/world/level/LevelReader;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/item/ItemStack;"))
    private class_1799 onPickBlock(class_2248 instance, class_4538 level, class_2338 pos, class_2680 state, Operation<class_1799> original) {
        if (player != null && instance instanceof MarkBlock markBlock && hitResult instanceof class_3965 result) {
            return markBlock.pick(player, level, pos, state, result);
        }
        return original.call(instance, level, pos, state);
    }
}
