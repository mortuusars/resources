package io.github.mortuusars.chalk.fabric;

import fuzs.forgeconfigapiport.fabric.api.neoforge.v4.NeoForgeConfigRegistry;
import fuzs.forgeconfigapiport.fabric.api.neoforge.v4.NeoForgeModConfigEvents;
import io.github.mortuusars.chalk.Chalk;
import io.github.mortuusars.chalk.Config;
import io.github.mortuusars.chalk.world.chalk.ChalkColors;
import io.github.mortuusars.chalk.event.CommonEvents;
import io.github.mortuusars.chalk.world.chalk.symbol.MarkSymbol;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.registry.DynamicRegistries;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableSource;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_39;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_7225;
import net.minecraft.class_7706;
import net.minecraft.class_83;
import net.minecraft.class_9282;
import net.minecraft.class_9334;
import net.neoforged.fml.config.ModConfig;

public class ChalkFabric implements ModInitializer {
    @Override
    public void onInitialize() {
        Chalk.init();

        NeoForgeConfigRegistry.INSTANCE.register(Chalk.ID, ModConfig.Type.SERVER, Config.Server.SPEC);
        NeoForgeConfigRegistry.INSTANCE.register(Chalk.ID, ModConfig.Type.COMMON, Config.Common.SPEC);
        NeoForgeConfigRegistry.INSTANCE.register(Chalk.ID, ModConfig.Type.CLIENT, Config.Client.SPEC);

        NeoForgeModConfigEvents.loading(Chalk.ID).register(config -> {
            if (config.getType() == ModConfig.Type.SERVER) {
                Config.Server.loading();
            }
        });
        NeoForgeModConfigEvents.reloading(Chalk.ID).register(config -> {
            if (config.getType() == ModConfig.Type.SERVER) {
                Config.Server.reloading();
            }
        });

        CommonEvents.commonSetup();

        DynamicRegistries.registerSynced(Chalk.Registries.MARK_SYMBOL, MarkSymbol.DIRECT_CODEC, MarkSymbol.DIRECT_CODEC);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(event -> {
            event.method_45420(new class_1799(Chalk.Items.CHALK.get()));

            if (Config.Server.ADD_DYED_CHALKS_TO_TAB.get()) {
                for (class_1767 dyeColor : ChalkColors.ORDERED_DYE_COLORS) {
                    if (dyeColor == class_1767.field_7952) {
                        continue;
                    }

                    class_1799 stack = new class_1799(Chalk.Items.CHALK.get());
                    int color = Chalk.Items.CHALK.get().getColorFromDye(stack, dyeColor);
                    stack.method_57379(class_9334.field_49644, new class_9282(color, true));
                    event.method_45420(stack);
                }
            }

            event.method_45421(Chalk.Items.CHALK_BOX.get());
        });

        LootTableEvents.MODIFY.register(ChalkFabric::modifyLoot);
    }

    private static void modifyLoot(class_5321<class_52> tableKey, class_52.class_53 builder,
                                   LootTableSource source, class_7225.class_7874 provider) {
        if (!Config.Common.LOOT.get()) {
            return;
        }

        if (class_39.field_472.equals(tableKey)) {
            builder.pool(class_55.method_347()
                  .method_351(class_83.method_428(Chalk.LootTables.ABANDONED_MINESHAFT_CHALKS))
                  .method_355());
        }
        if (class_39.field_885.equals(tableKey)) {
            builder.pool(class_55.method_347()
                  .method_351(class_83.method_428(Chalk.LootTables.DESERT_PYRAMID_CHALKS))
                  .method_355());
        }
        if (class_39.field_16751.equals(tableKey)
              || class_39.field_17010.equals(tableKey)
              || class_39.field_16748.equals(tableKey)
              || class_39.field_16753.equals(tableKey)) {
            builder.pool(class_55.method_347()
                  .method_351(class_83.method_428(Chalk.LootTables.VILLAGE_CHALKS))
                  .method_355());
        }
        if (class_39.field_356.equals(tableKey)) {
            builder.pool(class_55.method_347()
                  .method_351(class_83.method_428(Chalk.LootTables.SIMPLE_DUNGEON_CHALKS))
                  .method_355());
        }
        if (class_39.field_850.equals(tableKey)) {
            builder.pool(class_55.method_347()
                  .method_351(class_83.method_428(Chalk.LootTables.VILLAGE_CHALKS))
                  .method_355());
        }
    }
}
