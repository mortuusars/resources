package io.github.mortuusars.chalk.fabric.client;

import io.github.mortuusars.chalk.client.render.MarkBakedModel;
import io.github.mortuusars.chalk.world.block.MarkBlockEntity;
import io.github.mortuusars.chalk.world.chalk.MarkSet;
import net.fabricmc.fabric.api.renderer.v1.Renderer;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.material.ShadeMode;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import java.util.Objects;
import java.util.function.Supplier;

public class FabricMarkBakedModel extends MarkBakedModel {
    private static final Renderer RENDERER = RendererAccess.INSTANCE.getRenderer();
    private static final RenderMaterial STANDARD_MATERIAL = Objects.requireNonNull(RENDERER).materialFinder().shadeMode(ShadeMode.VANILLA).find();

    public FabricMarkBakedModel(class_1087 baseModel) {
        super(baseModel);
    }

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
        QuadEmitter emitter = context.getEmitter();

        if (blockView.method_8321(pos) instanceof MarkBlockEntity blockEntity) {
            MarkSet marks = blockEntity.getMarks();
            if (!marks.isEmpty()) {
                marks.forEach((direction, mark) -> {
                    emitter.fromVanilla(bakeMarkQuad(direction, mark), STANDARD_MATERIAL, null);
                    emitter.emit();
                });
            }
        }
    }
}