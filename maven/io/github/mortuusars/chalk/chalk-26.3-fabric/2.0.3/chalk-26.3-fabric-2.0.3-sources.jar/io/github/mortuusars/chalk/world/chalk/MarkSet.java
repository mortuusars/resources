package io.github.mortuusars.chalk.world.chalk;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import net.minecraft.core.Direction;
import net.minecraft.util.StringRepresentable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.stream.IntStream;

public class MarkSet {
    public static final Codec<MarkSet> CODEC = Codec.simpleMap(Direction.CODEC, Mark.CODEC, StringRepresentable.keys(Direction.values())).codec()
          .xmap(map -> {
              Mark[] marks = new Mark[6];
              for (Direction direction : Direction.values()) {
                  marks[direction.get3DDataValue()] = map.get(direction);
              }
              return new MarkSet(marks);
          }, set -> {
              Map<Direction, Mark> map = new HashMap<>();

              for (Direction direction : Direction.values()) {
                  @Nullable Mark mark = set.get(direction);
                  if (mark != null) {
                      map.put(direction, mark);
                  }
              }

              return map;
          });

    private final Mark[] marks;
    private int mask;

    public MarkSet(Mark[] marks) {
        Preconditions.checkState(marks.length == 6, "MarkSet should always have 6 marks.");
        this.marks = marks;
        mask = 0;
        for (int i = 0; i < 6; i++) {
            if (marks[i] != null) {
                mask |= 1 << i;
            }
        }
    }

    public MarkSet() {
        this(new Mark[6]);
    }

    public @Nullable Mark get(Direction face) {
        return marks[face.get3DDataValue()];
    }

    public @Nullable Mark get(int index) {
        if (index < 0 || index >= 6) return null;
        return marks[index];
    }

    public void set(Direction face, @NotNull Mark mark) {
        marks[face.get3DDataValue()] = mark;
        mask |= 1 << face.get3DDataValue();
    }

    public void remove(Direction face) {
        marks[face.get3DDataValue()] = null;
        mask &= ~(1 << face.get3DDataValue());
    }

    public int[] getIndices() {
        return IntStream.range(0, marks.length)
              .filter(i -> marks[i] != null)
              .toArray();
    }

    public int getMask() {
        return mask;
    }

    public boolean isEmpty() {
        return mask == 0;
    }

    public int getCount() {
        int count = 0;
        for (Mark mark : marks) {
            if (mark != null) {
                count++;
            }
        }
        return count;
    }

    public void forEach(BiConsumer<Direction, Mark> consumer) {
        for (int i = 0; i < 6; i++) {
            @Nullable Mark mark = marks[i];
            if (mark != null) {
                consumer.accept(Direction.from3DDataValue(i), mark);
            }
        }
    }

    public Mark[] copyArray() {
        return marks.clone();
    }
}