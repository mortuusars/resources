package io.github.mortuusars.exposure_catalog.fabric;

import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_3222;

public class LuckPermsIntegration {
    public static boolean checkPermission(class_3222 player, String permission) {
        return Permissions.check(player, permission);
    }
}
