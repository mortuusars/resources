package io.github.mortuusars.exposure_catalog.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure_catalog.data.server.Catalog;
import io.github.mortuusars.exposure_catalog.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public class CatalogClosedC2SP implements Packet {
    public static final CatalogClosedC2SP INSTANCE = new CatalogClosedC2SP();

    public static final class_2960 ID = Exposure.resource("catalog_closed");
    public static final class_8710.class_9154<CatalogClosedC2SP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, CatalogClosedC2SP> STREAM_CODEC = class_9139.method_56431(INSTANCE);

    private CatalogClosedC2SP() { }

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        Catalog.removeWatchingPlayer(((class_3222) player));
        return true;
    }
}