package io.github.mortuusars.exposure_catalog.data;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ExposureThumbnail(int width, int height, byte[] pixels, class_2960 paletteId) {
    public static final class_9139<ByteBuf, ExposureThumbnail> STREAM_CODEC = class_9139.method_56905(
            class_9135.field_48550, ExposureThumbnail::width,
            class_9135.field_48550, ExposureThumbnail::height,
            class_9135.field_48987, ExposureThumbnail::pixels,
            class_2960.field_48267, ExposureThumbnail::paletteId,
            ExposureThumbnail::new
    );
}
