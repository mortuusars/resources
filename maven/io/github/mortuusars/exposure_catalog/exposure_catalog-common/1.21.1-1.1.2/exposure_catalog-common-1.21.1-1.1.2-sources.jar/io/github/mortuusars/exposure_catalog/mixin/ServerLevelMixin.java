package io.github.mortuusars.exposure_catalog.mixin;

import io.github.mortuusars.exposure_catalog.data.server.Catalog;
import net.minecraft.class_3218;
import net.minecraft.class_3536;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3218.class)
public class ServerLevelMixin {
    @Inject(method = "save", at = @At(value = "RETURN"))
    private void save(class_3536 progressListener, boolean bl, boolean bl2, CallbackInfo ci) {
        if (Catalog.shouldClear()) {
            Catalog.clear();
        }
    }
}