package io.github.mortuusars.exposure_catalog.client.gui;

import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;

public enum Mode implements class_3542 {
    EXPOSURES("exposures"), TEXTURES("textures");

    private final String name;

    Mode(String name) {
        this.name = name;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }

    public static Mode fromSerializedString(String str) {
        for (Mode value : values()) {
            if (value.method_15434().equals(str))
                return value;
        }
        throw new IllegalArgumentException(str + " cannot be deserialized to Mode");
    }
}
