package io.github.mortuusars.exposure_catalog.client.gui;

import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;

public enum Order implements class_3542 {
    ASCENDING("ascending"), DESCENDING("descending");

    private final String name;

    Order(String name) {
        this.name = name;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }

    public static Order fromSerializedString(String str) {
        for (Order value : values()) {
            if (value.method_15434().equals(str))
                return value;
        }
        throw new IllegalArgumentException(str + " cannot be deserialized to Order");
    }

}
