package io.github.mortuusars.exposure_catalog.data;

import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.world.level.storage.ExposureData;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ExposureInfo(String id, int width, int height, class_2960 paletteId, ExposureData.Tag tag) {
    public static final ExposureInfo EMPTY = new ExposureInfo("", 0, 0, ColorPalettes.DEFAULT.method_29177(), ExposureData.Tag.EMPTY);

    public static final class_9139<class_2540, ExposureInfo> STREAM_CODEC = class_9139.method_56906(
            class_9135.field_48554, ExposureInfo::id,
            class_9135.field_48550, ExposureInfo::width,
            class_9135.field_48550, ExposureInfo::height,
            class_2960.field_48267, ExposureInfo::paletteId,
            ExposureData.Tag.STREAM_CODEC, ExposureInfo::tag,
            ExposureInfo::new
    );

    public static ExposureInfo empty(String exposureId) {
        return new ExposureInfo(exposureId, 0, 0, ColorPalettes.DEFAULT.method_29177(), ExposureData.Tag.EMPTY);
    }
}