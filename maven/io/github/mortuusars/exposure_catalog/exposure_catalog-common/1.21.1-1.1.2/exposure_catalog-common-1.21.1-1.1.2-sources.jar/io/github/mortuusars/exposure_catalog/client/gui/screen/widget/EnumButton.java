package io.github.mortuusars.exposure_catalog.client.gui.screen.widget;

import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.client.gui.Widgets;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7919;
import net.minecraft.class_8494;
import net.minecraft.class_8666;

public class EnumButton<T extends Enum<T>> extends class_4185 {
    protected final List<T> states;
    protected final Map<T, class_8666> sprites;
    protected final OnStateChanged<T> onStateChanged;

    protected int currentStateIndex;
    protected @Nullable Function<T, class_7919> tooltipFunc;
    protected @Nullable class_7919 defaultTooltip;

    public EnumButton(Class<T> enumClass, int x, int y, int width, int height, class_2960 sprite,
                      OnStateChanged<T> onStateChanged, class_2561 message) {
        super(x, y, width, height, message, b -> {}, n -> class_2561.method_43473());
        this.states = Arrays.asList(enumClass.getEnumConstants());
        this.sprites = new HashMap<>();
        this.onStateChanged = onStateChanged;
        this.currentStateIndex = 0;

        for (T state : states) {
            String name = state.name().toLowerCase();
            class_8666 sprites = Widgets.threeStateSprites(sprite.method_48331("_" + name));
            this.sprites.put(state, sprites);
        }
    }

    public T getState() {
        return states.get(currentStateIndex);
    }

    public void setState(T state) {
        setStateIndex(state.ordinal());
    }

    public void setStateIndex(int index) {
        Preconditions.checkElementIndex(index, states.size());
        currentStateIndex = index;
    }

    public void changeState(T state) {
        T previousState = getState();
        if (!previousState.equals(state)) {
            setState(state);
            onStateChanged.onStateChanged(this, previousState, state);
        }
    }

    public void changeStateIndex(int index) {
        int previousIndex = currentStateIndex;
        if (previousIndex != index) {
            setStateIndex(index);
            onStateChanged.onStateChanged(this, states.get(previousIndex), states.get(index));
        }
    }

    public void previousState() {
        changeStateIndex((currentStateIndex - 1 + states.size()) % states.size());

    }

    public void nextState() {
        changeStateIndex((currentStateIndex + 1) % states.size());
    }

    public void setDefaultTooltip(@Nullable class_7919 tooltip) {
        this.defaultTooltip = tooltip;
    }

    public void setTooltipFunc(@Nullable Function<T, class_7919> tooltipFunc) {
        this.tooltipFunc = tooltipFunc;
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (method_25367()) {
            method_47400(tooltipFunc != null ? tooltipFunc.apply(getState()) : defaultTooltip);
        }

        class_8666 sprites = this.sprites.get(getState());
        class_2960 resourceLocation = sprites.method_52729(method_37303(), method_25367());
        guiGraphics.method_52706(resourceLocation, this.method_46426(), this.method_46427(), this.field_22758, this.field_22759);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (method_37303() && method_25361(mouseX, mouseY)) {
            if (button == class_3675.field_32002) {
                previousState();
            } else {
                nextState();
            }

            method_25354(class_310.method_1551().method_1483());
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (method_37303() && method_25361(mouseX, mouseY)) {
            if (scrollY < 0) {
                previousState();
            } else {
                nextState();
            }

            method_25354(class_310.method_1551().method_1483());
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (method_37303() && class_8494.method_51255(keyCode)) {
            if (class_437.method_25442()) {
                previousState();
            } else {
                nextState();
            }

            method_25354(class_310.method_1551().method_1483());
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public interface OnStateChanged<T extends Enum<T>> {
        void onStateChanged(EnumButton<T> button, T previousState, T newState);
    }
}