package io.github.mortuusars.exposure_catalog;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2168;
import net.minecraft.class_3222;

public class Permissions {
    public final static String CATALOG_COMMAND = "exposure_catalog.command.catalog";

    public static boolean canUseCatalog(class_2168 stack) {
        try {
            return canUseCatalog(stack.method_9207());
        } catch (CommandSyntaxException e) {
            return false;
        }
    }

    public static boolean canUseCatalog(class_3222 player) {
        //noinspection ConstantValue
        return player.method_5687(3) || PlatformHelper.checkCatalogCommandPermission(player);
    }
}