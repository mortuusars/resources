package io.github.mortuusars.exposure_catalog.network.packet.clientbound;

import io.github.mortuusars.exposure_catalog.ExposureCatalog;
import io.github.mortuusars.exposure_catalog.data.ExposureInfo;
import io.github.mortuusars.exposure_catalog.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure_catalog.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SendExposureInfosS2CP(List<ExposureInfo> exposures) implements Packet {
    public static final class_2960 ID = ExposureCatalog.resource("send_exposure_infos");
    public static final class_9154<SendExposureInfosS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, SendExposureInfosS2CP> STREAM_CODEC = class_9139.method_56434(
            ExposureInfo.STREAM_CODEC.method_56433(class_9135.method_56363()), SendExposureInfosS2CP::exposures,
            SendExposureInfosS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.receiveExposureInfos(this);
        return true;
    }
}