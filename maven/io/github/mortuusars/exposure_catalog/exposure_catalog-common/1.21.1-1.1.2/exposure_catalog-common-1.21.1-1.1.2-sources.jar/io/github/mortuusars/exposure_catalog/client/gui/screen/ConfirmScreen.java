package io.github.mortuusars.exposure_catalog.client.gui.screen;

import io.github.mortuusars.exposure_catalog.ExposureCatalog;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;

public class ConfirmScreen extends class_437 implements OverlayScreen {
    public static final class_2960 TEXTURE = ExposureCatalog.resource("textures/gui/confirm.png");

    protected final class_437 parent;
    protected final class_2561 message;
    protected final class_2561 yesButtonMsg;
    protected final class_4185.class_4241 onYesButtonPress;
    protected final class_2561 noButtonMsg;
    protected final class_4185.class_4241 onNoButtonPress;

    protected int imageWidth;
    protected int imageHeight;
    protected int leftPos;
    protected int topPos;
    private class_4185 yesButton;
    private class_4185 noButton;

    public ConfirmScreen(class_437 parent, class_2561 message, class_2561 yesButtonMsg, class_4185.class_4241 onYesButtonPress,
                         class_2561 noButtonMsg, class_4185.class_4241 onNoButtonPress) {
        super(class_2561.method_43473());
        this.parent = parent;
        this.message = message;
        this.yesButtonMsg = yesButtonMsg;
        this.onYesButtonPress = onYesButtonPress;
        this.noButtonMsg = noButtonMsg;
        this.onNoButtonPress = onNoButtonPress;
    }

    @Override
    protected void method_25426() {
        this.imageWidth = 240;
        this.imageHeight = 88;
        this.leftPos = field_22789 / 2 - imageWidth / 2;
        this.topPos = field_22790 / 2 - imageHeight / 2;

        yesButton = class_4185.method_46430(yesButtonMsg, button -> {
                    method_25419();
                    onYesButtonPress.onPress(button);
                })
                .method_46434(leftPos + 9, topPos + 60, 108, 19)
                .method_46431();
        method_37063(yesButton);

        noButton = class_4185.method_46430(noButtonMsg, button -> {
                    method_25419();
                    onNoButtonPress.onPress(button);
                })
                .method_46434(leftPos + 123, topPos + 60, 108, 19)
                .method_46431();
        method_37063(noButton);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        method_52752(guiGraphics);

        // Main texture
        guiGraphics.method_25293(TEXTURE, leftPos, topPos, imageWidth, imageHeight, 0, 0,
                imageWidth, imageHeight, 256, 256);

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        List<class_5481> messageLines = field_22793.method_1728(message, 221);
        int messageY = 28 - ((messageLines.size() * field_22793.field_2000) / 2);
        for (int i = 0; i < messageLines.size(); i++) {
            class_5481 messageLine = messageLines.get(i);
            guiGraphics.method_51430(field_22793, messageLine, leftPos + 120 - (field_22793.method_30880(messageLine) / 2), topPos + messageY + i * field_22793.field_2000, 0xFF414141, false);
        }
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {

    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (method_25399() == null && keyCode == class_3675.field_31957) {
            yesButton.method_25306();
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public class_437 getParent() {
        return parent;
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(getParent());
    }
}
