package io.github.mortuusars.exposure_catalog.network.packet.clientbound;

import io.github.mortuusars.exposure_catalog.ExposureCatalog;
import io.github.mortuusars.exposure_catalog.data.ExposureThumbnail;
import io.github.mortuusars.exposure_catalog.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure_catalog.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record SendExposureThumbnailS2CP(String id, ExposureThumbnail thumbnail) implements Packet {
    public static final class_2960 ID = ExposureCatalog.resource("send_exposure_thumbnail");
    public static final class_9154<SendExposureThumbnailS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, SendExposureThumbnailS2CP> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48554, SendExposureThumbnailS2CP::id,
            ExposureThumbnail.STREAM_CODEC, SendExposureThumbnailS2CP::thumbnail,
            SendExposureThumbnailS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.receiveExposureThumbnail(this);
        return true;
    }
}