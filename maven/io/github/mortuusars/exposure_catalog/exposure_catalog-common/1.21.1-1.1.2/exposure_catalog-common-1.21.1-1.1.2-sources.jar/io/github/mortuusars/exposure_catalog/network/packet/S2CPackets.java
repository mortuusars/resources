package io.github.mortuusars.exposure_catalog.network.packet;

import io.github.mortuusars.exposure_catalog.network.packet.clientbound.OpenCatalogS2CP;
import io.github.mortuusars.exposure_catalog.network.packet.clientbound.SendExposureInfosS2CP;
import io.github.mortuusars.exposure_catalog.network.packet.clientbound.SendExposureThumbnailS2CP;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class S2CPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
                new class_8710.class_9155<>(OpenCatalogS2CP.TYPE, OpenCatalogS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(SendExposureInfosS2CP.TYPE, SendExposureInfosS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(SendExposureThumbnailS2CP.TYPE, SendExposureThumbnailS2CP.STREAM_CODEC)
        );
    }
}