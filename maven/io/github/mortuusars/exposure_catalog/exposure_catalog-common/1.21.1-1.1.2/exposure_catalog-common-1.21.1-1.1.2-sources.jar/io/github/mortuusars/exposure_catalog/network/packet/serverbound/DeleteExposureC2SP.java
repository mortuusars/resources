package io.github.mortuusars.exposure_catalog.network.packet.serverbound;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure_catalog.Permissions;
import io.github.mortuusars.exposure_catalog.data.server.Catalog;
import io.github.mortuusars.exposure_catalog.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record DeleteExposureC2SP(String id) implements Packet {
    public static final class_2960 ID = Exposure.resource("delete_exposure");
    public static final class_8710.class_9154<DeleteExposureC2SP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, DeleteExposureC2SP> STREAM_CODEC = class_9139.method_56434(
            class_9135.field_48554, DeleteExposureC2SP::id,
            DeleteExposureC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        Preconditions.checkArgument(player instanceof class_3222, "Player is required for " + ID + " packet");
        class_3222 serverPlayer = (class_3222) player;

        if (!Permissions.canUseCatalog(serverPlayer)) {
            return true;
        }

        boolean deleted = Catalog.deleteExposure(id);
        String message = deleted ?
                "gui.exposure_catalog.catalog.exposure_deleted" :
                "gui.exposure_catalog.catalog.exposure_delete_failed";
        player.method_7353(class_2561.method_43469(message, id), false);

        return true;
    }
}