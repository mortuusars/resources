package io.github.mortuusars.exposure_catalog.client.gui.screen;

import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import net.minecraft.class_768;

public record Thumbnail(int index, int gridIndex, ExposureIdentifier identifier, class_768 area,
                        boolean selected) {
    public boolean isMouseOver(double mouseX, double mouseY) {
        return mouseX >= area.method_3321() && mouseX < area.method_3321() + area.method_3319()
                && mouseY >= area.method_3322() && mouseY < area.method_3322() + area.method_3320();
    }
}
