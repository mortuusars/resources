package io.github.mortuusars.exposure_catalog.network.packet.clientbound;

import io.github.mortuusars.exposure_catalog.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure_catalog.ExposureCatalog;
import io.github.mortuusars.exposure_catalog.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public final class OpenCatalogS2CP implements Packet {
    public static final OpenCatalogS2CP INSTANCE = new OpenCatalogS2CP();

    public static final class_2960 ID = ExposureCatalog.resource("open_catalog");
    public static final class_8710.class_9154<OpenCatalogS2CP> TYPE = new class_8710.class_9154<>(ID);
    public static final class_9139<class_2540, OpenCatalogS2CP> STREAM_CODEC = class_9139.method_56431(INSTANCE);

    private OpenCatalogS2CP() { }

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.openCatalog(this);
        return true;
    }
}
