package io.github.mortuusars.exposure_catalog.network.packet;

import io.github.mortuusars.exposure_catalog.network.packet.serverbound.CatalogClosedC2SP;
import io.github.mortuusars.exposure_catalog.network.packet.serverbound.DeleteExposureC2SP;
import io.github.mortuusars.exposure_catalog.network.packet.serverbound.QueryExposureThumbnailC2SP;
import io.github.mortuusars.exposure_catalog.network.packet.serverbound.QueryExposuresC2SP;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class C2SPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
                new class_8710.class_9155<>(CatalogClosedC2SP.TYPE, CatalogClosedC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(QueryExposureThumbnailC2SP.TYPE, QueryExposureThumbnailC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(QueryExposuresC2SP.TYPE, QueryExposuresC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(DeleteExposureC2SP.TYPE, DeleteExposureC2SP.STREAM_CODEC)
        );
    }
}