package io.github.mortuusars.exposure_catalog.network.packet.serverbound;

import io.github.mortuusars.exposure_catalog.ExposureCatalog;
import io.github.mortuusars.exposure_catalog.data.ExposureThumbnail;
import io.github.mortuusars.exposure_catalog.data.server.Catalog;
import io.github.mortuusars.exposure_catalog.network.Packets;
import io.github.mortuusars.exposure_catalog.network.packet.Packet;
import io.github.mortuusars.exposure_catalog.network.packet.clientbound.SendExposureThumbnailS2CP;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public record QueryExposureThumbnailC2SP(String id) implements Packet {
    public static final class_2960 ID = ExposureCatalog.resource("query_exposure_thumbnail");
    public static final class_8710.class_9154<QueryExposureThumbnailC2SP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, QueryExposureThumbnailC2SP> STREAM_CODEC = class_9139.method_56434(
            class_9135.field_48554, QueryExposureThumbnailC2SP::id,
            QueryExposureThumbnailC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        class_3222 serverPlayer = (class_3222) player;

        @Nullable ExposureThumbnail thumbnail = Catalog.getCache().getThumbnails().get(id);
        if (thumbnail != null) {
            Packets.sendToClient(new SendExposureThumbnailS2CP(id, thumbnail), serverPlayer);
        }

        return true;
    }
}