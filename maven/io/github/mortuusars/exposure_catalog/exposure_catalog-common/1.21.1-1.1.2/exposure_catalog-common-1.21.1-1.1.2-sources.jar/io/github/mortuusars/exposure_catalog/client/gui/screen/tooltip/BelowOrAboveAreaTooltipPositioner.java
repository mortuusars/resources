package io.github.mortuusars.exposure_catalog.client.gui.screen.tooltip;

import net.minecraft.class_768;
import net.minecraft.class_8000;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector2i;
import org.joml.Vector2ic;

public class BelowOrAboveAreaTooltipPositioner implements class_8000 {
    private final class_768 area;

    public BelowOrAboveAreaTooltipPositioner(class_768 area) {
        this.area = area;
    }

    @Override
    public @NotNull Vector2ic method_47944(int screenWidth, int screenHeight, int mouseX, int mouseY, int tooltipWidth, int tooltipHeight) {
        Vector2i vector2i = new Vector2i();
        vector2i.x = this.area.method_3321() + 8;
        vector2i.y = this.area.method_3322() + this.area.method_3320() + 8 + 1;
        if (vector2i.y + tooltipHeight + 3 > screenHeight) {
            vector2i.y = this.area.method_3322() - tooltipHeight - 8 - 1;
        }
        if (vector2i.x + tooltipWidth > screenWidth) {
            vector2i.x = Math.max(this.area.method_3321() + this.area.method_3319() - tooltipWidth - 8, 4);
        }
        return vector2i;
    }
}