package io.github.mortuusars.exposure_catalog.client.gui;

import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;

public enum Sorting implements class_3542 {
    ALPHABETICAL("alphabetical"), DATE("date");

    private final String name;

    Sorting(String name) {
        this.name = name;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }

    public static Sorting fromSerializedString(String str) {
        for (Sorting value : values()) {
            if (value.method_15434().equals(str))
                return value;
        }
        throw new IllegalArgumentException(str + " cannot be deserialized to Sorting");
    }

}
