package io.github.mortuusars.exposure_catalog.client.gui.screen;

import net.minecraft.class_437;

public interface OverlayScreen {
    class_437 getParent();
}