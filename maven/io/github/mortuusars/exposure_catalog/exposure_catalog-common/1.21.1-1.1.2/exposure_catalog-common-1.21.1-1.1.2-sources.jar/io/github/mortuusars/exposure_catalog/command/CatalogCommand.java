package io.github.mortuusars.exposure_catalog.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.exposure_catalog.Permissions;
import io.github.mortuusars.exposure_catalog.network.Packets;
import io.github.mortuusars.exposure_catalog.network.packet.clientbound.OpenCatalogS2CP;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

public class CatalogCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                class_2170.method_9247("exposure")
                        .then(class_2170.method_9247("catalog")
                                .requires(Permissions::canUseCatalog)
                                .executes(CatalogCommand::openCatalog)));
    }

    private static int openCatalog(CommandContext<class_2168> context) throws CommandSyntaxException {
        Packets.sendToClient(OpenCatalogS2CP.INSTANCE, context.getSource().method_9207());
        return 0;
    }
}
