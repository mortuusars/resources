package io.github.mortuusars.exposure_catalog.client.gui.screen;

import com.google.common.collect.Lists;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.client.gui.Widgets;
import io.github.mortuusars.exposure.client.gui.screen.album.ChildPhotographScreen;
import io.github.mortuusars.exposure.client.image.PalettedImage;
import io.github.mortuusars.exposure.client.image.renderable.RenderableImage;
import io.github.mortuusars.exposure.client.render.image.RenderCoordinates;
import io.github.mortuusars.exposure.client.task.ExportExposuresTask;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.data.export.ExportLook;
import io.github.mortuusars.exposure.data.export.ExportSize;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import io.github.mortuusars.exposure.world.item.util.ItemAndStack;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import io.github.mortuusars.exposure_catalog.ExposureCatalog;
import io.github.mortuusars.exposure_catalog.client.gui.screen.widget.EnumButton;
import io.github.mortuusars.exposure_catalog.data.ExposureInfo;
import io.github.mortuusars.exposure_catalog.data.client.CatalogClient;
import io.github.mortuusars.exposure_catalog.client.gui.Mode;
import io.github.mortuusars.exposure_catalog.client.gui.Order;
import io.github.mortuusars.exposure_catalog.client.gui.Sorting;
import io.github.mortuusars.exposure_catalog.client.gui.screen.tooltip.BelowOrAboveAreaTooltipPositioner;
import io.github.mortuusars.exposure_catalog.network.Packets;
import io.github.mortuusars.exposure_catalog.network.packet.serverbound.CatalogClosedC2SP;
import io.github.mortuusars.exposure_catalog.network.packet.serverbound.DeleteExposureC2SP;
import io.github.mortuusars.exposure_catalog.network.packet.serverbound.QueryExposuresC2SP;
import net.minecraft.class_1109;
import net.minecraft.class_1129;
import net.minecraft.class_1144;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_344;
import net.minecraft.class_3518;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4597;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_765;
import net.minecraft.class_768;
import net.minecraft.class_7919;
import net.minecraft.class_8494;
import net.minecraft.class_8666;
import net.minecraft.client.gui.components.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class CatalogScreen extends class_437 {
    public static final class_8666 REFRESH_BUTTON_SPRITES = Widgets.threeStateSprites(ExposureCatalog.resource("refresh"));
    public static final class_8666 EXPORT_BUTTON_SPRITES = Widgets.threeStateSprites(ExposureCatalog.resource("export"));
    public static final class_8666 EXPORT_STOP_BUTTON_SPRITES = Widgets.threeStateSprites(ExposureCatalog.resource("export_stop"));
    public static final class_8666 DELETE_BUTTON_SPRITES = Widgets.threeStateSprites(ExposureCatalog.resource("delete"));

    public static final class_2960 TEXTURE = ExposureCatalog.resource("textures/gui/catalog.png");
    public static final int TEX_SIZE = 512;
    public static final int ROWS = 4;
    public static final int COLS = 6;

    protected static final int SCROLL_THUMB_TOP_HEIGHT = 3;
    protected static final int SCROLL_THUMB_MID_HEIGHT = 4;
    protected static final int SCROLL_THUMB_BOT_HEIGHT = 2;

    public static final int REFRESH_COOLDOWN_MS = 500; // 0.5 seconds
    public static final int RELOAD_COOLDOWN_MS = 5000; // 5 seconds

    protected final File stateFile = new File(class_310.method_1551().field_1697, "exposure_catalog_state.json");

    protected int imageWidth;
    protected int imageHeight;
    protected int leftPos;
    protected int topPos;
    protected class_768 windowArea = new class_768(0, 0, 361, 265);
    protected class_768 scrollBarArea = new class_768(343, 22, 10, 221);
    protected class_768 searchBarArea = new class_768(219, 7, 118, 10);
    protected class_768 thumbnailsArea = new class_768(8, 22, 329, 221);

    protected EnumButton<Order> orderButton;
    protected EnumButton<Sorting> sortingButton;
    protected class_342 searchBox;
    protected EnumButton<Mode> modeButton;
    protected class_768 scrollThumb = new class_768(0, 0, 0, 0);
    protected List<Thumbnail> thumbnails = Collections.synchronizedList(new ArrayList<>());
    protected class_4185 refreshButton;
    protected class_4185 exportButton;
    protected class_4185 exportStopButton;
    protected class_4185 deleteButton;

    protected Mode mode = Mode.EXPOSURES;
    protected Order order = Order.ASCENDING;
    protected Sorting sorting = Sorting.DATE;
    protected ExportSize exportSize = ExportSize.X1;
    protected ExportLook exportLook = ExportLook.REGULAR;

    protected boolean isLoading;
    protected boolean haveExposures = true;

    protected List<String> exposures = new ArrayList<>();
    protected List<String> textures = Collections.emptyList();

    protected ArrayList<String> filteredItems = new ArrayList<>();

    protected SelectionHandler selection = new SelectionHandler();

    protected int totalRows = 0;

    protected int topRowIndex = 0;
    protected boolean isThumbnailsGridFocused;

    protected int focusedThumbnailIndex;
    protected boolean isDraggingScrollbar = false;

    protected int topRowIndexAtDragStart = 0;
    protected double dragDelta = 0;
    protected boolean initialized;

    protected long refreshCooldownExpireTime = 0;
    protected long lastScrolledTime = 0;

    public CatalogScreen() {
        super(class_2561.method_43471("gui.exposure_catalog.catalog"));
    }

    public void onExposuresReceived(Map<String, ExposureInfo> exposuresList) {
        isLoading = false;
        haveExposures = !exposuresList.isEmpty();

        exposures = new ArrayList<>(exposuresList.keySet().stream().toList());
        orderAndSortExposuresList(this.order, this.sorting);

        if (mode == Mode.EXPOSURES) {
            topRowIndex = 0;
            refreshSearchResults();
        }
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.imageWidth = windowArea.method_3319();
        this.imageHeight = windowArea.method_3320();
        this.leftPos = field_22789 / 2 - imageWidth / 2;
        this.topPos = field_22790 / 2 - imageHeight / 2;

        scrollBarArea = new class_768(leftPos + 343, topPos + 22, 10, 221);
        searchBarArea = new class_768(leftPos + 219, topPos + 7, 118, 10);
        thumbnailsArea = new class_768(leftPos + 8, topPos + 22, 329, 221);

        orderButton = new EnumButton<>(Order.class, leftPos + 188, topPos + 6, 12, 12,
                ExposureCatalog.resource("order"), (b, prev, current) -> changeOrder(current),
                class_2561.method_43471("gui.exposure_catalog.catalog.order")) {
            @Override
            public void method_25354(class_1144 handler) {
                playClickSound();
            }
        };
        orderButton.setTooltipFunc(value -> {
            class_5250 component = class_2561.method_43471("gui.exposure_catalog.catalog.order");

            for (Order v : Order.values()) {
                component.method_27693("\n ");
                component.method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.order." + v.method_15434())
                        .method_27696(class_2583.field_24360.method_36139(value == v ? 0x6677FF : 0x444444)));
            }

            return class_7919.method_47407(component);
        });
        method_37063(orderButton);

        sortingButton = new EnumButton<>(Sorting.class, leftPos + 203, topPos + 6, 12, 12,
                ExposureCatalog.resource("sorting"), (b, prev, current) -> changeSorting(current),
                class_2561.method_43471("gui.exposure_catalog.catalog.sorting")) {
            @Override
            public void method_25354(class_1144 handler) {
                playClickSound();
            }
        };
        sortingButton.setTooltipFunc(value -> {
            class_5250 component = class_2561.method_43471("gui.exposure_catalog.catalog.sorting");

            for (Sorting v : Sorting.values()) {
                component.method_27693("\n ");
                component.method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.sorting." + v.method_15434())
                        .method_27696(class_2583.field_24360.method_36139(value == v ? 0x6677FF : 0x444444)));
            }

            return class_7919.method_47407(component);
        });
        method_37063(sortingButton);

        searchBox = new class_342(field_22793, searchBarArea.method_3321() + 1, searchBarArea.method_3322() + 1, searchBarArea.method_3319(), field_22793.field_2000, class_2561.method_43471("itemGroup.search"));
        searchBox.method_1880(99);
        searchBox.method_1858(false);
        searchBox.method_1862(true);
        searchBox.method_1868(0xFFFFFF);
        method_37063(searchBox);

        modeButton = new EnumButton<>(Mode.class, leftPos + 342, topPos + 6, 12, 12,
                ExposureCatalog.resource("mode"), (b, prev, current) -> changeMode(current),
                class_2561.method_43471("gui.exposure_catalog.catalog.mode")) {
            @Override
            public void method_25354(class_1144 handler) {
                playClickSound();
            }
        };
        modeButton.setTooltipFunc(value -> {
            class_5250 component = class_2561.method_43471("gui.exposure_catalog.catalog.mode")
                    .method_27693(" ")
                    .method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.mode.hotkey"));

            for (Mode v : Mode.values()) {
                component.method_27693("\n ");
                component.method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.mode." + v.method_15434())
                        .method_27696(class_2583.field_24360.method_36139(value == v ? 0x6677FF : 0x444444)));
            }

            return class_7919.method_47407(component);
        });
        method_37063(modeButton);

        refreshButton = new class_344(leftPos + 7, topPos + 247, 12, 12, REFRESH_BUTTON_SPRITES, b -> refresh());
        refreshButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure_catalog.catalog.refresh")
                .method_27693(" ")
                .method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.refresh.hotkey"))
                .method_27693("\n")
                .method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.refresh.tooltip"))));
        method_37063(refreshButton);

        exportButton = new class_344(leftPos + 26, topPos + 247, 12, 12, EXPORT_BUTTON_SPRITES, b -> exportExposures()) {
            @Override
            public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
                if (method_25367()) {
                    method_47400(class_7919.method_47407(createExportButtonTooltip()));
                }
                super.method_48579(guiGraphics, mouseX, mouseY, partialTick);
            }

            @Override
            public boolean method_25402(double mouseX, double mouseY, int button) {
                if (!method_25367() || !this.field_22763 || !this.field_22764)
                    return super.method_25402(mouseX, mouseY, button);

                if (class_437.method_25441()) {
                    exportSize = ExportSize.values()[(exportSize.ordinal() + 1) % ExportSize.values().length];
                    playClickSound();
                    return true;
                }

                if (class_437.method_25442()) {
                    exportLook = ExportLook.values()[(exportLook.ordinal() + 1) % ExportLook.values().length];
                    playClickSound();
                    return true;
                }

                return super.method_25402(mouseX, mouseY, button);
            }

            @Override
            public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
                if (!method_25367() || !this.field_22763 || !this.field_22764) {
                    return super.method_25401(mouseX, mouseY, scrollX, scrollY);
                }

                if (class_437.method_25441()) {
                    int newValue = exportSize.ordinal() - (int) scrollY;
                    if (newValue < 0)
                        newValue = ExportSize.values().length - 1;
                    else if (newValue >= ExportSize.values().length)
                        newValue = 0;

                    if (exportSize != ExportSize.values()[newValue]) {
                        playClickSound();
                        exportSize = ExportSize.values()[newValue];
                    }
                    return true;
                }

                if (class_437.method_25442()) {
                    int newValue = exportLook.ordinal() - (int) scrollY;
                    if (newValue < 0)
                        newValue = ExportLook.values().length - 1;
                    else if (newValue >= ExportLook.values().length)
                        newValue = 0;

                    if (exportLook != ExportLook.values()[newValue]) {
                        playClickSound();
                        exportLook = ExportLook.values()[newValue];
                    }
                    return true;
                }

                return super.method_25401(mouseX, mouseY, scrollX, scrollY);
            }

            @Override
            public boolean method_25404(int keyCode, int scanCode, int modifiers) {
                if (!method_25367() || !this.field_22763 || !this.field_22764)
                    return super.method_25404(keyCode, scanCode, modifiers);

                if (class_8494.method_51255(keyCode) && class_437.method_25441()) {
                    exportSize = ExportSize.values()[(exportSize.ordinal() + 1) % ExportSize.values().length];
                    playClickSound();
                    return true;
                }

                if (class_8494.method_51255(keyCode) && class_437.method_25442()) {
                    exportLook = ExportLook.values()[(exportLook.ordinal() + 1) % ExportLook.values().length];
                    playClickSound();
                    return true;
                }

                return super.method_25404(keyCode, scanCode, modifiers);
            }
        };
        exportButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure_catalog.catalog.export")));
        method_37063(exportButton);

        exportStopButton = new class_344(leftPos + 26, topPos + 247, 12, 12, EXPORT_STOP_BUTTON_SPRITES, b -> ExportExposuresTask.stopCurrentTask());
        exportStopButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure_catalog.catalog.export_stop")
                .method_27693(" ")
                .method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.export.hotkey"))));
        method_37063(exportStopButton);

        deleteButton = new class_344(leftPos + 342, topPos + 247, 12, 12, DELETE_BUTTON_SPRITES, b -> deleteExposures());
        deleteButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure_catalog.catalog.delete")
                .method_27693(" ")
                .method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.delete.hotkey"))
                .method_27693("\n")
                .method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.delete.tooltip"))));
        method_37063(deleteButton);

        if (!initialized) {
            loadState();
            ExposureClient.exposureStore().clear();
            Packets.sendToServer(new QueryExposuresC2SP(false));
            isLoading = true;

            if (mode == Mode.TEXTURES) {
                refresh();
            }

            initialized = true;
        }

        updateElements();
    }

    protected void playClickSound() {
        class_310.method_1551().method_1483().method_4873(class_1109.method_4757(
                Exposure.SoundEvents.CAMERA_DIAL_CLICK.get(), 1f, 0.8f));
    }

    protected class_2561 createExportButtonTooltip() {
        class_5250 tooltip = class_2561.method_43471("gui.exposure_catalog.catalog.export." +
                        (selection.isEmpty() || selection.size() == exposures.size() ? "all" : "selected"))
                .method_27693(" ")
                .method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.export.hotkey"));

        tooltip.method_27693("\n");
        tooltip.method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.export.location_info"));

        tooltip.method_27693("\n")
                .method_27693("\n")
                .method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.export.size"));

        for (ExportSize size : ExportSize.values()) {
            tooltip.method_27693("\n");
            tooltip.method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.export.size." + size.method_15434())
                    .method_27696(class_2583.field_24360.method_36139(exportSize == size ? 0x6677FF : 0x444444)));
        }

        tooltip.method_27693("\n")
                .method_27693("\n")
                .method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.export.look"));

        for (ExportLook look : ExportLook.values()) {
            tooltip.method_27693("\n")
                    .method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.export.look." + look.method_15434())
                            .method_27696(class_2583.field_24360.method_36139(exportLook == look ? 0x6677FF : 0x444444)));
        }

        tooltip.method_27693("\n")
                .method_27693("\n")
                .method_10852(class_2561.method_43471("gui.exposure_catalog.catalog.export.control_info"));

        return tooltip;
    }

    protected boolean canRefresh() {
        if (mode == Mode.TEXTURES)
            return true;

        if (mode == Mode.EXPOSURES && isLoading)
            return false;

        return class_156.method_658() >= refreshCooldownExpireTime;
    }

    protected void refresh() {
        if (!canRefresh())
            return;

        if (mode == Mode.EXPOSURES) {
            ExposureClient.exposureStore().clear();
            boolean reload = class_437.method_25442();
            Packets.sendToServer(new QueryExposuresC2SP(reload));
            if (reload) {
                isLoading = true;
                CatalogClient.clear();
            }
            refreshCooldownExpireTime = class_156.method_658() + (reload ? RELOAD_COOLDOWN_MS : REFRESH_COOLDOWN_MS);
        } else if (mode == Mode.TEXTURES) {
            Map<class_2960, class_3298> resources = class_310.method_1551().method_1478().method_14488("textures", rl -> true);
            textures = resources.keySet().stream().map(class_2960::toString).collect(Collectors.toCollection(ArrayList::new));
            orderTexturesList(this.order);
            refreshSearchResults();
            updateElements();
        }
    }

    protected void exportExposures() {
        if (mode == Mode.TEXTURES)
            return;

        List<String> exposureIds = !selection.isEmpty()
                ? selection.get().stream().map(i -> filteredItems.get(i)).toList()
                : filteredItems;

        if (exposureIds.size() > 100) {
            class_2561 message = class_2561.method_43469("gui.exposure_catalog.catalog.confirm.message.export_all", exposureIds.size());
            class_437 confirmScreen = new ConfirmScreen(this, message, class_5244.field_24336,
                    b -> exportExposures(exposureIds, exportSize, exportLook), class_5244.field_24337, b -> {
            });
            class_310.method_1551().method_1507(confirmScreen);
        } else {
            exportExposures(exposureIds, exportSize, exportLook);
        }
    }

    protected void exportExposures(List<String> exposureIds, ExportSize size, ExportLook look) {
        ExportExposuresTask.start(exposureIds, size, look);
    }

    protected void deleteExposures() {
        if (mode != Mode.EXPOSURES || selection.isEmpty() || filteredItems.isEmpty())
            return;

        if (class_437.method_25442())
            deleteExposuresNoConfirm();
        else {
            class_2561 message;
            if (selection.size() == 1) {
                String exposureId = filteredItems.get(selection.get().iterator().next());
                message = class_2561.method_43469("gui.exposure_catalog.catalog.confirm.message.delete_one", exposureId);
            } else {
                message = class_2561.method_43469("gui.exposure_catalog.catalog.confirm.message.delete_many", selection.size());
            }

            class_437 confirmScreen = new ConfirmScreen(this, message, class_5244.field_24336,
                    b -> deleteExposuresNoConfirm(), class_5244.field_24337, b -> {
            });
            class_310.method_1551().method_1507(confirmScreen);
        }
    }

    protected void deleteExposuresNoConfirm() {
        if (mode != Mode.EXPOSURES || selection.isEmpty() || filteredItems.isEmpty())
            return;

        ArrayList<String> removedIds = new ArrayList<>();

        for (Integer index : selection.get()) {
            if (index < 0 || index >= filteredItems.size())
                continue;

            String exposureId = filteredItems.get(index);
            Packets.sendToServer(new DeleteExposureC2SP(exposureId));
            removedIds.add(exposureId);
        }

        //noinspection RedundantOperationOnEmptyContainer
        for (String id : removedIds) {
            exposures.remove(id);
            filteredItems.remove(id);
            CatalogClient.removeExposure(id);
            scrollTo(topRowIndex);
        }

        selection.clear();

        if (isThumbnailsGridFocused) {
            int globalIndex = focusedThumbnailIndex + (topRowIndex * COLS);
            if (globalIndex >= 0 && globalIndex < filteredItems.size() - 1)
                selection.select(globalIndex);
        }

        updateElements();
    }

    protected void updateButtons() {
        orderButton.setState(order);
        sortingButton.setState(sorting);
        modeButton.setState(mode);

        sortingButton.field_22763 = mode == Mode.EXPOSURES;

        exportButton.field_22764 = mode == Mode.EXPOSURES && !ExportExposuresTask.isRunning();
        exportButton.field_22763 = mode == Mode.EXPOSURES && !ExportExposuresTask.isRunning();
        exportStopButton.field_22764 = ExportExposuresTask.isRunning();
        exportStopButton.field_22763 = ExportExposuresTask.isRunning();
        deleteButton.field_22763 = mode == Mode.EXPOSURES && !selection.isEmpty();

        refreshButton.field_22763 = canRefresh();
    }

    protected void changeMode(Mode mode) {
        this.mode = mode;

        if ((mode == Mode.EXPOSURES && exposures.isEmpty()) ||
                (mode == Mode.TEXTURES && textures.isEmpty())) {
            refresh();
        }

        updateButtons();
        refreshSearchResults();
    }

    protected void changeOrder(Order order) {
        this.order = order;

        if (mode == Mode.EXPOSURES) {
            orderAndSortExposuresList(this.order, this.sorting);
        } else {
            orderTexturesList(this.order);
        }

        updateButtons();
        refreshSearchResults();
    }

    protected void changeSorting(Sorting sorting) {
        this.sorting = sorting;

        if (mode == Mode.EXPOSURES) {
            orderAndSortExposuresList(this.order, this.sorting);
        }

        updateButtons();
        refreshSearchResults();
    }

    protected void orderAndSortExposuresList(Order order, Sorting sorting) {
        exposures.sort(Comparator.naturalOrder());

        if (sorting == Sorting.DATE) {
            Comparator<String> comparator = new Comparator<>() {
                @Override
                public int compare(String s1, String s2) {
                    return Long.compare(getTimestamp(s1), getTimestamp(s2));
                }

                private long getTimestamp(String exposureId) {
                    @Nullable ExposureInfo exposureInfo = CatalogClient.getExposures().get(exposureId);
                    return exposureInfo != null ? exposureInfo.tag().unixTimestamp() : 0L;
                }
            };

            exposures.sort(comparator);
        }

        if (order == Order.DESCENDING)
            Collections.reverse(exposures);
    }

    protected void orderTexturesList(Order order) {
        textures.sort(order == Order.ASCENDING ? Comparator.naturalOrder() : Comparator.reverseOrder());
    }

    @Override
    protected void method_41843() {
        String searchBoxValue = searchBox.method_1882();
        super.method_41843();
        searchBox.method_1852(searchBoxValue);
    }

    protected void refreshSearchResults() {
        Collection<String> items = mode == Mode.EXPOSURES ? exposures : textures;
        String filter = searchBox != null ? searchBox.method_1882().trim() : "";
        String[] queries = filter.split("\\s+");

        filterSearchResults(items, queries, mode);

        this.totalRows = (int) Math.ceil(filteredItems.size() / (float) COLS);

        selection.clear();
        scroll(Integer.MIN_VALUE);
    }

    protected void filterSearchResults(Collection<String> items, String[] queries, Mode mode) {
        filteredItems.clear();

        if (queries.length == 0) {
            filteredItems.addAll(items);
            return;
        }

        List<String> filtered = new ArrayList<>(items);

        for (String query : queries) {
            if (query.isEmpty())
                continue;

            if (mode == Mode.EXPOSURES && (query.startsWith("=") || query.startsWith("!="))) {
                boolean negative = query.startsWith("!=");
                String filter = query.substring(negative ? 2 : 1);

                if (filter.isEmpty()) {
                    // Do nothing
                } else if ("printed".startsWith(filter)) {
                    filtered.removeIf(id -> !CatalogClient.getExposures().getOrDefault(id, ExposureInfo.EMPTY).tag().wasPrinted() ^ negative);
                } else if ("projected".startsWith(filter)) {
                    filtered.removeIf(id -> !CatalogClient.getExposures().getOrDefault(id, ExposureInfo.EMPTY).tag().loaded() ^ negative);
                } else if ("color".startsWith(filter)) {
                    filtered.removeIf(id -> CatalogClient.getExposures().getOrDefault(id, ExposureInfo.EMPTY).tag().type() != ExposureType.COLOR ^ negative);
                } else if ("bw".startsWith(filter)) {
                    filtered.removeIf(id -> CatalogClient.getExposures().getOrDefault(id, ExposureInfo.EMPTY).tag().type() != ExposureType.BLACK_AND_WHITE ^ negative);
                } else if (filter.startsWith("size:")) {
                    String sizeStr = filter.substring(5);
                    if (!sizeStr.isEmpty() && sizeStr.matches("^[0-9]+$")) {
                        int size = Integer.parseInt(sizeStr);
                        filtered.removeIf(id -> !(CatalogClient.getExposures().get(id).width() == size) ^ negative);
                    }
                } else if (filter.startsWith("palette:")) {
                    String palette = filter.substring(8).toLowerCase();

                    class_1129<String> tree = class_1129.plainText(filtered, id ->
                            CatalogClient.getExposures().get(id).paletteId().toString().lines());
                    ArrayList<String> matches = new ArrayList<>(tree.method_4810(palette));
                    if (negative) {
                        filtered.removeAll(matches);
                    } else {
                        filtered = matches;
                    }
                } else {
                    filtered.clear();
                }
            } else {
                class_1129<String> tree = class_1129.plainText(filtered, String::lines);
                filtered = new ArrayList<>(tree.method_4810(query.toLowerCase(Locale.ROOT)));
            }
        }

        filteredItems.addAll(filtered);
    }

    public void updateThumbnailsGrid() {
        thumbnails.clear();

        for (int row = 0; row < ROWS; row++) {
            for (int column = 0; column < COLS; column++) {
                int gridIndex = column + row * COLS;
                int idIndex = gridIndex + this.topRowIndex * COLS;

                if (idIndex >= filteredItems.size())
                    break;

                int thumbnailX = column * 54;
                int thumbnailY = row * 54;

                String item = filteredItems.get(idIndex);
                ExposureIdentifier identifier = mode == Mode.EXPOSURES
                        ? ExposureIdentifier.id(item)
                        : ExposureIdentifier.texture(class_2960.method_60654(item));

                class_768 area = new class_768(thumbnailsArea.method_3321() + 5 + thumbnailX,
                        thumbnailsArea.method_3322() + 5 + thumbnailY, 48, 48);
                boolean isSelected = selection.get().contains(idIndex);
                Thumbnail thumbnail = new Thumbnail(idIndex, gridIndex, identifier, area, isSelected);
                thumbnails.add(thumbnail);
            }
        }

        focusedThumbnailIndex = class_3532.method_15340(focusedThumbnailIndex, 0, thumbnails.size() - 1);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();

        method_52752(guiGraphics);

        // Main texture
        guiGraphics.method_25293(TEXTURE, leftPos, topPos, imageWidth, imageHeight, 0, 0,
                imageWidth, imageHeight, TEX_SIZE, TEX_SIZE);

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        renderScrollBar(guiGraphics, mouseX, mouseY, partialTick);
        renderThumbnailsGrid(guiGraphics, mouseX, mouseY, partialTick);
        renderLabels(guiGraphics, mouseX, mouseY, partialTick);
        renderTooltip(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {

    }

    protected void renderThumbnailsGrid(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        for (Thumbnail thumbnail : thumbnails) {
            class_4597.class_4598 bufferSource = class_310.method_1551().method_22940().method_23000();

            RenderableImage image = getThumbnailImage(thumbnail);
            RenderCoordinates coords = new RenderCoordinates(thumbnail.area().method_3321(), thumbnail.area().method_3322(),
                    thumbnail.area().method_3319(), thumbnail.area().method_3320());

            ExposureClient.imageRenderer().render(image, guiGraphics.method_51448(), bufferSource, coords, class_765.field_32767, 255, 255, 255, 255);

            bufferSource.method_22993();

            int frameVOffset = thumbnail.selected() ? 108 :
                    thumbnail.isMouseOver(mouseX, mouseY) ? 54 : 0;

            RenderSystem.enableBlend();
            // Frame overlay
            guiGraphics.method_25290(TEXTURE, thumbnail.area().method_3321() - 3, thumbnail.area().method_3322() - 3, 371, frameVOffset,
                    54, 54, 512, 512);
            RenderSystem.disableBlend();
        }
    }

    protected RenderableImage getThumbnailImage(Thumbnail thumbnail) {
        if (thumbnail.identifier().isTexture() || class_310.method_1551().method_47392()) {
            // Loading full size images is ok in singleplayer
            return ExposureClient.renderedExposures().getOrCreateRaw(thumbnail.identifier());
        }

        String id = thumbnail.identifier().getId().orElseThrow();

        return (class_156.method_658() - lastScrolledTime < 250 ?
                CatalogClient.getThumbnail(id) : CatalogClient.getOrQueryThumbnail(id))
                .map(thumb -> new PalettedImage(thumb.width(), thumb.height(), thumb.pixels(), thumb.paletteId()))
                .map(img -> RenderableImage.of("thumbnail_" + id, img))
                .orElse(RenderableImage.EMPTY);
    }

    protected void renderTooltip(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (searchBox.method_25405(mouseX, mouseY)) {
            List<class_2561> lines = new ArrayList<>();

            lines.add(class_2561.method_43471("gui.exposure_catalog.searchbar")
                    .method_27693(" ")
                    .method_10852(class_2561.method_43471("gui.exposure_catalog.searchbar.hotkey")));

            if (class_437.method_25442()) {
                lines.add(class_2561.method_43471("gui.exposure_catalog.searchbar.tooltip.size"));
                lines.add(class_2561.method_43471("gui.exposure_catalog.searchbar.tooltip.palette"));
                lines.add(class_2561.method_43471("gui.exposure_catalog.searchbar.tooltip.color"));
                lines.add(class_2561.method_43471("gui.exposure_catalog.searchbar.tooltip.bw"));
                lines.add(class_2561.method_43471("gui.exposure_catalog.searchbar.tooltip.printed"));
                lines.add(class_2561.method_43471("gui.exposure_catalog.searchbar.tooltip.projected"));
                lines.add(class_5244.field_39003);
                lines.add(class_2561.method_43471("gui.exposure_catalog.searchbar.tooltip.filters"));
                lines.add(class_2561.method_43471("gui.exposure_catalog.searchbar.tooltip.invert"));
            } else
                lines.add(class_2561.method_43471("gui.exposure_catalog.searchbar.tooltip.control_info"));

            guiGraphics.method_51437(field_22793, lines, Optional.empty(), mouseX, mouseY);
        }

        for (Thumbnail thumbnail : thumbnails) {
            if (thumbnail.isMouseOver(mouseX, mouseY)) {
                List<class_2561> lines = getThumbnailTooltipLines(thumbnail);
                guiGraphics.method_51437(field_22793, lines, Optional.empty(), mouseX, mouseY);
                break;
            }
            if (isThumbnailsGridFocused && thumbnail.gridIndex() == focusedThumbnailIndex) {
                List<class_2561> lines = getThumbnailTooltipLines(thumbnail);
                guiGraphics.method_51436(field_22793, Lists.transform(lines, class_2561::method_30937),
                        new BelowOrAboveAreaTooltipPositioner(thumbnail.area()), mouseX, mouseY);
                break;
            }
        }
    }

    @NotNull
    private List<class_2561> getThumbnailTooltipLines(Thumbnail thumbnail) {
        List<class_2561> lines = new ArrayList<>();
        lines.add(class_2561.method_43470(thumbnail.identifier().toValueString()));

        thumbnail.identifier().ifId(exposureId -> {
            @Nullable ExposureInfo exposureInfo = CatalogClient.getExposures().get(exposureId);
            if (exposureInfo != null) {
                long timestampSeconds = exposureInfo.tag().unixTimestamp();
                if (timestampSeconds > 0) {
                    Date date = new Date(timestampSeconds * 1000L);
                    String pattern = "yyyy-MM-dd HH:mm:ss";
                    SimpleDateFormat format = new SimpleDateFormat(pattern);
                    String format1 = format.format((date));
                    lines.add(class_2561.method_43470(format1).method_27692(class_124.field_1080));
                }

                lines.add(class_2561.method_43470(exposureInfo.width() + "x" + exposureInfo.height()).method_27692(class_124.field_1080));

                if (!exposureInfo.paletteId().equals(ColorPalettes.DEFAULT.method_29177())) {
                    lines.add(class_2561.method_43469("gui.exposure_catalog.catalog.tooltip.palette",
                            exposureInfo.paletteId().toString()).method_27692(class_124.field_1080));
                }

                if (exposureInfo.tag().wasPrinted())
                    lines.add(class_2561.method_43471("gui.exposure_catalog.catalog.tooltip.printed").method_27692(class_124.field_1080));
                if (exposureInfo.tag().loaded())
                    lines.add(class_2561.method_43471("gui.exposure_catalog.catalog.tooltip.projected").method_27692(class_124.field_1080));
            }
        });

        lines.add(class_2561.method_43473());
        if (class_437.method_25442()) {
            lines.add(class_2561.method_43471("gui.exposure_catalog.thumbnail.tooltip.view"));
            lines.add(class_2561.method_43471("gui.exposure_catalog.thumbnail.tooltip.selection"));
            lines.add(class_2561.method_43471("gui.exposure_catalog.thumbnail.tooltip.selection.shift"));
            lines.add(class_2561.method_43471("gui.exposure_catalog.thumbnail.tooltip.selection.clear"));
        } else {
            lines.add(class_2561.method_43471("gui.exposure_catalog.thumbnail.tooltip.control_info"));
        }
        return lines;
    }

    protected boolean isMouseOver(class_768 rect, double mouseX, double mouseY) {
        return mouseX >= rect.method_3321() && mouseX < rect.method_3321() + rect.method_3319()
                && mouseY >= rect.method_3322() && mouseY < rect.method_3322() + rect.method_3320();
    }

    protected void renderScrollBar(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int state = 0;
        if (!canScroll())
            state = 2;
        else if (isDraggingScrollbar || isMouseOver(scrollThumb, mouseX, mouseY))
            state = 1;

        int thumbStateOffset = SCROLL_THUMB_TOP_HEIGHT + SCROLL_THUMB_MID_HEIGHT + SCROLL_THUMB_BOT_HEIGHT;

        // Top
        guiGraphics.method_25290(TEXTURE, scrollThumb.method_3321(), scrollThumb.method_3322(),
                361, state * thumbStateOffset,
                scrollThumb.method_3319(), SCROLL_THUMB_TOP_HEIGHT, 512, 512);

        // Middle
        int middleParts = (scrollThumb.method_3320() - 3 - 2) / 4;
        for (int i = 0; i < middleParts; i++) {
            guiGraphics.method_25290(TEXTURE, scrollThumb.method_3321(), scrollThumb.method_3322() + i * 4 + 3,
                    361, SCROLL_THUMB_TOP_HEIGHT + state * thumbStateOffset,
                    scrollThumb.method_3319(), SCROLL_THUMB_MID_HEIGHT, 512, 512);
        }

        // Bottom
        guiGraphics.method_25290(TEXTURE, scrollThumb.method_3321(), scrollThumb.method_3322() + (middleParts * 4) + 3,
                361, SCROLL_THUMB_TOP_HEIGHT + SCROLL_THUMB_MID_HEIGHT + state * thumbStateOffset,
                scrollThumb.method_3319(), SCROLL_THUMB_BOT_HEIGHT, 512, 512);
    }

    protected void renderLabels(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        // Title
        class_2561 title = mode == Mode.EXPOSURES ? class_2561.method_43471("gui.exposure_catalog.catalog.exposures")
                : class_2561.method_43471("gui.exposure_catalog.catalog.textures");
        guiGraphics.method_51439(field_22793, title, leftPos + 8, topPos + 8, 0xFF414141, false);

        if (mode == Mode.EXPOSURES && !isLoading && !haveExposures) {
            class_2561 component = class_2561.method_43471("gui.exposure_catalog.catalog.no_exposures");
            int x = (thumbnailsArea.method_3321() + thumbnailsArea.method_3319() / 2) - field_22793.method_27525(component) / 2;
            int y = (thumbnailsArea.method_3322() + thumbnailsArea.method_3320() / 2) - 5;
            guiGraphics.method_51439(field_22793, component, x, y, 0xFF414141, false);
        }

        // Count
        if (isLoading && mode == Mode.EXPOSURES) {
            int dotAnimation = (int) (class_156.method_658() / 750 % 3) + 1;
            class_2561 component = class_2561.method_43471("gui.exposure_catalog.catalog.loading" + dotAnimation)
                    .method_27696(class_2583.field_24360.method_36139(0xFF414141));
            guiGraphics.method_51439(field_22793, component, leftPos + (imageWidth / 2) - (field_22793.method_27525(component) / 2),
                    topPos + 249, 0xFF414141, false);
        } else if (!filteredItems.isEmpty()) {
            String filteredCountStr = Integer.toString(filteredItems.size());

            class_2561 countComponent = class_2561.method_43470(filteredCountStr).method_27696(class_2583.field_24360.method_36139(0xFF414141));
            if (!selection.isEmpty()) {
                String selectedCountStr = Integer.toString(selection.size());
                countComponent = class_2561.method_43470(selectedCountStr).method_27696(class_2583.field_24360.method_36139(0xFF3858db))
                        .method_10852(class_2561.method_43470("/").method_27696(class_2583.field_24360.method_36139(0xFF414141)))
                        .method_10852(countComponent);
            }

            guiGraphics.method_51439(field_22793, countComponent, leftPos + (imageWidth / 2) - (field_22793.method_27525(countComponent) / 2),
                    topPos + 249, 0xFF414141, false);
        }

        // SearchBox placeholder text
        if (searchBox.method_1885() && !searchBox.method_25370() && searchBox.method_1882().isEmpty()) {
            guiGraphics.method_51439(field_22793, class_2561.method_43471("gui.exposure_catalog.catalog.search_bar_placeholder_text"),
                    searchBarArea.method_3321() + 2, searchBarArea.method_3322() + 1, 0xFFBEBEBE, false);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
//        if (getFocused() == searchBox && !searchBox.isMouseOver(mouseX, mouseY))
//            setFocused(null);

//        if (isThumbnailsGridFocused) {
        method_25395(null);
        isThumbnailsGridFocused = false;
//        }

        if (button == class_3675.field_32002 && searchBox.method_25405(mouseX, mouseY)) {
            String value = searchBox.method_1882();
            searchBox.method_1852("");
            if (!value.equals(searchBox.method_1882()))
                refreshSearchResults();

            method_25395(searchBox);

            return true;
        }

        if (super.method_25402(mouseX, mouseY, button))
            return true;

        if (button == class_3675.field_32001)
            return false;

        if (isMouseOver(thumbnailsArea, mouseX, mouseY)) {
            for (Thumbnail thumbnail : thumbnails) {
                if (!thumbnail.isMouseOver(mouseX, mouseY))
                    continue;

                if (class_437.method_25441() || button == class_3675.field_32002) {
                    if (class_437.method_25442()) {
                        int start = Math.min(thumbnail.index(), selection.getLastSelectedIndex());
                        int end = Math.max(thumbnail.index(), selection.getLastSelectedIndex());
                        for (int i = start; i <= end; i++) {
                            if (!selection.get().contains(i))
                                selection.select(i);
                        }
                    } else {
                        if (selection.get().contains(thumbnail.index()))
                            selection.remove(thumbnail.index());
                        else {
                            selection.select(thumbnail.index());
                        }
                    }
                    updateElements();
                } else {
                    openPhotographView(thumbnail.index());
                }

                return true;
            }

            if (!selection.isEmpty()) {
                selection.clear();
                updateThumbnailsGrid();
                return true;
            }
        }

        if (canScroll()) {
            if (isMouseOver(scrollThumb, mouseX, mouseY)) {
                this.method_25398(true);
                isDraggingScrollbar = true;
                dragDelta = 0;
                topRowIndexAtDragStart = topRowIndex;
                return true;
            } else if (isMouseOver(scrollBarArea, mouseX, mouseY)) {
                int direction = mouseY < scrollThumb.method_3322() ? -1 : 1;
                scroll(ROWS * direction);
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (!isDraggingScrollbar || button != class_3675.field_32000)
            return super.method_25403(mouseX, mouseY, button, dragX, dragY);

        dragDelta += dragY;

        double threshold = (double) scrollBarArea.method_3320() / Math.max(totalRows, 1);
        int rows = (int) (dragDelta / threshold);
        if (rows != 0 || topRowIndex != topRowIndexAtDragStart) {
            scrollTo(topRowIndexAtDragStart + rows);
        }

        return true;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        isDraggingScrollbar = false;
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (super.method_25401(mouseX, mouseY, scrollX, scrollY)) {
            return true;
        }

        scroll((int) -scrollY);
        return true;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == class_3675.field_31958 && (searchBox.method_25370() || isThumbnailsGridFocused)) {
            method_25395(null);
            isThumbnailsGridFocused = false;
            return true;
        }

        if (isThumbnailsGridFocused && keyCode == class_3675.field_31957) {
            openPhotographView(thumbnails.get(focusedThumbnailIndex).index());
            return true;
        }

        if (searchBox.method_20315() && keyCode != class_3675.field_31948) {
            String string = searchBox.method_1882();
            if (searchBox.method_25404(keyCode, scanCode, modifiers)) {
                if (!string.equals(searchBox.method_1882())) {
                    refreshSearchResults();
                }
                return true;
            } else if (keyCode != class_3675.field_31958)
                return true;
        }

        if (tabKeyPressed(keyCode)) return true;

        if (arrowKeysPressed(keyCode)) return true;

        if (keyCode == class_3675.field_31989) {
            selection.clear();
            selection.select(0);
            focusedThumbnailIndex = 0;
            scroll(Integer.MIN_VALUE);
            return true;
        }
        if (keyCode == class_3675.field_31988) {
            selection.clear();
            selection.select(filteredItems.size() - 1);
            focusedThumbnailIndex = filteredItems.size() - 1;
            scroll(Integer.MAX_VALUE);
            return true;
        }

        if (keyCode == class_3675.field_31987) {
            deleteExposures();
            return true;
        }

        if (class_437.method_25441()) {
            if (keyCode == class_3675.field_32020) {
                method_25395(searchBox);
                return true;
            }
            if (keyCode == class_3675.field_32027) {
                changeMode(Mode.values()[(mode.ordinal() + 1) % Mode.values().length]);
                playClickSound();
                return true;
            }
            if (keyCode == class_3675.field_31907) {
                if (canRefresh()) {
                    refresh();
                    playClickSound();
                }
                return true;
            }
            if (keyCode == class_3675.field_32019) {
                if (ExportExposuresTask.isRunning()) {
                    ExportExposuresTask.stopCurrentTask();
                } else {
                    exportExposures();
                }

                playClickSound();
                return true;
            }
            if (keyCode == class_3675.field_32015) {
                selection.clear();
                selection.select(IntStream.range(0, filteredItems.size()).boxed().toList());
                updateElements();
                playClickSound();
                return true;
            }
            if (keyCode == class_3675.field_32018) {
                if (!selection.isEmpty()) {
                    selection.clear();
                    updateElements();
                    playClickSound();
                }
                return true;
            }
        }

        if (class_310.method_1551().field_1690.field_1822.method_1417(keyCode, scanCode)) {
            this.method_25419();
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private boolean tabKeyPressed(int keyCode) {
        if (keyCode != class_3675.field_31948)
            return false;

        if (!filteredItems.isEmpty() && !class_437.method_25442() && method_25399() == modeButton) {
            method_25395(null);
            isThumbnailsGridFocused = true;
            focusedThumbnailIndex = 0;

            selection.clear();
            selection.select(focusedThumbnailIndex + (topRowIndex * COLS));
            updateElements();

            return true;
        } else if (!filteredItems.isEmpty() && class_437.method_25442() && method_25399() == refreshButton && !isThumbnailsGridFocused) {
            method_25395(null);
            isThumbnailsGridFocused = true;
            focusedThumbnailIndex = 0;

            selection.clear();
            selection.select(focusedThumbnailIndex + (topRowIndex * COLS));
            updateElements();

            return true;
        } else if (isThumbnailsGridFocused) {
            class_4185 newFocusTarget = class_437.method_25442() ? modeButton : refreshButton;
            method_25395(newFocusTarget);
            isThumbnailsGridFocused = false;

            if (selection.size() == 1 && selection.get().iterator().next() == focusedThumbnailIndex + (topRowIndex * COLS)) {
                selection.clear();
                updateElements();
            }

            return true;
        }
        return false;
    }

    private boolean arrowKeysPressed(int keyCode) {
        if (filteredItems.isEmpty() || !List.of(class_3675.field_31983, class_3675.field_31984,
                class_3675.field_31932, class_3675.field_31982).contains(keyCode))
            return false;

        if (!isThumbnailsGridFocused) {
            method_25395(null);
            isThumbnailsGridFocused = true;
            focusedThumbnailIndex = 0;
            selection.select(focusedThumbnailIndex + (topRowIndex * COLS));
            updateElements();
            return true;
        }

        Map<Integer, Integer> keys = Map.of(
                class_3675.field_31983, -1,
                class_3675.field_31984, 1,
                class_3675.field_31932, -COLS,
                class_3675.field_31982, COLS);
        int change = keys.get(keyCode);
        int oldIndex = focusedThumbnailIndex;
        int newIndex = focusedThumbnailIndex + change;

        if (newIndex < 0) {
            if (topRowIndex <= 0)
                return true;
            scroll(-1);
            newIndex += COLS;
        } else if (newIndex > (ROWS * COLS - 1)) {
            if (topRowIndex >= totalRows - ROWS)
                return true;
            scroll(1);
            newIndex -= COLS;
        }

        focusedThumbnailIndex = class_3532.method_15340(newIndex, 0, thumbnails.size() - 1);

        if (!class_437.method_25442())
            selection.clear();
        else {
            int lesser = Math.min(oldIndex, newIndex);
            int larger = Math.max(oldIndex, newIndex);
            for (int i = lesser; i <= larger; i++) {
                selection.select(i + (topRowIndex * COLS));
            }
        }

        selection.select(focusedThumbnailIndex + (topRowIndex * COLS));
        updateElements();

        return true;
    }

    protected void updateElements() {
        this.totalRows = (int) Math.ceil(filteredItems.size() / (float) COLS);

        updateScrollThumb();
        updateButtons();
        updateThumbnailsGrid();
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        if (searchBox.method_20315()) {
            String string = searchBox.method_1882();
            if (searchBox.method_25400(codePoint, modifiers)) {
                if (!string.equals(searchBox.method_1882())) {
                    refreshSearchResults();
                }
                return true;
            }
        }

        return false;
    }

    public boolean canScroll() {
        return totalRows > ROWS;
    }

    public void scroll(int rows) {
        scrollTo(topRowIndex + rows);
    }

    public void scrollTo(int row) {
        int maxRowWhenAtEnd = Math.max(0, (int) Math.ceil((filteredItems.size() - ROWS * COLS) / (float) COLS));
        topRowIndex = class_3532.method_15340(row, 0, maxRowWhenAtEnd);
        updateScrollThumb();
        updateThumbnailsGrid();
        lastScrolledTime = class_156.method_658();
    }

    protected void updateScrollThumb() {
        int minSize = SCROLL_THUMB_TOP_HEIGHT + SCROLL_THUMB_MID_HEIGHT + SCROLL_THUMB_BOT_HEIGHT;

        float ratio = ROWS / (float) Math.max(totalRows, 1);
        int size = class_3532.method_15340(class_3532.method_15386(scrollBarArea.method_3320() * ratio), minSize, scrollBarArea.method_3320());
        int midSize = size - SCROLL_THUMB_TOP_HEIGHT - SCROLL_THUMB_BOT_HEIGHT;
        int correctedMidSize = Math.max(midSize - (midSize % SCROLL_THUMB_MID_HEIGHT), SCROLL_THUMB_MID_HEIGHT);
        size = SCROLL_THUMB_TOP_HEIGHT + correctedMidSize + SCROLL_THUMB_BOT_HEIGHT;

        float topRowPos = (float) topRowIndex / Math.max(1, totalRows - ROWS);
        int pos = (int) class_3532.method_37959(topRowPos, 0f, 1f, 0f, scrollBarArea.method_3320() - size);

        scrollThumb = new class_768(scrollBarArea.method_3321(), scrollBarArea.method_3322() + pos, scrollBarArea.method_3319(), size);
    }

    protected void openPhotographView(int clickedIndex) {
        List<String> items = !selection.isEmpty()
                ? selection.get().stream().map(i -> filteredItems.get(i)).toList()
                : filteredItems;

        List<ItemAndStack<PhotographItem>> photographs = new ArrayList<>(items.stream().map(item -> {
            class_1799 stack = new class_1799(Exposure.Items.PHOTOGRAPH.get());

            ExposureIdentifier identifier = mode == Mode.EXPOSURES ?
                    ExposureIdentifier.id(item) :
                    ExposureIdentifier.texture(class_2960.method_60654(item));

            Frame frame = Frame.create().setIdentifier(identifier).toImmutable();
            stack.method_57379(Exposure.DataComponents.PHOTOGRAPH_FRAME, frame);

            return new ItemAndStack<PhotographItem>(stack);
        }).toList());

        String clickedId = filteredItems.get(clickedIndex);
        int clickedIdIndex = Math.max(0, items.indexOf(clickedId));

        Collections.rotate(photographs, -clickedIdIndex);

        ChildPhotographScreen screen = new ChildPhotographScreen(this, photographs);
        class_310.method_1551().method_1507(screen);
        Minecrft.get().method_1483()
                .method_4873(class_1109.method_4757(Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(),
                        Minecrft.level().method_8409().method_43057() * 0.2f + 1.3f, 0.75f));
    }

    @Override
    public void method_25419() {
        saveState();
        CatalogClient.clear();
        ExposureClient.exposureStore().clear();
        Packets.sendToServer(CatalogClosedC2SP.INSTANCE);
        super.method_25419();
    }

    protected void saveState() {
        JsonObject obj = new JsonObject();
        obj.addProperty("mode", mode.method_15434());
        obj.addProperty("order", order.method_15434());
        obj.addProperty("sorting", sorting.method_15434());
        obj.addProperty("export_size", exportSize.method_15434());
        obj.addProperty("export_look", exportLook.method_15434());

        try {
            try (FileWriter writer = new FileWriter(stateFile)) {
                new GsonBuilder().setPrettyPrinting().create().toJson(obj, writer);
            }
        } catch (Exception e) {
            LogUtils.getLogger().error("Cannot save catalog state: " + e);
        }
    }

    protected void loadState() {
        try {
            if (!Files.exists(stateFile.toPath()) || Files.size(stateFile.toPath()) == 0)
                return;

            try (FileReader reader = new FileReader(stateFile)) {
                JsonObject obj = class_3518.method_15255(reader);
                this.mode = Mode.fromSerializedString(obj.get("mode").getAsString());
                this.order = Order.fromSerializedString(obj.get("order").getAsString());
                this.sorting = Sorting.fromSerializedString(obj.get("sorting").getAsString());
                this.exportSize = ExportSize.byName(obj.get("export_size").getAsString());
                this.exportLook = ExportLook.byName(obj.get("export_look").getAsString());
            } catch (Exception e) {
                throw e;
            }
        } catch (Exception e) {
            LogUtils.getLogger().error("Cannot load catalog state: {}", e.toString());
        }
    }
}
