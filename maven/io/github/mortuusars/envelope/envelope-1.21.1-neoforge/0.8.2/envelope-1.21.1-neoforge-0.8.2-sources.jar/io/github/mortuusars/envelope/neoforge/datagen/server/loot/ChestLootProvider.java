package io.github.mortuusars.envelope.neoforge.datagen.server.loot;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.LetterContent;
import io.github.mortuusars.envelope.world.item.component.seal.SealSymbol;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import io.github.mortuusars.mortaar.resources.Resource;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.data.loot.LootTableSubProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.EitherHolder;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.SeededContainerLoot;
import net.minecraft.world.level.saveddata.maps.MapDecorationTypes;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.EmptyLootItem;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.entries.LootPoolSingletonContainer;
import net.minecraft.world.level.storage.loot.entries.NestedLootTable;
import net.minecraft.world.level.storage.loot.functions.ExplorationMapFunction;
import net.minecraft.world.level.storage.loot.functions.SetComponentsFunction;
import net.minecraft.world.level.storage.loot.functions.SetItemCountFunction;
import net.minecraft.world.level.storage.loot.functions.SetNameFunction;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;

public class ChestLootProvider implements LootTableSubProvider {
    protected final HolderLookup.Provider registries;

    public ChestLootProvider(HolderLookup.Provider registries) {
        this.registries = registries;
    }

    @Override
    public void generate(@NotNull BiConsumer<ResourceKey<LootTable>, LootTable.Builder> output) {
        collapsedMailHub(output);
        injects(output);
    }

    private void collapsedMailHub(@NotNull BiConsumer<ResourceKey<LootTable>, LootTable.Builder> output) {
        output.accept(
              Envelope.LootTables.COLLAPSED_MAIL_HUB_STORAGE,
              LootTable.lootTable().withPool(LootPool.lootPool()
                    .setRolls(ConstantValue.exactly(1))
                    .add(NestedLootTable.lootTableReference(Envelope.LootTables.COLLAPSED_MAIL_HUB_STORAGE_MAIL).setWeight(2))
                    .add(NestedLootTable.lootTableReference(Envelope.LootTables.COLLAPSED_MAIL_HUB_STORAGE_MATERIALS))
                    .add(NestedLootTable.lootTableReference(Envelope.LootTables.COLLAPSED_MAIL_HUB_STORAGE_STAMPS))
              )
        );

        MutableComponent automatedSupplyService = ServiceAddress.getOrThrow(ServiceAddress.AUTOMATED_SUPPLY_SERVICE, registries).format().toComponent();

        output.accept(
              Envelope.LootTables.COLLAPSED_MAIL_HUB_STORAGE_MAIL,
              LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                          .setRolls(UniformGenerator.between(1.0F, 3.0F))
                          .add(LootItem.lootTableItem(Items.PAPER).setWeight(2).apply(SetItemCountFunction.setCount(UniformGenerator.between(4.0F, 12.0F))))
                          .add(LootItem.lootTableItem(Envelope.Items.PAPER_BOX.get()).setWeight(2).apply(SetItemCountFunction.setCount(UniformGenerator.between(4.0F, 8.0F))))
                          .add(LootItem.lootTableItem(Envelope.Items.PACKAGE.get())
                                .apply(SetComponentsFunction.setComponent(DataComponents.ITEM_NAME, Component.translatable("item.envelope.lost_mail")))
                                .apply(SetComponentsFunction.setComponent(DataComponents.CONTAINER_LOOT, new SeededContainerLoot(Envelope.LootTables.LOST_MAIL, 0L)))
                                .apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 2.0F)))))
                    .withPool(LootPool.lootPool()
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.common_1")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.common_2")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.common_3")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.common_4")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.common_5")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.common_6")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.common_7", automatedSupplyService)))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.nether_1")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.nether_2")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.nether_3")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.nether_4")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.nether_5")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.nether_6")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.nether_7")))
                          .add(letter(Component.translatable("item.envelope.lost_mail"), Component.translatable("letter.envelope.collapsed_mail_hub.nether_8")))
                          .add(EmptyLootItem.emptyItem().setWeight(5))
                    ));

        output.accept(
              Envelope.LootTables.COLLAPSED_MAIL_HUB_STORAGE_MATERIALS,
              LootTable.lootTable().withPool(LootPool.lootPool()
                    .setRolls(UniformGenerator.between(1.0F, 4.0F))
                    .add(LootItem.lootTableItem(Items.PAPER).setWeight(1).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 6.0F))))
                    .add(LootItem.lootTableItem(Envelope.Items.ADDRESS_TAG.get()).setWeight(2).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 6.0F))))
                    .add(LootItem.lootTableItem(Envelope.Items.PAYBACK_TAG.get()).setWeight(1).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 6.0F))))
                    .add(LootItem.lootTableItem(Items.PAPER).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 6.0F))))
                    .add(LootItem.lootTableItem(Items.FEATHER).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 6.0F))))
                    .add(LootItem.lootTableItem(Items.BLACK_DYE).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 6.0F))))
                    .add(LootItem.lootTableItem(Items.BOOK).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 2.0F))))
                    .add(LootItem.lootTableItem(Envelope.Items.LETTER_AND_QUILL.get()).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 2.0F))))
                    .add(LootItem.lootTableItem(Items.WRITABLE_BOOK).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 2.0F))))
              )
        );

        output.accept(
              Envelope.LootTables.COLLAPSED_MAIL_HUB_STORAGE_STAMPS,
              LootTable.lootTable().withPool(LootPool.lootPool()
                    .setRolls(UniformGenerator.between(1.0F, 3.0F))
                    .add(LootItem.lootTableItem(Items.PAPER).setWeight(1).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 6.0F))))
                    .add(LootItem.lootTableItem(Envelope.Items.SEAL_STAMP.get()).setWeight(2).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 2.0F))))
                    .add(LootItem.lootTableItem(Envelope.Items.SEAL_STAMP.get())
                          .apply(SetComponentsFunction.setComponent(Envelope.DataComponents.SEAL_STAMP_DIE, new EitherHolder<>(Resource.getOrThrow(SealSymbol.HEART, registries)))))
                    .add(LootItem.lootTableItem(Envelope.Items.SEAL_STAMP.get())
                          .apply(SetComponentsFunction.setComponent(Envelope.DataComponents.SEAL_STAMP_DIE, new EitherHolder<>(Resource.getOrThrow(SealSymbol.CREEPER, registries)))))
                    .add(LootItem.lootTableItem(Envelope.Items.SEAL_STAMP.get())
                          .apply(SetComponentsFunction.setComponent(Envelope.DataComponents.SEAL_STAMP_DIE, new EitherHolder<>(Resource.getOrThrow(SealSymbol.LETTER_AND_QUILL, registries)))))
                    .add(LootItem.lootTableItem(Envelope.Items.SEAL_STAMP.get())
                          .apply(SetComponentsFunction.setComponent(Envelope.DataComponents.SEAL_STAMP_DIE, new EitherHolder<>(Resource.getOrThrow(SealSymbol.SWORDS, registries)))))
                    .add(LootItem.lootTableItem(Envelope.Items.SEAL_STAMP.get())
                          .apply(SetComponentsFunction.setComponent(Envelope.DataComponents.SEAL_STAMP_DIE, new EitherHolder<>(Resource.getOrThrow(SealSymbol.VILLAGER, registries)))))
              )
        );

        output.accept(
              Envelope.LootTables.COLLAPSED_MAIL_HUB_MANUFACTORY,
              LootTable.lootTable().withPool(LootPool.lootPool()
                    .setRolls(UniformGenerator.between(2.0F, 8.0F))
                    .add(LootItem.lootTableItem(Items.DIRT).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 8.0F))))
                    .add(LootItem.lootTableItem(Items.COARSE_DIRT).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 4.0F))))
                    .add(LootItem.lootTableItem(Items.PUMPKIN_SEEDS).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 8.0F))))
                    .add(LootItem.lootTableItem(Items.PUMPKIN).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 4.0F))))
                    .add(LootItem.lootTableItem(Items.CARVED_PUMPKIN).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 2.0F))))
                    .add(LootItem.lootTableItem(Items.COPPER_BLOCK).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 4.0F))))
                    .add(LootItem.lootTableItem(Items.EXPOSED_COPPER).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.WEATHERED_COPPER).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.OXIDIZED_COPPER).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 2.0F))))
              )
        );

        output.accept(
              Envelope.LootTables.COLLAPSED_MAIL_HUB_DISPATCHERY,
              LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                          .setRolls(UniformGenerator.between(1.0F, 3.0F))
                          .add(LootItem.lootTableItem(Items.PAPER).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 8.0F))))
                          .add(LootItem.lootTableItem(Items.FEATHER).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 8.0F))))
                          .add(LootItem.lootTableItem(Items.BLACK_DYE).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 8.0F))))
                          .add(LootItem.lootTableItem(Items.BOOK).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                          .add(LootItem.lootTableItem(Items.MAP).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                          .add(LootItem.lootTableItem(Items.WRITABLE_BOOK).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 2.0F))))
                          .add(LootItem.lootTableItem(Envelope.Items.LETTER_AND_QUILL.get()).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 2.0F)))))
                    .withPool(LootPool.lootPool()
                          .setRolls(ConstantValue.exactly(1f))
                          .add(LootItem.lootTableItem(Items.MUSIC_DISC_CREATOR))
                          .add(LootItem.lootTableItem(Items.DIAMOND).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 2.0F))).setWeight(2))
                          .add(EmptyLootItem.emptyItem().setWeight(7)))
        );

        output.accept(
              Envelope.LootTables.COLLAPSED_MAIL_HUB_CONSTRUCTION,
              LootTable.lootTable().withPool(LootPool.lootPool()
                    .setRolls(UniformGenerator.between(4.0F, 8.0F))
                    .add(LootItem.lootTableItem(Items.SCAFFOLDING).apply(SetItemCountFunction.setCount(UniformGenerator.between(4.0F, 8.0F))))
                    .add(LootItem.lootTableItem(Items.ACACIA_PLANKS).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 12.0F))))
                    .add(LootItem.lootTableItem(Items.ACACIA_FENCE).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 12.0F))))
                    .add(LootItem.lootTableItem(Items.RED_WOOL).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 12.0F))))
                    .add(LootItem.lootTableItem(Items.COPPER_INGOT).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 12.0F))))
                    .add(LootItem.lootTableItem(Items.COPPER_BLOCK).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.EXPOSED_COPPER).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.WEATHERED_COPPER).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.OXIDIZED_COPPER).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.COPPER_BULB).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.EXPOSED_COPPER_BULB).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.WEATHERED_COPPER_BULB).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.OXIDIZED_COPPER_BULB).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.CHISELED_COPPER).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.EXPOSED_CHISELED_COPPER).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.WEATHERED_CHISELED_COPPER).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.OXIDIZED_CHISELED_COPPER).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.COPPER_TRAPDOOR).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.EXPOSED_COPPER_TRAPDOOR).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.WEATHERED_COPPER_TRAPDOOR).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Items.OXIDIZED_COPPER_TRAPDOOR).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                    .add(LootItem.lootTableItem(Envelope.Items.PAPER_BOX.get()).apply(SetItemCountFunction.setCount(UniformGenerator.between(2.0F, 4.0F))))
              )
        );

        output.accept(
              Envelope.LootTables.COLLAPSED_MAIL_HUB_DOCK_NOTE,
              LootTable.lootTable().withPool(LootPool.lootPool()
                    .add(letter(Component.translatable("letter.envelope.collapsed_mail_hub.dock_note.name.note"), Component.translatable("letter.envelope.collapsed_mail_hub.dock_note_1")))
                    .add(letter(Component.translatable("letter.envelope.collapsed_mail_hub.dock_note.name.note"), Component.translatable("letter.envelope.collapsed_mail_hub.dock_note_2")))
                    .add(letter(Component.translatable("letter.envelope.collapsed_mail_hub.dock_note.name.status"), Component.translatable("letter.envelope.collapsed_mail_hub.dock_note_3")))
                    .add(letter(Component.translatable("letter.envelope.collapsed_mail_hub.dock_note.name.status"), Component.translatable("letter.envelope.collapsed_mail_hub.dock_note_4")))
                    .add(letter(Component.translatable("letter.envelope.collapsed_mail_hub.dock_note.name.status"), Component.translatable("letter.envelope.collapsed_mail_hub.dock_note_5")))
                    .add(letter(Component.translatable("letter.envelope.collapsed_mail_hub.dock_note.name.status"), Component.translatable("letter.envelope.collapsed_mail_hub.dock_note_6")))
                    .add(letter(Component.translatable("letter.envelope.collapsed_mail_hub.dock_note.name.status"), Component.translatable("letter.envelope.collapsed_mail_hub.dock_note_7")))
                    .add(letter(Component.translatable("letter.envelope.collapsed_mail_hub.dock_note.name.status"), Component.translatable("letter.envelope.collapsed_mail_hub.dock_note_8")))
              )
        );
    }

    private void injects(@NotNull BiConsumer<ResourceKey<LootTable>, LootTable.Builder> output) {
        output.accept(
              Envelope.LootTables.ABANDONED_MINESHAFT_INJECT,
              LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                          .setRolls(ConstantValue.exactly(1))
                          .add(LootItem.lootTableItem(Envelope.Items.PAPER_BOX.get()).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                          .add(EmptyLootItem.emptyItem().setWeight(2)))
                    .withPool(LootPool.lootPool()
                          .add(tatteredLetter(Component.translatable("letter.envelope.abandoned_mineshaft.journal_page.name"), Component.translatable("letter.envelope.abandoned_mineshaft.journal_page_1")))
                          .add(tatteredLetter(Component.translatable("letter.envelope.abandoned_mineshaft.journal_page.name"), Component.translatable("letter.envelope.abandoned_mineshaft.journal_page_2")))
                          .add(tatteredLetter(Component.translatable("letter.envelope.abandoned_mineshaft.journal_page.name"), Component.translatable("letter.envelope.abandoned_mineshaft.journal_page_3")))
                          .add(EmptyLootItem.emptyItem().setWeight(16))
                    ));

        output.accept(
              Envelope.LootTables.PILLAGER_OUTPOST_INJECT,
              LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                          .setRolls(ConstantValue.exactly(1))
                          .add(LootItem.lootTableItem(Envelope.Items.PAPER_BOX.get()).apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))))
                          .add(EmptyLootItem.emptyItem().setWeight(2)))
                    .withPool(LootPool.lootPool()
                          .add(illagerLetter(Component.translatable("letter.envelope.pillager_outpost.report.name"), Component.translatable("letter.envelope.pillager_outpost.report_1")))
                          .add(illagerLetter(Component.translatable("letter.envelope.pillager_outpost.report.name"), Component.translatable("letter.envelope.pillager_outpost.report_2")))
                          .add(illagerLetter(Component.translatable("letter.envelope.pillager_outpost.report.name"), Component.translatable("letter.envelope.pillager_outpost.report_3")))
                          .add(illagerLetter(Component.translatable("letter.envelope.pillager_outpost.report.name"), Component.translatable("letter.envelope.pillager_outpost.report_4")))
                          .add(EmptyLootItem.emptyItem().setWeight(16))
                    ));

        output.accept(
              Envelope.LootTables.RUINED_PORTAL_INJECT,
              LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                          .setRolls(ConstantValue.exactly(1.0F))
                          .add(LootItem.lootTableItem(Items.MAP)
                                .apply(ExplorationMapFunction.makeExplorationMap()
                                      .setDestination(Envelope.Tags.Structures.ON_COLLAPSED_MAIL_HUB_EXPLORER_MAPS)
                                      .setMapDecoration(MapDecorationTypes.RED_X)
                                      .setZoom((byte) 1)
                                      .setSkipKnownStructures(false))
                                .apply(SetNameFunction.setName(Component.translatable("envelope.filled_map.collapsed_mail_hub"), SetNameFunction.Target.ITEM_NAME)))
                          .add(EmptyLootItem.emptyItem())));
    }

    // --

    //TODO: refactor with static methods that chain (letter("asd").name("123").illager())?

    protected LootPoolSingletonContainer.Builder<?> letter(@Nullable MutableComponent name, @NotNull MutableComponent text) {
        LootPoolSingletonContainer.Builder<?> builder = LootItem.lootTableItem(Envelope.Items.LETTER.get())
              .apply(SetComponentsFunction.setComponent(Envelope.DataComponents.LETTER_CONTENT, new LetterContent(text)));

        if (name != null) {
            builder.apply(SetComponentsFunction.setComponent(DataComponents.ITEM_NAME, name));
        }

        return builder;
    }

    protected LootPoolSingletonContainer.Builder<?> tatteredLetter(@Nullable MutableComponent name, @NotNull MutableComponent text) {
        LootPoolSingletonContainer.Builder<?> builder = LootItem.lootTableItem(Envelope.Items.TATTERED_LETTER.get())
              .apply(SetComponentsFunction.setComponent(Envelope.DataComponents.LETTER_CONTENT, new LetterContent(text)));

        if (name != null) {
            builder.apply(SetComponentsFunction.setComponent(DataComponents.ITEM_NAME, name));
        }

        return builder;
    }

    protected LootPoolSingletonContainer.Builder<?> illagerLetter(@Nullable MutableComponent name, @NotNull MutableComponent text) {
        LootPoolSingletonContainer.Builder<?> builder = LootItem.lootTableItem(Envelope.Items.TATTERED_LETTER.get())
              .apply(SetComponentsFunction.setComponent(Envelope.DataComponents.LETTER_CONTENT, new LetterContent(text
                    .withStyle(Style.EMPTY.withFont(ResourceLocation.withDefaultNamespace("illageralt"))))));

        if (name != null) {
            builder.apply(SetComponentsFunction.setComponent(DataComponents.ITEM_NAME, name
                  .withStyle(Style.EMPTY.withFont(ResourceLocation.withDefaultNamespace("illageralt")))));
        }

        return builder;
    }
}