package io.github.mortuusars.envelope.neoforge.datagen;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.entity.PigeonVariant;
import io.github.mortuusars.envelope.world.item.component.seal.SealSymbol;
import io.github.mortuusars.envelope.world.item.component.seal.SealMaterial;
import io.github.mortuusars.envelope.world.mail.service.ServiceAddressDefinition;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.RegistrySetBuilder;
import net.minecraft.data.PackOutput;
import net.neoforged.neoforge.common.data.DatapackBuiltinEntriesProvider;

import java.util.Set;
import java.util.concurrent.CompletableFuture;

public class BuiltInDatapackEntries extends DatapackBuiltinEntriesProvider {
    public static final RegistrySetBuilder REGISTRIES = new RegistrySetBuilder()
          .add(Envelope.Registries.PIGEON_VARIANT, PigeonVariant::bootstrap)
          .add(Envelope.Registries.SERVICE_ADDRESS_DEFINITION, ServiceAddressDefinition::bootstrap)
          .add(Envelope.Registries.SEAL_MATERIAL, SealMaterial::bootstrap)
          .add(Envelope.Registries.SEAL_SYMBOL, SealSymbol::bootstrap);

    public BuiltInDatapackEntries(PackOutput output, CompletableFuture<HolderLookup.Provider> provider) {
        super(output, provider, REGISTRIES, Set.of(Envelope.ID));
    }
}