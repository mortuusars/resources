package io.github.mortuusars.envelope.neoforge.datagen.client;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.EnvelopeClient;
import io.github.mortuusars.envelope.world.block.LetterBlock;
import io.github.mortuusars.envelope.world.block.PaperBoxBlock;
import io.github.mortuusars.envelope.world.block.PigeonholeBlock;
import io.github.mortuusars.envelope.world.item.component.PaybackDuration;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.client.model.generators.BlockStateProvider;
import net.neoforged.neoforge.client.model.generators.ConfiguredModel;
import net.neoforged.neoforge.client.model.generators.ItemModelBuilder;
import net.neoforged.neoforge.client.model.generators.ModelFile;
import net.neoforged.neoforge.common.data.ExistingFileHelper;

public class ModelsDatagen extends BlockStateProvider {
    public ModelsDatagen(PackOutput output, ExistingFileHelper exFileHelper) {
        super(output, Envelope.ID, exFileHelper);
    }

    @Override
    protected void registerStatesAndModels() {
        Envelope.Blocks.PIGEONHOLES.forEach((id, block) -> {
            pigeonhole(id, block.get());
            itemModels().simpleBlockItem(block.get());
        });

        itemModels().simpleBlockItem(Envelope.Blocks.MAILBOX.get())
              .transforms()
              .transform(ItemDisplayContext.GUI)
              .rotation(30, -135, 0)
              .scale(0.75f)
              .translation(0, 0.75f, 0)
              .end();

        horizontalBlock(Envelope.Blocks.PACKAGE.get(), models().getExistingFile(modLoc("block/package")));
        horizontalBlock(Envelope.Blocks.SEALED_PACKAGE.get(), models().getExistingFile(modLoc("block/sealed_package")));

        getVariantBuilder(Envelope.Blocks.LETTER.get()).forAllStates(state -> {
            String model = "letter" + (state.getValue(LetterBlock.HAS_CONTENT) ? "_content" : "");
            return ConfiguredModel.builder()
                  .modelFile(models().getExistingFile(modLoc("block/" + model)))
                  .rotationY(((int)state.getValue(LetterBlock.FACING).toYRot() + 180) % 360)
                  .build();
        });

        getVariantBuilder(Envelope.Blocks.TATTERED_LETTER.get()).forAllStates(state -> {
            String model = "tattered_letter" + (state.getValue(LetterBlock.HAS_CONTENT) ? "_content" : "");
            return ConfiguredModel.builder()
                  .modelFile(models().getExistingFile(modLoc("block/" + model)))
                  .rotationY(((int)state.getValue(LetterBlock.FACING).toYRot() + 180) % 360)
                  .build();
        });

        getVariantBuilder(Envelope.Blocks.SERVICE_LETTER.get()).forAllStates(state -> {
            String model = "service_letter" + (state.getValue(LetterBlock.HAS_CONTENT) ? "_content" : "");
            return ConfiguredModel.builder()
                  .modelFile(models().getExistingFile(modLoc("block/" + model)))
                  .rotationY(((int)state.getValue(LetterBlock.FACING).toYRot() + 180) % 360)
                  .build();
        });

        getVariantBuilder(Envelope.Blocks.PAPER_BOX.get()).forAllStates(state -> {
            String[] boxes = {"one", "two", "three", "four", "five"};
            ModelFile.ExistingModelFile model = models().getExistingFile(
                  modLoc("block/paper_box_" + boxes[state.getValue(PaperBoxBlock.BOXES) - 1]));
            return ConfiguredModel.builder()
                  .modelFile(model)
                  .rotationY(state.getValue(PaperBoxBlock.AXIS) == Direction.Axis.X ? 0 : 90)
                  .build();
        });

        itemModels().basicItem(Envelope.Items.ADDRESS_TAG.get());
        itemModels().basicItem(Envelope.Items.SEAL_STAMP.get());
        Envelope.Items.DYED_SEAL_STAMPS.values().forEach(item -> itemModels().basicItem(item.get()));
        itemModels().basicItem(Envelope.Items.SOULBOUND_SEAL_STAMP.get());

        itemModels().basicItem(Envelope.Items.LETTER_AND_QUILL.get())
              .override()
              .predicate(EnvelopeClient.ItemModelOverrides.HAS_CONTENT, 1)
              .model(model(Envelope.resource("letter_and_quill_content")))
              .end();

        letter(Envelope.Items.LETTER.get());
        letter(Envelope.Items.TATTERED_LETTER.get());
        letter(Envelope.Items.SERVICE_LETTER.get());

        itemModels().basicItem(Envelope.Items.SEALED_LETTER.get())
              .texture("layer1", Envelope.resource("item/sealed_letter_overlay"));
        itemModels().basicItem(Envelope.Items.SEALED_TATTERED_LETTER.get())
              .texture("layer1", Envelope.resource("item/sealed_letter_overlay"));
        itemModels().basicItem(Envelope.Items.SEALED_SERVICE_LETTER.get())
              .texture("layer1", Envelope.resource("item/sealed_letter_overlay"));

        itemModels().getBuilder(Envelope.resource("sealed_package").toString())
              .parent(new ModelFile.UncheckedModelFile("item/generated"))
              .texture("layer0", Envelope.resource("item/sealed_package"))
              .texture("layer1", Envelope.resource("item/sealed_package_overlay"));

        itemModels().basicItem(Envelope.Items.PAPER_BOX.get())
              .override()
              .predicate(EnvelopeClient.ItemModelOverrides.OPEN, 1)
              .model(model(Envelope.resource("paper_box_open")))
              .end();
        itemModels().basicItem(Envelope.Items.PACKAGE.get())
              .override()
              .predicate(EnvelopeClient.ItemModelOverrides.OPEN, 1)
              .model(model(Envelope.resource("package_open")))
              .end();
        itemModels().basicItem(Envelope.Items.PAYBACK_BOX.get())
              .override()
              .predicate(EnvelopeClient.ItemModelOverrides.OPEN, 1)
              .model(model(Envelope.resource("payback_box_open")))
              .end();
        itemModels().basicItem(Envelope.Items.PAYBACK_PACKAGE.get())
              .override()
              .predicate(EnvelopeClient.ItemModelOverrides.OPEN, 1)
              .model(model(Envelope.resource("payback_package_open")))
              .end();

        // -- Payback Tag
        {
            ItemModelBuilder paybackTagShort = itemModels().getBuilder("envelope:payback_tag_short")
                  .parent(new ModelFile.UncheckedModelFile("item/generated"))
                  .texture("layer0", Envelope.resource("item/payback_tag_short"));

            ItemModelBuilder paybackTagMedium = itemModels().getBuilder("envelope:payback_tag_medium")
                  .parent(new ModelFile.UncheckedModelFile("item/generated"))
                  .texture("layer0", Envelope.resource("item/payback_tag_medium"));

            ItemModelBuilder paybackTagLong = itemModels().getBuilder("envelope:payback_tag_long")
                  .parent(new ModelFile.UncheckedModelFile("item/generated"))
                  .texture("layer0", Envelope.resource("item/payback_tag_long"));

            itemModels().getBuilder("envelope:payback_tag")
                  .parent(new ModelFile.UncheckedModelFile("envelope:item/payback_tag_medium"))
                  .override()
                  .predicate(EnvelopeClient.ItemModelOverrides.PAYBACK_TAG_DURATION, PaybackDuration.SHORT.ordinal() / 10f)
                  .model(paybackTagShort)
                  .end()
                  .override()
                  .predicate(EnvelopeClient.ItemModelOverrides.PAYBACK_TAG_DURATION, PaybackDuration.MEDIUM.ordinal() / 10f)
                  .model(paybackTagMedium)
                  .end()
                  .override()
                  .predicate(EnvelopeClient.ItemModelOverrides.PAYBACK_TAG_DURATION, PaybackDuration.LONG.ordinal() / 10f)
                  .model(paybackTagLong)
                  .end();
        }

        itemModels().spawnEggItem(Envelope.Items.PIGEON_SPAWN_EGG.get());
        itemModels().spawnEggItem(Envelope.Items.CHARRED_PIGEON_SPAWN_EGG.get());
    }

    protected ItemModelBuilder letter(Item item) {
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
        return itemModels().basicItem(id)
              .override()
              .predicate(EnvelopeClient.ItemModelOverrides.OPEN, 1)
              .predicate(EnvelopeClient.ItemModelOverrides.HAS_CONTENT, 0)
              .model(model(id.withSuffix("_open")))
              .end()
              .override()
              .predicate(EnvelopeClient.ItemModelOverrides.OPEN, 1)
              .predicate(EnvelopeClient.ItemModelOverrides.HAS_CONTENT, 1)
              .model(model(id.withSuffix("_open_content")))
              .end();
    }

    protected ItemModelBuilder model(ResourceLocation path) {
        return itemModels().getBuilder(path.toString())
              .parent(new ModelFile.UncheckedModelFile("item/generated"))
              .texture("layer0", ResourceLocation.fromNamespaceAndPath(path.getNamespace(), "item/" + path.getPath()));
    }

    protected void pigeonhole(ResourceLocation id, Block block) {
        String baseName = id.getPath();

        getVariantBuilder(block).forAllStates(state -> {
            Direction facing = state.getValue(PigeonholeBlock.FACING);
            int waste = state.getValue(PigeonholeBlock.WASTE_LEVEL);

            String suffix = (waste >= PigeonholeBlock.MAX_WASTE_LEVEL ? "_waste" : "");

            ModelFile model = models().orientableWithBottom(baseName + suffix,
                  Envelope.resource("block/" + baseName + "_side"),
                  Envelope.resource("block/" + baseName + "_front" + suffix),
                  Envelope.resource("block/" + baseName + "_end"),
                  Envelope.resource("block/" + baseName + "_end"));

            return ConfiguredModel.builder()
                  .modelFile(model)
                  .rotationY(((int) facing.toYRot() + 180) % 360)
                  .build();
        });
    }
}
