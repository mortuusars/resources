package io.github.mortuusars.envelope.fabric;

import fuzs.forgeconfigapiport.fabric.api.neoforge.v4.NeoForgeConfigRegistry;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.command.EnvelopeCommand;
import io.github.mortuusars.envelope.event.CommonEvents;
import io.github.mortuusars.envelope.event.ServerEvents;
import io.github.mortuusars.envelope.network.fabric.FabricC2SPackets;
import io.github.mortuusars.envelope.network.fabric.FabricS2CPackets;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.item.component.seal.SealImpression;
import io.github.mortuusars.envelope.world.item.component.seal.SealMaterial;
import io.github.mortuusars.envelope.world.mail.service.ServiceAddressDefinition;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.registry.DynamicRegistries;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_2902;
import net.minecraft.class_7706;
import net.minecraft.class_9169;
import net.neoforged.fml.config.ModConfig;

public class EnvelopeFabric implements ModInitializer {
    @Override
    public void onInitialize() {
        Envelope.init();

        NeoForgeConfigRegistry.INSTANCE.register(Envelope.ID, ModConfig.Type.SERVER, Config.Server.SPEC);
        NeoForgeConfigRegistry.INSTANCE.register(Envelope.ID, ModConfig.Type.CLIENT, Config.Client.SPEC);

        CommonEvents.commonSetup();

        DynamicRegistries.registerSynced(Envelope.Registries.SERVICE_ADDRESS_DEFINITION, ServiceAddressDefinition.DIRECT_CODEC, ServiceAddressDefinition.DIRECT_CODEC);
        DynamicRegistries.registerSynced(Envelope.Registries.SEAL_MATERIAL, SealMaterial.DIRECT_CODEC, SealMaterial.DIRECT_CODEC);
        DynamicRegistries.registerSynced(Envelope.Registries.SEAL_IMPRESSION, SealImpression.DIRECT_CODEC, SealImpression.DIRECT_CODEC);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(event -> {
            Envelope.Items.PIGEONHOLES.forEach(item -> event.method_45421(item.get()));
            event.method_45421(Envelope.Items.PAPER_BOX.get());
            event.method_45421(Envelope.Items.MAILBOX.get());
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(event -> {
            event.method_45421(Envelope.Items.LETTER_AND_QUILL.get());
            event.method_45421(Envelope.Items.LETTER.get());
            event.method_45421(Envelope.Items.SEALED_LETTER.get());
            event.method_45421(Envelope.Items.PACKAGE.get());
            event.method_45421(Envelope.Items.SEALED_PACKAGE.get());
            event.method_45421(Envelope.Items.ADDRESS_TAG.get());
            event.method_45421(Envelope.Items.PAYBACK_TAG.get());
            event.method_45421(Envelope.Items.SEAL_STAMP.get());
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(event -> {
            event.method_45421(Envelope.Items.PIGEON_SPAWN_EGG.get());
        });

        FabricDefaultAttributeRegistry.register(Envelope.EntityTypes.PIGEON.get(), Pigeon.createAttributes().method_26866());

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            PlatformImpl.server = server;
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            PlatformImpl.server = null;
        });

        ServerTickEvents.END_SERVER_TICK.register(ServerEvents::serverTick);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerEvents.playerLogin(handler.method_32311());
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            EnvelopeCommand.register(dispatcher, registryAccess);
        });

        BiomeModifications.addSpawn(biomeSelector -> biomeSelector.hasTag(Envelope.Tags.Biomes.ALLOWS_PIGEON_SPAWNS),
                class_1311.field_6294, Envelope.EntityTypes.PIGEON.get(), 2, 3, 6);

        class_1317.method_20637(Envelope.EntityTypes.PIGEON.get(), class_9169.field_48745,
                class_2902.class_2903.field_13197, Pigeon::checkSpawnRules);

        FlammableBlockRegistry.getDefaultInstance().add(Envelope.Blocks.PAPER_BOX.get(), 15, 50);
        FlammableBlockRegistry.getDefaultInstance().add(Envelope.Blocks.PACKAGE.get(), 15, 50);
        Envelope.Blocks.PIGEONHOLES.forEach((id, block) -> {
            FlammableBlockRegistry.getDefaultInstance().add(block.get(), 5, 20);
        });

        FabricC2SPackets.register();
        FabricS2CPackets.register();
    }
}
