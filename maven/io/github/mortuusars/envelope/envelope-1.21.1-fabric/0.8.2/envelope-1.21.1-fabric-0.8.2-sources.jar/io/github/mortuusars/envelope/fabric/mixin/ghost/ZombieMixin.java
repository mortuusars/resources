package io.github.mortuusars.envelope.fabric.mixin.ghost;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import net.minecraft.class_1266;
import net.minecraft.class_1315;
import net.minecraft.class_1641;
import net.minecraft.class_1642;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1642.class)
public class ZombieMixin {
    @WrapOperation(method = "killedEntity", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/monster/ZombieVillager;finalizeSpawn(Lnet/minecraft/world/level/ServerLevelAccessor;Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/world/entity/MobSpawnType;Lnet/minecraft/world/entity/SpawnGroupData;)Lnet/minecraft/world/entity/SpawnGroupData;"))
    private class_1315 onZombieVillagerSpawn(class_1641 instance, class_5425 level, class_1266 difficulty,
                                                 class_3730 spawnType, class_1315 spawnGroupData, Operation<class_1315> original) {
        Pigeon.trySpawnGhost(level.method_8410(), instance);
        return spawnGroupData;
    }
}
