package io.github.mortuusars.envelope.network.fabric;

import io.github.mortuusars.envelope.network.packet.CommonPackets;
import io.github.mortuusars.envelope.network.packet.S2CPackets;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public class FabricS2CPackets {
    @SuppressWarnings("unchecked")
    public static void register() {
        for (var definition : S2CPackets.getDefinitions()) {
            PayloadTypeRegistry.playS2C().register(
                    (class_8710.class_9154<class_8710>) definition.comp_2243(),
                    (class_9139<class_2540, class_8710>) definition.comp_2244());
        }

        for (var definition : CommonPackets.getDefinitions()) {
            PayloadTypeRegistry.playS2C().register(
                    (class_8710.class_9154<class_8710>) definition.comp_2243(),
                    (class_9139<class_2540, class_8710>) definition.comp_2244());
        }
    }
}
