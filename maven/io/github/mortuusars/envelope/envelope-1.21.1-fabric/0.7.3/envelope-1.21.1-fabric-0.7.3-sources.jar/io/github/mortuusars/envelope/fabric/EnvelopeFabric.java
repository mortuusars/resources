package io.github.mortuusars.envelope.fabric;

import fuzs.forgeconfigapiport.fabric.api.neoforge.v4.NeoForgeConfigRegistry;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.command.EnvelopeCommand;
import io.github.mortuusars.envelope.event.CommonEvents;
import io.github.mortuusars.envelope.event.ServerEvents;
import io.github.mortuusars.envelope.network.fabric.FabricC2SPackets;
import io.github.mortuusars.envelope.network.fabric.FabricS2CPackets;
import io.github.mortuusars.envelope.world.entity.CharredPigeon;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.entity.PigeonVariant;
import io.github.mortuusars.envelope.world.item.component.seal.SealSymbol;
import io.github.mortuusars.envelope.world.item.component.seal.SealMaterial;
import io.github.mortuusars.envelope.world.mail.service.ServiceAddressDefinition;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.ModificationPhase;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.registry.DynamicRegistries;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableSource;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_2902;
import net.minecraft.class_39;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_7225;
import net.minecraft.class_7706;
import net.minecraft.class_83;
import net.minecraft.class_9169;
import net.neoforged.fml.config.ModConfig;

public class EnvelopeFabric implements ModInitializer {
    @Override
    public void onInitialize() {
        Envelope.init();

        NeoForgeConfigRegistry.INSTANCE.register(Envelope.ID, ModConfig.Type.SERVER, Config.Server.SPEC);
        NeoForgeConfigRegistry.INSTANCE.register(Envelope.ID, ModConfig.Type.COMMON, Config.Common.SPEC);
        NeoForgeConfigRegistry.INSTANCE.register(Envelope.ID, ModConfig.Type.CLIENT, Config.Client.SPEC);

        CommonEvents.commonSetup();

        DynamicRegistries.registerSynced(Envelope.Registries.PIGEON_VARIANT, PigeonVariant.DIRECT_CODEC, PigeonVariant.DIRECT_CODEC);
        DynamicRegistries.registerSynced(Envelope.Registries.SERVICE_ADDRESS_DEFINITION, ServiceAddressDefinition.DIRECT_CODEC, ServiceAddressDefinition.DIRECT_CODEC);
        DynamicRegistries.registerSynced(Envelope.Registries.SEAL_MATERIAL, SealMaterial.DIRECT_CODEC, SealMaterial.DIRECT_CODEC);
        DynamicRegistries.registerSynced(Envelope.Registries.SEAL_SYMBOL, SealSymbol.DIRECT_CODEC, SealSymbol.DIRECT_CODEC);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(event -> {
            Envelope.Items.PIGEONHOLES.forEach(item -> event.method_45421(item.get()));
            event.method_45421(Envelope.Items.PAPER_BOX.get());
            event.method_45421(Envelope.Items.MAILBOX.get());
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(event -> {
            event.method_45421(Envelope.Items.LETTER_AND_QUILL.get());
            event.method_45421(Envelope.Items.LETTER.get());
            event.method_45421(Envelope.Items.SEALED_LETTER.get());
            event.method_45421(Envelope.Items.PACKAGE.get());
            event.method_45421(Envelope.Items.SEALED_PACKAGE.get());
            event.method_45421(Envelope.Items.ADDRESS_TAG.get());
            event.method_45421(Envelope.Items.PAYBACK_TAG.get());
            event.method_45421(Envelope.Items.SEAL_STAMP.get());
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(event -> {
            event.method_45421(Envelope.Items.PIGEON_SPAWN_EGG.get());
            event.method_45421(Envelope.Items.CHARRED_PIGEON_SPAWN_EGG.get());
        });

        FabricDefaultAttributeRegistry.register(Envelope.EntityTypes.PIGEON.get(), Pigeon.createAttributes().method_26866());
        FabricDefaultAttributeRegistry.register(Envelope.EntityTypes.CHARRED_PIGEON.get(), CharredPigeon.createAttributes().method_26866());

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            PlatformImpl.server = server;
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            PlatformImpl.server = null;
        });

        ServerTickEvents.END_SERVER_TICK.register(ServerEvents::serverTick);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerEvents.playerLogin(handler.method_32311());
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            EnvelopeCommand.register(dispatcher, registryAccess);
        });

        BiomeModifications.addSpawn(biomeSelector -> biomeSelector.hasTag(Envelope.Tags.Biomes.ALLOWS_PIGEON_SPAWNS),
                class_1311.field_6294, Envelope.EntityTypes.PIGEON.get(), 2, 3, 6);
        BiomeModifications.addSpawn(biomeSelector -> biomeSelector.hasTag(Envelope.Tags.Biomes.ALLOWS_CHARRED_PIGEON_SPAWNS),
              class_1311.field_6302, Envelope.EntityTypes.CHARRED_PIGEON.get(), 1, 1, 1);
        BiomeModifications.create(Envelope.resource("charred_pigeon_spawn_cost"))
              .add(ModificationPhase.ADDITIONS, biomeSelector -> biomeSelector.hasTag(Envelope.Tags.Biomes.ALLOWS_CHARRED_PIGEON_SPAWNS),
                    context -> context.getSpawnSettings().setSpawnCost(Envelope.EntityTypes.CHARRED_PIGEON.get(), 0.7, 0.15));

        class_1317.method_20637(Envelope.EntityTypes.PIGEON.get(), class_9169.field_48745,
                class_2902.class_2903.field_13197, Pigeon::checkSpawnRules);
        class_1317.method_20637(Envelope.EntityTypes.CHARRED_PIGEON.get(), class_9169.field_48745,
              class_2902.class_2903.field_13197, CharredPigeon::checkSpawnRules);

        FlammableBlockRegistry.getDefaultInstance().add(Envelope.Blocks.PAPER_BOX.get(), 50, 15);
        FlammableBlockRegistry.getDefaultInstance().add(Envelope.Blocks.PACKAGE.get(), 50, 15);
        FlammableBlockRegistry.getDefaultInstance().add(Envelope.Blocks.LETTER.get(), 200, 10);
        Envelope.Blocks.PIGEONHOLES.forEach((id, block) -> {
            FlammableBlockRegistry.getDefaultInstance().add(block.get(), 20, 15);
        });

        ServerLivingEntityEvents.AFTER_DEATH.register(CommonEvents::livingDeath);

        LootTableEvents.MODIFY.register(EnvelopeFabric::modifyLoot);

        FabricC2SPackets.register();
        FabricS2CPackets.register();
    }

    private static void modifyLoot(class_5321<class_52> tableKey, class_52.class_53 builder,
                                   LootTableSource source, class_7225.class_7874 provider) {
        if (!Config.Common.LOOT.get()) {
            return;
        }

        if (class_39.field_472.equals(tableKey)) {
            builder.pool(class_55.method_347()
                  .method_351(class_83.method_428(Envelope.LootTables.ABANDONED_MINESHAFT_INJECT))
                  .method_355());
        }
        if (class_39.field_16593.equals(tableKey)) {
            builder.pool(class_55.method_347()
                  .method_351(class_83.method_428(Envelope.LootTables.PILLAGER_OUTPOST_INJECT))
                  .method_355());
        }
    }
}
