package io.github.mortuusars.envelope.fabric;

import fuzs.forgeconfigapiport.fabric.api.neoforge.v4.client.ConfigScreenFactoryRegistry;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.EnvelopeClient;
import io.github.mortuusars.envelope.client.gui.screen.PackingScreen;
import io.github.mortuusars.envelope.client.gui.screen.PaybackPackingScreen;
import io.github.mortuusars.envelope.client.gui.screen.PaybackTagScreen;
import io.github.mortuusars.envelope.client.gui.screen.MailboxScreen;
import io.github.mortuusars.envelope.client.model.PigeonModel;
import io.github.mortuusars.envelope.client.renderer.entity.PigeonRenderer;
import io.github.mortuusars.envelope.client.renderer.entity.layer.PigeonBackpackLayer;
import io.github.mortuusars.envelope.client.renderer.entity.layer.PigeonHatLayer;
import io.github.mortuusars.envelope.network.fabric.FabricS2CPacketHandler;
import io.github.mortuusars.envelope.world.item.Sealable;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_3929;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;

public class EnvelopeFabricClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EnvelopeClient.init();

        ConfigScreenFactoryRegistry.INSTANCE.register(Envelope.ID, ConfigurationScreen::new);

        EntityRendererRegistry.register(Envelope.EntityTypes.PIGEON.get(), PigeonRenderer::new);
        EntityModelLayerRegistry.registerModelLayer(PigeonRenderer.PIGEON_LAYER, PigeonModel::createLayerDefinition);
        EntityModelLayerRegistry.registerModelLayer(PigeonBackpackLayer.PIGEON_BACKPACK, PigeonModel::createLayerDefinition);
        EntityModelLayerRegistry.registerModelLayer(PigeonHatLayer.PIGEON_HAT, PigeonModel::createLayerDefinition);

        ColorProviderRegistry.ITEM.register(Sealable::getSealOverlayColor, Envelope.Items.SEALED_LETTER.get());
        ColorProviderRegistry.ITEM.register(Sealable::getSealOverlayColor, Envelope.Items.SEALED_PACKAGE.get());
        ColorProviderRegistry.BLOCK.register(Sealable::getSealOverlayColor, Envelope.Blocks.SEALED_PACKAGE.get());

        class_3929.method_17542(Envelope.MenuTypes.PIGEONHOLE.get(), MailboxScreen::new);
        class_3929.method_17542(Envelope.MenuTypes.PACKAGE.get(), PackingScreen::new);
        class_3929.method_17542(Envelope.MenuTypes.PAYBACK_PACKAGE.get(), PaybackPackingScreen::new);
        class_3929.method_17542(Envelope.MenuTypes.PAYBACK_TAG.get(), PaybackTagScreen::new);

        FabricS2CPacketHandler.register();
    }
}
