package io.github.mortuusars.envelope.world.block.mailbox;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.Platform;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.clientbound.MailboxHasNewMailS2CP;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.inventory.MailboxMenu;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.address.SimpleBlockAddressGenerator;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.*;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2624;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_7225;

public class MailboxBlockEntity extends class_2624 implements Inbox {
    public static final int REGULAR_SLOTS = 2;
    public static final int SLOT_FOOD = 0;
    public static final int SLOT_MAIL = 1;
    public static final int INBOX_SLOT = 2;

    private static final Logger LOGGER = LogUtils.getLogger();

    private class_2371<class_1799> items = class_2371.method_10213(REGULAR_SLOTS, class_1799.field_8037);
    private @NotNull UUID inboxId = UUID.randomUUID();
    private @Nullable BlockAddress address;
    private @Nullable UUID owner;

    private @NotNull List<class_1799> mail = new ArrayList<>();
    private boolean loaded = false;
    private boolean blockRemoved = false;

    protected MailboxBlockEntity(class_2591<?> type, class_2338 pos, class_2680 blockState) {
        super(type, pos, blockState);
    }

    public MailboxBlockEntity(class_2338 pos, class_2680 blockState) {
        this(Envelope.BlockEntityTypes.MAILBOX.get(), pos, blockState);
    }

    @Override
    protected @NotNull class_2561 method_17823() {
        return address != null
              ? address.getComponent()
              : class_2561.method_43471("container.envelope.mailbox");
    }

    // -- Address

    public @NotNull BlockAddress getAddress() {
        return Preconditions.checkNotNull(address,
              "Address of mailbox at [" + method_11016().method_23854() + "] was not set.");
    }

    public void setAddress(@Nullable BlockAddress address) {
        @Nullable BlockAddress currentAddress = this.address;
        this.address = address;

        if (method_10997() instanceof class_3218 serverLevel && MailService.operatesIn(serverLevel)) {
            address = Objects.requireNonNullElseGet(address, () -> generateRandomAddress(serverLevel));
            address = MailService.of(serverLevel).getMailboxes().correctOrRegisterIfNeeded(address, method_11016());

            if (!address.equals(currentAddress)) {
                this.address = address;
                method_5431();
                // Syncs address to the client:
                serverLevel.method_8413(method_11016(), method_11010(), method_11010(), MailboxBlock.field_31036);
            }
        }
    }

    protected void applyAddress() {
        setAddress(this.address);
    }

    protected @NotNull BlockAddress generateRandomAddress(class_3218 level) {
        return new SimpleBlockAddressGenerator(MailService.of(level).getKnownAddresses(), 50).generate(level.method_8409());
    }

    // -- Owner

    public @Nullable UUID getOwner() {
        return owner;
    }

    public void setOwner(@Nullable UUID owner) {
        this.owner = owner;
        method_5431();
    }

    public Optional<class_1657> getOwnerPlayer() {
        if (owner == null || field_11863 == null) return Optional.empty();
        for (class_1657 player : field_11863.method_18456()) {
            if (player.method_5667().equals(owner)) {
                return Optional.of(player);
            }
        }
        return Optional.empty();
    }

    // -- Container

    @Override
    protected @NotNull class_2371<class_1799> method_11282() {
        return items;
    }

    @Override
    protected void method_11281(class_2371<class_1799> items) {
        this.items = items;
    }

    @Override
    public int method_5439() {
        return REGULAR_SLOTS + getAllMail().size();
    }

    @Override
    public @NotNull class_1799 method_5438(int slot) {
        if (slot >= INBOX_SLOT) {
            return getMail(slot - INBOX_SLOT);
        }
        return super.method_5438(slot);
    }

    @Override
    public @NotNull class_1799 method_5434(int slot, int amount) {
        if (slot >= INBOX_SLOT) {
            return removeMail(slot - INBOX_SLOT);
        }
        return super.method_5434(slot, amount);
    }

    @Override
    public @NotNull class_1799 method_5441(int slot) {
        if (slot >= INBOX_SLOT) {
            return removeMailNoUpdate(slot - INBOX_SLOT);
        }
        return super.method_5441(slot);
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        if (slot >= INBOX_SLOT) {
            addMail(slot - INBOX_SLOT, stack);
            return;
        }
        super.method_5447(slot, stack);
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        if (slot == SLOT_FOOD) return stack.method_31573(Envelope.Tags.Items.PIGEON_FOOD);
        if (slot == SLOT_MAIL) return isSendable(stack);
        return false;
    }

    @Override
    public boolean method_49104(class_1263 target, int slot, class_1799 stack) {
        return slot >= INBOX_SLOT
              && target.method_43256(class_1799::method_7960); // Prevents hoppers from removing the item and placing it back
    }

    public boolean isSendable(class_1799 stack) {
        return !stack.method_7960() && stack.method_31573(Envelope.Tags.Items.MAILABLE) && stack.method_57826(Envelope.DataComponents.MAIL_RECIPIENT);
    }

    public boolean isAvailableForPickup() {
        if (field_11863 == null) return false;
        return !method_5438(SLOT_FOOD).method_7960() && isSendable(method_5438(SLOT_MAIL));
    }

    @Override
    protected @NotNull class_1703 method_5465(int containerId, class_1661 inventory) {
        applyAddress();
        return new MailboxMenu(containerId, inventory, method_11016(), getAddress(), getAllMail());
    }

    public void openMenu(class_1657 player) {
        if (player instanceof class_3222 serverPlayer) {
            if (getOwner() == null) {
                setOwner(player.method_5667());
            }

            Platform.openMenu(serverPlayer, this, buffer -> {
                buffer.method_10807(method_11016());
                BlockAddress.STREAM_CODEC.encode(buffer, getAddress());
                class_1799.field_48350.encode(buffer, getAllMail());
            });
            playSound(class_3417.field_17604, 0.6f, 1.1f);
        }
    }

    @Override
    public void method_5448() {
        super.method_5448();
        mail.clear();
    }

    // -- Delivery

    public boolean tryStartDelivery(Pigeon pigeon) {
        if (!MailService.operatesIn(pigeon.method_37908())) {
            return false;
        }

        class_3218 level = ((class_3218) pigeon.method_37908());

        if (pigeon.isDelivering()) return false;
        class_1799 mailStack = method_5438(SLOT_MAIL);
        if (!isSendable(mailStack)) return false;

        applyAddress();

        class_1799 mail = Mail.removePreviousDeliveryData(mailStack.method_46651(1));

        MailService.of(level).getDeliveryManager()
              .start(pigeon, Delivery.draft()
                    .deliver(mail)
                    .from(getAddress())
                    .to(Mail.getRecipientOrUnknown(mail))
                    .owner(getOwner()));

        method_5434(SLOT_MAIL, 1);
        method_5434(SLOT_FOOD, 1);

        class_243 pos = pigeon.method_19538();
        level.method_14199(class_2398.field_11204, pos.field_1352, pos.field_1351, pos.field_1350, 10, 0.3, 0.3, 0.3, 0.02);
        level.method_60511(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_14581, class_3419.field_15254, 1f, 1.3f);

        return true;
    }

    // -- Inbox

    @Override
    public int getInboxCapacity() {
        return 512;
    }

    @Override
    public @NotNull List<class_1799> getAllMail() {
        return mail;
    }

    @Override
    public void onMailInserted(class_1799 mail) {
        playSound(class_3417.field_14725.comp_349(), 1, 1);
    }

    @Override
    public void onMailAdded(class_1799 mail) {
        if (field_11863 instanceof class_3218 serverLevel) {
            MailboxMenu.playersWithMenu(serverLevel, getAddress())
                  .forEach(player -> Packets.sendToClient(MailboxHasNewMailS2CP.INSTANCE, player));
        }
    }

    @Override
    public void onMailRemoved(int slot, class_1799 mail) {
        if (field_11863 instanceof class_3218 serverLevel) {
            Optional.ofNullable(Mail.getId(mail)).ifPresent(id -> {
                MailboxMenu.executeForPlayersWithMenu(serverLevel, getAddress(),
                      (player, menu) -> menu.onMailRemoved(id));
            });
        }
    }

    @Override
    public void onInboxChanged() {
        if (field_11863 != null) {
            field_11863.method_8455(method_11016(), method_11010().method_26204());
        }
    }

    // As inbox can be quite large in size, we cannot store it as regular block entity data.
    // So we use dedicated inbox storage for that, and load/unload each time block entity is being loaded/unloaded.

    public void loadInbox() {
        if (field_11863 instanceof class_3218 serverLevel && !inboxId.equals(class_156.field_25140)) {
            mail = InboxStorage.get(serverLevel).remove(inboxId)
                  .map(Inbox::getAllMail)
                  .orElseGet(ArrayList::new);
        } else {
            mail = new ArrayList<>();
        }
    }

    public void unloadInbox() {
        if (field_11863 instanceof class_3218 serverLevel && address != null && !inboxId.equals(class_156.field_25140)) {
            InboxStorage.get(serverLevel).put(inboxId, this);
        }
        mail.clear();
    }

    // -- Events

    public void serverTick(class_3218 level, class_2338 blockPos, class_2680 blockState) {
        if (!loaded) {
            onLoaded();
            loaded = true;
        }
    }

    protected void onLoaded() {
        applyAddress();
        if (field_11863 != null) {
            field_11863.method_8455(method_11016(), method_11010().method_26204());
        }
    }

    public void onBlockRemoved(class_1937 level, class_2338 pos, class_2680 state, class_2680 newState) {
        class_1264.method_54291(state, newState, level, pos);
        clearMail();
        blockRemoved = true;
    }

    @Override
    public void method_10996() {
        super.method_10996();
        loadInbox();
        blockRemoved = false;
    }

    @Override
    public void method_11012() {
        super.method_11012();
        if (!blockRemoved) {
            unloadInbox();
        }
    }

    @Override
    public void method_5431() {
        super.method_5431();
        updateBlockStateIfNeeded();
    }

    private void updateBlockStateIfNeeded() {
        if (!method_11015() && field_11863 instanceof class_3218 serverLevel) {
            class_2680 state = method_11010();
            boolean isOpen = state.method_11654(MailboxBlock.OPEN);
            boolean shouldBeOpen = isAvailableForPickup();
            if (isOpen != shouldBeOpen) {
                serverLevel.method_8501(method_11016(), state.method_11657(MailboxBlock.OPEN, shouldBeOpen));
                playSound(shouldBeOpen ? class_3417.field_42569 : class_3417.field_42568,
                      0.75f,
                      shouldBeOpen ? 1f : 0.75f);
            }
        }
    }

    // -- Sync

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public @NotNull class_2487 method_16887(class_7225.class_7874 registries) {
        return method_58692(registries);
    }

    // -- Loading/Saving

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        class_1262.method_5426(tag, items, registries);
        if (address != null) tag.method_10582("address", address.getString());
        if (owner != null) tag.method_25927("owner", owner);
        if (!inboxId.equals(class_156.field_25140)) tag.method_25927("inbox_id", inboxId);
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        class_1262.method_5429(tag, items, registries);
        setAddress(tag.method_10573("address", class_2520.field_33258) ? new BlockAddress(tag.method_10558("address")) : null);
        owner = tag.method_25928("owner") ? tag.method_25926("owner") : null;
        inboxId = tag.method_25928("inbox_id") ? tag.method_25926("inbox_id") : UUID.randomUUID();
    }

    // -- Util

    public void playSound(class_3414 soundEvent, float volume, float pitch) {
        if (field_11863 != null) {
            field_11863.method_8396(null, method_11016(), soundEvent, class_3419.field_15245, volume, pitch);
        }
    }
}
