package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_5530;
import net.minecraft.class_5533;

public class PigeonWanderGoal extends class_1352 {
    private static final int WANDER_THRESHOLD = 22;

    private final Pigeon pigeon;

    public PigeonWanderGoal(Pigeon pigeon) {
        this.pigeon = pigeon;
        method_6265(EnumSet.of(class_4134.field_18405));
    }

    @Override
    public boolean method_6264() {
        return !pigeon.isSitting() && pigeon.method_5942().method_6357() && pigeon.method_59922().method_43048(25) == 0;
    }

    @Override
    public boolean method_6266() {
        return pigeon.method_5942().method_23966();
    }

    @Override
    public void method_6269() {
        class_243 pos = this.findPos();
        if (pos != null) {
            pigeon.method_5942().method_6334(pigeon.method_5942().method_6348(class_2338.method_49638(pos), 1), 1.0);
        }
    }

    @Nullable
    private class_243 findPos() {
        class_243 pos;
        @Nullable class_2338 pigeonholePos = pigeon.getPigeonholeHandler().getTargetPos();
        if (pigeon.getPigeonholeHandler().isPigeonholeValid(pigeon.method_37908(), pigeon.method_24515())
              && pigeonholePos != null && !pigeon.closerThan(pigeonholePos, WANDER_THRESHOLD)) {
            class_243 pigeonholeCenter = Position.getGlobalCenter(pigeon.method_37908(), pigeonholePos);
            pos = pigeonholeCenter.method_1020(pigeon.method_19538()).method_1029();
        } else {
            pos = pigeon.method_5828(0.0F);
        }

        int radius = 8;
        class_243 hoverPos = class_5533.method_31524(pigeon, radius, 12, pos.field_1352, pos.field_1350, (float) (Math.PI / 2), 3, 1);
        return hoverPos != null ? hoverPos : class_5530.method_31504(pigeon, radius, 4, -2, pos.field_1352, pos.field_1350, (float) (Math.PI / 2));
    }
}
