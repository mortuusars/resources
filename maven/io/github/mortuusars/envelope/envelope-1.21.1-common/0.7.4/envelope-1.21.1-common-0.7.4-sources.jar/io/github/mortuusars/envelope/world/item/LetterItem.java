package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.clientbound.OpenLetterViewScreenS2CP;
import io.github.mortuusars.envelope.world.item.component.LetterContent;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.NotNull;

public class LetterItem extends class_1747 implements Sealable {
    public LetterItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        if (Config.Server.LETTER_BURNING.get() && context.method_8036() != null
              && context.method_8045().method_8320(context.method_8037()).method_26164(Envelope.Tags.Blocks.BURNING)) {
            context.method_8036().method_5998(context.method_20287()).method_7934(1);
            context.method_8045().method_8396(context.method_8036(), context.method_8037(),
                  class_3417.field_14970, class_3419.field_15248, 0.6f, 0.9f + context.method_8045().method_8409().method_43057() * 0.3f);
            context.method_8045().method_8396(context.method_8036(), context.method_8037(),
                  class_3417.field_17483, class_3419.field_15248, 1f, 1f);
            class_243 p = context.method_17698();

            if (context.method_8045() instanceof class_3218 serverLevel) {
                serverLevel.method_14199(class_2398.field_11239, p.field_1352, p.field_1351, p.field_1350, 3, 0.1, 0.1, 0.1, 0);
                serverLevel.method_14199(class_2398.field_11240, p.field_1352, p.field_1351, p.field_1350, 5, 0.2, 0.2, 0.2, 0.02);
            }

            return class_1269.field_5812;
        }

        if (!context.method_8046()) {
            return class_1269.field_5811;
        }
        return super.method_7884(context);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        class_1799 stack = player.method_5998(usedHand);
        stack.method_57379(Envelope.DataComponents.LETTER_CONTENT,
              stack.method_57825(Envelope.DataComponents.LETTER_CONTENT, LetterContent.EMPTY).withUnfolded(true));
        player.method_7357().method_7906(this, 5);

        if (player instanceof class_3222 serverPlayer) {
            Packets.sendToClient(new OpenLetterViewScreenS2CP(usedHand), serverPlayer);
        }

        level.method_43129(player, player, Envelope.SoundEvents.PAPER_CRACKLE.get(), class_3419.field_15248, 1, 1);
        return class_1271.method_29237(stack, level.field_9236);
    }

    @Override
    public class_1799 seal(class_1937 level, class_1799 stack, Seal seal) {
        class_1799 sealedLetter = stack.method_60503(Envelope.Items.SEALED_LETTER.get());
        sealedLetter.method_57379(Envelope.DataComponents.SEAL, seal);
        return sealedLetter;
    }
}