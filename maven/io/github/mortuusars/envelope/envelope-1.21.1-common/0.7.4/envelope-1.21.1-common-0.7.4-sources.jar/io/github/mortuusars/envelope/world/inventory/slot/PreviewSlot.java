package io.github.mortuusars.envelope.world.inventory.slot;

import io.github.mortuusars.envelope.Envelope;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

public class PreviewSlot extends class_1735 {
    public static final class_2960 OVERLAY_SPRITE = Envelope.resource("preview_slot_overlay");

    public PreviewSlot(class_1799 stack, int slot, int x, int y) {
        super(new class_1277(stack), slot, x, y);
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return false;
    }

    @Override
    public boolean method_7674(class_1657 player) {
        return false;
    }

    @Override
    public boolean method_55059() {
        return true;
    }
}
