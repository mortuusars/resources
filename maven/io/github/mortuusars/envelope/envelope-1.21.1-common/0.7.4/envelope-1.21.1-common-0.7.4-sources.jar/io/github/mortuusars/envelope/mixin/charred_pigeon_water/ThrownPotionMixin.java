package io.github.mortuusars.envelope.mixin.charred_pigeon_water;

import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.envelope.world.entity.CharredPigeon;
import net.minecraft.class_1299;
import net.minecraft.class_1686;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_3218;
import net.minecraft.class_3856;
import net.minecraft.class_3857;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings("LocalMayUseName")
@Mixin(class_1686.class)
public abstract class ThrownPotionMixin extends class_3857 implements class_3856 {
    public ThrownPotionMixin(class_1299<? extends class_3857> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "applyWater", at = @At("RETURN"))
    private void onApplyWater(CallbackInfo ci, @Local class_238 boundingBox) {
        if (method_37908() instanceof class_3218 level) {
            for (CharredPigeon pigeon : level.method_18467(CharredPigeon.class, boundingBox)) {
                if (pigeon.canConvert()) {
                    pigeon.convert(level);
                }
            }
        }
    }
}
