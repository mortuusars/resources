package io.github.mortuusars.envelope.util.component;

import com.mojang.serialization.Codec;
import net.minecraft.class_2561;
import net.minecraft.class_5244;
import net.minecraft.class_5819;
import net.minecraft.class_6012;

public record ComponentProvider(class_6012<WeightedComponent> list) {
    public static final Codec<ComponentProvider> CODEC = class_6012.method_34991(WeightedComponent.FULL_CODEC)
          .xmap(ComponentProvider::new, ComponentProvider::list);

    public static final ComponentProvider EMPTY = new ComponentProvider(class_6012.method_34990());

    public static ComponentProvider of(class_2561 component) {
        return new ComponentProvider(class_6012.method_34989(new WeightedComponent(component)));
    }

    public class_2561 get(class_5819 randomSource) {
        return list.method_34992(randomSource).map(WeightedComponent::getComponent).orElse(class_5244.field_39003);
    }
}
