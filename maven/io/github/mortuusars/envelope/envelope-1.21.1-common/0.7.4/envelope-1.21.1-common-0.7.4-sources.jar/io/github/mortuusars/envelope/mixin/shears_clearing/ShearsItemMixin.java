package io.github.mortuusars.envelope.mixin.shears_clearing;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.ApplicatorItem;
import net.minecraft.class_1799;
import net.minecraft.class_1820;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1820.class)
public class ShearsItemMixin implements ApplicatorItem {
    @SuppressWarnings({"AddedMixinMembersNamePattern"}) // This could cause crash due to name conflict, but probability of it should be pretty low.
    @Override
    public boolean shouldRenderTooltipWhileCarrying(class_1937 level, class_1799 carried, class_1799 hovered) {
        return hovered.method_31573(Envelope.Tags.Items.MAILABLE);
    }
}
