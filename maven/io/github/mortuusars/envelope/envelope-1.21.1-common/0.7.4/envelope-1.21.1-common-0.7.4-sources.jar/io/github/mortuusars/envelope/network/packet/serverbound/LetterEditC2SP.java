package io.github.mortuusars.envelope.network.packet.serverbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.packet.Packet;
import io.github.mortuusars.envelope.world.item.LetterAndQuillItem;
import io.github.mortuusars.envelope.world.item.component.LetterAndQuillContent;
import io.github.mortuusars.envelope.world.item.component.LetterContent;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3419;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record LetterEditC2SP(int slot, String text, boolean fold) implements Packet {
    public static final class_2960 ID = Envelope.resource("letter_edit");
    public static final class_9154<LetterEditC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, LetterEditC2SP> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48550, LetterEditC2SP::slot,
            class_9135.method_56364(LetterAndQuillContent.MAX_LENGTH), LetterEditC2SP::text,
            class_9135.field_48547, LetterEditC2SP::fold,
            LetterEditC2SP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (slot < 0 || slot > player.method_31548().field_7547.size()) {
            Envelope.LOGGER.error("Cannot handle {} packet: slot {} is not in valid range (0 - {}).",
                    ID, slot, player.method_31548().field_7547.size());
            return false;
        }

        class_1799 letterAndQuill = player.method_31548().method_5438(slot);
        if (!(letterAndQuill.method_7909() instanceof LetterAndQuillItem)) {
            Envelope.LOGGER.error("Cannot handle {} packet: item in slot {} is not a LetterAndQuillItem.", ID, slot);
            return false;
        }

        LetterAndQuillContent content = new LetterAndQuillContent(text);

        if (fold) {
            class_1799 letter = new class_1799(Envelope.Items.LETTER.get());
            if (!content.isEmpty()) {
                letter.method_57379(Envelope.DataComponents.LETTER_CONTENT, content.toWritten());
            }

            player.method_37908().method_43129(null, player, Envelope.SoundEvents.PAPER_CRACKLE.get(), class_3419.field_15248, 1, 1);
            player.method_31548().method_5447(slot, letter);
            player.method_7281(Envelope.Stats.LETTERS_FOLDED.get());
        } else {
            if (!content.isEmpty()) {
                letterAndQuill.method_57379(Envelope.DataComponents.LETTER_AND_QUILL_CONTENT, content);
            } else {
                letterAndQuill.method_57381(Envelope.DataComponents.LETTER_AND_QUILL_CONTENT);
            }
        }

        return true;
    }
}
