package io.github.mortuusars.envelope.world.entity.spawner;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.world.GameTime;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.mail.delivery.background.FinishedBackgroundCourier;
import io.github.mortuusars.envelope.world.mail.delivery.background.BackgroundDelivery;
import io.github.mortuusars.envelope.world.mail.MailService;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_156;
import net.minecraft.class_1928;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class FinishedBackgroundCourierSpawner extends Spawner {
    public FinishedBackgroundCourierSpawner() {
        super(10);
    }

    @Override
    public boolean worksIn(class_3218 level) {
        return MailService.operatesIn(level);
    }

    @Override
    public void spawn(class_3218 level) {
        if (Config.Server.DELIVERY_SPAWNING_RESPECTS_DOMOBSPAWNING_RULE.get()
              && !level.method_8450().method_8355(class_1928.field_19390)) {
            return;
        }

        BackgroundDelivery backgroundDelivery = MailService.of(level).getBackgroundDelivery();
        List<FinishedBackgroundCourier> couriers = backgroundDelivery.getFinishedCouriers();

        if (couriers.isEmpty()) {
            return;
        }

        FinishedBackgroundCourier courier = class_156.method_32309(couriers, level.method_8409());

        @Nullable class_2338 spawnPos = Position.findNearbyHeightmapSpawnPosition(level, courier.spawnPos(), 2);
        if (spawnPos == null) {
            return;
        }

        @Nullable class_1297 entity = courier.entityData().createEntity(level);
        if (entity == null) {
            return;
        }

        entity.method_5725(spawnPos, entity.method_36454(), entity.method_36455());
        level.method_30771(entity);

        if (entity instanceof Pigeon pigeon) {
            long tiredUntil = courier.finishedAt() + Config.Server.PIGEON_TIRED_AFTER_DELIVERY_TICKS.get();
            int tiredTicks = Math.max(0, GameTime.of(level).remainingTo(tiredUntil).getAsInt());
            pigeon.setTiredTicks(tiredTicks);
        }

        backgroundDelivery.removeFinishedCourier(courier);
    }
}