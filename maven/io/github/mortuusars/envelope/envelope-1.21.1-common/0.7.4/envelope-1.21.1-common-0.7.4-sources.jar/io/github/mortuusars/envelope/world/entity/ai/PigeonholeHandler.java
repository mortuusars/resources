package io.github.mortuusars.envelope.world.entity.ai;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.integration.sable.ContraptionTargets;
import io.github.mortuusars.envelope.util.Ticks;
import io.github.mortuusars.envelope.util.bugger.Bugger;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.block.PigeonholeBlockEntity;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3922;
import net.minecraft.class_4153;
import net.minecraft.class_4156;
import net.minecraft.class_5819;

public class PigeonholeHandler {
    public static final int MAX_BLACKLISTED_TARGETS = 3;
    public static final int DEFAULT_LOCATE_COOLDOWN = 100;
    public static final int FORGET_HOME_TIME = Ticks.IN_GAME_DAY * 3;

    public static final Codec<PigeonholeHandler> CODEC = RecordCodecBuilder.create(i -> i.group(
          class_2338.field_25064.optionalFieldOf("target_pos").forGetter(o -> Optional.ofNullable(o.getTargetPos())),
          class_2338.field_25064.optionalFieldOf("home_pos").forGetter(o -> Optional.ofNullable(o.getHomePos())),
          Codec.INT.optionalFieldOf("ticks_since_last_rest", -1).forGetter(PigeonholeHandler::getTicksSinceLastRest),
          Codec.INT.optionalFieldOf("locate_cooldown", 0).forGetter(PigeonholeHandler::getLocateCooldown),
          Codec.INT.optionalFieldOf("want_cooldown", 0).forGetter(PigeonholeHandler::getWantCooldown),
          Codec.INT.optionalFieldOf("enter_cooldown", 0).forGetter(PigeonholeHandler::getEnterCooldown)
    ).apply(i, PigeonholeHandler::new));
    public static final Logger LOGGER = LogUtils.getLogger();

    protected final List<class_2338> blacklistedPositions = new ArrayList<>();

    protected @Nullable class_2338 targetPos;
    protected @Nullable class_2338 homePos;
    protected int ticksSinceLastRest;
    protected int locateCooldown;
    protected int wantCooldown;
    protected int enterCooldown;

    public PigeonholeHandler(Optional<class_2338> targetPos, Optional<class_2338> homePos, int ticksSinceLastRest,
                             int locateCooldown, int wantCooldown, int enterCooldown) {
        this.targetPos = targetPos.orElse(null);
        this.homePos = homePos.orElse(null);
        this.ticksSinceLastRest = ticksSinceLastRest;
        this.locateCooldown = locateCooldown;
        this.wantCooldown = wantCooldown;
        this.enterCooldown = enterCooldown;
    }

    public PigeonholeHandler() {
        this(Optional.empty(), Optional.empty(), -1, 0, 0, 0);
    }

    public @Nullable class_2338 getTargetPos() {
        return targetPos;
    }

    public void setTargetPos(@Nullable class_2338 targetPos) {
        this.targetPos = targetPos;
    }

    public @Nullable class_2338 getHomePos() {
        return homePos;
    }

    public PigeonholeHandler setHomePos(@Nullable class_2338 homePos) {
        this.homePos = homePos;
        return this;
    }

    public int getTicksSinceLastRest() {
        return ticksSinceLastRest;
    }

    public PigeonholeHandler setTicksSinceLastRest(int ticks) {
        this.ticksSinceLastRest = ticks;
        return this;
    }

    public int getEnterCooldown() {
        return enterCooldown;
    }

    public void setEnterCooldown(int cooldown) {
        this.enterCooldown = cooldown;
    }

    public int getWantCooldown() {
        return wantCooldown;
    }

    public void setWantCooldown(int cooldown) {
        this.wantCooldown = cooldown;
    }

    public void setDefaultWantCooldown() {
        setWantCooldown(Config.Server.PIGEON_MIN_TICKS_OUTSIDE_PIGEONHOLE.get());
    }

    public void setRandomWantCooldownUpToDefault(class_5819 random) {
        setWantCooldown(random.method_43048(Config.Server.PIGEON_MIN_TICKS_OUTSIDE_PIGEONHOLE.get()));
    }

    public int getLocateCooldown() {
        return locateCooldown;
    }

    public void setLocateCooldown(int cooldown) {
        this.locateCooldown = cooldown;
    }

    public void resetLocateCooldown() {
        setLocateCooldown(DEFAULT_LOCATE_COOLDOWN);
    }

    // --

    public void tick(Pigeon pigeon, class_1937 level) {
        if (ticksSinceLastRest >= 0) ticksSinceLastRest++;
        if (wantCooldown > 0) wantCooldown--;
        if (locateCooldown > 0) locateCooldown--;

        if (level instanceof class_3218) {
            if (getHomePos() != null && getTicksSinceLastRest() > FORGET_HOME_TIME) {
                LOGGER.debug("{} has forgotten their home position [{}].", pigeon, getHomePos().method_23854());
                setHomePos(null);
            }

            if (pigeon.field_6012 % 20 == 0) {
                // This is important for the pigeon to forget its previous pigeonhole if far away or no longer existing
                if (getTargetPos() != null && !pigeon.isDelivering() && !isPigeonholeValid(level, pigeon.method_24515())) {
                    setTargetPos(null);
                }
                Bugger.PIGEON_PIGEONHOLE_HANDLER.send(pigeon.method_5628(), this);
            }
        }
    }

    // --

    public List<class_2338> findNearbyPigeonholesWithSpace(class_3218 level, class_2338 pos) {
        int radius = 48;
        List<class_2338> poiResults = level.method_19494()
              .method_19125(holder -> holder.method_40225(Envelope.PoiTypes.PIGEONHOLE), pos, radius, class_4153.class_4155.field_18489)
              .map(class_4156::method_19141)
              .filter(p -> level.method_8321(p) instanceof PigeonholeBlockEntity pigeonhole
                    && pigeonhole.hasSpaceForAnotherOccupant())
              .collect(Collectors.toList());

        class_243 position = class_243.method_24953(pos);

        return ContraptionTargets.locateNearby(
              level,
              position,
              radius,
              poiResults,
              () -> ContraptionTargets.findNearbyPigeonholes(level, position,
                    radius, PigeonholeBlockEntity::hasSpaceForAnotherOccupant));
    }

    public Optional<PigeonholeBlockEntity> getPigeonholeAtTargetPos(class_1937 level) {
        @Nullable class_2338 pos = getTargetPos();
        if (pos != null && level.method_8477(pos) && level.method_8321(pos) instanceof PigeonholeBlockEntity be) {
            return Optional.of(be);
        }
        return Optional.empty();
    }

    public boolean wantsToEnterPigeonhole(Pigeon pigeon) {
        if (getEnterCooldown() > 0) return false;
        class_1937 level = pigeon.method_37908();
        boolean wouldPreferInside = level.method_23886() || level.method_8419() || level.method_8546();
        boolean tiredOfOutside = pigeon.isTired() || getWantCooldown() <= 0;
        return (wouldPreferInside || tiredOfOutside);
    }

    public boolean isPigeonholeValid(class_1937 level, class_2338 entityPos) {
        @Nullable class_2338 currentPos = getTargetPos();
        if (currentPos == null) return false;
        if (Position.distanceToSqr(level, currentPos, entityPos.method_46558()) > 32 * 32) return false;
        return level.method_8321(currentPos) instanceof PigeonholeBlockEntity;
    }

    public boolean isTargetBlacklisted(class_2338 pos) {
        return blacklistedPositions.contains(pos);
    }

    private void blacklistTarget(class_2338 pos) {
        blacklistedPositions.add(pos);

        while (blacklistedPositions.size() > MAX_BLACKLISTED_TARGETS) {
            blacklistedPositions.removeFirst();
        }
    }

    public void clearBlacklist() {
        blacklistedPositions.clear();
    }

    public void dropAndBlacklistPigeonhole() {
        if (getTargetPos() != null) {
            blacklistTarget(getTargetPos());
        }

        dropPigeonhole();
    }

    public void dropPigeonhole() {
        setTargetPos(null);
        resetLocateCooldown();
    }

    @Override
    public String toString() {
        return "PigeonholeHandler{" +
              "targetPos=" + targetPos +
              ", homePos=" + homePos +
              ", ticksSinceLastRest=" + ticksSinceLastRest +
              ", locateCooldown=" + locateCooldown +
              ", wantCooldown=" + wantCooldown +
              ", enterCooldown=" + enterCooldown +
              '}';
    }

    // --

    public static boolean isPigeonholeSafe(class_1937 level, class_2338 pos) {
        return !class_3922.method_23895(level, pos) && !Position.isFireNearby(level, pos);
    }
}
