package io.github.mortuusars.envelope.client.gui.tooltip;

import com.google.common.base.Preconditions;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_7919;

public class Tooltips {
    public static <T> Map<T, class_7919> createMap(List<T> values, Function<T, class_2561> convertFunc) {
        Preconditions.checkArgument(!values.isEmpty(), "values list must not be empty.");
        Map<T, class_7919> map = new HashMap<>();
        for (T value : values) {
            map.put(value, class_7919.method_47407(convertFunc.apply(value)));
        }
        return map;
    }
}
