package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_3414;
import net.minecraft.class_5632;

public class SealedPackageItem extends PackageItem implements Unsealable {
    public SealedPackageItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    @Override
    public class_1935 getUnsealedItem() {
        return Envelope.Items.PACKAGE.get();
    }

    @Override
    public @NotNull Optional<class_5632> method_32346(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.SEAL));
    }

    @Override
    public @NotNull class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8950;
    }

    @Override
    public @NotNull class_3414 method_21830() {
        return getUnsealingSound();
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 entity) {
        return getUnsealingDuration(stack, entity);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        player.method_6019(hand);
        return class_1271.method_22427(player.method_5998(hand));
    }

    @Override
    public @NotNull class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 entity) {
        return unseal(stack, level, entity);
    }
}
