package io.github.mortuusars.envelope.integration.sable;

import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.block.PigeonholeBlockEntity;
import io.github.mortuusars.envelope.world.block.PigeonholeRegistry;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlockEntity;
import io.github.mortuusars.envelope.world.block.mailbox.Mailboxes;
import io.github.mortuusars.envelope.world.mail.MailService;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;

/**
 * Target discovery for blocks on Sable moving structures, where vanilla POI lookup does not apply.
 */
public final class ContraptionTargets {
    private ContraptionTargets() {
    }

    /**
     * Sorts POI results by projected distance, optionally merging in contraption-local targets when Sable is loaded.
     */
    public static List<class_2338> locateNearby(class_3218 level, class_243 entityPos, int radius,
                                              List<class_2338> poiResults,
                                              Supplier<List<class_2338>> contraptionResults) {
        if (MovingStructureCompat.isAvailable()) {
            return mergeWithContraptionTargets(level, entityPos, radius, poiResults, contraptionResults.get())
                  .toList();
        }

        return sortByProjectedDistance(level, entityPos, poiResults.stream()).toList();
    }

    /**
     * O(n) over all registered mailbox addresses — acceptable while mailbox counts stay small.
     * {@link class_3218#method_8321(class_2338)} at plot-local positions relies on Sable's level hooks.
     */
    public static List<class_2338> findNearbyMailboxes(class_3218 level, class_243 entityPos, int radius,
                                                     Predicate<MailboxBlockEntity> filter) {
        int radiusSqr = radius * radius;
        Mailboxes mailboxes = MailService.of(level).getMailboxes();

        return mailboxes.getAllAddresses().stream()
              .map(mailboxes::getPositionOf)
              .flatMap(Optional::stream)
              .filter(pos -> Position.distanceToSqr(level, pos, entityPos) <= radiusSqr)
              .filter(pos -> level.method_8321(pos) instanceof MailboxBlockEntity mailbox
                    && filter.test(mailbox))
              .sorted(Comparator.comparingDouble(pos -> Position.distanceToSqr(level, pos, entityPos)))
              .toList();
    }

    /**
     * O(n) over {@link PigeonholeRegistry} entries for the level.
     * {@link class_3218#method_8321(class_2338)} at plot-local positions relies on Sable's level hooks.
     */
    public static List<class_2338> findNearbyPigeonholes(class_3218 level, class_243 entityPos, int radius,
                                                       Predicate<PigeonholeBlockEntity> filter) {
        int radiusSqr = radius * radius;

        return PigeonholeRegistry.getAll(level).stream()
              .filter(pos -> Position.distanceToSqr(level, pos, entityPos) <= radiusSqr)
              .filter(pos -> level.method_8321(pos) instanceof PigeonholeBlockEntity pigeonhole
                    && filter.test(pigeonhole))
              .sorted(Comparator.comparingDouble(pos -> Position.distanceToSqr(level, pos, entityPos)))
              .toList();
    }

    public static Stream<class_2338> mergeWithContraptionTargets(class_3218 level, class_243 entityPos, int radius,
                                                               List<class_2338> poiResults,
                                                               List<class_2338> contraptionResults) {
        int radiusSqr = radius * radius;

        return sortByProjectedDistance(level, entityPos,
              Stream.concat(poiResults.stream(), contraptionResults.stream())
                    .distinct()
                    .filter(pos -> Position.distanceToSqr(level, pos, entityPos) <= radiusSqr));
    }

    private static Stream<class_2338> sortByProjectedDistance(class_3218 level, class_243 entityPos, Stream<class_2338> positions) {
        return positions.sorted(Comparator.comparingDouble(pos -> Position.distanceToSqr(level, pos, entityPos)));
    }
}
