package io.github.mortuusars.envelope.integration.jei.extensions;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.crafting.LetterCloningRecipe;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.ingredient.ICraftingGridHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.category.extensions.vanilla.crafting.ICraftingCategoryExtension;
import net.minecraft.class_1799;
import net.minecraft.class_8786;
import java.util.List;

public class LetterCloningRecipeExtension implements ICraftingCategoryExtension<LetterCloningRecipe> {
    @Override
    public void setRecipe(class_8786<LetterCloningRecipe> holder, IRecipeLayoutBuilder builder, ICraftingGridHelper craftingGridHelper, IFocusGroup focuses) {
        List<List<class_1799>> inputs = List.of(
              List.of(new class_1799(Envelope.Items.LETTER.get())),
              List.of(new class_1799(Envelope.Items.LETTER_AND_QUILL.get()))
        );

        List<class_1799> outputs = List.of(new class_1799(Envelope.Items.LETTER.get()));

        craftingGridHelper.createAndSetInputs(builder, VanillaTypes.ITEM_STACK, inputs, 0, 0);
        craftingGridHelper.createAndSetOutputs(builder, VanillaTypes.ITEM_STACK, outputs);
    }
}
