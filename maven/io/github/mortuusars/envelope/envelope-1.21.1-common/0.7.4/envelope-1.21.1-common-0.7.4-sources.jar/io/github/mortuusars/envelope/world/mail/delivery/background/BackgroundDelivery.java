package io.github.mortuusars.envelope.world.mail.delivery.background;

import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.entity.spawning.SpawnableItem;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;

import java.util.*;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

public class BackgroundDelivery extends class_18 {
    public static final Codec<BackgroundDelivery> CODEC = RecordCodecBuilder.create(instance -> instance.group(
          Codec.list(BackgroundCourier.CODEC)
                .optionalFieldOf("couriers", Collections.emptyList())
                .forGetter(BackgroundDelivery::getActiveCouriers),
          Codec.list(FinishedBackgroundCourier.CODEC)
                .optionalFieldOf("finished_couriers", Collections.emptyList())
                .forGetter(BackgroundDelivery::getFinishedCouriers),
          Codec.list(SpawnableItem.CODEC)
                .optionalFieldOf("dropped_items", Collections.emptyList())
                .forGetter(BackgroundDelivery::getDroppedMail)
    ).apply(instance, BackgroundDelivery::new));
    public static final Logger LOGGER = LogUtils.getLogger();

    protected final List<BackgroundCourier> couriers;
    protected final List<BackgroundCourier> pendingCouriers = new ArrayList<>();
    protected final List<FinishedBackgroundCourier> finishedCouriers;
    protected final List<SpawnableItem> droppedItems;

    public BackgroundDelivery(List<BackgroundCourier> couriers, List<FinishedBackgroundCourier> finishedCouriers, List<SpawnableItem> droppedItems) {
        this.couriers = new ArrayList<>(couriers);
        this.finishedCouriers = new ArrayList<>(finishedCouriers);
        this.droppedItems = new ArrayList<>(droppedItems);
    }

    public BackgroundDelivery() {
        this(Collections.emptyList(), Collections.emptyList(), Collections.emptyList());
    }

    public List<BackgroundCourier> getActiveCouriers() {
        return couriers;
    }

    public List<FinishedBackgroundCourier> getFinishedCouriers() {
        return finishedCouriers;
    }

    public List<SpawnableItem> getDroppedMail() {
        return droppedItems;
    }

    public void addCourier(BackgroundCourier courier) {
        pendingCouriers.add(courier);
        method_80();
    }

    public void removeCourier(BackgroundCourier courier) {
        if (couriers.remove(courier)) {
            method_80();
        }
    }

    public void addFinishedCourier(FinishedBackgroundCourier courier) {
        finishedCouriers.add(courier);
        method_80();
    }

    public void removeFinishedCourier(FinishedBackgroundCourier courier) {
        if (finishedCouriers.remove(courier)) {
            method_80();
        }
    }

    public void addDroppedMail(SpawnableItem item) {
        droppedItems.add(item);
        method_80();
    }

    public void removeDroppedMail(SpawnableItem item) {
        if (droppedItems.remove(item)) {
            method_80();
        }
    }

    // --

    public void tick(class_3218 level) {
        couriers.removeIf(courier -> {
            if (courier.isRemoved()) {
                method_80();
                return true;
            }
            courier.tick(level);
            return false;
        });
        processPendingCouriers();
    }

    protected void processPendingCouriers() {
        // Using buffer for new couriers, to avoid ConcurrentModification when courier addition is caused by courier tick
        couriers.addAll(pendingCouriers);
        pendingCouriers.clear();
    }

    // -- Save / Load

    public static BackgroundDelivery get(class_3218 level, String name) {
        return level.method_17983().method_17924(factory(), name);
    }

    @Override
    public boolean method_79() {
        return !couriers.isEmpty() || super.method_79();
    }

    public @NotNull class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
        processPendingCouriers();
        return CODEC.encode(this, registries.method_57093(class_2509.field_11560), tag)
              .ifError(e -> Envelope.LOGGER.error("Cannot save BackgroundDelivery: {}", e.message()))
              .result()
              .filter(t -> t instanceof class_2487)
              .map(t -> ((class_2487) t))
              .orElse(tag);
    }

    private static BackgroundDelivery load(class_2487 tag, class_7225.class_7874 registries) {
        return CODEC.decode(registries.method_57093(class_2509.field_11560), tag)
              .ifError(e -> Envelope.LOGGER.error("Cannot load BackgroundDelivery: {}", e.message()))
              .result()
              .map(Pair::getFirst)
              .orElseGet(BackgroundDelivery::new);
    }

    private static class_8645<BackgroundDelivery> factory() {
        return new class_8645<>(BackgroundDelivery::new, BackgroundDelivery::load, null);
    }
}