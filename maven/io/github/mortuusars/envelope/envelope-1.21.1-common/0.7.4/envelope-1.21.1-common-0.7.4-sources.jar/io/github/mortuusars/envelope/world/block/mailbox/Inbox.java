package io.github.mortuusars.envelope.world.block.mailbox;

import com.google.common.base.Preconditions;
import io.github.mortuusars.envelope.world.item.component.Id;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.address.Address;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1799;

public interface Inbox {
    Address getAddress();

    int getInboxCapacity();

    @NotNull List<class_1799> getAllMail();

    void onInboxChanged();

    default boolean isInboxFull() {
        return getAllMail().size() >= getInboxCapacity();
    }

    default boolean isInboxEmpty() {
        return getAllMail().isEmpty();
    }

    default class_1799 getMail(int slot) {
        if (slot >= 0 && slot < getAllMail().size()) {
            return getAllMail().get(slot);
        }
        return class_1799.field_8037;
    }

    // --

    default boolean addMailNoUpdate(int slot, class_1799 mail) {
        Preconditions.checkArgument(!mail.method_7960(), "Inbox can only store non-empty mail.");
        Preconditions.checkArgument(mail.method_7947() == 1, "Inbox can only store mail with stack size of 1. Got: " + mail.method_7947());
        Preconditions.checkArgument(Mail.hasId(mail), "Inbox can only store mail with 'envelope:mail_id' component.");
        Preconditions.checkArgument(slot >= 0, "Slot index should be larger or equal to 0. Got: " + slot);
        int size = getAllMail().size();
        if (size < getInboxCapacity()) {
            if (slot > size) {
                getAllMail().add(mail);
            } else {
                getAllMail().add(slot, mail);
            }
            return true;
        }
        return false;
    }

    default boolean addMailNoUpdate(class_1799 mail) {
        return addMailNoUpdate(Integer.MAX_VALUE, mail);
    }

    default boolean addMail(int slot, class_1799 mail) {
        if (addMailNoUpdate(slot, mail)) {
            onInboxChanged();
            onMailAdded(mail);
            return true;
        }
        return false;
    }

    default boolean addMail(class_1799 mail) {
        if (addMailNoUpdate(mail)) {
            onInboxChanged();
            onMailAdded(mail);
            return true;
        }
        return false;
    }

    // --

    default class_1799 removeMailNoUpdate(int slot) {
        if (slot >= 0 && slot < getAllMail().size()) {
            return getAllMail().remove(slot);
        }
        return class_1799.field_8037;
    }

    default class_1799 removeMailNoUpdate() {
        return removeMailNoUpdate(0);
    }

    default class_1799 removeMail(Id id) {
        for (int i = 0; i < getAllMail().size(); i++) {
            class_1799 mail = getAllMail().get(i);
            if (id.equals(Mail.getId(mail))) {
                return removeMail(i);
            }
        }
        return class_1799.field_8037;
    }

    default class_1799 removeMail(int slot) {
        class_1799 mail = removeMailNoUpdate(slot);
        if (!mail.method_7960()) {
            onInboxChanged();
            onMailRemoved(slot, mail);
        }
        return mail;
    }

    default class_1799 removeMail() {
        return removeMail(0);
    }

    default boolean clearMail() {
        if (getAllMail().isEmpty()) {
            return false;
        }
        getAllMail().clear();
        onInboxChanged();
        onMailCleared();
        return true;
    }

    // --

    /**
     * Intended to be called from outside (when delivering mail for example). <br>
     * Inbox can override it to add custom logic on deliberate insertion (not through hopper, etc).
     */
    default void onMailInserted(class_1799 mail) {
    }

    /**
     * Called when mail has been added. Can be overriden by implementations to execute related logic.
     */
    default void onMailAdded(class_1799 mail) {
    }

    /**
     * Called when mail has been removed. Can be overriden by implementations to execute related logic.
     */
    default void onMailRemoved(int slot, class_1799 mail) {
    }

    /**
     * Called when mail has been cleared. Can be overriden by implementations to execute related logic.
     */
    default void onMailCleared() {
    }
}
