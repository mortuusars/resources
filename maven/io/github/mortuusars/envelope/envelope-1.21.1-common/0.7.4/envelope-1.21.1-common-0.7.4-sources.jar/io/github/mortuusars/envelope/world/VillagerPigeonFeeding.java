package io.github.mortuusars.envelope.world;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.Ticks;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import net.minecraft.class_1646;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3852;
import net.minecraft.class_4102;
import net.minecraft.class_4115;
import net.minecraft.class_4140;
import net.minecraft.class_4215;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

public class VillagerPigeonFeeding {
    public static final int VILLAGER_PIGEON_FOOD_PICKUP_DELAY = (int) Ticks.fromSeconds(30);
    public static final int VILLAGER_PIGEON_FEED_BASE_COOLDOWN = (int) Ticks.fromSeconds(5);

    public static boolean tryFeed(class_1646 villager) {
        if (!Config.Server.PIGEON_EATS_SEEDS.get()) {
            return false;
        }

        if (Config.Server.VILLAGER_FEEDING_PIGEONS_NITWIT_ONLY.get()
              && villager.method_7231().method_16924() != class_3852.field_17062) {
            return false;
        }

        @Nullable class_4115 tracker = villager.method_18868().method_18904(class_4140.field_18446).orElse(null);
        if (!(tracker instanceof class_4102 entityTracker && entityTracker.method_35066() instanceof Pigeon pigeon)
              || villager.method_5739(pigeon) > 4
              || !villager.method_37908().method_8311(villager.method_24515())
              || villager.method_59922().method_43048(60) != 0) {
            return false;
        }

        class_4215.method_43392(villager,
              getFoodItem(villager),
              pigeon.method_19538().method_49272(villager.method_59922(), 1.5f),
              new class_243(0.3, 0.3, 0.3),
              0.5f);
        villager.method_43077(Envelope.SoundEvents.VILLAGER_THROW_PIGEON_FOOD.get());

        // Adding delay so nearby villagers (including the feeding one) won't pick up thrown food immediately
        class_238 area = new class_238(villager.method_24515()).method_1014(16);
        villager.method_37908().method_18467(class_1646.class, area)
              .forEach(entity -> {
                  if (entity instanceof FeedingVillager feedingVillager) {
                      feedingVillager.envelope$addPigeonFoodPickupDelay(getPigeonFoodPickupDelay(entity));
                  }
              });

        return true;
    }

    public static int getPigeonFoodPickupDelay(class_1646 villager) {
        return VILLAGER_PIGEON_FOOD_PICKUP_DELAY;
    }

    public static int getFeedCooldown(class_1646 villager) {
        return VILLAGER_PIGEON_FEED_BASE_COOLDOWN * (villager.method_59922().method_43051(1, 3));
    }

    public static class_1799 getFoodItem(class_1646 villager) {
        float chance = villager.method_59922().method_43057();

        class_6862<class_1792> pool = chance >= 0.98f ? Envelope.Tags.Items.VILLAGER_FEEDING_PIGEON_FOOD_RARE
              : chance >= 0.78f ? Envelope.Tags.Items.VILLAGER_FEEDING_PIGEON_FOOD_UNCOMMON
              : Envelope.Tags.Items.VILLAGER_FEEDING_PIGEON_FOOD_COMMON;

        class_1792 food = class_7923.field_41178.method_56159(pool, villager.method_59922())
              .map(class_6880::comp_349)
              .orElse(class_1802.field_8317);

        return new class_1799(food, getFoodCount(villager));
    }

    public static int getFoodCount(class_1646 villager) {
        int pigeonsNearby = villager.method_37908().method_18467(Pigeon.class, villager.method_5829().method_1014(8)).size();
        return villager.method_59922().method_43051(1, class_3532.method_15340(pigeonsNearby, 1, 3) + 1);
    }

    public interface FeedingVillager {
        void envelope$addPigeonFoodPickupDelay(int delay);
    }
}
