package io.github.mortuusars.envelope.util.bugger_data;

import io.github.mortuusars.envelope.util.bugger.BuggerEntityOverhead;
import io.github.mortuusars.envelope.world.GameTime;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.entity.ai.MailboxHandler;
import io.github.mortuusars.envelope.world.entity.ai.PigeonholeHandler;
import java.util.ArrayList;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_2561;

public class PigeonEntityDataDisplay implements BuggerEntityOverhead.EntityDataDisplay {
    @Override
    public void addLines(class_1297 entity, ArrayList<class_2561> lines) {
        if (!(entity instanceof Pigeon pigeon)) return;

        if (pigeon.getCurrentDelivery().isPresent()) {
            Delivery delivery = pigeon.getCurrentDelivery().get();
            lines.add(class_2561.method_43473()
                  .method_10852(delivery.getSender().format().asSender().toComponent())
                  .method_27693(" → ")
                  .method_10852(delivery.getRecipient().format().asRecipient().toComponent()));
            lines.add(line(delivery.getPhase().toPrettyString()).method_27692(class_124.field_1080));
            return;
        }

        if (pigeon.isTired()) {
            lines.add(line("Tired [" + GameTime.format(pigeon.getTiredTicks(), true).getString() + "]"));
        }

        PigeonholeHandler pigeonholeHandler = pigeon.getPigeonholeHandler();
        MailboxHandler mailboxHandler = pigeon.getMailboxHandler();

        if (mailboxHandler.getTargetPos() != null) {
            lines.add(line("Going to Mailbox for pickup"));
        }

        if (pigeonholeHandler.wantsToEnterPigeonhole(pigeon)) {
            lines.add(line(pigeonholeHandler.getTargetPos() != null ? "Going to Pigeonhole" : "Looking for Pigeonhole"));
        } else {
            lines.add(line("Would want to enter after: " + pigeonholeHandler.getWantCooldown() / 20));
            if (pigeonholeHandler.getEnterCooldown() > 0) {
                lines.add(line("Could enter after: " + pigeonholeHandler.getEnterCooldown() / 20));
            }
        }

        if (pigeonholeHandler.getTargetPos() != null) {
            lines.add(line("Target: [" + pigeonholeHandler.getTargetPos().method_23854() + "]"));
        }
        if (pigeonholeHandler.getHomePos() != null) {
            lines.add(line("Home: [" + pigeonholeHandler.getHomePos().method_23854() + "]"));
        }
    }
}
