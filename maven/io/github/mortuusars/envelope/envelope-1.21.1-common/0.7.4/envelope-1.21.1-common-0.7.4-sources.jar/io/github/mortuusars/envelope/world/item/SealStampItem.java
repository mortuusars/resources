package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.inventory.tooltip.SealDieTooltipComponent;
import io.github.mortuusars.envelope.world.item.component.seal.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5536;
import net.minecraft.class_5632;
import net.minecraft.class_6880;

public class SealStampItem extends class_1792 implements ApplicatorItem {
    public SealStampItem(class_1793 properties) {
        super(properties);
    }

    @SuppressWarnings("removal")
    public Optional<class_6880<SealSymbol>> getDie(class_1799 stack) {
        if (stack.method_57826(Envelope.DataComponents.SEAL_STAMP_IMPRESSION)) {
            stack.method_57379(Envelope.DataComponents.SEAL_STAMP_DIE, stack.method_57381(Envelope.DataComponents.SEAL_STAMP_IMPRESSION));
        }
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.SEAL_STAMP_DIE));
    }

    public class_6880<SealSymbol> getDieOrDefault(class_1799 stack, class_5455 registryAccess, @Nullable class_1657 player) {
        return getDie(stack).orElseGet(() ->
              SealSymbol.getOrThrow(registryAccess, SealSymbol.firstCharOrDefault(player)));
    }

    // --

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> components, class_1836 flag) {
        if (flag.method_8035()) {
            getDie(stack)
                  .flatMap(class_6880::method_40230)
                  .ifPresent(key -> {
                      components.add(class_2561.method_43470("Die: ").method_27692(class_124.field_1063)
                            .method_10852(class_2561.method_43470(key.method_29177().toString()).method_27692(class_124.field_1080)));
                  });
        }
    }

    @Override
    public @NotNull Optional<class_5632> method_32346(class_1799 stack) {
        return Optional.of(new SealDieTooltipComponent(getDie(stack)));
    }

    @Override
    public boolean shouldRenderTooltipWhileCarrying(class_1937 level, class_1799 carried, class_1799 hovered) {
        return hovered.method_57826(Envelope.DataComponents.SEAL)
              || (hovered.method_7909() instanceof Sealable sealable && sealable.canSeal(level, hovered));
    }

    @Override
    public boolean method_31565(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player) {
        if (action != class_5536.field_27014) {
            return false;
        }

        if (!slot.method_32754(player)) {
            player.method_43077(class_3417.field_14762);
            return true;
        }

        class_1799 target = slot.method_7677();

        @Nullable Seal existingSeal = target.method_57824(Envelope.DataComponents.SEAL);
        if (existingSeal != null && canApplyGold(stack, player)) {
            class_5321<SealMaterial> currentMaterial = existingSeal.material().method_40230().orElse(SealMaterial.RED_WAX);
            class_5321<SealMaterial> newMaterial = currentMaterial == SealMaterial.RED_WAX ? SealMaterial.GOLD : SealMaterial.RED_WAX;

            class_6880<SealMaterial> material = SealMaterial.getOrThrow(player.method_56673(), newMaterial);

            target.method_57379(Envelope.DataComponents.SEAL, new Seal(material, existingSeal.impression(), existingSeal.signature()));
            slot.method_7673(target);
            player.method_43077(class_3417.field_14920);
            return true;
        }

        if (!(target.method_7909() instanceof Sealable sealable) || !sealable.canSeal(player.method_37908(), target)) {
            player.method_43077(class_3417.field_14762);
            return true;
        }

        class_1799 sealResult = sealable.seal(player.method_37908(), target, createSeal(stack, player));
        slot.method_7673(sealResult);
        player.method_43077(class_3417.field_14920);

        player.method_7281(Envelope.Stats.SEALS_APPLIED.get());

        return true;
    }

    public Seal createSeal(class_1799 stack, class_1657 player) {
        return new Seal(
              SealMaterial.getOrThrow(player.method_56673(), SealMaterial.RED_WAX),
              getDieOrDefault(stack, player.method_56673(), player),
              player.method_5477());
    }

    protected boolean canApplyGold(class_1799 stack, class_1657 player) {
        //TODO: patreon supporters
        return false;
    }
}