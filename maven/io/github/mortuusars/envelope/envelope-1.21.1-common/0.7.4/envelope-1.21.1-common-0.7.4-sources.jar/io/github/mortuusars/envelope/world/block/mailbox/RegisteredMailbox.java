package io.github.mortuusars.envelope.world.block.mailbox;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import net.minecraft.class_2338;

public class RegisteredMailbox {
    public static final Codec<RegisteredMailbox> CODEC = RecordCodecBuilder.create(instance -> instance.group(
          BlockAddress.STRING_CODEC.fieldOf("address").forGetter(RegisteredMailbox::getAddress),
          class_2338.field_25064.fieldOf("pos").forGetter(RegisteredMailbox::getPos)
    ).apply(instance, RegisteredMailbox::new));

    private final BlockAddress address;
    private final class_2338 pos;

    public RegisteredMailbox(BlockAddress address, class_2338 pos) {
        this.address = address;
        this.pos = pos;
    }

    public BlockAddress getAddress() {
        return address;
    }

    public class_2338 getPos() {
        return pos;
    }
}