package io.github.mortuusars.envelope.world.mail.service;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailRecipe;
import io.github.mortuusars.envelope.world.item.crafting.mail.Mailing;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import io.github.mortuusars.envelope.world.mail.address.type.PlayerAddress;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import io.github.mortuusars.envelope.world.mail.dropoff.MailDropOffContext;
import io.github.mortuusars.envelope.world.mail.dropoff.MailDropOffResult;
import net.minecraft.class_124;
import net.minecraft.class_1277;
import net.minecraft.class_1429;
import net.minecraft.class_1496;
import net.minecraft.class_155;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_8786;
import net.minecraft.class_9334;
import net.minecraft.network.chat.*;
import java.util.Arrays;
import java.util.Optional;

public class EquineAssuranceBureau {
    private static final class_2960 RECIPE_ID = ServiceAddresses.EQUINE_ASSURANCE_BUREAU.method_29177()
          .method_45138("mailing/")
          .method_48331("/golden_horse_armor");
    private static final long MIN_SEND_INTERVAL = class_155.field_29704;
    private static final String DATA_LAST_SEND_TIME = "last_send_time";
    private static final String DATA_SENT_NOTICES_COUNT = "sent_notices_count";
    private static final String DATA_DELIVERIES_COUNT = "deliveries_count";

    public static void onTameAnimal(class_3222 player, class_1429 animal) {
        if (!Config.Server.SERVICE_EQUINE_BUREAU_NOTICE_SENDING_ENABLED.get() || !MailService.operatesIn(player.method_37908())) {
            return;
        }

        Optional<ServiceAddress> bureauAddress = ServiceAddress.get(player.method_56673(), ServiceAddresses.EQUINE_ASSURANCE_BUREAU);
        if (bureauAddress.isEmpty()) {
            return;
        }

        Optional<class_8786<MailRecipe>> recipe = Mailing.getAllRecipesOf(bureauAddress.get(), player.method_51469())
              .filter(recipeHolder -> recipeHolder.comp_1932().equals(RECIPE_ID))
              .findFirst();
        if (recipe.isEmpty()) {
            return;
        }

        if (!(animal instanceof class_1496) && player.method_59922().method_43048(5) != 0) {
            return; // 1 in 5 chance of sending for animals other than horses.
        }

        MailService service = MailService.of(player.method_51469());

        PlayerAddress playerAddress = new PlayerAddress(player);
        Optional<BlockAddress> defaultAddress = service.getPlayerDefaultAddress(playerAddress);
        if (defaultAddress.isEmpty()) {
            return;
        }

        class_2487 data = service.getPersistentData().get(ServiceAddresses.EQUINE_ASSURANCE_BUREAU.method_29177());
        class_2487 playerData = data.method_10562(player.method_5820());

        long lastSendTime = playerData.method_10537(DATA_LAST_SEND_TIME);
        if (lastSendTime > 0 && service.getGameTime() - lastSendTime < MIN_SEND_INTERVAL) {
            return;
        }

        int sentNoticesCount = playerData.method_10550(DATA_SENT_NOTICES_COUNT);
        int deliveriesCount = playerData.method_10550(DATA_DELIVERIES_COUNT);
        double chance = Math.max(0.02, 1.0 / (1 + ((sentNoticesCount + deliveriesCount) * 2)));

        if (service.getLevel().method_8409().method_43058() < chance
              && sendLetter(player.method_51469(), playerAddress)) {
            playerData.method_10569(DATA_SENT_NOTICES_COUNT, sentNoticesCount + 1);
            playerData.method_10544(DATA_LAST_SEND_TIME, service.getGameTime());
            data.method_10566(player.method_5820(), playerData);
            service.getPersistentData().set(ServiceAddresses.EQUINE_ASSURANCE_BUREAU.method_29177(), data);
        }
    }

    public static boolean sendLetter(class_3218 level, Address recipient) {
        if (!MailService.operatesIn(level)) {
            return false;
        }

        class_1799 letter = createLetter(level);
        if (letter.method_7960()) {
            return false;
        }

        return ServiceAddress.get(level.method_30349(), ServiceAddresses.EQUINE_ASSURANCE_BUREAU)
              .map(address -> {
                  MailService.of(level).getDeliveryManager().startService(Delivery.draft()
                        .deliver(letter)
                        .from(address)
                        .to(recipient));
                  return true;
              })
              .orElse(false);
    }

    public static void onCraft(MailDropOffContext context, ServiceAddress address, MailDropOffResult craftingResult) {
        context.getDelivery().getOwner()
              .filter(owner -> isCarryingRecipeResult(context, craftingResult))
              .flatMap(owner -> context.getService().getKnownPlayers().getDataOf(owner))
              .ifPresent(player -> {
                  class_2487 data = context.getService().getPersistentData().get(ServiceAddresses.EQUINE_ASSURANCE_BUREAU.method_29177());
                  class_2487 playerData = data.method_10562(player.getProfile().getName());

                  playerData.method_10569(DATA_DELIVERIES_COUNT, playerData.method_10550(DATA_DELIVERIES_COUNT) + 1);
                  data.method_10566(player.getProfile().getName(), playerData);

                  context.getService().getPersistentData().set(ServiceAddresses.EQUINE_ASSURANCE_BUREAU.method_29177(), data);
              });
    }

    private static boolean isCarryingRecipeResult(MailDropOffContext context, MailDropOffResult craftingResult) {
        class_1799 expectedResult = context.getService().getLevel().method_8433()
              .method_8130(RECIPE_ID)
              .map(holder -> holder.comp_1933().method_8110(context.getService().getLevel().method_30349()))
              .orElse(new class_1799(class_1802.field_8077));

        class_1799 actualResult = craftingResult.getMail()
              .method_57825(Envelope.DataComponents.PACKAGE_CONTENTS, PackageContents.EMPTY)
              .method_59984(0);

        return class_1799.method_31577(expectedResult, actualResult);
    }

    public static class_1799 createLetter(class_3218 level) {
        Optional<class_8786<MailRecipe>> recipe = ServiceAddress.get(level.method_30349(), ServiceAddresses.EQUINE_ASSURANCE_BUREAU)
              .flatMap(address -> Mailing.getAllRecipesOf(address, level)
                    .filter(recipeHolder -> recipeHolder.comp_1932().equals(RECIPE_ID))
                    .findFirst());

        if (recipe.isEmpty()) {
            return class_1799.field_8037;
        }

        class_1277 inputContainer = new class_1277(PackageContents.SLOTS);

        recipe.get().comp_1933().method_8117().stream()
              .map(i -> Arrays.stream(i.method_8105()).findFirst())
              .filter(Optional::isPresent)
              .forEach(item -> inputContainer.method_5491(item.get()));

        class_5250 requiredItems = class_2561.method_43473();
        boolean multiple = false;

        for (class_1799 stack : inputContainer.method_24514()) {
            class_2583 style = createItemStyle(stack);

            if (multiple) {
                requiredItems.method_27693(", ");
            }

            if (stack.method_7947() > 1) {
                requiredItems.method_10852(class_2561.method_43470(stack.method_7947() + "x ").method_27696(style));
            }

            requiredItems.method_10852(stack.method_7964().method_27661().method_27696(style));

            multiple = true;
        }

        class_2561 body = class_2561.method_43469("letter.envelope.equine_assurance_notice.body", requiredItems);

        return Mail.createLetter(body)
              .set(class_9334.field_50239, class_2561.method_43471("letter.envelope.equine_assurance_notice.name"))
              .get();
    }

    private static class_2583 createItemStyle(class_1799 stack) {
        return class_2583.field_24360
              .method_10977(class_124.field_1079)
              .method_30938(true)
              .method_10949(new class_2568(class_2568.class_5247.field_24343, new class_2568.class_5249(stack)));
    }
}
