package io.github.mortuusars.envelope.network.packet.serverbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.packet.Packet;
import io.github.mortuusars.envelope.world.inventory.PackingMenu;
import io.github.mortuusars.envelope.world.mail.address.Address;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record PackingMenuPresetAddressC2SP(Optional<Address> address) implements Packet {
    public static final class_2960 ID = Envelope.resource("packing_menu_preset_address");
    public static final class_9154<PackingMenuPresetAddressC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, PackingMenuPresetAddressC2SP> STREAM_CODEC = class_9139.method_56434(
          class_9135.method_56382(Address.STREAM_CODEC), PackingMenuPresetAddressC2SP::address,
          PackingMenuPresetAddressC2SP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (!(player.field_7512 instanceof PackingMenu packingMenu)) {
            Envelope.LOGGER.error("Cannot handle {} packet: player {} does not have PackingMenu open.",
                  ID, player.method_5820());
            return false;
        }

        packingMenu.presetAddress(address.orElse(null));

        return false;
    }
}
