package io.github.mortuusars.envelope.world.item.component;

import com.mojang.serialization.Codec;
import java.util.Optional;
import java.util.function.BiFunction;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * ItemStacks cannot be used in DataComponentType because when the stack is changed
 * - it can change in more than one place and cause unwanted side effects.
 * So this is an "immutable" wrapper around the ItemStack.
 * But because it's still possible to mutate the ItemStack stored in this class - care should be taken in how we use it.
 * {@link StoredItemStack#getForReading()} should be used when ItemStack is needed for read-only tasks such as checking item type, count, etc.
 * This avoids unnecessary copying of the stack.
 * {@link StoredItemStack#getCopy()} should be used when ItemStack will be changed in any way.
 */
public class StoredItemStack {
    public static final StoredItemStack EMPTY = new StoredItemStack(class_1799.field_8037);

    public static final Codec<StoredItemStack> CODEC = class_1799.field_24671.xmap(StoredItemStack::new, StoredItemStack::getForReading);
    public static final class_9139<class_9129, StoredItemStack> STREAM_CODEC = class_1799.field_48349.method_56432(
            StoredItemStack::new,
            StoredItemStack::getForReading
    );

    private final class_1799 stack;

    public StoredItemStack(class_1799 stack) {
        this.stack = stack;
    }

    public class_1799 getForReading() {
        return stack;
    }

    public class_1799 getCopy() {
        return stack.method_7972();
    }

    public class_1792 getItem() {
        return getForReading().method_7909();
    }

    public boolean isEmpty() {
        return getForReading().method_7960();
    }

    public <T, R> Optional<R> mapIf(Class<T> clazz, BiFunction<T, class_1799, R> func) {
        if (getForReading().method_7909().getClass().equals(clazz)) {
            return Optional.ofNullable(func.apply(clazz.cast(getForReading().method_7909()), getForReading()));
        }
        return Optional.empty();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof StoredItemStack other) {
            return class_1799.method_31577(getForReading(), other.getForReading());
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return class_1799.method_57355(getForReading());
    }

    @Override
    public String toString() {
        return "ItemStackBox{" +
                "stack=" + getForReading() +
                '}';
    }
}
