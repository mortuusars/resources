package io.github.mortuusars.envelope.client.renderer.entity;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.model.CharredPigeonModel;
import io.github.mortuusars.envelope.client.renderer.entity.layer.CharredPigeonBackpackLayer;
import io.github.mortuusars.envelope.client.renderer.entity.layer.CharredPigeonFireLayer;
import io.github.mortuusars.envelope.world.entity.CharredPigeon;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5601;
import net.minecraft.class_5617;
import net.minecraft.class_927;
import org.jetbrains.annotations.NotNull;

public class CharredPigeonRenderer extends class_927<CharredPigeon, CharredPigeonModel> {
    public static final class_5601 MODEL_LAYER = new class_5601(Envelope.resource("charred_pigeon"), "main");

    public static final class_2960 TEXTURE = Envelope.resource("textures/entity/charred_pigeon/charred_pigeon.png");

    public CharredPigeonRenderer(class_5617.class_5618 context) {
        super(context, new CharredPigeonModel(context.method_32167(MODEL_LAYER)), 0.35f);
        method_4046(new CharredPigeonFireLayer(this));
        method_4046(new CharredPigeonBackpackLayer(this, context.method_32170()));
    }

    @Override
    public @NotNull class_2960 getTextureLocation(CharredPigeon entity) {
        return TEXTURE;
    }

    @Override
    protected float getBob(CharredPigeon pigeon, float partialTick) {
        float f = class_3532.method_16439(partialTick, pigeon.oFlap, pigeon.flap);
        float g = class_3532.method_16439(partialTick, pigeon.oFlapSpeed, pigeon.flapSpeed);
        return (class_3532.method_15374(f) + 1.0F) * g;
    }
}