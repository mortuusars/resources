package io.github.mortuusars.envelope.util.bugger.data;

import io.github.mortuusars.envelope.util.bugger.Bugger;
import java.util.function.Consumer;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

public class NbtData extends Data<class_2487> {
    private final boolean accumulate;

    public NbtData(class_2960 id) {
        this(id, false);
    }

    public NbtData(class_2960 id, boolean accumulate) {
        super(id, class_2487.field_25128);
        this.accumulate = accumulate;
    }

    @Override
    public class_2487 apply(class_2487 oldValue, class_2487 newValue) {
        if (accumulate) return oldValue.method_10543(newValue);
        return newValue;
    }

    public void sendValues(Consumer<class_2487> tag) {
        if (Bugger.isEnabled()) {
            class_2487 compoundTag = new class_2487();
            tag.accept(compoundTag);
            send(compoundTag);
        }
    }
}
