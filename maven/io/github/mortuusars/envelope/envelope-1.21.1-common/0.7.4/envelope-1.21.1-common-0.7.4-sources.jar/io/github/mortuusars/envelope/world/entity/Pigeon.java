package io.github.mortuusars.envelope.world.entity;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.Ticks;
import io.github.mortuusars.envelope.util.bugger.Bugger;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.block.occupiable.Occupiable;
import io.github.mortuusars.envelope.world.entity.ai.MailboxHandler;
import io.github.mortuusars.envelope.world.entity.ai.PigeonNavigation;
import io.github.mortuusars.envelope.world.entity.ai.PigeonholeHandler;
import io.github.mortuusars.envelope.world.entity.ai.goal.*;
import io.github.mortuusars.envelope.world.entity.spawning.SpawnableEntityData;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.delivery.*;
import net.minecraft.class_1266;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1331;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1353;
import net.minecraft.class_1361;
import net.minecraft.class_1391;
import net.minecraft.class_1407;
import net.minecraft.class_1429;
import net.minecraft.class_1432;
import net.minecraft.class_1451;
import net.minecraft.class_1542;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3701;
import net.minecraft.class_3730;
import net.minecraft.class_3852;
import net.minecraft.class_4019;
import net.minecraft.class_4050;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_5425;
import net.minecraft.class_5531;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import net.minecraft.class_7;
import net.minecraft.class_7988;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.animal.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.*;
import java.util.function.Predicate;

public class Pigeon extends class_1429 implements class_7988<class_6880<PigeonVariant>>, class_1432, PhysicalCourier {
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final List<String> IGNORED_TAGS = Arrays.asList(
          "Air",
          "ArmorDropChances",
          "ArmorItems",
          "Brain",
          "CanPickUpLoot",
          "DeathTime",
          "FallDistance",
          "FallFlying",
          "Fire",
          "HandDropChances",
          "HandItems",
          "HurtByTimestamp",
          "HurtTime",
          "LeftHanded",
          "Motion",
          "NoGravity",
          "OnGround",
          "PortalCooldown",
          "Pos",
          "Rotation",
          "SleepingX",
          "SleepingY",
          "SleepingZ",
          "Passengers",
          "UUID",
          "leash",
          "Sitting",
          "Delivery"
    );

    public static final Predicate<class_1309> AVOID_SELECTOR = entity -> {
        if (entity instanceof class_1451) return Config.Server.PIGEON_HUNTED_BY_CAT.get();
        if (entity instanceof class_3701) return Config.Server.PIGEON_HUNTED_BY_OCELOT.get();
        if (entity instanceof class_4019) return Config.Server.PIGEON_HUNTED_BY_FOX.get();
        return false;
    };

    public static final Predicate<class_1542> SEARCHED_FOOD_ITEMS_PREDICATE = item ->
          item.method_5805() && !item.method_6977() && item.method_6983().method_31573(Envelope.Tags.Items.PIGEON_FOOD);

    public static final Predicate<class_1308> FOLLOW_PREDICATE = mob -> Config.Server.PIGEON_EATS_SEEDS.get()
          && Config.Server.VILLAGER_FEEDING_PIGEONS.get()
          && mob instanceof class_1646 villager
          && (!Config.Server.VILLAGER_FEEDING_PIGEONS_NITWIT_ONLY.get()
          || villager.method_7231().method_16924() == class_3852.field_17062)
          && mob.method_59922().method_43048(60) == 0;

    private static final class_2940<class_6880<PigeonVariant>> DATA_VARIANT = class_2945.method_12791(Pigeon.class, Envelope.EntityDataSerializers.PIGEON_VARIANT.get());
    private static final class_2940<Boolean> DATA_DELIVERING = class_2945.method_12791(Pigeon.class, class_2943.field_13323);
    private static final class_2940<Boolean> DATA_HAS_MAIL = class_2945.method_12791(Pigeon.class, class_2943.field_13323);
    private static final class_2940<Boolean> DATA_SERVICE = class_2945.method_12791(Pigeon.class, class_2943.field_13323);
    private static final class_2940<Integer> DATA_TIRED_TICKS = class_2945.method_12791(Pigeon.class, class_2943.field_13327);
    private static final class_2940<Integer> DATA_EATING_TICKS = class_2945.method_12791(Pigeon.class, class_2943.field_13327);

    public float flap;
    public float flapSpeed;
    public float oFlapSpeed;
    public float oFlap;
    protected float flapping = 1.0F;
    protected float nextFlap = 1.0F;

    protected PigeonholeHandler pigeonholeHandler;
    protected MailboxHandler mailboxHandler;

    protected PigeonWanderGoal wanderGoal;
    protected PigeonAvoidEntityGoal<class_1429> avoidEntityGoal;

    protected @Nullable Delivery delivery;
    protected @Nullable CourierOrigin origin;
    protected int timeInUltraWarmDimension;

    public Pigeon(class_1299<? extends Pigeon> entityType, class_1937 level) {
        super(entityType, level);
        field_6207 = new class_1331(this, 10, false);
        pigeonholeHandler = new PigeonholeHandler();
        mailboxHandler = new MailboxHandler();
        method_5941(class_7.field_9, -1.0F);
        method_5941(class_7.field_3, -1.0F);
        method_5952(true);
    }

    // -- Spawn

    public static boolean checkSpawnRules(class_1299<Pigeon> pigeon, class_1936 level,
                                          class_3730 spawnType, class_2338 pos, class_5819 random) {
        return Config.Server.PIGEON_SPAWNS_NATURALLY.get()
              && level.method_8320(pos.method_10074()).method_26164(Envelope.Tags.Blocks.PIGEONS_SPAWNABLE_ON)
              && method_39448(level, pos);
    }

    public static Pigeon createService(class_3218 level) {
        Pigeon pigeon = Objects.requireNonNull(Envelope.EntityTypes.PIGEON.get().method_5883(level),
              "Failed to create an entity. This should not happen.");
        pigeon.setVariant(PigeonVariant.getRandomServiceVariant(level.method_30349(), level.method_8409()));
        pigeon.setOrigin(CourierOrigin.service());
        return pigeon;
    }

    public static Courier spawnServiceCourier(class_3218 level, Delivery delivery) {
        Pigeon pigeon = createService(level);
        pigeon.startDelivery(delivery);
        return pigeon.transitionToBackground(level);
    }

    @Override
    public @NotNull class_1315 method_5943(class_5425 level, class_1266 difficulty,
                                                 class_3730 spawnType, @Nullable class_1315 spawnGroupData) {
        setVariant(PigeonVariant.getRandomSpawnVariant(level.method_30349(), level.method_8409(), level.method_23753(method_24515())));
        getPigeonholeHandler().setRandomWantCooldownUpToDefault(level.method_8409());
        return super.method_5943(level, difficulty, spawnType, spawnGroupData);
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
              .method_26868(class_5134.field_23716, 8.0)
              .method_26868(class_5134.field_23720, 1F)
              .method_26868(class_5134.field_23719, 0.2F)
              .method_26868(class_5134.field_23721, 3.0);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(DATA_VARIANT, PigeonVariant.withFallback(method_56673(), Optional.empty()));
        builder.method_56912(DATA_DELIVERING, false);
        builder.method_56912(DATA_SERVICE, false);
        builder.method_56912(DATA_HAS_MAIL, false);
        builder.method_56912(DATA_TIRED_TICKS, 0);
        builder.method_56912(DATA_EATING_TICKS, 0);
    }

    // -- Variant

    public @NotNull class_6880<PigeonVariant> method_47827() {
        return field_6011.method_12789(DATA_VARIANT);
    }

    public void setVariant(class_6880<PigeonVariant> variant) {
        field_6011.method_12778(DATA_VARIANT, variant);
    }

    // -- AI

    @Override
    protected void method_5959() {
        field_6201.method_6277(0, new PigeonDeliverMailGoal(this));
        field_6201.method_6277(1, avoidEntityGoal = new PigeonAvoidEntityGoal<>(this, class_1429.class,
              5, 0.5, 0.6, AVOID_SELECTOR));
        field_6201.method_6277(2, new PigeonPanicGoal(this, 3.5));
        field_6201.method_6277(2, new PigeonEnterPigeonholeGoal(this));
        field_6201.method_6277(3, new PigeonStartDeliveryFromMailboxGoal(this));
        field_6201.method_6277(4, new class_1341(this, 1.0));
        field_6201.method_6277(5, new class_1391(this, 1.25, itemStack -> itemStack.method_31573(Envelope.Tags.Items.PIGEON_FOOD), false));
        field_6201.method_6277(6, new class_1353(this, 1.25));
        field_6201.method_6277(7, new PigeonLocatePigeonholeGoal(this));
        field_6201.method_6277(7, new PigeonGoToPigeonholeGoal(this));
        field_6201.method_6277(7, new PigeonLocateMailboxGoal(this));
        field_6201.method_6277(7, new PigeonSitGoal(this));
        field_6201.method_6277(8, new PigeonGoToMailboxGoal(this));
        field_6201.method_6277(9, new PigeonSearchForFoodGoal(this));
        field_6201.method_6277(9, new FollowSpecificMobGoal(this, FOLLOW_PREDICATE, 0.5, 3, 8));
        field_6201.method_6277(10, wanderGoal = new PigeonWanderGoal(this, 0.5));
        field_6201.method_6277(11, new class_1347(this));
        field_6201.method_6277(12, new class_1361(this, class_1657.class, 8.0F));
        field_6201.method_6277(13, new class_1361(this, class_1646.class, 8.0F, 0.01F));
    }

    @Override
    protected @NotNull class_1407 method_5965(class_1937 level) {
        class_1407 navigation = new PigeonFlyingPathNavigation(this, level);
        navigation.method_6332(false);
        navigation.method_6354(true);
        navigation.method_6331(true);
        return navigation;
    }

    @Override
    public void method_6007() {
        super.method_6007();
        this.calculateFlapping();

        getPigeonholeHandler().tick(this, method_37908());
        getMailboxHandler().tick(this, method_37908());

        if (getTiredTicks() > 0) {
            setTiredTicks(getTiredTicks() - 1);

            if (method_37908().method_8409().method_43048(32) == 0) {
                method_37908().method_8406(class_2398.field_11251,
                      method_19538().field_1352 + method_59922().method_43057() * 0.25f,
                      method_19538().field_1351 + method_59922().method_43057() * 0.25f,
                      method_19538().field_1350 + method_59922().method_43057() * 0.25f, 0, 0, 0);
            }
        }

        if (isSitting() && method_5942().method_23966()) {
            setSitting(false);
        }

        class_1799 mainHandItem = method_6047();
        if (method_6481(mainHandItem)) {
            setEatingTicks(getEatingTicks() + 1);

            if (getEatingTicks() == 5) {
                if (method_37908() instanceof class_3218 serverLevel) {
                    serverLevel.method_14199(new class_2392(class_2398.field_11218, mainHandItem),
                          method_19538().field_1352, method_19538().field_1351 + 0.3, method_19538().field_1350, 5, 0.25, 0.25, 0.25, 0);
                }
                method_5783(method_18869(mainHandItem), 0.5f, method_59922().method_43057() * 0.2f + 0.9f);
            }

            if (getEatingTicks() >= 10) {
                method_5673(class_1304.field_6173, class_1799.field_8037);
                setEatingTicks(0);
            }
        } else if (getEatingTicks() > 10) {
            setEatingTicks(0);
        }

        if (Config.Server.PIGEON_CONVERT_INTO_CHARRED.get() && method_37908() instanceof class_3218 serverLevel) {
            if (canConvert()) {
                timeInUltraWarmDimension++;
            } else {
                timeInUltraWarmDimension = 0;
            }

            if (timeInUltraWarmDimension > Config.Server.PIGEON_CONVERT_INTO_CHARRED_TICKS.get() && !method_29504()) {
                convert(serverLevel);
            }
        }
    }

    public boolean canConvert() {
        return method_37908().method_8597().comp_644() && !method_5987();
    }

    protected void convert(class_3218 serverLevel) {
        class_1799 carriedMail = getCurrentDelivery().map(Delivery::getMail).orElse(class_1799.field_8037);
        @Nullable CharredPigeon charredPigeon = method_29243(Envelope.EntityTypes.CHARRED_PIGEON.get(), true);
        if (charredPigeon != null) {
            charredPigeon.setCarriedMail(carriedMail);
            charredPigeon.method_18799(method_18798());
            charredPigeon.method_36457(method_36455());
            charredPigeon.method_5847(method_5791());
            charredPigeon.method_36456(method_36454());
            if (method_5942().method_6355() != null) {
                charredPigeon.method_5942().method_6334(charredPigeon.method_5942().method_6348(method_5942().method_6355(), 1), 1);
            }

            serverLevel.method_43129(null, charredPigeon, class_3417.field_15013, class_3419.field_15254, 0.6f, 1);
            serverLevel.method_14199(class_2398.field_11240, method_19538().field_1352, method_19538().field_1351 + 0.2, method_19538().field_1350, 15, 0.4, 0.4, 0.4, 0);
            serverLevel.method_14199(class_2398.field_11239, method_19538().field_1352, method_19538().field_1351 + 0.2, method_19538().field_1350, 6, 0.4, 0.4, 0.4, 0);
        }
    }

    @Override
    public void method_5982() {
        // This method seems to be called every tick, even if entity is not in ticking range
        // It's a good place to check if courier should be transitioned to background
        if (method_37908() instanceof class_3218 level && !method_5987() && isDelivering() && !Position.isInSimulationDistance(level, this)) {
            transitionToBackground(level);
            return;
        }

        super.method_5982();
    }

    @Override
    public boolean method_5947() {
        // Not sure if this changes much, but just to make sure.
        return super.method_5947() || isDelivering() || getPigeonholeHandler().getHomePos() != null;
    }

    protected void calculateFlapping() {
        this.oFlap = this.flap;
        this.oFlapSpeed = this.flapSpeed;
        this.flapSpeed = this.flapSpeed + (float) (!this.method_24828() && !this.method_5765() ? 4 : -1) * 0.3F;
        this.flapSpeed = class_3532.method_15363(this.flapSpeed, 0.0F, 1.0F);
        if (!this.method_24828() && this.flapping < 1.0F) {
            this.flapping = 1.0F;
        }

        this.flapping *= 0.9F;
        class_243 vec3 = this.method_18798();
        if (!this.method_24828() && vec3.field_1351 < 0.0) {
            float descendRate = getDescendRate();
            this.method_18799(vec3.method_18805(1, descendRate, 1));
        }

        this.flap = this.flap + this.flapping * 2.0F;
    }

    protected float getDescendRate() {
        if (delivery != null) {
            if (delivery.getPhase().isDescending()) return 0.9f;
            if (delivery.getPhase().isAscending()) return 0.5f;
        }
        return 0.75f;
    }

    @Override
    public boolean method_20820(class_1799 stack) {
        return Config.Server.PIGEON_EATS_SEEDS.get()
              && method_24828()
              && method_6047().method_7960()
              && method_6481(stack)
              && getEatingTicks() <= 0;
    }

    @Override
    public boolean method_18397(class_1799 stack) {
        return method_20820(stack);
    }

    @Override
    public boolean method_5939(class_1799 stack) {
        return method_20820(stack);
    }

    @Override
    protected void method_5949(class_1542 itemEntity) {
        if (method_59922().method_43048(10) != 0) {
            return;
        }
        class_1799 item = itemEntity.method_6983();
        if (itemEntity.method_24828() && method_5739(itemEntity) < 1 && method_5939(item)) {
            if (item.method_7947() > 1) {
                method_5775(item.method_7971(item.method_7947() - 1));
            }

            method_29499(itemEntity);
            method_5673(class_1304.field_6173, item.method_7971(1));
            method_6103(itemEntity, item.method_7947());
            itemEntity.method_31472();
            setEatingTicks(0);
        }
    }

    @Override
    protected boolean method_27071() {
        return super.method_27071() && (origin == null || !origin.isService());
    }

    @Override
    protected void method_16080(class_3218 level, class_1282 damageSource) {
        super.method_16080(level, damageSource);

        getCurrentDelivery().ifPresent(delivery -> {
            diedWhileDelivering(level, damageSource, delivery);
        });
    }

    protected void diedWhileDelivering(class_3218 level, class_1282 damageSource, Delivery delivery) {
        String message = damageSource.method_5506(this).getString();
        String carriedItem = !delivery.getMail().method_7960()
              ? " a " + delivery.getMail().method_7964().getString()
              : "";
        String addresses = delivery.getSender().getString()
              + " to "
              + delivery.getRecipient().getString();
        String service = getOrigin().isService() ? "Service " : "";
        Envelope.LOGGER.info("{}{} at [{}] while delivering{} from {}!", service, message, method_24515().method_23854(), carriedItem, addresses);

        if (!getOrigin().isService()) {
            MailService.of(level).sendCourierDeathNotice(this, delivery, damageSource);
        }

        if (!delivery.getMail().method_7960()) {
            class_1799 mail = delivery.getPhase().isOnRecipientSide()
                  ? Mail.asDelivered(delivery.getMail())
                  : delivery.getMail();
            method_5775(mail);
            delivery.setMail(class_1799.field_8037);
        }
    }

    // -- Properties

    public boolean isSitting() {
        return method_18376() == class_4050.field_40118;
    }

    public void setSitting(boolean sitting) {
        method_18380(sitting ? class_4050.field_40118 : class_4050.field_18076);
    }

    @Override
    public boolean isDelivering() {
        return field_6011.method_12789(DATA_DELIVERING);
    }

    public void setDelivering(boolean delivering) {
        field_6011.method_12778(DATA_DELIVERING, delivering);
    }

    public boolean hasMail() {
        return field_6011.method_12789(DATA_HAS_MAIL);
    }

    public void setHasMail(boolean hasMail) {
        field_6011.method_12778(DATA_HAS_MAIL, hasMail);
    }

    public boolean isService() {
        return field_6011.method_12789(DATA_SERVICE);
    }

    public void setService(boolean service) {
        field_6011.method_12778(DATA_SERVICE, service);
    }

    public boolean isTired() {
        return getTiredTicks() > 0;
    }

    public int getTiredTicks() {
        return field_6011.method_12789(DATA_TIRED_TICKS);
    }

    public void setTiredTicks(int ticks) {
        if (ticks <= 0 && getTiredTicks() > 0 && method_37908() instanceof class_3218 level) {
            level.method_14199(class_2398.field_11211,
                  method_19538().field_1352, method_19538().field_1351 + method_5829().method_17940() / 2f, method_19538().field_1350,
                  7, 0.25, 0.25, 0.25, 0);
        }

        field_6011.method_12778(DATA_TIRED_TICKS, ticks);
    }

    public int getEatingTicks() {
        return field_6011.method_12789(DATA_EATING_TICKS);
    }

    public void setEatingTicks(int ticks) {
        field_6011.method_12778(DATA_EATING_TICKS, ticks);
    }

    public boolean hasMailmanHat() {
        return isService();
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 level, class_1296 otherParent) {
        @Nullable Pigeon offspring = Envelope.EntityTypes.PIGEON.get().method_5883(level);
        if (offspring != null && otherParent instanceof Pigeon otherPigeon) {
            class_6880<PigeonVariant> variant = method_59922().method_43056() ? this.method_47827() : otherPigeon.method_47827();
            if (!variant.comp_349().inheritable()) {
                variant = PigeonVariant.withFallback(method_56673(), PigeonVariant.getRandomVariant(method_56673(), method_59922(),
                      PigeonVariant::inheritable, v -> v.weights().common()));
            }
            offspring.setVariant(variant);
        }
        return offspring;
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31573(Envelope.Tags.Items.PIGEON_FOOD);
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (method_37908().method_8608()) return false;
        if (method_29504()) return false;

        if (method_59922().method_43058() < Config.Server.PIGEON_DAMAGE_EVASION_CHANCE_WHILE_DELIVERING.get()
              && !source.method_48789(Envelope.Tags.DamageTypes.BYPASSES_PIGEON_DELIVERY_EVASION)) {

            if (method_37908() instanceof class_3218 level) {
                level.method_14199(class_2398.field_11203, method_19538().field_1352, method_19538().field_1351, method_19538().field_1350, 3, 0.3, 0.3, 0.3, 0);
                level.method_43129(null, this, class_3417.field_38923, class_3419.field_15254, 1,
                      method_59922().method_43057() * 0.1f + 0.95f);
            }

            return false;
        }

        return super.method_5643(source, amount);
    }

    @Override
    protected boolean method_5776() {
        return field_28627 > nextFlap;
    }

    @Override
    protected void method_5801() {
        method_5783(Envelope.SoundEvents.PIGEON_FLY.get(), 0.15F, 1.0F);
        nextFlap = field_28627 + flapSpeed / 2.0F;
    }

    @Override
    public boolean method_6581() {
        return !this.method_24828() && !method_5765();
    }

    @Override
    protected float method_49484() {
        if (method_52546() || avoidEntityGoal.isAvoiding()) return 0.030f;
        if (isTired()) return 0.0175f;
        return 0.0275f;
    }

    @Override
    public @NotNull class_243 method_29919() {
        return new class_243(0.0, method_5751() * 0.65F, method_17681() * 0.4F);
    }

    public boolean hasReachedTarget(class_2338 localPos) {
        return PigeonNavigation.hasReachedTarget(this, localPos, PigeonNavigation.getReachDistance());
    }

    protected boolean hasReachedTarget(class_2338 localPos, double distance) {
        return PigeonNavigation.hasReachedTarget(this, localPos, distance);
    }

    public boolean closerThan(class_2338 localPos, double distance) {
        return PigeonNavigation.isWithinReach(this, localPos, distance);
    }

    public boolean pathfindDirectlyTowards(class_2338 localPos) {
        class_2338 navigationPos = PigeonNavigation.getNavigationPos(this, localPos);
        method_5942().method_23964(10.0F);
        method_5942().method_58160(navigationPos.method_10263(), navigationPos.method_10264(), navigationPos.method_10260(), 1, 1);
        return method_5942().method_6345() != null && method_5942().method_6345().method_21655();
    }

    public void pathfindRandomlyTowards(class_2338 localPos) {
        class_243 vec3 = Position.getGlobalCenter(method_37908(), localPos).method_1023(0, 0.5, 0);
        int i = 0;
        class_2338 blockPos = this.method_24515();
        int j = (int) vec3.field_1351 - blockPos.method_10264();
        if (j > 2) {
            i = 4;
        } else if (j < -2) {
            i = -4;
        }

        int k = 6;
        int l = 8;
        int m = blockPos.method_19455(Position.getNavigationPos(method_37908(), localPos));
        if (m < 15) {
            k = m / 2;
            l = m / 2;
        }

        class_243 vec32 = class_5531.method_31508(this, k, l, i, vec3, (float) (Math.PI / 10));
        if (vec32 != null) {
            this.field_6189.method_23964(1.0F);
            this.field_6189.method_6337(vec32.field_1352, vec32.field_1351, vec32.field_1350, 1);
        }
    }

    public PigeonWanderGoal getWanderGoal() {
        return wanderGoal;
    }

    // -- Pigeonhole

    public @NotNull PigeonholeHandler getPigeonholeHandler() {
        return pigeonholeHandler;
    }

    public void setPigeonholeHandler(PigeonholeHandler handler) {
        this.pigeonholeHandler = handler;
    }

    public void releasedFromPigeonhole(class_2338 pos, class_2680 state, Occupiable.ReleaseReason releaseReason) {
        if (releaseReason == Occupiable.ReleaseReason.EMERGENCY) {
            getPigeonholeHandler().setEnterCooldown(200);
        } else {
            getPigeonholeHandler().setTargetPos(pos);
            getPigeonholeHandler().setHomePos(pos);
            getPigeonholeHandler().setDefaultWantCooldown();

            if (isTired()) {
                setTiredTicks(0);
                if (method_37908() instanceof class_3218 level) {
                    level.method_14199(class_2398.field_11211, method_19538().field_1352, method_19538().field_1351, method_19538().field_1350, 5, 0.25, 0.25, 0.25, 0);
                }
            }
        }

        getPigeonholeHandler().setTicksSinceLastRest(0);

        // Immediately going for mailbox after release looks weird
        getMailboxHandler().setLocateCooldown(method_37908().method_8409().method_43051(20, MailboxHandler.DEFAULT_LOCATE_COOLDOWN));

        // Force wandering immediately, instead of standing (or falling) in front of the Pigeonhole
        // - looks especially stupid if there's an emergency
        wanderGoal.method_6304();
    }

    // -- Mailbox

    public MailboxHandler getMailboxHandler() {
        return mailboxHandler;
    }

    public Pigeon setMailboxHandler(MailboxHandler mailboxHandler) {
        this.mailboxHandler = mailboxHandler;
        return this;
    }

    // -- Sound

    @Nullable
    @Override
    public class_3414 method_5994() {
        return Envelope.SoundEvents.PIGEON_AMBIENT.get();
    }

    @Override
    public @NotNull class_3414 method_18869(class_1799 stack) {
        return Envelope.SoundEvents.PIGEON_EAT.get();
    }

    @Override
    protected class_3414 method_6011(class_1282 damageSource) {
        return Envelope.SoundEvents.PIGEON_HURT.get();
    }

    @Override
    protected class_3414 method_6002() {
        return Envelope.SoundEvents.PIGEON_DEATH.get();
    }

    /**
     * Overwritten to use entity instead of entity position.
     * This properly updates sound position for longer sounds and stops ambient sounds when entity dies.
     * I think that might be a bug that Mojang doesn't use entity overload, but maybe it's for some optimization, idk.
     */
    @Override
    public void method_5783(class_3414 sound, float volume, float pitch) {
        if (!method_5701()) {
            method_37908().method_43129(null, this, sound, method_5634(), volume, pitch);
        }
    }

    @Override
    protected void method_5712(class_2338 pos, class_2680 state) {
        method_5783(Envelope.SoundEvents.PIGEON_STEP.get(), 0.15F, 1.0F);
    }

    @Override
    public float method_6017() {
        return getPitch(field_5974) + (method_6109() ? 0.3f : 0);
    }

    public static float getPitch(class_5819 random) {
        return (random.method_43057() - random.method_43057()) * 0.1F + 1.0F;
    }

    @Override
    public @NotNull class_3419 method_5634() {
        return class_3419.field_15254;
    }

    // -- Interaction

    @Override
    public boolean method_5810() {
        return true;
    }

    @Override
    protected void method_6087(class_1297 entity) {
        if (!(entity instanceof class_1657)) {
            super.method_6087(entity);
        }
    }

    // -- Courier

    public boolean canStartDelivery() {
        return !method_60953() && !isTired() && !method_37908().method_23886() && !method_37908().method_8419() && !method_37908().method_8546();
    }

    public Courier startDelivery(Delivery delivery) {
        if (this.delivery != null && this.delivery != delivery) {
            LOGGER.warn("Starting new delivery when pigeon is already delivering. This might be an error.");
        }
        if (origin == null || !origin.isService()) {
            setOrigin(CourierOrigin.regular(method_24515()));
        }
        method_5848();
        setDelivery(delivery);
        return this;
    }

    public Optional<Delivery> getCurrentDelivery() {
        return Optional.ofNullable(delivery);
    }

    public void setDelivery(@Nullable Delivery delivery) {
        if (delivery == null && this.delivery == null) {
            return;
        }
        this.delivery = delivery;
        onDeliveryChanged();
    }

    public void onDeliveryChanged() {
        if (!method_37908().method_8608()) {
            setDelivering(getCurrentDelivery().isPresent());
            setHasMail(delivery != null && !delivery.getMail().method_7960());

            Bugger.PIGEON_DELIVERY.send(method_5628(), Optional.ofNullable(delivery));
        }
    }

    public @NotNull CourierOrigin getOrigin() {
        if (origin == null) {
            LOGGER.warn("Origin of a Pigeon was not set properly. Current position will be used as origin instead.");
            origin = CourierOrigin.regular(method_24515());
        }
        return origin;
    }

    public void setOrigin(@Nullable CourierOrigin origin) {
        this.origin = origin;
        setService(origin != null && origin.isService());
    }

    @Override
    public SpawnableEntityData toSpawnableData() {
        return SpawnableEntityData.of(this, IGNORED_TAGS);
    }

    @Override
    public int getPhaseDuration(class_3218 level, Delivery delivery, DeliveryPhase phase) {
        return switch (phase) {
            // Longer approach/depart phases to allow for pathfinding to finish
            case DEPARTING_SENDER, APPROACHING_RECIPIENT, DEPARTING_RECIPIENT, APPROACHING_SENDER -> 30 * Ticks.SECOND;
            default -> PhysicalCourier.super.getPhaseDuration(level, delivery, phase);
        };
    }

    @Override
    public void phaseStarted(class_3218 level, Delivery delivery) {
        PhysicalCourier.super.phaseStarted(level, delivery);
        if (delivery.getPhase().isTraveling()) {
            transitionToBackground(level);
        }
        onDeliveryChanged();
    }

    @Override
    public boolean handlePhaseTransition(class_3218 level, Delivery delivery) {
        if (delivery.getPhase() == DeliveryPhase.DEPARTING_SENDER && !hasReachedSegmentEndPos(delivery)) {
            Mail.returned(delivery.getMail(), DeliveryRecord.Message.UNABLE_TO_REACH);
            delivery.beginPhase(DeliveryPhase.APPROACHING_SENDER);
            return true;
        }

        if (delivery.getPhase() == DeliveryPhase.APPROACHING_RECIPIENT && !hasReachedSegmentEndPos(delivery)) {
            Mail.returned(delivery.getMail(), DeliveryRecord.Message.UNABLE_TO_REACH);
            delivery.beginPhase(DeliveryPhase.DEPARTING_RECIPIENT);
            return true;
        }

        return PhysicalCourier.super.handlePhaseTransition(level, delivery);
    }

    @Override
    public void endDelivery(class_3218 level, Delivery delivery) {
        if (!delivery.getMail().method_7960()) {
            method_5775(delivery.getMail().method_7972());
            Pigeon.LOGGER.info("{} has dropped undelivered mail on the ground.", method_5477().getString());
            delivery.setMail(class_1799.field_8037);
        }

        setDelivery(null);

        if (getOrigin().isService()) {
            onVanished(level);
            method_31472();
        } else {
            setOrigin(null);
            getPigeonholeHandler().setTargetPos(getPigeonholeHandler().getHomePos());
            // Prevent Pigeon entering Pigeonhole immediately:
            getPigeonholeHandler().setWantCooldown(20);
            setTiredTicks(Config.Server.PIGEON_TIRED_AFTER_DELIVERY_TICKS.get());
        }
    }

    protected boolean hasReachedSegmentEndPos(Delivery delivery) {
        return delivery.getRoute().getSegment(delivery.getPhase()).endPos()
              .map(endPos -> hasReachedTarget(
                    PigeonNavigation.getSegmentApproachTarget(method_37908(), endPos, delivery.getPhase())))
              .orElse(true);
    }

    // -- Save / Load

    @Override
    public void method_5652(class_2487 tag) {
        super.method_5652(tag);
        tag.method_10566("PigeonholeHandler", PigeonholeHandler.CODEC.encode(getPigeonholeHandler(), class_2509.field_11560, new class_2487()).getOrThrow());
        tag.method_10566("MailboxHandler", MailboxHandler.CODEC.encode(getMailboxHandler(), class_2509.field_11560, new class_2487()).getOrThrow());
        method_47827()
              .method_40230()
              .ifPresent(key -> tag.method_10582("Variant", key.method_29177().toString()));
        if (isSitting()) tag.method_10556("Sitting", true);
        if (getTiredTicks() > 0) tag.method_10569("TiredTicks", getTiredTicks());
        if (getEatingTicks() > 0) tag.method_10569("EatingTicks", getEatingTicks());

        if (timeInUltraWarmDimension > 0) tag.method_10569("TimeInUltraWarmDimension", timeInUltraWarmDimension);

        if (delivery != null) {
            Delivery.CODEC.encodeStart(method_56673().method_57093(class_2509.field_11560), delivery)
                  .resultOrPartial(LOGGER::error)
                  .ifPresent(value -> tag.method_10566("Delivery", value));
        }
        if (origin != null) {
            CourierOrigin.CODEC.encodeStart(class_2509.field_11560, origin)
                  .resultOrPartial(LOGGER::error)
                  .ifPresent(value -> tag.method_10566("Origin", value));
        }
    }

    @Override
    public void method_5749(class_2487 tag) {
        super.method_5749(tag);

        PigeonholeHandler.CODEC.parse(class_2509.field_11560, tag.method_10562("PigeonholeHandler"))
              .resultOrPartial(e -> LOGGER.error("Cannot parse PigeonholeHandler from tag '{}': {}", tag.method_10562("PigeonholeHandler"), e))
              .ifPresent(this::setPigeonholeHandler);
        MailboxHandler.CODEC.parse(class_2509.field_11560, tag.method_10562("MailboxHandler"))
              .resultOrPartial(e -> LOGGER.error("Cannot parse MailboxHandler from tag '{}': {}", tag.method_10562("MailboxHandler"), e))
              .ifPresent(this::setMailboxHandler);

        String variant = tag.method_10573("Variant", class_2520.field_33253)
              ? PigeonVariant.fromLegacyId(tag.method_10550("Variant"))
              : tag.method_10558("Variant");

        Optional.ofNullable(class_2960.method_12829(variant))
              .map(key -> class_5321.method_29179(Envelope.Registries.PIGEON_VARIANT, key))
              .flatMap(key -> method_56673().method_30530(Envelope.Registries.PIGEON_VARIANT)
                    .method_40264(key))
              .ifPresent(this::setVariant);

        setSitting(tag.method_10577("Sitting"));
        setTiredTicks(tag.method_10550("TiredTicks"));
        setEatingTicks(tag.method_10550("EatingTicks"));

        timeInUltraWarmDimension = tag.method_10550("TimeInUltraWarmDimension");

        if (tag.method_10545("Delivery")) {
            setDelivery(Delivery.CODEC.parse(method_56673().method_57093(class_2509.field_11560), tag.method_10562("Delivery"))
                  .resultOrPartial(e -> LOGGER.error("Cannot parse Delivery from tag '{}': {}", tag.method_10562("Delivery"), e))
                  .orElse(null)
            );
        }

        if (tag.method_10545("Origin")) {
            setOrigin(CourierOrigin.CODEC.parse(class_2509.field_11560, tag.method_10562("Origin"))
                  .resultOrPartial(e -> LOGGER.error("Cannot parse CourierOrigin from tag '{}': {}", tag.method_10562("Origin"), e))
                  .orElse(null));
        }

        setDelivering(delivery != null);
        setHasMail(delivery != null && !delivery.getMail().method_7960());
    }
}