package io.github.mortuusars.envelope.world.item.component;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.inventory.StackIngredient;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_5632;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record PaybackRequest(List<StackIngredient> items, PaybackDuration duration) implements class_5632 {
    public static final int SLOTS = 6;

    private static final Codec<PaybackRequest> FULL_CODEC = RecordCodecBuilder.create(i -> i.group(
          Codec.list(StackIngredient.CODEC, 1, SLOTS).fieldOf("ingredients").forGetter(PaybackRequest::items),
          PaybackDuration.CODEC.optionalFieldOf("duration", PaybackDuration.MEDIUM).forGetter(PaybackRequest::duration)
    ).apply(i, PaybackRequest::new));

    private static final Codec<PaybackRequest> SIMPLE_CODEC = Codec.list(StackIngredient.CODEC, 1, 6)
          .xmap(PaybackRequest::new, PaybackRequest::items);

    public static final Codec<PaybackRequest> CODEC = Codec.withAlternative(FULL_CODEC, SIMPLE_CODEC);

    public static final class_9139<class_9129, PaybackRequest> STREAM_CODEC = class_9139.method_56435(
          StackIngredient.STREAM_CODEC.method_56433(class_9135.method_58000(SLOTS)), PaybackRequest::items,
          PaybackDuration.STREAM_CODEC, PaybackRequest::duration,
          PaybackRequest::new
    );

    public PaybackRequest {
        Preconditions.checkArgument(!items.isEmpty(), "Payback must have at least one requested item.");
    }

    public PaybackRequest(List<StackIngredient> items) {
        this(items, PaybackDuration.MEDIUM);
    }

    public static Optional<PaybackRequest> create(List<StackIngredient> items, PaybackDuration duration) {
        return !items.isEmpty() ? Optional.of(new PaybackRequest(items, duration)) : Optional.empty();
    }

    public static PaybackRequest createOrDefault(List<StackIngredient> items, PaybackDuration duration) {
        return !items.isEmpty()
              ? new PaybackRequest(items, duration)
              : createDefault(duration);
    }

    public static PaybackRequest createDefault() {
        return new PaybackRequest(List.of(StackIngredient.createDefault()), PaybackDuration.MEDIUM);
    }

    public static PaybackRequest createDefault(PaybackDuration duration) {
        return new PaybackRequest(List.of(StackIngredient.createDefault()), duration);
    }

    // --

    public boolean matches(class_1263 container) {
        for (int slot = 0; slot < items().size(); slot++) {
            StackIngredient stackIngredient = items().get(slot);
            if (slot >= container.method_5439()) {
                return false;
            }
            class_1799 stack = container.method_5438(slot);
            if (!stackIngredient.test(stack)) {
                return false;
            }
        }

        return true;
    }

    public boolean matches(PackageContents packageContents) {
        for (int slot = 0; slot < items().size(); slot++) {
            StackIngredient stackIngredient = items().get(slot);
            if (slot >= packageContents.method_59983()) {
                return false;
            }
            class_1799 stack = packageContents.method_59984(slot);
            if (!stackIngredient.test(stack)) {
                return false;
            }
        }

        return true;
    }

    public Optional<StackIngredient> getRequestedItem(int index) {
        return index < items.size() ? Optional.of(items.get(index)) : Optional.empty();
    }

    // --

    public static boolean isValid(class_1799 stack) {
        return stack.method_7909().method_31568() && !stack.method_31573(Envelope.Tags.Items.CANNOT_BE_PACKAGED) && !stack.method_31573(Envelope.Tags.Items.CANNOT_BE_USED_AS_PAYBACK);
    }
}
