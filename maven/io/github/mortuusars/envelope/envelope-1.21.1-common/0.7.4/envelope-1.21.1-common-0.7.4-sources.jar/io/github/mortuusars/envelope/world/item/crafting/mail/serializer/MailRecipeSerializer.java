package io.github.mortuusars.envelope.world.item.crafting.mail.serializer;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.EnvelopeCodecs;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailCraftingRecipe;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailRecipe;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2371;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;

import java.util.function.Function;

public class MailRecipeSerializer<T extends MailCraftingRecipe> implements class_1865<T> {
    private final MapCodec<T> codec;
    private final class_9139<class_9129, T> streamCodec;

    public MailRecipeSerializer(Constructor<T> constructor) {
        this.codec = RecordCodecBuilder.mapCodec(i -> i.group(
              ServiceAddress.DEFINITION_CODEC
                    .fieldOf("address")
                    .forGetter(MailCraftingRecipe::getAddress),
              EnvelopeCodecs.recipeIngredients(PackageContents.SLOTS, Envelope.RecipeTypes.MAILING.get())
                    .fieldOf("ingredients")
                    .forGetter(MailCraftingRecipe::method_8117),
              class_1799.field_51397
                    .fieldOf("result")
                    .forGetter(MailCraftingRecipe::getResult),
              Codec.FLOAT
                    .optionalFieldOf("experience", 0.0f)
                    .forGetter(MailCraftingRecipe::getExperience)
        ).apply(i, constructor::create));

        this.streamCodec = class_9139.method_56905(
              ServiceAddress.STREAM_CODEC, MailCraftingRecipe::getAddress,
              class_1856.field_48355
                    .method_56433(class_9135.method_58000(PackageContents.SLOTS))
                    .method_56432(list ->
                                class_2371.method_10212(class_1856.field_9017, list.toArray(class_1856[]::new)),
                          Function.identity()), MailCraftingRecipe::method_8117,
              class_1799.field_48349, MailCraftingRecipe::getResult,
              class_9135.field_48552, MailCraftingRecipe::getExperience,
              constructor::create
        );
    }

    @Override
    public @NotNull MapCodec<T> method_53736() {
        return codec;
    }

    @Override
    public @NotNull class_9139<class_9129, T> method_56104() {
        return streamCodec;
    }

    @FunctionalInterface
    public interface Constructor<T extends MailRecipe> {
        T create(ServiceAddress address, class_2371<class_1856> ingredients, class_1799 result, float experience);
    }
}
