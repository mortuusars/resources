package io.github.mortuusars.envelope.client.gui.tooltip;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.world.inventory.StackIngredient;
import io.github.mortuusars.envelope.world.item.component.PaybackDuration;
import io.github.mortuusars.envelope.world.item.component.PaybackRequest;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;

public record PaybackRequestTooltipComponent(PaybackRequest paybackRequest) implements class_5684 {
    public static final class_2960 SLOT_SPRITE = Envelope.resource("tooltip/payback/slot");

    private static final class_1799 PAYBACK_TAG_SHORT = class_156.method_656(() -> {
        class_1799 stack = new class_1799(Envelope.Items.PAYBACK_TAG.get());
        stack.method_57379(Envelope.DataComponents.PAYBACK_TAG_CONTENTS, PaybackRequest.createDefault(PaybackDuration.SHORT));
        return stack;
    });
    private static final class_1799 PAYBACK_TAG_MEDIUM = class_156.method_656(() -> {
        class_1799 stack = new class_1799(Envelope.Items.PAYBACK_TAG.get());
        stack.method_57379(Envelope.DataComponents.PAYBACK_TAG_CONTENTS, PaybackRequest.createDefault(PaybackDuration.MEDIUM));
        return stack;
    });
    private static final class_1799 PAYBACK_TAG_LONG = class_156.method_656(() -> {
        class_1799 stack = new class_1799(Envelope.Items.PAYBACK_TAG.get());
        stack.method_57379(Envelope.DataComponents.PAYBACK_TAG_CONTENTS, PaybackRequest.createDefault(PaybackDuration.LONG));
        return stack;
    });

    @Override
    public int method_32664(class_327 font) {
        return 18 + (18 * paybackRequest().items().size()) + 5;
    }

    @Override
    public int method_32661() {
        return 26;
    }

    @Override
    public void method_32666(class_327 font, int x, int y, class_332 guiGraphics) {
        class_1799 tagPreview = switch (paybackRequest().duration()) {
            case SHORT -> PAYBACK_TAG_SHORT;
            case MEDIUM -> PAYBACK_TAG_MEDIUM;
            case LONG -> PAYBACK_TAG_LONG;
        };
        guiGraphics.method_55231(tagPreview, x - 1, y + 4, 0);

        int slots = paybackRequest().items().size();

        for (int i = 0; i < slots; i++) {
            StackIngredient ingredient = paybackRequest().items().get(i);
            class_1799 stack = ingredient.getRollingDisplayedStack();

            int slotX = x + 17 + 3 + (i * 18);
            int slotY = y + 3;

            if (i == 0) {
                // Left border
                guiGraphics.method_52708(SLOT_SPRITE, 24, 24, 0, 0, slotX - 3, y, 3, 24);
            }

            if (i == slots - 1) {
                // Right border
                guiGraphics.method_52708(SLOT_SPRITE, 24, 24, 21, 0, slotX + 18, y, 3, 24);
            }

            guiGraphics.method_52708(SLOT_SPRITE, 24, 24, 3, 0, slotX, y, 18, 24);
            guiGraphics.method_55231(stack, slotX + 1, slotY + 1, 0);
            guiGraphics.method_51431(font, stack, slotX + 1, slotY + 1);

            if (ingredient.items().method_45925().isPresent()) {
                guiGraphics.method_51448().method_46416(0, 0, 200);
                guiGraphics.method_51433(font, "#", slotX + 1 + 19 - 2 - font.method_1727("#"), y + 1, Colors.WHITE, true);
            }
        }
    }
}
