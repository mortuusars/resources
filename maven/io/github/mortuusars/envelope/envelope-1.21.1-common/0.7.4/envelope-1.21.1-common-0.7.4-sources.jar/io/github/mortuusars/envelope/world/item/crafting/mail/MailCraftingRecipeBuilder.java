package io.github.mortuusars.envelope.world.item.crafting.mail;

import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_8790;

public class MailCraftingRecipeBuilder extends MailRecipeBuilder {
    private final class_2371<class_1856> ingredients = class_2371.method_10211();
    private class_1799 result = class_1799.field_8037;
    private float experience;

    public MailCraftingRecipeBuilder(ServiceAddress address) {
        super(address);
    }

    @Override
    public class_1799 getResult() {
        return result;
    }

    public MailCraftingRecipeBuilder forResult(class_1799 result) {
        this.result = result;
        return this;
    }

    public MailCraftingRecipeBuilder forResult(class_1935 item, int count) {
        this.result = new class_1799(item, count);
        return this;
    }

    public MailCraftingRecipeBuilder forResult(class_1935 item) {
        this.result = new class_1799(item, 1);
        return this;
    }

    public MailCraftingRecipeBuilder requires(class_1856 ingredient) {
        ingredients.add(ingredient);
        return this;
    }

    public MailCraftingRecipeBuilder requires(class_1856 ingredient, int quantity) {
        for (int i = 0; i < quantity; i++) {
            ingredients.add(ingredient);
        }
        return this;
    }

    public MailCraftingRecipeBuilder experience(float experience) {
        this.experience = experience;
        return this;
    }

    public void save(class_8790 output, class_2960 id) {
        MailCraftingRecipe recipe = new MailCraftingRecipe(getAddress(), ingredients, result, experience);
        output.method_53819(id, recipe, null);
    }
}
