package io.github.mortuusars.envelope.world.entity.spawning;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.List;
import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_9279;

public record SpawnableEntityData(class_9279 data) {
    public static final Codec<SpawnableEntityData> CODEC =
                class_9279.field_49303.validate(data -> {
                    if (data.method_57458()) return DataResult.error(() -> "Entity data cannot be empty.");
                    return DataResult.success(data);
                })
          .xmap(SpawnableEntityData::new, SpawnableEntityData::data);

    private static final Logger LOGGER = LogUtils.getLogger();

    @SuppressWarnings("deprecation")
    public SpawnableEntityData {
        Preconditions.checkArgument(!data.method_57458(), "Entity data cannot be empty.");
        Preconditions.checkState(!data.method_57463().method_33133(), "Entity tag cannot be empty.");
        Preconditions.checkState(data.method_57463().method_10573("id", class_2520.field_33258),
              "Entity tag does not contain an 'id': " + data.getClass());
    }

    public static SpawnableEntityData of(class_1297 entity, List<String> ignoredTags) {
        Preconditions.checkArgument(!entity.method_5765() && !entity.method_31481() && entity.method_5864().method_5893(),
              "Cannot create SpawnableEntityData: entity '" + entity + "' is passenger, removed or the type is not serializable.");

        class_2487 tag = new class_2487();

        if (!entity.method_5662(tag)) {
            LOGGER.error("Failed to save entity '{}' to a tag. Entity is passenger, " +
                  "about to be removed or entity type is not serializable.", entity);
        }

        ignoredTags.forEach(tag::method_10551);
        return new SpawnableEntityData(class_9279.method_57456(tag));
    }

    // --

    @SuppressWarnings("deprecation")
    public @Nullable class_1297 createEntity(class_3218 level) {
        @Nullable class_1297 entity = class_1299.method_17842(data.method_57463(), level, Function.identity());
        if (entity == null) {
            LOGGER.error("Failed to create spawnable entity. Tag: {}", data.method_57463());
        }
        return entity;
    }
}