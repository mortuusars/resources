package io.github.mortuusars.envelope.client.gui.screen;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.gui.Sprites;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.serverbound.PackingMenuPresetAddressC2SP;
import io.github.mortuusars.envelope.world.inventory.PackingMenu;
import io.github.mortuusars.envelope.world.mail.address.Address;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_344;
import net.minecraft.class_4185;
import net.minecraft.class_5244;
import net.minecraft.class_7919;
import net.minecraft.class_8666;

public class PackingScreen extends AbstractInHandContainerScreen<PackingMenu> {
    public static final class_2960 TEXTURE = Envelope.resource("textures/gui/packing.png");
    public static final class_8666 PACK_BUTTON_SPRITES = Sprites.threeStates(Envelope.resource("packing/pack_button"));
    public static final class_8666 PRESET_ADDRESS_BUTTON_SPRITES = Sprites.threeStates(Envelope.resource("packing/preset_address_button"));

    protected class_344 packButton;
    protected class_344 presetAddressButton;

    public PackingScreen(PackingMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title, TEXTURE);
    }

    @Override
    protected void method_25426() {
        field_2792 = 176;
        field_2779 = 178;
        super.method_25426();

        packButton = method_37063(new class_344(field_2776 + 126, field_2800 + 39, 26, 21,
              PACK_BUTTON_SPRITES,
              this::pack,
              class_2561.method_43471("gui.envelope.packing.pack")));
        packButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.envelope.packing.pack")));

        presetAddressButton = method_37063(new class_344(field_2776 + 152, field_2800 + 39, 20, 21,
              PRESET_ADDRESS_BUTTON_SPRITES,
              this::removePresetAddress,
              class_2561.method_43471("gui.envelope.packing.preset_address")));
    }

    protected void pack(class_4185 button) {
        method_17577().method_7604(method_17577().getPlayer(), PackingMenu.PACK_BUTTON_ID);
        Minecrft.gameMode().method_2900(method_17577().field_7763, PackingMenu.PACK_BUTTON_ID);
        method_25419();
    }

    protected void removePresetAddress(class_4185 button) {
        method_17577().presetAddress(null);
        Packets.sendToServer(new PackingMenuPresetAddressC2SP(Optional.empty()));
    }

    @Override
    protected void updateButtons() {
        packButton.field_22764 = method_17577().canPack();
        packButton.field_22763 = !method_17577().isPacked();
        presetAddressButton.field_22764 = packButton.field_22764 && method_17577().getPresetAddress() != null;
        presetAddressButton.field_22763 = packButton.field_22763 && !method_17577().getAddressTag().method_7960();
        if (method_17577().getPresetAddress() instanceof Address presetAddress) {
            if (presetAddressButton.field_22763) {
                presetAddressButton.method_47400(class_7919.method_47407(
                      class_2561.method_43473()
                            .method_10852(presetAddress.format().asNeutral().toComponent())
                            .method_10852(class_5244.field_33849)
                            .method_10852(class_2561.method_43471("gui.envelope.packing.preset_address.will_apply")
                                  .method_27692(class_124.field_1080))
                ));
            } else {
                presetAddressButton.method_47400(class_7919.method_47407(
                      class_2561.method_43473()
                            .method_10852(presetAddress.format().asNeutral().toComponent())
                            .method_10852(class_5244.field_33849)
                            .method_10852(class_2561.method_43471("gui.envelope.packing.preset_address.no_address_tag")
                                  .method_27692(class_124.field_1080))));
            }
        }
    }
}
