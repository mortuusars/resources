package io.github.mortuusars.envelope.world.mail.delivery;

import io.github.mortuusars.envelope.world.item.component.Id;
import io.github.mortuusars.envelope.world.mail.address.Address;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class DeliveryDraft {
    private @Nullable Id id = null;
    private @Nullable UUID owner = null;
    private Address sender = Address.UNKNOWN;
    private Address recipient = Address.UNKNOWN;
    private class_1799 mail = class_1799.field_8037;
    private DeliveryPhase phase = DeliveryPhase.STARTED;

    // --

    public DeliveryDraft deliver(class_1799 mail) {
        this.mail = mail;
        return this;
    }

    public DeliveryDraft from(Address sender) {
        this.sender = sender;
        return this;
    }

    public DeliveryDraft to(Address recipient) {
        this.recipient = recipient;
        return this;
    }

    public DeliveryDraft owner(@Nullable UUID owner) {
        this.owner = owner;
        return this;
    }

    public DeliveryDraft id(@Nullable Id id) {
        this.id = id;
        return this;
    }

    public DeliveryDraft owner(class_1657 player) {
        this.owner = player.method_5667();
        return this;
    }

    public DeliveryDraft startAtPhase(DeliveryPhase phase) {
        this.phase = phase;
        return this;
    }

    // --


    public @NotNull Id getOrCreateId(class_1937 level) {
        return id != null ? id : Id.create(level);
    }

    public Optional<UUID> getOwner() {
        return Optional.ofNullable(owner);
    }

    public Address getRecipient() {
        return recipient;
    }

    public Address getSender() {
        return sender;
    }

    public class_1799 getMail() {
        return mail;
    }

    public DeliveryPhase getPhase() {
        return phase;
    }

    // --

    @Override
    public String toString() {
        return "DeliveryDraft{" +
              "owner=" + owner +
              ", sender=" + sender +
              ", recipient=" + recipient +
              ", mail=" + mail +
              ", phase=" + phase +
              '}';
    }
}
