package io.github.mortuusars.envelope.util.bugger_data;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.EnvelopeSymbols;
import io.github.mortuusars.envelope.util.bugger.data.NbtData;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.delivery.Courier;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import io.github.mortuusars.envelope.world.mail.delivery.background.BackgroundCourier;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.mail.MailService;
import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_5575;

public class MailServiceBuggerData extends NbtData {
    public MailServiceBuggerData() {
        super(Envelope.resource("mail_service"));
    }

    public void collectAndSendData(MailService mailService) {
        sendValues(tag -> writeDebugInfo(mailService, tag));
    }

    // --

    private void writeDebugInfo(MailService mailService, class_2487 tag) {
        List<? extends Pigeon> pigeons = mailService.getLevel().method_18198(class_5575.method_31795(Pigeon.class), Pigeon::isDelivering);
        List<BackgroundCourier> backgroundCouriers = mailService.getBackgroundDelivery().getActiveCouriers();

        tag.method_10569("mailboxes", mailService.getMailboxes().getAllAddresses().size());
        tag.method_10569("dropped_mail_count", mailService.getBackgroundDelivery().getDroppedMail().size());
        tag.method_10569("payback_pending_mail_count", mailService.getPaybackDepartment().getPendingPaybackSubjectCount());

        tag.method_10569("delivering_pigeons", pigeons.size());
        tag.method_10569("background_delivering_pigeons", backgroundCouriers.size());
        tag.method_10569("background_finished_pigeons", mailService.getBackgroundDelivery().getFinishedCouriers().size());

        class_2499 deliveries = Stream.concat(pigeons.stream(), backgroundCouriers.stream())
              .sorted(Comparator.comparingLong(courier -> courier.getCurrentDelivery().orElseThrow().getId().getTick()))
              .map(courier -> formDeliveryString(mailService, courier))
              .map(class_2519::method_23256)
              .collect(Collectors.toCollection(class_2499::new));

        tag.method_10566("deliveries", deliveries);
    }

    private @NotNull String formDeliveryString(MailService mailService, Courier courier) {
        Delivery delivery = courier.getCurrentDelivery().orElseThrow();
        int phaseDuration = courier.getPhaseDuration(mailService.getLevel(), delivery, delivery.getPhase());

        return class_124.field_1075 + delivery.getSender().format().withIcon().toString() + class_124.field_1070 +
              " " + EnvelopeSymbols.SMALL_FILLED_ARROW_RIGHT + " " +
              class_124.field_1060 + delivery.getRecipient().format().withIcon().toString() + class_124.field_1070 +

              class_124.field_1080 +
              " | " + (courier.getOrigin().isService() ? "Service" : "Regular") +
              " | " + (Mail.isReturned(delivery.getMail()) ? "← " : "") + "✉ " + (!delivery.getMail().method_7960() ? delivery.getMail().method_7964().getString() : "Empty") +
              " | ↔ " + delivery.getRoute().getDistance(mailService.getLevel()) +
              " | ⌚" + delivery.getRoute().getFullTravelDuration().seconds() + "s" +
              class_124.field_1070 +

              " // " + delivery.getPhase().toPrettyString() +

              class_124.field_1080 +
              " ⌛" + (phaseDuration - delivery.getPhaseProgress()) / 20 +
              class_124.field_1070;
    }
}
