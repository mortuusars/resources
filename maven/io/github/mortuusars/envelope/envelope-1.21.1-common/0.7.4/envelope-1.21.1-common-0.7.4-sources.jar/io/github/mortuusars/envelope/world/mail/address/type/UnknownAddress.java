package io.github.mortuusars.envelope.world.mail.address.type;

import io.github.mortuusars.envelope.world.mail.address.Address;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import org.jetbrains.annotations.NotNull;

public enum UnknownAddress implements Address {
    INSTANCE;

    @Override
    public Type getType() {
        return Type.UNKNOWN;
    }

    @Override
    public String getString() {
        return getComponent().getString();
    }

    @Override
    public class_5250 getComponent() {
        return class_2561.method_43471("address.envelope.unknown");
    }

    // --

    @Override
    public @NotNull String toString() {
        return "[Unknown]";
    }
}