package io.github.mortuusars.envelope.world.inventory;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1799;

public class ContainerUtils {
    public static class_1263 compact(class_1263 container, int maxSlots) {
        class_1277 compactedContainer = new class_1277(maxSlots);
        for (int slot = 0; slot < container.method_5439(); slot++) {
            compactedContainer.method_5491(container.method_5438(slot));
        }
        return compactedContainer;
    }

    public static class_1263 compact(class_1263 container) {
        return compact(container, container.method_5439());
    }

    public static class_1263 compact(List<class_1799> items, int maxSlots) {
        class_1277 compactedContainer = new class_1277(maxSlots);
        for (class_1799 item : items) {
            compactedContainer.method_5491(item);
        }
        return compactedContainer;
    }

    public static class_1263 compact(List<class_1799> items) {
        class_1277 compactedContainer = new class_1277(items.size());
        for (class_1799 item : items) {
            compactedContainer.method_5491(item);
        }
        return compactedContainer;
    }

    public static List<class_1263> split(class_1263 container, int slots) {
        List<class_1263> containers = new ArrayList<>();

        class_1277 currentContainer = new class_1277(slots);

        for (int i = 0; i < container.method_5439(); i += slots) {
            for (int slot = 0; slot < slots; slot++) {
                currentContainer.method_5447(slot, container.method_5438(i + slot));
            }

            if (!currentContainer.method_5442()) {
                containers.add(currentContainer);
                currentContainer = new class_1277(slots);
            }
        }

        return containers;
    }

    public static List<class_1799> toList(class_1263 container, int maxSlots) {
        List<class_1799> items = new ArrayList<>();
        for (int i = 0; i < Math.min(container.method_5439(), maxSlots); i++) {
            items.add(container.method_5438(i));
        }
        return items;
    }
}
