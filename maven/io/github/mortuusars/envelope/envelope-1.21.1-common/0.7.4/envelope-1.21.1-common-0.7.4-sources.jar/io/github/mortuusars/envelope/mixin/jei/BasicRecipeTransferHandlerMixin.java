package io.github.mortuusars.envelope.mixin.jei;

import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.serverbound.PackingMenuPresetAddressC2SP;
import io.github.mortuusars.envelope.world.inventory.PackingMenu;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailRecipe;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.recipe.transfer.IRecipeTransferError;
import mezz.jei.api.recipe.transfer.IRecipeTransferHandler;
import mezz.jei.library.transfer.BasicRecipeTransferHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1860;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@Mixin(BasicRecipeTransferHandler.class)
public abstract class BasicRecipeTransferHandlerMixin<C extends class_1703, R> implements IRecipeTransferHandler<C, R> {
    @Inject(method = "transferRecipe", at = @At(value = "INVOKE", target = "Lmezz/jei/common/network/IConnectionToServer;sendPacketToServer(Lmezz/jei/common/network/packets/PlayToServerPacket;)V"))
    private void onTransferRecipe(C container, R recipe, IRecipeSlotsView recipeSlotsView, class_1657 player,
                                  boolean maxTransfer, boolean doTransfer, CallbackInfoReturnable<IRecipeTransferError> cir) {
        @Nullable class_1860<?> actualRecipe = null;

        if (recipe instanceof class_1860<?> direct) {
            actualRecipe = direct;
        } else if (recipe instanceof class_8786<?> holder) {
            actualRecipe = holder.comp_1933();
        }

        if (container instanceof PackingMenu packingMenu && actualRecipe instanceof MailRecipe mailRecipe) {
            packingMenu.presetAddress(mailRecipe.getAddress());
            Packets.sendToServer(new PackingMenuPresetAddressC2SP(Optional.ofNullable(mailRecipe.getAddress())));
        }
    }
}
