package io.github.mortuusars.envelope.util.result;

import com.mojang.serialization.DataResult;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class Error {
    protected final String message;
    protected final @Nullable String translationKey;

    public Error(String message, @Nullable String translationKey) {
        this.message = message;
        this.translationKey = translationKey;
    }

    public Error(String message) {
        this(message, null);
    }

    public String getMessage() {
        return message;
    }

    public class_5250 getTranslation() {
        return translationKey != null ? class_2561.method_43471(translationKey) : class_2561.method_43470(message);
    }

    public void log(Logger logger) {
        logger.error(getMessage());
    }

    public <T> DataResult<T> asDataResult() {
        return DataResult.error(this::getMessage);
    }

    @Override
    public String toString() {
        return getMessage();
    }
}
