package io.github.mortuusars.envelope.mixin.equine_assurance_bureau;

import io.github.mortuusars.envelope.world.mail.service.EquineAssuranceBureau;
import net.minecraft.class_1429;
import net.minecraft.class_2131;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2131.class)
public abstract class TameAnimalTriggerMixin {
    @Inject(method = "trigger", at = @At("RETURN"))
    private void onTrigger(class_3222 player, class_1429 entity, CallbackInfo ci) {
        EquineAssuranceBureau.onTameAnimal(player, entity);
    }
}
