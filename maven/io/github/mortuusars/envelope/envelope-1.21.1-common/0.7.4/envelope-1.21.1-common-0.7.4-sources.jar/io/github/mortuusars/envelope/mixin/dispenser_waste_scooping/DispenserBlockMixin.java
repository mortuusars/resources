package io.github.mortuusars.envelope.mixin.dispenser_waste_scooping;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.block.dispenser.WasteScoopingDispenseItemBehavior;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2357;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2315.class)
public class DispenserBlockMixin {
    @Inject(method = "getDispenseMethod", at = @At("HEAD"), cancellable = true)
    private void onGetDispenseMethod(class_1937 level, class_1799 item, CallbackInfoReturnable<class_2357> cir) {
        if (Config.Server.PIGEONHOLE_DISPENSER_WASTE_SCOOPING.get() && item.method_31573(Envelope.Tags.Items.WASTE_SCOOPABLE)) {
            cir.setReturnValue(WasteScoopingDispenseItemBehavior.INSTANCE);
        }
    }
}
