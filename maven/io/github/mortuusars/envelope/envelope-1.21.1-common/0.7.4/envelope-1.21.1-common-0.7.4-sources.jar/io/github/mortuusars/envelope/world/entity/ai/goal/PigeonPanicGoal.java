package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.world.entity.Pigeon;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1314;
import net.minecraft.class_1374;
import net.minecraft.class_243;
import net.minecraft.class_6862;
import net.minecraft.class_8110;

public class PigeonPanicGoal extends class_1374 {
    public PigeonPanicGoal(Pigeon pigeon, double speedModifier) {
        super(pigeon, speedModifier);
    }

    public PigeonPanicGoal(Pigeon pigeon, double speedModifier, class_6862<class_8110> panicCausingDamageTypes) {
        super(pigeon, speedModifier, panicCausingDamageTypes);
    }

    public PigeonPanicGoal(Pigeon pigeon, double speedModifier, Function<class_1314, class_6862<class_8110>> panicCausingDamageTypes) {
        super(pigeon, speedModifier, panicCausingDamageTypes);
    }

    @Override
    protected boolean method_6301() {
        if (!(field_6549.method_6081() instanceof class_1282 damageSource)) return false;
        if (!(damageSource.method_5526() instanceof class_1297 entity)) return false;

        @Nullable class_243 pos = PigeonAvoidEntityGoal.getPosAway(field_6549, 14, 8, entity.method_19538());

        if (pos != null) {
            this.field_6547 = pos.field_1352;
            this.field_6546 = pos.field_1351;
            this.field_6550 = pos.field_1350;
            return true;
        }

        return false;
    }
}
