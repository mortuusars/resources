package io.github.mortuusars.envelope.world.mail.delivery;

import io.github.mortuusars.envelope.world.mail.delivery.background.BackgroundCourier;
import net.minecraft.class_1297;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import io.github.mortuusars.envelope.world.entity.spawning.SpawnableEntityData;
import io.github.mortuusars.envelope.world.mail.MailService;

public interface PhysicalCourier extends Courier {
    SpawnableEntityData toSpawnableData();

    void setDelivery(Delivery delivery);

    default BackgroundCourier transitionToBackground(class_3218 level) {
        Delivery delivery = getCurrentDelivery().orElseThrow(() -> new IllegalStateException("Cannot transition: courier is not delivering."));
        BackgroundCourier backgroundCourier = new BackgroundCourier(toSpawnableData(), getOrigin(), delivery);
        MailService.of(level).getBackgroundDelivery().addCourier(backgroundCourier);
        onVanished(level);
        ((class_1297) this).method_31472();
        return backgroundCourier;
    }

    default void onAppeared(class_3218 level) {
        class_243 pos = ((class_1297) this).method_19538();
        level.method_14199(class_2398.field_11204, pos.field_1352, pos.field_1351, pos.field_1350, 16, 0.1, 0.1, 0.1, 0.05);
        level.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_15065, class_3419.field_15254, 1, 1);
    }

    default void onVanished(class_3218 level) {
        class_243 pos = ((class_1297) this).method_19538();
        level.method_14199(class_2398.field_11204, pos.field_1352, pos.field_1351, pos.field_1350, 16, 0.1, 0.1, 0.1, 0.05);
        level.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_15065, class_3419.field_15254, 1, 1);
    }
}