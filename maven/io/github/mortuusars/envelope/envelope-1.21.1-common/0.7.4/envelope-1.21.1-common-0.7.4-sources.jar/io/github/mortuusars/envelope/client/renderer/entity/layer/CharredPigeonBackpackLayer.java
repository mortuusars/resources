package io.github.mortuusars.envelope.client.renderer.entity.layer;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.model.CharredPigeonModel;
import io.github.mortuusars.envelope.world.entity.CharredPigeon;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5599;
import net.minecraft.class_5601;

public class CharredPigeonBackpackLayer extends class_3887<CharredPigeon, CharredPigeonModel> {
    public static final class_5601 MODEL_LAYER = new class_5601(Envelope.resource("charred_pigeon_backpack"), "main");

    public static final class_2960 TEXTURE = Envelope.resource("textures/entity/charred_pigeon/charred_pigeon_backpack.png");

    protected final CharredPigeonModel model;

    public CharredPigeonBackpackLayer(class_3883<CharredPigeon, CharredPigeonModel> renderer, class_5599 modelSet) {
        super(renderer);
        model = new CharredPigeonModel(modelSet.method_32072(MODEL_LAYER));
    }

    @Override
    public void render(class_4587 poseStack, class_4597 buffer, int packedLight, CharredPigeon pigeon, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!pigeon.method_6109() && pigeon.hasMail()) {
            method_23196(method_17165(), model, TEXTURE, poseStack, buffer, packedLight, pigeon,
                  limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, partialTick, -1);
        }
    }
}
