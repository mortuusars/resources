package io.github.mortuusars.envelope.mixin.tooltip;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.envelope.EnvelopeClient;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_5632;
import net.minecraft.class_9322;

@Mixin(class_1799.class)
public abstract class ItemStackMixin implements class_9322 {
    @ModifyReturnValue(method = "getTooltipImage", at = @At("RETURN"))
    private Optional<class_5632> getTooltipImage(Optional<class_5632> original) {
        return EnvelopeClient.TooltipComponents.modifyTooltipImage(((class_1799) (Object) this), original);
    }

    @SuppressWarnings("LocalMayUseName") // Using variable names can cause crashes on fabric.
    @Inject(method = "getTooltipLines",
          at = @At(value = "INVOKE",
          ordinal = 0,
          target = "Lnet/minecraft/world/item/ItemStack;addToTooltip(Lnet/minecraft/core/component/DataComponentType;Lnet/minecraft/world/item/Item$TooltipContext;Ljava/util/function/Consumer;Lnet/minecraft/world/item/TooltipFlag;)V"))
    private void appendHoverText(class_1792.class_9635 tooltipContext, @Nullable class_1657 player, class_1836 tooltipFlag,
                                 CallbackInfoReturnable<List<class_2561>> cir, @Local Consumer<class_2561> consumer) {
        EnvelopeClient.TooltipComponents.appendTooltipLines(((class_1799) (Object) this), consumer, tooltipContext, player, tooltipFlag);
    }
}