package io.github.mortuusars.envelope.integration.jei.util;

import io.github.mortuusars.envelope.client.gui.screen.PaybackTagScreen;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.serverbound.PaybackTagMenuSetSlotC2SP;
import io.github.mortuusars.envelope.world.item.component.PaybackRequest;
import mezz.jei.api.gui.handlers.IGhostIngredientHandler;
import mezz.jei.api.ingredients.ITypedIngredient;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_768;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PaybackTagGhostIngredientHandler implements IGhostIngredientHandler<PaybackTagScreen> {
    @Override
    public <I> @NotNull List<Target<I>> getTargetsTyped(PaybackTagScreen screen, ITypedIngredient<I> ingredient, boolean doStart) {
        Optional<class_1799> itemStack = ingredient.getItemStack();
        if (itemStack.isEmpty()) {
            return List.of();
        }

        class_1799 stack = itemStack.get();
        if (!PaybackRequest.isValid(stack)) {
            return List.of();
        }

        List<Target<I>> targets = new ArrayList<>();

        for (int index = 0; index < PaybackRequest.SLOTS; index++) {
            class_1735 slot = screen.method_17577().field_7761.get(index);
            targets.add(new Target<>() {
                @Override
                public @NotNull class_768 getArea() {
                    return new class_768(screen.getLeftPos() + slot.field_7873 - 1, screen.getTopPos() + slot.field_7872 - 1, 18, 18);
                }

                @Override
                public void accept(I ingredient) {
                    if (ingredient instanceof class_1799 stackIngredient) {
                        slot.method_53512(stackIngredient);
                        Packets.sendToServer(new PaybackTagMenuSetSlotC2SP(slot.field_7874, stackIngredient));
                    }
                }
            });
        }

        return targets;
    }

    @Override
    public void onComplete() {
    }
}
