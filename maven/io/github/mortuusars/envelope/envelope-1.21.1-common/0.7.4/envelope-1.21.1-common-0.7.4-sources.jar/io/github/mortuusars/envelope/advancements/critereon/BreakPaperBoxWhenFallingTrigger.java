package io.github.mortuusars.envelope.advancements.critereon;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_2048;
import net.minecraft.class_2096;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public class BreakPaperBoxWhenFallingTrigger extends class_4558<BreakPaperBoxWhenFallingTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player, double fallDistance) {
        this.method_22510(player, triggerInstance -> triggerInstance.matches(fallDistance));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  Optional<class_2096.class_2099> distance) implements SimpleInstance {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                    class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::player),
                    class_2096.class_2099.field_45762.optionalFieldOf("distance").forGetter(TriggerInstance::distance))
              .apply(instance, TriggerInstance::new));

        public boolean matches(double fallDistance) {
            return (this.distance.isEmpty() || this.distance.get().method_9047(fallDistance));
        }
    }
}
