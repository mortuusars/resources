package io.github.mortuusars.envelope.world.inventory.slot;

import org.jetbrains.annotations.NotNull;

import java.util.function.Predicate;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3532;

public class GhostSlot extends class_1735 {
    private final Predicate<class_1799> filter;

    public GhostSlot(class_1263 container, int slot, int x, int y, Predicate<class_1799> filter) {
        super(container, slot, x, y);
        this.filter = filter;
    }

    /**
     * Due to other mods using {@link #method_7680} to check if they can insert items into the slot - we check if the item is valid separately.
     */
    public boolean canContain(class_1799 stack) {
        return filter.test(stack);
    }

    @Override
    public boolean method_55059() {
        return true;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return false;
    }

    @Override
    public boolean method_7674(class_1657 player) {
        return false;
    }

    @Override
    public void method_7670(class_1799 oldStack, class_1799 newStack) {
    }

    @Override
    public @NotNull class_1799 method_7671(int amount) {
        super.method_7671(amount);
        return class_1799.field_8037; // Returning original will dupe items in some cases
    }

    public void setCount(int count) {
        count = class_3532.method_15340(count, 1, method_7676(method_7677()));
        if (method_7677().method_7947() != count) {
            method_53512(method_7677().method_46651(count));
        }
    }
}
