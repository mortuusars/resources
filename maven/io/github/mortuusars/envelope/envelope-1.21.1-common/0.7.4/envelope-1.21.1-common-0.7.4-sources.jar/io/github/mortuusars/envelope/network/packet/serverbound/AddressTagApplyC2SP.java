package io.github.mortuusars.envelope.network.packet.serverbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.network.packet.Packet;
import io.github.mortuusars.envelope.world.item.AddressTagItem;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record AddressTagApplyC2SP(int slot, Optional<Address> address) implements Packet {
    public static final class_2960 ID = Envelope.resource("address_tag_apply");
    public static final class_9154<AddressTagApplyC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, AddressTagApplyC2SP> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48550, AddressTagApplyC2SP::slot,
            class_9135.method_56382(Address.STREAM_CODEC), AddressTagApplyC2SP::address,
            AddressTagApplyC2SP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (slot < 0 || slot > player.method_31548().field_7547.size()) {
            Envelope.LOGGER.error("Cannot handle {} packet: slot {} is not in valid range (0 - {}).",
                    ID, slot, player.method_31548().field_7547.size());
            return false;
        }

        class_1799 tag = player.method_31548().method_5438(slot);

        if (tag.method_7909() instanceof AddressTagItem) {
            address.ifPresentOrElse(
                    value -> tag.method_57379(Envelope.DataComponents.ADDRESS, value),
                    () -> tag.method_57381(Envelope.DataComponents.ADDRESS));
            return true;
        }

        return false;
    }
}
