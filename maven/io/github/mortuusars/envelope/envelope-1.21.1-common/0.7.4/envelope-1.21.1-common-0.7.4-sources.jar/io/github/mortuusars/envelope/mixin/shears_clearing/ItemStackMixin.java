package io.github.mortuusars.envelope.mixin.shears_clearing;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1820;
import net.minecraft.class_5536;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1799.class)
public abstract class ItemStackMixin {
    @Shadow
    public abstract boolean is(class_1792 item);

    @Shadow
    public abstract class_1792 getItem();

    @WrapOperation(method = "overrideStackedOnOther",
          at = @At(value = "INVOKE",
                target = "Lnet/minecraft/world/item/Item;overrideStackedOnOther(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/inventory/Slot;Lnet/minecraft/world/inventory/ClickAction;Lnet/minecraft/world/entity/player/Player;)Z"))
    private boolean overrideStackedOnOther(class_1792 instance, class_1799 stack, class_1735 slot, class_5536 action, class_1657 player, Operation<Boolean> original) {
        if (original.call(instance, stack, slot, action, player)) {
            return true;
        }

        if (getItem() instanceof class_1820) {
            return Mail.handleShearsUse(stack, slot, action, player);
        }

        return false;
    }
}
