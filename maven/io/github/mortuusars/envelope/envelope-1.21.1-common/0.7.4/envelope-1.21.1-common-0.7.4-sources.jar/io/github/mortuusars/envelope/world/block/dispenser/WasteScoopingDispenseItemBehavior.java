package io.github.mortuusars.envelope.world.block.dispenser;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.block.PigeonholeBlock;
import net.minecraft.class_1799;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2680;
import net.minecraft.class_2969;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import org.jetbrains.annotations.NotNull;

public class WasteScoopingDispenseItemBehavior extends class_2969 {
    public static final WasteScoopingDispenseItemBehavior INSTANCE = new WasteScoopingDispenseItemBehavior();

    @Override
    protected @NotNull class_1799 method_10135(class_2342 blockSource, class_1799 item) {
        class_3218 level = blockSource.comp_1967();
        class_2338 blockPos = blockSource.comp_1968().method_10093(blockSource.comp_1969().method_11654(class_2315.field_10918));
        method_27955(tryScoopWaste(level, blockPos, item));
        return item;
    }

    protected boolean tryScoopWaste(class_3218 level, class_2338 pos, class_1799 item) {
        class_2680 state = level.method_8320(pos);
        if (state.method_26204() instanceof PigeonholeBlock block && block.canScoopWaste(state)) {
            block.dropWasteItems(level, pos, state, item, null);
            block.clearWaste(level, pos, state);
            item.method_7956(1, level, null, i -> {});
            level.method_8396(null, pos, Envelope.SoundEvents.PIGEONHOLE_SCOOP.get(), class_3419.field_15245,
                  1.0F, level.field_9229.method_43057() * 0.1f + 0.95f);
            return true;
        }
        return false;
    }
}
