package io.github.mortuusars.envelope.world.mail.address;

import com.mojang.datafixers.util.Either;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.util.EnvelopeSymbols;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import org.jetbrains.annotations.NotNull;

import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3544;
import net.minecraft.class_5250;

public class AddressFormatter {
    protected final Address address;
    protected boolean icon = false;
    protected String iconSeparator = " ";
    protected Either<class_124, class_2583> iconStyle = Either.right(class_2583.field_24360);
    protected Either<class_124, class_2583> textStyle = Either.right(class_2583.field_24360);
    protected int maxLength = Integer.MAX_VALUE;

    protected AddressFormatter(Address address) {
        this.address = address;
    }

    public static AddressFormatter of(Address address) {
        return new AddressFormatter(address);
    }

    // --

    public AddressFormatter asNeutral() {
        return this
              .withIcon()
              .withIconColor(Colors.ADDRESS_NEUTRAL)
              .withColor(Colors.ADDRESS_NEUTRAL);
    }

    public AddressFormatter asSender() {
        return this
              .withIcon()
              .withIconColor(Colors.ADDRESS_SENDER)
              .withColor(Colors.ADDRESS_SENDER);
    }

    public AddressFormatter asRecipient() {
        return this
              .withIcon()
              .withIconColor(Colors.ADDRESS_RECIPIENT)
              .withColor(Colors.ADDRESS_RECIPIENT);
    }

    // --

    public AddressFormatter withIcon() {
        this.icon = true;
        return this;
    }

    public AddressFormatter withIconSeparator(String separator) {
        this.iconSeparator = separator;
        return this;
    }

    public AddressFormatter withIconColor(class_124 formatting) {
        this.iconStyle = Either.left(formatting);
        return this;
    }

    public AddressFormatter withIconStyle(class_2583 style) {
        this.iconStyle = Either.right(style);
        return this;
    }

    public AddressFormatter withIconColor(int color) {
        this.iconStyle = Either.right(class_2583.field_24360.method_36139(color));
        return this;
    }

    public AddressFormatter withColor(class_124 formatting) {
        this.textStyle = Either.left(formatting);
        return this;
    }

    public AddressFormatter withStyle(class_2583 style) {
        this.textStyle = Either.right(style);
        return this;
    }

    public AddressFormatter withColor(int color) {
        this.textStyle = Either.right(class_2583.field_24360.method_36139(color));
        return this;
    }

    public AddressFormatter withMaxLength(int maxLength) {
        this.maxLength = maxLength;
        return this;
    }

    // --

    public class_5250 toComponent() {
        class_5250 addressComponent;
        if (maxLength < Integer.MAX_VALUE) {
            String string = class_3544.method_34963(address.getString(), maxLength, true);
            addressComponent = class_2561.method_43470(string);
        } else {
            addressComponent = address.getComponent();
        }
        addressComponent = addressComponent.method_27696(createStyle(textStyle));

        if (icon) {
            return class_2561.method_43473()
                  .method_10852(class_2561.method_43470(getIcon(address)).method_27696(createStyle(iconStyle)))
                  .method_27693(iconSeparator)
                  .method_10852(addressComponent);
        }

        return addressComponent;
    }

    @Override
    public String toString() {
        String addressString = class_3544.method_34963(address.getString(), maxLength, true);

        String addressText = textStyle.left()
              .map(formatting -> formatting + addressString + class_124.field_1070)
              .orElse(addressString);

        if (icon) {
            String icon = iconStyle.left()
                  .map(formatting -> formatting + getIcon(address) + class_124.field_1070)
                  .orElse(getIcon(address));
            return icon + iconSeparator + addressText;
        }

        return addressText;
    }

    protected class_2583 createStyle(Either<class_124, class_2583> style) {
        return style.map(class_2583.field_24360::method_27706, Function.identity());
    }

    // --

    public static @NotNull String getIcon(Address address) {
        return switch (address.getType()) {
            case BLOCK -> EnvelopeSymbols.ADDRESS_BLOCK;
            case PLAYER -> EnvelopeSymbols.ADDRESS_PLAYER;
            case SERVICE -> ((ServiceAddress) address).getDefinition().icon();
            case CUSTOM -> EnvelopeSymbols.ADDRESS_CUSTOM;
            case UNKNOWN -> EnvelopeSymbols.ADDRESS_UNKNOWN;
        };
    }

//    public static @NotNull Component fullSender(@Nullable Address sender) {
//        if (sender == null) return CommonComponents.EMPTY;
//        return Component.translatable("gui.envelope.mail.sender").withStyle(ChatFormatting.GRAY)
//              .append(": ").withStyle(ChatFormatting.GRAY)
//              .append(sender.format().asSender().toComponent());
//    }
//
//    public static @NotNull Component fullRecipient(@Nullable Address recipient) {
//        if (recipient == null) return CommonComponents.EMPTY;
//        return Component.translatable("gui.envelope.mail.recipient").withStyle(ChatFormatting.GRAY)
//              .append(": ").withStyle(ChatFormatting.GRAY)
//              .append(recipient.format().asRecipient().toComponent());
//    }

//    public static @NotNull Component senderToRecipient(@Nullable Address sender, @Nullable Address recipient) {
//        if (sender == null && recipient == null) return CommonComponents.EMPTY;
//
//        if (sender != null) {
//            if (recipient == null) {
//                recipient = Address.UNKNOWN;
//            }
//
//            return sender.format().asSender().withMaxLength(25).toComponent()
//                  .append(Component.literal(" " + EnvelopeSymbols.SMALL_FILLED_ARROW_RIGHT + " ").withStyle(ChatFormatting.GRAY))
//                  .append(recipient.format().asRecipient().withMaxLength(25).toComponent());
//        }
//
//        return recipient.format().asRecipient().toComponent();
//    }
}
