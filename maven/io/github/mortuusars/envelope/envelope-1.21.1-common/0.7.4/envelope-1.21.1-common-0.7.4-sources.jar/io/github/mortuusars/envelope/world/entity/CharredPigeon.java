package io.github.mortuusars.envelope.world.entity;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.bugger.Bugger;
import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1315;
import net.minecraft.class_1331;
import net.minecraft.class_1347;
import net.minecraft.class_1366;
import net.minecraft.class_1395;
import net.minecraft.class_1400;
import net.minecraft.class_1407;
import net.minecraft.class_156;
import net.minecraft.class_1569;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_173;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_47;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_52;
import net.minecraft.class_5425;
import net.minecraft.class_5530;
import net.minecraft.class_5533;
import net.minecraft.class_5534;
import net.minecraft.class_5819;
import net.minecraft.class_7;
import net.minecraft.class_8111;
import net.minecraft.class_8567;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.goal.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CharredPigeon extends class_1588 implements class_1569 {
    private static final Logger LOGGER = LogUtils.getLogger();

    private static final class_2940<Boolean> DATA_HAS_MAIL = class_2945.method_12791(CharredPigeon.class, class_2943.field_13323);

    public float flap;
    public float flapSpeed;
    public float oFlapSpeed;
    public float oFlap;
    protected float flapping = 1.0F;
    protected float nextFlap = 1.0F;

    protected class_1799 carriedMail = class_1799.field_8037;
    protected int timeInSafeDimension = 0;

    public CharredPigeon(class_1299<? extends class_1588> type, class_1937 level) {
        super(type, level);
        field_6207 = new class_1331(this, 10, false);
        method_5941(class_7.field_9, -1.0F);
        method_5941(class_7.field_3, -1.0F);
    }

    // -- Spawn

    public static boolean checkSpawnRules(class_1299<CharredPigeon> pigeon, class_1936 level,
                                          class_3730 spawnType, class_2338 pos, class_5819 random) {
        return Config.Server.CHARRED_PIGEON_SPAWNS_NATURALLY.get();
    }

    @Override
    public @Nullable class_1315 method_5943(class_5425 level, class_1266 difficulty,
                                                  class_3730 spawnType, @Nullable class_1315 spawnGroupData) {
        if (level.method_8409().method_43058() < Config.Server.CHARRED_PIGEON_MAIL_CHANCE.get()) {
            class_52 table = level.method_8410().method_8503().method_58576().method_58295(Envelope.LootTables.CHARRED_PIGEON_MAIL);
            if (table != class_52.field_948) {
                List<class_1799> items = new ArrayList<>();
                class_8567 lootParams = new class_8567.class_8568(level.method_8410())
                      .method_51874(class_181.field_1226, this)
                      .method_51874(class_181.field_24424, this.method_19538())
                      .method_51875(class_173.field_50217);
                class_47 lootContext = new class_47.class_48(lootParams)
                      .method_60568(level.method_8409())
                      .method_309(Optional.empty());
                table.method_320(lootContext, items::add);
                if (!items.isEmpty()) {
                    setCarriedMail(class_156.method_32309(items, level.method_8409()));
                }
            }
        }

        return super.method_5943(level, difficulty, spawnType, spawnGroupData);
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
              .method_26868(class_5134.field_23716, 8.0)
              .method_26868(class_5134.field_23720, 1F)
              .method_26868(class_5134.field_23719, 0.2F)
              .method_26868(class_5134.field_23721, 4.0);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(DATA_HAS_MAIL, false);
    }

    // --

    public boolean hasMail() {
        return field_6011.method_12789(DATA_HAS_MAIL);
    }

    public class_1799 getCarriedMail() {
        return carriedMail;
    }

    public void setCarriedMail(class_1799 carriedMail) {
        this.carriedMail = carriedMail;
        field_6011.method_12778(DATA_HAS_MAIL, !carriedMail.method_7960());
    }

    // -- AI

    @Override
    protected void method_5959() {
        field_6201.method_6277(2, new class_1366(this, 1.5, false));
        field_6201.method_6277(5, new WanderGoal(this, 1));
        field_6201.method_6277(8, new class_1347(this));
        field_6185.method_6277(1, new class_1400<>(this, class_1657.class, 10, true, true, arg -> Math.abs(arg.method_23318() - this.method_23318()) <= 4.0));
    }

    @Override
    protected @NotNull class_1407 method_5965(class_1937 level) {
        class_1407 navigation = new PigeonFlyingPathNavigation(this, level);
        navigation.method_6332(false);
        navigation.method_6354(true);
        navigation.method_6331(true);
        return navigation;
    }

    @Override
    public void method_6007() {
        super.method_6007();
        calculateFlapping();

        spawnParticle();

        if (Config.Server.CHARRED_PIGEON_CONVERT_INTO_REGULAR.get() && method_37908() instanceof class_3218 serverLevel) {
            if (canConvert()) {
                timeInSafeDimension++;

                if (!method_29504() && (method_5816() || timeInSafeDimension > Config.Server.CHARRED_PIGEON_CONVERT_INTO_REGULAR_TICKS.get())) {
                    convert(serverLevel);
                }
            } else {
                timeInSafeDimension = 0;
            }
        }
    }

    protected void spawnParticle() {
        if (method_37908().method_8608() && method_37908().method_8409().method_43048(3) == 0) {
            class_2394 particle = method_59922().method_43048(20) == 0
                  ? class_2398.field_11239
                  : method_59922().method_43056() ? class_2398.field_11240 : class_2398.field_27783;
            class_243 p = method_19538().method_1019(method_5828(0).method_1021(-0.25));
            method_37908().method_8406(particle,
                  p.field_1352 + method_59922().method_43057() * 0.8f - 0.4f,
                  p.field_1351 + 0.2 + method_59922().method_43057() * 0.3f,
                  p.field_1350 + method_59922().method_43057() * 0.8f - 0.4f, 0, 0, 0);
        }
    }

    public boolean canConvert() {
        return !method_37908().method_8597().comp_644() && !method_5987();
    }

    public void convert(class_3218 serverLevel) {
        class_1799 carriedMail = getCarriedMail();
        @Nullable Pigeon pigeon = method_29243(Envelope.EntityTypes.PIGEON.get(), true);
        if (pigeon != null) {
            PigeonVariant.get(method_56673(), PigeonVariant.CHARRED).ifPresentOrElse(pigeon::setVariant,
                  () -> LOGGER.error("Cannot set charred variant when converting to regular pigeon. Variant is not found."));

            if (!carriedMail.method_7960()) {
                method_5775(carriedMail);
                setCarriedMail(class_1799.field_8037);
            }

            pigeon.method_18799(method_18798());
            pigeon.method_36457(method_36455());
            pigeon.method_5847(method_5791());
            pigeon.method_36456(method_36454());
            if (method_5942().method_6355() != null) {
                pigeon.method_5942().method_6334(pigeon.method_5942().method_6348(method_5942().method_6355(), 1), 1);
            }

            serverLevel.method_43129(null, pigeon, class_3417.field_15102, class_3419.field_15254, 0.6f, 1);
            serverLevel.method_14199(class_2398.field_11237, method_19538().field_1352, method_19538().field_1351 + 0.2, method_19538().field_1350, 5, 0.3, 0.3, 0.3, 0);
        }
    }

    protected void calculateFlapping() {
        this.oFlap = this.flap;
        this.oFlapSpeed = this.flapSpeed;
        this.flapSpeed = this.flapSpeed + (float) (!this.method_24828() && !this.method_5765() ? 4 : -1) * 0.3F;
        this.flapSpeed = class_3532.method_15363(this.flapSpeed, 0.0F, 1.0F);
        if (!this.method_24828() && this.flapping < 1.0F) {
            this.flapping = 1.0F;
        }

        this.flapping *= 0.9F;
        class_243 vec3 = this.method_18798();
        if (!this.method_24828() && vec3.field_1351 < 0.0) {
            this.method_18799(vec3.method_18805(1, 0.75f, 1));
        }

        this.flap = this.flap + this.flapping * 2.0F;
    }

    @Override
    protected boolean method_5776() {
        return field_28627 > nextFlap;
    }

    @Override
    protected void method_5801() {
        method_5783(Envelope.SoundEvents.CHARRED_PIGEON_FLY.get(), 0.15F, 1.0F);
        nextFlap = field_28627 + flapSpeed / 2.0F;
    }

    public boolean isFlying() {
        return !this.method_24828() && !method_5765();
    }

    @Override
    public boolean method_6121(class_1297 target) {
        if (super.method_6121(target)) {
            target.method_5639((float) Config.Server.CHARRED_PIGEON_IGNITE_SECONDS.getAsDouble());
            return true;
        }
        return false;
    }

    @Override
    protected @NotNull class_1269 method_5992(class_1657 player, class_1268 hand) {
        if (player.method_5998(hand).method_7960() && !getCarriedMail().method_7960()) {
            player.method_6122(hand, getCarriedMail().method_7972());
            setCarriedMail(class_1799.field_8037);
            method_37908().method_43129(null, player, class_3417.field_15197, class_3419.field_15248, 1, 1);
            return class_1269.field_5812;
        }
        return super.method_5992(player, hand);
    }

    @Override
    public void method_6078(class_1282 damageSource) {
        super.method_6078(damageSource);
        if (damageSource.method_49708(class_8111.field_42338) && Bugger.isEnabled()) {
            LOGGER.info("Charred Pigeon has died in lava at: [{}]!", method_24515().method_23854());
        }
    }

    @Override
    protected void method_6099(class_3218 level, class_1282 damageSource, boolean recentlyHit) {
        super.method_6099(level, damageSource, recentlyHit);

        if (!getCarriedMail().method_7960()) {
            method_5775(getCarriedMail());
            setCarriedMail(class_1799.field_8037);
        }
    }

    // -- Sound

    @Nullable
    @Override
    public class_3414 method_5994() {
        return Envelope.SoundEvents.CHARRED_PIGEON_AMBIENT.get();
    }

    @Override
    protected @NotNull class_3414 method_6011(class_1282 damageSource) {
        return Envelope.SoundEvents.CHARRED_PIGEON_HURT.get();
    }

    @Override
    protected @NotNull class_3414 method_6002() {
        return Envelope.SoundEvents.CHARRED_PIGEON_DEATH.get();
    }

    /**
     * Overwritten to use entity instead of entity position.
     * This properly updates sound position for longer sounds and stops ambient sounds when entity dies.
     * I think that might be a bug that Mojang doesn't use entity overload, but maybe it's for some optimization, idk.
     */
    @Override
    public void method_5783(class_3414 sound, float volume, float pitch) {
        if (!method_5701()) {
            method_37908().method_43129(null, this, sound, method_5634(), volume, pitch);
        }
    }

    @Override
    protected void method_5712(class_2338 pos, class_2680 state) {
        method_5783(Envelope.SoundEvents.CHARRED_PIGEON_STEP.get(), 0.15F, 1.0F);
    }

    @Override
    public float method_6017() {
        return getPitch(field_5974) + (method_6109() ? 0.3f : 0);
    }

    public static float getPitch(class_5819 random) {
        return (random.method_43057() - random.method_43057()) * 0.1F + 1.0F;
    }

    // -- Interaction

    @Override
    public boolean method_5810() {
        return true;
    }

    @Override
    protected void method_6087(class_1297 entity) {
        if (!(entity instanceof class_1657)) {
            super.method_6087(entity);
        }
    }

    // -- Save / Load

    @Override
    public void method_5652(class_2487 tag) {
        super.method_5652(tag);
        if (!getCarriedMail().method_7960()) tag.method_10566("CarriedMail", getCarriedMail().method_57358(method_56673()));
        if (timeInSafeDimension > 0) tag.method_10569("TimeInSafeDimension", timeInSafeDimension);
    }

    @Override
    public void method_5749(class_2487 tag) {
        super.method_5749(tag);
        setCarriedMail(class_1799.method_57360(method_56673(), tag.method_10562("CarriedMail")).orElse(class_1799.field_8037));
        timeInSafeDimension = tag.method_10550("TimeInSafeDimension");
    }

    // --

    static class WanderGoal extends class_1395 {
        final CharredPigeon pigeon;

        public WanderGoal(CharredPigeon pigeon, double speedModifier) {
            super(pigeon, speedModifier);
            this.pigeon = pigeon;
            field_6564 = 10;
        }

        @Override
        protected @Nullable class_243 method_6302() {
            if (pigeon.method_5816()) {
                @Nullable class_243 pos = class_5534.method_31527(pigeon, 15, 15);
                if (pos != null) {
                    return pos;
                }
            }

            class_243 direction = pigeon.method_5828(0.0F);

            int range = 8;
            int yRange = 8;

            class_243 hoverPos = class_5533.method_31524(pigeon, range, yRange,
                  direction.field_1352, direction.field_1350, (float) (Math.PI / 2), 3, 1);
            if (hoverPos != null) {
                return hoverPos;
            }

            return class_5530.method_31504(pigeon, range, yRange, -1,
                  direction.field_1352, direction.field_1350, (float) (Math.PI / 2));
        }
    }
}
