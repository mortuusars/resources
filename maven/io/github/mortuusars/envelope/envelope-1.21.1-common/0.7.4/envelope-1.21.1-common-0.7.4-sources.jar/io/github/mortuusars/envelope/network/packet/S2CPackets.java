package io.github.mortuusars.envelope.network.packet;

import io.github.mortuusars.envelope.network.packet.clientbound.*;
import io.github.mortuusars.envelope.util.bugger.network.BuggerDataS2CP;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class S2CPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
                new class_8710.class_9155<>(MailboxHasNewMailS2CP.TYPE, MailboxHasNewMailS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(MailboxMenuSetMailS2CP.TYPE, MailboxMenuSetMailS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(MailboxMenuMailRemovedS2CP.TYPE, MailboxMenuMailRemovedS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(OpenLetterEditScreenS2CP.TYPE, OpenLetterEditScreenS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(OpenLetterBlockViewScreenS2CP.TYPE, OpenLetterBlockViewScreenS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(OpenLetterViewScreenS2CP.TYPE, OpenLetterViewScreenS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(OpenAddressTagScreenS2CP.TYPE, OpenAddressTagScreenS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(OpenMailboxAddressTagScreenS2CP.TYPE, OpenMailboxAddressTagScreenS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(OpenMailboxPlacingScreenS2CP.TYPE, OpenMailboxPlacingScreenS2CP.STREAM_CODEC),

                new class_8710.class_9155<>(BuggerDataS2CP.TYPE, BuggerDataS2CP.STREAM_CODEC)
        );
    }
}