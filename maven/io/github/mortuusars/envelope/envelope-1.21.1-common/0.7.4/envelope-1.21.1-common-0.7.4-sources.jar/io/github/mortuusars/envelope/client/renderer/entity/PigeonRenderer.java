package io.github.mortuusars.envelope.client.renderer.entity;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.model.PigeonModel;
import io.github.mortuusars.envelope.client.renderer.entity.layer.PigeonBackpackLayer;
import io.github.mortuusars.envelope.client.renderer.entity.layer.PigeonHatLayer;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5601;
import net.minecraft.class_5617;
import net.minecraft.class_927;
import org.jetbrains.annotations.NotNull;

public class PigeonRenderer extends class_927<Pigeon, PigeonModel> {
    public static final class_5601 MODEL_LAYER = new class_5601(Envelope.resource("pigeon"), "main");

    public PigeonRenderer(class_5617.class_5618 context) {
        super(context, new PigeonModel(context.method_32167(MODEL_LAYER)), 0.35f);
        method_4046(new PigeonBackpackLayer(this, context.method_32170()));
        method_4046(new PigeonHatLayer(this, context.method_32170()));
    }

    @Override
    public @NotNull class_2960 getTextureLocation(Pigeon entity) {
        return entity.method_47827().comp_349().texture();
    }

    @Override
    protected float getBob(Pigeon livingBase, float partialTick) {
        float f = class_3532.method_16439(partialTick, livingBase.oFlap, livingBase.flap);
        float g = class_3532.method_16439(partialTick, livingBase.oFlapSpeed, livingBase.flapSpeed);
        return (class_3532.method_15374(f) + 1.0F) * g;
    }
}