package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.Platform;
import io.github.mortuusars.envelope.world.inventory.PackageMenu;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import net.minecraft.class_124;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1277;
import net.minecraft.class_1303;
import net.minecraft.class_1657;
import net.minecraft.class_173;
import net.minecraft.class_174;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5632;
import net.minecraft.class_747;
import net.minecraft.class_8567;
import net.minecraft.class_9297;
import net.minecraft.class_9334;
import net.minecraft.world.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

public class PackageItem extends class_1747 implements Sealable {
    public PackageItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    @Override
    public boolean method_31568() {
        return false;
    }

    @Override
    public @NotNull Optional<class_5632> method_32346(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.PACKAGE_CONTENTS));
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> components, class_1836 tooltipFlag) {
        super.method_7851(stack, context, components, tooltipFlag);

        @Nullable class_9297 loot = stack.method_57824(class_9334.field_49626);
        if (loot != null) {
            components.add(class_2561.method_43471("container.envelope.package.contents_unknown").method_27692(class_124.field_1080));

            if (tooltipFlag.method_8035()) {
                components.add(class_2561.method_43470("Loot Table: ").method_27692(class_124.field_1063)
                      .method_10852(class_2561.method_43470(loot.comp_2414().method_29177().toString()).method_27692(class_124.field_1063)));
            }
        }

        if (tooltipFlag.method_8035()) {
            int xp = stack.method_57825(Envelope.DataComponents.PACKAGE_EXPERIENCE, 0);
            if (xp > 0) {
                components.add(class_2561.method_43470("Experience: " + xp).method_27692(class_124.field_1063));
            }
        }
    }

    public double getBoxReturnChance(class_1799 stack) {
        return Config.Server.PACKAGE_PAPER_BOX_RETURN_CHANCE.get();
    }

    public class_1799 createBoxReturnItem(class_1799 stack) {
        return new class_1799(Envelope.Items.PAPER_BOX.get());
    }

    // --

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        if (!context.method_8046()) {
            return class_1269.field_5811;
        }
        return super.method_7884(context);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (Config.Server.PACKAGE_SNEAK_QUICK_UNPACK.get() && player.method_21823()) {
            destroy(stack, level, player.method_19538(), player);
            stack.method_7934(1);
        } else {
            unpackLootTableIfPresent(stack, level, player.method_19538(), player);
            dropExperience(stack, level, player.method_19538());

            if (player instanceof class_3222 serverPlayer) {
                // Force update the stack on client before opening, so the client has correct initial state.
                player.field_7498.method_7623();

                class_747 menuProvider = new class_747(
                      (id, inventory, pl) -> new PackageMenu(id, inventory, hand), stack.method_7964());
                Platform.openMenu(serverPlayer, menuProvider, buffer -> buffer.method_10817(hand));
            }
        }

        player.method_37908().method_43129(player, player, Envelope.SoundEvents.PAPER_TEAR.get(), class_3419.field_15248, 0.6f, 0.95f);
        return class_1271.method_22427(stack);
    }

    protected void unpackLootTableIfPresent(class_1799 stack, class_1937 level, class_243 pos, @Nullable class_1657 player) {
        if (level instanceof class_3218 serverLevel
              && stack.method_57824(class_9334.field_49626) instanceof class_9297(class_5321<class_52> table, long seed)) {
            class_52 lootTable = serverLevel.method_8503().method_58576().method_58295(table);

            class_8567.class_8568 builder = new class_8567.class_8568(serverLevel)
                  .method_51874(class_181.field_24424, pos);

            if (player != null) {
                builder.method_51871(player.method_7292()).method_51874(class_181.field_1226, player);
            }

            class_1277 container = new class_1277(PackageContents.SLOTS);
            lootTable.method_329(container, builder.method_51875(class_173.field_1179), seed);

            if (stack.method_57826(Envelope.DataComponents.PACKAGE_CONTENTS)) {
                Envelope.LOGGER.warn("Unpacking container loot into the Package, that already has contents inside. " +
                      "Loot will override the contents.");
            }

            if (player instanceof class_3222 serverPlayer) {
                class_174.field_24479.method_27993(serverPlayer, table);
            }

            stack.method_57381(class_9334.field_49626);
            stack.method_57379(Envelope.DataComponents.PACKAGE_CONTENTS, new PackageContents(container));
        }
    }

    public void destroy(class_1799 stack, class_1937 level, class_243 pos, @Nullable class_1657 player) {
        unpack(stack, level, pos, player).forEach(item ->
              class_1264.method_5449(level, pos.method_10216(), pos.method_10214(), pos.method_10215(), item));
        dropExperience(stack, level, pos);
        onDestroyed(stack, level, pos, player);
    }

    public void onDestroyed(class_1799 stack, class_1937 level, class_243 pos, @Nullable class_1657 player) {
        if (!level.method_8608() && level.method_8409().method_43058() < getBoxReturnChance(stack)) {
            class_1264.method_5449(level, pos.method_10216(), pos.method_10214(), pos.method_10215(), createBoxReturnItem(stack));
        }
        if (player != null) {
            player.method_7281(Envelope.Stats.PACKAGES_OPENED.get());
        }
    }

    public List<class_1799> unpack(class_1799 stack, class_1937 level, class_243 pos, @Nullable class_1657 player) {
        unpackLootTableIfPresent(stack, level, pos, player);
        PackageContents contents = stack.method_57825(Envelope.DataComponents.PACKAGE_CONTENTS, PackageContents.EMPTY);
        stack.method_57381(Envelope.DataComponents.PACKAGE_CONTENTS);
        return contents.copyItems();
    }

    public void dropExperience(class_1799 stack, class_1937 level, class_243 pos) {
        if (level instanceof class_3218 serverLevel) {
            int points = stack.method_57825(Envelope.DataComponents.PACKAGE_EXPERIENCE, 0);
            stack.method_57381(Envelope.DataComponents.PACKAGE_EXPERIENCE);
            if (points > 0) {
                class_1303.method_31493(serverLevel, pos, points);
            }
        }
    }

    // --

    @Override
    public class_1799 seal(class_1937 level, class_1799 stack, Seal seal) {
        class_1799 sealedPackage = stack.method_60503(Envelope.Items.SEALED_PACKAGE.get());
        sealedPackage.method_57379(Envelope.DataComponents.SEAL, seal);
        return sealedPackage;
    }
}