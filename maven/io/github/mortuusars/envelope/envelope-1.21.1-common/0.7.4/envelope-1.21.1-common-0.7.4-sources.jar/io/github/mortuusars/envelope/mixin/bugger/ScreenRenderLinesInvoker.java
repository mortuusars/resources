package io.github.mortuusars.envelope.mixin.bugger;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_340;

@Mixin(class_340.class)
public interface ScreenRenderLinesInvoker {
    @Invoker("renderLines")
    void drawLines(class_332 guiGraphics, List<String> lines, boolean leftSide);
}
