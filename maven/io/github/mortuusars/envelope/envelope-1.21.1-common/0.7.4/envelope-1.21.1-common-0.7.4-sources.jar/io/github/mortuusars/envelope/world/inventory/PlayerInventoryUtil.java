package io.github.mortuusars.envelope.world.inventory;

import java.util.function.Predicate;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;

public class PlayerInventoryUtil {
    public static boolean canAddWholeStack(class_1657 player, class_1799 stack) {
        class_1661 inventory = player.method_31548();
        class_1799 insertedStack = stack.method_7972();

        for (int i = 0; i < inventory.field_7547.size(); i++) {
            class_1799 slotStack = inventory.method_5438(i);

            if (slotStack.method_7960()) {
                int maxInsert = Math.min(inventory.method_5444(), insertedStack.method_7914());
                int insertedAmount = Math.min(insertedStack.method_7947(), maxInsert);
                insertedStack.method_7934(insertedAmount);
            } else if (class_1799.method_31577(slotStack, insertedStack)) {
                int space = Math.min(inventory.method_5444(), slotStack.method_7914()) - slotStack.method_7947();
                if (space > 0) {
                    int insertedAmount = Math.min(space, insertedStack.method_7947());
                    insertedStack.method_7934(insertedAmount);
                }
            }

            if (insertedStack.method_7960()) {
                return true; // Whole stack fits
            }
        }

        return false; // Cannot fit whole stack
    }

    public static boolean tryAddWholeStack(class_1657 player, class_1799 stack) {
        class_1661 inventory = player.method_31548();
        class_1799 insertedStack = stack.method_7972();

        for (int i = 0; i < inventory.field_7547.size(); i++) {
            class_1799 slotStack = inventory.method_5438(i);

            if (slotStack.method_7960()) {
                int maxInsert = Math.min(inventory.method_5444(), insertedStack.method_7914());
                int insertedAmount = Math.min(insertedStack.method_7947(), maxInsert);
                insertedStack.method_7934(insertedAmount);
            } else if (class_1799.method_31577(slotStack, insertedStack)) {
                int space = Math.min(inventory.method_5444(), slotStack.method_7914()) - slotStack.method_7947();
                if (space > 0) {
                    int insertedAmount = Math.min(space, insertedStack.method_7947());
                    insertedStack.method_7934(insertedAmount);
                }
            }

            if (insertedStack.method_7960()) { // Whole stack fits
                player.method_31548().method_7394(stack);
                return true;
            }
        }

        return false; // Cannot fit whole stack
    }

    public static class_1799 findFirstMatching(class_1657 player, Predicate<class_1799> predicate) {
        for (class_1799 stack : player.method_31548().field_7544) {
            if (predicate.test(stack)) {
                return stack;
            }
        }

        for (class_1799 stack : player.method_31548().field_7547) {
            if (predicate.test(stack)) {
                return stack;
            }
        }

        return class_1799.field_8037;
    }
}
