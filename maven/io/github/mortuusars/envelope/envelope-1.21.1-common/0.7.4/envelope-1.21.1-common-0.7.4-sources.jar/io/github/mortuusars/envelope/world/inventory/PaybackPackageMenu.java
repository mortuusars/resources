package io.github.mortuusars.envelope.world.inventory;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.inventory.slot.PreviewSlot;
import io.github.mortuusars.envelope.world.item.component.PaybackSubject;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3917;
import net.minecraft.class_9129;

public class PaybackPackageMenu extends PackageMenu {
    protected PaybackSubject subject;

    protected PaybackPackageMenu(@Nullable class_3917<?> menuType, int containerId, class_1661 inventory, class_1268 hand) {
        super(menuType, containerId, inventory, hand);
    }

    public PaybackPackageMenu(int containerId, class_1661 inventory, class_1268 hand) {
        this(Envelope.MenuTypes.PAYBACK_PACKAGE.get(), containerId, inventory, hand);
    }

    public static PaybackPackageMenu fromNetwork(int id, class_1661 inventory, class_9129 buffer) {
        return new PaybackPackageMenu(id, inventory, buffer.method_10818(class_1268.class));
    }

    public PaybackSubject getPaybackSubject() {
        return subject;
    }

    @Override
    protected void init() {
        this.subject = Objects.requireNonNull(getItemInHand().method_57824(Envelope.DataComponents.PAYBACK_SUBJECT),
              "Item in hand does not have 'envelope:payback_subject' component.");
        super.init();
        method_7621(new PreviewSlot(subject.mail(), 0, 19, 42));
    }

    @Override
    protected void onDestroyed(@NotNull class_1657 player, class_1799 stack) {
        class_1937 level = player.method_37908();
        class_243 pos = player.method_19538();
        if (!level.method_8608() && level.method_8409().method_43058() < getBoxReturnChance()) {
            class_1264.method_5449(level, pos.method_10216(), pos.method_10214(), pos.method_10215(), createBoxReturnItem());
        }
    }

    protected double getBoxReturnChance() {
        return Config.Server.PAYBACK_PACKAGE_BOX_RETURN_CHANCE.get();
    }

    protected class_1799 createBoxReturnItem() {
        return Mail.createPaybackBox(getPaybackSubject()).get();
    }
}