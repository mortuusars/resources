package io.github.mortuusars.envelope.world.item.component.seal;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2561;
import net.minecraft.class_5244;
import net.minecraft.class_5632;
import net.minecraft.class_6880;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record Seal(class_6880<SealMaterial> material, class_6880<SealSymbol> impression, class_2561 signature) implements class_5632 {
    public static final Codec<Seal> CODEC = RecordCodecBuilder.create(i -> i.group(
          SealMaterial.CODEC.fieldOf("material").forGetter(Seal::material),
          SealSymbol.CODEC.fieldOf("impression").forGetter(Seal::impression),
          class_8824.field_46597.optionalFieldOf("signature", class_5244.field_39003).forGetter(Seal::signature)
    ).apply(i, Seal::new));

    public static final class_9139<class_9129, Seal> STREAM_CODEC = class_9139.method_56436(
          SealMaterial.STREAM_CODEC, Seal::material,
          SealSymbol.STREAM_CODEC, Seal::impression,
          class_8824.field_48540, Seal::signature,
          Seal::new
    );
}