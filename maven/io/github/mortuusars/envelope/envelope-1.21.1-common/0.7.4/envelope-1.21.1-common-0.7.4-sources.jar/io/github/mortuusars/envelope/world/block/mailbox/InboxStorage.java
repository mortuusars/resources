package io.github.mortuusars.envelope.world.block.mailbox;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.bugger.Bugger;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;

import java.util.*;
import net.minecraft.class_1799;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_3218;
import net.minecraft.class_4844;
import net.minecraft.class_7225;

public class InboxStorage extends class_18 {
    public static final Codec<InboxStorage> CODEC = RecordCodecBuilder.create(instance -> instance.group(
          Codec.unboundedMap(class_4844.field_41525, UnloadedInbox.CODEC)
                .optionalFieldOf("inboxes", Collections.emptyMap()).forGetter(InboxStorage::getInboxes)
    ).apply(instance, InboxStorage::new));
    public static final Logger LOGGER = LogUtils.getLogger();

    private final Map<UUID, UnloadedInbox> inboxes;

    public InboxStorage(Map<UUID, UnloadedInbox> inboxes) {
        this.inboxes = new HashMap<>(inboxes); // Make sure it's mutable
    }

    public InboxStorage() {
        this.inboxes = new HashMap<>();
    }

    protected Map<UUID, UnloadedInbox> getInboxes() {
        return inboxes;
    }

    public void put(UUID id, Inbox inbox) {
        UnloadedInbox unloadedInbox = new UnloadedInbox(id, inbox.getAddress(), inbox.getInboxCapacity(), inbox.getAllMail());
        unloadedInbox.getAllMail().removeIf(class_1799::method_7960); // Empty stacks are not allowed.
        inboxes.put(unloadedInbox.getId(), unloadedInbox);
        method_80();

        if (Bugger.isEnabled() && !unloadedInbox.isInboxEmpty()) {
            LOGGER.info("Stored inbox with size [{}] of mailbox {}", unloadedInbox.getAllMail().size(), unloadedInbox.getAddress());
        }
    }

    /**
     * Removes inbox from storage by its id, if present.
     */
    public Optional<Inbox> remove(UUID id) {
        return Optional.ofNullable(inboxes.remove(id))
              .map(inbox -> {
                  method_80();
                  if (Bugger.isEnabled() && !inbox.getAllMail().isEmpty()) {
                      LOGGER.info("Loaded inbox with size [{}] of mailbox {}", inbox.getAllMail().size(), inbox.getAddress());
                  }
                  return inbox;
              });
    }

    public @NotNull Optional<Inbox> getForDelivery(BlockAddress address) {
        for (UnloadedInbox inbox : getInboxes().values()) {
            if (inbox.getAddress().equals(address)) {
                inbox.onChanged(this::method_80);
                return Optional.of(inbox);
            }
        }
        return Optional.empty();
    }

    // --

    public static InboxStorage get(class_3218 level) {
        return level.method_8503().method_30002().method_17983().method_17924(factory(), "envelope_inboxes");
    }

    public static @NotNull class_8645<InboxStorage> factory() {
        return new class_8645<>(
              InboxStorage::new,
              (tag, provider) -> CODEC.parse(provider.method_57093(class_2509.field_11560), tag)
                    .resultOrPartial(e -> Envelope.LOGGER.error("Cannot load InboxStorage: {}", e))
                    .orElse(null),
              null);
    }

    public @NotNull class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
        return (class_2487) CODEC.encode(this, registries.method_57093(class_2509.field_11560), tag)
              .resultOrPartial(e -> Envelope.LOGGER.error("Cannot save InboxStorage: {}", e))
              .orElse(tag);
    }
}