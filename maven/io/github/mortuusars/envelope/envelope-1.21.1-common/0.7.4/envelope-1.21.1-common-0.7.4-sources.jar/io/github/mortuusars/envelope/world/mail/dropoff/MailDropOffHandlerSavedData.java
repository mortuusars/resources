package io.github.mortuusars.envelope.world.mail.dropoff;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import io.github.mortuusars.envelope.Envelope;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;

public class MailDropOffHandlerSavedData extends class_18 {
    public static final Codec<MailDropOffHandlerSavedData> CODEC = class_2487.field_25128.xmap(MailDropOffHandlerSavedData::new, MailDropOffHandlerSavedData::getData);

    protected final class_2487 data;

    public MailDropOffHandlerSavedData(class_2487 data) {
        this.data = data;
    }

    public MailDropOffHandlerSavedData() {
        this.data = new class_2487();
    }

    public class_2487 getData() {
        return data;
    }

    public class_2487 get(class_2960 location) {
        return getData().method_10562(location.toString());
    }

    public void set(class_2960 location, class_2487 data) {
        getData().method_10566(location.toString(), data);
        method_80();
    }

    // -- Save / Load

    public static MailDropOffHandlerSavedData get(class_3218 level) {
        return level.method_8503().method_30002().method_17983().method_17924(factory(), "envelope_mail_dropoff_handlers");
    }

    @Override
    public @NotNull class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
        return CODEC.encode(this, class_2509.field_11560, tag)
                .ifError(e -> Envelope.LOGGER.error("Cannot save MailDropOffHandlerSavedData: {}", e.message()))
                .result()
                .filter(t -> t instanceof class_2487)
                .map(t -> ((class_2487) t))
                .orElse(tag);
    }

    private static MailDropOffHandlerSavedData load(class_2487 tag, class_7225.class_7874 registries) {
        return CODEC.decode(class_2509.field_11560, tag)
                .ifError(e -> Envelope.LOGGER.error("Cannot load MailDropOffHandlerSavedData: {}", e.message()))
                .result().map(Pair::getFirst).orElseGet(MailDropOffHandlerSavedData::new);
    }

    private static class_8645<MailDropOffHandlerSavedData> factory() {
        return new class_8645<>(MailDropOffHandlerSavedData::new, MailDropOffHandlerSavedData::load, null);
    }
}
