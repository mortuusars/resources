package io.github.mortuusars.envelope.mixin.bugger;

import io.github.mortuusars.envelope.util.bugger.BuggerEntityOverhead;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_897;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
public abstract class EntityRendererMixin<T extends class_1297> {
    @Shadow @Final protected class_898 entityRenderDispatcher;

    @Inject(method = "render", at = @At("RETURN"))
    private void onRender(T entity, float entityYaw, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight, CallbackInfo ci) {
        BuggerEntityOverhead.onRenderEntity(entityRenderDispatcher, entity, partialTick, poseStack, bufferSource, packedLight);
    }
}
