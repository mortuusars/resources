package io.github.mortuusars.envelope.world.item.crafting;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.PaybackTagItem;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_9694;
import org.jetbrains.annotations.NotNull;

public class PaybackTagApplicationRecipe extends class_1852 {
    public PaybackTagApplicationRecipe(class_7710 category) {
        super(category);
    }

    public boolean matches(class_9694 input, class_1937 level) {
        int targets = 0;
        int tags = 0;

        for (int k = 0; k < input.method_59983(); k++) {
            class_1799 stack = input.method_59984(k);
            if (stack.method_7960()) {
                continue;
            }

            if (stack.method_31573(Envelope.Tags.Items.MAILABLE)) {
                targets++;
            } else {
                if (!(stack.method_7909() instanceof PaybackTagItem) || !stack.method_57826(Envelope.DataComponents.PAYBACK_TAG_CONTENTS)) {
                    return false;
                }

                tags++;
            }

            if (tags > 1 || targets > 1) {
                return false;
            }
        }

        return targets == 1 && tags == 1;
    }

    public @NotNull class_1799 assemble(class_9694 input, class_7225.class_7874 registries) {
        class_1799 target = class_1799.field_8037;
        class_1799 tag = class_1799.field_8037;

        for (int i = 0; i < input.method_59983(); i++) {
            class_1799 stack = input.method_59984(i);
            if (stack.method_7960()) {
                continue;
            }

            if (stack.method_31573(Envelope.Tags.Items.MAILABLE)) {
                target = stack;
            } else if (stack.method_7909() instanceof PaybackTagItem) {
                tag = stack;
            }
        }

        if (target.method_7960() || tag.method_7960()) {
            return class_1799.field_8037;
        }

        return Mail.setPaybackRequest(target.method_46651(1), tag.method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS));
    }

    @Override
    public boolean method_8113(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return Envelope.RecipeSerializers.PAYBACK_TAG_APPLICATION.get();
    }
}
