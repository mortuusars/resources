package io.github.mortuusars.envelope.advancements.critereon;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.advancements.predicate.DeliveryPredicate;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_2048;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;

public class MailDeliveredTrigger extends class_4558<MailDeliveredTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player,
                        Delivery delivery) {
        this.method_22510(player, triggerInstance ->
              triggerInstance.matches(player, delivery));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  Optional<DeliveryPredicate> delivery) implements class_4558.class_8788 {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                    class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::comp_2029),
                    DeliveryPredicate.CODEC.optionalFieldOf("delivery").forGetter(TriggerInstance::delivery))
              .apply(instance, TriggerInstance::new));

        public boolean matches(class_3222 player,
                               Delivery delivery) {
            return (this.delivery.isEmpty() || this.delivery.get().matches(player.method_51469(), delivery));
        }
    }
}
