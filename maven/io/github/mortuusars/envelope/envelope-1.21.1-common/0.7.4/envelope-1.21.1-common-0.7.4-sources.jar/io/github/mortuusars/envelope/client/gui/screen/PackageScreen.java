package io.github.mortuusars.envelope.client.gui.screen;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.inventory.PackageMenu;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public class PackageScreen extends AbstractInHandContainerScreen<PackageMenu> {
    public static final class_2960 TEXTURE = Envelope.resource("textures/gui/package.png");

    public PackageScreen(PackageMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title, TEXTURE);
    }

    @Override
    protected void method_25426() {
        field_2792 = 176;
        field_2779 = 178;
        super.method_25426();
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        super.method_2389(guiGraphics, partialTick, mouseX, mouseY);

        if (method_17577().isDestroyedOnClose()) {
            guiGraphics.method_25302(TEXTURE, field_2776 + 45, field_2800 + 17, 0, 178, 86, 64);
        }
    }
}