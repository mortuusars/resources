package io.github.mortuusars.envelope.mixin.predators;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import net.minecraft.class_1299;
import net.minecraft.class_1321;
import net.minecraft.class_1404;
import net.minecraft.class_1451;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1451.class)
public abstract class CatMixin extends class_1321 {
    protected CatMixin(class_1299<? extends class_1321> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "registerGoals", at = @At("RETURN"))
    private void registerGoals(CallbackInfo ci) {
        this.field_6185.method_6277(1, new class_1404<>((class_1451)(Object)this, Pigeon.class, false,
              entity -> Config.Server.PIGEON_HUNTED_BY_CAT.get()));
    }
}
