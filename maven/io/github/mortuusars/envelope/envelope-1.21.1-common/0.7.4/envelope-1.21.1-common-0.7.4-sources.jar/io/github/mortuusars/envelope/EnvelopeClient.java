package io.github.mortuusars.envelope;

import io.github.mortuusars.envelope.client.gui.tooltip.*;
import io.github.mortuusars.envelope.client.renderer.SealRenderer;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.util.bugger.BuggerDebugScreen;
import io.github.mortuusars.envelope.util.bugger.BuggerEntityOverhead;
import io.github.mortuusars.envelope.util.bugger_data.EnvelopeBuggerPage;
import io.github.mortuusars.envelope.util.bugger_data.PigeonEntityDataDisplay;
import io.github.mortuusars.envelope.world.item.component.*;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryLog;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.item.tooltip.CompositeTooltip;
import io.github.mortuusars.envelope.world.item.tooltip.MailAddressTagTooltip;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_437;
import net.minecraft.class_5272;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import net.minecraft.class_638;

public class EnvelopeClient {
    private static final SealRenderer sealRenderer = new SealRenderer();

    public static void init() {
        BuggerDebugScreen.addPage(new EnvelopeBuggerPage());
        BuggerEntityOverhead.addData(new PigeonEntityDataDisplay());
        ItemModelOverrides.register();
    }

    public static SealRenderer getSealRenderer() {
        return sealRenderer;
    }

    // --

    public static class ItemModelOverrides {
        public static final class_2960 LETTER_TATTERED = Envelope.resource("letter_tattered");
        public static final class_2960 LETTER_UNFOLDED = Envelope.resource("letter_unfolded");
        public static final class_2960 LETTER_CONTENT = Envelope.resource("letter_content");

        public static final class_2960 PAYBACK_TAG_DURATION = Envelope.resource("payback_tag_duration");

        public static void register() {
            class_5272.method_27879(Envelope.Items.LETTER_AND_QUILL.get(), LETTER_CONTENT, ItemModelOverrides::hasLetterContent);

            class_5272.method_27879(Envelope.Items.LETTER.get(), LETTER_TATTERED, ItemModelOverrides::isLetterTattered);
            class_5272.method_27879(Envelope.Items.LETTER.get(), LETTER_UNFOLDED, ItemModelOverrides::isLetterUnfolded);
            class_5272.method_27879(Envelope.Items.LETTER.get(), LETTER_CONTENT, ItemModelOverrides::hasLetterContent);

            class_5272.method_27879(Envelope.Items.SEALED_LETTER.get(), LETTER_TATTERED, ItemModelOverrides::isLetterTattered);

            class_5272.method_27879(Envelope.Items.PAYBACK_TAG.get(), PAYBACK_TAG_DURATION, ItemModelOverrides::getPaybackDuration);
        }

        public static float isLetterTattered(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed) {
            return stack.method_57826(Envelope.DataComponents.LETTER_TATTERED) ? 1 : 0;
        }

        public static float isLetterUnfolded(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed) {
            LetterContent content = stack.method_57825(Envelope.DataComponents.LETTER_CONTENT, LetterContent.EMPTY);
            return content.unfolded() ? 1 : 0;
        }

        public static float hasLetterContent(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed) {
            if (!stack.method_57825(Envelope.DataComponents.LETTER_AND_QUILL_CONTENT, LetterAndQuillContent.EMPTY).isEmpty()) {
                return 1;
            }
            if (!stack.method_57825(Envelope.DataComponents.LETTER_CONTENT, LetterContent.EMPTY).isEmpty()) {
                return 1;
            }
            return 0;
        }

        public static float getPaybackDuration(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed) {
            PaybackDuration duration = stack.method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS) instanceof PaybackRequest request
                  ? request.duration()
                  : PaybackDuration.MEDIUM;
            return duration.ordinal() / 10f; // 0.0, 0.1, 0.2, etc.
        }
    }

    public static class TooltipComponents {
        public static class_5684 create(class_5632 component) {
            return switch (component) {
                case MailAddressTagTooltip mailAddress -> new MailAddressTagTooltipComponent(mailAddress.address());
                case PackageContents packageContents -> new PackageTooltipComponent(packageContents);
                case PaybackRequest paybackRequest -> new PaybackRequestTooltipComponent(paybackRequest);
                case Seal seal -> new SealTooltipComponent(seal);
                case io.github.mortuusars.envelope.world.inventory.tooltip.SealDieTooltipComponent die ->
                      new SealDieTooltipComponent(die.impression());
                case CompositeTooltip composite -> new CompositeTooltipComponent(
                      composite.components().stream().map(class_5684::method_32663).toList()
                );
                default -> null;
            };
        }

        public static Optional<class_5632> modifyTooltipImage(class_1799 stack, Optional<class_5632> original) {
            if (stack.method_31573(Envelope.Tags.Items.MAILABLE)) {
                return CompositeTooltip.of(
                      original,
                      Optional.ofNullable(stack.method_57824(Envelope.DataComponents.MAIL_RECIPIENT)).map(MailAddressTagTooltip::new),
                      Optional.ofNullable(stack.method_57824(Envelope.DataComponents.MAIL_PAYBACK_REQUEST))
                );
            }

            return original;
        }

        public static void appendTooltipLines(class_1799 stack, Consumer<class_2561> consumer,
                                              class_1792.class_9635 context, class_1657 player, class_1836 tooltipFlag) {
            Mail.getSender(stack).ifPresent(sender -> {
                DeliveryLog deliveryLog = Mail.getLog(stack);
                if (class_437.method_25442() && !deliveryLog.isEmpty()) {
                    consumer.accept(class_2561.method_43471("gui.envelope.delivery_log"));
                    for (DeliveryRecord record : deliveryLog.records()) {
                        consumer.accept(record.getDisplayComponent());
                    }
                } else {
                    consumer.accept(class_2561.method_43471("gui.envelope.mail.from").method_27692(class_124.field_1080)
                          .method_27693(": ").method_27692(class_124.field_1080)
                          .method_10852(sender.format().asNeutral().toComponent()));
                }
            });

            if (tooltipFlag.method_8035()) {
                Optional.ofNullable(Mail.getId(stack)).ifPresent(id -> {
                    consumer.accept(class_2561.method_43470("Mail Id: " + id).method_27692(class_124.field_1063));
                });
            }
        }
    }
}
