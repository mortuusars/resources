package io.github.mortuusars.envelope.world.item.component.mail.log.record;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ReturnedRecord(class_2561 message) implements DeliveryRecord {
    public static final MapCodec<ReturnedRecord> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
          class_8824.field_46597.fieldOf("message").forGetter(ReturnedRecord::message)
    ).apply(i, ReturnedRecord::new));

    public static final class_9139<class_9129, ReturnedRecord> STREAM_CODEC = class_9139.method_56434(
          class_8824.field_48540, ReturnedRecord::message,
          ReturnedRecord::new
    );

    @Override
    public Type getType() {
        return Type.RETURNED;
    }

    @Override
    public class_5250 getDisplayComponent() {
        return class_2561.method_43469("gui.envelope.delivery_log.record.returned", message);
    }
}
