package io.github.mortuusars.envelope.client.gui.tooltip;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.world.mail.address.Address;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4597;
import net.minecraft.class_5244;
import net.minecraft.class_5684;
import net.minecraft.class_765;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;

public class MailAddressTagTooltipComponent implements class_5684 {
    private static final class_1799 ADDRESS_TAG = new class_1799(Envelope.Items.ADDRESS_TAG.get());

    private final @NotNull class_2561 component;

    public MailAddressTagTooltipComponent(Address address) {
        component = address.format().withIcon()
              .withIconColor(Colors.ADDRESS_NEUTRAL)
              .withColor(Colors.ADDRESS_NEUTRAL).toComponent();
    }

    @Override
    public int method_32664(class_327 font) {
//        if (Screen.hasShiftDown()) {
//            return Math.max(19, Math.max(font.width(fullSenderComponent), font.width(fullComponent)));
//        }
        return 19 + font.method_27525(component);
    }

    @Override
    public int method_32661() {
//        if (Screen.hasShiftDown()) {
//            return 16 + (!isEmpty(fullSenderComponent) ? 10 : 0) + (!isEmpty(fullComponent) ? 10 : 0);
//        }
        return 16;
    }

    @Override
    public void method_32666(class_327 font, int x, int y, class_332 guiGraphics) {
        guiGraphics.method_55231(ADDRESS_TAG, x - 1, y - 1, 0);
    }

    @Override
    public void method_32665(class_327 font, int x, int y, Matrix4f matrix, class_4597.class_4598 bufferSource) {
//        if (Screen.hasShiftDown()) {
//            y += 16;
//
//            if (!isEmpty(fullSenderComponent)) {
//                drawText(font, fullSenderComponent, x, y, matrix, bufferSource);
//                y += 10;
//            }
//
//            if (!isEmpty(fullComponent)) {
//                drawText(font, fullComponent, x, y, matrix, bufferSource);
//            }
//        } else {
//        }
            drawText(font, component, x + 18, y + 3, matrix, bufferSource);
    }

    private void drawText(class_327 font, class_2561 component, int x, int y, Matrix4f matrix, class_4597.class_4598 bufferSource) {
        font.method_30882(component, x, y, 0, true,
              matrix, bufferSource, class_327.class_6415.field_33993, 0x00000000, class_765.field_32767);
    }

    private boolean isEmpty(class_2561 component) {
        return component.equals(class_5244.field_39003);
    }
}
