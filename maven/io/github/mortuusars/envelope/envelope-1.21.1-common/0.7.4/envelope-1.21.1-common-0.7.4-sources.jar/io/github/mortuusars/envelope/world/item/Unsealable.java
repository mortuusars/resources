package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.util.Minecrft;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;

public interface Unsealable {
    class_1935 getUnsealedItem();

    default class_3414 getUnsealingSound() {
        return Envelope.SoundEvents.PAPER_CRACKLE.get();
    }

    default class_3414 getUnsealFinishedSound() {
        return Envelope.SoundEvents.PAPER_TEAR.get();
    }

    default int getUnsealingDuration(class_1799 stack, class_1309 entity) {
        return 20;
    }

    default class_1799 unseal(class_1799 stack, class_1937 level, @Nullable class_1309 entity) {
        class_1799 unsealedStack = stack.method_60503(getUnsealedItem());
        unsealedStack.method_57381(Envelope.DataComponents.SEAL);

        onUnsealed(stack, unsealedStack, level, entity);

        return unsealedStack;
    }

    default void onUnsealed(class_1799 stack, class_1799 unsealedStack, class_1937 level, @Nullable class_1309 entity) {
        if (entity != null) {
            @Nullable class_1657 player = entity instanceof class_1657 pl ? pl : null;
            level.method_43129(player, entity, getUnsealFinishedSound(), class_3419.field_15248, 1f,
                  level.method_8409().method_43057() * 0.1f + 0.8f);
        }

        if (level.method_8608()) {
            // Release use key after opening.
            // Otherwise, right click will be still held and will activate use again.
            Minecrft.releaseUseButton();
        }

        if (entity instanceof class_3222 serverPlayer) {
            serverPlayer.method_7281(Envelope.Stats.SEALS_BROKEN.get());
        }
    }
}
