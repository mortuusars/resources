package io.github.mortuusars.envelope.integration.jei;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailRecipe;
import mezz.jei.api.recipe.RecipeType;
import net.minecraft.class_8786;

public class EnvelopeJeiRecipeTypes {
    public static final RecipeType<class_8786<MailRecipe>> MAILING_RECIPE_TYPE =
          RecipeType.createFromVanilla(Envelope.RecipeTypes.MAILING.get());
}
