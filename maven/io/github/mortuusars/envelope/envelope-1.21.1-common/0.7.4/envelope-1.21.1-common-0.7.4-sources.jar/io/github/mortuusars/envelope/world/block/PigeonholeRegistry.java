package io.github.mortuusars.envelope.world.block;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/**
 * Runtime registry of pigeonhole block positions for moving-structure-aware target discovery.
 * Stores local identity positions; spatial checks must project before comparing distances.
 */
public final class PigeonholeRegistry {
    private static final WeakHashMap<class_3218, Set<class_2338>> REGISTRY = new WeakHashMap<>();

    private PigeonholeRegistry() {
    }

    public static void register(class_3218 level, class_2338 pos) {
        getOrCreate(level).add(pos.method_10062());
    }

    public static void unregister(class_3218 level, class_2338 pos) {
        getOrCreate(level).remove(pos);
    }

    public static Set<class_2338> getAll(class_3218 level) {
        return Collections.unmodifiableSet(getOrCreate(level));
    }

    private static Set<class_2338> getOrCreate(class_3218 level) {
        return REGISTRY.computeIfAbsent(level, ignored -> ConcurrentHashMap.newKeySet());
    }
}
