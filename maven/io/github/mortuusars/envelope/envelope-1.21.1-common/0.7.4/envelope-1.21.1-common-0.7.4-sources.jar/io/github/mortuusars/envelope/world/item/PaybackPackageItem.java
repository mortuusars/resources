package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.Platform;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.world.GameTime;
import io.github.mortuusars.envelope.world.inventory.PaybackPackageMenu;
import io.github.mortuusars.envelope.world.item.component.PaybackSubject;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_5632;
import net.minecraft.class_747;

public class PaybackPackageItem extends class_1792 {
    public PaybackPackageItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public boolean method_31568() {
        return false;
    }

    @Override
    public @NotNull Optional<class_5632> method_32346(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.PACKAGE_CONTENTS));
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> components, class_1836 flag) {
        appendPaybackHoverText(stack, context, components, flag);
    }

    public static void appendPaybackHoverText(class_1799 stack, class_9635 context, List<class_2561> components, class_1836 flag) {
        appendPaybackSubjectHoverText(components, stack.method_57824(Envelope.DataComponents.PAYBACK_SUBJECT));
    }

    public static void appendPaybackSubjectHoverText(List<class_2561> components, @Nullable PaybackSubject subject) {
        if (subject == null || subject.mail().method_7960()) {
            return;
        }

        long remainingTicks = subject.expiresAt() - Minecrft.level().method_8510();
        if (remainingTicks < 1) {
            components.add(class_2561.method_43471("gui.envelope.payback.expired").method_54663(Colors.TOOLTIP_RED));
        } else {
            class_5250 time = class_437.method_25442()
                  ? GameTime.format(remainingTicks, false)
                  : GameTime.formatLargest(remainingTicks, false);

            components.add(class_2561.method_43470("⌛ ").method_10852(time).method_54663(Colors.TOOLTIP_RED));
        }
    }

    // --

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (player instanceof class_3222 serverPlayer) {
            class_747 menuProvider = new class_747(
                  (id, inventory, pl) -> new PaybackPackageMenu(id, inventory, hand), stack.method_7964());
            Platform.openMenu(serverPlayer, menuProvider, buffer -> buffer.method_10817(hand));
        }

        player.method_37908().method_43129(player, player, Envelope.SoundEvents.PAPER_TEAR.get(), class_3419.field_15248, 0.6f, 0.95f);
        return class_1271.method_22427(stack);
    }
}