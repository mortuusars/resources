package io.github.mortuusars.envelope.util;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.function.*;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_9322;
import net.minecraft.class_9323;
import net.minecraft.class_9331;

public class ItemAndStack<T extends class_1792> implements class_9322 {
    private final T item;
    private final class_1799 stack;

    public ItemAndStack(class_1799 stack) {
        this.stack = stack;
        //noinspection unchecked
        this.item = (T) stack.method_7909();
    }

    public T getItem() {
        return item;
    }

    public class_1799 getItemStack() {
        return stack;
    }

    public ItemAndStack<T> apply(BiConsumer<T, class_1799> function) {
        function.accept(item, stack);
        return this;
    }

    public <R> R map(BiFunction<T, class_1799, R> mappingFunction) {
        return mappingFunction.apply(item, stack);
    }

    // -- Components

    @Override
    public @NotNull class_9323 method_57353() {
        return stack.method_57353();
    }

    @Nullable
    public <C> C set(class_9331<? super C> component, @Nullable C value) {
        return stack.method_57379(component, value);
    }

    @Nullable
    public <C, U> C update(class_9331<C> component, C defaultValue, U updateValue, BiFunction<C, U, C> updater) {
        return set(component, updater.apply(stack.method_57825(component, defaultValue), updateValue));
    }

    @Nullable
    public <C> C update(class_9331<C> component, C defaultValue, UnaryOperator<C> updater) {
        C object = method_57825(component, defaultValue);
        return set(component, updater.apply(object));
    }

    @Nullable
    public <C> C remove(class_9331<? extends C> component) {
        return stack.method_57381(component);
    }

    // --

    @Override
    public String toString() {
        return "ItemAndStack{" + stack.toString() + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ItemAndStack<?> that = (ItemAndStack<?>) o;
        return Objects.equals(item, that.item) && Objects.equals(stack, that.stack);
    }

    @Override
    public int hashCode() {
        return Objects.hash(item, stack);
    }
}
