package io.github.mortuusars.envelope.world.item.crafting.mail.serializer;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.crafting.mail.CustomMailRecipe;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import net.minecraft.class_1865;
import net.minecraft.class_6899;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public class CustomMailingRecipeSerializer<T extends CustomMailRecipe> implements class_1865<T> {
    private final MapCodec<T> codec;
    private final class_9139<class_9129, T> streamCodec;

    public CustomMailingRecipeSerializer(Constructor<T> constructor) {
        this.codec = RecordCodecBuilder.mapCodec(i -> i.group(
              class_6899.method_40400(Envelope.Registries.SERVICE_ADDRESS_DEFINITION)
                    .xmap(ServiceAddress::new, ServiceAddress::getDefinitionHolder)
                    .fieldOf("address")
                    .forGetter(CustomMailRecipe::getAddress)
        ).apply(i, constructor::create));

        this.streamCodec = class_9139.method_56434(
              ServiceAddress.STREAM_CODEC, CustomMailRecipe::getAddress,
              constructor::create
        );
    }

    @Override
    public @NotNull MapCodec<T> method_53736() {
        return codec;
    }

    @Override
    public @NotNull class_9139<class_9129, T> method_56104() {
        return streamCodec;
    }

    @FunctionalInterface
    public interface Constructor<T extends CustomMailRecipe> {
        T create(ServiceAddress address);
    }
}
