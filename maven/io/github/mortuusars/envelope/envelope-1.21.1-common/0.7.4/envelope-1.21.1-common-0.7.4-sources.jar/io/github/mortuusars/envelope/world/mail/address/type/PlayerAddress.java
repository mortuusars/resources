package io.github.mortuusars.envelope.world.mail.address.type;

import com.google.common.base.Preconditions;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.mail.address.Address;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_3544;
import net.minecraft.class_5250;
import net.minecraft.class_5699;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class PlayerAddress implements Address {
    public static final MapCodec<PlayerAddress> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
          class_5699.field_49183.fieldOf("name").forGetter(PlayerAddress::getString)
    ).apply(instance, PlayerAddress::new));

    public static final class_9139<class_9129, PlayerAddress> STREAM_CODEC =
          class_9135.field_48554.method_56432(PlayerAddress::new, PlayerAddress::getString).method_56430();

    private final String name;

    public PlayerAddress(String name) {
        Preconditions.checkArgument(!class_3544.method_57181(name) && class_3544.method_57179(name),
              name + " is not valid PlayerAddress. Too long or contains illegal characters.");
        this.name = name;
    }

    public PlayerAddress(class_1657 player) {
        this(player.method_5820());
    }

    @Override
    public Type getType() {
        return Type.PLAYER;
    }

    public String getString() {
        return name;
    }

    public class_5250 getComponent() {
        return class_2561.method_43470(name);
    }

    // --

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PlayerAddress that = (PlayerAddress) o;
        return this.name.equalsIgnoreCase(that.name);
    }

    @Override
    public int hashCode() {
        return ("p" + name.toLowerCase(Locale.ROOT)).hashCode();
    }

    @Override
    public @NotNull String toString() {
        return "Player[" + name + "]";
    }
}
