package io.github.mortuusars.envelope.mixin.tooltip;

import io.github.mortuusars.envelope.EnvelopeClient;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5684.class)
public interface ClientTooltipComponentMixin {
    @Inject(method = "create(Lnet/minecraft/world/inventory/tooltip/TooltipComponent;)Lnet/minecraft/client/gui/screens/inventory/tooltip/ClientTooltipComponent;",
          at = @At("HEAD"),
          cancellable = true)
    private static void onCreate(class_5632 component, CallbackInfoReturnable<class_5684> cir) {
        @Nullable class_5684 clientComponent = EnvelopeClient.TooltipComponents.create(component);
        if (clientComponent != null) {
            cir.setReturnValue(clientComponent);
        }
    }
}