package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.Platform;
import io.github.mortuusars.envelope.world.inventory.PaybackPackingMenu;
import io.github.mortuusars.envelope.world.item.component.PaybackSubject;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_747;

public class PaybackBoxItem extends class_1792 {
    public PaybackBoxItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> components, class_1836 flag) {
        PaybackPackageItem.appendPaybackHoverText(stack, context, components, flag);
    }

    // --

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (openPackingGui(player, hand, stack)) {
            return class_1271.method_29237(stack, level.field_9236);
        }
        return class_1271.method_22431(stack);
    }

    public boolean openPackingGui(class_1657 player, class_1268 hand, class_1799 stack) {
        @Nullable PaybackSubject subject = stack.method_57824(Envelope.DataComponents.PAYBACK_SUBJECT);
        if (subject == null || subject.mail().method_7960() || !subject.mail().method_57826(Envelope.DataComponents.MAIL_PAYBACK_REQUEST)) {
            return false;
        }

        if (player instanceof class_3222 serverPlayer) {
            Platform.openMenu(serverPlayer, new class_747((id, inventory, pl) ->
                        new PaybackPackingMenu(id, inventory, hand), stack.method_7964()),
                  buffer -> buffer.method_10817(hand));
        }

        player.method_37908().method_43129(player, player, Envelope.SoundEvents.PAPER_USE.get(), class_3419.field_15248, 0.6f, 0.95f);
        return true;
    }
}