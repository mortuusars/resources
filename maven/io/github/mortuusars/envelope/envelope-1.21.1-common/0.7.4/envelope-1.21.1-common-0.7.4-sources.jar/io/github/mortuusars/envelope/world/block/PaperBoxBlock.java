package io.github.mortuusars.envelope.world.block;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.VoxelShapeUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_2470;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5134;
import net.minecraft.class_9062;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PaperBoxBlock extends class_2248 {
    public static final int MAX_BOXES = 5;

    public static final class_2754<class_2350.class_2351> AXIS = class_2741.field_12529;
    public static final class_2758 BOXES = class_2758.method_11867("boxes", 1, MAX_BOXES);

    private static final class_265[] SHAPES = new class_265[8];

    static {
        // Axis X
        SHAPES[0] = class_2248.method_9541(5, 0, 4, 11, 6, 12);
        SHAPES[1] = class_259.method_1084(class_2248.method_9541(1, 0, 4, 7, 6, 13), class_2248.method_9541(8, 0, 5, 15, 6, 12));
        SHAPES[2] = class_259.method_17786(class_2248.method_9541(1, 0, 5, 7, 6, 14), class_2248.method_9541(8, 0, 8, 15, 6, 15), class_2248.method_9541(8, 0, 1, 14, 6, 7));
        SHAPES[3] = class_259.method_1084(SHAPES[2], class_2248.method_9541(5, 6, 4, 11, 12, 13));
        // Axis Z
        SHAPES[4] = VoxelShapeUtils.rotate(SHAPES[0], class_2470.field_11463);
        SHAPES[5] = VoxelShapeUtils.rotate(SHAPES[1], class_2470.field_11463);
        SHAPES[6] = VoxelShapeUtils.rotate(SHAPES[2], class_2470.field_11463);
        SHAPES[7] = VoxelShapeUtils.rotate(SHAPES[3], class_2470.field_11463);
    }

    public PaperBoxBlock(class_2251 properties) {
        super(properties);
        this.method_9590(method_9595().method_11664()
              .method_11657(AXIS, class_2350.class_2351.field_11048)
              .method_11657(BOXES, 1));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(AXIS, BOXES);
    }

    @Override
    public @NotNull class_265 method_9530(@NotNull class_2680 state, @NotNull class_1922 pLevel, @NotNull class_2338 pPos, @NotNull class_3726 pContext) {
        int boxes = state.method_11654(BOXES);
        return boxes >= MAX_BOXES
              ? class_259.method_1077()
              : SHAPES[boxes - 1 + (state.method_11654(AXIS) == class_2350.class_2351.field_11051 ? 4 : 0)];
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2680 blockstate = context.method_8045().method_8320(context.method_8037());
        if (blockstate.method_27852(this)) {
            return blockstate.method_28493(BOXES);
        } else {
            return method_9595().method_11664().method_11657(AXIS, context.method_8042().method_10166());
        }
    }

    @Override
    public boolean method_9616(@NotNull class_2680 state, class_1750 context) {
        return !context.method_8046()
              && context.method_8041().method_7909() == this.method_8389()
              && state.method_11654(BOXES) < MAX_BOXES || super.method_9616(state, context);
    }

    @Override
    protected @NotNull class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        return !state.method_26184(level, pos)
              ? class_2246.field_10124.method_9564()
              : super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    protected boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        if (state.method_11654(BOXES) == MAX_BOXES) return true;
        class_2338 blockPos = pos.method_10074();
        class_2680 stateBelow = level.method_8320(blockPos);
        return !stateBelow.method_26220(level, blockPos).method_20538(class_2350.field_11036).method_1110()
              || stateBelow.method_26206(level, blockPos, class_2350.field_11036);
    }

    @Override
    public @NotNull class_2680 method_9598(@NotNull class_2680 state, class_2470 rotation) {
        switch (rotation) {
            case field_11465, field_11463 -> {
                return switch (state.method_11654(AXIS)) {
                    case field_11048 -> state.method_11657(AXIS, class_2350.class_2351.field_11051);
                    case field_11051 -> state.method_11657(AXIS, class_2350.class_2351.field_11048);
                    default -> state;
                };
            }
            default -> {
                return state;
            }
        }
    }

    // --

    @Override
    public void method_9554(class_1937 level, class_2680 state, class_2338 pos, class_1297 entity, float fallDistance) {
        float fallDistanceToBreak = getFallDistanceToBreak(state, pos, entity);
        if (fallDistanceToBreak > 0 && fallDistance > fallDistanceToBreak) {
            if (!level.method_8608()) {
                boolean drop = !(entity instanceof class_1657 player) || !player.method_7337();
                level.method_22352(pos, drop);

                if (entity instanceof class_3222 serverPlayer) {
                    // Adding 2 to compensate for wrong fallDistance (maybe due to speed or something)
                    // It's better to trigger for slightly less, than not trigger for expected height.
                    Envelope.CriteriaTriggers.BREAK_PAPER_BOX_WHEN_FALLING_TRIGGER.get().trigger(serverPlayer, fallDistance + 2);
                }
            }
        } else {
            super.method_9554(level, state, pos, entity, fallDistance);
        }
    }

    public float getFallDistanceToBreak(class_2680 state, class_2338 pos, class_1297 entity) {
        return entity instanceof class_1309 living
              ? (float) living.method_45325(class_5134.field_49079)
              : 0f;
    }

    @Override
    public void method_9502(class_1922 level, class_1297 entity) {
        if (entity.field_6017 <= 0) {
            super.method_9502(level, entity);
        } else {
            entity.method_18799(entity.method_18798().method_18805(1.0, 0.75f, 1.0));
        }
    }

    public float reduceFallDistance(class_2680 state, class_2338 pos, class_1297 entity, float fallDistance) {
        int boxes = state.method_11654(BOXES);
        if (boxes == MAX_BOXES) return 0;
        return fallDistance * (0.5f - (0.05f * boxes));
    }

    // --

    @Override
    protected @NotNull class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        if (!player.method_21823()) {
            return class_9062.field_47731;
        }

        int newBoxes = state.method_11654(BOXES) - 1;

        if (level instanceof class_3218 serverLevel) {
            if (newBoxes <= 0) {
                level.method_8650(pos, false);
            } else {
                level.method_8652(pos, state.method_11657(BOXES, newBoxes), class_2248.field_31036);

                if (!method_9558(level.method_8320(pos), level, pos)) {
                    level.method_22352(pos, true);
                }
            }

            if (!player.method_7337()) {
                player.method_7270(new class_1799(this.method_8389()));
            }

            serverLevel.method_14199(new class_2388(class_2398.field_11217, state),
                  pos.method_10263() + 0.5f, pos.method_10264() + 0.3f, pos.method_10260() + 0.5f, 3, 0.2, 0.2, 0.2, 0);
        }

        level.method_8396(player, pos, Envelope.SoundEvents.PAPER_USE.get(), class_3419.field_15245,
              0.9f, level.method_8409().method_43057() * 0.1f + 0.85f + (newBoxes * 0.2f));

        return class_9062.field_47728;
    }
}
