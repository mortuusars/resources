package io.github.mortuusars.envelope.world.block;

import com.mojang.serialization.MapCodec;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.block.occupiable.Occupiable;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1528;
import net.minecraft.class_1541;
import net.minecraft.class_1548;
import net.minecraft.class_1657;
import net.minecraft.class_1687;
import net.minecraft.class_1701;
import net.minecraft.class_173;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_181;
import net.minecraft.class_1890;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2358;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3730;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_8567;
import net.minecraft.class_9062;
import net.minecraft.class_9636;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class PigeonholeBlock extends class_2237 {
    public static final MapCodec<PigeonholeBlock> field_46280 = method_54094(PigeonholeBlock::new);

    public static final int MAX_WASTE_LEVEL = 5;

    public static final class_2753 FACING = class_2383.field_11177;
    public static final class_2758 WASTE_LEVEL = class_2758.method_11867("waste_level", 0, MAX_WASTE_LEVEL);

    public PigeonholeBlock(class_2251 properties) {
        super(properties);
        method_9590(field_10647.method_11664()
              .method_11657(FACING, class_2350.field_11043)
              .method_11657(WASTE_LEVEL, 0));
    }

    @Override
    protected @NotNull MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, WASTE_LEVEL);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(FACING, context.method_8042().method_10153());
    }

    @Override
    protected @NotNull class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    protected int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        return state.method_11654(WASTE_LEVEL);
    }

    @Override
    public @NotNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public @NotNull class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new PigeonholeBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> blockEntityType) {
        return level.field_9236
              ? null
              : method_31618(blockEntityType, Envelope.BlockEntityTypes.PIGEONHOLE.get(),
              (lvl, blockPos, blockState, blockEntity) -> blockEntity.serverTick(((class_3218) lvl), blockPos, state));
    }

    @Override
    public void method_9556(class_1937 level, class_1657 player, class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity, class_1799 tool) {
        super.method_9556(level, player, pos, state, blockEntity, tool);
        if (blockEntity instanceof PigeonholeBlockEntity be) {
            if (!class_1890.method_60138(tool, class_9636.field_51553)) {
                be.releaseAllOccupants(level, pos, state, Occupiable.ReleaseReason.EMERGENCY);
                level.method_8455(pos, this);
            }
        }
    }

    @Override
    protected @NotNull List<class_1799> method_9560(class_2680 state, class_8567.class_8568 params) {
        class_1297 entity = params.method_51876(class_181.field_1226);
        if (entity instanceof class_1541
              || entity instanceof class_1548
              || entity instanceof class_1687
              || entity instanceof class_1528
              || entity instanceof class_1701) {
            if (params.method_51876(class_181.field_1228) instanceof PigeonholeBlockEntity be) {
                be.releaseAllOccupants(be.getLevelOrThrow(), be.method_11016(), state, Occupiable.ReleaseReason.EMERGENCY);
            }
        }

        return super.method_9560(state, params);
    }

    @Override
    protected @NotNull class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        if (level.method_8320(neighborPos).method_26204() instanceof class_2358
              && level.method_8321(pos) instanceof PigeonholeBlockEntity be) {
            be.releaseAllOccupants(be.getLevelOrThrow(), be.method_11016(), state, Occupiable.ReleaseReason.EMERGENCY);
        }

        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    // --

    public void addWaste(class_1937 level, class_2338 pos, class_2680 state) {
        int waste = state.method_11654(WASTE_LEVEL);
        if (waste < MAX_WASTE_LEVEL) {
            waste += 1;
            level.method_8501(pos, state.method_11657(WASTE_LEVEL, waste));
        }
    }

    public void clearWaste(class_1937 level, class_2338 pos, class_2680 state) {
        level.method_8501(pos, state.method_11657(WASTE_LEVEL, 0));
    }

    public boolean canScoopWaste(class_2680 state) {
        return state.method_11654(WASTE_LEVEL) >= MAX_WASTE_LEVEL;
    }

    public void dropWasteItems(class_3218 level, class_2338 pos, class_2680 state, class_1799 tool, @Nullable class_1657 player) {
        class_8567 lootParams = new class_8567.class_8568(level)
              .method_51874(class_181.field_1224, state)
              .method_51874(class_181.field_24424, class_243.method_24953(pos))
              .method_51874(class_181.field_1229, tool)
              .method_51877(class_181.field_1226, player)
              .method_51875(class_173.field_1172);

        List<class_1799> items = level.method_8503().method_58576()
              .method_58295(Envelope.LootTables.PIGEONHOLE_WASTE)
              .method_51878(lootParams);

        for (class_1799 item : items) {
            method_36992(level, pos, state.method_11654(FACING), item);

            if (item.method_31574(class_1802.field_8477) && player instanceof class_3222 serverPlayer) {
                Envelope.CriteriaTriggers.SCOOP_DIAMOND.get().method_9141(serverPlayer);
            }
        }
    }

    // -- Interaction

    @Override
    protected @NotNull class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        if (stack.method_31574(Envelope.Items.PIGEON_SPAWN_EGG.get())) {
            if (level instanceof class_3218 serverLevel
                  && level.method_8321(pos) instanceof PigeonholeBlockEntity blockEntity
                  && blockEntity.hasSpaceForAnotherOccupant()) {
                if (!player.method_7337()) {
                    stack.method_7934(1);
                }

                @Nullable Pigeon pigeon = Envelope.EntityTypes.PIGEON.get().method_47821(serverLevel, pos, class_3730.field_16465);
                if (pigeon != null) {
                    blockEntity.addOccupant(pos, state, pigeon);
                }
            }

            return class_9062.field_47728;
        }

        if (stack.method_31573(Envelope.Tags.Items.WASTE_SCOOPABLE) && canScoopWaste(state)) {
            if (level instanceof class_3218 serverLevel) {
                dropWasteItems(serverLevel, pos, state, player.method_5998(hand), player);
                clearWaste(level, pos, state);
                stack.method_7970(1, player, class_1309.method_56079(hand));
                player.method_7259(class_3468.field_15372.method_14956(stack.method_7909()));
            }

            level.method_8396(player, pos, Envelope.SoundEvents.PIGEONHOLE_SCOOP.get(), class_3419.field_15245,
                  1.0F, level.field_9229.method_43057() * 0.2f + 0.95f);

            return class_9062.field_47728;
        }

        return super.method_55765(stack, state, level, pos, player, hand, hitResult);
    }
}