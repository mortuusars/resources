package io.github.mortuusars.envelope.advancements.predicate;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import java.util.Optional;
import net.minecraft.class_2073;
import net.minecraft.class_2096;
import net.minecraft.class_3218;

public record DeliveryPredicate(
      Optional<class_2073> mail,
      Optional<class_2096.class_2100> distance) {
    public static final Codec<DeliveryPredicate> CODEC = RecordCodecBuilder.create(i -> i.group(
                class_2073.field_45754.optionalFieldOf("mail").forGetter(DeliveryPredicate::mail),
                class_2096.class_2100.field_45763.optionalFieldOf("distance").forGetter(DeliveryPredicate::distance))
          .apply(i, DeliveryPredicate::new));

    public boolean matches(class_3218 level, Delivery delivery) {
        return (mail.isEmpty() || mail.get().method_8970(delivery.getMail()))
              && (distance.isEmpty() || distance.get().method_9054(delivery.getRoute().getDistance(level)));
    }
}
