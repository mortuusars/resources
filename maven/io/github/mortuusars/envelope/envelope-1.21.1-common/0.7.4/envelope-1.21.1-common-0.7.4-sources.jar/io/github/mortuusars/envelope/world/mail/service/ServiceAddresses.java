package io.github.mortuusars.envelope.world.mail.service;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.EnvelopeSymbols;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.AddressLocation;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import java.util.*;
import java.util.stream.Collectors;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7891;

public class ServiceAddresses {
    public static final class_5321<ServiceAddressDefinition> MAIL_SERVICE =
          class_5321.method_29179(Envelope.Registries.SERVICE_ADDRESS_DEFINITION, Envelope.resource("mail_service"));
    public static final class_5321<ServiceAddressDefinition> AUTOMATED_SUPPLY_SERVICE =
          class_5321.method_29179(Envelope.Registries.SERVICE_ADDRESS_DEFINITION, Envelope.resource("automated_supply_service"));
    public static final class_5321<ServiceAddressDefinition> EQUINE_ASSURANCE_BUREAU =
          class_5321.method_29179(Envelope.Registries.SERVICE_ADDRESS_DEFINITION, Envelope.resource("equine_assurance_bureau"));

    private final MailService service;

    public ServiceAddresses(MailService service) {
        this.service = service;
    }

    public MailService getMailService() {
        return service;
    }

    public Set<ServiceAddress> getAllAddresses() {
        return getMailService().getLevel().method_30349().method_30530(Envelope.Registries.SERVICE_ADDRESS_DEFINITION)
              .method_40270()
              .map(ServiceAddress::new)
              .collect(Collectors.toSet());
    }

    public void tick() {
    }

    // --

    public static void bootstrap(class_7891<ServiceAddressDefinition> context) {
        context.method_46838(MAIL_SERVICE, new ServiceAddressDefinition(
              class_2561.method_43471("address.envelope.mail_service"),
              EnvelopeSymbols.ADDRESS_MAIL_SERVICE,
              new AddressLocation.Relative(0)));
        context.method_46838(AUTOMATED_SUPPLY_SERVICE, new ServiceAddressDefinition(
              class_2561.method_43471("address.envelope.automated_supply_service"),
              EnvelopeSymbols.ADDRESS_SERVICE,
              new AddressLocation.Relative(1000)));
        context.method_46838(EQUINE_ASSURANCE_BUREAU, new ServiceAddressDefinition(
              class_2561.method_43471("address.envelope.equine_assurance_bureau"),
              EnvelopeSymbols.ADDRESS_SERVICE,
              new AddressLocation.Relative(2000)));
    }
}
