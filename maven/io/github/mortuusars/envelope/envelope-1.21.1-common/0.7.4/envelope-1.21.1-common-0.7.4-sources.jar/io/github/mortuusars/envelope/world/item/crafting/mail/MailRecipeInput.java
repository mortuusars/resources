package io.github.mortuusars.envelope.world.item.crafting.mail;

import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.Address;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1662;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_9695;

public class MailRecipeInput implements class_9695 {
    private final MailService service;
    private final Address sender;
    private final List<class_1799> items;
    private class_1662 stackedContents;
    private int ingredientCount;

    public MailRecipeInput(MailService service, Address sender, List<class_1799> items) {
        this.service = service;
        this.sender = sender;
        this.items = new ArrayList<>(items);
        updateIngredients();
    }

    public MailRecipeInput(MailService service, Address sender, PackageContents contents) {
        this(service, sender, contents.copyItems());
    }

    private void updateIngredients() {
        stackedContents = new class_1662();
        int i = 0;
        for (class_1799 itemStack : items) {
            if (!itemStack.method_7960()) {
                i++;
                this.stackedContents.method_20478(itemStack, 1);
            }
        }
        this.ingredientCount = i;
    }

    // --

    public MailService service() {
        return service;
    }

    public class_3218 level() {
        return service.getLevel();
    }

    public Address sender() {
        return sender;
    }

    public List<class_1799> items() {
        return items;
    }

    @Override
    public @NotNull class_1799 method_59984(int index) {
        return items.get(index);
    }

    public void setItem(int index, class_1799 item) {
        items.set(index, item);
        updateIngredients();
    }

    @Override
    public int method_59983() {
        return items.size();
    }

    public class_1662 stackedContents() {
        return stackedContents;
    }

    public int ingredientCount() {
        return ingredientCount;
    }

    public PackageContents toPackageContents() {
        return new PackageContents(items());
    }

    // --


    @Override
    public String toString() {
        return "MailingInput{" +
              "sender=" + sender +
              ", items=" + items +
              '}';
    }

    @SuppressWarnings("deprecation")
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }

        return object instanceof MailRecipeInput input
              && sender.equals(input.sender)
              && ingredientCount == input.ingredientCount
              && class_1799.method_57362(items, input.items);
    }

    @SuppressWarnings("deprecation")
    public int hashCode() {
        return sender.hashCode() + class_1799.method_57361(this.items);
    }
}
