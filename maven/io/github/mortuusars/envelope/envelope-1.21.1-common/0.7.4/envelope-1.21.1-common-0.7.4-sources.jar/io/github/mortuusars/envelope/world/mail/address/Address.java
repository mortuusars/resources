package io.github.mortuusars.envelope.world.mail.address;

import com.mojang.serialization.*;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.type.*;
import io.github.mortuusars.envelope.world.mail.service.ServiceAddresses;
import org.jetbrains.annotations.NotNull;

import java.util.function.IntFunction;
import net.minecraft.class_2561;
import net.minecraft.class_3542;
import net.minecraft.class_5250;
import net.minecraft.class_7995;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public interface Address {
    Codec<Address> CODEC = Type.CODEC.dispatch(Address::getType, Type::getCodec);
    class_9139<class_9129, Address> STREAM_CODEC = Type.STREAM_CODEC.method_56440(Address::getType, Type::getStreamCodec);

    UnknownAddress UNKNOWN = UnknownAddress.INSTANCE;

    Type getType();

    String getString();

    class_5250 getComponent();

    default boolean matches(String name) {
        return getString().equalsIgnoreCase(name);
    }

    default AddressFormatter format() {
        return AddressFormatter.of(this);
    }

    default boolean isMailService() {
        return this instanceof ServiceAddress serviceAddress && serviceAddress.getDefinitionHolder().method_40225(ServiceAddresses.MAIL_SERVICE);
    }

    default boolean isUnknown() {
        return this instanceof UnknownAddress;
    }

    // --

    /**
     * Returns an endpoint from a given address. Registered block address, default address of a player, etc. Or unknown if missing.
     * @return Endpoint address or Unknown address.
     */
    default Address resolve(MailService service) {
        return switch (this) {
            case BlockAddress blockAddress -> service.getKnownAddresses().isKnown(blockAddress)
                  ? blockAddress
                  : UNKNOWN;
            case PlayerAddress playerAddress -> service.getPlayerDefaultAddress(playerAddress)
                  .map(Address.class::cast)
                  .orElse(UNKNOWN);
            default -> this;
        };
    }

    // --

    enum Type implements class_3542 {
        BLOCK("block", BlockAddress.CODEC, BlockAddress.STREAM_CODEC),
        PLAYER("player", PlayerAddress.CODEC, PlayerAddress.STREAM_CODEC),
        SERVICE("service", ServiceAddress.CODEC, ServiceAddress.STREAM_CODEC),
        CUSTOM("custom", CustomAddress.CODEC, CustomAddress.STREAM_CODEC),
        UNKNOWN("unknown", MapCodec.unit(UnknownAddress.INSTANCE), class_9139.method_56431(UnknownAddress.INSTANCE));

        public static final Codec<Type> CODEC = class_3542.method_28140(Type::values);
        public static final IntFunction<Type> BY_ID = class_7995.method_47914(Type::ordinal, values(), class_7995.class_7996.field_41664);
        public static final class_9139<class_9129, Type> STREAM_CODEC = class_9135.method_56375(BY_ID, Type::ordinal).method_56430();

        private final String name;
        private final MapCodec<? extends Address> codec;
        private final class_9139<class_9129, ? extends Address> streamCodec;

        Type(String name, MapCodec<? extends Address> codec, class_9139<class_9129, ? extends Address> streamCodec) {
            this.name = name;
            this.codec = codec;
            this.streamCodec = streamCodec;
        }

        @Override
        public @NotNull String method_15434() {
            return name;
        }

        public MapCodec<? extends Address> getCodec() {
            return codec;
        }

        public class_9139<class_9129, ? extends Address> getStreamCodec() {
            return streamCodec;
        }

        public class_5250 translate() {
            return class_2561.method_43471("address_type.envelope." + method_15434());
        }
    }
}
