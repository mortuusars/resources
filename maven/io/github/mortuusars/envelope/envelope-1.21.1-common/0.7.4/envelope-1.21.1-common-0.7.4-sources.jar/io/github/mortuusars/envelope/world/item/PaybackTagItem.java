package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.Platform;
import io.github.mortuusars.envelope.world.block.PigeonholeBlock;
import io.github.mortuusars.envelope.world.inventory.PaybackTagMenu;
import io.github.mortuusars.envelope.world.item.component.PaybackRequest;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_5536;
import net.minecraft.class_5632;
import net.minecraft.class_747;
import net.minecraft.world.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class PaybackTagItem extends class_1792 implements ApplicatorItem {
    public PaybackTagItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public @NotNull Optional<class_5632> method_32346(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS));
    }

    @Override
    public boolean method_31565(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player) {
        if (action != class_5536.field_27014) return false;
        if (!slot.method_32754(player)) return false;
        class_1799 target = slot.method_7677();
        if (!target.method_31573(Envelope.Tags.Items.MAILABLE)) return false;

        @Nullable PaybackRequest request = stack.method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS);
        @Nullable PaybackRequest currentRequest = target.method_57824(Envelope.DataComponents.MAIL_PAYBACK_REQUEST);

        if (request != null) {
            if (stack.method_7947() < target.method_7947()) {
                player.method_5783(class_3417.field_14624.comp_349(), 1, 1);
                return true;
            }

            if (request.equals(currentRequest)) {
                return true; // do nothing
            }
            target.method_57379(Envelope.DataComponents.MAIL_PAYBACK_REQUEST, request);
        } else {
            if (currentRequest == null) {
                return true; // do nothing
            }
            target.method_57381(Envelope.DataComponents.MAIL_PAYBACK_REQUEST);
        }

        slot.method_7668();
        if (request != null) {
            stack.method_7934(target.method_7947());
        }
        player.method_5783(class_3417.field_14883.comp_349(), 1, 1);
        return true;
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_2680 state = context.method_8045().method_8320(context.method_8037());
        if (state.method_26204() instanceof PigeonholeBlock) {
            return class_1269.field_5814;
        }

        return super.method_7884(context);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (player.method_21823()) {
            @Nullable PaybackRequest removedRequest = player.method_5998(hand).method_57381(Envelope.DataComponents.PAYBACK_TAG_CONTENTS);
            if (removedRequest != null) {
                player.method_5783(class_3417.field_14883.comp_349(), 1, 1);
                return class_1271.method_29237(player.method_5998(hand), level.method_8608());
            }
        }

        if (player instanceof class_3222 serverPlayer) {
            Platform.openMenu(
                  serverPlayer,
                  new class_747((id, inventory, pl) ->
                        new PaybackTagMenu(id, inventory, hand), class_2561.method_43471("container.envelope.payback_tag")),
                  buffer -> buffer.method_10817(hand));
            player.method_7357().method_7906(this, 3);
        }

        return class_1271.method_29237(player.method_5998(hand), level.method_8608());
    }

    @Override
    public boolean shouldRenderTooltipWhileCarrying(class_1937 level, class_1799 carried, class_1799 hovered) {
        return true;
    }
}