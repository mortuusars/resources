package io.github.mortuusars.envelope.mixin.injected;

import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.MailServiceHolder;
import net.minecraft.class_1937;
import net.minecraft.class_2874;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_3695;
import net.minecraft.class_3949;
import net.minecraft.class_5268;
import net.minecraft.class_5269;
import net.minecraft.class_5304;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_8565;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

@Mixin(class_3218.class)
public abstract class ServerLevelMixin extends class_1937 implements MailServiceHolder {
    @Shadow
    public abstract @NotNull MinecraftServer method_8503();

    @Unique
    private MailService envelope$mailService;

    protected ServerLevelMixin(class_5269 levelData, class_5321<class_1937> dimension,
                               class_5455 registryAccess, class_6880<class_2874> dimensionTypeRegistration,
                               Supplier<class_3695> profiler, boolean isClientSide, boolean isDebug,
                               long biomeZoomSeed, int maxChainedNeighborUpdates) {
        super(levelData, dimension, registryAccess, dimensionTypeRegistration, profiler,
              isClientSide, isDebug, biomeZoomSeed, maxChainedNeighborUpdates);
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInit(MinecraftServer server, Executor dispatcher, class_32.class_5143 levelStorageAccess,
                        class_5268 serverLevelData, class_5321<class_1937> dimension, class_5363 levelStem,
                        class_3949 progressListener, boolean isDebug, long biomeZoomSeed,
                        List<class_5304> customSpawners, boolean tickTime, class_8565 randomSequences, CallbackInfo ci) {
        if (method_27983() == field_25179) { // Mail works only in overworld, hence why it's only instantiated on it.
            envelope$mailService = MailService.create((class_3218) (Object) this);
        }
    }

    @SuppressWarnings("AddedMixinMembersNamePattern") // Probability of name collision is close to zero.
    @Override
    public @NotNull MailService getEnvelopeMailService() {
        if (method_27983() != field_25179) {
            return method_8503().method_30002().getEnvelopeMailService();
        }
        return Objects.requireNonNull(envelope$mailService, "Attempting to get MailService too early.");
    }

    @Inject(method = "tick", at = @At(value = "RETURN"))
    private void onTick(BooleanSupplier hasTimeLeft, CallbackInfo ci) {
        if (envelope$mailService != null) {
            method_16107().method_15405("envelope_mail_service");
            envelope$mailService.tick();
        }
    }
}