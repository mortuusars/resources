package io.github.mortuusars.envelope.mixin.predators;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import net.minecraft.class_1299;
import net.minecraft.class_1400;
import net.minecraft.class_1429;
import net.minecraft.class_1937;
import net.minecraft.class_4019;
import net.minecraft.world.entity.animal.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4019.class)
public abstract class FoxMixin extends class_1429 {
    protected FoxMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "registerGoals", at = @At("RETURN"))
    private void registerGoals(CallbackInfo ci) {
        this.field_6185.method_6277(4, new class_1400<>((class_4019) (Object) this, Pigeon.class, 10,
              false, false, entity -> Config.Server.PIGEON_HUNTED_BY_FOX.get()));
    }
}
