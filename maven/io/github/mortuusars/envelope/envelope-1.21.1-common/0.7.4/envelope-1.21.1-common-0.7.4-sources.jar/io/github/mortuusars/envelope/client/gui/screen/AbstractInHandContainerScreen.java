package io.github.mortuusars.envelope.client.gui.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.envelope.world.inventory.AbstractInHandContainerMenu;
import io.github.mortuusars.envelope.world.inventory.slot.DisabledSlot;
import io.github.mortuusars.envelope.world.inventory.slot.PickupOnlySlot;
import io.github.mortuusars.envelope.world.inventory.slot.PreviewSlot;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class AbstractInHandContainerScreen<T extends AbstractInHandContainerMenu> extends class_465<T> {
    private final class_2960 texture;

    public AbstractInHandContainerScreen(T menu, class_1661 playerInventory, class_2561 title, class_2960 texture) {
        super(menu, playerInventory, title);
        this.texture = texture;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25270 = field_2779 - 94;
    }

    public int getLeftPos() {
        return field_2776;
    }

    public int getTopPos() {
        return field_2800;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        method_2380(guiGraphics, mouseX, mouseY);
    }

    protected void updateButtons() {

    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        guiGraphics.method_25302(texture, field_2776, field_2800, 0, 0, field_2792, field_2779);
    }

    @Override
    protected void method_2385(class_332 guiGraphics, class_1735 slot) {
        super.method_2385(guiGraphics, slot);
        renderSlotOverlays(guiGraphics, slot);
    }

    protected void renderSlotOverlays(class_332 guiGraphics, class_1735 slot) {
        if (slot instanceof PreviewSlot) {
            guiGraphics.method_51448().method_22903();
            guiGraphics.method_51448().method_46416(0, 0, 300);
            RenderSystem.enableBlend();
            guiGraphics.method_52706(PreviewSlot.OVERLAY_SPRITE, slot.field_7873 - 1, slot.field_7872 - 1, 18, 18);
            RenderSystem.disableBlend();
            guiGraphics.method_51448().method_22909();
        } else if (shouldRenderDisabledOverlayOver(slot)) {
            guiGraphics.method_51448().method_22903();
            guiGraphics.method_51448().method_46416(0, 0, 300);
            RenderSystem.enableBlend();
            guiGraphics.method_52706(DisabledSlot.OVERLAY_SPRITE, slot.field_7873 - 1, slot.field_7872 - 1, 18, 18);
            RenderSystem.disableBlend();
            guiGraphics.method_51448().method_22909();
        }
    }

    protected boolean shouldRenderDisabledOverlayOver(class_1735 slot) {
        return slot instanceof DisabledSlot
              || slot instanceof PickupOnlySlot && !slot.method_7681()
              || (!slot.method_7681() && !slot.method_7674(method_17577().getPlayer()));
    }
}
