package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlockEntity;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.entity.ai.MailboxHandler;
import net.minecraft.class_11;
import net.minecraft.class_2338;
import org.jetbrains.annotations.Nullable;

public class PigeonGoToMailboxGoal extends AbstractGoToBlockGoal {
    @Nullable
    protected class_11 lastPath;

    public PigeonGoToMailboxGoal(Pigeon pigeon) {
        super(pigeon);
    }

    @Override
    public @Nullable class_2338 getBlockPos() {
        return pigeon.getMailboxHandler().getTargetPos();
    }

    @Override
    public boolean method_6264() {
        return !pigeon.isDelivering()
              && pigeon.canStartDelivery()
              && super.method_6264()
              && pigeon.method_37908().method_8321(getBlockPos()) instanceof MailboxBlockEntity blockEntity
              && blockEntity.isAvailableForPickup();
    }

    @Override
    public void method_6268() {
        MailboxHandler handler = pigeon.getMailboxHandler();

        if (handler.getTargetPos() == null) return;

        travellingTicks++;
        if (travellingTicks > method_38847(MAX_TRAVELLING_TICKS)) {
            handler.dropAndBlacklistMailbox();
            return;
        }

        if (pigeon.method_5942().method_23966()) {
            return;
        }

        if (!pigeon.closerThan(handler.getTargetPos(), 16)) {
            if (handler.getTargetPos() != null
                  && Position.distanceToSqr(pigeon.method_37908(), handler.getTargetPos(), pigeon.method_19538()) > 32 * 32) {
                handler.dropMailbox();
            } else {
                pigeon.pathfindRandomlyTowards(handler.getTargetPos());
            }
        } else {
            boolean canReach = pigeon.pathfindDirectlyTowards(handler.getTargetPos());
            if (!canReach) {
                handler.dropAndBlacklistMailbox();
            } else if (lastPath != null && lastPath.method_41(pigeon.method_5942().method_6345())) {
                ticksStuck++;
                if (ticksStuck > TICKS_BEFORE_DROP) {
                    handler.dropMailbox();
                    ticksStuck = 0;
                }
            } else {
                lastPath = pigeon.method_5942().method_6345();
            }
        }
    }
}
