package io.github.mortuusars.envelope.client.gui.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.gui.Sprites;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.world.inventory.PaybackPackingMenu;
import io.github.mortuusars.envelope.world.inventory.slot.PreviewSlot;
import io.github.mortuusars.envelope.world.inventory.slot.RequestedItemSlot;
import io.github.mortuusars.envelope.world.item.PaybackPackageItem;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_7919;
import net.minecraft.class_8666;

public class PaybackPackingScreen extends AbstractInHandContainerScreen<PaybackPackingMenu> {
    public static final class_2960 TEXTURE = Envelope.resource("textures/gui/payback_packing.png");
    public static final class_8666 PACK_BUTTON_SPRITES = Sprites.threeStates(Envelope.resource("packing/payback_pack_button"));

    protected class_344 packButton;

    public PaybackPackingScreen(PaybackPackingMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title, TEXTURE);
    }

    @Override
    protected void method_25426() {
        field_2792 = 176;
        field_2779 = 178;
        super.method_25426();

        packButton = new class_344(field_2776 + 126, field_2800 + 40, 26, 20,
              PACK_BUTTON_SPRITES,
              button -> pack(),
              class_2561.method_43471("gui.envelope.packing.pack"));
        packButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.envelope.packing.pack")));
        method_37063(packButton);
    }

    protected void pack() {
        method_17577().method_7604(method_17577().getPlayer(), PaybackPackingMenu.PACK_BUTTON_ID);
        Minecrft.gameMode().method_2900(method_17577().field_7763, PaybackPackingMenu.PACK_BUTTON_ID);
        method_25419();
    }

    @Override
    protected void updateButtons() {
        packButton.field_22763 = !method_17577().isPacked();
        packButton.field_22764 = method_17577().canPack();
    }

    @Override
    protected void method_2385(class_332 guiGraphics, class_1735 slot) {
        if (slot instanceof RequestedItemSlot requestedItemSlot) {
            if (!slot.method_7681()) {
                class_1799 preview = requestedItemSlot.getIngredient().getRollingDisplayedStack();
                guiGraphics.method_51448().method_22903();
                guiGraphics.method_51448().method_46416(0, 0, -100);
                guiGraphics.method_51427(preview, slot.field_7873, slot.field_7872);
                guiGraphics.method_51431(Minecrft.get().field_1772, preview, slot.field_7873, slot.field_7872);
                if (requestedItemSlot.getIngredient().items().method_45925().isPresent()) {
                    guiGraphics.method_51448().method_46416(0, 0, 200);
                    guiGraphics.method_51433(field_22793, "#", slot.field_7873 + 1 + 19 - 2 - field_22793.method_1727("#"), slot.field_7872 - 1, Colors.WHITE, true);
                }
                guiGraphics.method_51448().method_22909();
            }

            boolean isFulfilled = requestedItemSlot.getIngredient().test(slot.method_7677());

            guiGraphics.method_51448().method_22903();
            guiGraphics.method_51448().method_46416(0, 0, 150);
            RenderSystem.enableBlend();
            guiGraphics.method_25302(TEXTURE, slot.field_7873 - 1, slot.field_7872 - 1, 176, isFulfilled ? 18 : 0, 18, 18);
            RenderSystem.disableBlend();
            guiGraphics.method_51448().method_22909();
        }

        super.method_2385(guiGraphics, slot);
    }

    @Override
    protected void method_2380(class_332 guiGraphics, int x, int y) {
        if (field_2797.method_34255().method_7960() && field_2787 instanceof RequestedItemSlot requestedItemSlot && !requestedItemSlot.method_7681()) {
            class_1799 stack = requestedItemSlot.getRequestedItemPreview();

            List<class_2561> lines = requestedItemSlot.getIngredient().items().method_45925()
                  .map(tag -> {
                      List<class_2561> list = new ArrayList<>(method_51454(stack));
                      list.addLast(class_2561.method_43470("Accepts Tag:").method_27692(class_124.field_1080));
                      list.addLast(class_2561.method_43470("#" + tag.comp_327()).method_27692(class_124.field_1080));
                      return list;
                  })
                  .orElseGet(() -> method_51454(stack));

            guiGraphics.method_51437(this.field_22793, lines, stack.method_32347(), x, y);
        } else {
            super.method_2380(guiGraphics, x, y);
        }
    }

    @Override
    protected @NotNull List<class_2561> method_51454(class_1799 stack) {
        List<class_2561> components = super.method_51454(stack);

        if (field_2787 instanceof PreviewSlot) {
            PaybackPackageItem.appendPaybackSubjectHoverText(components, method_17577().getPaybackSubject());
        }

        return components;
    }
}
