package io.github.mortuusars.envelope.mixin.spawners;

import io.github.mortuusars.envelope.world.entity.spawner.BackgroundCourierSpawner;
import io.github.mortuusars.envelope.world.entity.spawner.FinishedBackgroundCourierSpawner;
import io.github.mortuusars.envelope.world.entity.spawner.DroppedMailSpawner;
import io.github.mortuusars.envelope.world.entity.spawner.Spawner;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import net.minecraft.class_1937;
import net.minecraft.class_2874;
import net.minecraft.class_3218;
import net.minecraft.class_3695;
import net.minecraft.class_5269;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6880;

@Mixin(class_3218.class)
public abstract class ServerLevelMixin extends class_1937 {
    @Unique
    private final List<Spawner> envelope$spawners = List.of(
          new BackgroundCourierSpawner(),
          new FinishedBackgroundCourierSpawner(),
          new DroppedMailSpawner()
    );

    protected ServerLevelMixin(class_5269 levelData, class_5321<class_1937> dimension, class_5455 registryAccess,
                               class_6880<class_2874> dimensionTypeRegistration, Supplier<class_3695> profiler,
                               boolean isClientSide, boolean isDebug, long biomeZoomSeed, int maxChainedNeighborUpdates) {
        super(levelData, dimension, registryAccess, dimensionTypeRegistration, profiler,
              isClientSide, isDebug, biomeZoomSeed, maxChainedNeighborUpdates);
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void onTick(BooleanSupplier hasTimeLeft, CallbackInfo ci) {
        envelope$spawners.forEach(spawner -> spawner.tick((class_3218) (Object) this));
    }
}
