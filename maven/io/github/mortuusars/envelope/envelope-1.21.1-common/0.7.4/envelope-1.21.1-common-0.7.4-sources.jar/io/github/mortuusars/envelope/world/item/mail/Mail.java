package io.github.mortuusars.envelope.world.item.mail;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.inventory.ContainerUtils;
import io.github.mortuusars.envelope.world.item.PackageItem;
import io.github.mortuusars.envelope.world.item.component.*;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryLog;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.mail.address.Address;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3902;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5536;
import net.minecraft.class_9297;
import net.minecraft.class_9334;

public final class Mail {
    private Mail() {
    }

    // -- Address

    public static Optional<Address> getSender(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.MAIL_SENDER));
    }

    public static @NotNull Address getSenderOrElse(class_1799 stack, Address orElse) {
        return stack.method_57825(Envelope.DataComponents.MAIL_SENDER, orElse);
    }

    public static @NotNull Address getSenderOrUnknown(class_1799 stack) {
        return getSenderOrElse(stack, Address.UNKNOWN);
    }

    public static void setSender(@NotNull class_1799 stack, @Nullable Address sender) {
        stack.method_57379(Envelope.DataComponents.MAIL_SENDER, sender);
    }

    public static Optional<Address> getRecipient(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.MAIL_RECIPIENT));
    }

    public static @NotNull Address getRecipientOrElse(class_1799 stack, Address orElse) {
        return stack.method_57825(Envelope.DataComponents.MAIL_RECIPIENT, orElse);
    }

    public static @NotNull Address getRecipientOrUnknown(class_1799 stack) {
        return getRecipientOrElse(stack, Address.UNKNOWN);
    }

    public static class_1799 setRecipient(@NotNull class_1799 stack, @Nullable Address recipient) {
        stack.method_57379(Envelope.DataComponents.MAIL_RECIPIENT, recipient);
        return stack;
    }

    // -- Id

    public static boolean hasId(class_1799 stack) {
        return stack.method_57826(Envelope.DataComponents.MAIL_ID);
    }

    public static @Nullable Id getId(class_1799 stack) {
        return stack.method_57824(Envelope.DataComponents.MAIL_ID);
    }

    public static Id getOrCreateId(class_1799 stack, class_1937 level) {
        return stack.method_57368(Envelope.DataComponents.MAIL_ID, Id.create(level), UnaryOperator.identity());
    }

    public static class_1799 setId(class_1799 stack, Id id) {
        stack.method_57379(Envelope.DataComponents.MAIL_ID, id);
        return stack;
    }

    // -- Payback

    public static class_1799 setPaybackRequest(@NotNull class_1799 stack, @Nullable PaybackRequest request) {
        stack.method_57379(Envelope.DataComponents.MAIL_PAYBACK_REQUEST, request);
        return stack;
    }

    // -- Returned

    public static boolean isReturned(class_1799 stack) {
        return stack.method_57826(Envelope.DataComponents.MAIL_RETURNED);
    }

    public static class_1799 setReturned(class_1799 stack, boolean returned) {
        stack.method_57379(Envelope.DataComponents.MAIL_RETURNED, returned ? class_3902.field_17274 : null);
        return stack;
    }

    public static class_1799 setReturned(class_1799 stack) {
        return setReturned(stack, true);
    }

    public static class_1799 returned(class_1799 mail, class_2561 message) {
        if (mail.method_7960()) {
            return mail;
        }
        writeToLog(mail, DeliveryRecord.returned(message));
        setReturned(mail);
        return mail;
    }

    // -- Log

    public static DeliveryLog getLog(class_1799 stack) {
        return stack.method_57825(Envelope.DataComponents.MAIL_DELIVERY_LOG, DeliveryLog.EMPTY);
    }

    public static class_1799 setLog(class_1799 stack, DeliveryLog log) {
        stack.method_57379(Envelope.DataComponents.MAIL_DELIVERY_LOG, log);
        return stack;
    }

    public static class_1799 writeToLog(class_1799 stack, DeliveryRecord record) {
        stack.method_57368(Envelope.DataComponents.MAIL_DELIVERY_LOG, DeliveryLog.EMPTY, log -> log.append(record));
        return stack;
    }

    public static class_1799 writeToLog(class_1799 stack, DeliveryRecord... records) {
        stack.method_57368(Envelope.DataComponents.MAIL_DELIVERY_LOG, DeliveryLog.EMPTY, log -> log.append(records));
        return stack;
    }

    // --

    public static class_1799 removePreviousDeliveryData(class_1799 mail) {
        if (mail.method_7960()) return class_1799.field_8037;

        mail.method_57381(Envelope.DataComponents.MAIL_ID);
        mail.method_57381(Envelope.DataComponents.MAIL_SENDER);
        mail.method_57381(Envelope.DataComponents.MAIL_DELIVERY_LOG);
        mail.method_57381(Envelope.DataComponents.MAIL_RETURNED);

        return mail;
    }

    public static class_1799 removeAllDeliveryData(class_1799 mail) {
        if (mail.method_7960()) return class_1799.field_8037;

        mail.method_57381(Envelope.DataComponents.MAIL_RECIPIENT);
        mail.method_57381(Envelope.DataComponents.MAIL_PAYBACK_REQUEST);
        return removePreviousDeliveryData(mail);
    }

    public static class_1799 asDelivered(class_1799 mail) {
        if (mail.method_7960()) return class_1799.field_8037;

        if (!isReturned(mail)) {
            mail.method_57381(Envelope.DataComponents.MAIL_RECIPIENT);
            mail.method_57381(Envelope.DataComponents.MAIL_PAYBACK_REQUEST);
        }

        return mail;
    }

    // --

    public static MailBuilder<?> of(class_1799 stack) {
        return new MailBuilder<>(stack);
    }

    public static MailBuilder<?> createLetter(class_2561 text) {
        return new MailBuilder<>(Envelope.Items.LETTER.get())
              .set(Envelope.DataComponents.LETTER_CONTENT, new LetterContent(text));
    }

    public static MailBuilder<?> createLetter(LetterContent content) {
        return new MailBuilder<>(Envelope.Items.LETTER.get())
              .set(Envelope.DataComponents.LETTER_CONTENT, content);
    }

    public static MailBuilder<?> createPackage(PackageContents contents) {
        return new MailBuilder<>(Envelope.Items.PACKAGE.get())
              .set(Envelope.DataComponents.PACKAGE_CONTENTS, contents);
    }

    public static MailBuilder<?> createPackage(class_5321<class_52> lootTable) {
        return new MailBuilder<>(Envelope.Items.PACKAGE.get())
              .set(class_9334.field_49626, new class_9297(lootTable, 0L));
    }

    /**
     * Splits items into packages, however many are required to fit all items.
     *
     * @param builder callback for each package builder, allows setting necessary data for each created package.
     */
    public static List<class_1799> createPackages(List<class_1799> items, Consumer<MailBuilder<?>> builder) {
        items = new ArrayList<>(items.stream().filter(stack -> !stack.method_7960()).toList()); // Non-empty and ensure mutability
        if (items.isEmpty()) return List.of();

        // Separate items that are already a package:
        List<class_1799> packages = new ArrayList<>();
        items.removeIf(stack -> {
            if (stack.method_7909() instanceof PackageItem) {
                packages.add(Mail.of(stack).apply(builder).get());
                return true;
            }
            return false;
        });

        List<class_1799> packedPackages = ContainerUtils.split(ContainerUtils.compact(items), PackageContents.SLOTS)
              .stream()
              .map(PackageContents::new)
              .map(contents -> Mail.createPackage(contents).apply(builder).get())
              .toList();

        return Stream.concat(packages.stream(), packedPackages.stream()).toList();

//        Container container = ContainerUtils.compact(items);
//
//        for (int i = 0; i < container.getContainerSize(); i += PackageContents.SLOTS) {
//            List<ItemStack> contents = new ArrayList<>();
//            for (int slot = 0; slot < PackageContents.SLOTS; slot++) {
//                int index = i + slot;
//                contents.add()
//
//            }
//
//            ItemStack stack = container.getItem(i);
//
//
//        }
//
//
//        SimpleContainer container = new SimpleContainer(PackageContents.SLOTS);
//
//        while (!items.isEmpty()) {
//            SimpleContainer finalContainer = container;
//
//            items.removeIf(stack -> {
//                if (stack.getItem() instanceof PackageItem) {
//                    packages.add(Mail.of(stack).apply(builder).get());
//                    return true;
//                }
//                return finalContainer.addItem(stack).isEmpty();
//            });
//
//            if (!container.isEmpty()) {
//                ItemStack pkg = Mail.createPackage(new PackageContents(container)).apply(builder).get();
//                packages.add(pkg);
//                container = new SimpleContainer(PackageContents.SLOTS);
//            }
//        }

//        return packages;
    }

    public static MailBuilder<?> createPaybackBox(PaybackSubject subject) {
        return new MailBuilder<>(Envelope.Items.PAYBACK_BOX.get())
              .set(Envelope.DataComponents.PAYBACK_SUBJECT, subject);
    }

    // --

    public static boolean handleShearsUse(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player) {
        if (action != class_5536.field_27014) return false;
        if (!slot.method_32754(player)) return false;
        if (!slot.method_7677().method_31573(Envelope.Tags.Items.MAILABLE)) return false;

        class_1799 result = removePreviousDeliveryData(slot.method_7677().method_7972());

        if (!class_1799.method_31577(slot.method_7677(), result)) {
            slot.method_53512(result);
            stack.method_7970(1, player, class_1304.field_6173);
            player.method_5783(class_3417.field_14975, 0.75f, 1f);
        } else {
            player.method_5783(class_3417.field_14762, 0.75f, 1f);
        }

        return true;
    }
}
