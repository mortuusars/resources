package io.github.mortuusars.envelope.world.item.component.mail.log;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import io.github.mortuusars.envelope.Platform;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.world.GameTime;
import io.github.mortuusars.envelope.world.item.component.mail.log.record.ArrivedRecord;
import io.github.mortuusars.envelope.world.item.component.mail.log.record.MessageRecord;
import io.github.mortuusars.envelope.world.item.component.mail.log.record.ReturnedRecord;
import io.github.mortuusars.envelope.world.item.component.mail.log.record.SentRecord;
import io.github.mortuusars.envelope.world.mail.address.Address;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3542;
import net.minecraft.class_5250;
import net.minecraft.class_7995;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;
import java.util.function.IntFunction;

public interface DeliveryRecord {
    Codec<DeliveryRecord> CODEC = DeliveryRecord.Type.CODEC.dispatch(DeliveryRecord::getType, DeliveryRecord.Type::getCodec);
    class_9139<class_9129, DeliveryRecord> STREAM_CODEC = DeliveryRecord.Type.STREAM_CODEC.method_56440(DeliveryRecord::getType, DeliveryRecord.Type::getStreamCodec);

    DeliveryRecord.Type getType();

    class_5250 getDisplayComponent();

    default Optional<class_2561> getElapsedTime(long timestamp) {
        if (timestamp <= 0) return Optional.empty();
        return getCurrentGameTime().map(time -> GameTime.formatLargest(time - timestamp, false)
              .method_27692(class_124.field_1063));
    }

    // --

    static DeliveryRecord sentFrom(Address address, long timestamp) {
        return new SentRecord(Objects.requireNonNull(address), timestamp);
    }

    /**
     * Uses current server time as timestamp.
     */
    static DeliveryRecord sentFrom(Address address) {
        return new SentRecord(Objects.requireNonNull(address), getCurrentGameTime().orElse(-1L));
    }

    static DeliveryRecord arrivedTo(Address address, long timestamp) {
        return new ArrivedRecord(Objects.requireNonNull(address), timestamp);
    }

    /**
     * Uses current server time as timestamp.
     */
    static DeliveryRecord arrivedTo(Address address) {
        return new ArrivedRecord(Objects.requireNonNull(address), getCurrentGameTime().orElse(-1L));
    }

    static DeliveryRecord returned(class_2561 message) {
        return new ReturnedRecord(Objects.requireNonNull(message));
    }

    static DeliveryRecord message(class_2561 message) {
        return new MessageRecord(Objects.requireNonNull(message));
    }

    // --

    static Optional<Long> getCurrentGameTime() {
        @Nullable MinecraftServer server = Platform.getCurrentServer();
        if (server == null) return Optional.empty();
        return Optional.of(server.method_30002().method_8510());
    }

    // --

    enum Type implements class_3542 {
        SENT("sent", SentRecord.CODEC, SentRecord.STREAM_CODEC),
        ARRIVED("arrived", ArrivedRecord.CODEC, ArrivedRecord.STREAM_CODEC),
        RETURNED("returned", ReturnedRecord.CODEC, ReturnedRecord.STREAM_CODEC),
        MESSAGE("message", MessageRecord.CODEC, MessageRecord.STREAM_CODEC);

        public static final Codec<DeliveryRecord.Type> CODEC = class_3542.method_28140(DeliveryRecord.Type::values);
        public static final IntFunction<DeliveryRecord.Type> BY_ID = class_7995.method_47914(DeliveryRecord.Type::ordinal, values(), class_7995.class_7996.field_41664);
        public static final class_9139<class_9129, DeliveryRecord.Type> STREAM_CODEC = class_9135.method_56375(BY_ID, DeliveryRecord.Type::ordinal).method_56430();

        private final String name;
        private final MapCodec<? extends DeliveryRecord> codec;
        private final class_9139<class_9129, ? extends DeliveryRecord> streamCodec;

        Type(String name, MapCodec<? extends DeliveryRecord> codec, class_9139<class_9129, ? extends DeliveryRecord> streamCodec) {
            this.name = name;
            this.codec = codec;
            this.streamCodec = streamCodec;
        }

        @Override
        public @NotNull String method_15434() {
            return name;
        }

        public MapCodec<? extends DeliveryRecord> getCodec() {
            return codec;
        }

        public class_9139<class_9129, ? extends DeliveryRecord> getStreamCodec() {
            return streamCodec;
        }
    }

    interface Message {
        class_2561 RECIPIENT_NOT_FOUND = class_2561.method_43471("gui.envelope.delivery_log.message.recipient_not_found").method_54663(Colors.TOOLTIP_RED);
        class_2561 RECIPIENT_IS_UNKNOWN = class_2561.method_43471("gui.envelope.delivery_log.message.recipient_unknown").method_54663(Colors.TOOLTIP_RED);
        class_2561 RECIPIENT_INBOX_IS_FULL = class_2561.method_43471("gui.envelope.delivery_log.message.recipient_inbox_is_full").method_54663(Colors.TOOLTIP_RED);
        class_2561 UNABLE_TO_REACH = class_2561.method_43471("gui.envelope.delivery_log.message.unable_to_reach").method_54663(Colors.TOOLTIP_RED);
        class_2561 REJECTED = class_2561.method_43471("gui.envelope.delivery_log.message.rejected").method_54663(Colors.TOOLTIP_RED);

        class_2561 PAYBACK_FULFILLED = class_2561.method_43471("gui.envelope.delivery_log.message.payback_fulfilled").method_54663(Colors.TOOLTIP_GREEN);
        class_2561 PAYBACK_SUBJECT_NOT_FOUND = class_2561.method_43471("gui.envelope.delivery_log.message.payback.subject_not_found").method_54663(Colors.TOOLTIP_RED);
        class_2561 PAYBACK_IS_NOT_VALID = class_2561.method_43471("gui.envelope.delivery_log.message.payback.is_not_valid").method_54663(Colors.TOOLTIP_RED);
        class_2561 PAYBACK_EXPIRED = class_2561.method_43471("gui.envelope.delivery_log.message.payback.expired").method_54663(Colors.TOOLTIP_RED);
        class_2561 PAYBACK_CANCELED = class_2561.method_43471("gui.envelope.delivery_log.message.payback.canceled").method_54663(Colors.TOOLTIP_RED);

        class_2561 CRAFTING_UNPROCESSED_ITEMS = class_2561.method_43471("gui.envelope.delivery_log.message.crafting.unprocessed_items").method_54663(Colors.TOOLTIP_RED);
        class_2561 CRAFTING_UNABLE_TO_PROCESS = class_2561.method_43471("gui.envelope.delivery_log.message.crafting.unable_to_process").method_54663(Colors.TOOLTIP_RED);
    }
}