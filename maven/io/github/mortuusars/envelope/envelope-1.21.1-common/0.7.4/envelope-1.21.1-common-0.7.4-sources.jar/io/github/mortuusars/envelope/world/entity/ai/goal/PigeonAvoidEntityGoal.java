package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.world.entity.Pigeon;
import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1338;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4051;
import net.minecraft.class_5493;
import net.minecraft.class_5530;
import net.minecraft.class_5532;
import net.minecraft.class_5535;

public class PigeonAvoidEntityGoal<T extends class_1309> extends class_1338<T> {
    private final Pigeon pigeon;
    private final class_4051 targetingConditions;

    public PigeonAvoidEntityGoal(Pigeon pigeon, Class<T> entityClassToAvoid, float maxDistance, double walkSpeedModifier,
                                 double sprintSpeedModifier, Predicate<class_1309> predicateOnAvoidEntity) {
        super(pigeon, entityClassToAvoid, maxDistance, walkSpeedModifier, sprintSpeedModifier, predicateOnAvoidEntity);
        this.pigeon = pigeon;
        this.targetingConditions = class_4051.method_36625().method_18418(maxDistance).method_18420(predicateOnAvoidEntity.and(field_6393));
    }

    public boolean isAvoiding() {
        return field_6390 != null;
    }

    @Override
    public boolean method_6264() {
        // Add some delay, or else pigeon is too good at avoiding
        if (pigeon.method_59922().method_43048(6) != 0) {
            return false;
        }

        field_6390 = pigeon.method_37908().method_18468(
              pigeon.method_37908().method_8390(field_6392, pigeon.method_5829().method_1009(field_6386, field_6386, field_6386), entity -> true),
              targetingConditions, pigeon, pigeon.method_23317(), pigeon.method_23318(), pigeon.method_23321()
        );

        if (field_6390 == null) {
            return false;
        }

        class_243 pos = class_5532.method_31511(pigeon, 14, 8, field_6390.method_19538());

        if (pos == null) {
            return false;
        } else if (field_6390.method_5649(pos.field_1352, pos.field_1351, pos.field_1350) < field_6390.method_5858(pigeon)) {
            return false;
        } else {
            field_6387 = field_6394.method_6352(pos.field_1352, pos.field_1351, pos.field_1350, 0);
            return field_6387 != null;
        }
    }

    @Nullable
    public static class_243 getPosAway(class_1314 mob, int radius, int yRange, class_243 vectorPosition) {
        class_243 awayVector = mob.method_19538().method_1020(vectorPosition);
        boolean isWithinRestriction = class_5493.method_31517(mob, radius);
        return class_5535.method_31538(mob, () -> {
            class_2338 blockPos = class_5530.method_31505(mob, radius, yRange, 3, awayVector.field_1352, awayVector.field_1350, 1, isWithinRestriction);
            return blockPos != null && !class_5493.method_31518(mob, blockPos) ? blockPos : null;
        });
    }
}