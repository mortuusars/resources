package io.github.mortuusars.envelope.world.inventory;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.inventory.slot.DisabledSlot;
import io.github.mortuusars.envelope.world.inventory.slot.PreviewSlot;
import io.github.mortuusars.envelope.world.inventory.slot.RequestedItemSlot;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.component.PaybackRequest;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.item.component.PaybackSubject;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3917;
import net.minecraft.class_9129;

public class PaybackPackingMenu extends PackingMenu {
    protected PaybackSubject subject;
    protected PaybackRequest request;

    protected PaybackPackingMenu(@Nullable class_3917<?> menuType, int containerId, class_1661 playerInventory, class_1268 hand) {
        super(menuType, containerId, playerInventory, hand);
    }

    public PaybackPackingMenu(int containerId, class_1661 playerInventory, class_1268 hand) {
        this(Envelope.MenuTypes.PAYBACK_PACKING.get(), containerId, playerInventory, hand);
    }

    public static PaybackPackingMenu fromNetwork(int id, class_1661 inventory, class_9129 buffer) {
        return new PaybackPackingMenu(id, inventory, buffer.method_10818(class_1268.class));
    }

    // --

    public PaybackRequest getPaybackRequest() {
        return request;
    }

    public PaybackSubject getPaybackSubject() {
        return subject;
    }

    @Override
    public boolean canPack() {
        return super.canPack() && getPaybackRequest().matches(getContainer());
    }

    // --

    @Override
    protected void init() {
        this.subject = Objects.requireNonNull(getItemInHand().method_57824(Envelope.DataComponents.PAYBACK_SUBJECT),
              "Item in hand does not have 'envelope:payback_subject' component.");
        this.request = subject.getRequest();
        super.init();
        method_7621(new PreviewSlot(subject.mail(), 0, 19, 42));
    }

    @Override
    protected class_1735 createContainerSlot(int index, int x, int y) {
        return getPaybackRequest().getRequestedItem(index)
              .map(requestedItem -> (class_1735) new RequestedItemSlot(getContainer(), index, x, y, requestedItem))
              .orElseGet(() -> new DisabledSlot(getContainer(), index, x, y));
    }

    @Override
    protected @NotNull class_1799 createPackingResult() {
        class_1799 result = getItemInHand().method_60503(Envelope.Items.PAYBACK_PACKAGE.get());
        result.method_57379(Envelope.DataComponents.PACKAGE_CONTENTS, new PackageContents(getContainer()));
        Mail.removePreviousDeliveryData(result);
        Mail.setRecipient(result, getPaybackSubject().returnAddress());
        return result;
    }
}