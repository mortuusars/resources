package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.world.entity.Pigeon;
import net.minecraft.class_1352;

public class PigeonSitGoal extends class_1352 {
    private final Pigeon pigeon;
    private int time;
    private long cooldownUntil;

    public PigeonSitGoal(Pigeon pigeon) {
        this.pigeon = pigeon;
    }

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public boolean method_6264() {
        return !pigeon.isDelivering()
              && pigeon.isTired() && pigeon.getTiredTicks() > 100
              && !pigeon.method_52546()
              && pigeon.method_24828()
              && pigeon.method_37908().method_8510() >= cooldownUntil
              && pigeon.method_59922().method_43048(20) == 0;
    }

    @Override
    public boolean method_6266() {
        return pigeon.isTired() && pigeon.isSitting() && time < 600;
    }

    @Override
    public void method_6269() {
        pigeon.setSitting(true);
        time = 0;
    }

    @Override
    public void method_6270() {
        pigeon.setSitting(false);
        cooldownUntil = pigeon.method_37908().method_8510() + 100;
    }

    @Override
    public void method_6268() {
        if (pigeon.isSitting()) {
            time++;
        }
    }
}
