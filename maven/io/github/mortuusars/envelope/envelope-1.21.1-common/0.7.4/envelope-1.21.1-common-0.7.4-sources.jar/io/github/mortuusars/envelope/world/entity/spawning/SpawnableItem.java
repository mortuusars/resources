package io.github.mortuusars.envelope.world.entity.spawning;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1799;
import net.minecraft.class_2338;

public record SpawnableItem(class_1799 item, class_2338 pos) {
    public static final Codec<SpawnableItem> CODEC = RecordCodecBuilder.create(i -> i.group(
          class_1799.field_24671.fieldOf("item").forGetter(SpawnableItem::item),
          class_2338.field_25064.fieldOf("pos").forGetter(SpawnableItem::pos)
    ).apply(i, SpawnableItem::new));
}
