package io.github.mortuusars.envelope.world.item;

import net.minecraft.class_1799;
import net.minecraft.class_1937;

public interface ApplicatorItem {
    boolean shouldRenderTooltipWhileCarrying(class_1937 level, class_1799 carried, class_1799 hovered);
}
