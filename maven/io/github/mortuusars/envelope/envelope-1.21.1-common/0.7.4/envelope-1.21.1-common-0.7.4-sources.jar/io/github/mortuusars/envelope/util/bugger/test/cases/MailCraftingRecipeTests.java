package io.github.mortuusars.envelope.util.bugger.test.cases;

import io.github.mortuusars.envelope.util.bugger.test.BuggerTests;
import io.github.mortuusars.envelope.util.bugger.test.Test;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailCraftingRecipe;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailRecipeInput;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.Address;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2371;
import net.minecraft.server.MinecraftServer;
import java.util.Arrays;

public class MailCraftingRecipeTests extends BuggerTests {
    private final MinecraftServer server;

    public MailCraftingRecipeTests(MinecraftServer server) {
        this.server = server;
        matching();
    }

    private void matching() {
        add("MailCraftingRecipe_MatchesIfCorrect", Test.isTrue(() -> matches(
              recipe(
                    class_1856.method_8091(class_1802.field_8687),
                    class_1856.method_8091(class_1802.field_8477)
              ),
              input(
                    new class_1799(class_1802.field_8687, 2),
                    new class_1799(class_1802.field_8477, 6)
              ))));

        add("MailCraftingRecipe_MatchesIfCorrectMultipleOfSame", Test.isTrue(() -> matches(
              recipe(
                    class_1856.method_8091(class_1802.field_8687),
                    class_1856.method_8091(class_1802.field_8477),
                    class_1856.method_8091(class_1802.field_8477),
                    class_1856.method_8091(class_1802.field_27022)
              ),
              input(
                    new class_1799(class_1802.field_8687, 2),
                    new class_1799(class_1802.field_8477, 6),
                    new class_1799(class_1802.field_8477, 6),
                    new class_1799(class_1802.field_27022, 6)
              ))));

        add("MailCraftingRecipe_MatchesIfMore", Test.isTrue(() -> matches(
              recipe(
                    class_1856.method_8091(class_1802.field_8687),
                    class_1856.method_8091(class_1802.field_8477)
              ),
              input(
                    new class_1799(class_1802.field_8687, 30),
                    new class_1799(class_1802.field_8477, 30)
              )
        )));

        add("MailCraftingRecipe_MatchesIfMoreMultipleOfSame", Test.isTrue(() -> matches(
              recipe(
                    class_1856.method_8091(class_1802.field_8687),
                    class_1856.method_8091(class_1802.field_8477),
                    class_1856.method_8091(class_1802.field_8477),
                    class_1856.method_8091(class_1802.field_27022)
              ),
              input(
                    new class_1799(class_1802.field_8687, 30),
                    new class_1799(class_1802.field_8477, 30),
                    new class_1799(class_1802.field_8477, 30),
                    new class_1799(class_1802.field_27022, 30)
              ))));

        add("MailCraftingRecipe_MatchesWhenOutOfOrder", Test.isTrue(() -> matches(
              recipe(
                    class_1856.method_8091(class_1802.field_8687),
                    class_1856.method_8091(class_1802.field_8477),
                    class_1856.method_8091(class_1802.field_8477),
                    class_1856.method_8091(class_1802.field_27022)
              ),
              input(
                    new class_1799(class_1802.field_27022, 30),
                    new class_1799(class_1802.field_8477, 30),
                    new class_1799(class_1802.field_8687, 30),
                    new class_1799(class_1802.field_8477, 30)
              ))));

        add("MailCraftingRecipe_MatchesWithEmptyItems", Test.isTrue(() -> matches(
              recipe(
                    class_1856.method_8091(class_1802.field_8687),
                    class_1856.method_8091(class_1802.field_8477)
              ),
              input(
                    class_1799.field_8037,
                    class_1799.field_8037,
                    new class_1799(class_1802.field_8477, 6),
                    new class_1799(class_1802.field_8687, 2),
                    class_1799.field_8037
              )
        )));

        // --

        add("MailCraftingRecipe_Matching_FailsIfInputEmpty", Test.isFalse(() -> matches(
              recipe(
                    class_1856.method_8091(class_1802.field_8687),
                    class_1856.method_8091(class_1802.field_8477)
              ),
              input(
                    class_1799.field_8037,
                    class_1799.field_8037
              )
        )));

        add("MailCraftingRecipe_Matching_FailsIfNotEnough", Test.isFalse(() -> matches(
              recipe(
                    class_1856.method_8091(class_1802.field_8687),
                    class_1856.method_8091(class_1802.field_8477)
              ),
              input(
                    new class_1799(class_1802.field_8687, 2)
              )
        )));

        add("MailCraftingRecipe_Matching_FailsIfLessInputs", Test.isFalse(() -> matches(
              recipe(
                    class_1856.method_8091(class_1802.field_8687),
                    class_1856.method_8091(class_1802.field_8477),
                    class_1856.method_8091(class_1802.field_8094)
              ),
              input(
                    new class_1799(class_1802.field_8687, 2),
                    new class_1799(class_1802.field_8477, 1)
              )
        )));

        add("MailCraftingRecipe_Matching_FailsIfMoreInputs", Test.isFalse(() -> matches(
              recipe(
                    class_1856.method_8091(class_1802.field_8687),
                    class_1856.method_8091(class_1802.field_8477)
              ),
              input(
                    new class_1799(class_1802.field_8687, 2),
                    new class_1799(class_1802.field_8477, 1),
                    new class_1799(class_1802.field_8094)
              )
        )));

        add("MailCraftingRecipe_Matching_FailsIfMoreInputsOfCorrectItem", Test.isFalse(() ->
              matches(
                    recipe(
                          class_1856.method_8091(class_1802.field_8687),
                          class_1856.method_8091(class_1802.field_8477)
                    ),
                    input(
                          new class_1799(class_1802.field_8687, 2),
                          new class_1799(class_1802.field_8477, 6),
                          new class_1799(class_1802.field_8477, 3)
                    )
              )));
    }

    // --

    private MailCraftingRecipe recipe(class_1856... ingredients) {
        return new MailCraftingRecipe(
              MailService.of(server.method_30002()).getAddress(),
              class_2371.method_10212(class_1856.field_9017, ingredients),
              new class_1799(class_1802.field_8077),
              0);
    }

    private MailRecipeInput input(class_1799... items) {
        return new MailRecipeInput(server.method_30002().getEnvelopeMailService(), Address.UNKNOWN, Arrays.stream(items).toList());
    }

    private boolean matches(MailCraftingRecipe recipe, MailRecipeInput input) {
        return recipe.matches(input, server.method_30002());
    }
}
