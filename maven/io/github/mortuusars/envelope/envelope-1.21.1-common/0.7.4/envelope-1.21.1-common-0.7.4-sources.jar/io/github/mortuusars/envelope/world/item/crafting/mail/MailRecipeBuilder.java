package io.github.mortuusars.envelope.world.item.crafting.mail;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_8790;

public abstract class MailRecipeBuilder {
    private final ServiceAddress address;

    public MailRecipeBuilder(ServiceAddress address) {
        this.address = address;
    }

    public ServiceAddress getAddress() {
        return address;
    }

    public abstract class_1799 getResult();

    public abstract void save(class_8790 output, class_2960 id);

    public void save(class_8790 output, String name) {
        save(output, Envelope.resource(getDefaultPath(getAddress(), name)));
    }

    public void save(class_8790 output) {
        save(output, getDefaultRecipeName(getResult().method_7909()));
    }

    // --

    public static MailCraftingRecipeBuilder crafting(ServiceAddress address) {
        return new MailCraftingRecipeBuilder(address);
    }

    protected String getDefaultRecipeName(class_1935 itemLike) {
        return class_7923.field_41178.method_10221(itemLike.method_8389()).method_12832();
    }

    public static String getDefaultPath(ServiceAddress address, String name) {
        String addressStr = address.getDefinitionHolder().method_40230()
              .map(key -> key.method_29177().method_12832())
              .orElseThrow();
        return "mailing/" + addressStr + "/" + name;
    }
}
