package io.github.mortuusars.envelope.world;

import io.github.mortuusars.envelope.integration.sable.MovingStructureCompat;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2358;
import net.minecraft.class_243;
import net.minecraft.class_2902;
import net.minecraft.class_3218;

public class Position {
    public static class_243 lerp(class_2338 origin, class_2338 target, double delta) {
        double x = origin.method_10263() + (target.method_10263() - origin.method_10263()) * delta;
        double y = origin.method_10264() + (target.method_10264() - origin.method_10264()) * delta;
        double z = origin.method_10260() + (target.method_10260() - origin.method_10260()) * delta;
        return new class_243(x, y, z);
    }

    public static class_243 lerp(class_1937 level, class_2338 origin, class_2338 target, double delta) {
        return getGlobalCenter(level, origin).method_35590(getGlobalCenter(level, target), delta);
    }

    public static class_2338 snapToGrid(class_2338 pos, int size) {
        int x = Math.round(pos.method_10263() / (float) size) * size;
        int z = Math.round(pos.method_10260() / (float) size) * size;
        return new class_2338(x, pos.method_10264(), z);
    }

    public static class_2338 nearestHub(class_2338 pos) {
        return snapToGrid(pos, 1024).method_33096(500);
    }

    public static class_2338 towardsDirection(class_2338 origin, class_2338 target, double distance) {
        class_243 originVec = class_243.method_24953(origin);
        class_243 targetVec = class_243.method_24953(target);
        class_243 direction = targetVec.method_1020(originVec).method_1029();
        return class_2338.method_49638(originVec.method_1019(direction.method_1021(distance)));
    }

    public static class_2338 towardsHorizontalDirection(class_2338 origin, class_2338 target, double distance) {
        return towardsDirection(origin, target.method_33096(origin.method_10264()), distance);
    }

    public static class_2338 towardsRandomHorizontalDirection(class_2338 origin, int distance, int seed) {
        Random random = new Random(seed);
        random.nextLong(); // For some reason this fixes similar values returned for similar seeds. I'm not going to pretend I know why.
        double angle = random.nextDouble() * 2 * Math.PI;
        return origin.method_10069((int) (Math.cos(angle) * distance), 0, (int) (Math.sin(angle) * distance));
    }

    public static class_2338 ascendTowards(class_2338 origin, class_2338 target, int distance) {
        return Position.towardsHorizontalDirection(origin, target, distance)
              .method_10086(distance);
    }

    public static class_2338 ascendTowards(class_1937 level, class_2338 origin, Optional<class_2338> target, int distance, int seed) {
        class_2338 pos = target
              .map(recipientPos -> Position.towardsHorizontalDirection(origin, recipientPos, distance))
              .orElseGet(() -> Position.towardsRandomHorizontalDirection(origin, distance, seed))
              .method_10086(distance);

        return aboveGround(level, pos, 5);
    }

    public static Optional<class_2338> ascendTowards(class_1937 level, Optional<class_2338> origin,
                                                   Optional<class_2338> target, int distance, int seed) {
        return origin.map(pos -> ascendTowards(level, pos, target, distance, seed));
    }

    public static class_243 getGlobalCenter(class_1937 level, class_2338 localPos) {
        return MovingStructureCompat.getGlobalCenter(level, localPos);
    }

    public static class_2338 getNavigationPos(class_1937 level, class_2338 localPos) {
        return MovingStructureCompat.getNavigationPos(level, localPos);
    }

    public static double distanceToSqr(class_1937 level, class_2338 localPos, class_243 entityPos) {
        return getGlobalCenter(level, localPos).method_1025(entityPos);
    }

    /**
     * Whether an entity is within {@code distance} of a local block target.
     * Uses projected world-space distance first, then falls back to block-grid distance for flying entities.
     */
    public static boolean isWithinReach(class_1937 level, class_2338 localPos, class_243 entityPos, class_2338 entityBlockPos, double distance) {
        if (distanceToSqr(level, localPos, entityPos) < distance * distance) {
            return true;
        }
        return localPos.method_19771(entityBlockPos, distance);
    }

    public static boolean closerThan(class_1937 level, class_2338 localPos, class_243 entityPos, double distance) {
        return distanceToSqr(level, localPos, entityPos) < distance * distance;
    }

    @Deprecated
    public static boolean isInSafeSimulationDistance(class_3218 level, class_2338 pos) {
        if (!level.method_8477(pos)) {
            return false;
        }
        int simDistance = level.method_8503().method_3760().method_38651();
        int range = simDistance - 1; // Reduce by 1 chunk to be safe.
        return level.method_18456().stream().anyMatch(player -> {
            double dx = Math.abs(pos.method_10263() - player.method_23317()) / 16.0;
            double dz = Math.abs(pos.method_10260() - player.method_23321()) / 16.0;
            return Math.max(dx, dz) <= range;
        });
    }

    public static boolean isInSimulationDistance(class_3218 level, class_1923 chunkPos) {
        return level.method_14178().field_17254.method_17263().method_38630(chunkPos.method_8324());
    }

    public static boolean isInSimulationDistance(class_3218 level, class_2338 pos) {
        return isInSimulationDistance(level, new class_1923(pos));
    }

    public static boolean isInSimulationDistance(class_3218 level, class_1297 entity) {
        return isInSimulationDistance(level, entity.method_31476());
    }

    public static @Nullable class_2338 findNearbyHeightmapSpawnPosition(class_3218 level, class_2338 pos, int altitude) {
        double lowestDistance = Double.MAX_VALUE;
        @Nullable class_2338 closestRandomPos = null;

        for (int i = 0; i < 5; i++) {
            class_2338 randomPos = aboveGround(level, level.method_8536(pos.method_10263(), pos.method_10264(), pos.method_10260(), 15), altitude);

            if (Position.isInSimulationDistance(level, randomPos)) {
                double distance = randomPos.method_10262(pos);

                if (distance < lowestDistance) {
                    lowestDistance = distance;
                    closestRandomPos = randomPos;
                }
            }
        }

        if (closestRandomPos != null) {
            return closestRandomPos;
        }

        class_2338 blockPos = aboveGround(level, pos, altitude);
        if (Position.isInSimulationDistance(level, blockPos)) {
            return blockPos;
        }

        return null;
    }

    public static class_2338 aboveGround(class_1937 level, class_2338 pos, int altitude) {
        int heightmapY = level.method_8598(class_2902.class_2903.field_13197, pos).method_10264();
        int y = Math.max(pos.method_10264(), heightmapY + altitude);
        return pos.method_10264() == y ? pos : pos.method_33096(y);
    }

    public static int getDistanceBetween(class_2338 a, class_2338 b) {
        return (int) Math.sqrt(a.method_10262(b));
    }

    public static int getDistanceBetween(class_1937 level, class_2338 a, class_2338 b) {
        return (int) Math.sqrt(getGlobalCenter(level, a).method_1025(getGlobalCenter(level, b)));
    }

    public static Optional<Integer> getDistanceBetween(Optional<class_2338> a, Optional<class_2338> b) {
        if (a.isEmpty() || b.isEmpty()) return Optional.empty();
        return Optional.of(getDistanceBetween(a.get(), b.get()));
    }

    public static boolean isFireNearby(class_1937 level, class_2338 pos) {
        if (level == null) return false;

        for (class_2338 blockPos : class_2338.method_10097(pos.method_10069(-1, -1, -1), pos.method_10069(1, 1, 1))) {
            if (level.method_8320(blockPos).method_26204() instanceof class_2358) {
                return true;
            }
        }

        return false;
    }
}
