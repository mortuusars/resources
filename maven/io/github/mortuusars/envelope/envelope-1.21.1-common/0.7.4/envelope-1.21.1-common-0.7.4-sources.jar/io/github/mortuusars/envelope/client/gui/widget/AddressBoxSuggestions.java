package io.github.mortuusars.envelope.client.gui.widget;

import com.mojang.brigadier.suggestion.Suggestion;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.AddressFormatter;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1109;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3417;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_6382;

public class AddressBoxSuggestions extends class_339 {
    protected final class_327 font = Minecrft.get().field_1772;

    protected final class_342 editBox;
    protected final AllAddresses addresses;

    protected final List<Suggestion> suggestions = new ArrayList<>();
    protected int maxDisplayedLines;
    protected int selectedIndex = 0;
    protected int scroll = 0;
    protected boolean show;

    public AddressBoxSuggestions(class_342 addressBox, AllAddresses addresses, int maxDisplayedLines) {
        super(addressBox.method_46426(), addressBox.method_46427() + addressBox.method_25364() + 3, addressBox.method_25368(), 1, class_2561.method_43473());
        this.editBox = addressBox;
        this.addresses = addresses;
        this.maxDisplayedLines = maxDisplayedLines;
    }

    public void update() {
        suggestions.clear();
        selectedIndex = 0;
        setScroll(0);
        editBox.method_1887(null);

        String text = editBox.method_1882();

        if (!addresses.isKnown(text)) {
            suggestions.addAll(class_2172.method_9264(
                        addresses.stream().map(Address::getString),
                        new SuggestionsBuilder(text, 0)
                  )
                  .join()
                  .getList());
            show = !text.isEmpty();
        }
    }

    @Override
    protected void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (!show) {
            return;
        }

        int lineHeight = 11;

        method_53533(lineHeight * Math.min(maxDisplayedLines, suggestions.size()));
        int y = method_46427();

        int hoveredIndex = getHoveredSuggestionIndex(mouseX, mouseY);

        for (int i = scroll; i < Math.min(maxDisplayedLines + scroll, suggestions.size()); i++) {
            Suggestion suggestion = suggestions.get(i);

            boolean selected = i == selectedIndex;

            int textColor = selected ? 0xFFEDB548 : 0xFFFFFFFF;
            int fillColor = selected ? 0xD0000000 : 0xD0111111;

            guiGraphics.method_25294(method_46426() - 13, y, method_46426() + method_25368(), y + lineHeight, fillColor);

            String icon = addresses.byName(suggestion.getText()).map(AddressFormatter::getIcon).orElse("");
            if (!icon.isBlank()) {
                int iconColor = selected ? textColor : 0xFFAAAAAA;
                guiGraphics.method_51433(font, icon, method_46426() - 9, y + 1, iconColor, true);
            }

            String text = suggestion.getText();
            if (font.method_1727(text) > method_25368()) {
                String ellipsis = "...";
                text = font.method_27523(suggestion.getText(), method_25368() - font.method_1727(ellipsis)) + ellipsis;

                if (hoveredIndex == i) {
                    guiGraphics.method_51438(font, class_2561.method_43470(suggestion.getText()), mouseX, mouseY);
                }
            }
            guiGraphics.method_51433(font, text, method_46426(), y + 1, textColor, true);

            y += lineHeight;
        }

        renderScrollBar(guiGraphics, mouseX, mouseY, partialTick);
    }

    protected void renderScrollBar(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (!suggestions.isEmpty() && suggestions.size() > maxDisplayedLines) {
            int trackHeight = method_25364() - 2;

            int maxScroll = suggestions.size() - maxDisplayedLines;
            int thumbHeight = trackHeight * maxDisplayedLines / suggestions.size();

            float scrollRatio = maxScroll != 0 ? (float) scroll / maxScroll : 0;

            int thumbY = (int) ((trackHeight - thumbHeight) * scrollRatio);

            guiGraphics.method_25294(method_46426() + method_25368(), method_46427(), method_46426() + method_25368() + 3, method_46427() + method_25364(), 0xD0111111);
            guiGraphics.method_25294(method_46426() + method_25368() + 1, method_46427() + thumbY + 1,
                  method_46426() + method_25368() + 2, method_46427() + thumbY + thumbHeight + 1, 0xFFAAAAAA);
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == class_3675.field_31950) {
            show = !show;
            return true;
        }

        if (!show) {
            return false;
        }

        if (keyCode == class_3675.field_31932) {
            select(selectedIndex - 1);
            return true;
        }
        if (keyCode == class_3675.field_31982) {
            select(selectedIndex + 1);
            return true;
        }
        if (keyCode == class_3675.field_31948) {
            getSelected().ifPresent(suggestion -> editBox.method_1852(suggestion.getText()));
            Minecrft.get().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1f));
            return true;
        }

        return false;
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        if (!show) {
            return;
        }

        int hoveredSuggestion = getHoveredSuggestionIndex(mouseX, mouseY);
        if (hoveredSuggestion >= 0 && selectedIndex != hoveredSuggestion) {
            select(hoveredSuggestion);
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (!show) {
            return false;
        }

        if (method_37303() && method_25367()) {
            //noinspection SuspiciousNameCombination
            setScroll(scroll - class_3532.method_17822(scrollY));
            return true;
        }

        return false;
    }

    public void scrollTo(int index) {
        int currentStart = scroll;
        int currentEnd = scroll + maxDisplayedLines - 1;

        if (index < currentStart) {
            setScroll(index);
        } else if (index > currentEnd) {
            setScroll(index - maxDisplayedLines + 1);
        } else {
            setScroll(scroll); // Update just in case
        }
    }

    public void setScroll(int value) {
        scroll = class_3532.method_15340(value, 0, Math.max(0, suggestions.size() - maxDisplayedLines));
    }

    public void select(int index) {
        if (index < 0) {
            index = suggestions.size() - 1;
        } else if (index >= suggestions.size()) {
            index = 0;
        }

        selectedIndex = class_3532.method_15340(index, 0, suggestions.size() - 1);
        scrollTo(selectedIndex);
        getSelected().ifPresent(suggestion -> {
            String suffix = calculateSuggestionSuffix(editBox.method_1882(), suggestion.getText());
            editBox.method_1887(suffix);
        });
    }

    protected @Nullable String calculateSuggestionSuffix(String inputText, String suggestionText) {
        return suggestionText.startsWith(inputText) ? suggestionText.substring(inputText.length()) : null;
    }

    public Optional<Suggestion> getSelected() {
        if (selectedIndex < 0 || selectedIndex >= suggestions.size()) return Optional.empty();
        return Optional.of(suggestions.get(selectedIndex));
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        if (!show) {
            return;
        }

        int hoveredSuggestion = getHoveredSuggestionIndex(mouseX, mouseY);
        if (hoveredSuggestion >= 0 && hoveredSuggestion < suggestions.size()) {
            editBox.method_1852(suggestions.get(hoveredSuggestion).getText());
        }
    }

    public int getHoveredSuggestionIndex(double mouseX, double mouseY) {
        if (suggestions.isEmpty()
              || mouseX < method_46426() || mouseX >= method_46426() + method_25368()
              || mouseY < method_46427() || mouseY >= method_46427() + 11 * Math.min(maxDisplayedLines, suggestions.size())) {
            return -1;
        }

        int y = (int) (mouseY - method_46427());

        return class_3532.method_15340(y / 11 + scroll, scroll, suggestions.size() - 1);
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) {

    }
}
