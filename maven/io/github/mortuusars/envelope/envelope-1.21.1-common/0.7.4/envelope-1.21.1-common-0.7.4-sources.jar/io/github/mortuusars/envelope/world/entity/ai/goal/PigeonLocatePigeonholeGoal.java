package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.integration.sable.ContraptionTargets;
import io.github.mortuusars.envelope.world.block.PigeonholeBlockEntity;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import java.util.List;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class PigeonLocatePigeonholeGoal extends class_1352 {
    protected final Pigeon pigeon;

    public PigeonLocatePigeonholeGoal(Pigeon pigeon) {
        this.pigeon = pigeon;
    }

    @Override
    public boolean method_6264() {
        return pigeon.getPigeonholeHandler().getLocateCooldown() == 0
              && pigeon.getPigeonholeHandler().getTargetPos() == null
              && pigeon.getPigeonholeHandler().wantsToEnterPigeonhole(pigeon);
    }

    @Override
    public boolean method_6266() {
        return false;
    }

    @Override
    public void method_6269() {
        pigeon.getPigeonholeHandler().resetLocateCooldown();
        List<class_2338> nearbyPigeonholes = pigeon.getPigeonholeHandler()
              .findNearbyPigeonholesWithSpace((class_3218)pigeon.method_37908(), pigeon.method_24515());

        if (!nearbyPigeonholes.isEmpty()) {
            for (class_2338 pos : nearbyPigeonholes) {
                if (!pigeon.getPigeonholeHandler().isTargetBlacklisted(pos)) {
                    pigeon.getPigeonholeHandler().setTargetPos(pos);
                    return;
                }
            }

            pigeon.getPigeonholeHandler().clearBlacklist();
            pigeon.getPigeonholeHandler().setTargetPos(nearbyPigeonholes.getFirst());
        }
    }
}
