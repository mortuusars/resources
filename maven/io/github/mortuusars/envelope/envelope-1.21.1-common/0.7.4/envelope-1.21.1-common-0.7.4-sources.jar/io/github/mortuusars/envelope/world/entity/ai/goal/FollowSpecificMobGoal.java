package io.github.mortuusars.envelope.world.entity.ai.goal;

import java.util.function.Predicate;
import net.minecraft.class_1308;
import net.minecraft.class_1348;

public class FollowSpecificMobGoal extends class_1348 {
    protected final Predicate<class_1308> predicate;

    public FollowSpecificMobGoal(class_1308 mob, Predicate<class_1308> predicate, double speedModifier, float stopDistance, float areaSize) {
        super(mob, speedModifier, stopDistance, areaSize);
        this.predicate = predicate;
    }

    @Override
    public boolean method_6264() {
        return super.method_6264() && field_6433 != null && predicate.test(field_6433);
    }
}
