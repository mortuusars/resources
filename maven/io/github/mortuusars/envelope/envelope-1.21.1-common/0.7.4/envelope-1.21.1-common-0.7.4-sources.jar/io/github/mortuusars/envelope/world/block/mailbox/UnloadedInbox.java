package io.github.mortuusars.envelope.world.block.mailbox;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.mail.address.Address;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_4844;

public class UnloadedInbox implements Inbox {
    public static final Codec<UnloadedInbox> CODEC = RecordCodecBuilder.create(i -> i.group(
          class_4844.field_41525.fieldOf("id").forGetter(UnloadedInbox::getId),
          Address.CODEC.fieldOf("address").forGetter(UnloadedInbox::getAddress),
          Codec.INT.optionalFieldOf("capacity", 512).forGetter(UnloadedInbox::getInboxCapacity),
          class_1799.field_24671.listOf().optionalFieldOf("mail", Collections.emptyList()).forGetter(UnloadedInbox::getAllMail)
    ).apply(i, UnloadedInbox::new));
    public static final Logger LOGGER = LogUtils.getLogger();

    private final UUID id;
    private final Address address;
    private final int capacity;
    private final List<class_1799> mail;

    private @Nullable Runnable onChanged;

    public UnloadedInbox(UUID id, Address address, int capacity, List<class_1799> mail) {
        this.id = id;
        this.address = address;
        this.capacity = capacity;
        this.mail = new ArrayList<>(mail);
    }

    public UUID getId() {
        return id;
    }

    public Address getAddress() {
        return address;
    }

    @Override
    public int getInboxCapacity() {
        return capacity;
    }

    @Override
    public @NotNull List<class_1799> getAllMail() {
        return mail;
    }

    // --

    public void onChanged(@NotNull Runnable onChanged) {
        this.onChanged = onChanged;
    }

    @Override
    public void onInboxChanged() {
        if (onChanged == null) {
            LOGGER.warn("UnloadedInbox was changed without onChanged callback being set. Changes may not persist.");
        } else {
            onChanged.run();
        }
    }
}
