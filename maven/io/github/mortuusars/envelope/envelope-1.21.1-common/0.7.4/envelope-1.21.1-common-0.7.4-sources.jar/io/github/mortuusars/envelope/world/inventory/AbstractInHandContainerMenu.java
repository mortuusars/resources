package io.github.mortuusars.envelope.world.inventory;

import io.github.mortuusars.envelope.world.inventory.slot.DisabledSlot;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3917;

public abstract class AbstractInHandContainerMenu extends class_1703 {
    private final class_1657 player;
    private final class_1268 hand;
    private final class_1792 usedItem;
    private final int usedSlot;
    private final class_1263 container;

    protected int playerSlotsX = 8;
    protected int playerSlotsY = 96;

    public AbstractInHandContainerMenu(@Nullable class_3917<?> menuType, int containerId, class_1661 playerInventory, class_1268 hand) {
        super(menuType, containerId);
        this.player = playerInventory.field_7546;
        this.hand = hand;
        this.usedItem = player.method_5998(hand).method_7909();
        this.usedSlot = hand == class_1268.field_5810 ? class_1661.field_30639 : playerInventory.field_7545;
        this.container = createContainer();
        init();
    }

    public class_1657 getPlayer() {
        return player;
    }

    public class_1268 getHand() {
        return hand;
    }

    public class_1799 getItemInHand() {
        return getPlayer().method_5998(getHand());
    }

    public class_1792 getUsedItem() {
        return usedItem;
    }

    public int getUsedSlot() {
        return usedSlot;
    }

    public class_1263 getContainer() {
        return Objects.requireNonNull(container, "Called too early. Container has not been created yet.");
    }

    // --

    protected void init() {
        addContainerSlots();
        addPlayerSlots(getPlayer().method_31548(), playerSlotsX, playerSlotsY);
    }

    protected abstract class_1263 createContainer();

    protected abstract void addContainerSlots();

    protected void addPlayerSlots(class_1263 inventory, int x, int y) {
        // Hotbar
        for (int index = 0; index < 9; index++) {
            int slotX = x + index * 18;
            int slotY = y + 58;
            method_7621(index == getUsedSlot()
                  ? new DisabledSlot(inventory, index, slotX, slotY)
                  : new class_1735(inventory, index, slotX, slotY));
        }

        // Inventory
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                int index = (column + row * 9) + 9;
                int slotX = x + column * 18;
                int slotY = y + row * 18;
                method_7621(index == getUsedSlot()
                      ? new DisabledSlot(inventory, index, slotX, slotY)
                      : new class_1735(inventory, index, slotX, slotY));
            }
        }
    }

    @Override
    public @NotNull class_1799 method_7601(@NotNull class_1657 player, int index) {
        class_1735 slot = field_7761.get(index);
        class_1799 clickedStack = slot.method_7677();

        if (index < getContainer().method_5439()) {
            if (!method_7616(clickedStack, getContainer().method_5439(), field_7761.size(), true)) {
                return class_1799.field_8037;
            }
        } else if (index < field_7761.size()) {
            if (!method_7616(clickedStack, 0, getContainer().method_5439(), false)) {
                return class_1799.field_8037;
            }
        }

        getContainer().method_5431();

        return class_1799.field_8037;
    }

    @Override
    public void method_7593(int slotId, int button, class_1713 clickType, class_1657 player) {
        if (clickType == class_1713.field_7791 && usedSlot == button) {
            // Fixes item dupe by moving the used item to another slot with 1-9 keys.
            // It would be nice of mojang to at least check mayPickup on the source slot, but yeah...
            return;
        }
        super.method_7593(slotId, button, clickType, player);
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return player.method_5998(hand).method_7909() == getUsedItem();
    }
}
