package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_11;
import net.minecraft.class_1352;
import net.minecraft.class_1542;

public class PigeonSearchForFoodGoal extends class_1352 {
    protected final Pigeon pigeon;

    public PigeonSearchForFoodGoal(Pigeon pigeon) {
        this.pigeon = pigeon;
        this.method_6265(EnumSet.of(class_1352.class_4134.field_18405));
    }

    @Override
    public boolean method_6264() {
        if (!Config.Server.PIGEON_EATS_SEEDS.get()
              || pigeon.isDelivering()
              || pigeon.isSitting()
              || !pigeon.method_6047().method_7960()
              || pigeon.getEatingTicks() > 0
              || pigeon.method_6065() != null
              || pigeon.method_59922().method_43048(method_38848(10)) != 0) {
            return false;
        }
        return !findItems().isEmpty();
    }

    @Override
    public void method_6268() {
        if (!pigeon.method_6047().method_7960()) {
            return;
        }
        List<class_1542> items = findItems();
        if (!items.isEmpty()) {
            @Nullable class_11 path = pigeon.method_5942().method_6349(items.getFirst(), 0);
            if (path != null) pigeon.method_5942().method_6334(path, 0.5);
        }
    }

    @Override
    public void method_6269() {
        List<class_1542> items = findItems();
        if (!items.isEmpty()) {
            @Nullable class_11 path = pigeon.method_5942().method_6349(items.getFirst(), 0);
            if (path != null) pigeon.method_5942().method_6334(path, 0.5);
        }
    }

    protected List<class_1542> findItems() {
        return pigeon.method_37908().method_8390(
              class_1542.class,
              pigeon.method_5829().method_1014(12),
              Pigeon.SEARCHED_FOOD_ITEMS_PREDICATE);
    }
}