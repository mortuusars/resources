package io.github.mortuusars.envelope.world.item.component.seal;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5381;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7891;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class SealSymbol {
    public static final Codec<SealSymbol> DIRECT_CODEC = RecordCodecBuilder.create(i -> i.group(
          class_2960.field_25139.fieldOf("texture").forGetter(SealSymbol::textureId)
    ).apply(i, SealSymbol::new));

    public static final class_9139<class_9129, SealSymbol> DIRECT_STREAM_CODEC = class_9139.method_56434(
          class_2960.field_48267, SealSymbol::textureId,
          SealSymbol::new
    );

    public static final Codec<class_6880<SealSymbol>> CODEC =
          class_5381.method_29749(Envelope.Registries.SEAL_SYMBOL, DIRECT_CODEC);

    public static final class_9139<class_9129, class_6880<SealSymbol>> STREAM_CODEC =
          class_9135.method_56367(Envelope.Registries.SEAL_SYMBOL, DIRECT_STREAM_CODEC);

    // --

    public static final Map<Character, class_5321<SealSymbol>> LETTERS = class_156.method_654(new HashMap<>(), map -> {
        for (char c = 'a'; c <= 'z'; c++) {
            map.put(c, key("letter/" + c));
        }
    });
    public static final Map<Character, class_5321<SealSymbol>> NUMBERS = class_156.method_654(new HashMap<>(), map -> {
        for (char c = '0'; c <= '9'; c++) {
            map.put(c, key("number/" + c));
        }
    });
    public static final Map<String, class_5321<SealSymbol>> EMBLEMS = new HashMap<>();

    public static final class_5321<SealSymbol> APPLE = emblemKey("apple");
    public static final class_5321<SealSymbol> AXE = emblemKey("axe");
    public static final class_5321<SealSymbol> BLOCK = emblemKey("block");
    public static final class_5321<SealSymbol> BOOK = emblemKey("book");
    public static final class_5321<SealSymbol> CREEPER = emblemKey("creeper");
    public static final class_5321<SealSymbol> EMERALD = emblemKey("emerald");
    public static final class_5321<SealSymbol> HEART = emblemKey("heart");
    public static final class_5321<SealSymbol> HOE = emblemKey("hoe");
    public static final class_5321<SealSymbol> LETTER = emblemKey("letter"); // Do not confuse with LETTERS
    public static final class_5321<SealSymbol> PICKAXE = emblemKey("pickaxe");
    public static final class_5321<SealSymbol> SHOVEL = emblemKey("shovel");
    public static final class_5321<SealSymbol> SKELETON = emblemKey("skeleton");
    public static final class_5321<SealSymbol> SKELETON_SMIRK = emblemKey("skeleton_smirk");
    public static final class_5321<SealSymbol> SWORD = emblemKey("sword");
    public static final class_5321<SealSymbol> SWORDS = emblemKey("swords");
    public static final class_5321<SealSymbol> VILLAGER = emblemKey("villager");

    public static final class_5321<SealSymbol> DEFAULT = CREEPER;

    // --

    private final class_2960 texture;
    private final class_2960 textureFull;

    public SealSymbol(class_2960 texture) {
        this.texture = texture;
        this.textureFull = texture.method_45134(path -> "textures/" + path + ".png");
    }

    public class_2960 textureId() {
        return texture;
    }

    public class_2960 texture() {
        return textureFull;
    }

    public static class_5321<SealSymbol> firstCharOrDefault(String string) {
        for (int i = 0; i < string.length(); i++) {
            char c = Character.toLowerCase(string.charAt(i));

            if (c >= 'a' && c <= 'z') {
                return LETTERS.getOrDefault(c, DEFAULT);
            }

            if (c >= '0' && c <= '9') {
                return NUMBERS.getOrDefault(c, DEFAULT);
            }
        }

        return DEFAULT;
    }

    public static class_5321<SealSymbol> firstCharOrDefault(@Nullable class_1657 player) {
        if (player == null) {
            return DEFAULT;
        }
        return firstCharOrDefault(player.method_5820());
    }

    // --

    public static Optional<class_6880.class_6883<SealSymbol>> get(class_7225.class_7874 registries, class_5321<SealSymbol> key) {
        return registries.method_46762(Envelope.Registries.SEAL_SYMBOL).method_46746(key);
    }

    public static class_6880<SealSymbol> getOrThrow(class_7225.class_7874 registries, class_5321<SealSymbol> key) {
        return registries.method_46762(Envelope.Registries.SEAL_SYMBOL).method_46747(key);
    }

    // --

    private static class_5321<SealSymbol> key(String path) {
        return class_5321.method_29179(Envelope.Registries.SEAL_SYMBOL, Envelope.resource(path));
    }

    private static class_5321<SealSymbol> emblemKey(String path) {
        class_5321<SealSymbol> key = class_5321.method_29179(Envelope.Registries.SEAL_SYMBOL, Envelope.resource(path));
        EMBLEMS.put(path, key);
        return key;
    }

    public static void bootstrap(class_7891<SealSymbol> context) {
        Function<class_5321<SealSymbol>, class_2960> keyToTexture = key ->
              key.method_29177().method_45134(path -> "seal/symbol/" + path);

        NUMBERS.values().forEach(key -> context.method_46838(key, new SealSymbol(keyToTexture.apply(key))));
        LETTERS.values().forEach(key -> context.method_46838(key, new SealSymbol(keyToTexture.apply(key))));
        EMBLEMS.values().forEach(key -> context.method_46838(key, new SealSymbol(keyToTexture.apply(key))));
    }
}
