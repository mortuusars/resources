package io.github.mortuusars.envelope.world.mail.address.type;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.BlockAddressValidation;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;
import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class BlockAddress implements Address {
    public static final Codec<String> ID_CODEC = Codec.STRING
          .xmap(String::trim, String::trim)
          .validate(BlockAddressValidation::validateId);

    public static final Codec<BlockAddress> STRING_CODEC = ID_CODEC.xmap(BlockAddress::new, BlockAddress::getString);

    public static final MapCodec<BlockAddress> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
          ID_CODEC.fieldOf("id").forGetter(BlockAddress::getString)
    ).apply(i, BlockAddress::new));

    public static final class_9139<class_9129, BlockAddress> STREAM_CODEC =
          class_9135.field_48554.method_56432(BlockAddress::new, BlockAddress::getString).method_56430();

    public static final int MAX_LENGTH = 40;

    private final String id;

    public BlockAddress(String id) {
        this.id = BlockAddressValidation.throwIfInvalid(id);
    }

    @Override
    public Type getType() {
        return Type.BLOCK;
    }

    public String getString() {
        return id;
    }

    public class_5250 getComponent() {
        return class_2561.method_43470(id);
    }

    // --

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        BlockAddress that = (BlockAddress) o;
        return matches(that.getString());
    }

    @Override
    public int hashCode() {
        return ("b" + id.toLowerCase(Locale.ROOT)).hashCode();
    }

    @Override
    public @NotNull String toString() {
        return "Block[" + id + "]";
    }
}
