package io.github.mortuusars.envelope.world.mail.address;

import com.mojang.serialization.DataResult;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.util.result.Error;
import io.github.mortuusars.envelope.util.validation.Rule;
import io.github.mortuusars.envelope.util.validation.Validator;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_3544;

public interface BlockAddressValidation {
    Error CANNOT_BE_EMPTY = new Error("Id cannot be empty", "error.envelope.address.id_cannot_be_empty");
    Error TOO_LONG = new Error("Id is too long", "error.envelope.address.id_too_long");
    Error CONTAINS_INVALID_CHARS = new Error("Id is too long", "error.envelope.address.id_contains_invalid_chars");
    Error TAKEN = new Error("Id is in use", "error.envelope.address.taken");
    Error NOT_ENOUGH_XP = new Error("Not enough xp levels", "error.envelope.address.not_enough_xp_levels");

    List<String> RESERVED_IDS = List.of(
          "Mail Service",
          "Unknown"
    );

    Validator<String> ID = Validator.of(
          Rule.when(class_3544::method_57181, CANNOT_BE_EMPTY),
          Rule.when(id -> id.length() > BlockAddress.MAX_LENGTH, TOO_LONG),
          Rule.when(id -> !class_3544.method_57180(id).equals(id), CONTAINS_INVALID_CHARS),
          Rule.when(RESERVED_IDS::contains, TAKEN)
    );

    static Validator<String> id() {
        return ID;
    }

    static Validator<String> forMailbox(AllAddresses addresses, class_1657 player) {
        return id()
              .and(isNotTaken(addresses))
              .and(hasEnoughXp(player, Config.Server.MAILBOX_ADDRESS_EXPERIENCE_LEVELS_COST.get()));
    }

    // --

    static Rule<String> isNotTaken(AllAddresses addresses) {
        return Rule.when(addresses::isKnown, TAKEN);
    }

    static Rule<String> hasEnoughXp(class_1657 player, int xpLevelsRequired) {
        return Rule.when(id -> !player.method_7337() && player.field_7520 < xpLevelsRequired, NOT_ENOUGH_XP);
    }

    static @NotNull DataResult<String> validateId(String id) {
        return id()
              .test(id)
              .map(DataResult::success, Error::asDataResult);
    }

    static String throwIfInvalid(String id) throws IllegalArgumentException {
        id().test(id).getError().ifPresent(error -> {
            throw new IllegalArgumentException(error.getMessage());
        });
        return id;
    }
}
