package io.github.mortuusars.envelope.world.mail.address;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.mail.delivery.TravelDuration;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3542;
import net.minecraft.class_5699;

public interface AddressLocation {
    int ASCEND_DISTANCE = 16;

    Codec<AddressLocation> CODEC = Type.CODEC.dispatch(AddressLocation::getType, Type::getCodec);

    Type getType();

    Optional<class_2338> getPosition();

    int getDistanceTo(class_2338 pos);

    default int getDistanceTo(Optional<class_2338> pos) {
        return pos.map(this::getDistanceTo).orElse(Config.Server.DELIVERY_DEFAULT_DISTANCE.get());
    }

    default TravelDuration getTravelDurationTo(class_2338 pos) {
        return TravelDuration.basedOnDistance(getDistanceTo(pos));
    }

    default TravelDuration getTravelDurationTo(Optional<class_2338> pos) {
        return TravelDuration.basedOnDistance(getDistanceTo(pos));
    }

    default Optional<class_2338> getNearestHub() {
        return getPosition().map(pos -> Position.snapToGrid(pos, 1024).method_33096(320));
    }

    default Optional<class_2338> ascendTowards(class_1937 level, Optional<class_2338> targetPos) {
        return getPosition().map(pos -> targetPos
                    .map(blockPos -> Position.ascendTowards(pos, blockPos, ASCEND_DISTANCE))
                    .orElseGet(() -> Position.towardsRandomHorizontalDirection(pos, ASCEND_DISTANCE, hashCode())))
              .map(pos -> Position.aboveGround(level, pos, 5));
    }

    default int getDistanceTo(class_1937 level, class_2338 pos) {
        return getDistanceTo(pos);
    }

    default int getDistanceTo(class_1937 level, Optional<class_2338> pos) {
        return pos.map(p -> getDistanceTo(level, p)).orElse(Config.Server.DELIVERY_DEFAULT_DISTANCE.get());
    }

    // --

    static AddressLocation exact(class_2338 pos) {
        return new Exact(pos);
    }

    record Exact(@NotNull class_2338 pos) implements AddressLocation {
        public static final MapCodec<Exact> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
              class_2338.field_25064.fieldOf("pos").forGetter(Exact::pos)
        ).apply(i, Exact::new));

        @Override
        public Type getType() {
            return Type.EXACT;
        }

        @Override
        public Optional<class_2338> getPosition() {
            return Optional.of(pos);
        }

        @Override
        public int getDistanceTo(class_2338 pos) {
            return Position.getDistanceBetween(this.pos, pos);
        }

        @Override
        public int getDistanceTo(class_1937 level, class_2338 pos) {
            return Position.getDistanceBetween(level, this.pos, pos);
        }
    }

    record Relative(int distance) implements AddressLocation {
        public static final MapCodec<Relative> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
              class_5699.field_33441.fieldOf("distance").forGetter(Relative::distance)
        ).apply(i, Relative::new));

        @Override
        public Type getType() {
            return Type.RELATIVE;
        }

        @Override
        public Optional<class_2338> getPosition() {
            return Optional.empty();
        }

        @Override
        public int getDistanceTo(class_2338 pos) {
            return distance;
        }
    }

    AddressLocation DEFAULT = new AddressLocation() {
        @Override
        public Type getType() {
            return Type.DEFAULT;
        }

        @Override
        public Optional<class_2338> getPosition() {
            return Optional.empty();
        }

        @Override
        public int getDistanceTo(class_2338 pos) {
            return Config.Server.DELIVERY_DEFAULT_DISTANCE.get();
        }
    };

    // --

    enum Type implements class_3542 {
        EXACT("exact", Exact.CODEC),
        RELATIVE("relative", Relative.CODEC),
        DEFAULT("default", MapCodec.unit(AddressLocation.DEFAULT));

        public static final Codec<Type> CODEC = class_3542.method_28140(Type::values);

        private final String name;
        private final MapCodec<? extends AddressLocation> codec;

        Type(String name, MapCodec<? extends AddressLocation> codec) {
            this.name = name;
            this.codec = codec;
        }

        public MapCodec<? extends AddressLocation> getCodec() {
            return codec;
        }

        @Override
        public @NotNull String method_15434() {
            return name;
        }
    }
}
