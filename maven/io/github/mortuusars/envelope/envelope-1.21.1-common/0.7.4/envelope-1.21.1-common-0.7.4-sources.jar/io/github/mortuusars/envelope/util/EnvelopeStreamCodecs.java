package io.github.mortuusars.envelope.util;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_3965;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public interface EnvelopeStreamCodecs {
    class_9139<ByteBuf, class_243> VEC3 = class_9139.method_56436(
          class_9135.field_48553, class_243::method_10216,
          class_9135.field_48553, class_243::method_10214,
          class_9135.field_48553, class_243::method_10215,
          class_243::new
    );

    class_9139<class_2540, class_3965> BLOCK_HIT_RESULT = class_9139.method_56905(
          VEC3, class_3965::method_17784,
          class_2350.field_48450, class_3965::method_17780,
          class_2338.field_48404, class_3965::method_17777,
          class_9135.field_48547, class_3965::method_17781,
          class_3965::new
    );
}
