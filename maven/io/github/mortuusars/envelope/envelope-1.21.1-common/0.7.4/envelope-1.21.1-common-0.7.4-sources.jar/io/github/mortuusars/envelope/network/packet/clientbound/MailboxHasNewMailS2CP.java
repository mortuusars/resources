package io.github.mortuusars.envelope.network.packet.clientbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.packet.Packet;
import io.github.mortuusars.envelope.world.inventory.MailboxMenu;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public class MailboxHasNewMailS2CP implements Packet {
    public static final MailboxHasNewMailS2CP INSTANCE = new MailboxHasNewMailS2CP();
    public static final class_2960 ID = Envelope.resource("mailbox_has_new_mail");
    public static final class_9154<MailboxHasNewMailS2CP> TYPE = new class_9154<>(ID);
    public static final class_9139<class_2540, MailboxHasNewMailS2CP> STREAM_CODEC = class_9139.method_56431(INSTANCE);
    private MailboxHasNewMailS2CP() {
    }

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (!(player.field_7512 instanceof MailboxMenu menu)) {
            Envelope.LOGGER.error("Cannot handle '{}' packet: Player '{}' does not have MailboxMenu open.", ID, player);
            return false;
        }

        menu.setHasNewMail(true);
        player.method_37908().method_43129(player, player, class_3417.field_14627, class_3419.field_15245, 0.75f, 1f);
        return true;
    }
}

