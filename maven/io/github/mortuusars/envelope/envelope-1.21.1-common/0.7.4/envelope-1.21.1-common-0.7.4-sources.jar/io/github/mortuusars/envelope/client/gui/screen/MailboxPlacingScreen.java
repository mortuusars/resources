package io.github.mortuusars.envelope.client.gui.screen;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.serverbound.MailboxPlaceC2SP;
import io.github.mortuusars.envelope.world.item.MailboxBlockItem;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_746;

public class MailboxPlacingScreen extends AbstractMailboxAddressScreen {
    protected final class_746 player;
    protected final class_3965 hitResult;

    public MailboxPlacingScreen(class_1268 hand, AllAddresses knownAddresses, class_3965 hitResult, class_2561 title) {
        super(hand, knownAddresses, Optional.empty(), title);
        this.player = Minecrft.player();
        this.hitResult = hitResult;
        this.existingAddress = Optional.empty();
    }

    @Override
    protected class_1799 getTargetPreview() {
        //TODO: Support for proper block state preview. As it will look when placed.
        return Minecrft.player().method_5998(hand);
    }

    @Override
    protected void onConfirm() {
        class_1799 stack = player.method_5998(hand);

        if (!(stack.method_7909() instanceof class_1747 blockItem)) {
            return;
        }

        if (blockItem.method_7712(new class_1750(player, hand, stack, hitResult)).method_23665()) {
            if (Config.Server.MAILBOX_ADDRESS_EXPERIENCE_LEVELS_COST.get() > 0) {
                player.method_37908().method_45447(player, hitResult.method_17777(), class_3417.field_15119, class_3419.field_15245);
            }

            Packets.sendToServer(new MailboxPlaceC2SP(hand, getCurrentAddressId().trim(), hitResult));
        }
    }

    @Override
    protected boolean stillValid() {
        return player.method_5998(hand).method_7909() instanceof MailboxBlockItem;
    }

    @Override
    protected boolean isCurrentIdSameAsExistingAddress() {
        return false;
    }
}
