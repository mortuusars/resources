package io.github.mortuusars.envelope.world.block.mailbox;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

public class MailboxesSavedData extends class_18 {
    public static final Codec<MailboxesSavedData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
          Codec.unboundedMap(BlockAddress.STRING_CODEC, RegisteredMailbox.CODEC)
                .optionalFieldOf("mailboxes", Collections.emptyMap()).forGetter(MailboxesSavedData::getMailboxes)
    ).apply(instance, MailboxesSavedData::new));

    private final HashMap<BlockAddress, RegisteredMailbox> mailboxes;

    protected MailboxesSavedData(Map<BlockAddress, RegisteredMailbox> mailboxes) {
        this.mailboxes = new HashMap<>(mailboxes); // Make sure it's mutable
    }

    protected MailboxesSavedData() {
        this(new HashMap<>());
    }

    public HashMap<BlockAddress, RegisteredMailbox> getMailboxes() {
        return mailboxes;
    }

    // -- Save / Load

    public static MailboxesSavedData get(class_3218 level) {
        return level.method_17983().method_17924(factory(), "envelope_mailboxes");
    }

    public static @NotNull class_8645<MailboxesSavedData> factory() {
        return new class_8645<>(
              MailboxesSavedData::new,
              (tag, provider) -> CODEC.parse(provider.method_57093(class_2509.field_11560), tag)
                    .resultOrPartial(e -> Envelope.LOGGER.error("Cannot load MailboxesSavedData: {}", e))
                    .orElse(null),
              null);
    }

    public @NotNull class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
        return (class_2487) CODEC.encode(this, registries.method_57093(class_2509.field_11560), tag)
              .resultOrPartial(e -> Envelope.LOGGER.error("Cannot save MailboxesSavedData: {}", e))
              .orElse(tag);
    }
}