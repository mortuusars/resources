package io.github.mortuusars.envelope.world.item.component;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2561;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record LetterAndQuillContent(String text) {
    public static final int MAX_LENGTH = 4096;

    public static final Codec<LetterAndQuillContent> CODEC = RecordCodecBuilder.create(i -> i.group(
          Codec.string(0, MAX_LENGTH).optionalFieldOf("text", "").forGetter(LetterAndQuillContent::text)
    ).apply(i, LetterAndQuillContent::new));

    public static final class_9139<ByteBuf, LetterAndQuillContent> STREAM_CODEC = class_9139.method_56434(
          class_9135.method_56364(MAX_LENGTH), LetterAndQuillContent::text,
          LetterAndQuillContent::new
    );

    public static final LetterAndQuillContent EMPTY = new LetterAndQuillContent("");

    public boolean isEmpty() {
        return this.equals(EMPTY);
    }

    public LetterContent toWritten() {
        return new LetterContent(class_2561.method_43470(text));
    }
}
