package io.github.mortuusars.envelope.world.item.component;

import com.mojang.serialization.Codec;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.util.Ticks;
import io.netty.buffer.ByteBuf;
import org.jetbrains.annotations.NotNull;

import java.util.function.IntFunction;
import net.minecraft.class_3542;
import net.minecraft.class_7995;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public enum PaybackDuration implements class_3542 {
    SHORT("short"),
    MEDIUM("medium"),
    LONG("long");

    public static final IntFunction<PaybackDuration> BY_ID = class_7995.method_47914(PaybackDuration::ordinal, PaybackDuration.values(), class_7995.class_7996.field_41664);

    public static final Codec<PaybackDuration> CODEC = class_3542.method_28140(PaybackDuration::values);
    public static final class_9139<ByteBuf, PaybackDuration> STREAM_CODEC = class_9135.method_56375(BY_ID, PaybackDuration::ordinal);

    private final String name;

    PaybackDuration(String name) {
        this.name = name;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }

    public int getMinutes() {
        return switch (this) {
            case SHORT -> Config.Server.PAYBACK_REQUEST_DURATION_SHORT.get();
            case MEDIUM -> Config.Server.PAYBACK_REQUEST_DURATION_MEDIUM.get();
            case LONG -> Config.Server.PAYBACK_REQUEST_DURATION_LONG.get();
        };
    }

    public long getTicks() {
        return Ticks.fromMinutes(getMinutes());
    }
}
