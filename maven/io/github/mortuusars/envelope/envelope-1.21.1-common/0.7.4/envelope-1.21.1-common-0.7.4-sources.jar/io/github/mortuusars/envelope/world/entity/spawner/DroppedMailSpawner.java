package io.github.mortuusars.envelope.world.entity.spawner;

import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.entity.spawning.SpawnableItem;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.delivery.background.BackgroundDelivery;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_156;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class DroppedMailSpawner extends Spawner {
    public DroppedMailSpawner() {
        super(10);
    }

    @Override
    public boolean worksIn(class_3218 level) {
        return MailService.operatesIn(level);
    }

    @Override
    public void spawn(class_3218 level) {
        BackgroundDelivery backgroundDelivery = MailService.of(level).getBackgroundDelivery();
        List<SpawnableItem> items = backgroundDelivery.getDroppedMail();

        if (items.isEmpty()) {
            return;
        }

        SpawnableItem item = class_156.method_32309(items, level.method_8409());

        @Nullable class_2338 spawnPos = getSpawnPos(level, item);
        if (spawnPos == null) {
            return;
        }

        class_1297 entity = new class_1542(level,
              item.pos().method_10263() + 0.5,
              item.pos().method_10264() + 0.5,
              item.pos().method_10260() + 0.5,
              item.item());
        entity.method_5725(spawnPos, entity.method_36454(), entity.method_36455());
        level.method_30771(entity);

        backgroundDelivery.removeDroppedMail(item);
    }

    public @Nullable class_2338 getSpawnPos(class_3218 level, SpawnableItem item) {
        if (Position.isInSimulationDistance(level, item.pos())) {
            return item.pos();
        }
        return null;
    }
}
