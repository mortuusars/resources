package io.github.mortuusars.envelope.world.entity.spawner;

import net.minecraft.class_3218;

public abstract class Spawner {
    protected final int interval;
    protected final int id;

    static int counter;

    public Spawner(int interval) {
        this.interval = interval;
        this.id = counter++;
    }

    public final void tick(class_3218 level) {
        if (!worksIn(level)) return;
        if ((level.method_8510() + id) % interval != 0) return;
        spawn(level);
    }

    public abstract boolean worksIn(class_3218 level);
    public abstract void spawn(class_3218 level);
}
