package io.github.mortuusars.envelope.world.item.crafting.mail;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_3532;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;

public interface MailRecipe extends class_1860<MailRecipeInput> {
    ServiceAddress getAddress();

    @Override
    default @NotNull class_3956<?> method_17716() {
        return Envelope.RecipeTypes.MAILING.get();
    }

    @Override
    default boolean method_8118() {
        return true;
    }

    /**
     * Whether the crafting should only be done one time per delivery.<br>
     * Some recipes (and their side effects) could get out of control when multiple is allowed (like letter broadcasting).
     */
    default boolean isOneCraftPerDelivery() {
        return false;
    }

    @Override
    default @NotNull class_1799 method_17447() {
        return new class_1799(Envelope.Blocks.PACKAGE.get());
    }

    @Override
    default boolean method_8113(int width, int height) {
        return width * height >= PackageContents.SLOTS;
    }

    default float getExperience() {
        return 0f;
    }

    default int getExperiencePoints() {
        float xp = getExperience();
        int points = class_3532.method_15375(xp);
        float remainder = class_3532.method_22450(xp);
        if (remainder != 0.0F && Math.random() < remainder) {
            points++;
        }
        return points;
    }

    // --

    @Override
    default boolean matches(MailRecipeInput input, class_1937 level) {
        if (input.ingredientCount() != method_8117().size()) {
            return false;
        }
        return input.method_59983() == 1 && method_8117().size() == 1
              ? method_8117().getFirst().method_8093(input.method_59984(0))
              : input.stackedContents().method_7402(this, null);
    }

    /**
     * Regular result assemble method. Does not mutate world state. Can be called as many times as needed.
     */
    @Override
    default @NotNull class_1799 assemble(MailRecipeInput input, class_7225.class_7874 registries) {
        return method_8110(registries).method_7972();
    }

    /**
     * Special assemble method, that allows performing extra actions, that could potentially mutate the world state.<br>
     * - This method should be called only once per craft, when the crafting is guaranteed.<br>
     * - Should return the same item "shape" (type, count), as {@link MailRecipe#assemble(MailRecipeInput, class_7225.class_7874)},
     * to make sure the crafting works properly. Components can be different.
     */
    default @NotNull class_1799 assembleWithSideEffects(MailRecipeInput input, class_7225.class_7874 registries) {
        return assemble(input, registries);
    }
}
