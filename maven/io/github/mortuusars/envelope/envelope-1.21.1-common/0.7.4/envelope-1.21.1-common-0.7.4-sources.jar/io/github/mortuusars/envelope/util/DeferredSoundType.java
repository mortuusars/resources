package io.github.mortuusars.envelope.util;

import java.util.function.Supplier;
import net.minecraft.class_2498;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import org.jetbrains.annotations.NotNull;

/**
 * Copy of forge's sound type, for use with Suppliers.
 */
public class DeferredSoundType extends class_2498 {
    private final Supplier<class_3414> breakSound;
    private final Supplier<class_3414> stepSound;
    private final Supplier<class_3414> placeSound;
    private final Supplier<class_3414> hitSound;
    private final Supplier<class_3414> fallSound;

    public DeferredSoundType(float volume, float pitch, Supplier<class_3414> breakSound, Supplier<class_3414> stepSound, Supplier<class_3414> placeSound, Supplier<class_3414> hitSound, Supplier<class_3414> fallSound) {
        // Pass defaults instead of null, in case that nulls might break something.
        super(volume, pitch, class_3417.field_14574, class_3417.field_14574, class_3417.field_14574, class_3417.field_14574, class_3417.field_14574);
        this.breakSound = breakSound;
        this.stepSound = stepSound;
        this.placeSound = placeSound;
        this.hitSound = hitSound;
        this.fallSound = fallSound;
    }

    @Override
    public @NotNull class_3414 method_10595() {
        return breakSound.get();
    }

    @Override
    public @NotNull class_3414 method_10594() {
        return stepSound.get();
    }

    @Override
    public @NotNull class_3414 method_10598() {
        return placeSound.get();
    }

    @Override
    public @NotNull class_3414 method_10596() {
        return hitSound.get();
    }

    @Override
    public @NotNull class_3414 method_10593() {
        return fallSound.get();
    }
}
