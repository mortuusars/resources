package io.github.mortuusars.envelope.world.item.tooltip;

import io.github.mortuusars.envelope.world.mail.address.Address;
import net.minecraft.class_5632;
import org.jetbrains.annotations.NotNull;

public record MailAddressTagTooltip(@NotNull Address address) implements class_5632 {
}
