package io.github.mortuusars.envelope.world.item.component.mail.log.record;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.mail.address.Address;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SentRecord(Address address, long timestamp) implements DeliveryRecord {
    public static final MapCodec<SentRecord> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
          Address.CODEC.fieldOf("address").forGetter(SentRecord::address),
          Codec.LONG.fieldOf("timestamp").forGetter(SentRecord::timestamp)
    ).apply(i, SentRecord::new));

    public static final class_9139<class_9129, SentRecord> STREAM_CODEC = class_9139.method_56435(
          Address.STREAM_CODEC, SentRecord::address,
          class_9135.field_48551, SentRecord::timestamp,
          SentRecord::new
    );

    @Override
    public Type getType() {
        return Type.SENT;
    }

    @Override
    public class_5250 getDisplayComponent() {
        class_2561 address = this.address.format()
              .withIcon()
              .withIconColor(Colors.ADDRESS_SENDER)
              .withColor(Colors.ADDRESS_SENDER)
              .toComponent();

        return class_2561.method_43469("gui.envelope.delivery_log.record.sent", address, getElapsedTime(timestamp).orElse(class_2561.method_43473()));
    }
}
