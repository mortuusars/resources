package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import net.minecraft.class_10;
import net.minecraft.class_1395;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_5530;
import net.minecraft.class_5533;
import net.minecraft.class_5534;
import org.jetbrains.annotations.Nullable;

public class PigeonWanderGoal extends class_1395 {
    public static final int WANDER_RADIUS = 24;

    protected final Pigeon pigeon;

    public PigeonWanderGoal(Pigeon pigeon, double speedModifier) {
        super(pigeon, speedModifier);
        this.pigeon = pigeon;
        field_6564 = 100;
    }

    @Override
    protected @Nullable class_243 method_6302() {
        if (pigeon.method_5816()) {
            @Nullable class_243 pos = class_5534.method_31527(pigeon, 15, 15);
            if (pos != null) {
                return pos;
            }
        }

        @Nullable class_2338 homePos = pigeon.getPigeonholeHandler().getHomePos();
        if (homePos != null) {
            homePos = class_2338.method_49638(Position.getGlobalCenter(pigeon.method_37908(), homePos));
        }

        @Nullable class_243 newPos = choosePos(homePos);
        if (newPos == null || homePos == null) {
            return newPos;
        }

        double newDistanceToHomeSqr = homePos.method_19770(newPos);

        if (newDistanceToHomeSqr < WANDER_RADIUS * WANDER_RADIUS
              || newDistanceToHomeSqr <= homePos.method_19770(pigeon.method_19538())) { // If it brings the pigeon closer to home
            return newPos;
        }

        return null;
    }

    private @Nullable class_243 choosePos(@Nullable class_2338 homePos) {
        if (pigeon.isSitting() && (pigeon.isTired() || pigeon.method_59922().method_43057() < 0.75f)) {
            // Returning null keeps pigeon sitting pose.
            // When tired, sitting is controlled by PigeonSitGoal.
            // But if perched, we keep the pose with 75% chance.
            return null;
        }

        if (pigeon.method_59922().method_43057() < 0.2) {
            // Parrots use very low probability (0.001 or so) for their "perching".
            // But even with 0.2 it does not happen that often in my tests.
            @Nullable class_243 pos = getPerchPos();
            if (pos != null) {
                return pos;
            }
        }

        if (pigeon.method_59922().method_43057() < 0.2f
              && pigeon.method_37908().method_8320(pigeon.method_24515().method_10074()).method_26164(Envelope.Tags.Blocks.PIGEONS_PERCHABLE_ON)) {
            pigeon.setSitting(true);
            return null;
        }

        class_243 direction = homePos != null && homePos.method_19770(pigeon.method_19538()) > WANDER_RADIUS * WANDER_RADIUS
              ? class_243.method_24953(homePos).method_1020(pigeon.method_19538()).method_1029() // Bias towards home
              : pigeon.method_5828(0.0F); // Bias towards facing

        int range = 8;
        int yRange = 8;

        class_243 hoverPos = class_5533.method_31524(pigeon, range, yRange,
              direction.field_1352, direction.field_1350, (float) (Math.PI / 2), 3, 1);
        if (hoverPos != null) {
            return hoverPos;
        }

        return class_5530.method_31504(pigeon, range, yRange, -1,
              direction.field_1352, direction.field_1350, (float) (Math.PI / 2));
    }

    protected @Nullable class_243 getPerchPos() {
        class_2338 currentPos = pigeon.method_24515();
        class_2338.class_2339 abovePos = new class_2338.class_2339();
        class_2338.class_2339 belowPos = new class_2338.class_2339();

        Iterable<class_2338> positions = class_2338.method_10094(
              class_3532.method_15357(pigeon.method_23317() - 3.0), class_3532.method_15357(pigeon.method_23318() - 6.0), class_3532.method_15357(pigeon.method_23321() - 3.0),
              class_3532.method_15357(pigeon.method_23317() + 3.0), class_3532.method_15357(pigeon.method_23318() + 6.0), class_3532.method_15357(pigeon.method_23321() + 3.0)
        );

        for (class_2338 pos : positions) {
            if (currentPos.equals(pos)) {
                continue;
            }

            class_2680 stateBelow = pigeon.method_37908().method_8320(belowPos.method_25505(pos, class_2350.field_11033));
            if (stateBelow.method_26164(Envelope.Tags.Blocks.PIGEONS_PERCHABLE_ON)
                  && isPathfindable(pos)
                  && isPathfindable(abovePos.method_25505(pos, class_2350.field_11036))) {
                return class_243.method_24955(pos);
            }
        }

        return null;
    }

    protected boolean isPathfindable(class_2338 pos) {
        return pigeon.method_37908().method_22347(pos) || pigeon.method_37908().method_8320(pos).method_26171(class_10.field_51);
    }
}