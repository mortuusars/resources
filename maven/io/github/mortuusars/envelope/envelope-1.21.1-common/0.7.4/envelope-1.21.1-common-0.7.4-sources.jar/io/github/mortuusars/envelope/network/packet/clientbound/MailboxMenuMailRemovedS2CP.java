package io.github.mortuusars.envelope.network.packet.clientbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.packet.Packet;
import io.github.mortuusars.envelope.world.inventory.MailboxMenu;
import io.github.mortuusars.envelope.world.item.component.Id;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

/**
 * Updates the client when mail is removed from the storage by hopper or something.
 */
public record MailboxMenuMailRemovedS2CP(Id id) implements Packet {
    public static final class_2960 ID = Envelope.resource("mailbox_menu_mail_removed");
    public static final class_9154<MailboxMenuMailRemovedS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, MailboxMenuMailRemovedS2CP> STREAM_CODEC = class_9139.method_56434(
          Id.STREAM_CODEC, MailboxMenuMailRemovedS2CP::id,
          MailboxMenuMailRemovedS2CP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (!(player.field_7512 instanceof MailboxMenu menu)) {
            Envelope.LOGGER.error("Cannot handle '{}' packet: Player '{}' does not have MailboxMenu open.", ID, player);
            return false;
        }

        menu.onMailRemoved(id);
        return true;
    }
}
