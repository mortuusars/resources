package io.github.mortuusars.envelope.world.inventory.slot;

import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class PickupOnlySlot extends class_1735 {
    public PickupOnlySlot(class_1263 container, int slot, int x, int y) {
        super(container, slot, x, y);
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return false;
    }
}