package io.github.mortuusars.envelope.client.gui.screen;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.gui.Sprites;
import io.github.mortuusars.envelope.client.gui.widget.textbox.TextBox;
import io.github.mortuusars.envelope.client.gui.widget.textbox.text.FormattedString;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.integration.jei.JeiCompatibleScreen;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.serverbound.LetterEditC2SP;
import io.github.mortuusars.envelope.util.ItemAndStack;
import io.github.mortuusars.envelope.world.item.LetterAndQuillItem;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_364;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7919;
import net.minecraft.class_8666;
import org.jetbrains.annotations.Nullable;

public class LetterEditScreen extends class_437 implements JeiCompatibleScreen {
    public static final class_2960 TEXTURE = Envelope.resource("textures/gui/letter_and_quill.png");
    public static final class_8666 FOLD_BUTTON_SPRITES = Sprites.threeStates(Envelope.resource("letter_and_quill/fold_button"));

    protected final ItemAndStack<LetterAndQuillItem> letter;
    protected final class_1268 hand;

    protected int imageWidth, imageHeight, leftPos, topPos;
    protected TextBox textBox;
    protected class_344 foldButton;

    public LetterEditScreen(class_1799 letter, class_1268 hand) {
        super(class_2561.method_43473());
        this.letter = new ItemAndStack<>(letter);
        this.hand = hand;
    }

    @Override
    public boolean method_25421() {
        return Config.Server.LETTER_PAUSE.get();
    }

    @Override
    protected void method_25426() {
        imageWidth = 176;
        imageHeight = 192;
        leftPos = (field_22789 - imageWidth) / 2;
        topPos = (field_22790 - imageHeight) / 2;

        textBox = method_37063(new TextBox(field_22793, leftPos + 17, topPos + 21, 142, 144)
              .setFontColor(0xFF7B593D)
              .setFontUnfocusedColor(0xFF7B593D)
              .setSelectionColor(0xFF664488)
              .setSelectionUnfocusedColor(0xFF696170)
              .setHintColor(0xFFC2A57F)
              .setText(FormattedString.parse(letter.map(LetterAndQuillItem::getContent).text())));

        foldButton = method_37063(new class_344(
              leftPos + imageWidth + 5, topPos + 144,
              18, 18,
              FOLD_BUTTON_SPRITES,
              btn -> {
                  saveChanges(true);
                  Minecrft.get().method_1507(null);
              },
              class_2561.method_43471("envelope.letter_and_quill.fold_button")));
        foldButton.method_47400(class_7919.method_47407(class_2561.method_43471("envelope.letter_and_quill.fold_button")
              .method_10852(class_5244.field_33849)
              .method_10852(class_2561.method_43471("envelope.letter_and_quill.fold_warning").method_27692(class_124.field_1080))));

        method_48265(textBox);
    }

    @Override
    public void method_25410(class_310 minecraft, int width, int height) {
        // Prevent contents reset when window is resized
        FormattedString message = textBox.getEditor().getText();
        int messageCursorPos = textBox.getEditor().getCursorPos();
        super.method_25410(minecraft, width, height);
        textBox.getEditor().setText(message);
        textBox.getEditor().setCursorPos(messageCursorPos, false);
    }

    // -- Render

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.method_52752(guiGraphics);
        guiGraphics.method_25302(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);
    }

    // -- Input

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        // Special handling for toolbar, without this clicks will go to another element under the cursor,
        // if toolbar is over that element.
        if (method_25399() instanceof TextBox box && box.formattingToolbarMouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (!(method_25399() instanceof TextBox)) {
            if (class_310.method_1551().field_1690.field_1822.method_1417(keyCode, scanCode)) {
                this.method_25419();
                return true;
            }
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        @Nullable class_364 lastFocused = method_25399();
        super.method_25395(focused);
        // Clear selection if focus changes:
        if (lastFocused != null && !lastFocused.equals(method_25399()) && lastFocused instanceof TextBox box) {
            box.getEditor().clearSelection();
            box.getDisplayCache().scheduleUpdate();
        }
    }

    // --

    @Override
    public void method_25419() {
        super.method_25419();
        saveChanges(false);
    }

    protected void saveChanges(boolean fold) {
        String text = textBox.getEditor().getText().toString();

        int slot = this.hand == class_1268.field_5808 ? Minecrft.player().method_31548().field_7545 : class_1661.field_30639;
        Packets.sendToServer(new LetterEditC2SP(slot, text, fold));
    }

    // --

    @Override
    public boolean shouldBlockJeiInput() {
        // Always block JEI input, as this screen does not have jei showing,
        // but hotkeys such as Ctrl + O will still hide JEI if pressed.
        return true;
    }
}
