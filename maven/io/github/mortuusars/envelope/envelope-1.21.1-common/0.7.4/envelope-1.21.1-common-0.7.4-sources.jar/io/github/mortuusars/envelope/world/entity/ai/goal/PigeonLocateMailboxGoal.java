package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.integration.sable.ContraptionTargets;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlockEntity;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.mail.MailService;
import java.util.List;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_4153;
import net.minecraft.class_4156;

public class PigeonLocateMailboxGoal extends class_1352 {
    protected final Pigeon pigeon;

    public PigeonLocateMailboxGoal(Pigeon pigeon) {
        this.pigeon = pigeon;
    }

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public boolean method_6264() {
        return MailService.operatesIn(pigeon.method_37908())
              && !pigeon.isDelivering()
              && pigeon.canStartDelivery()
              && pigeon.getMailboxHandler().getLocateCooldown() <= 0
              && pigeon.getMailboxHandler().getTargetPos() == null
              && pigeon.method_37908().method_8409().method_43057() < 0.05;
    }

    @Override
    public boolean method_6266() {
        return false;
    }

    @Override
    public void method_6269() {
        pigeon.getMailboxHandler().resetLocateCooldown();
        List<class_2338> mailboxes = findNearbyAvailableMailboxes();
        if (!mailboxes.isEmpty()) {
            for (class_2338 pos : mailboxes) {
                if (!pigeon.getMailboxHandler().isTargetBlacklisted(pos)) {
                    pigeon.getMailboxHandler().setTargetPos(pos);
                    return;
                }
            }

            pigeon.getMailboxHandler().clearBlacklist();
            pigeon.getMailboxHandler().setTargetPos(mailboxes.getFirst());
        }
    }

    private List<class_2338> findNearbyAvailableMailboxes() {
        class_3218 level = (class_3218) pigeon.method_37908();
        int radius = 20;
        class_4153 poiManager = level.method_19494();
        List<class_2338> poiResults = poiManager.method_19125(holder ->
                    holder.method_40225(Envelope.PoiTypes.MAILBOX), pigeon.method_24515(), radius, class_4153.class_4155.field_18489)
              .map(class_4156::method_19141)
              .filter(p -> level.method_8321(p) instanceof MailboxBlockEntity mailbox
                    && mailbox.isAvailableForPickup())
              .toList();

        return ContraptionTargets.locateNearby(
              level,
              pigeon.method_19538(),
              radius,
              poiResults,
              () -> ContraptionTargets.findNearbyMailboxes(
                    level, pigeon.method_19538(), radius, MailboxBlockEntity::isAvailableForPickup));
    }
}
