package io.github.mortuusars.envelope.world.item.crafting.mail;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2371;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;

public class MailCraftingRecipe implements MailRecipe {
    private final ServiceAddress address;
    private final class_2371<class_1856> ingredients;
    private final class_1799 result;
    private final float experience;

    public MailCraftingRecipe(ServiceAddress address, class_2371<class_1856> ingredients, class_1799 result, float experience) {
        this.address = address;
        this.ingredients = ingredients;
        this.result = result;
        this.experience = experience;
    }

    @Override
    public ServiceAddress getAddress() {
        return address;
    }

    @Override
    public @NotNull class_2371<class_1856> method_8117() {
        return ingredients;
    }

    public class_1799 getResult() {
        return result;
    }

    @Override
    public float getExperience() {
        return experience;
    }

    @Override
    public @NotNull class_1799 method_8110(class_7225.class_7874 registries) {
        return result;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return Envelope.RecipeSerializers.MAIL_CRAFTING.get();
    }

    @Override
    public String toString() {
        return getClass().getName() + "{" +
              "address=" + address +
              ", ingredients=" + ingredients +
              ", result=" + result +
              (experience > 0 ? ", experience=" + experience : "") +
              '}';
    }
}
