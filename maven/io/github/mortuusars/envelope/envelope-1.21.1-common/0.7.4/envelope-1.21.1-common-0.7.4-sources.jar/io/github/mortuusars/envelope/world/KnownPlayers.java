package io.github.mortuusars.envelope.world;

import com.mojang.authlib.GameProfile;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import io.github.mortuusars.envelope.world.mail.address.type.PlayerAddress;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import net.minecraft.class_1657;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_3218;
import net.minecraft.class_5699;
import net.minecraft.class_7225;

public class KnownPlayers extends class_18 {
    public static final Codec<KnownPlayers> CODEC = Codec.unboundedMap(Codec.STRING, PlayerData.CODEC)
          .xmap(KnownPlayers::new, KnownPlayers::getData);

    protected final Map<String, PlayerData> data;
    protected @Nullable Set<PlayerAddress> addresses;
    protected @Nullable Map<PlayerAddress, BlockAddress> defaultAddresses;

    public KnownPlayers(Map<String, PlayerData> data) {
        this.data = new HashMap<>(data); // Make sure it's modifiable
    }

    public KnownPlayers() {
        this(Collections.emptyMap());
    }

    protected Map<String, PlayerData> getData() {
        return data;
    }

    // --

    public void add(class_1657 player) {
        if (player.method_5820().equalsIgnoreCase("replay viewer")) {
            // Flashback mod uses space in the player name, which causes an error.
            // A mod about pigeons should not validate player names by the mojang's rules.
            return;
        }
        data.computeIfAbsent(player.method_5820(), name -> new PlayerData(player.method_7334()));
        method_80();
    }

    public void remove(String name) {
        if (data.remove(name) != null) {
            method_80();
        }
    }

    public void clear() {
        data.clear();
        method_80();
    }

    // --

    public Optional<PlayerData> getDataOf(String playerName) {
        return Optional.ofNullable(data.get(playerName));
    }

    public Optional<PlayerData> getDataOf(UUID uuid) {
        return data.values().stream().filter(d -> d.profile.getId().equals(uuid)).findFirst();
    }

    // --

    public Optional<BlockAddress> getDefaultAddressOf(class_1657 player) {
        return getDataOf(player.method_5820()).flatMap(PlayerData::getDefaultAddress);
    }

    public Optional<BlockAddress> getDefaultAddressOf(PlayerAddress playerAddress) {
        return getDataOf(playerAddress.getString()).flatMap(PlayerData::getDefaultAddress);
    }

    public void setDefaultAddress(class_1657 player, BlockAddress address) {
        update(player, data -> data.setDefaultAddress(address));
    }

    public void renameDefaultAddress(BlockAddress oldAddress, BlockAddress newAddress) {
        getData().values().forEach(data -> {
            if (data.getDefaultAddress().map(a -> a.equals(oldAddress)).orElse(false)) {
                data.setDefaultAddress(newAddress);
            }
        });
        method_80();
    }

    public void removeDefaultAddress(BlockAddress address) {
        getData().values().forEach(data -> {
            if (data.getDefaultAddress().map(a -> a.equals(address)).orElse(false)) {
                data.setDefaultAddress(null);
            }
        });
        method_80();
    }

    // --

    public void update(class_1657 player, Consumer<PlayerData> updater) {
        data.compute(player.method_5820(), (name, data) -> {
            if (data == null) {
                data = new PlayerData(player.method_7334());
            }
            updater.accept(data);
            return data;
        });
        method_80();
    }

    // --

    public @NotNull Set<PlayerAddress> getAllAddresses() {
        if (addresses == null) {
            addresses = data.keySet().stream()
                  .map(PlayerAddress::new)
                  .collect(Collectors.toSet());
        }
        return addresses;
    }

    public Map<PlayerAddress, BlockAddress> getDefaultAddresses() {
        if (defaultAddresses == null) {
            defaultAddresses = new HashMap<>();
            getData().forEach((name, data) ->
                  data.getDefaultAddress().ifPresent(defaultAddress -> defaultAddresses.put(data.getAddress(), defaultAddress)));
        }
        return defaultAddresses;
    }

    @Override
    public void method_80() {
        super.method_80();
        resetCache();
    }

    protected void resetCache() {
        addresses = null;
        defaultAddresses = null;
    }

    // -- Save / Load

    public static KnownPlayers get(class_3218 level, String name) {
        return level.method_17983().method_17924(factory(), name);
    }

    @Override
    public @NotNull class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
        return CODEC.encode(this, class_2509.field_11560, tag)
                .ifError(e -> Envelope.LOGGER.error("Cannot save KnownPlayers: {}", e.message()))
                .result()
                .filter(t -> t instanceof class_2487)
                .map(t -> ((class_2487) t))
                .orElse(tag);
    }

    private static KnownPlayers load(class_2487 tag, class_7225.class_7874 registries) {
        return CODEC.decode(class_2509.field_11560, tag)
                .ifError(e -> Envelope.LOGGER.error("Cannot load KnownPlayers: {}", e.message()))
                .result().map(Pair::getFirst).orElseGet(KnownPlayers::new);
    }

    private static class_8645<KnownPlayers> factory() {
        return new class_8645<>(KnownPlayers::new, KnownPlayers::load, null);
    }

    // --

    public static class PlayerData {
        public static final Codec<PlayerData> CODEC = RecordCodecBuilder.create(i -> i.group(
              class_5699.field_45076.codec().fieldOf("profile").forGetter(PlayerData::getProfile),
              BlockAddress.STRING_CODEC.optionalFieldOf("default_address").forGetter(PlayerData::getDefaultAddress)
        ).apply(i, PlayerData::new));

        protected final GameProfile profile;
        protected final PlayerAddress address;
        protected Optional<BlockAddress> defaultAddress;

        public PlayerData(GameProfile profile, Optional<BlockAddress> defaultAddress) {
            this.profile = profile;
            this.address = new PlayerAddress(profile.getName());
            this.defaultAddress = defaultAddress;
        }

        public PlayerData(GameProfile profile) {
            this(profile, Optional.empty());
        }

        public GameProfile getProfile() {
            return profile;
        }

        public PlayerAddress getAddress() {
            return address;
        }

        public Optional<BlockAddress> getDefaultAddress() {
            return defaultAddress;
        }

        public void setDefaultAddress(@Nullable BlockAddress address) {
            this.defaultAddress = Optional.ofNullable(address);
        }
    }
}
