package io.github.mortuusars.envelope.world.mail.address.type;

import com.mojang.serialization.*;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.service.ServiceAddressDefinition;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;
import java.util.Optional;
import net.minecraft.class_5250;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_6899;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class ServiceAddress implements Address {
    public static final MapCodec<ServiceAddress> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
          class_6899.method_40400(Envelope.Registries.SERVICE_ADDRESS_DEFINITION)
                .fieldOf("definition")
                .forGetter(ServiceAddress::getDefinitionHolder)
    ).apply(i, ServiceAddress::new));

    public static final Codec<ServiceAddress> DEFINITION_CODEC = class_6899.method_40400(Envelope.Registries.SERVICE_ADDRESS_DEFINITION)
          .xmap(ServiceAddress::new, ServiceAddress::getDefinitionHolder);

    public static final class_9139<class_9129, ServiceAddress> STREAM_CODEC = class_9139.method_56434(
          class_9135.method_56383(Envelope.Registries.SERVICE_ADDRESS_DEFINITION), ServiceAddress::getDefinitionHolder,
          ServiceAddress::new
    );

    private final class_6880<ServiceAddressDefinition> definition;

    public ServiceAddress(class_6880<ServiceAddressDefinition> definition) {
        this.definition = definition;
    }

    @Override
    public Type getType() {
        return Type.SERVICE;
    }

    public class_6880<ServiceAddressDefinition> getDefinitionHolder() {
        return definition;
    }

    public ServiceAddressDefinition getDefinition() {
        return getDefinitionHolder().comp_349();
    }

    @Override
    public String getString() {
        return getDefinition().name().getString();
    }

    @Override
    public class_5250 getComponent() {
        return getDefinition().name().method_27661();
    }

    // --

    @SuppressWarnings("deprecation")
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        ServiceAddress that = (ServiceAddress) o;
        return definition.method_55838(that.getDefinitionHolder());
    }

    @Override
    public int hashCode() {
        return ("s" + getString().toLowerCase(Locale.ROOT)).hashCode();
    }

    @Override
    public @NotNull String toString() {
        return "Service[" + getString() + "]";
    }

    // --

    public static ServiceAddress getOrThrow(class_7225.class_7874 registries, class_5321<ServiceAddressDefinition> key) {
        return new ServiceAddress(getHolderOrThrow(registries, key));
    }

    public static Optional<ServiceAddress> get(class_7225.class_7874 registries, class_5321<ServiceAddressDefinition> key) {
        return getHolder(registries, key).map(ServiceAddress::new);
    }

    public static class_6880.class_6883<ServiceAddressDefinition> getHolderOrThrow(class_7225.class_7874 registries, class_5321<ServiceAddressDefinition> key) {
        return registries.method_46762(Envelope.Registries.SERVICE_ADDRESS_DEFINITION).method_46747(key);
    }

    public static Optional<class_6880.class_6883<ServiceAddressDefinition>> getHolder(class_7225.class_7874 registries, class_5321<ServiceAddressDefinition> key) {
        return registries.method_46762(Envelope.Registries.SERVICE_ADDRESS_DEFINITION).method_46746(key);
    }
}