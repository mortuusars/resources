package io.github.mortuusars.envelope.world.item.crafting.mail;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import org.slf4j.Logger;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_3218;
import net.minecraft.class_8786;

public class Mailing {
    private static final Logger LOGGER = LogUtils.getLogger();

    public static List<class_8786<MailRecipe>> getAllRecipes(class_3218 level) {
        return level.method_8433().method_30027(Envelope.RecipeTypes.MAILING.get());
    }

    public static Stream<class_8786<MailRecipe>> getAllRecipesOf(ServiceAddress address, class_3218 level) {
        return getAllRecipes(level)
              .stream()
              .filter(recipeHolder -> recipeHolder.comp_1933().getAddress().equals(address));
    }

    public static Optional<class_8786<MailRecipe>> findMatchingRecipe(ServiceAddress address, MailRecipeInput input, class_3218 level) {
        return getAllRecipesOf(address, level)
              .filter(recipeHolder -> recipeHolder.comp_1933().matches(input, level))
              .findFirst();
    }

    // --

    public static Result craft(MailRecipe recipe, MailRecipeInput input) {
        class_1277 outputContainer = new class_1277(PackageContents.SLOTS);
        int experience = 0;

        do {
            if (!outputContainer.method_27070(recipe.assemble(input, input.level().method_30349()))) {
                break;
            }

            class_1799 result = recipe.assembleWithSideEffects(input, input.level().method_30349());
            consumeInputs(recipe, input);
            experience += recipe.getExperiencePoints();

            if (!outputContainer.method_5491(result).method_7960()) {
                LOGGER.error("Unable to insert mail crafting result '{}' without a remainder into package container {}. " +
                      "Part of the result will be voided.", result, outputContainer);
            }

            if (recipe.isOneCraftPerDelivery()) {
                break;
            }

            if (!PackageContents.canHold(result)) {
                // If package cannot hold a result, then it's likely another package.
                // Stop the crafting to return only one package.
                break;
            }
        }
        while (recipe.matches(input, input.level()));

        return new Result(input, outputContainer.method_24514(), experience);
    }

    public static void consumeInputs(MailRecipe recipe, MailRecipeInput input) {
        class_2371<class_1799> remainingItems = recipe.method_8111(input);

        for (int slot = 0; slot < input.items().size(); slot++) {
            class_1799 item = input.method_59984(slot);
            if (!item.method_7960()) {
                item.method_7934(1);
                input.setItem(slot, item);
            }

            class_1799 remainingItem = remainingItems.get(slot);
            if (!remainingItem.method_7960()) {
                if (item.method_7960()) {
                    input.setItem(slot, remainingItem);
                } else if (class_1799.method_31577(item, remainingItem)) {
                    remainingItem.method_7933(item.method_7947());
                    input.setItem(slot, remainingItem);
                } else {
                    LOGGER.warn("Cannot insert remaining item [{}] into slot [{}] while crafting '{}'. Input: {}",
                          remainingItem, slot, recipe, input);
                }
            }
        }
    }

    // --

    public record Result(MailRecipeInput input, List<class_1799> output, int experience) {
    }
}
