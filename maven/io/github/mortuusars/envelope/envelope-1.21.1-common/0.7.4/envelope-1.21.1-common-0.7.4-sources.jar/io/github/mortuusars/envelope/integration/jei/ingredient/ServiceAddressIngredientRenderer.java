package io.github.mortuusars.envelope.integration.jei.ingredient;

import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.util.EnvelopeSymbols;
import io.github.mortuusars.envelope.world.GameTime;
import io.github.mortuusars.envelope.world.mail.address.AddressFormatter;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import mezz.jei.api.ingredients.IIngredientRenderer;
import net.minecraft.class_124;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class ServiceAddressIngredientRenderer implements IIngredientRenderer<ServiceAddress> {
    @Override
    public void render(class_332 guiGraphics, ServiceAddress ingredient) {
        String address = ingredient.getString();
        String string = AddressFormatter.getIcon(ingredient)
              + EnvelopeSymbols.SMALL_SPACE
              + (!address.isEmpty() ? address.charAt(0) : "");

        guiGraphics.method_25300(Minecrft.get().field_1772, string, 9, 5, Colors.GUI_LABEL);
        guiGraphics.method_25300(Minecrft.get().field_1772, string, 8, 5, Colors.ADDRESS_NEUTRAL);
    }

    @Override
    public @NotNull List<class_2561> getTooltip(ServiceAddress ingredient, class_1836 tooltipFlag) {
        if (tooltipFlag.method_8035()) {
            int travelDuration = ingredient.getDefinition().location().getTravelDurationTo(Minecrft.player().method_24515()).ticks();
            return List.of(
                  ingredient.format().withIcon().toComponent(),
                  class_2561.method_43470("⌚" + EnvelopeSymbols.SMALL_SPACE)
                        .method_10852(GameTime.format(travelDuration, true)).method_27692(class_124.field_1080));
        } else {
            return List.of(ingredient.format().withIcon().toComponent());
        }
    }
}
