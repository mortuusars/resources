package io.github.mortuusars.envelope.network.packet.clientbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.handler.ClientPacketsHandler;
import io.github.mortuusars.envelope.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record OpenLetterBlockViewScreenS2CP(class_1799 letter, class_2338 pos) implements Packet {
    public static final class_2960 ID = Envelope.resource("open_letter_block_view_screen");
    public static final class_9154<OpenLetterBlockViewScreenS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, OpenLetterBlockViewScreenS2CP> STREAM_CODEC = class_9139.method_56435(
          class_1799.field_48349, OpenLetterBlockViewScreenS2CP::letter,
          class_2338.field_48404, OpenLetterBlockViewScreenS2CP::pos,
          OpenLetterBlockViewScreenS2CP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        ClientPacketsHandler.openPlacedLetterViewScreen(this);
        return true;
    }
}
