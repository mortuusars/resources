package io.github.mortuusars.envelope.util.component;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.NotNull;

import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_6007;
import net.minecraft.class_6008;
import net.minecraft.class_8824;

public class WeightedComponent implements class_6008 {
    public static final Codec<WeightedComponent> FULL_CODEC = RecordCodecBuilder.create(i -> i.group(
          class_8824.field_46597.optionalFieldOf("component", class_2561.method_43473()).forGetter(WeightedComponent::getComponent),
          class_6007.field_29927.optionalFieldOf("weight", class_6007.method_34977(1)).forGetter(WeightedComponent::method_34979)
    ).apply(i, WeightedComponent::new));

    public static final Codec<WeightedComponent> CODEC = Codec.either(class_8824.field_46597, FULL_CODEC)
          .xmap(regularOrWeighted -> regularOrWeighted.map(WeightedComponent::new, Function.identity()),
                WeightedComponent::asEither);

    private final class_2561 component;
    private final class_6007 weight;

    public WeightedComponent(class_2561 component, class_6007 weight) {
        this.component = component;
        this.weight = weight;
    }

    public WeightedComponent(class_2561 component) {
        this.component = component;
        this.weight = class_6007.method_34977(1);
    }

    public class_2561 getComponent() {
        return component;
    }

    @Override
    public @NotNull class_6007 method_34979() {
        return weight;
    }

    public Either<class_2561, WeightedComponent> asEither() {
        if (method_34979().method_34976() <= 1) {
            return Either.left(getComponent());
        } else {
            return Either.right(this);
        }
    }
}