package io.github.mortuusars.envelope.client.gui.screen;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.inventory.PaybackPackageMenu;
import io.github.mortuusars.envelope.world.inventory.slot.PreviewSlot;
import io.github.mortuusars.envelope.world.item.PaybackPackageItem;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public class PaybackPackageScreen extends AbstractInHandContainerScreen<PaybackPackageMenu> {
    public static final class_2960 TEXTURE = Envelope.resource("textures/gui/payback_package.png");

    public PaybackPackageScreen(PaybackPackageMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title, TEXTURE);
    }

    @Override
    protected void method_25426() {
        field_2792 = 176;
        field_2779 = 178;
        super.method_25426();
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        super.method_2389(guiGraphics, partialTick, mouseX, mouseY);

        if (method_17577().isDestroyedOnClose()) {
            guiGraphics.method_25302(TEXTURE, field_2776 + 45, field_2800 + 17, 0, 178, 86, 64);
        }
    }

    @Override
    protected @NotNull List<class_2561> method_51454(class_1799 stack) {
        List<class_2561> components = super.method_51454(stack);

        if (field_2787 instanceof PreviewSlot) {
            PaybackPackageItem.appendPaybackSubjectHoverText(components, method_17577().getPaybackSubject());
        }

        return components;
    }
}