package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.clientbound.OpenMailboxPlacingScreenS2CP;
import io.github.mortuusars.envelope.world.mail.MailService;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1838;
import net.minecraft.class_2248;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;

public class MailboxBlockItem extends class_1747 {
    public MailboxBlockItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        if (!MailService.operatesIn(context.method_8045())
              || context.method_8041().method_57825(class_9334.field_49611, class_9279.field_49302).method_57450("address")) {
            return super.method_7884(context);
        }

        class_1750 blockPlaceContext = new class_1750(context);

        if (blockPlaceContext.method_7716()) {
            if (blockPlaceContext.method_8036() instanceof class_3222 serverPlayer) {
                var hitResult = new class_3965(context.method_17698(),
                      context.method_8038(), context.method_8037(), context.method_17699());
                var packet = new OpenMailboxPlacingScreenS2CP(context.method_20287(), hitResult,
                      MailService.of(serverPlayer.method_51469()).getKnownAddresses());
                Packets.sendToClient(packet, serverPlayer);
            }

            context.method_8045().method_8396(context.method_8036(), context.method_8037(),
                  getInitialSound(), class_3419.field_15245, 1, 1);

            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }

    protected @NotNull class_3414 getInitialSound() {
        return class_3417.field_14718;
    }
}
