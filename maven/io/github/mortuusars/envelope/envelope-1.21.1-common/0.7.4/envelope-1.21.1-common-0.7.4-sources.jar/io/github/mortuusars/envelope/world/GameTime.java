package io.github.mortuusars.envelope.world;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_5244;
import net.minecraft.class_5250;

public interface GameTime {
    long get();

    default int getAsInt() {
        return (int) get();
    }

    static GameTime of(class_1937 level) {
        return level::method_8510;
    }

    static GameTime at(long tick) {
        return () -> tick;
    }

    // --

    default GameTime fromNow(GameTime time) {
        return () -> get() + time.get();
    }

    default GameTime fromNow(long ticks) {
        return () -> get() + ticks;
    }

    default boolean hasPassed(GameTime time) {
        return hasPassed(time.get());
    }

    default boolean hasPassed(long tick) {
        return get() > tick;
    }

    default GameTime elapsedSince(GameTime time) {
        return () -> get() - time.get();
    }

    default GameTime elapsedSince(long tick) {
        return () -> get() - tick;
    }

    default GameTime remainingTo(GameTime time) {
        return () -> time.get() - get();
    }

    default GameTime remainingTo(long tick) {
        return () -> tick - get();
    }

    // --

    default class_5250 format(boolean withSeconds) {
        return format(get(), withSeconds);
    }

    default class_5250 formatLargest(boolean withSeconds) {
        return formatLargest(get(), withSeconds);
    }

    // --

    static class_5250 format(long ticks, boolean withSeconds) {
        long secondsTotal = ticks / 20;

        long years = secondsTotal / 31104000;
        secondsTotal %= 31104000;
        long months = secondsTotal / 2592000;
        secondsTotal %= 2592000;
        long weeks = secondsTotal / 604800;
        secondsTotal %= 604800;
        long days = secondsTotal / 86400;
        secondsTotal %= 86400;
        long hours = secondsTotal / 3600;
        secondsTotal %= 3600;
        long minutes = secondsTotal / 60;
        secondsTotal %= 60;
        long seconds = secondsTotal;

        List<class_2561> parts = new ArrayList<>();

        if (years > 0) parts.add(class_2561.method_43469("gui.envelope.time.years", years));
        if (months > 0) parts.add(class_2561.method_43469("gui.envelope.time.months", months));
        if (weeks > 0) parts.add(class_2561.method_43469("gui.envelope.time.weeks", weeks));
        if (days > 0) parts.add(class_2561.method_43469("gui.envelope.time.days", days));
        if (hours > 0) parts.add(class_2561.method_43469("gui.envelope.time.hours", hours));
        if (minutes > 0) parts.add(class_2561.method_43469("gui.envelope.time.minutes", minutes));
        if (withSeconds) {
            if (seconds > 0) parts.add(class_2561.method_43469("gui.envelope.time.seconds", seconds));
            else parts.add(class_2561.method_43471("gui.envelope.time.less_than_one_second"));
        }
        if (parts.isEmpty()) parts.add(class_2561.method_43471("gui.envelope.time.less_than_one_minute"));

        class_5250 result = class_2561.method_43473();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) result.method_10852(class_5244.field_41874);
            result.method_10852(parts.get(i));
        }

        return result;
    }

    static class_5250 formatLargest(long ticks, boolean withSeconds) {
        long secondsTotal = ticks / 20;

        long years = secondsTotal / 31104000;
        if (years > 0) return class_2561.method_43469("gui.envelope.time.years", years);
        secondsTotal %= 31104000;
        long months = secondsTotal / 2592000;
        if (months > 0) return class_2561.method_43469("gui.envelope.time.months", months);
        secondsTotal %= 2592000;
        long weeks = secondsTotal / 604800;
        if (weeks > 0) return class_2561.method_43469("gui.envelope.time.weeks", weeks);
        secondsTotal %= 604800;
        long days = secondsTotal / 86400;
        if (days > 0) return class_2561.method_43469("gui.envelope.time.days", days);
        secondsTotal %= 86400;
        long hours = secondsTotal / 3600;
        if (hours > 0) return class_2561.method_43469("gui.envelope.time.hours", hours);
        secondsTotal %= 3600;
        long minutes = secondsTotal / 60;
        if (minutes > 0) return class_2561.method_43469("gui.envelope.time.minutes", minutes);
        secondsTotal %= 60;
        long seconds = secondsTotal;
        if (withSeconds) {
            if (seconds > 0) return class_2561.method_43469("gui.envelope.time.minutes", minutes);
            else return class_2561.method_43471("gui.envelope.time.less_than_one_second");
        }
        return class_2561.method_43471("gui.envelope.time.less_than_one_minute");
    }
}