package io.github.mortuusars.envelope.api;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import io.github.mortuusars.envelope.world.mail.dropoff.MailDropOffHandler;
import io.github.mortuusars.envelope.world.mail.service.ServiceAddressDefinition;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public class ServiceDropOffHandlerRegistry {
    private static final Map<class_5321<ServiceAddressDefinition>, List<MailDropOffHandler>> handlers = new HashMap<>();

    public static void register(class_5321<ServiceAddressDefinition> definition, MailDropOffHandler handler) {
        List<MailDropOffHandler> list = handlers.computeIfAbsent(definition, key -> new ArrayList<>());
        list.add(handler);
        handlers.put(definition, list);
    }

    public static void register(class_2960 definition, MailDropOffHandler handler) {
        register(class_5321.method_29179(Envelope.Registries.SERVICE_ADDRESS_DEFINITION, definition), handler);
    }

    // --

    public static List<MailDropOffHandler> getHandlers(ServiceAddress address) {
        return address.getDefinitionHolder().method_40230()
              .map(key -> handlers.getOrDefault(key, List.of()))
              .orElse(List.of());
    }
}
