package io.github.mortuusars.envelope.network.packet.serverbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.packet.Packet;
import io.github.mortuusars.envelope.world.inventory.PaybackTagMenu;
import io.github.mortuusars.envelope.world.item.component.PaybackRequest;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record PaybackTagMenuSetSlotC2SP(int slotIndex, class_1799 item) implements Packet {
    public static final class_2960 ID = Envelope.resource("payback_tag_menu_set_slot");
    public static final class_9154<PaybackTagMenuSetSlotC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, PaybackTagMenuSetSlotC2SP> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48550, PaybackTagMenuSetSlotC2SP::slotIndex,
            class_1799.field_48349, PaybackTagMenuSetSlotC2SP::item,
            PaybackTagMenuSetSlotC2SP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (!(player.field_7512 instanceof PaybackTagMenu menu)) {
            Envelope.LOGGER.error("Cannot handle {} packet from {}: Player does not have PaybackTagMenu open.",
                  ID, player.method_5820());
            return false;
        }

        if (slotIndex < 0 || slotIndex > PaybackRequest.SLOTS) {
            Envelope.LOGGER.error("Cannot handle {} packet from {}: slot {} is not in valid range (0 - {}).",
                    ID, player.method_5820(), slotIndex, PaybackRequest.SLOTS);
            return false;
        }

        class_1735 slot = menu.field_7761.get(slotIndex);

        if (slot.field_7871 instanceof class_1661) { // Extra check to make sure it's not an inventory
            Envelope.LOGGER.error("Cannot handle {} packet from {}: slot {} is for player inventory O_O.",
                  ID, player.method_5820(), slotIndex);
            return false;
        }

        slot.method_53512(item);
        return true;
    }
}
