package io.github.mortuusars.envelope.world.entity.ai;

import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlock;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.mail.delivery.DeliveryPhase;
import net.minecraft.class_11;
import net.minecraft.class_1408;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

/**
 * Pathfinding and reach checks for pigeons interacting with local block targets.
 * <p>
 * Local {@link class_2338} values may live in a Sable sub-level plot grid; callers should pass those
 * stored positions and let {@link Position} project them when comparing or navigating.
 */
public final class PigeonNavigation {
    private PigeonNavigation() {
    }

    public static double getReachDistance() {
        return 1;
    }

    /**
     * Block in front of a mailbox face — where pigeons stand when approaching for delivery.
     */
    public static class_2338 getMailboxApproachTarget(class_1937 level, class_2338 mailboxPos) {
        class_2680 state = level.method_8320(mailboxPos);
        if (state.method_26204() instanceof MailboxBlock) {
            return mailboxPos.method_10093(state.method_11654(MailboxBlock.FACING));
        }
        return mailboxPos;
    }

    public static class_2338 getSegmentApproachTarget(class_1937 level, class_2338 segmentEndPos, DeliveryPhase phase) {
        return phase.isDescending()
              ? getMailboxApproachTarget(level, segmentEndPos)
              : segmentEndPos;
    }

    /**
     * Whether a pigeon has reached a local target block.
     * <ol>
     *   <li>Within {@code distance} in projected world space, or via legacy block-grid distance.</li>
     *   <li>Current path finished at the projected navigation target.</li>
     *   <li>Navigation idle at the projected target and within block-grid distance of it.</li>
     * </ol>
     */
    public static boolean hasReachedTarget(Pigeon pigeon, class_2338 localPos, double distance) {
        if (isWithinReach(pigeon, localPos, distance)) {
            return true;
        }

        class_1937 level = pigeon.method_37908();
        class_2338 navigationPos = Position.getNavigationPos(level, localPos);
        class_1408 navigation = pigeon.method_5942();
        @Nullable class_11 path = navigation.method_6345();

        if (path != null && path.method_21655() && path.method_46() && path.method_48().equals(navigationPos)) {
            return true;
        }

        class_2338 navigationTarget = navigation.method_6355();
        return !navigation.method_23966()
              && navigationTarget != null
              && navigationTarget.equals(navigationPos)
              && navigationTarget.method_19771(pigeon.method_24515(), distance);
    }

    public static boolean isWithinReach(Pigeon pigeon, class_2338 localPos, double distance) {
        return Position.isWithinReach(pigeon.method_37908(), localPos, pigeon.method_19538(), pigeon.method_24515(), distance);
    }

    public static class_2338 getNavigationPos(Pigeon pigeon, class_2338 localPos) {
        return Position.getNavigationPos(pigeon.method_37908(), localPos);
    }
}
