package io.github.mortuusars.envelope.world.mail.delivery;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.AddressLocation;
import io.github.mortuusars.envelope.world.mail.MailService;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3532;

/**
 * Describes a path courier takes to deliver mail.<br>
 * The idea is to create a route similar to how airplanes fly:<br>
 * Ascend to cruise height > Travel > Hub > Travel > Descend to destination. And back.
 */
public class DeliveryRoute {
    public static final Codec<DeliveryRoute> CODEC = RecordCodecBuilder.create(i -> i.group(
          AddressLocation.CODEC.fieldOf("sender_location").forGetter(DeliveryRoute::getSenderLocation),
          AddressLocation.CODEC.fieldOf("recipient_location").forGetter(DeliveryRoute::getRecipientLocation),
          class_2338.field_25064.optionalFieldOf("sender_pos").forGetter(DeliveryRoute::getSenderPos),
          class_2338.field_25064.optionalFieldOf("sender_ascend_pos").forGetter(DeliveryRoute::getSenderAscendPos),
          TravelDuration.CODEC.optionalFieldOf("sender_to_hub_duration", TravelDuration.DEFAULT).forGetter(DeliveryRoute::getSenderToHubDuration),
          class_2338.field_25064.optionalFieldOf("hub_pos").forGetter(DeliveryRoute::getHubPos),
          TravelDuration.CODEC.optionalFieldOf("recipient_to_hub_duration", TravelDuration.DEFAULT).forGetter(DeliveryRoute::getRecipientToHubDuration),
          class_2338.field_25064.optionalFieldOf("recipient_ascend_pos").forGetter(DeliveryRoute::getRecipientAscendPos),
          class_2338.field_25064.optionalFieldOf("recipient_pos").forGetter(DeliveryRoute::getRecipientPos)
    ).apply(i, DeliveryRoute::new));

    public static final DeliveryRoute EMPTY = new DeliveryRoute(
          AddressLocation.DEFAULT, AddressLocation.DEFAULT,
          Optional.empty(), Optional.empty(),
          TravelDuration.DEFAULT, Optional.empty(), TravelDuration.DEFAULT,
          Optional.empty(), Optional.empty());

    private final AddressLocation senderLocation;
    private final AddressLocation recipientLocation;
    private final Optional<class_2338> senderPos;
    private final Optional<class_2338> senderAscendPos;
    private final TravelDuration senderToHubDuration;
    private final Optional<class_2338> hubPos;
    private final TravelDuration recipientToHubDuration;
    private final Optional<class_2338> recipientAscendPos;
    private final Optional<class_2338> recipientPos;

    private @Nullable Map<DeliveryPhase, Segment> segments;

    public DeliveryRoute(AddressLocation senderLocation, AddressLocation recipientLocation,
                         Optional<class_2338> senderPos, Optional<class_2338> senderAscendPos,
                         TravelDuration senderToHubDuration, Optional<class_2338> hubPos, TravelDuration recipientToHubDuration,
                         Optional<class_2338> recipientAscendPos, Optional<class_2338> recipientPos) {
        this.senderLocation = senderLocation;
        this.recipientLocation = recipientLocation;
        this.senderPos = senderPos;
        this.senderAscendPos = senderAscendPos;
        this.senderToHubDuration = senderToHubDuration;
        this.hubPos = hubPos;
        this.recipientToHubDuration = recipientToHubDuration;
        this.recipientAscendPos = recipientAscendPos;
        this.recipientPos = recipientPos;
    }

    public static DeliveryRoute build(class_3218 level, Address sender, Address recipient) {
        MailService mailService = MailService.of(level);

        AddressLocation senderLocation = mailService.getLocationOf(sender);
        AddressLocation recipientLocation = mailService.getLocationOf(recipient);

        Optional<class_2338> senderPos = senderLocation.getPosition();
        Optional<class_2338> recipientPos = recipientLocation.getPosition();
        Optional<class_2338> hubPos = getHubPosition(senderLocation, recipientLocation);

        return new DeliveryRoute(
              senderLocation,
              recipientLocation,
              senderPos,
              senderLocation.ascendTowards(level, hubPos),
              TravelDuration.basedOnDistance(senderLocation.getDistanceTo(level, hubPos)),
              hubPos,
              TravelDuration.basedOnDistance(recipientLocation.getDistanceTo(level, hubPos)),
              recipientLocation.ascendTowards(level, hubPos),
              recipientPos);
    }

    public static Optional<class_2338> getHubPosition(AddressLocation senderLocation, AddressLocation recipientLocation) {
        return senderLocation.getNearestHub().or(recipientLocation::getNearestHub);
    }

    // --

    public AddressLocation getSenderLocation() {
        return senderLocation;
    }

    public AddressLocation getRecipientLocation() {
        return recipientLocation;
    }

    public Optional<class_2338> getSenderPos() {
        return senderPos;
    }

    public Optional<class_2338> getSenderAscendPos() {
        return senderAscendPos;
    }

    public TravelDuration getSenderToHubDuration() {
        return senderToHubDuration;
    }

    public Optional<class_2338> getHubPos() {
        return hubPos;
    }

    public TravelDuration getRecipientToHubDuration() {
        return recipientToHubDuration;
    }

    public Optional<class_2338> getRecipientAscendPos() {
        return recipientAscendPos;
    }

    public Optional<class_2338> getRecipientPos() {
        return recipientPos;
    }

    public TravelDuration getFullTravelDuration() {
        return new TravelDuration(getSenderToHubDuration().ticks() + getRecipientToHubDuration().ticks());
    }

    public int getDistance(class_1937 level) {
        return senderLocation.getDistanceTo(level, hubPos)
              + recipientLocation.getDistanceTo(level, hubPos);
    }

    // --

    public Segment getSegment(DeliveryPhase phase) {
        if (segments == null) {
            segments = buildSegments();
        }
        return Objects.requireNonNull(segments.get(phase));
    }

    protected Map<DeliveryPhase, Segment> buildSegments() {
        Map<DeliveryPhase, Segment> map = new HashMap<>();
        map.put(DeliveryPhase.STARTED, new Segment(senderPos, senderPos));
        map.put(DeliveryPhase.DEPARTING_SENDER, new Segment(senderPos, senderAscendPos));
        map.put(DeliveryPhase.TRAVELING_FROM_SENDER_TO_HUB, new Segment(senderAscendPos, hubPos));
        map.put(DeliveryPhase.DISPATCHING_DELIVERY, new Segment(hubPos, hubPos));
        map.put(DeliveryPhase.TRAVELING_FROM_HUB_TO_RECIPIENT, new Segment(hubPos, recipientAscendPos));
        map.put(DeliveryPhase.APPROACHING_RECIPIENT, new Segment(recipientAscendPos, recipientPos));
        map.put(DeliveryPhase.HANDLING_DELIVERY, new Segment(recipientPos, recipientPos));
        map.put(DeliveryPhase.DEPARTING_RECIPIENT, new Segment(recipientPos, recipientAscendPos));
        map.put(DeliveryPhase.TRAVELING_FROM_RECIPIENT_TO_HUB, new Segment(recipientAscendPos, hubPos));
        map.put(DeliveryPhase.DISPATCHING_RETURN, new Segment(hubPos, hubPos));
        map.put(DeliveryPhase.TRAVELING_FROM_HUB_TO_SENDER, new Segment(hubPos, senderAscendPos));
        map.put(DeliveryPhase.APPROACHING_SENDER, new Segment(senderAscendPos, senderPos));
        map.put(DeliveryPhase.HANDLING_RETURN, new Segment(senderPos, senderPos));
        map.put(DeliveryPhase.FINISHED, new Segment(senderPos, senderPos));
        Preconditions.checkState(map.size() == DeliveryPhase.values().length, "Built segments do not cover all delivery phases!");
        return map;
    }

    public record Segment(Optional<class_2338> startPos, Optional<class_2338> endPos) {
        public static final Segment EMPTY = new Segment(Optional.empty(), Optional.empty());

        public Optional<class_2338> getCurrentLocation(class_1937 level, float progress) {
            if (startPos().isPresent() && endPos().isPresent()) {
                class_243 pos = Position.lerp(level, startPos().get(), endPos().get(), class_3532.method_15363(progress, 0, 1));
                return Optional.of(class_2338.method_49638(pos));
            }
            return Optional.empty();
        }
    }
}