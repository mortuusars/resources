package io.github.mortuusars.envelope.client.gui.tooltip;

import org.joml.Matrix4f;

import java.util.List;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4597;
import net.minecraft.class_5684;

public class CompositeTooltipComponent implements class_5684 {
    private final List<class_5684> components;

    public CompositeTooltipComponent(List<class_5684> components) {
        this.components = components;
    }

    @Override
    public int method_32664(class_327 font) {
        int width = 0;
        for (class_5684 component : components) {
            width = Math.max(component.method_32664(font), width);
        }
        return width;
    }

    @Override
    public int method_32661() {
        int height = 0;
        for (class_5684 component : components) {
            height += component.method_32661();
        }
        return height;
    }

    @Override
    public void method_32666(class_327 font, int x, int y, class_332 guiGraphics) {
        for (class_5684 component : components) {
            component.method_32666(font, x, y, guiGraphics);
            y += component.method_32661();
        }
    }

    @Override
    public void method_32665(class_327 font, int mouseX, int mouseY, Matrix4f matrix, class_4597.class_4598 bufferSource) {
        for (class_5684 component : components) {
            component.method_32665(font, mouseX, mouseY, matrix, bufferSource);
            mouseY += component.method_32661();
        }
    }
}
