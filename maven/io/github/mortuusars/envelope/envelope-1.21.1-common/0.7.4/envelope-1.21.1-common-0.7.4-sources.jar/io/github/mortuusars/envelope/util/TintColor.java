package io.github.mortuusars.envelope.util;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_3532;
import net.minecraft.class_5253;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Approximation of hard-light blend mode to calculate tint.<br>
 * Color brighter than 50% will produce brighter image, lower than 50% - darker.<br><br>
 * It's not 1:1, but I don't know of a closer solution.
 * setShaderColor seems to behave slightly differently than anything that I can do in photoshop.
 */
public record TintColor(float r, float g, float b, float a) {
    public static final Codec<TintColor> CODEC = EnvelopeCodecs.HEX_COLOR.xmap(TintColor::of, TintColor::tint);
    public static final class_9139<ByteBuf, TintColor> STREAM_CODEC = class_9135.field_49675.method_56432(TintColor::of, TintColor::tint);

    public static TintColor of(int argb) {
        float a = (float) (class_5253.class_5254.method_27762(argb) - 127) / 127 + 1;
        float r = (float) (class_5253.class_5254.method_27765(argb) - 127) / 127 + 1;
        float g = (float) (class_5253.class_5254.method_27766(argb) - 127) / 127 + 1;
        float b = (float) (class_5253.class_5254.method_27767(argb) - 127) / 127 + 1;
        return new TintColor(r, g, b, a);
    }

    public void setShaderColor() {
        RenderSystem.setShaderColor(r, g ,b, a);
    }

    public int tint(int argb) {
        int a = (int)class_3532.method_15363(class_5253.class_5254.method_27762(argb) * this.a, 0, 255);
        int r = (int)class_3532.method_15363(class_5253.class_5254.method_27765(argb) * this.r, 0, 255);
        int g = (int)class_3532.method_15363(class_5253.class_5254.method_27766(argb) * this.g, 0, 255);
        int b = (int)class_3532.method_15363(class_5253.class_5254.method_27767(argb) * this.b, 0, 255);
        return class_5253.class_5254.method_27764(a, r, g, b);
    }

    public int tint() {
        return tint(0xFF7F7F7F);
    }
}
