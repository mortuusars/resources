package io.github.mortuusars.envelope.world.block.occupiable;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import java.util.List;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9279;

public record Occupant(class_9279 entityData, int slot, int minTicksInside, int ticksInside) {
    public static final Codec<Occupant> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                class_9279.field_49303.optionalFieldOf("entity_data", class_9279.field_49302).forGetter(Occupant::entityData),
                Codec.INT.fieldOf("slot").forGetter(Occupant::slot),
                Codec.INT.fieldOf("min_ticks_inside").forGetter(Occupant::minTicksInside),
                Codec.INT.optionalFieldOf("ticks_inside", 0).forGetter(Occupant::ticksInside))
          .apply(instance, Occupant::new)
    );

    public static final Codec<List<Occupant>> LIST_CODEC = CODEC.listOf();

    @SuppressWarnings("deprecation")
    public static final class_9139<ByteBuf, Occupant> STREAM_CODEC = class_9139.method_56905(
          class_9279.field_49305, Occupant::entityData,
          class_9135.field_48550, Occupant::slot,
          class_9135.field_48550, Occupant::minTicksInside,
          class_9135.field_48550, Occupant::ticksInside,
          Occupant::new
    );

    public Mutable toMutable() {
        return new Mutable(this);
    }

    public static class Mutable {
        protected final Occupant occupant;
        protected int ticksInside;

        public Mutable(Occupant occupant) {
            this.occupant = occupant;
            this.ticksInside = occupant.ticksInside();
        }

        public Occupant getOccupant() {
            return occupant;
        }

        public int getTicksInside() {
            return ticksInside;
        }

        public boolean tick() {
            return this.ticksInside++ >= occupant.minTicksInside();
        }

        public Occupant toImmutable() {
            return new Occupant(occupant.entityData(), occupant.slot(), occupant.minTicksInside(), getTicksInside());
        }
    }
}