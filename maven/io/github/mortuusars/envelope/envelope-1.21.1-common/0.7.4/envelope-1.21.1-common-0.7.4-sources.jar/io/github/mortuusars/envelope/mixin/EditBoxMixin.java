package io.github.mortuusars.envelope.mixin;

import io.github.mortuusars.envelope.client.gui.screen.AddressTagScreen;
import io.github.mortuusars.envelope.client.util.Minecrft;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_342.class)
public abstract class EditBoxMixin extends class_339 {
    public EditBoxMixin(int x, int y, int width, int height, class_2561 message) {
        super(x, y, width, height, message);
    }

    // I hope no-one will try to do modify the same constant, because it will most likely crash.
    // But I don't see other easy ways to change the color.
    @ModifyConstant(method = "renderWidget", constant = @Constant(intValue = 0xFF808080))
    private int onRenderWidget(int constant) {
        if (Minecrft.get().field_1755 instanceof AddressTagScreen addressTagScreen) {
            return addressTagScreen.getSuggestionTextColor();
        }
        return constant;
    }

    // Purpose of scissoring here is to limit suggestion text to the widget bounds, otherwise it overflows.
    // You can clearly tell that mojang made half of features of EditBox for chat screen and never bothered to make them work elsewhere.
    @Inject(method = "renderWidget", at = @At("HEAD"))
    private void onRenderWidgetHead(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (Minecrft.get().field_1755 instanceof AddressTagScreen) {
            guiGraphics.method_44379(method_46426() - 1, method_46427(), method_46426() + method_25368() + 1, method_46427() + method_25364());
        }
    }

    @Inject(method = "renderWidget", at = @At("RETURN"))
    private void onRenderWidgetReturn(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (Minecrft.get().field_1755 instanceof AddressTagScreen) {
            guiGraphics.method_44380();
        }
    }
}