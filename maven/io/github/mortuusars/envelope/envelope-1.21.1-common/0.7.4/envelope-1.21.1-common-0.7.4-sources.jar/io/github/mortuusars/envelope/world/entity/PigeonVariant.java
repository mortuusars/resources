package io.github.mortuusars.envelope.world.entity;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import net.minecraft.class_1959;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5381;
import net.minecraft.class_5455;
import net.minecraft.class_5699;
import net.minecraft.class_5819;
import net.minecraft.class_6008;
import net.minecraft.class_6012;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_6895;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.core.*;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;

public record PigeonVariant(class_2960 texture, class_6885<class_1959> biomes, SpawningWeights weights, boolean inheritable) {
    public static final class_5321<PigeonVariant> GRAY =
          class_5321.method_29179(Envelope.Registries.PIGEON_VARIANT, Envelope.resource("gray"));
    public static final class_5321<PigeonVariant> BROWN =
          class_5321.method_29179(Envelope.Registries.PIGEON_VARIANT, Envelope.resource("brown"));
    public static final class_5321<PigeonVariant> WHITE =
          class_5321.method_29179(Envelope.Registries.PIGEON_VARIANT, Envelope.resource("white"));
    public static final class_5321<PigeonVariant> PASSENGER =
          class_5321.method_29179(Envelope.Registries.PIGEON_VARIANT, Envelope.resource("passenger"));
    public static final class_5321<PigeonVariant> CHARRED =
          class_5321.method_29179(Envelope.Registries.PIGEON_VARIANT, Envelope.resource("charred"));
    public static final class_5321<PigeonVariant> ARCHIMEDES =
          class_5321.method_29179(Envelope.Registries.PIGEON_VARIANT, Envelope.resource("archimedes"));
    public static final class_5321<PigeonVariant> DEFAULT = GRAY;

    // --

    public static final Codec<PigeonVariant> DIRECT_CODEC = RecordCodecBuilder.create(i -> i.group(
          class_2960.field_25139.fieldOf("texture").forGetter(PigeonVariant::texture),
          class_6895.method_40340(class_7924.field_41236).optionalFieldOf("spawn_biomes", class_6885.method_58563()).forGetter(PigeonVariant::biomes),
          SpawningWeights.CODEC.optionalFieldOf("spawn_weights", SpawningWeights.DEFAULT).forGetter(PigeonVariant::weights),
          Codec.BOOL.optionalFieldOf("inheritable", true).forGetter(PigeonVariant::inheritable)
    ).apply(i, PigeonVariant::new));

    public static final class_9139<class_9129, PigeonVariant> DIRECT_STREAM_CODEC = class_9139.method_56905(
          class_2960.field_48267, PigeonVariant::texture,
          class_9135.method_58001(class_7924.field_41236), PigeonVariant::biomes,
          SpawningWeights.STREAM_CODEC, PigeonVariant::weights,
          class_9135.field_48547, PigeonVariant::inheritable,
          PigeonVariant::new
    );

    public static final Codec<class_6880<PigeonVariant>> CODEC =
          class_5381.method_29749(Envelope.Registries.PIGEON_VARIANT, DIRECT_CODEC);

    public static final class_9139<class_9129, class_6880<PigeonVariant>> STREAM_CODEC =
          class_9135.method_56367(Envelope.Registries.PIGEON_VARIANT, DIRECT_STREAM_CODEC);

    // --

    public static Optional<class_6880.class_6883<PigeonVariant>> get(class_5455 registryAccess, class_5321<PigeonVariant> key) {
        return registryAccess.method_30530(Envelope.Registries.PIGEON_VARIANT).method_40264(key);
    }

    public static class_6880<PigeonVariant> getOrThrow(class_5455 registryAccess, class_5321<PigeonVariant> key) {
        return registryAccess.method_30530(Envelope.Registries.PIGEON_VARIANT).method_40290(key);
    }

    public static class_6880<PigeonVariant> getRandomSpawnVariant(class_5455 registryAccess, class_5819 random, class_6880<class_1959> biome) {
        return getRandomVariant(registryAccess, random,
              variant -> variant.biomes().method_40241(biome),
              variant -> variant.weights().biome())
              .orElseGet(() -> getRandomCommonVariant(registryAccess, random));
    }

    public static class_6880<PigeonVariant> getRandomCommonVariant(class_5455 registryAccess, class_5819 random) {
        return withFallback(registryAccess,
              getRandomVariant(registryAccess, random, variant -> variant.weights().common()));
    }

    public static class_6880<PigeonVariant> getRandomServiceVariant(class_5455 registryAccess, class_5819 random) {
        return withFallback(registryAccess,
              getRandomVariant(registryAccess, random, variant -> variant.weights().service()));
    }

    public static Optional<class_6880<PigeonVariant>> getRandomVariant(class_5455 registryAccess, class_5819 random, Function<PigeonVariant, Integer> weightGetter) {
        return getRandomVariant(registryAccess, random, variant -> true, weightGetter);
    }

    public static Optional<class_6880<PigeonVariant>> getRandomVariant(class_5455 registryAccess, class_5819 random, Predicate<PigeonVariant> filter, Function<PigeonVariant, Integer> weightGetter) {
        class_2378<PigeonVariant> registry = registryAccess.method_30530(Envelope.Registries.PIGEON_VARIANT);
        var variants = registry.method_40270()
              .filter(holder -> filter.test(holder.comp_349()))
              .map(variant -> class_6008.method_34980(variant, weightGetter.apply(variant.comp_349())))
              .toList();
        return class_6012.method_34988(variants)
              .method_34992(random)
              .map(class_6008.class_6010::comp_2542);
    }

    public static class_6880<PigeonVariant> withFallback(class_5455 registryAccess, Optional<class_6880<PigeonVariant>> variant) {
        class_2378<PigeonVariant> registry = registryAccess.method_30530(Envelope.Registries.PIGEON_VARIANT);
        return variant
              .or(() -> registry.method_40264(DEFAULT))
              .or(registry::method_60385)
              .orElseThrow();
    }

    public static String fromLegacyId(int variant) {
        var key = switch (variant) {
            case 1 -> BROWN;
            case 2 -> WHITE;
            case 3 -> PASSENGER;
            default -> DEFAULT;
        };
        return key.method_29177().toString();
    }

    public record SpawningWeights(int biome, int service, int common) {
        public static final Codec<SpawningWeights> CODEC = RecordCodecBuilder.create(i -> i.group(
              class_5699.field_33442.optionalFieldOf("biome", 1).forGetter(SpawningWeights::biome),
              class_5699.field_33441.optionalFieldOf("service", 0).forGetter(SpawningWeights::service),
              class_5699.field_33441.optionalFieldOf("common", 0).forGetter(SpawningWeights::common)
        ).apply(i, SpawningWeights::new));

        public static final class_9139<class_9129, SpawningWeights> STREAM_CODEC = class_9139.method_56436(
              class_9135.field_49675, SpawningWeights::biome,
              class_9135.field_49675, SpawningWeights::service,
              class_9135.field_49675, SpawningWeights::common,
              SpawningWeights::new
        );

        public static final SpawningWeights DEFAULT = new SpawningWeights(1, 0, 0);

        public SpawningWeights(int service, int common) {
            this(1, service, common);
        }
    }

    // --

    public static void bootstrap(class_7891<PigeonVariant> context) {
        register(context, GRAY, "gray", class_6885.method_58563(), new SpawningWeights(12, 10), true);
        register(context, BROWN, "brown", class_6885.method_58563(), new SpawningWeights(6, 5), true);
        register(context, WHITE, "white", class_6885.method_58563(), new SpawningWeights(2, 1), true);
        register(context, PASSENGER, "passenger", Envelope.Tags.Biomes.SPAWNS_PASSENGER_PIGEONS, new SpawningWeights(1, 0), true);
        register(context, CHARRED, "charred", class_6885.method_58563(), new SpawningWeights(0, 0), false);
        register(context, ARCHIMEDES, "archimedes", class_6885.method_58563(), new SpawningWeights(0, 0), false);
    }

    static void register(class_7891<PigeonVariant> context, class_5321<PigeonVariant> key,
                         String name, class_5321<class_1959> spawnBiome, SpawningWeights weights, boolean inheritable) {
        register(context, key, name,
              class_6885.method_40246(context.method_46799(class_7924.field_41236).method_46747(spawnBiome)), weights, inheritable);
    }

    static void register(class_7891<PigeonVariant> context, class_5321<PigeonVariant> key,
                         String name, class_6862<class_1959> spawnBiomes, SpawningWeights weights, boolean inheritable) {
        register(context, key, name,
              context.method_46799(class_7924.field_41236).method_46735(spawnBiomes), weights, inheritable);
    }

    static void register(class_7891<PigeonVariant> context, class_5321<PigeonVariant> key,
                         String name, class_6885<class_1959> spawnBiomes, SpawningWeights weights, boolean inheritable) {
        context.method_46838(key, new PigeonVariant(Envelope.resource("textures/entity/pigeon/pigeon_" + name + ".png"),
              spawnBiomes, weights, inheritable));
    }
}
