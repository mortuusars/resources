package io.github.mortuusars.envelope.world.entity;

import net.minecraft.class_1308;
import net.minecraft.class_1407;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public class PigeonFlyingPathNavigation extends class_1407 {
    public PigeonFlyingPathNavigation(class_1308 mob, class_1937 level) {
        super(mob, level);
    }

    @Override
    public boolean method_6333(class_2338 pos) {
        // By default, only positions that have solid block underneath them are valid.
        // But pigeons can fly to any position.
        // Without this, pigeons only wander near the ground, and basically never fly higher, unless there's blocks there.
        return true;
    }
}
