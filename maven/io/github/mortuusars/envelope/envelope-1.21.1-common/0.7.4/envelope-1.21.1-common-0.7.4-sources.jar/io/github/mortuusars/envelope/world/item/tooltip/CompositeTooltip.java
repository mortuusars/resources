package io.github.mortuusars.envelope.world.item.tooltip;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_5632;

public record CompositeTooltip(List<class_5632> components) implements class_5632 {
    @SafeVarargs
    public static Optional<class_5632> of(Optional<class_5632>... components) {
        if (components.length == 0) {
            return Optional.empty();
        }

        List<class_5632> list = Arrays.stream(components).filter(Optional::isPresent).map(Optional::get).toList();
        if (list.isEmpty()) {
            return Optional.empty();
        }

        if (list.size() == 1) {
            return Optional.of(list.getFirst());
        }

        return Optional.of(new CompositeTooltip(list));
    }
}
