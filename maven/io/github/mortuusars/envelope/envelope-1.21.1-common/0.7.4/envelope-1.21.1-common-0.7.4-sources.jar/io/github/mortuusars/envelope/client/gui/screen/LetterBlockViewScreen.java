package io.github.mortuusars.envelope.client.gui.screen;

import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.world.block.LetterBlock;
import net.minecraft.class_1799;
import net.minecraft.class_2338;

public class LetterBlockViewScreen extends LetterViewScreen {
    private final class_2338 pos;

    public LetterBlockViewScreen(class_1799 letter, class_2338 pos) {
        super(letter, null);
        this.pos = pos;
    }

    @Override
    public void method_25393() {
        if (!(Minecrft.level().method_8320(pos).method_26204() instanceof LetterBlock)) {
            method_25419();
        }
    }
}
