package io.github.mortuusars.envelope.world.mail.address.type;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.mail.address.Address;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;
import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public final class CustomAddress implements Address {
    public static final MapCodec<CustomAddress> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
          class_8824.field_46597.fieldOf("name").forGetter(CustomAddress::getComponent)
    ).apply(instance, CustomAddress::new));

    public static final class_9139<class_9129, CustomAddress> STREAM_CODEC = class_9139.method_56434(
          class_8824.field_48540, CustomAddress::getComponent,
          CustomAddress::new
    );

    private final class_2561 name;

    public CustomAddress(@NotNull class_2561 name) {
        this.name = Objects.requireNonNull(name);
    }

    @Override
    public Type getType() {
        return Type.CUSTOM;
    }

    @Override
    public String getString() {
        return getComponent().getString();
    }

    @Override
    public class_5250 getComponent() {
        return name.method_27661();
    }

    // --

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        CustomAddress that = (CustomAddress) o;
        return Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return ("c" + getString().toLowerCase(Locale.ROOT)).hashCode();
    }

    @Override
    public @NotNull String toString() {
        return "Custom[" + getString() + "]";
    }
}