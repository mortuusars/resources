package io.github.mortuusars.envelope.world.mail.dropoff;

import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import net.minecraft.class_1799;
import net.minecraft.class_2561;

public interface MailDropOffResult {
    MailDropOffResult CONSUME = () -> class_1799.field_8037;
    MailDropOffResult PASS = () -> class_1799.field_8037;

    class_1799 getMail();

    default boolean isHandled() {
        return this != PASS;
    }

    default boolean isReply() {
        return this instanceof Reply;
    }

    // --

    static MailDropOffResult reply(class_1799 mail) {
        return new Reply(mail);
    }

    static MailDropOffResult returned(class_1799 mail) {
        Mail.returned(mail, DeliveryRecord.Message.REJECTED);
        return new Returned(mail);
    }

    static MailDropOffResult returned(class_1799 mail, class_2561 message) {
        Mail.returned(mail, message);
        return new Returned(mail);
    }

    // --

    record Reply(class_1799 mail) implements MailDropOffResult {
        @Override
        public class_1799 getMail() {
            return mail;
        }
    }

    record Returned(class_1799 mail) implements MailDropOffResult {
        @Override
        public class_1799 getMail() {
            return mail;
        }
    }
}
