package io.github.mortuusars.envelope.world.block;

import io.github.mortuusars.envelope.Envelope;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PackageBlock extends class_2248 implements class_2343 {
    public static final class_2753 FACING = class_2741.field_12481;

    public static final class_265 SHAPE_X = class_2248.method_9541(4, 0, 3, 12, 6, 13);
    public static final class_265 SHAPE_Y = class_2248.method_9541(3, 0, 4, 13, 6, 12);

    public PackageBlock(class_2251 properties) {
        super(properties);
        this.method_9590(method_9595().method_11664()
              .method_11657(FACING, class_2350.field_11043));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Override
    public @NotNull class_265 method_9530(@NotNull class_2680 state, @NotNull class_1922 pLevel,
                                        @NotNull class_2338 pPos, @NotNull class_3726 pContext) {
        return state.method_11654(FACING).method_10166() == class_2350.class_2351.field_11048 ? SHAPE_X : SHAPE_Y;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        return method_9595().method_11664().method_11657(FACING, context.method_8042().method_10153());
    }

    @Override
    public boolean method_9558(@NotNull class_2680 state, @NotNull class_4538 level, class_2338 pos) {
        return class_2248.method_20044(level, pos.method_10074(), class_2350.field_11036);
    }

    @Override
    public @NotNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public @NotNull class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new PackageBlockEntity(pos, state);
    }

    // --

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        if (level.method_8321(pos) instanceof PackageBlockEntity blockEntity) {
            blockEntity.setPackage(stack.method_7972());
            level.method_8408(pos, state.method_26204()); // Forces seal tint color to update
        }
    }

    @Override
    public @NotNull class_2680 method_9576(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
        if (!level.field_9236
              && level.method_8321(pos) instanceof PackageBlockEntity blockEntity
              && !player.method_21823()) {
            if (!player.method_7337()) {
                blockEntity.setUnpackWhenBroken(false);
            } else {
                blockEntity.setPackage(class_1799.field_8037);
            }
        }
        return super.method_9576(level, pos, state, player);
    }

    @Override
    public void method_9536(class_2680 state, @NotNull class_1937 level, @NotNull class_2338 pos, class_2680 newState, boolean isMoving) {
        if (!state.method_27852(newState.method_26204()) && level.method_8321(pos) instanceof PackageBlockEntity blockEntity) {
            if (blockEntity.unpackWhenBroken()) {
                level.method_8396(null, pos, Envelope.SoundEvents.PAPER_TEAR.get(), class_3419.field_15245, 0.8f, 1);
            }
            blockEntity.dropContents(level, pos);
        }
        super.method_9536(state, level, pos, newState, isMoving);
    }
}