package io.github.mortuusars.envelope.world.inventory;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_5699;
import net.minecraft.class_6862;
import net.minecraft.class_6885;
import net.minecraft.class_6898;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9323;
import net.minecraft.class_9329;
import net.minecraft.class_9334;

/**
 * Advanced ingredient to allow matching stacks of specific count and/or components.
 * <br>
 * Similar to {@link net.minecraft.class_2073} but more suited for inventories and crafting.
 * <br>
 * <br>
 * It is detached from all vanilla ingredient system, so logic for it has to be manually written.
 */
@SuppressWarnings("deprecation")
public class StackIngredient {
    public static final Codec<StackIngredient> CODEC = RecordCodecBuilder.create(i -> i.group(
          class_6898.method_40388(class_7924.field_41197, class_7923.field_41178.method_40294(), false)
                .fieldOf("item")
                .forGetter(StackIngredient::items),
          class_5699.method_48766(1, 99)
                .optionalFieldOf("count", 1)
                .forGetter(StackIngredient::count),
          class_9329.field_49595
                .optionalFieldOf("components", class_9329.field_49597)
                .forGetter(StackIngredient::components),
          Codec.BOOL
                .optionalFieldOf("strict", false)
                .forGetter(StackIngredient::isStrict)
    ).apply(i, StackIngredient::new));

    public static final class_9139<class_9129, StackIngredient> STREAM_CODEC = class_9139.method_56905(
          class_9135.method_58001(class_7924.field_41197), StackIngredient::items,
          class_9135.field_49675, StackIngredient::count,
          class_9329.field_49596, StackIngredient::components,
          class_9135.field_48547, StackIngredient::isStrict,
          StackIngredient::new
    );

    private final class_6885<class_1792> items;
    private final int count;
    private final class_9329 components;
    private final boolean strict;
    private @Nullable class_1799[] stacks;

    public StackIngredient(class_6885<class_1792> items, int count, class_9329 components, boolean strict) {
        Preconditions.checkArgument(count >= 1 && count <= 99, "Count must be in range 1-99.");
        this.items = items;
        this.count = count;
        this.components = components;
        this.strict = strict;
    }

    public StackIngredient(class_1792 item, int count, class_9329 components) {
        this(class_6885.method_40246(item.method_40131()), count, components, false);
    }

    public StackIngredient(class_1792 item, int count) {
        this(item, count, class_9329.field_49597);
    }

    public StackIngredient(class_1792 item) {
        this(item, 1);
    }

    public StackIngredient(class_6862<class_1792> tag, int count, class_9329 components) {
        this(class_7923.field_41178.method_40266(tag)
              .or(() -> {
                  // This fallback is for datagen, where getting tag from registry fails.
                  LogUtils.getLogger().warn("Failed to get tag '#{}' from BuiltInRegistries.ITEM. Will use empty set.", tag.comp_327());
                  return Optional.of(class_6885.method_45924(class_7923.field_41178.method_46770(), tag));
              })
              .orElseThrow(),
              count, components, false);
    }

    public StackIngredient(class_6862<class_1792> tag, int count) {
        this(tag, count, class_9329.field_49597);
    }

    public StackIngredient(class_6862<class_1792> tag) {
        this(tag, 1);
    }

    // --

    public static StackIngredient createDefault() {
        return new StackIngredient(class_6885.method_40246(class_1802.field_8687.method_40131()),
              1, class_9329.field_49597, false);
    }

    public static StackIngredient createFromStack(class_1799 stack) {
        if (stack.method_7960()) {
            Envelope.LOGGER.warn("Tried to create StackIngredient from empty ItemStack. Default will be returned instead.");
            return StackIngredient.createDefault();
        }

        class_9323 defaultComponents = new class_1799(stack.method_7909(), stack.method_7947()).method_57353();
        class_9323 components = stack.method_7972().method_57353();
        class_9323 uniqueComponents = components.method_57828(type ->
              !Objects.equals(components.method_57829(type), defaultComponents.method_57829(type)));
        return new StackIngredient(class_6885.method_40246(stack.method_41409()), stack.method_7947(),
              class_9329.method_57865(uniqueComponents), false);
    }

    // --

    public class_6885<class_1792> items() {
        return items;
    }

    public int count() {
        return count;
    }

    public class_9329 components() {
        return components;
    }

    public boolean isStrict() {
        return strict;
    }

    public @NotNull class_1799[] stacks() {
        if (stacks == null) {
            stacks = items.method_40239()
                  .map(item -> new class_1799(item, count, components.method_57870()))
                  .toArray(class_1799[]::new);
            if (stacks.length == 0) {
                class_1799 barrier = new class_1799(class_1802.field_8077, count);
                barrier.method_57379(class_9334.field_49631, class_2561.method_43471("envelope.empty_tag"));
                stacks = List.of(barrier).toArray(class_1799[]::new);
            }
        }

        //noinspection NullableProblems
        return stacks;
    }

    // --

    public boolean test(class_1799 stack) {
        return countMatches(stack) && testIgnoreCount(stack);
    }

    public boolean testExactCount(class_1799 stack) {
        return countEquals(stack) && testIgnoreCount(stack);
    }

    public boolean testIgnoreCount(class_1799 stack) {
        return stack.method_53187(items()) && componentsMatch(stack);
    }

    public boolean countMatches(class_1799 stack) {
        return stack.method_7947() >= count();
    }

    public boolean countEquals(class_1799 stack) {
        return stack.method_7947() == count();
    }

    public boolean componentsMatch(class_1799 stack) {
        return strict
              ? stacks().length != 0 && Objects.equals(stack.method_57353(), stacks()[0].method_57353())
              : components().method_57864(stack);
    }

    // --

    public class_1799 getRollingDisplayedStack() {
        if (stacks().length == 0) return class_1799.field_8037;
        int index = (int)(class_156.method_658() / 1000) % stacks().length;
        return stacks()[index];
    }

    // --

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        StackIngredient that = (StackIngredient) o;
        return count == that.count && strict == that.strict && Objects.equals(items, that.items) && Objects.equals(components, that.components);
    }

    @Override
    public int hashCode() {
        return Objects.hash(items, count, components, strict);
    }

    @Override
    public String toString() {
        return "StackIngredient{" +
              "items=" + items +
              ", count=" + count +
              ", components=" + components +
              ", strict=" + strict +
              '}';
    }
}