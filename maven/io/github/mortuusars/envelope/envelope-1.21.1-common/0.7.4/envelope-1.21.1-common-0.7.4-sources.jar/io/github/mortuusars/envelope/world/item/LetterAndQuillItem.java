package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.clientbound.OpenLetterEditScreenS2CP;
import io.github.mortuusars.envelope.world.item.component.LetterAndQuillContent;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import org.jetbrains.annotations.NotNull;

public class LetterAndQuillItem extends class_1792 {
    public LetterAndQuillItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        if (player instanceof class_3222 serverPlayer) {
            Packets.sendToClient(new OpenLetterEditScreenS2CP(usedHand), serverPlayer);
        }
        return class_1271.method_29237(player.method_5998(usedHand), level.field_9236);
    }

    public LetterAndQuillContent getContent(class_1799 stack) {
        return stack.method_57825(Envelope.DataComponents.LETTER_AND_QUILL_CONTENT, LetterAndQuillContent.EMPTY);
    }
}