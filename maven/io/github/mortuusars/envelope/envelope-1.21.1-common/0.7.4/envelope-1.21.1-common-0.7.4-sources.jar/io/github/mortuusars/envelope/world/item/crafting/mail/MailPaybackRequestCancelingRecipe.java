package io.github.mortuusars.envelope.world.item.crafting.mail;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.EnvelopeCodecs;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.component.PaybackSubject;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9334;

public class MailPaybackRequestCancelingRecipe extends CustomMailRecipe {
    public static final Logger LOGGER = LogUtils.getLogger();
    private final class_2371<class_1856> ingredients;

    public MailPaybackRequestCancelingRecipe(ServiceAddress address, class_2371<class_1856> ingredients) {
        super(address);
        this.ingredients = ingredients;
    }

    @Override
    public @NotNull class_2371<class_1856> method_8117() {
        return ingredients;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return Envelope.RecipeSerializers.MAIL_PAYBACK_REQUEST_CANCELING.get();
    }

    @Override
    public boolean isOneCraftPerDelivery() {
        return true;
    }

    @Override
    public @NotNull class_1799 method_8110(class_7225.class_7874 registries) {
        return Mail.of(new class_1799(Envelope.Items.SEALED_PACKAGE.get()))
              .set(class_9334.field_50239, class_2561.method_43471("package.envelope.canceled_payback_request.name"))
              .get();
    }

    @Override
    public @NotNull class_1799 assemble(MailRecipeInput input, class_7225.class_7874 registries) {
        return method_8110(registries).method_7972();
    }

    @Override
    public @NotNull class_1799 assembleWithSideEffects(MailRecipeInput input, class_7225.class_7874 registries) {
        List<PaybackSubject> subjects = input.service().getPaybackDepartment().getSubjectsOf(input.sender())
              .stream()
              .sorted(Comparator.comparingLong(subject -> subject.id().getTick()))
              .toList();

        if (subjects.isEmpty()
              || !(input.service().getPaybackDepartment().removeSubject(subjects.getLast().id()) instanceof PaybackSubject subject)) {
            class_5250 text = class_2561.method_43473()
                  .method_10852(class_2561.method_43471("letter.envelope.payback_request_cancel_report.title").method_27692(class_124.field_1056))
                  .method_27693("\n\n")
                  .method_10852(class_2561.method_43471("letter.envelope.payback_request_cancel_report.error_no_requests"))
                  .method_27693("\n\n")
                  .method_10852(getAddress().getComponent());
            return Mail.createLetter(text)
                  .set(class_9334.field_50239, class_2561.method_43471("letter.envelope.payback_request_cancel_report.name"))
                  .get();
        }

        LOGGER.info("Payback request [{}] was cancelled.", subject);
        return Mail.returned(subject.mail(), DeliveryRecord.Message.PAYBACK_CANCELED);
    }

    public static class Serializer implements class_1865<MailPaybackRequestCancelingRecipe> {
        public static final MapCodec<MailPaybackRequestCancelingRecipe> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
              ServiceAddress.DEFINITION_CODEC
                    .fieldOf("address")
                    .forGetter(MailPaybackRequestCancelingRecipe::getAddress),
              EnvelopeCodecs.recipeIngredients(PackageContents.SLOTS, Envelope.RecipeTypes.MAILING.get())
                    .fieldOf("ingredients")
                    .forGetter(MailPaybackRequestCancelingRecipe::method_8117)
        ).apply(i, MailPaybackRequestCancelingRecipe::new));

        public static final class_9139<class_9129, MailPaybackRequestCancelingRecipe> STREAM_CODEC = class_9139.method_56435(
              ServiceAddress.STREAM_CODEC, MailPaybackRequestCancelingRecipe::getAddress,
              class_1856.field_48355
                    .method_56433(class_9135.method_58000(PackageContents.SLOTS))
                    .method_56432(list ->
                                class_2371.method_10212(class_1856.field_9017, list.toArray(class_1856[]::new)),
                          Function.identity()), MailPaybackRequestCancelingRecipe::method_8117,
              MailPaybackRequestCancelingRecipe::new
        );

        @Override
        public @NotNull MapCodec<MailPaybackRequestCancelingRecipe> method_53736() {
            return CODEC;
        }

        @Override
        public @NotNull class_9139<class_9129, MailPaybackRequestCancelingRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }
}
