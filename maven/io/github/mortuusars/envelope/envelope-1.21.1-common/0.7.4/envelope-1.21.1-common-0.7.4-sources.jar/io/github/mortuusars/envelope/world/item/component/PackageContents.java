package io.github.mortuusars.envelope.world.item.component;

import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import io.github.mortuusars.envelope.Envelope;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_5632;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9695;

public final class PackageContents implements class_9695, class_5632 {
    public static final int SLOTS = 6;

    public static final Codec<PackageContents> CODEC = class_1799.field_49266.listOf(0, SLOTS)
            .xmap(PackageContents::new, PackageContents::getItemsTrimmed);
    public static final class_9139<class_9129, PackageContents> STREAM_CODEC = class_1799.field_49268
            .method_56433(class_9135.method_58000(SLOTS))
            .method_56432(PackageContents::new, PackageContents::getItemsTrimmed);

    public static final PackageContents EMPTY = new PackageContents(Collections.emptyList());

    private final List<class_1799> items;

    public PackageContents(List<class_1799> items) {
        this.items = class_2371.method_10213(SLOTS, class_1799.field_8037);
        for (int i = 0; i < Math.min(items.size(), SLOTS); i++) {
            this.items.set(i, items.get(i));
        }
    }

    public PackageContents(class_1263 container) {
        this.items = class_2371.method_10213(SLOTS, class_1799.field_8037);
        for (int i = 0; i < Math.min(container.method_5439(), SLOTS); i++) {
            this.items.set(i, container.method_5438(i));
        }
    }

    public static PackageContents of(class_1799 stack) {
        return stack.method_57825(Envelope.DataComponents.PACKAGE_CONTENTS, EMPTY);
    }

    // --

    public boolean method_59987() {
        return this == EMPTY || getItems().isEmpty() || getItems().stream().allMatch(class_1799::method_7960);
    }

    public int method_59983() {
        return items.size();
    }

    /**
     * Items should not be modified. Use {@link PackageContents#copyItems()} if modification is needed.
     */
    public List<class_1799> getItems() {
        return items;
    }

    /**
     * Items without trailing empty stacks.
     * <br>
     * Items should not be modified. Use {@link PackageContents#copyItems()} if modification is needed.
     */
    public List<class_1799> getItemsTrimmed() {
        List<class_1799> list = new ArrayList<>(items);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (!list.get(i).method_7960()) {
                break;
            }
            list.remove(i);
        }
        return list;
    }

    /**
     * Item should not be modified. Copy the stack if modification is needed.
     */
    public @NotNull class_1799 method_59984(int index) {
        return index < method_59983() ? items.get(index) : class_1799.field_8037;
    }

    /**
     * Returned item can be modified safely.
     */
    public @NotNull class_1799 copyItem(int index) {
        return method_59984(index).method_7972();
    }

    /**
     * Returned items can be modified safely.
     */
    public List<class_1799> copyItems() {
        return Lists.transform(this.items, class_1799::method_7972);
    }

    // --

    @SuppressWarnings("deprecation")
    public boolean equals(Object another) {
        return this == another ||
              (another instanceof PackageContents packageContents
                    && class_1799.method_57362(this.items, packageContents.items));
    }

    @SuppressWarnings("deprecation")
    public int hashCode() {
        return class_1799.method_57361(this.items);
    }

    public String toString() {
        return "PackageContents" + this.items;
    }

    // --

    public static boolean canHold(class_1799 stack) {
        return stack.method_7909().method_31568() && !stack.method_31573(Envelope.Tags.Items.CANNOT_BE_PACKAGED);
    }
}
