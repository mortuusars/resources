package io.github.mortuusars.envelope.client.gui.widget.textbox;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.envelope.client.gui.widget.textbox.display.FormattedStringDisplayCache;
import io.github.mortuusars.envelope.client.gui.widget.textbox.display.FormattingToolbar;
import io.github.mortuusars.envelope.client.gui.widget.textbox.display.HorizontalAlignment;
import io.github.mortuusars.envelope.client.gui.widget.textbox.display.Line;
import io.github.mortuusars.envelope.client.gui.widget.textbox.text.FormattedString;
import io.github.mortuusars.envelope.client.gui.widget.textbox.text.FormattedStringEditor;
import io.github.mortuusars.envelope.client.gui.widget.textbox.text.Formatting;
import io.github.mortuusars.envelope.client.util.Pos2i;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_768;

public class TextBox extends class_339 {
    protected FormattedStringEditor editor = new FormattedStringEditor(() ->
            FormattedStringEditor.Validator.fitInDimensions(getFont(), method_25368(), method_25364()));
    protected FormattedStringDisplayCache displayCache = new FormattedStringDisplayCache(editor);

    protected HorizontalAlignment horizontalAlignment = HorizontalAlignment.LEFT;
    protected class_327 font;
    protected int fontColor = 0xFF000000;
    protected int fontUnfocusedColor = 0xFF000000;
    protected int selectionColor = 0xFF0000FF;
    protected int selectionUnfocusedColor = 0x880000FF;
    protected Consumer<FormattedString> onTextChanged = text -> { };
    protected boolean formattingEnabled = true;
    protected @Nullable class_2561 hint = null;
    protected int hintColor = 0x77000000;
    protected @Nullable FormattedString autocompleteSuggestion = null;
    protected int autocompleteSuggestionColor = 0x77000000;

    protected FormattingToolbar formattingToolbar = new FormattingToolbar(this);

    protected Pos2i lastClickPos = new Pos2i(0, 0);
    protected long lastActionTime;
    protected boolean canDrag;

    public TextBox(int x, int y, int width, int height) {
        this(class_310.method_1551().field_1772, x, y, width, height);
    }

    public TextBox(class_327 font, int x, int y, int width, int height) {
        super(x, y, width, height, class_2561.method_43473());
        this.font = font;
    }

    public class_327 getFont() {
        return font;
    }

    public TextBox setFont(class_327 font) {
        this.font = font;
        refreshDisplayCache();
        return this;
    }

    public FormattedStringEditor getEditor() {
        return editor;
    }

    public FormattedStringDisplayCache getDisplayCache() {
        if (displayCache.shouldUpdate()) {
            displayCache.update(getFont(), method_25368(), method_25364(), getHorizontalAlignment());
        }

        return displayCache;
    }

    public FormattingToolbar getFormattingToolbar() {
        if (formattingToolbar.shouldUpdate()) {
            formattingToolbar.update();
        }
        return formattingToolbar;
    }

    public TextBox setFormattingToolbar(FormattingToolbar formattingToolbar) {
        this.formattingToolbar = formattingToolbar;
        this.formattingToolbar.scheduleUpdate();
        return this;
    }

    public HorizontalAlignment getHorizontalAlignment() {
        return horizontalAlignment;
    }

    public TextBox setHorizontalAlignment(HorizontalAlignment horizontalAlignment) {
        this.horizontalAlignment = horizontalAlignment;
        refreshDisplayCache();
        return this;
    }

    public int getFontColor() {
        return fontColor;
    }

    public TextBox setFontColor(int fontColor) {
        this.fontColor = fontColor;
        refreshDisplayCache();
        return this;
    }

    public int getFontUnfocusedColor() {
        return fontUnfocusedColor;
    }

    public TextBox setFontUnfocusedColor(int fontUnfocusedColor) {
        this.fontUnfocusedColor = fontUnfocusedColor;
        refreshDisplayCache();
        return this;
    }

    public int getSelectionColor() {
        return selectionColor;
    }

    public TextBox setSelectionColor(int selectionColor) {
        this.selectionColor = selectionColor;
        refreshDisplayCache();
        return this;
    }

    public int getSelectionUnfocusedColor() {
        return selectionUnfocusedColor;
    }

    public TextBox setSelectionUnfocusedColor(int selectionUnfocusedColor) {
        this.selectionUnfocusedColor = selectionUnfocusedColor;
        refreshDisplayCache();
        return this;
    }

    public int getCurrentFontColor() {
        return method_25370() ? fontColor : fontUnfocusedColor;
    }

    public int getCurrentSelectionColor() {
        return method_25370() ? selectionColor : selectionUnfocusedColor;
    }

    public boolean isFormattingEnabled() {
        return formattingEnabled;
    }

    public TextBox setFormattingEnabled(boolean formattingEnabled) {
        this.formattingEnabled = formattingEnabled;
        getEditor().setFormattingEnabled(formattingEnabled);
        return this;
    }

    public TextBox setTextValidator(Predicate<String> validator) {
        getEditor().setValidator(validator);
        return this;
    }

    public Consumer<FormattedString> onTextChanged() {
        return onTextChanged;
    }

    public TextBox setOnTextChanged(Consumer<FormattedString> onTextChanged) {
        this.onTextChanged = onTextChanged;
        return this;
    }

    public TextBox setText(FormattedString text) {
        getEditor().setText(text);
        getEditor().setCursorPos(getEditor().length(), false);
        return this;
    }

    public TextBox setTextAndUpdate(FormattedString text) {
        setText(text);
        onTextChanged().accept(getEditor().getText());
        getDisplayCache().scheduleUpdate();
        return this;
    }

    public TextBox clearText() {
        setTextAndUpdate(FormattedString.parse(""));
        return this;
    }

    public @Nullable class_2561 getHint() {
        return hint;
    }

    public TextBox setHint(class_2561 hint) {
        this.hint = hint;
        return this;
    }

    public int getHintColor() {
        return hintColor;
    }

    public TextBox setHintColor(int color) {
        this.hintColor = color;
        return this;
    }

    public @Nullable FormattedString getAutocompleteSuggestion() {
        return autocompleteSuggestion;
    }

    public TextBox setAutocompleteSuggestion(FormattedString suggestion) {
        this.autocompleteSuggestion = suggestion;
        return this;
    }

    public int getAutocompleteSuggestionColor() {
        return autocompleteSuggestionColor;
    }

    public TextBox setAutocompleteSuggestionColor(int color) {
        this.autocompleteSuggestionColor = color;
        return this;
    }

    // -- Render

    @Override
    protected void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        FormattedStringDisplayCache displayCache = getDisplayCache();

        if (getHint() != null && !method_25370() && getEditor().getText().toString().isBlank()) {
            int x = method_46426() + getHorizontalAlignment().align(method_25368(), font.method_27525(getHint()));
            guiGraphics.method_51439(font, getHint(), x, method_46427(), getHintColor(), false);
        }

        if (getAutocompleteSuggestion() != null && method_25370()) {
            int x = method_46426() + getHorizontalAlignment().align(method_25368(), font.method_27525(getAutocompleteSuggestion()));
            x += font.method_1727(getEditor().getText().toString());

            String string = getAutocompleteSuggestion().toString().substring(Math.max(0, getEditor().length()));
            guiGraphics.method_51433(font, string, x, method_46427(), getAutocompleteSuggestionColor(), false);
        }

        renderLines(guiGraphics, mouseX, mouseY, partialTick, displayCache.getLines(), getCurrentFontColor());

        int cursorColor = getCurrentFontColor();
        Formatting currentFormatting = getEditor().getFormattingAtCursor();
        if (currentFormatting.color() != null) {
            //noinspection DataFlowIssue
            cursorColor = currentFormatting.color().asChatFormatting().method_532() | 0xFF000000;
        }

        renderCursor(guiGraphics, mouseX, mouseY, partialTick, getEditor(), displayCache.getCursor(), cursorColor);
        renderSelection(guiGraphics, mouseX, mouseY, partialTick, displayCache.getSelection(), getCurrentSelectionColor());

        if (isFormattingEnabled()) {
            getFormattingToolbar().render(guiGraphics, mouseX, mouseY, partialTick);
        }
    }

    public void renderLines(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, List<Line> lines, int color) {
        for (Line line : lines) {
            guiGraphics.method_51433(font, line.renderedString(), method_46426() + line.x(), method_46427() + line.y(), color, false);
        }
    }

    public void renderSelection(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, List<class_768> selection, int color) {
        for (class_768 rect : selection) {
            int x0 = method_46426() + rect.method_3321();
            int y0 = method_46427() + rect.method_3322();
            int x1 = x0 + rect.method_3319();
            int y1 = y0 + rect.method_3320();
            guiGraphics.method_51739(class_1921.method_51786(), x0, y0, x1, y1, color);
        }
    }

    public void renderCursor(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, FormattedStringEditor editor, Pos2i cursor, int color) {
        if (!method_25370()) return;
        if (editor.isSelecting()) return;
        if (System.currentTimeMillis() - lastActionTime > 200 && (System.currentTimeMillis() - lastActionTime) % 600 > 300) // Blinking
            return;

        if (editor.isCursorAtEnd()) {
            Line line = getDisplayCache().getLine(getDisplayCache().getLines().size() - 1);
            if (cursor.y + font.field_2000 > method_25364()) {
                int x = line.x() + line.width();
                int y = line.y();
                guiGraphics.method_51433(getFont(), "<", method_46426() + x, method_46427() + y,
                        color, false);
            } else {
                guiGraphics.method_51433(getFont(), "_", method_46426() + cursor.x, method_46427() + cursor.y,
                        color, false);
            }
        } else {
            guiGraphics.method_51448().method_22903();
            guiGraphics.method_51448().method_46416(0, 0, 50);
            RenderSystem.disableBlend();
            guiGraphics.method_25294(
                    method_46426() + cursor.x,
                    method_46427() + cursor.y - 1,
                    method_46426() + cursor.x + 1,
                    method_46427() + cursor.y + font.field_2000,
                    color);
            guiGraphics.method_51448().method_22909();
        }
    }

    protected void refreshDisplayCache() {
        displayCache.scheduleUpdate(); // This call should reference the field directly, for updating to work properly.
        if (isFormattingEnabled()) {
            formattingToolbar.scheduleUpdate(); // This call should reference the field directly, for updating to work properly.
        }
    }

    // -- Input

    public boolean canConsumeInput() {
        return method_37303() && method_25370();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (!method_25370() || !method_37303() || !field_22764) return false;

        if (handleKeyPressed(keyCode, scanCode, modifiers)) {
            lastActionTime = System.currentTimeMillis();
            onTextChanged().accept(getEditor().getText());
            refreshDisplayCache();
            return true;
        }

        return false;
    }

    protected boolean handleKeyPressed(int keyCode, int scanCode, int modifiers) {
        if (isFormattingEnabled() && getFormattingToolbar().keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        } else if (keyCode == class_3675.field_31948 && getAutocompleteSuggestion() != null) {
            getEditor().setText(getAutocompleteSuggestion());
            getEditor().setCursorToEnd(false);
            return true;
        } else if (keyCode == class_3675.field_31932) {
            changeLine(-1);
            return true;
        } else if (keyCode == class_3675.field_31982) {
            changeLine(1);
            return true;
        } else if (keyCode == class_3675.field_31989) {
            keyHome();
            return true;
        } else if (keyCode == class_3675.field_31988) {
            keyEnd();
            return true;
        }

        return getEditor().keyPressed(keyCode);
    }

    public boolean method_25400(char codePoint, int modifiers) {
        if (method_25370() && getEditor().charTyped(codePoint)) {
            lastActionTime = System.currentTimeMillis();
            onTextChanged().accept(getEditor().getText());
            refreshDisplayCache();
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!method_37303() || !field_22764) return false;

        if (formattingToolbarMouseClicked(mouseX, mouseY, button)) {
            return true;
        }

        if (field_22762 && button == class_3675.field_32000) {
            long currentTime = System.currentTimeMillis();
            FormattedStringDisplayCache display = getDisplayCache();

            int indexAtMousePos = display.getCharIndexAtPosition(font, (int) (mouseX - method_46426()), (int) (mouseY - method_46427()));

            if (Math.abs(lastClickPos.x - (int) mouseX) < 4 && Math.abs(lastClickPos.y - (int) mouseY) < 4 && currentTime - lastActionTime < 250L) {
                if (!getEditor().isSelecting()) {
                    getEditor().selectWord(indexAtMousePos);
                } else {
                    getEditor().selectAll();
                }
            } else {
                getEditor().setCursorPos(indexAtMousePos, class_437.method_25442());
            }

            refreshDisplayCache();

            lastClickPos = new Pos2i((int) mouseX, (int) mouseY);
            lastActionTime = currentTime;
            canDrag = true;
            return true;
        }

        if (!field_22762) {
            getEditor().clearSelection();
            refreshDisplayCache();
        }

        return false;
    }

    public boolean formattingToolbarMouseClicked(double mouseX, double mouseY, int button) {
        if (isFormattingEnabled() && getFormattingToolbar().mouseClicked(mouseX, mouseY, button)) {
            refreshDisplayCache();
            onTextChanged().accept(getEditor().getText());
            canDrag = false;
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (button == 0 && canDrag) {
            FormattedStringDisplayCache display = getDisplayCache();
            int indexAtMousePos = display.getCharIndexAtPosition(font, (int) (mouseX - method_46426()), (int) (mouseY - method_46427()));
            getEditor().setCursorPos(indexAtMousePos, true);
            refreshDisplayCache();
            return true;
        }
        return false;
    }

    // --

    public void changeLine(int yChange) {
        Pos2i cursor = getDisplayCache().getCursor();
        int x = cursor.x;
        int y = cursor.y + (font.field_2000 * yChange);
        int index = getDisplayCache().getCharIndexAtPosition(font, x, y);

        getEditor().setCursorPos(index, class_437.method_25442());
    }

    public void keyHome() {
        if (class_437.method_25441()) {
            getEditor().setCursorToStart(class_437.method_25442());
        } else {
            int cursorPos = getEditor().getCursorPos();
            int lineIndex = getDisplayCache().findLineIndexByCharIndex(cursorPos);
            Line line = getDisplayCache().getLine(lineIndex);
            getEditor().setCursorPos(line.firstCharIndex(), class_437.method_25442());
        }
    }

    public void keyEnd() {
        if (class_437.method_25441()) {
            getEditor().setCursorToEnd(class_437.method_25442());
        } else {
            int cursorPos = getEditor().getCursorPos();
            int lineIndex = getDisplayCache().findLineIndexByCharIndex(cursorPos);
            Line line = getDisplayCache().getLine(lineIndex);
            getEditor().setCursorPos(line.lastCharIndex() + 1, class_437.method_25442());
        }
    }

    // --

    @Override
    public @NotNull class_2561 method_25369() {
        return class_2561.method_43470(getEditor().getText().toStringWithoutFormatting());
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) {
        narrationElementOutput.method_37034(class_6381.field_33788, method_25360());
    }
}
