package io.github.mortuusars.envelope.world.block.dispenser;

import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2350;
import net.minecraft.class_2968;
import net.minecraft.class_2969;
import org.jetbrains.annotations.NotNull;

public class PlaceBlockDispenseItemBehavior extends class_2969 {
    @Override
    protected @NotNull class_1799 method_10135(class_2342 blockSource, class_1799 stack) {
        this.method_27955(false);
        if (stack.method_7909() instanceof class_1747 blockItem) {
            class_2350 direction = blockSource.comp_1969().method_11654(class_2315.field_10918);
            class_2338 placePos = blockSource.comp_1968().method_10093(direction);

            try {
                method_27955(blockItem.method_7712(new class_2968(blockSource.comp_1967(), placePos, direction, stack, direction))
                      .method_23665());
            } catch (Exception e) {
                field_34020.error("Error trying to place block at {}", placePos, e);
            }
        }

        return stack;
    }
}
