package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.block.PackageBlockEntity;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public interface Sealable {
    class_1799 seal(class_1937 level, class_1799 stack, Seal seal);

    default boolean canSeal(class_1937 level, class_1799 stack) {
        return !stack.method_57826(Envelope.DataComponents.SEAL);
    }

    // --

    static int getSealOverlayColor(class_1799 stack, int layer) {
        if (layer != 1) {
            return -1;
        }

        @Nullable Seal seal = stack.method_57824(Envelope.DataComponents.SEAL);
        if (seal != null) {
            return seal.material().comp_349().modelTintColor();
        }

        return 0xFFCC4E47; // Default red color
    }

    static int getSealOverlayColor(class_2680 state, @Nullable class_1920 level, @Nullable class_2338 pos, int index) {
        if (index != 0) {
            return -1;
        }

        if (level != null && pos != null && level.method_8321(pos) instanceof PackageBlockEntity blockEntity) {
            @Nullable Seal seal = blockEntity.getPackage().method_57824(Envelope.DataComponents.SEAL);
            if (seal != null) {
                return seal.material().comp_349().modelTintColor();
            }
        }

        return 0xFFCC4E47; // Default red color
    }
}
