package io.github.mortuusars.envelope.world.mail.service;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.EnvelopeSymbols;
import io.github.mortuusars.envelope.world.mail.address.AddressLocation;
import net.minecraft.class_2561;
import net.minecraft.class_5381;
import net.minecraft.class_6880;
import net.minecraft.class_8824;

public record ServiceAddressDefinition(class_2561 name, String icon, AddressLocation location) {
    public static final Codec<ServiceAddressDefinition> DIRECT_CODEC = RecordCodecBuilder.create(i -> i.group(
          class_8824.field_46597.fieldOf("name").forGetter(ServiceAddressDefinition::name),
          Codec.STRING.optionalFieldOf("icon", EnvelopeSymbols.ADDRESS_SERVICE).forGetter(ServiceAddressDefinition::icon),
          AddressLocation.CODEC.fieldOf("location").forGetter(ServiceAddressDefinition::location)
    ).apply(i, ServiceAddressDefinition::new));

    public static final Codec<class_6880<ServiceAddressDefinition>> CODEC =
          class_5381.method_29749(Envelope.Registries.SERVICE_ADDRESS_DEFINITION, DIRECT_CODEC);
}
