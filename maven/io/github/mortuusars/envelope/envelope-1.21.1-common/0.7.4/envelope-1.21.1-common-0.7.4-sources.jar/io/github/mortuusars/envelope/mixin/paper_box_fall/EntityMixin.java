package io.github.mortuusars.envelope.mixin.paper_box_fall;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import io.github.mortuusars.envelope.world.block.PaperBoxBlock;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1297.class)
public class EntityMixin {
    @Shadow
    public float fallDistance;

    @WrapMethod(method = "checkFallDamage")
    private void onCheckFallDamage(double y, boolean onGround, class_2680 state, class_2338 pos, Operation<Void> original) {
        @Nullable Float distance = null;
        class_1297 entity = (class_1297)(Object)this;

        if (state.method_26204() instanceof PaperBoxBlock block && fallDistance > block.getFallDistanceToBreak(state, pos, entity)) {
            distance = block.reduceFallDistance(state, pos, entity, fallDistance);
        }

        original.call(y, onGround, state, pos);

        if (distance != null) {
            fallDistance = distance;
        }
    }
}
