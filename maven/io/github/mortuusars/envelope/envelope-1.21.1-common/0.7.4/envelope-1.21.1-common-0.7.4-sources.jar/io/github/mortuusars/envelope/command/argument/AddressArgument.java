package io.github.mortuusars.envelope.command.argument;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import io.github.mortuusars.envelope.util.result.Error;
import io.github.mortuusars.envelope.world.mail.address.*;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import io.github.mortuusars.envelope.world.mail.address.type.PlayerAddress;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_2168;
import net.minecraft.class_2561;

public class AddressArgument implements ArgumentType<Address> {
    private final @Nullable Address.Type type;

    protected AddressArgument(@Nullable Address.Type type) {
        this.type = type;
    }

    public static AddressArgument all() {
        return new AddressArgument(null);
    }

    public static AddressArgument block() {
        return new AddressArgument(Address.Type.BLOCK);
    }

    public static AddressArgument player() {
        return new AddressArgument(Address.Type.PLAYER);
    }

    public static AddressArgument entity() {
        return new AddressArgument(Address.Type.SERVICE);
    }

    public static BlockAddress getBlock(CommandContext<class_2168> context, String name) throws CommandSyntaxException {
        Address address = context.getArgument(name, Address.class);
        if (address instanceof BlockAddress block) {
            return block;
        }
        class_2561 message = class_2561.method_43470("Address has wrong type: Expected: "
              + Address.Type.BLOCK.method_15434() + ", Got: "
              + address.getType().method_15434());
        throw new SimpleCommandExceptionType(message).create();
    }

    @Override
    public Address parse(StringReader reader) throws CommandSyntaxException {
        String id = reader.readString();

        Optional<Error> error = BlockAddressValidation.id().test(id).getError();

        if (error.isPresent()) {
            class_2561 message = class_2561.method_43470("Invalid address: ").method_10852(error.get().getTranslation());
            throw new SimpleCommandExceptionType(message).create();
        }

        //TODO: this is not what it should be probably

        if (type == null) {
            return Address.UNKNOWN;
        }

        return switch (type) {
            case BLOCK -> new BlockAddress(id);
            case PLAYER -> new PlayerAddress(id);
            default -> throw new SimpleCommandExceptionType(class_2561.method_43470("Cannot parse address type " + type)).create();
        };
    }
}