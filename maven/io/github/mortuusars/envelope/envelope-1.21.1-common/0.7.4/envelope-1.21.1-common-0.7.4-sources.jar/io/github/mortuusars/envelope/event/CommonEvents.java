package io.github.mortuusars.envelope.event;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.block.dispenser.PlaceBlockDispenseItemBehavior;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.entity.PigeonVariant;
import io.github.mortuusars.envelope.world.mail.MailService;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import org.jetbrains.annotations.Nullable;

public class CommonEvents {
    public static void commonSetup() {
        MailService.init();

        PlaceBlockDispenseItemBehavior placeBlockBehavior = new PlaceBlockDispenseItemBehavior();
        class_2315.method_10009(Envelope.Items.PACKAGE.get(), placeBlockBehavior);
        class_2315.method_10009(Envelope.Items.SEALED_PACKAGE.get(), placeBlockBehavior);
    }

    public static void levelTick(class_1937 level) {
    }

    /**
     * Fired before level data storage is saved.
     */
    public static void saveLevelData(class_3218 level) {
    }

    public static void entityLeaveLevel(class_1937 level, class_1297 entity) {
    }

    public static void livingDeath(class_1309 entity, class_1282 source) {
        if (entity.method_59922().method_43058() < Config.Server.ARCHIMEDES_CHANCE.get()
              && entity.method_37908().method_27983() == class_1937.field_25179
              && source.method_5529() instanceof class_3222 player
              && entity.method_5864().method_20210(Envelope.Tags.EntityTypes.SPAWNS_ARCHIMEDES)
              && source.method_48789(Envelope.Tags.DamageTypes.SPAWNS_ARCHIMEDES)
              && player.method_51469().method_18467(
                    Pigeon.class, new class_238(entity.method_24515()).method_1009(48, 32, 48)).size() < 8) {
            @Nullable Pigeon pigeon = Envelope.EntityTypes.PIGEON.get().method_47821(player.method_51469(), entity.method_24515(), class_3730.field_16461);
            if (pigeon == null) {
                Envelope.LOGGER.warn("Cannot spawn Archimedes :(");
                return;
            }

            pigeon.setVariant(PigeonVariant.getOrThrow(entity.method_56673(), PigeonVariant.ARCHIMEDES));
            pigeon.method_29495(entity.method_5829().method_1005());
            pigeon.getWanderGoal().method_6304();
            pigeon.onAppeared(player.method_51469());
            class_243 direction = entity.method_19538().method_1020(source.method_5510());
            pigeon.method_18799(direction.method_1029().method_1021(0.75));

            Envelope.CriteriaTriggers.SPAWN_ARCHIMEDES.get().method_9141(player);
        }
    }
}
