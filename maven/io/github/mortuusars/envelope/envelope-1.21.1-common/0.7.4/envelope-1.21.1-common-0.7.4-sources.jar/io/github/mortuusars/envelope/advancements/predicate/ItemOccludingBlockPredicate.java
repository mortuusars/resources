package io.github.mortuusars.envelope.advancements.predicate;

import com.mojang.serialization.Codec;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_9360;

public class ItemOccludingBlockPredicate implements class_9360 {
    public static final ItemOccludingBlockPredicate INSTANCE = new ItemOccludingBlockPredicate();
    public static final Codec<ItemOccludingBlockPredicate> CODEC = Codec.unit(INSTANCE);
    public static final class_8745<ItemOccludingBlockPredicate> TYPE = new class_8745<>(ItemOccludingBlockPredicate.CODEC);

    private ItemOccludingBlockPredicate() {}

    @Override
    public boolean method_58161(class_1799 stack) {
        // This is a crude way to check for at least somewhat heavy blocks. This is probably the best we can do without having access to level and position.
        return stack.method_7909() instanceof class_1747 blockItem && blockItem.method_7711().method_9564().method_26225();
    }
}
