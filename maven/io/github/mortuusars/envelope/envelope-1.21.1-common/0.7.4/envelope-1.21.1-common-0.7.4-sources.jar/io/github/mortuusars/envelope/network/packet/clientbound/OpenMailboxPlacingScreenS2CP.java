package io.github.mortuusars.envelope.network.packet.clientbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.handler.ClientPacketsHandler;
import io.github.mortuusars.envelope.network.packet.Packet;
import io.github.mortuusars.envelope.util.EnvelopeStreamCodecs;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3965;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record OpenMailboxPlacingScreenS2CP(class_1268 hand,
                                           class_3965 hitResult,
                                           AllAddresses knownAddresses) implements Packet {
    public static final class_2960 ID = Envelope.resource("open_mailbox_placing_screen");
    public static final class_9154<OpenMailboxPlacingScreenS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, OpenMailboxPlacingScreenS2CP> STREAM_CODEC = class_9139.method_56436(
          class_9135.field_48550.method_56432(i -> class_1268.values()[i], class_1268::ordinal), OpenMailboxPlacingScreenS2CP::hand,
          EnvelopeStreamCodecs.BLOCK_HIT_RESULT, OpenMailboxPlacingScreenS2CP::hitResult,
          AllAddresses.STREAM_CODEC, OpenMailboxPlacingScreenS2CP::knownAddresses,
          OpenMailboxPlacingScreenS2CP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        ClientPacketsHandler.openMailboxPlacingScreen(this);
        return true;
    }
}
