package io.github.mortuusars.envelope.integration.jei.extensions;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.world.item.crafting.AddressTagApplicationRecipe;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import io.github.mortuusars.envelope.world.mail.service.ServiceAddresses;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.ingredient.ICraftingGridHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.category.extensions.vanilla.crafting.ICraftingCategoryExtension;
import net.minecraft.class_1799;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import java.util.List;

public class AddressTagApplicationRecipeExtension implements ICraftingCategoryExtension<AddressTagApplicationRecipe> {
    @Override
    public void setRecipe(class_8786<AddressTagApplicationRecipe> holder, IRecipeLayoutBuilder builder, ICraftingGridHelper craftingGridHelper, IFocusGroup focuses) {
        List<class_1799> mailableItems = class_7923.field_41178.method_40266(Envelope.Tags.Items.MAILABLE)
              .map(named -> named.method_40239().map(class_1799::new).toList())
              .orElse(List.of());

        class_1799 tag = new class_1799(Envelope.Items.ADDRESS_TAG.get());
        tag.method_57379(Envelope.DataComponents.ADDRESS, ServiceAddress.getOrThrow(Minecrft.registryAccess(), ServiceAddresses.MAIL_SERVICE));
        List<class_1799> tagItems = List.of(tag);

        List<class_1799> resultItems = mailableItems.stream()
              .map(stack -> {
                  class_1799 result = stack.method_7972();
                  Mail.setRecipient(result, tag.method_57824(Envelope.DataComponents.ADDRESS));
                  return result;
              })
              .toList();

        craftingGridHelper.createAndSetInputs(builder, VanillaTypes.ITEM_STACK, List.of(mailableItems, tagItems), 0, 0);
        craftingGridHelper.createAndSetOutputs(builder, VanillaTypes.ITEM_STACK, resultItems);
    }
}
