package io.github.mortuusars.envelope.client.gui.screen;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.util.EnvelopeSymbols;
import io.github.mortuusars.envelope.util.validation.CachedValidator;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.BlockAddressValidation;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_5250;
import net.minecraft.class_746;
import net.minecraft.class_7919;

public abstract class AbstractMailboxAddressScreen extends AddressTagScreen {
    protected final class_746 player;
    protected CachedValidator<String> addressValidator;

    public AbstractMailboxAddressScreen(class_1268 hand, AllAddresses knownAddresses,
                                        Optional<BlockAddress> existingAddress, class_2561 title) {
        super(hand, knownAddresses, title);
        this.player = Minecrft.player();
        this.existingAddress = existingAddress.map(Address.class::cast);
        this.addressValidator = BlockAddressValidation.forMailbox(knownAddresses, player).cached();
    }

    @Override
    protected abstract class_1799 getTargetPreview();
    protected abstract void onConfirm();
    protected abstract boolean stillValid();

    // -- Address

    @Override
    protected String getInitialAddressValue() {
        return existingAddress
              .map(Address::getString)
              .orElseGet(() -> Optional.ofNullable(player.method_5998(hand).method_57824(Envelope.DataComponents.ADDRESS))
                    .map(Address::getString)
                    .orElse(""));
    }

    @Override
    protected AllAddresses getAddressesForSuggestions() {
        return AllAddresses.EMPTY; // Don't suggest anything
    }

    // -- Validation

    public CachedValidator<String> getAddressValidator() {
        return addressValidator;
    }

    protected boolean canConfirm() {
        return isCurrentIdSameAsExistingAddress() || getAddressValidator().getErrors().isEmpty();
    }

    // --

    protected void updateConfirmButton() {
        if (confirmButton == null) return; // Not initialized yet

        confirmButton.field_22763 = canConfirm();

        class_5250 confirmTooltip = class_2561.method_43471("gui.envelope.confirm");

        if (!confirmButton.field_22763) {
            getAddressValidator().getErrors()
                  .forEach(issue -> confirmTooltip.method_27693("\n")
                        .method_10852(class_2561.method_43470("• ").method_27692(class_124.field_1061))
                        .method_10852(issue.getTranslation().method_27692(class_124.field_1061)));
            confirmButton.method_47400(class_7919.method_47407(confirmTooltip));
            return;
        }

        if (isRenaming() && !isCurrentIdSameAsExistingAddress()) {
            confirmTooltip.method_27693("\n")
                  .method_10852(class_2561.method_43471("gui.envelope.mailbox_address.rename_warning.inbox")
                        .method_54663(Colors.TOOLTIP_RED))
                  .method_27693("\n")
                  .method_10852(class_2561.method_43471("gui.envelope.mailbox_address.rename_warning.traveling")
                        .method_54663(Colors.TOOLTIP_RED));
        }
        confirmButton.method_47400(class_7919.method_47407(confirmTooltip));
    }

    // -- Events

    @Override
    protected void addressTextChanged(String text) {
        super.addressTextChanged(text);
        getAddressValidator().testAll(getCurrentAddressId());
    }

    @Override
    protected boolean confirm() {
        if (!canConfirm()) {
            return false;
        }

        if (!isCurrentIdSameAsExistingAddress()) {
            onConfirm();
        }
        close();
        return true;
    }

    // -- Render

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (!stillValid()) {
            close();
        }

        updateConfirmButton();

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        renderExperienceCost(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void renderAddressIcon(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int color = canConfirm() ? 0xFFFFFFFF : 0xAAFFFFFF;
        guiGraphics.method_51433(field_22793, EnvelopeSymbols.ADDRESS_BLOCK, leftPos + 17, topPos + 21, color, true);
    }

    protected void renderExperienceCost(class_332 guiGraphics, int mouseX, int mouseY) {
        if (isCurrentIdSameAsExistingAddress() || player.method_7337()) return;

        int cost = Config.Server.MAILBOX_ADDRESS_EXPERIENCE_LEVELS_COST.get();
        if (cost <= 0) return;

        boolean hasEnough = player.field_7520 >= cost;
        class_2960 sprite = Envelope.resource("address_tag/experience" + (hasEnough ? "" : "_disabled"));

        int x = 159;
        int y = 4;

        guiGraphics.method_52706(sprite, leftPos + x, topPos + y, 11, 11);

        // Below is rendering of a xp level number with outline
        // Mojang did this with texture, but in our case it needs to be dynamic (because it's configurable)

        String text = Integer.toString(cost);
        int centerColor = hasEnough ? 0xFFC8FF8F : 0xFF8C605D;
        int outlineColor = hasEnough ? 0xFF2D2102 : 0xFF47352F;

        x += 7;
        y += 2;

        guiGraphics.method_51433(field_22793, text, leftPos + x, topPos + y - 1, outlineColor, false);
        guiGraphics.method_51433(field_22793, text, leftPos + x + 1, topPos + y - 1, outlineColor, false);
        guiGraphics.method_51433(field_22793, text, leftPos + x + 1, topPos + y, outlineColor, false);
        guiGraphics.method_51433(field_22793, text, leftPos + x + 1, topPos + y + 1, outlineColor, false);
        guiGraphics.method_51433(field_22793, text, leftPos + x, topPos + y + 1, outlineColor, false);
        guiGraphics.method_51433(field_22793, text, leftPos + x - 1, topPos + y + 1, outlineColor, false);
        guiGraphics.method_51433(field_22793, text, leftPos + x - 1, topPos + y, outlineColor, false);

        guiGraphics.method_51433(field_22793, text, leftPos + x, topPos + y, centerColor, false);
    }
}