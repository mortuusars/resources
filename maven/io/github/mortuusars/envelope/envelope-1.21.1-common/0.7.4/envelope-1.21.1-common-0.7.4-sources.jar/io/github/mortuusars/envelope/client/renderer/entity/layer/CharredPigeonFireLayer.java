package io.github.mortuusars.envelope.client.renderer.entity.layer;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.model.CharredPigeonModel;
import io.github.mortuusars.envelope.world.entity.CharredPigeon;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;

public class CharredPigeonFireLayer extends class_3887<CharredPigeon, CharredPigeonModel> {
    public static final class_1921 RENDER_TYPE = class_1921.method_23026(Envelope.resource("textures/entity/charred_pigeon/charred_pigeon_fire.png"));
    public static final class_2960 TEXTURE = Envelope.resource("textures/entity/charred_pigeon/charred_pigeon_fire.png");

    public CharredPigeonFireLayer(class_3883<CharredPigeon, CharredPigeonModel> renderer) {
        super(renderer);
    }

    @Override
    public void render(class_4587 poseStack, class_4597 buffer, int packedLight, CharredPigeon pigeon, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        method_17165().method_60879(poseStack, buffer.getBuffer(
              class_1921.method_42600(Envelope.resource("textures/entity/charred_pigeon/charred_pigeon_fire.png"))),
              0xFFFFFFFF, class_4608.field_21444);
    }
}
