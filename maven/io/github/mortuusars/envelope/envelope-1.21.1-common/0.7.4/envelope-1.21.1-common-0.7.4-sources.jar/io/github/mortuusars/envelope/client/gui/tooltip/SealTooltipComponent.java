package io.github.mortuusars.envelope.client.gui.tooltip;

import io.github.mortuusars.envelope.EnvelopeClient;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4597;
import net.minecraft.class_5684;
import net.minecraft.class_765;
import org.joml.Matrix4f;

public class SealTooltipComponent implements class_5684 {
    protected final Seal seal;

    public SealTooltipComponent(Seal seal) {
        this.seal = seal;
    }

    @Override
    public int method_32664(class_327 font) {
        return 35 + font.method_27525(seal.signature());
    }

    @Override
    public int method_32661() {
        return 32;
    }

    @Override
    public void method_32666(class_327 font, int x, int y, class_332 guiGraphics) {
        EnvelopeClient.getSealRenderer().render(seal, guiGraphics, x, y);
    }

    @Override
    public void method_32665(class_327 font, int x, int y, Matrix4f matrix, class_4597.class_4598 buffer) {
        // Signature:
        x += 34;
        y += 11;
        int color = seal.material().comp_349().impressionPalette().highlight().tint();
        int outlineColor = seal.material().comp_349().impressionPalette().shadow().tint();
        text(seal.signature(), font, x - 1, y, outlineColor, matrix, buffer);
        text(seal.signature(), font, x - 1, y - 1, outlineColor, matrix, buffer);
        text(seal.signature(), font, x, y - 1, outlineColor, matrix, buffer);
        text(seal.signature(), font, x + 1, y - 1, outlineColor, matrix, buffer);
        text(seal.signature(), font, x + 1, y, outlineColor, matrix, buffer);
        text(seal.signature(), font, x + 1, y + 1, outlineColor, matrix, buffer);
        text(seal.signature(), font, x, y + 1, outlineColor, matrix, buffer);
        text(seal.signature(), font, x - 1, y + 1, outlineColor, matrix, buffer);
        text(seal.signature(), font, x, y, color, matrix, buffer);
    }

    private void text(class_2561 text, class_327 font, int x, int y, int color, Matrix4f matrix, class_4597.class_4598 buffer) {
        font.method_30882(text, x, y, color, false, matrix, buffer,
              class_327.class_6415.field_33993, 0x00000000, class_765.field_32767);
    }
}
