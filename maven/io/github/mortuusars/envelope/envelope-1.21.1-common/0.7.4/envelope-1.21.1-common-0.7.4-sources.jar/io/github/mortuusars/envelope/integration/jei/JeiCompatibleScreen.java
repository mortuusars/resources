package io.github.mortuusars.envelope.integration.jei;

import io.github.mortuusars.envelope.client.gui.widget.textbox.TextBox;
import net.minecraft.class_437;

public interface JeiCompatibleScreen {
    default boolean shouldBlockJeiInput() {
        return this instanceof class_437 screen && screen.method_25399() instanceof TextBox textBox && textBox.getEditor().isSelecting();
    }
}
