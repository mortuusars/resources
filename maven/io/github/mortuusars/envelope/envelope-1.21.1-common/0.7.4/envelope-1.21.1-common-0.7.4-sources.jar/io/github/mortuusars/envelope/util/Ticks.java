package io.github.mortuusars.envelope.util;

import net.minecraft.class_155;

public abstract class Ticks {
    public static final int SECOND = class_155.field_29702;
    public static final int MINUTE = class_155.field_29703;
    public static final int IN_GAME_DAY = class_155.field_29704;

    public static long fromSeconds(double seconds) {
        return (long) (seconds * SECOND);
    }

    public static long fromMinutes(double minutes) {
        return (long) (minutes * MINUTE);
    }
}
