package io.github.mortuusars.envelope.mixin.villager_feeds_pigeon;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.VillagerPigeonFeeding;
import net.minecraft.class_1299;
import net.minecraft.class_1646;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3851;
import net.minecraft.class_3988;
import net.minecraft.class_4094;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1646.class)
public abstract class VillagerMixin extends class_3988
      implements class_4094, class_3851, VillagerPigeonFeeding.FeedingVillager {
    @Unique
    public int envelope$pigeonFoodPickupDelay = 0; // Villagers pick up the seeds themselves, so we need to block that when feeding
    @Unique
    public int envelope$pigeonFeedCooldown = 0;

    public VillagerMixin(class_1299<? extends class_3988> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Override
    public void envelope$addPigeonFoodPickupDelay(int delay) {
        envelope$pigeonFoodPickupDelay = delay;
    }

    @Inject(method = "customServerAiStep", at = @At("RETURN"))
    private void onCustomServerAiStep(CallbackInfo ci) {
        class_1646 villager = ((class_1646) (Object) this);

        if (envelope$pigeonFoodPickupDelay > 0) envelope$pigeonFoodPickupDelay--;
        if (envelope$pigeonFeedCooldown > 0) envelope$pigeonFeedCooldown--;

        if (Config.Server.VILLAGER_FEEDING_PIGEONS.get()
              && envelope$pigeonFeedCooldown <= 0
              && VillagerPigeonFeeding.tryFeed(villager)) {
            envelope$pigeonFeedCooldown = VillagerPigeonFeeding.getFeedCooldown(villager);
        }
    }

    @Inject(method = "wantsToPickUp", at = @At("HEAD"), cancellable = true)
    private void wantsToPickUp(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
        if (envelope$pigeonFoodPickupDelay > 0 && stack.method_31573(Envelope.Tags.Items.PIGEON_FOOD)) {
            cir.setReturnValue(false);
        }
    }

    // --

    @Inject(method = "addAdditionalSaveData", at = @At("RETURN"))
    private void save(class_2487 tag, CallbackInfo ci) {
        if (envelope$pigeonFoodPickupDelay > 0) tag.method_10569("EnvelopeItemPickupDelay", envelope$pigeonFoodPickupDelay);
        if (envelope$pigeonFeedCooldown > 0) tag.method_10569("EnvelopePigeonFeedCooldown", envelope$pigeonFeedCooldown);
    }

    @Inject(method = "readAdditionalSaveData", at = @At("RETURN"))
    private void load(class_2487 tag, CallbackInfo ci) {
        envelope$pigeonFoodPickupDelay = tag.method_10550("EnvelopeItemPickupDelay");
        envelope$pigeonFeedCooldown = tag.method_10550("EnvelopePigeonFeedCooldown");
    }
}
