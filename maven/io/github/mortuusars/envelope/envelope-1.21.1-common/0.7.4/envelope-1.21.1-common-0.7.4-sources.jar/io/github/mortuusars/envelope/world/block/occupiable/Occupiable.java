package io.github.mortuusars.envelope.world.block.occupiable;

import io.github.mortuusars.envelope.Envelope;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_4481;
import net.minecraft.class_5712;
import net.minecraft.class_7225;
import net.minecraft.class_9279;

public interface Occupiable {
    List<String> IGNORED_OCCUPANT_TAGS = Arrays.asList(
          "Air",
          "ArmorDropChances",
          "ArmorItems",
          "Brain",
          "CanPickUpLoot",
          "DeathTime",
          "FallDistance",
          "FallFlying",
          "Fire",
          "HandDropChances",
          "HandItems",
          "HurtByTimestamp",
          "HurtTime",
          "LeftHanded",
          "Motion",
          "NoGravity",
          "OnGround",
          "PortalCooldown",
          "Pos",
          "Rotation",
          "SleepingX",
          "SleepingY",
          "SleepingZ",
          "Passengers",
          "UUID",
          "leash"
    );

    boolean canBeOccupiedBy(class_1297 entity);

    List<Occupant.Mutable> getOccupants();

    class_3414 getOccupantEnterSound(class_1297 entity);

    class_3414 getOccupantExitSound(class_1297 entity);

    class_3414 getOccupantWorkSound();

    void playSound(class_3414 soundEvent, float volume, float pitch);

    default List<Occupant> getImmutableOccupants() {
        return getOccupants().stream().map(Occupant.Mutable::toImmutable).toList();
    }

    default int getMaxOccupantsCount() {
        return 3;
    }

    default boolean hasSpaceForAnotherOccupant() {
        return getOccupants().size() < getMaxOccupantsCount();
    }

    default int getMinimumTicksInsideForOccupant(class_1297 entity) {
        return 600;
    }

    default void addOccupant(class_2338 pos, class_2680 state, class_1297 entity) {
        if (!hasSpaceForAnotherOccupant() || !canBeOccupiedBy(entity)) return;

        entity.method_5848();
        entity.method_5772();

        class_2487 tag = new class_2487();
        entity.method_5662(tag);
        cleanupOccupantEntityTag(tag);
        getOccupants().add(new Occupant(class_9279.method_57456(tag), getFirstFreeSlotForOccupant(),
              getMinimumTicksInsideForOccupant(entity), 0).toMutable());

        entity.method_37908().method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43286(entity, state));
        playSound(getOccupantEnterSound(entity), 1.0F, entity.method_37908().method_8409().method_43057() * 0.2F + 0.85F);
        if (entity.method_37908() instanceof class_3218 level) {
            level.method_14199(class_2398.field_11204,
                  entity.method_23317(), entity.method_23318(), entity.method_23321(), 1, 0.2f, 0.2f, 0.2f, 0);
        }

        entity.method_31472();
        onOccupantsChanged();
    }

    default Optional<class_1297> releaseOccupant(class_1937 level, class_2338 pos, class_2680 state, Occupant occupant, ReleaseReason reason) {
        if (!(level instanceof class_3218 serverLevel)) return Optional.empty();
        if ((level.method_23886() || level.method_8419() || level.method_8546()) && reason != ReleaseReason.EMERGENCY) {
            return Optional.empty();
        }

        class_2350 direction = state.method_11654(class_4481.field_20419);
        class_2338 releasePos = pos.method_10093(direction);

        boolean isFrontBlockedOff = !level.method_8320(releasePos).method_26220(level, releasePos).method_1110();
        if (isFrontBlockedOff && reason != ReleaseReason.EMERGENCY) {
            return Optional.empty();
        }

        @Nullable class_1297 entity = createEntityFromOccupant(level, occupant, pos);
        if (entity == null) return Optional.empty();

        double offset = isFrontBlockedOff ? 0.0 : 0.55 + (double) (entity.method_17681() / 2.0F);
        double x = (double) pos.method_10263() + 0.5 + offset * (double) direction.method_10148();
        double y = (double) pos.method_10264() + 0.5 - (double) (entity.method_17682() / 2.0F);
        double z = (double) pos.method_10260() + 0.5 + offset * (double) direction.method_10165();
        entity.method_5808(x, y, z, entity.method_36454(), entity.method_36455());

        level.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43286(entity, state));
        playSound(getOccupantExitSound(entity), 1.0F, entity.method_37908().method_8409().method_43057() * 0.2F + 0.85F);
        serverLevel.method_14199(class_2398.field_11204,
              entity.method_23317(), entity.method_23318() + 0.5f, entity.method_23321(), 1, 0.2f, 0.2f, 0.2f, 0);

        if (level.method_8649(entity)) {
            onOccupantReleased(serverLevel, entity, reason);
            return Optional.of(entity);
        }

        return Optional.empty();
    }

    default @Nullable class_1297 createEntityFromOccupant(class_1937 level, Occupant occupant, class_2338 pos) {
        class_2487 tag = occupant.entityData().method_57461();
        cleanupOccupantEntityTag(tag);

        @Nullable class_1297 entity = class_1299.method_17842(tag, level, Function.identity());
        if (entity == null || !canBeOccupiedBy(entity)) {
            return null;
        }

        updateEntityAfterRelease(entity, occupant.ticksInside());
        return entity;
    }

    default List<class_1297> releaseAllOccupants(class_1937 level, class_2338 pos, class_2680 state, ReleaseReason reason) {
        List<class_1297> releasedEntities = new ArrayList<>();

        getOccupants().removeIf(occupant ->
              releaseOccupant(level, pos, state, occupant.toImmutable(), reason)
              .map(entity -> {
                  releasedEntities.add(entity);
                  return true;
              }).orElse(false));

        if (!releasedEntities.isEmpty()) {
            onOccupantsChanged();
        }

        return releasedEntities;
    }

    default void onOccupantReleased(class_1937 level, class_1297 entity, ReleaseReason reason) {
    }

    default void updateEntityAfterRelease(class_1297 entity, int ticksInside) {
        entity.method_5875(true);

        if (entity instanceof class_1429 animal) {
            int ageTicks = animal.method_5618();
            if (ageTicks < 0) {
                animal.method_5614(Math.min(0, ageTicks + ticksInside));
            } else if (ageTicks > 0) {
                animal.method_5614(Math.max(0, ageTicks - ticksInside));
            }

            animal.method_6476(Math.max(0, animal.method_29270() - ticksInside));
        }
    }

    default void onOccupantsChanged() {
    }

    default void tickOccupants(class_1937 level, class_2338 pos, class_2680 state) {
        if (getOccupants().removeIf(occupant -> occupant.tick()
              && releaseOccupant(level, pos, state, occupant.toImmutable(), ReleaseReason.DEFAULT).isPresent())) {
            onOccupantsChanged();
        }

        if (!getOccupants().isEmpty()) {
            if (level.method_8409().method_43058() < 0.004 * getOccupants().size()) {
                playSound(getOccupantWorkSound(), 1.0F, level.method_8409().method_43057() * 0.2F + 0.9F);
            }
        }
    }

    // -- Save / Load

    default void cleanupOccupantEntityTag(class_2487 tag) {
        IGNORED_OCCUPANT_TAGS.forEach(tag::method_10551);
    }

    default String getSerializedOccupantsName() {
        return "occupants";
    }

    default void saveOccupiable(class_2487 tag, class_7225.class_7874 registries) {
        tag.method_10566(getSerializedOccupantsName(), Occupant.LIST_CODEC.encodeStart(class_2509.field_11560, getImmutableOccupants()).getOrThrow());
    }

    default void loadOccupiable(class_2487 tag, class_7225.class_7874 registries) {
        getOccupants().clear();
        Occupant.LIST_CODEC
              .parse(class_2509.field_11560, tag.method_10580(getSerializedOccupantsName()))
              .resultOrPartial(error -> Envelope.LOGGER.error("Failed to parse occupants: '{}'", error))
              .map(list -> list.stream().map(Occupant::toMutable).toList())
              .ifPresent(list -> getOccupants().addAll(list));
    }

    // --

    default int getFirstFreeSlotForOccupant() {
        List<Integer> slots = getImmutableOccupants().stream()
              .map(Occupant::slot)
              .sorted()
              .toList();

        int slot = 0;
        while (true) {
            if (!slots.contains(slot)) {
                return slot;
            }
            slot++;
        }
    }

    enum ReleaseReason {
        DEFAULT,
        EMERGENCY;
    }
}