package io.github.mortuusars.envelope.integration.jei.category;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.integration.jei.EnvelopeJeiPlugin;
import io.github.mortuusars.envelope.integration.jei.EnvelopeJeiRecipeTypes;
import io.github.mortuusars.envelope.world.item.Unsealable;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailRecipe;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.gui.placement.HorizontalAlignment;
import mezz.jei.api.gui.widgets.IRecipeExtrasBuilder;
import mezz.jei.api.helpers.IJeiHelpers;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.category.AbstractRecipeCategory;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_8786;

public class MailingRecipeCategory extends AbstractRecipeCategory<class_8786<MailRecipe>> {
    private final IDrawable background;

    public MailingRecipeCategory(IJeiHelpers helper) {
        super(EnvelopeJeiRecipeTypes.MAILING_RECIPE_TYPE,
              class_2561.method_43471("envelope.jei.category.mailing"),
              helper.getGuiHelper().createDrawableItemLike(Envelope.Items.PACKAGE.get()), 146, 74);
        background = helper.getGuiHelper().createDrawable(
              Envelope.resource("textures/gui/jei/category_mailing.png"), 0, 0, getWidth(), getHeight());
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, class_8786<MailRecipe> recipeHolder, IFocusGroup focuses) {
        MailRecipe recipe = recipeHolder.comp_1933();

        builder.addInvisibleIngredients(RecipeIngredientRole.CATALYST)
              .addItemLike(Envelope.Items.PAPER_BOX.get())
              .addItemLike(Envelope.Items.PACKAGE.get());

        builder.addInvisibleIngredients(RecipeIngredientRole.INPUT)
              .addIngredient(EnvelopeJeiPlugin.SERVICE_ADDRESS_INGREDIENT, recipe.getAddress());
        builder.addInvisibleIngredients(RecipeIngredientRole.OUTPUT)
              .addIngredient(EnvelopeJeiPlugin.SERVICE_ADDRESS_INGREDIENT, recipe.getAddress());

        for (int row = 0; row < 2; row++) {
            for (int column = 0; column < 3; column++) {
                int index = column + row * 3;

                int xPos = 18;
                int yPos = 24;

                if (index >= recipe.method_8117().size()) continue;

                builder.addInputSlot(xPos + column * 18, yPos + row * 18)
                      .addIngredients(recipe.method_8117().get(index));
            }
        }

        builder.addOutputSlot(122, 33)
              .addItemStack(recipe.method_8110(Minecrft.registryAccess()));

        class_1799 resultItem = recipe.method_8110(Minecrft.registryAccess());
        if (!(resultItem.method_7909() instanceof Unsealable)) { // If not sealed
            PackageContents resultContents = PackageContents.of(resultItem);
            if (!resultContents.method_59987()) {
                // Makes contents "known" to jei usages lookup:
                builder.addInvisibleIngredients(RecipeIngredientRole.OUTPUT)
                      .addItemStacks(resultContents.getItems());
            }
        }

        builder.setShapeless(getWidth() - 9, getHeight() - 9);
    }

    @Override
    public void draw(class_8786<MailRecipe> recipe, IRecipeSlotsView recipeSlotsView, class_332 guiGraphics, double mouseX, double mouseY) {
        background.draw(guiGraphics, 0, 0);
    }

    @Override
    public void createRecipeExtras(IRecipeExtrasBuilder builder, class_8786<MailRecipe> recipeHolder, IFocusGroup focuses) {
        class_2561 component = recipeHolder.comp_1933().getAddress()
              .format()
              .withIcon()
              .toComponent();

        builder.addText(component, getWidth(), 12)
              .setPosition(0, 0)
              .setTextAlignment(HorizontalAlignment.CENTER)
              .setColor(0xFF808080);

        builder.addRecipeArrow().setPosition(90, 32);
    }
}