package io.github.mortuusars.envelope.world.block;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.clientbound.OpenLetterBlockViewScreenS2CP;
import io.github.mortuusars.envelope.util.VoxelShapeUtils;
import io.github.mortuusars.envelope.world.item.component.LetterContent;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3902;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class LetterBlock extends class_2248 implements class_2343 {
    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2746 TATTERED = class_2746.method_11825("tattered");
    public static final class_2746 HAS_CONTENT = class_2746.method_11825("has_content");

    public static final class_265 SHAPE_NORTH = class_2248.method_9541(3, 2, 15, 13, 14, 16);
    public static final class_265 SHAPE_EAST = class_2248.method_9541(0, 2, 3, 1, 14, 13);
    public static final class_265 SHAPE_SOUTH = class_2248.method_9541(3, 2, 0, 13, 14, 1);
    public static final class_265 SHAPE_WEST = class_2248.method_9541(15, 2, 3, 16, 14, 13);

    public LetterBlock(class_2251 properties) {
        super(properties);
        method_9590(method_9595().method_11664()
              .method_11657(FACING, class_2350.field_11043)
              .method_11657(TATTERED, false)
              .method_11657(HAS_CONTENT, true));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, TATTERED, HAS_CONTENT);
    }

    @Override
    public @NotNull class_1799 method_9574(class_4538 level, class_2338 pos, class_2680 state) {
        class_1799 stack = super.method_9574(level, pos, state);
        if (state.method_11654(TATTERED)) stack.method_57379(Envelope.DataComponents.LETTER_TATTERED, class_3902.field_17274);
        return stack;
    }

    @Override
    public @NotNull class_265 method_9530(@NotNull class_2680 state, @NotNull class_1922 pLevel,
                                        @NotNull class_2338 pPos, @NotNull class_3726 pContext) {
        return switch (state.method_11654(FACING)) {
            case field_11043 -> SHAPE_NORTH;
            case field_11034 -> SHAPE_EAST;
            case field_11035 -> SHAPE_SOUTH;
            case field_11039 -> SHAPE_WEST;
            default -> class_259.method_1077();
        };
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        class_2350 facing = context.method_8038();
        return facing.method_10166().method_10179()
              ? method_9595().method_11664()
              .method_11657(FACING, facing)
              .method_11657(TATTERED, context.method_8041().method_57824(Envelope.DataComponents.LETTER_TATTERED) != null)
              .method_11657(HAS_CONTENT, !context.method_8041()
                    .method_57825(Envelope.DataComponents.LETTER_CONTENT, LetterContent.EMPTY).isEmpty())
              : null;
    }

    @Override
    public boolean method_9558(@NotNull class_2680 state, @NotNull class_4538 level, class_2338 pos) {
        class_2350 facing = state.method_11654(FACING);
        return class_2248.method_20044(level, pos.method_10093(facing.method_10153()), facing);
    }

    @Override
    public @NotNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
        class_2350 facing = rotation.method_10503(state.method_11654(FACING));
        return facing.method_10166().method_10179()
              ? state.method_11657(FACING, facing)
              : state;
    }

    @Override
    public @NotNull class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new LetterBlockEntity(Envelope.BlockEntityTypes.LETTER.get(), pos, state);
    }

    // --

    @Override
    protected @NotNull class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        return !state.method_26184(level, pos)
              ? class_2246.field_10124.method_9564()
              : super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        if (level.method_8321(pos) instanceof LetterBlockEntity blockEntity) {
            blockEntity.setLetter(stack.method_46651(1));
            level.method_8408(pos, state.method_26204()); // Force block to update
        }
    }

    @Override
    public void method_9536(class_2680 state, @NotNull class_1937 level, @NotNull class_2338 pos, class_2680 newState, boolean isMoving) {
        if (!state.method_27852(newState.method_26204()) && level.method_8321(pos) instanceof LetterBlockEntity blockEntity) {
            class_1264.method_5449(level, pos.method_10263(), pos.method_10264(), pos.method_10260(), blockEntity.getLetter(null));
            blockEntity.setLetter(class_1799.field_8037);
        }
        super.method_9536(state, level, pos, newState, isMoving);
    }

    // --

    @Override
    protected @NotNull class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
        if (level.method_8321(pos) instanceof LetterBlockEntity blockEntity
              && player instanceof class_3222 serverPlayer) {
            Packets.sendToClient(new OpenLetterBlockViewScreenS2CP(blockEntity.getLetter(player), pos), serverPlayer);
        }
        level.method_43129(player, player, Envelope.SoundEvents.PAPER_CRACKLE.get(), class_3419.field_15248, 1, 1);
        return class_1269.field_51370;
    }

    public void ignite(@NotNull class_2680 state, @NotNull class_1937 level, @NotNull class_2338 pos,
                       @Nullable class_2350 direction, @Nullable class_1309 igniter) {
        if (level instanceof class_3218 serverLevel) {
            class_265 shape = state.method_26218(level, pos);
            class_238 bounds = shape.method_1107();
            class_243 p = class_243.method_24954(pos).method_1019(bounds.method_1005());
            serverLevel.method_14199(class_2398.field_11240, p.field_1352, p.field_1351, p.field_1350, 12,
                  bounds.method_17939() / 2, bounds.method_17940() / 2, bounds.method_17941() / 2, 0.01);

            level.method_8544(pos); // Prevent item dropping
            level.method_8650(pos, false);
            level.method_8396(null, pos, class_3417.field_14993, class_3419.field_15245, 1, 1);
        }
    }
}
