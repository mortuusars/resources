package io.github.mortuusars.envelope.world.item.component.mail.log.record;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.mail.address.Address;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ArrivedRecord(Address address, long timestamp) implements DeliveryRecord {
    public static final MapCodec<ArrivedRecord> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
          Address.CODEC.fieldOf("address").forGetter(ArrivedRecord::address),
          Codec.LONG.fieldOf("timestamp").forGetter(ArrivedRecord::timestamp)
    ).apply(i, ArrivedRecord::new));

    public static final class_9139<class_9129, ArrivedRecord> STREAM_CODEC = class_9139.method_56435(
          Address.STREAM_CODEC, ArrivedRecord::address,
          class_9135.field_48551, ArrivedRecord::timestamp,
          ArrivedRecord::new
    );

    @Override
    public Type getType() {
        return Type.ARRIVED;
    }

    @Override
    public class_5250 getDisplayComponent() {
        class_2561 address = this.address.format()
              .withIcon()
              .withIconColor(Colors.ADDRESS_RECIPIENT)
              .withColor(Colors.ADDRESS_RECIPIENT)
              .toComponent();

        return class_2561.method_43469("gui.envelope.delivery_log.record.arrived", address, getElapsedTime(timestamp).orElse(class_2561.method_43473()));
    }
}
