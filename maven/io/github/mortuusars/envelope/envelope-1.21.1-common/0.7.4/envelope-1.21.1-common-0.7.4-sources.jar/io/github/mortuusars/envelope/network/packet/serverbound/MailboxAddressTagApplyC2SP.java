package io.github.mortuusars.envelope.network.packet.serverbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.packet.Packet;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlock;
import io.github.mortuusars.envelope.world.item.AddressTagItem;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2598;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record MailboxAddressTagApplyC2SP(class_1268 hand, String addressId, class_2338 pos) implements Packet {
    public static final class_2960 ID = Envelope.resource("mailbox_address_tag_apply");
    public static final class_9154<MailboxAddressTagApplyC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, MailboxAddressTagApplyC2SP> STREAM_CODEC = class_9139.method_56436(
          class_9135.field_48550.method_56432(i -> class_1268.values()[i], class_1268::ordinal), MailboxAddressTagApplyC2SP::hand,
          class_9135.field_48554, MailboxAddressTagApplyC2SP::addressId,
          class_2338.field_48404, MailboxAddressTagApplyC2SP::pos,
          MailboxAddressTagApplyC2SP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        class_1799 tag = player.method_5998(hand);

        if (!(tag.method_7909() instanceof AddressTagItem)) {
            Envelope.LOGGER.error("Cannot handle {} packet: item in hand is not an AddressTagItem, but {}.", ID, tag);
            return false;
        }

        class_2680 state = player.method_37908().method_8320(pos);
        if (!(state.method_26204() instanceof MailboxBlock block)) {
            Envelope.LOGGER.error("Cannot handle {} packet: block at pos [{}] is not a MailboxBlock", ID, pos);
            return false;
        }

        block.changeAddress(player, pos, hand, addressId);
        return true;
    }
}
