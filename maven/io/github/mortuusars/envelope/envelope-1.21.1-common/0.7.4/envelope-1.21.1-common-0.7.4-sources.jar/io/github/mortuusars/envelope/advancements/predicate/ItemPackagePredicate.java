package io.github.mortuusars.envelope.advancements.predicate;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2073;
import net.minecraft.class_9331;
import net.minecraft.class_9365;
import net.minecraft.class_9648;

public record ItemPackagePredicate(Optional<class_9648<class_1799, class_2073>> items) implements class_9365<PackageContents> {
    public static final Codec<ItemPackagePredicate> CODEC = RecordCodecBuilder.create(i -> i.group(
                class_9648.method_59623(class_2073.field_45754).optionalFieldOf("items").forGetter(ItemPackagePredicate::items))
          .apply(i, ItemPackagePredicate::new)
    );

    @Override
    public @NotNull class_9331<PackageContents> method_58163() {
        return Envelope.DataComponents.PACKAGE_CONTENTS;
    }

    public boolean matches(class_1799 stack, PackageContents contents) {
        return this.items.isEmpty() || this.items.get().method_59625(contents.getItems());
    }
}
