package io.github.mortuusars.envelope.world.block;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.envelope.Envelope;
import net.minecraft.class_1275;
import net.minecraft.class_1657;
import net.minecraft.class_173;
import net.minecraft.class_174;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import net.minecraft.class_8567;
import net.minecraft.class_9297;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class LetterBlockEntity extends class_2586 implements class_1275 {
    private static final Logger LOGGER = LogUtils.getLogger();

    protected @Nullable class_9297 loot = null;
    protected @NotNull class_1799 letter = class_1799.field_8037;

    public LetterBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public LetterBlockEntity(class_2338 pos, class_2680 state) {
        super(Envelope.BlockEntityTypes.LETTER.get(), pos, state);
    }

    public class_1799 getLetter(@Nullable class_1657 player) {
        unpackLootTableIfPresent(player);
        return !letter.method_7960() ? letter : new class_1799(Envelope.Items.LETTER.get());
    }

    public void setLetter(class_1799 letter) {
        this.letter = letter;
        this.loot = null;
        method_5431();
    }

    protected void unpackLootTableIfPresent(@Nullable class_1657 player) {
        if (loot != null && field_11863 instanceof class_3218 serverLevel) {
            if (!letter.method_7960()) {
                Envelope.LOGGER.warn("Unpacking loot-table of the Letter block, that already has letter defined. " +
                      "Existing letter will be overriden.");
            }

            class_8567.class_8568 params = new class_8567.class_8568(serverLevel)
                  .method_51874(class_181.field_24424, class_243.method_24953(method_11016()));

            if (player != null) {
                params.method_51871(player.method_7292()).method_51874(class_181.field_1226, player);
            }

            if (player instanceof class_3222 serverPlayer) {
                class_174.field_24479.method_27993(serverPlayer, loot.comp_2414());
            }

            serverLevel.method_8503().method_58576().method_58295(loot.comp_2414())
                  .method_51879(params.method_51875(class_173.field_1179), loot.comp_2415())
                  .stream()
                  .findAny()
                  .ifPresent(this::setLetter);
        }
    }

    // --

    @Override
    public @NotNull class_2561 method_5477() {
        return letter.method_7964();
    }

    @Override
    public boolean method_16914() {
        return class_1275.super.method_16914() || letter.method_57826(class_9334.field_50239);
    }

    @Override
    public @Nullable class_2561 method_5797() {
        return letter.method_57824(class_9334.field_49631);
    }

    // -- Sync

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public @NotNull class_2487 method_16887(class_7225.class_7874 registries) {
        return method_58692(registries);
    }

    // -- Save/Load

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        if (loot != null) {
            class_9297.field_49361.encodeStart(class_2509.field_11560, loot)
                  .resultOrPartial(LOGGER::error)
                  .ifPresent(lootTag -> tag.method_10566("Loot", lootTag));
        }
        if (!letter.method_7960()) {
            tag.method_10566("Letter", letter.method_57376(registries, new class_2487()));
        }
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        if (tag.method_10573("Loot", class_2487.field_33260)) {
            loot = class_9297.field_49361.parse(class_2509.field_11560, tag.method_10562("Loot"))
                  .resultOrPartial(LOGGER::error)
                  .orElse(null);
        }
        if (tag.method_10573("Letter", class_2487.field_33260)) {
            letter = class_1799.method_57360(registries, tag.method_10562("Letter"))
                  .orElse(class_1799.field_8037);
        }
    }
}
