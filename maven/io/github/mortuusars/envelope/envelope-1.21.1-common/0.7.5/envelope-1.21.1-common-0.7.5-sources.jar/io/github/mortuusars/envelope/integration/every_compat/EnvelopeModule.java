package io.github.mortuusars.envelope.integration.every_compat;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.block.PigeonholeBlock;
import net.mehvahdjukaar.every_compat.api.SimpleEntrySet;
import net.mehvahdjukaar.every_compat.api.TabAddMode;
import net.mehvahdjukaar.every_compat.api.TextureInfo;
import net.mehvahdjukaar.every_compat.modules.EveryCompatModule;
import net.mehvahdjukaar.moonlight.api.platform.RegHelper;
import net.mehvahdjukaar.moonlight.api.resources.SimpleTagBuilder;
import net.mehvahdjukaar.moonlight.api.resources.pack.ResourceGenTask;
import net.mehvahdjukaar.moonlight.api.set.wood.VanillaWoodTypes;
import net.mehvahdjukaar.moonlight.api.set.wood.WoodType;
import net.minecraft.class_3481;
import net.minecraft.class_4970;
import net.minecraft.class_7706;
import net.minecraft.class_7924;
import java.util.function.Consumer;

public class EnvelopeModule extends EveryCompatModule {
    SimpleEntrySet<WoodType, PigeonholeBlock> pigeonholes;

    public EnvelopeModule() {
        super(Envelope.ID, "env", Envelope.ID);

        pigeonholes = SimpleEntrySet.builder(
                    WoodType.class, "pigeonhole",
                    Envelope.Blocks.OAK_PIGEONHOLE, () -> VanillaWoodTypes.OAK,
                    (w) -> new PigeonholeBlock(class_4970.class_2251.method_9630(net.minecraft.class_2246.field_20422)
                          .method_9632(2f)
                          .method_31710(w.getColor()))
              )
              .addTextureM(
                    Envelope.resource("block/oak_pigeonhole_side"),
                    Envelope.resource("block/pigeonhole_side_everycompat_mask")
              )
              .addTextureM(
                    Envelope.resource("block/oak_pigeonhole_front"),
                    Envelope.resource("block/pigeonhole_front_everycompat_mask")
              )
              .addTexture(TextureInfo.of(Envelope.resource("block/oak_pigeonhole_front"))
                    .mask(Envelope.resource("block/pigeonhole_front_waste_everycompat_mask"))
                    .overlay(Envelope.resource("block/pigeonhole_front_waste_everycompat_overlay"))
                    .customTexture("block/oak_pigeonhole_front_waste"))
              .addTexture(Envelope.resource("block/oak_pigeonhole_end"))
              .addTag(class_3481.field_33713, class_7924.field_41254)
              .addTag(class_3481.field_49147, class_7924.field_41254)
              .addTag(Envelope.Tags.Blocks.PIGEONHOLES, class_7924.field_41254)
              .addTag(Envelope.Tags.Items.PIGEONHOLES, class_7924.field_41197)
              .addTile(Envelope.BlockEntityTypes.PIGEONHOLE)
              .setTab(getTab(class_7706.field_40197))
              .setTabMode(TabAddMode.AFTER_SAME_TYPE)
              .defaultRecipe()
              .build();

        this.addEntry(pigeonholes);

        RegHelper.addExtraPOIStatesRegistration(event -> {
            pigeonholes.blocks.forEach((w, block) -> {
                event.addBlock(Envelope.PoiTypes.PIGEONHOLE, block);
                Envelope.LOGGER.info("Registered '{}' as '{}' POI.", block, Envelope.PoiTypes.PIGEONHOLE.method_29177());
            });
        });
    }

    @Override
    public void addDynamicServerResources(Consumer<ResourceGenTask> executor) {
        super.addDynamicServerResources(executor);
        executor.accept((manager, sink) -> {
            pigeonholes.blocks.forEach((w, block) -> {
                if (!w.canBurn()) return;
                sink.addTag(
                      SimpleTagBuilder.of(Envelope.Tags.Blocks.PIGEONHOLES_THAT_BURN)
                            .addEntry(block), class_7924.field_41254);
            });
        });
    }
}
