package io.github.mortuusars.envelope.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.envelope.command.argument.AddressArgument;
import io.github.mortuusars.envelope.command.suggestion.AddressSuggestions;
import io.github.mortuusars.envelope.util.bugger.Bugger;
import io.github.mortuusars.envelope.world.delivery.Delivery;
import io.github.mortuusars.envelope.world.delivery.phase.DeliveryPhase;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.AddressFormatter;
import io.github.mortuusars.envelope.world.service.MailService;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2179;
import net.minecraft.class_2287;
import net.minecraft.class_2290;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_7157;
import net.minecraft.network.chat.*;
import java.util.*;

public class EnvelopeCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 context) {
        dispatcher.register(class_2170.method_9247("envelope")
              .requires((stack) -> stack.method_9259(2))
              .then(class_2170.method_9247("send")
                    .then(class_2170.method_9244("mail", class_2287.method_9776(context))
                          .executes(c -> sendMail(c, class_2287.method_9777(c, "mail"), Address.UNKNOWN))
                          .then(class_2170.method_9244("sender", class_2179.method_9284())
                                .executes(c -> sendMail(c,
                                      class_2287.method_9777(c, "mail"),
                                      parseAddress(class_2179.method_9285(c, "sender")))))))
              .then(class_2170.method_9247("mailbox")
                    .then(class_2170.method_9247("list")
                          .executes(EnvelopeCommand::listAllMailboxes)
                          .then(class_2170.method_9247("default")
                                .executes(EnvelopeCommand::listDefaultMailboxes)))
                    .then(class_2170.method_9247("position")
                          .then(class_2170.method_9244("address", AddressArgument.block())
                                .suggests(AddressSuggestions.block())
                                .executes(c -> mailboxPosition(c, AddressArgument.getBlock(c, "address"))))))
              .then(EnvelopeDebugCommand.commands())
              .then(class_2170.method_9247("test")
                    .requires(stack -> {
                        if (!Bugger.isEnabled()) {
                            stack.method_9213(class_2561.method_43470("Requires debug mode."));
                            return false;
                        }
                        return true;
                    })
                    .executes(EnvelopeCommand::test)));
    }

    // -- Mail

    private static int sendMail(CommandContext<class_2168> context, class_2290 item, Address sender) throws CommandSyntaxException {
        class_3218 level = context.getSource().method_9225();
        class_1799 mail = item.method_9781(1, false);

        Address recipient = Mail.getRecipientOrUnknown(mail);

        if (recipient.equals(Address.UNKNOWN)) {
            context.getSource().method_9213(class_2561.method_43470("Cannot send: recipient is not defined."));
            return 0;
        }

        MailService.of(level).getDeliveryManager()
              .startService(Delivery.draft()
                    .deliver(mail)
                    .from(sender)
                    .to(recipient))
              .ifPresentOrElse(
                    delivery -> {
                        class_2561 message = class_2561.method_43470("Mail sent to ")
                              .method_10852(delivery.delivery().getRecipient().format().asRecipient().toComponent());
                        context.getSource().method_9226(() -> message, true);
                    },
                    error -> context.getSource().method_9213(class_2561.method_43470("Cannot send: ").method_10852(error.getTranslation()))
              );

        return 0;
    }

    private static Address parseAddress(class_2487 tag) {
        return Address.CODEC.parse(class_2509.field_11560, tag).getOrThrow();
    }

    // -- Mailbox

    private static int listAllMailboxes(CommandContext<class_2168> context) {
        class_3218 level = context.getSource().method_9225();
        Set<Address.Block> addresses = MailService.of(level).getMailboxes().getAllAddresses();

        if (!addresses.isEmpty()) {
            context.getSource().method_9226(() -> class_2561.method_43470("All mailboxes:"), true);
            for (Address.Block address : addresses) {
                context.getSource().method_9226(() -> copyableAddressAndPos(address,
                      MailService.of(level).getMailboxes().getPositionOf(address)), true);
            }
        } else {
            context.getSource().method_9226(() ->
                  class_2561.method_43470("There are no known mailboxes."), true);
        }
        return 0;
    }

    private static int listDefaultMailboxes(CommandContext<class_2168> context) {
        class_3218 level = context.getSource().method_9225();

        Map<Address.Player, Address.Block> defaultAddresses = MailService.of(level).getPlayers().getDefaultAddresses();

        if (!defaultAddresses.isEmpty()) {
            context.getSource().method_9226(() -> class_2561.method_43470("Default addresses:"), true);

            defaultAddresses.forEach((playerAddress, address) -> {
                Optional<class_2338> position = MailService.of(level).getMailboxes().getPositionOf(address);
                context.getSource().method_9226(() -> class_2561.method_43470(playerAddress.toString())
                      .method_27693(" - ")
                      .method_10852(copyableAddressAndPos(address, position)), true);
            });
        } else {
            context.getSource().method_9226(() ->
                  class_2561.method_43470("There are no default mailboxes."), true);
        }

        return 0;
    }

    private static int mailboxPosition(CommandContext<class_2168> context, Address.Block address) {
        class_3218 level = context.getSource().method_9225();
        if (!MailService.of(level).getMailboxes().exists(address)) {
            context.getSource().method_9213(address.getName().method_27693(" does not exist."));
            return 1;
        }

        MailService.of(level).getMailboxes().getPositionOf(address)
              .ifPresentOrElse(
                    pos -> context.getSource().method_9226(() -> copyableAddressAndPos(address, Optional.of(pos)), true),
                    () -> context.getSource().method_9213(address.getName()
                          .method_27693(" does not have a position associated with it.")));
        return 0;
    }

    private static class_5250 copyableAddressAndPos(Address address, Optional<class_2338> pos) {
        String addressId = address.getName().getString();
        String posStr = pos.map(class_2338::method_23854).orElse("");
        String posToCopy = posStr.replace(",", "");

        return address.getName()
              .method_27696(class_2583.field_24360
                    .method_36139(AddressFormatter.NEUTRAL_COLOR)
                    .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Copy Address")
                          .method_27693("\n")
                          .method_10852(class_2561.method_43470(addressId).method_27692(class_124.field_1080))))
                    .method_10958(new class_2558(class_2558.class_2559.field_21462, addressId)))
              .method_10852(class_2561.method_43470("@[" + posStr + "]").method_27696(class_2583.field_24360
                    .method_10977(class_124.field_1068)
                    .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Copy Position")
                          .method_27693("\n")
                          .method_10852(class_2561.method_43470(posToCopy).method_27692(class_124.field_1080))))
                    .method_10958(new class_2558(class_2558.class_2559.field_21462, posToCopy))));
    }

    // --

    private static int test(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_3222 player = context.getSource().method_9207();

        MailService.of(player.method_51469()).getDeliveryManager()
              .startService(Delivery.draft()
                    .deliver(Mail.createPackage(new PackageContents(List.of(new class_1799(class_1802.field_8820))))
                          .get())
                    .from(new Address.Block("Blue"))
                    .to(new Address.Block("Red"))
                    .startAtPhase(DeliveryPhase.DISPATCHING_DELIVERY));

//        ItemStack pkg = new ItemStack(Envelope.Items.PACKAGE.get());
//        pkg.set(Envelope.DataComponents.PACKAGE_CONTENTS, new PackageContents(List.of(new ItemStack(Items.FEATHER, 5))));
//        pkg.set(Envelope.DataComponents.SENDER, new Address.Block("Original-Sender"));
//        pkg.set(Envelope.DataComponents.RECIPIENT, new Address.Block("Base"));
//        pkg.set(Envelope.DataComponents.PAYBACK, Payback.createOrDefault(List.of(
//              new RequestedItem(Items.EMERALD, 3), new RequestedItem(ItemTags.LOGS, 13))));
//
//        Mail mail = new Mail(pkg);
//
//        ItemStack paybackPackage = new ItemStack(Envelope.Items.PAYBACK_PACKING_BOX.get());
//        paybackPackage.set(Envelope.DataComponents.PAYBACK_SUBJECT, new StoredItemStack(mail.getItemCopy()));
//        paybackPackage.set(Envelope.DataComponents.SENDER, Address.MAIL_SERVICE);
//        paybackPackage.set(Envelope.DataComponents.RECIPIENT, mail.getRecipient());
//
//        Containers.dropItemStack(context.getSource().getLevel(), player.getX(), player.getY(), player.getZ(), paybackPackage);

        return 0;
    }
}