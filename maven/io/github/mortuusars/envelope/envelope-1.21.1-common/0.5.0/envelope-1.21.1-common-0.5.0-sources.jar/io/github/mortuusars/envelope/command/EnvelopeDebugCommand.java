package io.github.mortuusars.envelope.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import io.github.mortuusars.envelope.util.bugger.test.BuggerTests;
import io.github.mortuusars.envelope.util.bugger.test.TestResults;
import io.github.mortuusars.envelope.util.bugger.test.cases.DeliveryHandlerTests;
import io.github.mortuusars.envelope.util.bugger.test.cases.RequestedItemTests;
import io.github.mortuusars.envelope.world.service.MailService;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3218;

public class EnvelopeDebugCommand {
    public static LiteralArgumentBuilder<class_2168> commands() {
        return class_2170.method_9247("debug")
              .then(class_2170.method_9247("expire_all_awaiting_payback")
                    .executes(EnvelopeDebugCommand::timeoutAllPaybackMail))
              .then(class_2170.method_9247("tests")
                    .executes(EnvelopeDebugCommand::runBuggerTests));
    }

    private static int timeoutAllPaybackMail(CommandContext<class_2168> context) {
        class_3218 level = context.getSource().method_9225();
        MailService service = MailService.of(level);
        int returnedCount = service.getPaybackDepartment().returnAllAwaitingAsTimedOut();

        if (returnedCount > 0) {
            context.getSource().method_9226(() -> class_2561.method_43470("Returned " +
                  returnedCount + " mail awaiting payback."), true);
        } else {
            context.getSource().method_9213(class_2561.method_43470("No mail awaiting payback is returned."));
        }

        return 0;
    }

    private static int runBuggerTests(CommandContext<class_2168> context) {
        TestResults testResults = new BuggerTests()
              .add(new RequestedItemTests(context.getSource().method_9211()))
              .add(new DeliveryHandlerTests(context.getSource().method_9211()))
              .run(count -> context.getSource().method_9226(() ->
                    class_2561.method_43470("Running " + count + " bugger tests."), true));

        context.getSource().method_9226(() -> class_2561.method_43470("Bugger tests finished:"), true);

        if (testResults.failed().isEmpty()) {
            context.getSource().method_9226(() -> class_2561.method_43470("All tests are passed!")
                  .method_27692(class_124.field_1060), true);
        } else {
            context.getSource().method_9226(() -> class_2561.method_43470("Passed: " + testResults.passed().size() + "\n"), true);
            context.getSource().method_9226(() -> class_2561.method_43470("Failed: " + testResults.failed().size() + ":")
                  .method_27692(class_124.field_1061), true);

            testResults.failed().forEach(failedTest -> {
                context.getSource().method_9226(() -> class_2561.method_43470(" " + failedTest.name() + ": " + failedTest.error())
                      .method_27692(class_124.field_1061), true);
            });
        }

        return 0;
    }
}
