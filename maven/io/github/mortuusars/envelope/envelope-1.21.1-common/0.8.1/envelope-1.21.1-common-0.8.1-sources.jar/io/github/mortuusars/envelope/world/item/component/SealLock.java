package io.github.mortuusars.envelope.world.item.component;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.world.level.saveddata.SealLocks;
import io.github.mortuusars.mortaar.util.GameTimeId;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3544;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

/**
 * Defines a lock that can be locked or unlocked, depending on its presence in {@link SealLocks}.
 */
public record SealLock(String owner, GameTimeId id) {
    public static final Codec<SealLock> CODEC = Codec.STRING.comapFlatMap(SealLock::parse, SealLock::toString);

    public static final class_9139<class_9129, SealLock> STREAM_CODEC = class_9139.method_56435(
          class_9135.field_48554, SealLock::owner,
          GameTimeId.STREAM_CODEC, SealLock::id,
          SealLock::new
    );

    public SealLock {
        Preconditions.checkArgument(!owner.isBlank(), "Owner cannot be empty.");
    }

    public static DataResult<SealLock> parse(String string) {
        if (class_3544.method_15438(string)) {
            return DataResult.error(() -> "SealLock cannot be parsed from null or empty string.");
        }

        int hash = string.indexOf('#');
        if (hash == -1) {
            return DataResult.error(() -> "Incorrect format for SealLock string. Expected format: 'owner#1D' Got: " + string);
        }

        try {
            String owner = string.substring(0, hash);
            GameTimeId id = GameTimeId.parseFromHex(string.substring(hash + 1)).getOrThrow();
            return DataResult.success(new SealLock(owner, id));
        } catch (Exception e) {
            return DataResult.error(() -> "Failed to parse SealLock: " + e.getMessage());
        }
    }

    @Override
    public @NotNull String toString() {
        return owner + "#" + id;
    }

    // --

    public boolean isOwnedBy(class_1657 player) {
        return owner.equalsIgnoreCase(player.method_5820());
    }

    public boolean isLocked(class_1937 level) {
        return SealLocks.get(level).isLocked(this);
    }

    public boolean isLockedFor(class_1657 player) {
        if (Config.Server.SOULBOUND_SEAL_OWNER_BYPASSES_LOCK.get() && isOwnedBy(player)) {
            return false;
        }

        return isLocked(player.method_37908());
    }

    public boolean lock(class_1937 level) {
        return SealLocks.get(level).lock(this);
    }

    public boolean unlock(class_1937 level) {
        return SealLocks.get(level).unlock(this);
    }

    public static boolean unlockAllFrom(String owner, class_1937 level) {
        return SealLocks.get(level).unlockAllFrom(owner);
    }
}
