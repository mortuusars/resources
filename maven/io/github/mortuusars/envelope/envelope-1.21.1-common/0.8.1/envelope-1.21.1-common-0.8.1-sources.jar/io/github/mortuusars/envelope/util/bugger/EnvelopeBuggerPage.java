package io.github.mortuusars.envelope.util.bugger;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.mortaar.bugger.screen.page.BuggerScreenPage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

public class EnvelopeBuggerPage implements BuggerScreenPage {
    @Override
    public String getTitle() {
        return "Envelope";
    }

    @Override
    public List<String> getLeftLines() {
        return Envelope.BuggerData.MAIL_SERVICE.get()
              .map(tag -> {

                  List<String> lines = new ArrayList<>(List.of(
                        "Mailboxes: " + tag.method_10550("mailboxes"),
                        "",
                        "Mail:",
                        "  Dropped: " + tag.method_10550("dropped_mail_count"),
                        "  Awaiting Payback: " + tag.method_10550("payback_pending_mail_count"),
                        "  In Cloud Depository: " + tag.method_10550("cloud_depository_count"),
                        "",
                        "Couriers:",
                        "  Real: " + tag.method_10550("delivering_couriers"),
                        "  Background: " + tag.method_10550("background_delivering_couriers"),
                        "  Finished: " + tag.method_10550("background_finished_couriers")
                  ));

                  class_2499 deliveries = tag.method_10554("deliveries", class_2520.field_33258);
                  if (!deliveries.isEmpty()) {
                      lines.add("");
                      lines.add("Deliveries:");
                      for (class_2520 delivery : deliveries) {
                          lines.add("  " + delivery.method_10714());
                      }
                  }

                  return lines;
              })
              .orElse(Collections.emptyList());
    }
}
