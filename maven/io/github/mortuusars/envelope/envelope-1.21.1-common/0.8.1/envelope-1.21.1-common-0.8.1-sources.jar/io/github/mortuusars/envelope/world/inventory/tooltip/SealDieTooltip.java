package io.github.mortuusars.envelope.world.inventory.tooltip;

import io.github.mortuusars.envelope.world.item.component.seal.SealSymbol;
import java.util.Optional;
import net.minecraft.class_5632;
import net.minecraft.class_9791;

public record SealDieTooltip(Optional<class_9791<SealSymbol>> die) implements class_5632 {
}
