package io.github.mortuusars.envelope.client.model;

import io.github.mortuusars.envelope.world.entity.CourierBat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_5597;
import net.minecraft.class_630;
import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;
import net.minecraft.class_8928;
import org.jetbrains.annotations.NotNull;

@Environment(EnvType.CLIENT)
public class CourierBatModel extends class_5597<CourierBat> {
    private final class_630 root;
    private final class_7184 batFlyingWithBackpack;
    private final class_7184 testAnimation;

    public CourierBatModel(class_630 root) {
        super(class_1921::method_23576);
        this.root = root;

        batFlyingWithBackpack = class_7184.class_7185.method_41818(0.5F)
              .method_41817()
              .method_41820(
                    "head",
                    new class_7179(
                          class_7179.class_7183.field_37887,
                          new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.125F, class_7187.method_41829(20.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "head",
                    new class_7179(
                          class_7179.class_7183.field_37886,
                          new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.125F, class_7187.method_41823(0.0F, 2.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.25F, class_7187.method_41823(0.0F, 1.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.375F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.4583F, class_7187.method_41823(0.0F, -1.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "body",
                    new class_7179(
                          class_7179.class_7183.field_37887,
                          new class_7186(0.0F, class_7187.method_41829(40.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.25F, class_7187.method_41829(52.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.5F, class_7187.method_41829(40.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "body",
                    new class_7179(
                          class_7179.class_7183.field_37886,
                          new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.125F, class_7187.method_41823(0.0F, 2.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.25F, class_7187.method_41823(0.0F, 1.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.375F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.4583F, class_7187.method_41823(0.0F, -1.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "feet",
                    new class_7179(
                          class_7179.class_7183.field_37887,
                          new class_7186(0.0F, class_7187.method_41829(10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.125F, class_7187.method_41829(-21.25F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.25F, class_7187.method_41829(-12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.5F, class_7187.method_41829(10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "right_wing",
                    new class_7179(
                          class_7179.class_7183.field_37887,
                          new class_7186(0.0F, class_7187.method_41829(0.0F, 25.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.125F, class_7187.method_41829(0.0F, -55.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.25F, class_7187.method_41829(0.0F, 35.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.375F, class_7187.method_41829(0.0F, 45.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.5F, class_7187.method_41829(0.0F, 25.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "right_wing_tip",
                    new class_7179(
                          class_7179.class_7183.field_37887,
                          new class_7186(0.0F, class_7187.method_41829(0.0F, 50.5F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.0417F, class_7187.method_41829(0.0F, 65.5F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.2083F, class_7187.method_41829(0.0F, -135.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.5F, class_7187.method_41829(0.0F, 50.5F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "left_wing",
                    new class_7179(
                          class_7179.class_7183.field_37887,
                          new class_7186(0.0F, class_7187.method_41829(0.0F, -25.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.125F, class_7187.method_41829(0.0F, 55.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.25F, class_7187.method_41829(0.0F, -35.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.375F, class_7187.method_41829(0.0F, -45.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.5F, class_7187.method_41829(0.0F, -25.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "left_wing_tip",
                    new class_7179(
                          class_7179.class_7183.field_37887,
                          new class_7186(0.0F, class_7187.method_41829(0.0F, -50.5F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.0417F, class_7187.method_41829(0.0F, -65.5F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.2083F, class_7187.method_41829(0.0F, 135.0F, 0.0F), class_7179.class_7181.field_37884),
                          new class_7186(0.5F, class_7187.method_41829(0.0F, -50.5F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41821();

        testAnimation = class_7184.class_7185.method_41818(0.5F)
              .method_41817()
              .method_41820(
                    "head",
                    new class_7179(
                          class_7179.class_7183.field_37887,
//                          new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.125F, KeyframeAnimations.degreeVec(20.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                          new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "head",
                    new class_7179(
                          class_7179.class_7183.field_37886,
//                          new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.125F, KeyframeAnimations.posVec(0.0F, 2.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.25F, KeyframeAnimations.posVec(0.0F, 1.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.4583F, KeyframeAnimations.posVec(0.0F, -1.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                          new class_7186(0.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "body",
                    new class_7179(
                          class_7179.class_7183.field_37887,
//                          new Keyframe(0.0F, KeyframeAnimations.degreeVec(40.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.25F, KeyframeAnimations.degreeVec(52.5F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                          new class_7186(0.5F, class_7187.method_41829(40.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "body",
                    new class_7179(
                          class_7179.class_7183.field_37886,
//                          new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.125F, KeyframeAnimations.posVec(0.0F, 2.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.25F, KeyframeAnimations.posVec(0.0F, 1.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.4583F, KeyframeAnimations.posVec(0.0F, -1.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                          new class_7186(0.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "feet",
                    new class_7179(
                          class_7179.class_7183.field_37887,
//                          new Keyframe(0.0F, KeyframeAnimations.degreeVec(10.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.125F, KeyframeAnimations.degreeVec(-21.25F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.25F, KeyframeAnimations.degreeVec(-12.5F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                          new class_7186(0.5F, class_7187.method_41829(10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "right_wing",
                    new class_7179(
                          class_7179.class_7183.field_37887,
//                          new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 25.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.125F, KeyframeAnimations.degreeVec(0.0F, -55.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.25F, KeyframeAnimations.degreeVec(0.0F, 35.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.375F, KeyframeAnimations.degreeVec(0.0F, 45.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                          new class_7186(0.5F, class_7187.method_41829(0.0F, 25.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "right_wing_tip",
                    new class_7179(
                          class_7179.class_7183.field_37887,
//                          new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 50.5F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.0417F, KeyframeAnimations.degreeVec(0.0F, 65.5F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.2083F, KeyframeAnimations.degreeVec(0.0F, -135.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                          new class_7186(0.5F, class_7187.method_41829(0.0F, 50.5F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "left_wing",
                    new class_7179(
                          class_7179.class_7183.field_37887,
//                          new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, -25.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.125F, KeyframeAnimations.degreeVec(0.0F, 55.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.25F, KeyframeAnimations.degreeVec(0.0F, -35.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.375F, KeyframeAnimations.degreeVec(0.0F, -45.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                          new class_7186(0.5F, class_7187.method_41829(0.0F, -25.0F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41820(
                    "left_wing_tip",
                    new class_7179(
                          class_7179.class_7183.field_37887,
//                          new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, -50.5F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.0417F, KeyframeAnimations.degreeVec(0.0F, -65.5F, 0.0F), AnimationChannel.Interpolations.LINEAR),
//                          new Keyframe(0.2083F, KeyframeAnimations.degreeVec(0.0F, 135.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                          new class_7186(0.5F, class_7187.method_41829(0.0F, -50.5F, 0.0F), class_7179.class_7181.field_37884)
                    )
              )
              .method_41821();
    }

    public @NotNull class_630 method_32008() {
        return this.root;
    }

    public void setupAnim(CourierBat entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        method_32008().method_32088().forEach(class_630::method_41923);
        method_43782(entity.flyAnimationState, entity.hasMail() ? batFlyingWithBackpack : class_8928.field_47104, ageInTicks, 1.0F);
    }
}
