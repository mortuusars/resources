package io.github.mortuusars.envelope.integration.jei.extensions;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.crafting.SealStampDyeingRecipe;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.builder.IRecipeSlotBuilder;
import mezz.jei.api.gui.ingredient.ICraftingGridHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.category.extensions.vanilla.crafting.ICraftingCategoryExtension;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_8786;
import java.util.List;

public class SealStampDyeingRecipeExtension implements ICraftingCategoryExtension<SealStampDyeingRecipe> {
    @Override
    public void setRecipe(class_8786<SealStampDyeingRecipe> holder, IRecipeLayoutBuilder builder,
                          ICraftingGridHelper craftingGridHelper, IFocusGroup focuses) {



        List<class_1799> stamps = List.of(new class_1799(Envelope.Items.SEAL_STAMP.get()));
        List<class_1799> dyes = Envelope.Items.DYED_SEAL_STAMPS.keySet().stream().map(class_1769::method_7803).map(class_1799::new).toList();
        List<class_1799> results = Envelope.Items.DYED_SEAL_STAMPS.values().stream().map(i -> new class_1799(i.get())).toList();

        List<IRecipeSlotBuilder> inputSlots = craftingGridHelper.createAndSetInputs(builder, List.of(stamps, dyes), 0, 0);
        IRecipeSlotBuilder outputSlot = craftingGridHelper.createAndSetOutputs(builder, results);

        builder.createFocusLink(inputSlots.get(1), outputSlot);
    }
}
