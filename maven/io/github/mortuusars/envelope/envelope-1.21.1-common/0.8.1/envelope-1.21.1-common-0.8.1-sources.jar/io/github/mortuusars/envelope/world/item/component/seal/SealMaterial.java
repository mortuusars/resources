package io.github.mortuusars.envelope.world.item.component.seal;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.mortaar.serialization.Codecs;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_1767;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5381;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class SealMaterial {
    public static final Codec<SealMaterial> DIRECT_CODEC = RecordCodecBuilder.create(i -> i.group(
          class_2960.field_25139.fieldOf("sprite").forGetter(SealMaterial::sprite),
          Codecs.HEX_COLOR.fieldOf("model_tint_color").forGetter(SealMaterial::modelTintColor),
          ShadingPalette.CODEC.fieldOf("impression_palette").forGetter(SealMaterial::impressionPalette),
          Codec.BOOL.optionalFieldOf("has_glint", false).forGetter(SealMaterial::hasGlint)
    ).apply(i, SealMaterial::new));

    public static final class_9139<class_9129, SealMaterial> DIRECT_STREAM_CODEC = class_9139.method_56905(
          class_2960.field_48267, SealMaterial::sprite,
          class_9135.field_49675, SealMaterial::modelTintColor,
          ShadingPalette.STREAM_CODEC, SealMaterial::impressionPalette,
          class_9135.field_48547, SealMaterial::hasGlint,
          SealMaterial::new
    );

    public static final Codec<class_6880<SealMaterial>> CODEC =
          class_5381.method_29749(Envelope.Registries.SEAL_MATERIAL, DIRECT_CODEC);

    public static final class_9139<class_9129, class_6880<SealMaterial>> STREAM_CODEC =
          class_9135.method_56367(Envelope.Registries.SEAL_MATERIAL, DIRECT_STREAM_CODEC);

    public static final Map<class_1767, class_5321<SealMaterial>> WAX_COLORS = new LinkedHashMap<>();
    public static final class_5321<SealMaterial> WAX = class_5321.method_29179(Envelope.Registries.SEAL_MATERIAL, Envelope.resource("wax"));
    public static final class_5321<SealMaterial> WHITE_WAX = dyedWax(class_1767.field_7952);
    public static final class_5321<SealMaterial> LIGHT_GRAY_WAX = dyedWax(class_1767.field_7967);
    public static final class_5321<SealMaterial> GRAY_WAX = dyedWax(class_1767.field_7944);
    public static final class_5321<SealMaterial> BLACK_WAX = dyedWax(class_1767.field_7963);
    public static final class_5321<SealMaterial> BROWN_WAX = dyedWax(class_1767.field_7957);
    public static final class_5321<SealMaterial> RED_WAX = dyedWax(class_1767.field_7964);
    public static final class_5321<SealMaterial> ORANGE_WAX = dyedWax(class_1767.field_7946);
    public static final class_5321<SealMaterial> YELLOW_WAX = dyedWax(class_1767.field_7947);
    public static final class_5321<SealMaterial> LIME_WAX = dyedWax(class_1767.field_7961);
    public static final class_5321<SealMaterial> GREEN_WAX = dyedWax(class_1767.field_7942);
    public static final class_5321<SealMaterial> CYAN_WAX = dyedWax(class_1767.field_7955);
    public static final class_5321<SealMaterial> LIGHT_BLUE_WAX = dyedWax(class_1767.field_7951);
    public static final class_5321<SealMaterial> BLUE_WAX = dyedWax(class_1767.field_7966);
    public static final class_5321<SealMaterial> PURPLE_WAX = dyedWax(class_1767.field_7945);
    public static final class_5321<SealMaterial> MAGENTA_WAX = dyedWax(class_1767.field_7958);
    public static final class_5321<SealMaterial> PINK_WAX = dyedWax(class_1767.field_7954);

    public static final class_5321<SealMaterial> SCULK = class_5321.method_29179(Envelope.Registries.SEAL_MATERIAL, Envelope.resource("sculk"));
    public static final class_5321<SealMaterial> GOLD = class_5321.method_29179(Envelope.Registries.SEAL_MATERIAL, Envelope.resource("gold"));

    private final class_2960 sprite;
    private final int modelTintColor;
    private final ShadingPalette impressionPalette;
    private final boolean hasGlint;

    public SealMaterial(class_2960 sprite, int modelTintColor, ShadingPalette impressionPalette, boolean hasGlint) {
        this.sprite = sprite;
        this.modelTintColor = modelTintColor;
        this.impressionPalette = impressionPalette;
        this.hasGlint = hasGlint;
    }

    public static @Nullable class_5321<SealMaterial> fromDyeColor(class_1767 color) {
        return WAX_COLORS.get(color);
    }

    public static @Nullable class_1767 colorFromMaterial(class_5321<SealMaterial> key) {
        for (Map.Entry<class_1767, class_5321<SealMaterial>> entry : WAX_COLORS.entrySet()) {
            if (entry.getValue().equals(key)) {
                return entry.getKey();
            }
        }
        return null;
    }

    public class_2960 sprite() {
        return sprite;
    }

    public int modelTintColor() {
        return modelTintColor;
    }

    public ShadingPalette impressionPalette() {
        return impressionPalette;
    }

    public boolean hasGlint() {
        return hasGlint;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (SealMaterial) obj;
        return Objects.equals(this.sprite, that.sprite) &&
              this.modelTintColor == that.modelTintColor &&
              Objects.equals(this.impressionPalette, that.impressionPalette);
    }

    @Override
    public int hashCode() {
        int i = 1;
        i = 31 * i + this.sprite.hashCode();
        i = 31 * i + this.modelTintColor;
        return 31 * i + this.impressionPalette.hashCode();
    }

    @Override
    public String toString() {
        return "SealMaterial[" +
              "sprite=" + sprite + ", " +
              "modelTintColor=" + modelTintColor + ", " +
              "impressionPalette=" + impressionPalette + "," +
              "hasGlint=" + hasGlint + ']';
    }

    // --

    private static class_5321<SealMaterial> dyedWax(class_1767 color) {
        class_5321<SealMaterial> key = class_5321.method_29179(Envelope.Registries.SEAL_MATERIAL, Envelope.resource(color.method_15434() + "_wax"));
        WAX_COLORS.put(color, key);
        return key;
    }

    public static class_2960 spriteLocationFromKey(class_5321<SealMaterial> key) {
        return key.method_29177().method_45134(path -> "seal/material/" + path);
    }

    public static void bootstrap(class_7891<SealMaterial> context) {
        register(context, WAX, 0xFFCC4E47, 0xFFA53732, 0xFFE17D68, 0xFF761814, 0xFF902926, false);
        register(context, WHITE_WAX, 0xFFFCFDFF, 0xFFD1D1D7, 0xFFECECEE, 0xFF9F9FAC, 0xFFB8B8BF, false);
        register(context, LIGHT_GRAY_WAX, 0xFFC9C9CD, 0xFF9D9DA5, 0xFFCCCCCF, 0xFF71717D, 0xFF8A8A94, false);
        register(context, GRAY_WAX, 0xFF969595, 0xFF63636F, 0xFF8D8D94, 0xFF3F3F4C, 0xFF52525C, false);
        register(context, BLACK_WAX, 0xFF414053, 0xFF2A293F, 0xFF58566E, 0xFF09081D, 0xFF161526, false);
        register(context, BROWN_WAX, 0xFFA76641, 0xFF834623, 0xFFCC865C, 0xFF5D2A09, 0xFF6E3816, false);
        register(context, RED_WAX, 0xFFEB5A4C, 0xFFBB3B36, 0xFFF56F5D, 0xFF891312, 0xFFA62C29, false);
        register(context, ORANGE_WAX, 0xFFF39B19, 0xFFCA712C, 0xFFF7A94F, 0xFF9D460C, 0xFFB55C1D, false);
        register(context, YELLOW_WAX, 0xFFECD527, 0xFFD3AF2A, 0xFFF4DF4F, 0xFFA3770C, 0xFFC2951B, false);
        register(context, LIME_WAX, 0xFF8FD13C, 0xFF8AC03C, 0xFFB8ED63, 0xFF578812, 0xFF71A626, false);
        register(context, GREEN_WAX, 0xFF668A16, 0xFF66881C, 0xFF97BA38, 0xFF3F5812, 0xFF527016, false);
        register(context, CYAN_WAX, 0xFF4AA7B0, 0xFF3A8992, 0xFF6ABCC0, 0xFF16616A, 0xFF28747D, false);
        register(context, LIGHT_BLUE_WAX, 0xFF93BFFF, 0xFF6E9FC8, 0xFF9DCDEA, 0xFF376993, 0xFF5386B5, false);
        register(context, BLUE_WAX, 0xFF537EE8, 0xFF3A4D8F, 0xFF6A80C6, 0xFF182C65, 0xFF2A3D78, false);
        register(context, PURPLE_WAX, 0xFFA755DA, 0xFF6C3697, 0xFF9D69CF, 0xFF3D1468, 0xFF53257D, false);
        register(context, MAGENTA_WAX, 0xFFCA6DC4, 0xFF973291, 0xFFCF66CD, 0xFF681369, 0xFF7D247B, false);
        register(context, PINK_WAX, 0xFFF283B9, 0xFFD4548E, 0xFFFA94CD, 0xFFA11D5D, 0xFFBA3C75, false);
        register(context, SCULK, 0xFF256067, 0xFF06313A, 0xFF2E7F80, 0xFF0D1217, 0xFF131D24, false);
        register(context, GOLD, 0xFFFFB347, 0xFFE39C38, 0xFFFFE685, 0xFFA15611, 0xFFBF7B22, true);
    }

    public static void register(class_7891<SealMaterial> context, class_5321<SealMaterial> key, int modelTintColor,
                                 int paletteBaseColor, int paletteHighlightColor, int paletteShadowColor, int paletteSideColor, boolean hasGlint) {
        context.method_46838(key, new SealMaterial(
              spriteLocationFromKey(key),
              modelTintColor,
              new ShadingPalette(paletteBaseColor, paletteHighlightColor, paletteShadowColor, paletteSideColor), hasGlint));
    }
}
