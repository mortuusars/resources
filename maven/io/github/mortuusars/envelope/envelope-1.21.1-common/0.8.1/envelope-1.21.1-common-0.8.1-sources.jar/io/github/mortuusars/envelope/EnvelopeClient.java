package io.github.mortuusars.envelope;

import io.github.mortuusars.envelope.client.gui.tooltip.*;
import io.github.mortuusars.envelope.client.renderer.SealRenderer;
import io.github.mortuusars.envelope.util.bugger.EnvelopeBuggerPage;
import io.github.mortuusars.envelope.util.bugger.PigeonEntityDataDisplay;
import io.github.mortuusars.envelope.world.inventory.tooltip.SealDieTooltip;
import io.github.mortuusars.envelope.world.item.component.*;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import io.github.mortuusars.envelope.world.item.tooltip.MailAddressTagTooltip;
import io.github.mortuusars.mortaar.bugger.screen.BuggerEntityOverhead;
import io.github.mortuusars.mortaar.bugger.screen.BuggerScreen;
import io.github.mortuusars.mortaar.client.gui.tooltip.Tooltips;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;

public class EnvelopeClient {
    private static final SealRenderer sealRenderer = new SealRenderer();

    public static void init() {
        ItemModelOverrides.register();

        Tooltips.register(MailAddressTagTooltip.class, mailAddress -> new MailAddressTagTooltipComponent(mailAddress.address()));
        Tooltips.register(PackageContents.class, PackageTooltipComponent::new);
        Tooltips.register(PaybackRequest.class, PaybackRequestTooltipComponent::new);
        Tooltips.register(Seal.class, SealTooltipComponent::new);
        Tooltips.register(SealDieTooltip.class, sealDie -> new SealDieTooltipComponent(sealDie.die()));

        BuggerScreen.addPage(new EnvelopeBuggerPage());
        BuggerEntityOverhead.addData(new PigeonEntityDataDisplay());
    }

    public static SealRenderer getSealRenderer() {
        return sealRenderer;
    }

    // --

    public static class ItemModelOverrides {
        public static final class_2960 OPEN = Envelope.resource("open");
        public static final class_2960 HAS_CONTENT = Envelope.resource("has_content");

        public static final class_2960 PAYBACK_TAG_DURATION = Envelope.resource("payback_tag_duration");

        public static void register() {
            class_5272.method_27879(Envelope.Items.LETTER_AND_QUILL.get(), HAS_CONTENT, ItemModelOverrides::hasLetterContent);

            class_5272.method_27879(Envelope.Items.LETTER.get(), OPEN, ItemModelOverrides::isOpen);
            class_5272.method_27879(Envelope.Items.LETTER.get(), HAS_CONTENT, ItemModelOverrides::hasLetterContent);
            class_5272.method_27879(Envelope.Items.TATTERED_LETTER.get(), OPEN, ItemModelOverrides::isOpen);
            class_5272.method_27879(Envelope.Items.TATTERED_LETTER.get(), HAS_CONTENT, ItemModelOverrides::hasLetterContent);
            class_5272.method_27879(Envelope.Items.SERVICE_LETTER.get(), OPEN, ItemModelOverrides::isOpen);
            class_5272.method_27879(Envelope.Items.SERVICE_LETTER.get(), HAS_CONTENT, ItemModelOverrides::hasLetterContent);

            class_5272.method_27879(Envelope.Items.PAPER_BOX.get(), OPEN, ItemModelOverrides::isOpen);
            class_5272.method_27879(Envelope.Items.PACKAGE.get(), OPEN, ItemModelOverrides::isOpen);
            class_5272.method_27879(Envelope.Items.PAYBACK_BOX.get(), OPEN, ItemModelOverrides::isOpen);
            class_5272.method_27879(Envelope.Items.PAYBACK_PACKAGE.get(), OPEN, ItemModelOverrides::isOpen);

            class_5272.method_27879(Envelope.Items.PAYBACK_TAG.get(), PAYBACK_TAG_DURATION, ItemModelOverrides::getPaybackDuration);
        }

        public static float isOpen(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed) {
            return stack.method_57826(Envelope.DataComponents.OPEN) ? 1 : 0;
        }

        public static float hasLetterContent(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed) {
            if (!stack.method_57825(Envelope.DataComponents.LETTER_AND_QUILL_CONTENT, LetterAndQuillContent.EMPTY).isEmpty()) {
                return 1;
            }
            if (!stack.method_57825(Envelope.DataComponents.LETTER_CONTENT, LetterContent.EMPTY).isEmpty()) {
                return 1;
            }
            return 0;
        }

        public static float getPaybackDuration(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed) {
            PaybackDuration duration = stack.method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS) instanceof PaybackRequest request
                  ? request.duration()
                  : PaybackDuration.MEDIUM;
            return duration.ordinal() / 10f; // 0.0, 0.1, 0.2, etc.
        }
    }
}
