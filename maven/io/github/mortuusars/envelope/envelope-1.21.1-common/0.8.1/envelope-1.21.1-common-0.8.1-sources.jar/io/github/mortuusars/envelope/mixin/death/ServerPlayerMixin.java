package io.github.mortuusars.envelope.mixin.death;

import com.mojang.authlib.GameProfile;
import io.github.mortuusars.envelope.world.item.component.SealLock;
import net.minecraft.class_1282;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3222.class)
public abstract class ServerPlayerMixin extends class_1657 {
    public ServerPlayerMixin(class_1937 level, class_2338 pos, float yRot, GameProfile gameProfile) {
        super(level, pos, yRot, gameProfile);
    }

    @Shadow
    public abstract class_3218 serverLevel();

    @Inject(method = "die", at = @At("RETURN"))
    private void onDie(class_1282 damageSource, CallbackInfo ci) {
        SealLock.unlockAllFrom(method_5820(), serverLevel());
    }
}
