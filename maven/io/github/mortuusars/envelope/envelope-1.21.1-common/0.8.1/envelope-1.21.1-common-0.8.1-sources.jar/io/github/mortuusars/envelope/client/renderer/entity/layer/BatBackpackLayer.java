package io.github.mortuusars.envelope.client.renderer.entity.layer;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.model.BatBackpackModel;
import io.github.mortuusars.envelope.client.model.CourierBatModel;
import io.github.mortuusars.envelope.world.entity.CourierBat;
import net.minecraft.class_1921;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5601;
import net.minecraft.class_630;

public class BatBackpackLayer extends class_3887<CourierBat, CourierBatModel> {
    public static final class_5601 MODEL_LAYER = new class_5601(Envelope.resource("bat_backpack"), "main");

    protected final BatBackpackModel model;

    public BatBackpackLayer(class_3883<CourierBat, CourierBatModel> renderer, class_630 root) {
        super(renderer);
        model = new BatBackpackModel(root);
    }

    @Override
    public void render(class_4587 poseStack, class_4597 buffer, int packedLight, CourierBat bat, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!bat.hasMail()) {
            return;
        }

        poseStack.method_22903();

        CourierBatModel batModel = method_17165();
        class_630 body = batModel.method_32008().method_32086("body");
        body.method_22703(poseStack);
//        ModelPart feet = body.getChild("feet");
//        feet.translateAndRotate(poseStack);

        class_4588 vertexConsumer = buffer.getBuffer(class_1921.method_23578(BatBackpackModel.TEXTURE));
        model.method_2828(poseStack, vertexConsumer, packedLight, class_4608.field_21444, 0xFFFFFFFF);

        poseStack.method_22909();
    }
}