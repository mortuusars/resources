package io.github.mortuusars.envelope.world.entity.ai.goal.courier;

import io.github.mortuusars.envelope.world.entity.ai.CourierNavigation;
import io.github.mortuusars.envelope.world.entity.ai.PigeonNavigation;
import io.github.mortuusars.envelope.world.mail.delivery.PhysicalCourier;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import net.minecraft.class_1314;
import net.minecraft.class_1352;
import net.minecraft.class_1408;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_5530;

public class DeliverMailGoal extends class_1352 {
    protected final PhysicalCourier courier;

    public DeliverMailGoal(PhysicalCourier courier) {
        this.courier = courier;
        method_6265(EnumSet.of(class_4134.field_18405));
    }

    public PhysicalCourier getCourier() {
        return courier;
    }

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public boolean method_6264() {
        return courier.isDelivering();
    }

    @Override
    public void method_6270() {
        courier.setDelivery(null);
        class_1408 navigation = courier.asEntity().method_5942();
        navigation.method_6340();
        navigation.method_23965();
    }

    @Override
    public void method_6268() {
        if (!(courier.asEntity().method_37908() instanceof class_3218 level)) {
            return;
        }

        courier.getCurrentDelivery().ifPresent(delivery -> {
            courier.tickDelivery(level, delivery);

            delivery.getRoute().getSegment(delivery.getPhase()).endPos()
                  .ifPresentOrElse(localPos -> {
                      class_2338 targetLocal = delivery.getPhase().isDescending()
                            ? PigeonNavigation.getMailboxApproachTarget(level, localPos)
                            : localPos;

                      if ((delivery.getPhase().isAscending() || delivery.getPhase().isDescending())
                            && courier.hasReachedTarget(targetLocal)) {
                          // Complete the phase instantly
                          delivery.setPhaseProgress(courier.getPhaseDuration(level, delivery, delivery.getPhase()));
                          return;
                      }

                      if (!courier.hasReachedTarget(targetLocal)) {
                          class_2338 navigationPos = CourierNavigation.getNavigationPos(courier, targetLocal);
                          if (!courier.asEntity().method_5942().method_23966()
                                || !navigationPos.equals(courier.asEntity().method_5942().method_6355())) {
                              courier.pathfindDirectlyTowards(targetLocal);
                          }
                      }
                  }, () -> {
                      class_1314 entity = courier.asEntity();
                      @Nullable class_243 randomPos = class_5530.method_31504(entity, 8, 4, -2,
                            entity.method_23317(), entity.method_23321(), (float) (Math.PI / 2));
                      if (randomPos != null && level.method_8409().method_43057() < 0.1f) {
                          courier.pathfindDirectlyTowards(class_2338.method_49638(randomPos));
                      }
                  });
        });
    }
}