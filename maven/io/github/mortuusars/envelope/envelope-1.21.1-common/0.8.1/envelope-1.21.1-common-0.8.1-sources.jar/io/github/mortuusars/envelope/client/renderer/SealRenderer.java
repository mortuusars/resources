package io.github.mortuusars.envelope.client.renderer;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.seal.*;
import io.github.mortuusars.mortaar.client.Minecrft;
import io.github.mortuusars.mortaar.util.color.TintColor;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public class SealRenderer {
    public static final class_2960 IRON_DIE_SPRITE = Envelope.resource("seal/die/iron");
    public static final class_2960 SEAL_GLINT_SPRITE = Envelope.resource("seal/glint");
    public static final class_2960 LOCK_SPRITE = Envelope.resource("seal/lock");
    public static final class_2960 LOCKED_OVERLAY_SPRITE = Envelope.resource("seal/locked_overlay");

    public void render(Seal seal, class_332 guiGraphics, int x, int y) {
        SealMaterial material = seal.material().comp_349();
        ShadingPalette colors = material.impressionPalette();

        class_2960 materialTexture = material.sprite();
        class_2960 impressionTexture = seal.impression().comp_349().sprite();

        // Background
        guiGraphics.method_52706(materialTexture, x, y, 32, 32);

        // Side
        setShaderTintColor(colors.side());
        guiGraphics.method_52706(impressionTexture, x + 1, y + 2, 32, 32);
        guiGraphics.method_52706(impressionTexture, x, y + 2, 32, 32);
        guiGraphics.method_52706(impressionTexture, x - 1, y + 2, 32, 32);
        guiGraphics.method_52706(impressionTexture, x + 1, y + 1, 32, 32);
        guiGraphics.method_52706(impressionTexture, x, y + 1, 32, 32);
        guiGraphics.method_52706(impressionTexture, x - 1, y + 1, 32, 32);
        guiGraphics.method_52706(impressionTexture, x + 1, y, 32, 32);
        guiGraphics.method_52706(impressionTexture, x, y, 32, 32);
        guiGraphics.method_52706(impressionTexture, x - 1, y, 32, 32);
        guiGraphics.method_52706(impressionTexture, x + 1, y - 1, 32, 32);
        guiGraphics.method_52706(impressionTexture, x, y - 1, 32, 32);
        guiGraphics.method_52706(impressionTexture, x - 1, y - 1, 32, 32);
        guiGraphics.method_52706(impressionTexture, x, y - 2, 32, 32);

        // Shadow
        setShaderTintColor(colors.shadow());
        guiGraphics.method_52706(impressionTexture, x, y + 1, 32, 32);

        // Highlight
        setShaderTintColor(colors.highlight());
        guiGraphics.method_52706(impressionTexture, x, y - 1, 32, 32);

        // Base
        setShaderTintColor(colors.base());
        guiGraphics.method_52706(impressionTexture, x, y, 32, 32);

        RenderSystem.setShaderColor(1, 1, 1, 1);

        if (material.hasGlint()) {
            RenderSystem.enableBlend();
            guiGraphics.method_52708(SEAL_GLINT_SPRITE, 32, 32, 0, 0, x + 1, y + 1, 32, 32);
            RenderSystem.disableBlend();
        }

        seal.lock().ifPresent(lock -> {
            if (lock.isLocked(Minecrft.level())) {
                // Heartbeat pulsing effect:
                double time = (Minecrft.level().method_8510() + Minecrft.get().method_60646().method_60637(true)) / 20.0;
                double beat = Math.pow((Math.sin(time * Math.PI * 2 * 1) + 1.0) * 0.5, 10);
                float brightness = (float) class_3532.method_16436(beat, 1.0, 1.4);
                RenderSystem.setShaderColor(brightness, brightness, brightness, 1.0f);

                RenderSystem.enableBlend();
                guiGraphics.method_52708(LOCKED_OVERLAY_SPRITE, 34, 34,
                      0, 0, x - 1, y - 1, 34, 34);
                RenderSystem.disableBlend();

                guiGraphics.method_52708(LOCK_SPRITE, 34, 34,
                      0, 0, x - 1, y - 1, 34, 34);
                RenderSystem.setShaderColor(1, 1, 1, 1);
            }
        });
    }

    public void renderDie(SealSymbol impression, ShadingPalette colors, class_332 guiGraphics, int x, int y) {
        // Background
        guiGraphics.method_52706(IRON_DIE_SPRITE, x, y, 30, 30);

        class_2960 impressionSprite = impression.sprite();

        // flipping the sprite on the X axis is a bit tricky, hopefully it'll not break

        y--;

        // Side
        setShaderTintColor(colors.side());
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x + 1, y + 1, 30, 30);
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x, y + 1, 30, 30);
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x - 1, y + 1, 30, 30);
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x + 1, y, 30, 30);
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x, y, 30, 30);
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x - 1, y, 30, 30);
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x + 1, y - 1, 30, 30);
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x, y - 1, 30, 30);
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x - 1, y - 1, 30, 30);
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x + 1, y - 2, 30, 30);
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x, y - 2, 30, 30);
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x - 1, y - 2, 30, 30);

        // Highlight
        setShaderTintColor(colors.highlight());
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x, y + 1, 30, 30);

        // Shadow
        setShaderTintColor(colors.shadow());
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x, y - 1, 30, 30);

        // Base
        setShaderTintColor(colors.base());
        guiGraphics.method_52708(impressionSprite, -30, 30, -30, 0, x, y, 30, 30);

        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    public static void setShaderTintColor(TintColor color) {
        RenderSystem.setShaderColor(color.r(), color.g(), color.b(), color.a());
    }

    // Have you seen someone rendering textures this way? Now you have.
    // Patent Pending ™
}
