package io.github.mortuusars.envelope.client.model;

import com.google.common.collect.ImmutableList;
import io.github.mortuusars.envelope.world.entity.PigeonVariant;
import io.github.mortuusars.mortaar.client.Minecrft;
import io.github.mortuusars.mortaar.util.Easing;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4592;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.class_765;
import net.minecraft.class_8144;
import net.minecraft.client.model.geom.builders.*;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PigeonModel extends class_4592<Pigeon> {
    private final class_630 root;

    private final class_630 head;
    private final class_630 beak;
    private final class_630 hat;

    private final class_630 body;
    private final class_630 backpackStraps;
    private final class_630 backpackBag;

    private final class_630 leftLeg;
    private final class_630 rightLeg;
    private final class_630 tail;
    private final class_630 leftWing;
    private final class_630 rightWing;

    private boolean ghost;
    private class_2960 texture;

    public PigeonModel(class_630 root) {
        // bodyYOffset = 24 * (babyBodyScale - 1)
        // babyYHeadOffset = I have not been able to crack the code. so have a magic number instead.
        super(true, 10F, 0, 2F, 2F, 24F);
        this.root = root;

        head = root.method_32086("head");
        beak = head.method_32086("beak");
        hat = head.method_32086("hat");

        body = root.method_32086("body");
        backpackStraps = body.method_32086("backpack_straps");
        backpackBag = body.method_32086("backpack_bag");

        leftLeg = root.method_32086("left_leg");
        rightLeg = root.method_32086("right_leg");
        tail = root.method_32086("tail");
        leftWing = root.method_32086("left_wing");
        rightWing = root.method_32086("right_wing");
    }

    public static class_5607 createLayerDefinition() {
        class_5609 mesh = new class_5609();
        class_5610 part = mesh.method_32111();

        class_5610 head = part.method_32117("head",
              class_5606.method_32108()
                    .method_32101(0, 14)
                    .method_32098(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F, class_5605.field_27715),
              class_5603.method_32090(0.0F, 18f, -3.0F));

        class_5610 beak = head.method_32117("beak",
              class_5606.method_32108()
                    .method_32101(0, 14)
                    .method_32098(-1.0F, -1.0F, -1.0F, 2.0F, 2.0F, 1.0F, new class_5605(0.01F))
                    .method_32101(0, 16)
                    .method_32098(0.0F, 0.0F, -2.0F, 0.0F, 1.0F, 1.0F, class_5605.field_27715),
              class_5603.method_32090(0.0F, -3.0F, -3.0F));

        class_5610 hat = head.method_32117("hat",
              class_5606.method_32108()
                    .method_32101(1, 46)
                    .method_32098(-3.5F, -2.0F, -3.5F, 7.0F, 2.0F, 7.0F, class_5605.field_27715)
                    .method_32101(0, 55)
                    .method_32098(-3.5F, 0.0F, -4.5F, 7.0F, 1.0F, 8.0F, class_5605.field_27715),
              class_5603.method_32091(0.0F, -5.75F, 0.0F, -0.1745F, 0.0F, 0.0F));

        class_5610 body = part.method_32117("body",
              class_5606.method_32108()
                    .method_32101(0, 0)
                    .method_32098(-4.0F, -8.0F, -4.0F, 8.0F, 6.0F, 8.0F, class_5605.field_27715),
              class_5603.method_32090(0.0F, 24.05F, 0.0F));

        class_5610 backpackStraps = body.method_32117("backpack_straps",
              class_5606.method_32108()
                    .method_32101(32, 50)
                    .method_32098(-4.0F, -3.0F, -4.0F, 8.0F, 6.0F, 8.0F, new class_5605(0, 0.01F, 0.01F)),
              class_5603.method_32090(0.0F, -5.0F, 0.0F));

        class_5610 backpackBag = body.method_32117("backpack_bag",
              class_5606.method_32108()
                    .method_32101(32, 38)
                    .method_32098(-5.0F, -3.0F, -3.0F, 10.0F, 6.0F, 6.0F, class_5605.field_27715),
              class_5603.method_32091(0.0F, -9.0F, 2.0F, 0.7854F, 0.0F, 0.0F));


        class_5610 leftLeg = part.method_32117("left_leg", class_5606.method_32108()
                    .method_32101(9, 26)
                    .method_32098(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 0.0F, class_5605.field_27715)
                    .method_32101(6, 28)
                    .method_32098(-1.0F, 2.0F, -3.0F, 3.0F, 0.0F, 3.0F, class_5605.field_27715),
              class_5603.method_32090(1.0F, 22.0F, 1.0F));

        class_5610 rightLeg = part.method_32117("right_leg", class_5606.method_32108()
                    .method_32101(7, 26)
                    .method_32098(-1.0F, 0.0F, 0.0F, 1.0F, 2.0F, 0.0F, class_5605.field_27715)
                    .method_32101(0, 28)
                    .method_32098(-2.0F, 2.0F, -3.0F, 3.0F, 0.0F, 3.0F, class_5605.field_27715),
              class_5603.method_32090(-1.0F, 22.0F, 1.0F));

        class_5610 tail = part.method_32117("tail",
              class_5606.method_32108()
                    .method_32101(24, 0)
                    .method_32098(-3.0F, 0.0F, -1.0F, 6.0F, 5.0F, 1.0F, class_5605.field_27715),
              class_5603.method_32091(0.0F, 19.0F, 4.0F, 0.7854F, 0.0F, 0.0F));

        class_5610 leftWing = part.method_32117("left_wing",
              class_5606.method_32108()
                    .method_32101(46, 3).method_32096()
                    .method_32098(-1.0F, 0.0F, -3.0F, 1.0F, 4.0F, 6.0F, class_5605.field_27715).method_32106(false),
              class_5603.method_32091(4.0F, 17.0F, 0.0F, 0.0F, 0.0F, -0.3927F));

        class_5610 rightWing = part.method_32117("right_wing",
              class_5606.method_32108()
                    .method_32101(32, 3)
                    .method_32098(0.0F, 0.0F, -3.0F, 1.0F, 4.0F, 6.0F, class_5605.field_27715),
              class_5603.method_32091(-4.0F, 17.0F, 0.0F, 0.0F, 0.0F, 0.3927F));

        return class_5607.method_32110(mesh, 64, 64);
    }

    public void setupAnim(Pigeon pigeon, float limbSwing, float limbSwingAmount, float bob, float netHeadYaw, float headPitch) {
        root.method_32088().forEach(class_630::method_41923);
        ghost = pigeon.method_47827().method_40225(PigeonVariant.GHOST);
        texture = pigeon.method_47827().comp_349().texture();

        head.field_3654 = headPitch * (float) (Math.PI / 180.0);
        head.field_3675 = netHeadYaw * (float) (Math.PI / 180.0);

        float partialTick = Minecrft.get().method_60646().method_60637(true);

        switch (getState(pigeon)) {
            case FLYING -> {
                leftWing.field_3674 = -(bob + 0.3f);
                rightWing.field_3674 = bob + 0.3f;

                leftLeg.field_3654 = 0.75f * limbSwingAmount;
                leftLeg.field_3675 = -0.15f;
                rightLeg.field_3654 = 0.75f * limbSwingAmount;
                rightLeg.field_3675 = 0.15f;

                // Rock back and forth
                float anim = ((pigeon.field_6012 + partialTick) % 60) / 60;
                anim *= 2;
                if (anim > 1) {
                    anim = 2 - anim;
                }
                anim = ((float) Easing.IN_OUT_QUAD.ease(anim));
                body.field_3654 = anim * 0.05f;
                head.field_3654 += -anim * 0.025f;
                head.field_3655 -= 0.5F * (anim);

                leftWing.field_3654 += (anim * 0.1f);
                leftWing.field_3656 -= 0.3F * (anim);
                leftWing.field_3655 -= 0.5F * (anim);

                rightWing.field_3654 += (anim * 0.1f);
                rightWing.field_3656 -= 0.3F * (anim);
                rightWing.field_3655 -= 0.5F * (anim);

                tail.field_3654 += (limbSwingAmount * 0.5F) + (anim * 0.1f);
                tail.field_3656 -= 0.3F * (anim);
                tail.field_3655 -= 0.4F * (anim);
            }
            case STANDING -> {
                leftWing.field_3674 = -0.3927F;
                rightWing.field_3674 = 0.3927F;
                leftLeg.field_3654 = class_3532.method_15362(limbSwing * 0.6662F + (float) Math.PI) * 1.4F * limbSwingAmount;
                rightLeg.field_3654 = class_3532.method_15362(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
            }
            case SITTING -> {
                body.field_3656 += 1.9F;
                head.field_3656 += pigeon.method_6109() ? 1.9F : 2.9F;

                leftWing.field_3674 = -0.2F;
                rightWing.field_3674 = 0.2F;
                leftWing.field_3656 += 2;
                rightWing.field_3656 += 2;

                tail.field_3654 = 0.75f;
            }
        }

        int eatingTicks = pigeon.getEatingTicks();
        if (eatingTicks > 0) {
            float anim = class_3532.method_15363((eatingTicks + partialTick) / 10f, 0.0f, 1.0f);
            anim *= 2;
            if (anim > 1) {
                anim = 2 - anim;
            }

            head.field_3654 += anim;
        }

        String customName = class_8144.method_49078(pigeon.method_5797(), class_2561::getString, "");
        if (customName.equalsIgnoreCase("drumstick") || customName.equalsIgnoreCase("matisslee")) {
            body.field_3656 += 0.5f;
            body.field_3655 -= 0.5f;
            head.field_3656 += 0.5f;
            head.field_3655 -= 0.75f;
            head.field_37938 = 1.1f;
            body.field_37938 = 1.15f;
            body.field_37939 = 1.1f;
            body.field_37940 = 1.15f;
            beak.field_37938 = 1.2f;
            beak.field_37940 = 0.75f;
        }
    }

    @Override
    public void method_2828(class_4587 poseStack, class_4588 buffer, int packedLight, int packedOverlay, int color) {
        if (ghost && color == 0xFFFFFFFF) {
            // This is probably stupid, but looks pretty good

            // Low opacity regular render to block water and clouds (entityTranslucentEmissive does not sort transparency well)
            color = 0x22FFFFFF;
            super.method_2828(poseStack, buffer, class_765.field_32767, packedOverlay, color);

            class_4588 emissiveBuffer = Minecrft.get().method_22940().method_23000().getBuffer(
                  class_1921.method_42600(texture));
            color = 0x7F93FF93;
            super.method_2828(poseStack, emissiveBuffer, class_765.field_32767, packedOverlay, color);
        } else {
            super.method_2828(poseStack, buffer, packedLight, packedOverlay, color);
        }
    }

    public PigeonModel.State getState(@Nullable Pigeon pigeon) {
        if (pigeon == null) return State.STANDING;
        if (pigeon.isSitting()) return State.SITTING;
        return pigeon.method_6581() ? State.FLYING : State.STANDING;
    }

    @Override
    protected @NotNull Iterable<class_630> method_22946() {
        return ImmutableList.of(head);
    }

    @Override
    protected @NotNull Iterable<class_630> method_22948() {
        return ImmutableList.of(body, rightLeg, leftLeg, rightWing, leftWing, tail);
    }

    public enum State {
        FLYING,
        STANDING,
        SITTING
    }
}
