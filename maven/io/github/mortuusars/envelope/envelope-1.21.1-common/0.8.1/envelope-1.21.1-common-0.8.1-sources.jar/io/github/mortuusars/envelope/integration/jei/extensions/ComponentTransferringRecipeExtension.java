package io.github.mortuusars.envelope.integration.jei.extensions;

import io.github.mortuusars.envelope.world.item.crafting.ComponentTransferringRecipe;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.ingredient.ICraftingGridHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.category.extensions.vanilla.crafting.ICraftingCategoryExtension;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_8786;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ComponentTransferringRecipeExtension implements ICraftingCategoryExtension<ComponentTransferringRecipe> {
    @Override
    public void setRecipe(class_8786<ComponentTransferringRecipe> holder, IRecipeLayoutBuilder builder,
                          ICraftingGridHelper craftingGridHelper, IFocusGroup focuses) {
        ComponentTransferringRecipe recipe = holder.comp_1933();

        List<List<class_1799>> inputs = new ArrayList<>();

        inputs.add(Arrays.stream(recipe.getSourceIngredient().method_8105()).toList());
        for (class_1856 ingredient : recipe.method_8117()) {
            inputs.add(Arrays.stream(ingredient.method_8105()).toList());
        }

        craftingGridHelper.createAndSetInputs(builder, VanillaTypes.ITEM_STACK, inputs, 0, 0);
        craftingGridHelper.createAndSetOutputs(builder, VanillaTypes.ITEM_STACK, List.of(recipe.getResult()));
    }
}
