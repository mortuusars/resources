package io.github.mortuusars.envelope.mixin.fox_tatter;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.world.item.LetterItem;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_4019;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_4019.class)
public abstract class FoxMixin extends class_1429 {
    protected FoxMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyVariable(method = "spitOutItem", at = @At("HEAD"), argsOnly = true)
    private class_1799 onSpitOutItem(class_1799 stack) {
        if (Config.Server.FOX_LETTER_TATTERING.get()) {
            return LetterItem.tatterIfApplicable(method_37908(), stack);
        }
        return stack;
    }
}
