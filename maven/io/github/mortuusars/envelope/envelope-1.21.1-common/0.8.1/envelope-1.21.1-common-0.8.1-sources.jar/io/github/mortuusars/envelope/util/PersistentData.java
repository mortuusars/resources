package io.github.mortuusars.envelope.util;

import com.mojang.serialization.Codec;
import java.util.function.Supplier;
import net.minecraft.class_2960;

public abstract class PersistentData {
    protected boolean dirty;

    public void setDirty() {
        setDirty(true);
    }

    public void setDirty(boolean dirty) {
        this.dirty = dirty;
    }

    public boolean isDirty() {
        return this.dirty;
    }

    public record Type<T extends PersistentData>(class_2960 id, Supplier<T> constructor, Codec<T> codec) {}
}
