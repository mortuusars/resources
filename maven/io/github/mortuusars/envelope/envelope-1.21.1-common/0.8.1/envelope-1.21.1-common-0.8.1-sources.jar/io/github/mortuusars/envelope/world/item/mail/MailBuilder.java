package io.github.mortuusars.envelope.world.item.mail;

import com.google.common.base.Preconditions;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.SealedItem;
import io.github.mortuusars.envelope.world.item.component.LetterContent;
import io.github.mortuusars.envelope.world.item.component.ServiceLetterMeaning;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryLog;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import io.github.mortuusars.envelope.world.mail.address.Address;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_9322;
import net.minecraft.class_9323;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

public class MailBuilder<T extends MailBuilder<T>> implements class_9322 {
    private final @NotNull class_1799 item;

    public MailBuilder(@NotNull class_1799 item) {
        Preconditions.checkNotNull(item);
        this.item = item;
    }

    public MailBuilder(@NotNull class_1792 item) {
        Preconditions.checkNotNull(item);
        this.item = new class_1799(item);
    }

    @SuppressWarnings("unchecked")
    T self() {
        return (T) this;
    }

    public T sender(Address sender) {
        Mail.setSender(item, sender);
        return self();
    }

    public T recipient(Address recipient) {
        Mail.setRecipient(item, recipient);
        return self();
    }

    public T setLog(DeliveryLog log) {
        Mail.setLog(item, log);
        return self();
    }

    public T writeToLog(DeliveryRecord record) {
        Mail.writeToLog(item, record);
        return self();
    }

    public T apply(Consumer<MailBuilder<?>> consumer) {
        consumer.accept(this);
        return self();
    }

    // --

    @Override
    public @NotNull class_9323 method_57353() {
        return item.method_57353();
    }

    public <V> T set(class_9331<V> type, @Nullable V value) {
        item.method_57379(type, value);
        return self();
    }

    public <V> T update(class_9331<V> type, V defaultValue, @NotNull UnaryOperator<V> updater) {
        item.method_57368(type, defaultValue, updater);
        return self();
    }

    // Base

    public T name(class_2561 component) {
        set(class_9334.field_50239, component);
        return self();
    }

    public T addressTag(Address address) {
        set(Envelope.DataComponents.MAIL_ADDRESS_TAG, address);
        return self();
    }

    // Letter

    public T letterContent(LetterContent content) {
        set(Envelope.DataComponents.LETTER_CONTENT, content);
        return self();
    }

    public T letterContent(class_2561 component) {
        return letterContent(new LetterContent(component));
    }

    public T serviceLetterMeaning(ServiceLetterMeaning meaning) {
        set(Envelope.DataComponents.SERVICE_LETTER_MEANING, meaning);
        return self();
    }

    // Sealable

    public T seal(Seal seal) {
        Preconditions.checkState(item.method_7909() instanceof SealedItem, "Seal is only applicable to SealedItem's");
        set(Envelope.DataComponents.SEAL, seal);
        return self();
    }

    // --

    public @NotNull class_1799 itemStack() {
        return item;
    }
}