package io.github.mortuusars.envelope.mixin.shears_clearing;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.mortaar.world.item.ApplicatorItem;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1820;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1820.class)
public class ShearsItemMixin implements ApplicatorItem {
    @Override
    public boolean shouldRenderSlotTooltipWhileCarrying(class_1657 player, class_1703 menu, class_1735 slot, class_1799 carried) {
        //TODO: Should probably check if we have something to remove from the mail
        return slot.method_7677().method_31573(Envelope.Tags.Items.MAILABLE);
    }
}
