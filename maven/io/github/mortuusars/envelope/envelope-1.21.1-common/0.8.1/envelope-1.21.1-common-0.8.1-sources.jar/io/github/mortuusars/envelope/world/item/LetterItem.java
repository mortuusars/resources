package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.packet.clientbound.ClientboundOpenLetterViewScreenPacket;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3902;
import org.jetbrains.annotations.NotNull;

public class LetterItem extends class_1747 implements SealableItem {
    public LetterItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        if (Config.Server.LETTER_BURNING.get() && context.method_8036() != null
              && context.method_8045().method_8320(context.method_8037()).method_26164(Envelope.Tags.Blocks.BURNING)) {
            context.method_8036().method_5998(context.method_20287()).method_7934(1);
            context.method_8045().method_8396(context.method_8036(), context.method_8037(),
                  Envelope.SoundEvents.IGNITE.get(), class_3419.field_15248, 0.5f, 0.9f + context.method_8045().method_8409().method_43057() * 0.3f);
            context.method_8045().method_8396(context.method_8036(), context.method_8037(),
                  class_3417.field_14993, class_3419.field_15248, 1f, 1f);
            class_243 p = context.method_17698();

            if (context.method_8045() instanceof class_3218 serverLevel) {
                serverLevel.method_14199(class_2398.field_11239, p.field_1352, p.field_1351, p.field_1350, 3, 0.1, 0.1, 0.1, 0);
                serverLevel.method_14199(class_2398.field_11240, p.field_1352, p.field_1351, p.field_1350, 5, 0.2, 0.2, 0.2, 0.02);
            }

            return class_1269.field_5812;
        }

        if (!context.method_8046()) {
            return class_1269.field_5811;
        }

        return super.method_7884(context);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        class_1799 stack = player.method_5998(usedHand);

        if (player instanceof class_3222 serverPlayer) {
            stack.method_57379(Envelope.DataComponents.OPEN, class_3902.field_17274);
            new ClientboundOpenLetterViewScreenPacket(usedHand).sendToClient(serverPlayer);
        }

        level.method_43129(player, player, Envelope.SoundEvents.PAPER_CRACKLE.get(), class_3419.field_15248, 1, 1);
        return class_1271.method_29237(stack, level.field_9236);
    }

    @Override
    public class_1799 seal(class_1937 level, class_1799 stack, Seal seal) {
        class_1799 sealedLetter = stack.method_60503(getSealedItem());
        sealedLetter.method_57379(Envelope.DataComponents.SEAL, seal);
        return sealedLetter;
    }

    public class_1935 getSealedItem() {
        return Envelope.Items.SEALED_LETTER.get();
    }

    // --

    public static class_1799 tatterIfApplicable(class_1937 level, class_1799 stack) {
        if (stack.method_31574(Envelope.Items.TATTERED_LETTER.get()) || stack.method_31574(Envelope.Items.SEALED_TATTERED_LETTER.get())) {
            return stack;
        }

        if (stack.method_31574(Envelope.Items.LETTER.get())) {
            return stack.method_60503(Envelope.Items.TATTERED_LETTER.get());
        }
        else if (stack.method_31574(Envelope.Items.SEALED_LETTER.get())) {
            return stack.method_60503(Envelope.Items.SEALED_TATTERED_LETTER.get());
        }

        return stack;
    }
}
