package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import net.minecraft.class_1935;
import net.minecraft.class_2248;

public class TatteredLetterItem extends LetterItem {
    public TatteredLetterItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    @Override
    public class_1935 getSealedItem() {
        return Envelope.Items.SEALED_TATTERED_LETTER.get();
    }
}
