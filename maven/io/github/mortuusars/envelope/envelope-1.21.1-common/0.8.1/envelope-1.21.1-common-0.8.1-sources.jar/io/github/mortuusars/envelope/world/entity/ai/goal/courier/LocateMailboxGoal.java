package io.github.mortuusars.envelope.world.entity.ai.goal.courier;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.integration.sable.ContraptionTargets;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlockEntity;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.delivery.PhysicalCourier;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_4153;
import net.minecraft.class_4156;

public class LocateMailboxGoal extends class_1352 {
    protected final PhysicalCourier courier;
    protected final int maxDistance;
    protected final float frequency;

    public LocateMailboxGoal(PhysicalCourier courier, int maxDistance, float frequency) {
        this.courier = courier;
        this.maxDistance = maxDistance;
        this.frequency = frequency;
        method_6265(EnumSet.of(class_4134.field_18408));
    }

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public boolean method_6264() {
        return MailService.operatesIn(courier.asEntity().method_37908())
              && !courier.isDelivering()
              && courier.canStartDelivery()
              && courier.getMailboxHandler().getLocateCooldown() <= 0
              && courier.getMailboxHandler().getTargetPos() == null
              && courier.asEntity().method_37908().method_8409().method_43057() < frequency;
    }

    @Override
    public boolean method_6266() {
        return false;
    }

    @Override
    public void method_6269() {
        courier.getMailboxHandler().resetLocateCooldown();
        List<class_2338> mailboxes = findNearbyAvailableMailboxes();
        if (!mailboxes.isEmpty()) {
            for (class_2338 pos : mailboxes) {
                if (!courier.getMailboxHandler().isTargetBlacklisted(pos)) {
                    courier.getMailboxHandler().setTargetPos(pos);
                    return;
                }
            }

            courier.getMailboxHandler().clearBlacklist();
            courier.getMailboxHandler().setTargetPos(mailboxes.getFirst());
        }
    }

    private List<class_2338> findNearbyAvailableMailboxes() {
        class_3218 level = (class_3218) courier.asEntity().method_37908();
        class_4153 poiManager = level.method_19494();

        List<class_2338> poiResults = poiManager.method_19125(holder -> holder.method_40225(Envelope.PoiTypes.MAILBOX),
                    courier.asEntity().method_24515(), maxDistance, class_4153.class_4155.field_18489)
              .map(class_4156::method_19141)
              .filter(p -> level.method_8321(p) instanceof MailboxBlockEntity blockEntity
                    && blockEntity.isAvailableForPickup())
              .toList();

        return ContraptionTargets.locateNearby(level, courier.asEntity().method_19538(), maxDistance, poiResults,
              () -> ContraptionTargets.findNearbyMailboxes(
                    level, courier.asEntity().method_19538(), maxDistance, MailboxBlockEntity::isAvailableForPickup));
    }
}
