package io.github.mortuusars.envelope.integration.jei.ingredient;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.world.mail.delivery.CourierProperties;
import io.github.mortuusars.mortaar.client.Minecrft;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.util.EnvelopeSymbols;
import io.github.mortuusars.envelope.world.mail.address.AddressFormatter;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import io.github.mortuusars.mortaar.util.GameTime;
import mezz.jei.api.ingredients.IIngredientRenderer;
import net.minecraft.class_124;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5348;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class ServiceAddressIngredientRenderer implements IIngredientRenderer<ServiceAddress> {
    @Override
    public void render(class_332 guiGraphics, ServiceAddress ingredient) {
        class_327 font = Minecrft.get().field_1772;

        StringBuilder initials = new StringBuilder();
        for (String s : ingredient.getString().split("\\s")) {
            if (!s.isEmpty()) {
                initials.append(Character.toUpperCase(s.charAt(0)));
            }
        }

        String name = font.method_1714(class_5348.method_29430(initials.toString()), 16).getString();
        String icon = font.method_1714(class_5348.method_29430(AddressFormatter.getIcon(ingredient)), 16).getString();

        text(guiGraphics, font, icon, 9 - font.method_1727(icon) / 2, 0);
        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(8 - font.method_1727(name) / 2f + 0.5f, 0, 0);
        text(guiGraphics, font, name, 0, 7);
        guiGraphics.method_51448().method_22909();
    }

    private static void text(class_332 guiGraphics, class_327 font, String string, int x, int y) {
        int mainColor = Colors.ADDRESS_NEUTRAL;
        int shadowColor = 0x453723;
        int outlineColor = 0x63533C;

        guiGraphics.method_51433(font, string, x - 1, y, outlineColor, false);
        guiGraphics.method_51433(font, string, x - 1, y - 1, outlineColor, false);
        guiGraphics.method_51433(font, string, x, y - 1, outlineColor, false);
        guiGraphics.method_51433(font, string, x + 1, y - 1, outlineColor, false);
        guiGraphics.method_51433(font, string, x + 1, y, outlineColor, false);
        guiGraphics.method_51433(font, string, x, y + 1, outlineColor, false);
        guiGraphics.method_51433(font, string, x - 1, y + 1, outlineColor, false);

        guiGraphics.method_51433(font, string, x + 1, y + 1, shadowColor, false);

        guiGraphics.method_51433(font, string, x, y, mainColor, false);
    }

    @SuppressWarnings("removal")
    @Override
    public @NotNull List<class_2561> getTooltip(ServiceAddress ingredient, class_1836 tooltipFlag) {
        if (tooltipFlag.method_8035()) {
            int travelDuration = ingredient.getDefinition().location().getTravelDurationTo(
                  Minecrft.player().method_24515(),
                  Config.Server.PIGEON_DELIVERY_TRAVEL_SPEED.get()).ticks();
            return List.of(
                  ingredient.format().withIcon().toComponent(),
                  class_2561.method_43470("⌚" + EnvelopeSymbols.SMALL_SPACE)
                        .method_10852(GameTime.format(travelDuration, true)).method_27692(class_124.field_1080),
                  class_2561.method_43470(ingredient.getDefinitionHolder().method_40230()
                        .map(key -> key.method_29177().toString()).orElse("<unknown>")).method_27692(class_124.field_1063));
        } else {
            return List.of(ingredient.format().withIcon().toComponent());
        }
    }
}
