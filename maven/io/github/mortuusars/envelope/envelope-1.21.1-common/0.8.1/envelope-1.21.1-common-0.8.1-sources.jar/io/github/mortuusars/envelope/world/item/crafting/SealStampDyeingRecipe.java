package io.github.mortuusars.envelope.world.item.crafting;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.SealStampItem;
import io.github.mortuusars.envelope.world.item.component.seal.SealMaterial;
import io.github.mortuusars.mortaar.resources.Resource;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_9694;
import net.minecraft.class_9791;

public class SealStampDyeingRecipe extends class_1852 {
    public SealStampDyeingRecipe(class_7710 category) {
        super(category);
    }

    public boolean matches(class_9694 input, class_1937 level) {
        @Nullable SealStampItem stamp = null;
        class_1799 stampStack = class_1799.field_8037;
        @Nullable class_1769 dye = null;

        for (int i = 0; i < input.method_59983(); i++) {
            class_1799 stack = input.method_59984(i);
            if (stack.method_7960()) {
                continue;
            }

            if (stack.method_7909() instanceof SealStampItem sealStampItem) {
                if (stamp != null) {
                    return false;
                }

                stamp = sealStampItem;
                stampStack = stack;
            } else if (stack.method_7909() instanceof class_1769 dyeItem) {
                if (dye != null || !SealMaterial.WAX_COLORS.containsKey(dyeItem.method_7802())) {
                    return false;
                }

                dye = dyeItem;
            }
        }

        return stamp != null && dye != null
              && stamp.canDyeWith(stampStack, dye.method_7802());
    }

    public @NotNull class_1799 assemble(class_9694 input, class_7225.class_7874 registries) {
        @Nullable SealStampItem stamp = null;
        class_1799 stampStack = class_1799.field_8037;
        @Nullable class_1769 dye = null;

        for (int i = 0; i < input.method_59983(); i++) {
            class_1799 stack = input.method_59984(i);
            if (stack.method_7960()) {
                continue;
            }

            if (stack.method_7909() instanceof SealStampItem sealStampItem) {
                if (stamp != null) {
                    return class_1799.field_8037;
                }

                stamp = sealStampItem;
                stampStack = stack;
            } else if (stack.method_7909() instanceof class_1769 dyeItem) {
                if (dye != null || !SealMaterial.WAX_COLORS.containsKey(dyeItem.method_7802())) {
                    return class_1799.field_8037;
                }

                dye = dyeItem;
            }
        }

        if (stamp == null || dye == null || !stamp.canDyeWith(stampStack, dye.method_7802())) {
            return class_1799.field_8037;
        }

        class_1799 finalStampStack = stampStack;
        @Nullable class_1769 finalDye = dye;

        @Nullable class_5321<SealMaterial> dyedMaterialKey = SealMaterial.fromDyeColor(dye.method_7802());
        if (dyedMaterialKey == null) {
            return class_1799.field_8037;
        }

        return Resource.get(dyedMaterialKey, registries)
              .map(material -> {
                  @Nullable Supplier<SealStampItem> dyedStamp = Envelope.Items.DYED_SEAL_STAMPS.get(finalDye.method_7802());
                  if (dyedStamp == null) {
                      return class_1799.field_8037;
                  }
                  class_1799 result = finalStampStack.method_60503(dyedStamp.get());
                  result.method_57379(Envelope.DataComponents.SEAL_STAMP_MATERIAL, new class_9791<>(material));
                  return result;
              })
              .orElse(class_1799.field_8037);
    }

    @Override
    public boolean method_8113(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return Envelope.RecipeSerializers.SEAL_STAMP_DYEING.get();
    }
}
