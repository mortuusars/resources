package io.github.mortuusars.envelope.world.entity.ai.goal.courier;

import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlockEntity;
import io.github.mortuusars.envelope.world.entity.ai.MailboxHandler;
import io.github.mortuusars.envelope.world.mail.delivery.PhysicalCourier;
import net.minecraft.class_11;
import net.minecraft.class_1408;
import net.minecraft.class_2338;
import org.jetbrains.annotations.Nullable;

public class GoToMailboxGoal extends AbstractGoToBlockGoal {
    @Nullable
    protected class_11 lastPath;

    public GoToMailboxGoal(PhysicalCourier courier) {
        super(courier);
    }

    @Override
    public @Nullable class_2338 getBlockPos() {
        return courier.getMailboxHandler().getTargetPos();
    }

    @Override
    public boolean method_6264() {
        return !courier.isDelivering()
              && courier.canStartDelivery()
              && super.method_6264()
              && courier.asEntity().method_37908().method_8321(getBlockPos()) instanceof MailboxBlockEntity blockEntity
              && blockEntity.isAvailableForPickup();
    }

    @Override
    public void method_6268() {
        MailboxHandler handler = courier.getMailboxHandler();

        if (handler.getTargetPos() == null) return;

        travellingTicks++;
        if (travellingTicks > method_38847(MAX_TRAVELLING_TICKS)) {
            handler.dropAndBlacklistMailbox();
            return;
        }

        class_1408 navigation = courier.asEntity().method_5942();
        if (navigation.method_23966()) {
            return;
        }

        if (!courier.closerThan(handler.getTargetPos(), 16)) {
            if (handler.getTargetPos() != null
                  && Position.distanceToSqr(courier.asEntity().method_37908(), handler.getTargetPos(), courier.asEntity().method_19538()) > 48 * 48) {
                handler.dropMailbox();
            } else {
                courier.pathfindRandomlyTowards(handler.getTargetPos());
            }
        } else if (!navigation.method_23966()) {
            boolean canReach = courier.pathfindDirectlyTowards(handler.getTargetPos());
            if (!canReach && navigation.method_6345() == null) {
                handler.dropAndBlacklistMailbox();
            } else if (lastPath != null && lastPath.method_41(navigation.method_6345())) {
                ticksStuck++;
                if (ticksStuck > TICKS_BEFORE_DROP) {
                    handler.dropMailbox();
                    ticksStuck = 0;
                }
            } else {
                lastPath = navigation.method_6345();
            }
        }
    }
}
