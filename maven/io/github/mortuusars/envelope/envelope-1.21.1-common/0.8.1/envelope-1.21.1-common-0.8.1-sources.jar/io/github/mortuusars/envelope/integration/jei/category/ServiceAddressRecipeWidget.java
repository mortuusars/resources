package io.github.mortuusars.envelope.integration.jei.category;

import io.github.mortuusars.envelope.integration.jei.EnvelopeJeiPlugin;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import io.github.mortuusars.mortaar.client.Minecrft;
import io.github.mortuusars.mortaar.util.TextUtil;
import mezz.jei.api.gui.builder.ITooltipBuilder;
import mezz.jei.api.gui.widgets.IRecipeWidget;
import mezz.jei.api.ingredients.IIngredientRenderer;
import net.minecraft.class_1836;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5348;
import net.minecraft.class_8029;
import net.minecraft.class_8030;
import org.jetbrains.annotations.NotNull;

public class ServiceAddressRecipeWidget implements IRecipeWidget {
    protected class_8030 area;
    protected final ServiceAddress address;
    protected class_327 font;
    protected final class_5348 text;
    protected final int textWidth;

    public ServiceAddressRecipeWidget(class_8030 area, ServiceAddress address) {
        this.area = area;
        this.address = address;
        class_2561 addressComponent = address
              .format()
              .withIcon()
              .toComponent();
        this.font = Minecrft.get().field_1772;
        this.text = TextUtil.truncateStringToWidth(font, addressComponent, area.comp_1196());
        this.textWidth = font.method_27525(text);
    }

    @Override
    public @NotNull class_8029 getPosition() {
        return area.comp_1195();
    }

    @SuppressWarnings("removal")
    @Override
    public void draw(class_332 guiGraphics, double mouseX, double mouseY) {
        int x = area.comp_1195().comp_1193() + area.comp_1196() / 2 - textWidth / 2;
        int y = area.comp_1195().comp_1194();

        int color = 0xFF808080;
        if (isHovering(mouseX, mouseY)) {
            color = 0xFFFFFFFF;
        }

        guiGraphics.method_51430(font, class_2477.method_10517().method_30934(text), x, y, color, false);
    }

    @Override
    public void getTooltip(ITooltipBuilder tooltip, double mouseX, double mouseY) {
        if (isHovering(mouseX, mouseY) && EnvelopeJeiPlugin.runtime != null) {
            // All that is to render the same tooltip as JEI renders on ingredients (with blue mod-name text, etc.)
            IIngredientRenderer<ServiceAddress> renderer =
                  EnvelopeJeiPlugin.runtime.getIngredientManager().getIngredientRenderer(EnvelopeJeiPlugin.SERVICE_ADDRESS_INGREDIENT);

            //noinspection removal
            renderer.getTooltip(tooltip, address,
                  Minecrft.options().field_1827 ? class_1836.field_41071 : class_1836.field_41070);

            EnvelopeJeiPlugin.runtime.getIngredientManager()
                  .createTypedIngredient(EnvelopeJeiPlugin.SERVICE_ADDRESS_INGREDIENT, address, false)
                  .ifPresent(tooltip::setIngredient);
        }
    }

    public boolean isHovering(double mouseX, double mouseY) {
        double textX = area.comp_1195().comp_1193() + area.comp_1196() / 2.0 - textWidth / 2.0;
        return mouseX >= textX && mouseX <= textX + textWidth
              && mouseY >= area.comp_1195().comp_1194() && mouseY <= area.comp_1197();
    }
}
