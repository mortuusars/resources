package io.github.mortuusars.envelope.network.packet.serverbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.mortaar.network.packet.Packet;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3965;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlock;
import io.github.mortuusars.envelope.world.item.MailboxBlockItem;
import io.github.mortuusars.mortaar.network.codec.StreamCodecs;
import org.jetbrains.annotations.NotNull;

public record ServerboundMailboxPlacePacket(class_1268 hand, String address, class_3965 hitResult) implements Packet {
    public static final class_2960 ID = Envelope.resource("mailbox_place");
    public static final class_9154<ServerboundMailboxPlacePacket> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, ServerboundMailboxPlacePacket> STREAM_CODEC = class_9139.method_56436(
          class_9135.field_48550.method_56432(i -> class_1268.values()[i], class_1268::ordinal), ServerboundMailboxPlacePacket::hand,
          class_9135.field_48554, ServerboundMailboxPlacePacket::address,
          StreamCodecs.BLOCK_HIT_RESULT, ServerboundMailboxPlacePacket::hitResult,
          ServerboundMailboxPlacePacket::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        class_1799 mailbox = player.method_5998(hand);

        if (mailbox.method_7960() || !(mailbox.method_7909() instanceof MailboxBlockItem)) {
            Envelope.LOGGER.error("Cannot handle {} packet: {} is not a valid mailbox item.", ID, mailbox);
            return false;
        }

        class_1750 context = new class_1750(player, hand, mailbox, hitResult);
        MailboxBlock.placeBlockWithAddress(player, hand, context, address);
        return true;
    }
}
