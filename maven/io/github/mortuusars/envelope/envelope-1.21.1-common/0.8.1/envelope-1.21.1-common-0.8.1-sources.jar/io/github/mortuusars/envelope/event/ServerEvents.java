package io.github.mortuusars.envelope.event;

import io.github.mortuusars.envelope.world.level.saveddata.SealLocks;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_3222;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.server.MinecraftServer;

public class ServerEvents {
    public static void serverStarted(MinecraftServer server) {
    }

    public static void serverTick(MinecraftServer server) {
    }

    public static void playerLogin(class_3222 player) {
        player.method_51469().getEnvelopeMailService().getKnownPlayers().add(player);
        SealLocks.get(player.method_37908()).syncToClient(player);
    }

    public static void playerCopy(class_3222 oldPlayer, class_3222 newPlayer, boolean alive) {
        if (!alive && !oldPlayer.method_37908().method_8450().method_8355(class_1928.field_19389)) {
            transferKeptItems(oldPlayer, newPlayer);
        }
    }

    private static void transferKeptItems(class_3222 oldPlayer, class_3222 newPlayer) {
        for (int i = 0; i < oldPlayer.method_31548().method_5439(); i++) {
            class_1799 item = oldPlayer.method_31548().method_5438(i);

            if (item.method_7960()) {
                continue;
            }

            class_9279 data = item.method_57825(class_9334.field_49628, class_9279.field_49302);
            if (data.method_57450("envelope_keep_in_inventory_on_transfer")) {
                data = data.method_57451(tag -> tag.method_10551("envelope_keep_in_inventory_on_transfer"));
                if (data.method_57458()) {
                    item.method_57381(class_9334.field_49628);
                } else {
                    item.method_57379(class_9334.field_49628, data);
                }
                newPlayer.method_31548().method_5447(i, item);
            }
        }
    }
}
