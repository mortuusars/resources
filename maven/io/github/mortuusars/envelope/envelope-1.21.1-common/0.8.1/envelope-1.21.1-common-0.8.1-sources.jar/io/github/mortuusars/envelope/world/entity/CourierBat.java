package io.github.mortuusars.envelope.world.entity;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.entity.ai.MailboxHandler;
import io.github.mortuusars.envelope.world.entity.ai.goal.courier.*;
import io.github.mortuusars.envelope.world.entity.spawning.SpawnableEntityData;
import io.github.mortuusars.envelope.world.mail.delivery.CourierOrigin;
import io.github.mortuusars.envelope.world.mail.delivery.CourierProperties;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import io.github.mortuusars.envelope.world.mail.delivery.PhysicalCourier;
import io.github.mortuusars.mortaar.bugger.Bugger;
import net.minecraft.class_11;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1314;
import net.minecraft.class_1331;
import net.minecraft.class_1347;
import net.minecraft.class_1352;
import net.minecraft.class_1395;
import net.minecraft.class_1407;
import net.minecraft.class_1432;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2512;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_7094;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.goal.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.*;

public class CourierBat extends class_1314 implements class_1432, PhysicalCourier {
    public static final List<String> IGNORED_TAGS = Arrays.asList(
          "Air",
          "ArmorDropChances",
          "ArmorItems",
          "Brain",
          "CanPickUpLoot",
          "DeathTime",
          "FallDistance",
          "FallFlying",
          "Fire",
          "HandDropChances",
          "HandItems",
          "HurtByTimestamp",
          "HurtTime",
          "LeftHanded",
          "Motion",
          "NoGravity",
          "OnGround",
          "PortalCooldown",
          "Pos",
          "Rotation",
          "SleepingX",
          "SleepingY",
          "SleepingZ",
          "Passengers",
          "UUID",
          "leash",
          "Delivery"
    );

    private static final Logger LOGGER = LogUtils.getLogger();

    private static final class_2940<Boolean> DATA_DELIVERING = class_2945.method_12791(CourierBat.class, class_2943.field_13323);
    private static final class_2940<Boolean> DATA_HAS_MAIL = class_2945.method_12791(CourierBat.class, class_2943.field_13323);
    private static final class_2940<Boolean> DATA_SERVICE = class_2945.method_12791(CourierBat.class, class_2943.field_13323);

    public final class_7094 flyAnimationState = new class_7094();

    protected MailboxHandler mailboxHandler = new MailboxHandler();

    protected @Nullable Delivery delivery;
    protected @Nullable CourierOrigin origin;

    protected @Nullable class_2338 spawnPos;
    protected int deliveries;

    public CourierBat(class_1299<? extends CourierBat> entityType, class_1937 level) {
        super(entityType, level);
        field_6207 = new class_1331(this, 10, false);
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
              .method_26868(class_5134.field_23716, 6.0)
              .method_26868(class_5134.field_23720, 1F)
              .method_26868(class_5134.field_23719, 0.2F);
    }

    public static CourierBat createService(class_3218 level) {
        return Objects.requireNonNull(Envelope.EntityTypes.COURIER_BAT.get().method_5883(level),
              "Failed to create an entity. This should not happen.");
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(DATA_DELIVERING, false);
        builder.method_56912(DATA_HAS_MAIL, false);
        builder.method_56912(DATA_SERVICE, false);
    }

    // -- Mailbox

    public MailboxHandler getMailboxHandler() {
        return mailboxHandler;
    }

    public void setMailboxHandler(MailboxHandler mailboxHandler) {
        this.mailboxHandler = mailboxHandler;
    }

    // -- Properties

    @Override
    public boolean isDelivering() {
        return field_6011.method_12789(DATA_DELIVERING);
    }

    public void setDelivering(boolean delivering) {
        field_6011.method_12778(DATA_DELIVERING, delivering);
    }

    public boolean hasMail() {
        return field_6011.method_12789(DATA_HAS_MAIL);
    }

    public void setHasMail(boolean hasMail) {
        field_6011.method_12778(DATA_HAS_MAIL, hasMail);
    }

    public boolean isService() {
        return field_6011.method_12789(DATA_SERVICE);
    }

    public void setService(boolean service) {
        field_6011.method_12778(DATA_SERVICE, service);
    }

    public @Nullable class_2338 getSpawnPos() {
        return spawnPos;
    }

    public CourierBat setSpawnPos(@Nullable class_2338 pos) {
        this.spawnPos = pos;
        return this;
    }

    @Override
    protected void method_5623(double y, boolean onGround, class_2680 state, class_2338 pos) {

    }

    protected class_1297.@NotNull class_5799 method_33570() {
        return class_5799.field_28632;
    }

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    protected void method_6087(class_1297 entity) {
    }

    protected void method_6070() {
    }

    public boolean method_5696() {
        return true;
    }

    @Override
    public void method_5982() {
        // This method seems to be called every tick, even if entity is not in ticking range
        // It's a good place to check if courier should be transitioned to background
        if (method_37908() instanceof class_3218 level && !method_5987() && isDelivering() && !Position.isInSimulationDistance(level, this)) {
            transitionToBackground(level);
            return;
        }

        super.method_5982();
    }

    @Override
    public boolean method_5947() {
        // Not sure if this changes much, but just to make sure.
        return super.method_5947() || isDelivering();
    }

    /**
     * Implementing FlyingAnimal makes significant difference, as some movement code (in LivingEntity) executes differently if entity is one.
     * Without it, Bat turns back occasionally making its flight look weird.<br>
     * The method itself doesn't really make a difference, but Bat is flying - so returning 'true' here wouldn't hurt.
     */
    @Override
    public boolean method_6581() {
        return true;
    }

    @Override
    protected float method_49484() {
        return 0.04f;
    }

    public boolean method_5776() {
        return (float) field_6012 % 10.0F == 0.0F;
    }

    @Override
    public boolean method_5931() {
        return false;
    }

    // -- Loot

    @Override
    protected @NotNull class_5321<class_52> method_5991() {
        return class_1299.field_6108.method_16351();
    }

    @Override
    protected boolean method_27071() {
        return false;
    }

    @Override
    protected void method_16080(class_3218 level, class_1282 damageSource) {
        super.method_16080(level, damageSource);
        getCurrentDelivery().ifPresent(delivery -> diedWhileDelivering(level, damageSource, delivery));
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (method_37908().method_8608()) return false;
        if (method_29504()) return false;

        if (method_59922().method_43058() < Config.Server.DELIVERY_COURIER_DAMAGE_EVASION_CHANCE.get()
              && !source.method_48789(Envelope.Tags.DamageTypes.BYPASSES_COURIER_DELIVERY_EVASION)) {

            if (method_37908() instanceof class_3218 level) {
                level.method_14199(class_2398.field_11203, method_19538().field_1352, method_19538().field_1351, method_19538().field_1350, 3, 0.3, 0.3, 0.3, 0);
                level.method_43129(null, this, Envelope.SoundEvents.COURIER_EVADE.get(), class_3419.field_15254, 1,
                      method_59922().method_43057() * 0.1f + 0.95f);
            }

            return false;
        }

        return super.method_5643(source, amount);
    }

    // -- Sound

    @Override
    protected float method_6107() {
        return 0.1F;
    }

    @Override
    public float method_6017() {
        return super.method_6017() * 0.95F;
    }

    @Override
    protected void method_5712(class_2338 pos, class_2680 state) {

    }

    @Override
    @Nullable
    public class_3414 method_5994() {
        return class_3417.field_15009;
    }

    @Override
    protected class_3414 method_6011(class_1282 damageSource) {
        return class_3417.field_14746;
    }

    @Override
    protected class_3414 method_6002() {
        return class_3417.field_14911;
    }

    // -- AI

    @Override
    protected void method_5959() {
        field_6201.method_6277(0, new DespawnGoal());
        field_6201.method_6277(0, new ConvertGoal());
        field_6201.method_6277(0, new LeaveGoal(this));
        field_6201.method_6277(0, new DeliverMailGoal(this));
        field_6201.method_6277(1, new StartDeliveryFromMailboxGoal(this));
        field_6201.method_6277(2, new GoToMailboxGoal(this));
        field_6201.method_6277(3, new LocateMailboxGoal(this, 32, 1f));

        class_1395 wanderGoal = new class_1395(this, 1f);
        wanderGoal.method_6303(1);
        field_6201.method_6277(4, wanderGoal);
        field_6201.method_6277(10, new class_1347(this));
    }

    @Override
    protected @NotNull class_1407 method_5965(class_1937 level) {
        class_1407 navigation = new class_1407(this, level);
        navigation.method_6332(false);
        navigation.method_6354(true);
        navigation.method_6331(true);
        return navigation;
    }

    @Override
    public void method_5773() {
        super.method_5773();
        flyAnimationState.method_41324(this.field_6012);
    }

    @Override
    public void method_6007() {
        if (method_5987()) {
            return;
        }

        getMailboxHandler().tick(this, method_37908());

        if (spawnPos == null && !isDelivering() && getMailboxHandler().getTargetPos() == null) {
            spawnPos = Position.ascendTowards(method_37908(), method_24515(),
                  Optional.empty(), Config.Server.DELIVERY_ASCEND_DISTANCE.get(), method_5628());
        }

        super.method_6007();
    }

    @Override
    public @NotNull class_1269 method_5992(class_1657 player, class_1268 hand) {
        if (player.method_5998(hand).method_31574(class_1802.field_8688)) {
            method_5977(!method_5987());
            player.method_7353(class_2561.method_43470("Set NoAI of " + method_5477().getString() + " to: " + method_5987()), true);
            return class_1269.field_5812;
        }
        return super.method_5992(player, hand);
    }

    // -- Courier

    @Override
    public boolean canEat(class_1799 food) {
        return food.method_31573(Envelope.Tags.Items.BAT_FOOD);
    }

    @Override
    public CourierProperties getCourierProperties() {
        return new CourierProperties(Config.Server.BAT_DELIVERY_TRAVEL_SPEED.get());
    }

    @Override
    public class_2394 getTransitionParticle() {
        return class_2398.field_11237;
    }

    @Override
    public boolean canStartDelivery() {
        return method_37908().method_23886()
              && !method_37908().method_8419()
              && !method_37908().method_8546()
              && deliveries < Config.Server.BAT_MAX_DELIVERIES.get();
    }

    public Optional<Delivery> getCurrentDelivery() {
        return Optional.ofNullable(delivery);
    }

    public void setDelivery(@Nullable Delivery delivery) {
        if (delivery == null && this.delivery == null) {
            return;
        }
        this.delivery = delivery;
        onDeliveryChanged();

        if (!method_37908().method_8608() && Bugger.isEnabled()) {
            Envelope.BuggerData.COURIER_DELIVERY.send(method_5628(), Optional.ofNullable(delivery));
        }
    }

    public void onDeliveryChanged() {
        if (!method_37908().method_8608()) {
            setDelivering(getCurrentDelivery().isPresent());
            setHasMail(delivery != null && !delivery.getMail().method_7960());
        }
    }

    @Override
    public @NotNull CourierOrigin getCourierOrigin() {
        if (origin == null) {
            LOGGER.warn("Origin of a Bat was not set properly. Service origin will be used instead.");
            origin = CourierOrigin.service();
        }
        return origin;
    }

    public void setOrigin(@Nullable CourierOrigin origin) {
        this.origin = origin;
        setService(origin != null && origin.isService());
    }

    @Override
    public SpawnableEntityData toSpawnableCourierData() {
        return SpawnableEntityData.of(this, IGNORED_TAGS);
    }

    @Override
    public void endDelivery(class_3218 level, Delivery delivery) {
        if (!delivery.getMail().method_7960()) {
            method_5775(delivery.getMail().method_7972());
            LOGGER.info("{} has dropped undelivered mail on the ground.", method_5477().getString());
            delivery.setMail(class_1799.field_8037);
        }

        setDelivery(null);

        deliveries++;

        getMailboxHandler().setTargetPos(null);
        method_5966();

        if (getCourierOrigin().isService() && spawnPos == null) {
            spawnPos = Position.ascendTowards(level, method_24515(),
                  Optional.empty(), Config.Server.DELIVERY_ASCEND_DISTANCE.get(), method_5628());
        }
    }

    public void despawn() {
        if (method_37908() instanceof class_3218 level) {
            onVanished(level);
            method_31472();
        }
    }

    // -- Save / Load

    @Override
    public void method_5652(class_2487 tag) {
        super.method_5652(tag);

        tag.method_10566("MailboxHandler", MailboxHandler.CODEC.encode(getMailboxHandler(), class_2509.field_11560, new class_2487()).getOrThrow());

        if (delivery != null) {
            Delivery.CODEC.encodeStart(method_56673().method_57093(class_2509.field_11560), delivery)
                  .resultOrPartial(LOGGER::error)
                  .ifPresent(value -> tag.method_10566("Delivery", value));
        }

        if (origin != null) {
            CourierOrigin.CODEC.encodeStart(class_2509.field_11560, origin)
                  .resultOrPartial(LOGGER::error)
                  .ifPresent(value -> tag.method_10566("Origin", value));
        }

        if (deliveries > 0) {
            tag.method_10569("Deliveries", deliveries);
        }

        if (spawnPos != null) {
            tag.method_10566("SpawnPos", class_2512.method_10692(spawnPos));
        }
    }

    @Override
    public void method_5749(class_2487 tag) {
        super.method_5749(tag);

        MailboxHandler.CODEC.parse(class_2509.field_11560, tag.method_10562("MailboxHandler"))
              .resultOrPartial(e -> LOGGER.error("Cannot parse MailboxHandler from tag '{}': {}", tag.method_10562("MailboxHandler"), e))
              .ifPresent(this::setMailboxHandler);

        if (tag.method_10545("Delivery")) {
            setDelivery(Delivery.CODEC.parse(method_56673().method_57093(class_2509.field_11560), tag.method_10562("Delivery"))
                  .resultOrPartial(e -> LOGGER.error("Cannot parse Delivery from tag '{}': {}", tag.method_10562("Delivery"), e))
                  .orElse(null)
            );
        }

        if (tag.method_10545("Origin")) {
            setOrigin(CourierOrigin.CODEC.parse(class_2509.field_11560, tag.method_10562("Origin"))
                  .resultOrPartial(e -> LOGGER.error("Cannot parse CourierOrigin from tag '{}': {}", tag.method_10562("Origin"), e))
                  .orElse(null));
        }

        setDelivering(delivery != null);
        setHasMail(delivery != null && !delivery.getMail().method_7960());

        deliveries = tag.method_10550("Deliveries");
        spawnPos = class_2512.method_10691(tag, "SpawnPos").orElse(null);
    }

    public class LeaveGoal extends AbstractGoToBlockGoal {
        private class_11 lastPath;
        private int unreachableTicks;

        public LeaveGoal(PhysicalCourier courier) {
            super(courier);
        }

        @Override
        public @Nullable class_2338 getBlockPos() {
            return spawnPos;
        }

        @Override
        public boolean method_6264() {
            if (isDelivering()) return false;
            return super.method_6264() && (!canStartDelivery() || getMailboxHandler().getTargetPos() == null);
        }

        @Override
        public void method_6269() {
            super.method_6269();
            // If bat decided to leave - prevent it from searching mailbox again.
            // Default cooldown is rather short, and in some cases the bat will be caught in a loop of
            // leaving -> going to mailbox -> cannot reach -> leaving -> going to mailbox -> cannot reach -> etc.
            getMailboxHandler().setLocateCooldown(400);
        }

        @Override
        public void method_6268() {
            class_2338 target = getBlockPos();

            if (target == null) {
                return;
            }

            travellingTicks++;
            if (travellingTicks > method_38847(600)) {
                setSpawnPos(null);
            } else if (!method_5942().method_23966()) {
                if (!closerThan(target, 20)) {
                    pathfindRandomlyTowards(target);
                } else {
                    boolean canReach = pathfindDirectlyTowards(target);
                    if (!canReach) {
                        unreachableTicks++;
                        if (unreachableTicks > 20) {
                            despawn();
                        }
                    } else if (lastPath != null && Objects.requireNonNull(method_5942().method_6345()).method_41(lastPath)) {
                        // Fixes bat sometimes not being able to reach the target while being just under it.
                        if (hasReachedTarget(target, 2.5)) {
                            despawn();
                        }

                        ticksStuck++;
                        if (ticksStuck > 40) {
                            setSpawnPos(null);
                            ticksStuck = 0;
                        }
                    } else {
                        lastPath = method_5942().method_6345();
                    }
                }
            }
        }
    }

    public class DespawnGoal extends class_1352 {
        @Override
        public boolean method_6264() {
            if (isDelivering() || getCourierOrigin().isRegular()) return false;
            return (!canStartDelivery() || getMailboxHandler().getTargetPos() == null)
                  && (spawnPos == null || hasReachedTarget(spawnPos));
        }

        @Override
        public void method_6269() {
            despawn();
            Envelope.LOGGER.debug("Service CourierBat was despawned.");
        }
    }

    public class ConvertGoal extends class_1352 {
        @Override
        public boolean method_6264() {
            if (isDelivering() || getCourierOrigin().isService()) return false;
            return (!canStartDelivery() || getMailboxHandler().getTargetPos() == null);
        }

        @Override
        public void method_6269() {
            if (method_29243(class_1299.field_6108, false) == null) {
                if (method_37908() instanceof class_3218 serverLevel) {
                    onVanished(serverLevel);
                }
                method_31472();
                Envelope.LOGGER.debug("CourierBat was despawned as it failed to convert into a regular Bat.");
            } else {
                Envelope.LOGGER.debug("CourierBat was converted into a regular Bat.");
            }
        }
    }
}
