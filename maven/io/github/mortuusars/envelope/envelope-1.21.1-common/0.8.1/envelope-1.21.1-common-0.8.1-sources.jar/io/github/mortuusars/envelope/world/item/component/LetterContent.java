package io.github.mortuusars.envelope.world.item.component;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2561;
import net.minecraft.class_5244;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record LetterContent(class_2561 text) {
    public static final Codec<LetterContent> CODEC = RecordCodecBuilder.create(i -> i.group(
          class_8824.field_46597.optionalFieldOf("text", class_5244.field_39003).forGetter(LetterContent::text)
    ).apply(i, LetterContent::new));

    public static final class_9139<class_9129, LetterContent> STREAM_CODEC = class_9139.method_56434(
          class_8824.field_48540, LetterContent::text,
          LetterContent::new
    );

    public static final LetterContent EMPTY = new LetterContent(class_5244.field_39003);

    public boolean isEmpty() {
        return this.equals(EMPTY) || text().getString().isEmpty();
    }
}