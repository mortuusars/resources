package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.ServiceLetterMeaning;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import org.jetbrains.annotations.NotNull;

public class ServiceLetterItem extends LetterItem {
    public ServiceLetterItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    @Override
    public @NotNull class_2561 method_7864(class_1799 stack) {
        if (stack.method_57824(Envelope.DataComponents.SERVICE_LETTER_MEANING) instanceof ServiceLetterMeaning meaning) {
            return meaning.translate();
        }
        return super.method_7864(stack);
    }

    public class_1935 getSealedItem() {
        return Envelope.Items.SEALED_SERVICE_LETTER.get();
    }
}
