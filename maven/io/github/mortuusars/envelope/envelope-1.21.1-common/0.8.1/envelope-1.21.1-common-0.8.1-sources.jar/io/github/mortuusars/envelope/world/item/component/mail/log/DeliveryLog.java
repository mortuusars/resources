package io.github.mortuusars.envelope.world.item.component.mail.log;

import com.mojang.serialization.Codec;
import java.util.*;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record DeliveryLog(List<DeliveryRecord> records) {
    public static final Codec<DeliveryLog> CODEC =
          DeliveryRecord.CODEC.listOf(0, 64).xmap(DeliveryLog::new, DeliveryLog::records);
    public static final class_9139<class_9129, DeliveryLog> STREAM_CODEC =
          DeliveryRecord.STREAM_CODEC.method_56433(class_9135.method_58000(64)).method_56432(DeliveryLog::new, DeliveryLog::records);

    public static final DeliveryLog EMPTY = new DeliveryLog(Collections.emptyList());

    public boolean isEmpty() {
        return records.isEmpty();
    }

    public DeliveryLog append(DeliveryRecord record) {
        List<DeliveryRecord> records = new ArrayList<>(this.records);
        records.add(record);
        while (records.size() > 64) {
            records.removeFirst();
        }
        return new DeliveryLog(records);
    }

    public DeliveryLog append(DeliveryRecord... list) {
        List<DeliveryRecord> records = new ArrayList<>(this.records);
        records.addAll(Arrays.asList(list));
        while (records.size() > 64) {
            records.removeFirst();
        }
        return new DeliveryLog(records);
    }

    @Override
    public boolean equals(Object object) {
        if (object == null || getClass() != object.getClass()) return false;
        DeliveryLog that = (DeliveryLog) object;
        return Objects.equals(records, that.records);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(records);
    }
}