package io.github.mortuusars.envelope.world.entity.ai.goal.courier;

import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.mail.delivery.PhysicalCourier;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_1408;
import net.minecraft.class_2338;

public abstract class AbstractGoToBlockGoal extends class_1352 {
    public static final int MAX_TRAVELLING_TICKS = 600;
    public static final int TICKS_BEFORE_DROP = 60;

    protected final PhysicalCourier courier;

    protected int travellingTicks;
    protected int ticksStuck;

    public AbstractGoToBlockGoal(PhysicalCourier courier) {
        this.courier = courier;
        method_6265(EnumSet.of(class_4134.field_18405));
    }

    public abstract @Nullable class_2338 getBlockPos();

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public boolean method_6264() {
        @Nullable class_2338 pos = getBlockPos();
        return pos != null
              && !courier.asEntity().method_18410()
              && !courier.hasReachedTarget(pos)
              && !Position.isFireNearby(courier.asEntity().method_37908(), pos);
    }

    @Override
    public void method_6269() {
        travellingTicks = 0;
        ticksStuck = 0;
        super.method_6269();
    }

    @Override
    public void method_6270() {
        this.travellingTicks = 0;
        this.ticksStuck = 0;
        class_1408 navigation = courier.asEntity().method_5942();
        navigation.method_6340();
        navigation.method_23965();
    }
}
