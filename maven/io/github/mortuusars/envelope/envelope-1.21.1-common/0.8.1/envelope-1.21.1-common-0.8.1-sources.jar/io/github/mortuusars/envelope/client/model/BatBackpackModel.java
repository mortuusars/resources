package io.github.mortuusars.envelope.client.model;

import io.github.mortuusars.envelope.Envelope;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;

public class BatBackpackModel extends class_3879 {
    public static final class_2960 TEXTURE = Envelope.resource("textures/entity/bat/misc/bat_backpack.png");

    private final class_630 root;

    public BatBackpackModel(class_630 root) {
        super(class_1921::method_23578);
        this.root = root;
    }

    public static class_5607 createLayerDefinition() {
        class_5609 mesh = new class_5609();
        class_5610 root = mesh.method_32111();

        root.method_32117(
              "backpack",
              class_5606.method_32108()
                    .method_32101(0, 0)
                    .method_32097(-3f, -1f, 0.999f, 6, 7, 5),
              class_5603.field_27701
        );

//        root.addOrReplaceChild(
//              "strap",
//              CubeListBuilder.create()
//                    .texOffs(0, 0)
//                    .addBox(0.75f, -1f, -1f, 1, 6f, 2, new CubeDeformation(0, 0, 0.01f)),
//              PartPose.rotation(0, 0, Mth.DEG_TO_RAD * 32.5f)
//        );

        root.method_32117(
              "strap",
              class_5606.method_32108()
                    .method_32101(0, 12)
                    .method_32098(-0.5f, -3, -1, 1, 6, 2, new class_5605(0, 0, 0.01f)),
              class_5603.method_32091(0, 2.5f, 0, 0, 0, class_3532.field_29847 * 32.5f)
        );

//        root.addOrReplaceChild(
//              "backpack",
//              CubeListBuilder.create()
//                    .texOffs(0, 0)
//                    .addBox(-4, 1.5f, -2.5f, 8, 5, 5),
//              PartPose.ZERO
//        );

        return class_5607.method_32110(mesh, 32, 32);
    }

    @Override
    public void method_2828(class_4587 poseStack, class_4588 buffer, int packedLight, int packedOverlay, int color) {
        root.method_22699(poseStack, buffer, packedLight, packedOverlay, color);
    }
}
