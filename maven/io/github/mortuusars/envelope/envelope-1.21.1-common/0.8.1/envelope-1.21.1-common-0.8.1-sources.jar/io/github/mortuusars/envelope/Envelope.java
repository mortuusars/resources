package io.github.mortuusars.envelope;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import dev.architectury.injectables.annotations.ExpectPlatform;
import io.github.mortuusars.envelope.advancements.critereon.BreakPaperBoxWhenFallingTrigger;
import io.github.mortuusars.envelope.advancements.critereon.MailDeliveredTrigger;
import io.github.mortuusars.envelope.advancements.predicate.ItemOccludingBlockPredicate;
import io.github.mortuusars.envelope.advancements.predicate.ItemPackagePredicate;
import io.github.mortuusars.envelope.api.ServiceDropOffHandlerRegistry;
import io.github.mortuusars.envelope.command.argument.AddressArgument;
import io.github.mortuusars.envelope.command.argument.SealLockArgument;
import io.github.mortuusars.envelope.integration.Mods;
import io.github.mortuusars.envelope.integration.every_compat.EveryCompatIntegration;
import io.github.mortuusars.envelope.network.packet.clientbound.*;
import io.github.mortuusars.envelope.network.packet.serverbound.*;
import io.github.mortuusars.envelope.test.cases.EnvelopeBuggerTests;
import io.github.mortuusars.envelope.util.bugger.data.MailServiceBuggerData;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlock;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlockEntity;
import io.github.mortuusars.envelope.world.entity.CharredPigeon;
import io.github.mortuusars.envelope.world.entity.CourierBat;
import io.github.mortuusars.envelope.world.entity.PigeonVariant;
import io.github.mortuusars.envelope.world.entity.ai.MailboxHandler;
import io.github.mortuusars.envelope.world.entity.ai.PigeonholeHandler;
import io.github.mortuusars.envelope.world.inventory.*;
import io.github.mortuusars.envelope.world.item.*;
import io.github.mortuusars.envelope.world.item.component.mail.DeliveryInfo;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import io.github.mortuusars.envelope.world.item.component.seal.SealSymbol;
import io.github.mortuusars.envelope.world.item.component.seal.SealMaterial;
import io.github.mortuusars.envelope.world.item.crafting.*;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailCraftingRecipe;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailLetterBroadcastingRecipe;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailPaybackRequestCancelingRecipe;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailRecipe;
import io.github.mortuusars.envelope.world.item.crafting.mail.serializer.MailRecipeSerializer;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.block.*;
import io.github.mortuusars.envelope.world.block.occupiable.Occupant;
import io.github.mortuusars.envelope.world.item.component.*;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import io.github.mortuusars.envelope.world.mail.delivery.PhysicalCourier;
import io.github.mortuusars.envelope.world.mail.dropoff.MailDropOffContext;
import io.github.mortuusars.envelope.world.mail.dropoff.MailDropOffResult;
import io.github.mortuusars.envelope.world.mail.service.cloud_depository.CloudDepository;
import io.github.mortuusars.envelope.world.mail.service.ServiceAddressDefinition;
import io.github.mortuusars.mortaar.Register;
import io.github.mortuusars.mortaar.Registrar;
import io.github.mortuusars.mortaar.bugger.Bugger;
import io.github.mortuusars.mortaar.bugger.data.EntityData;
import io.github.mortuusars.mortaar.bugger.data.OptionalEntityData;
import io.github.mortuusars.mortaar.util.DeferredSoundType;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_1865;
import net.minecraft.class_1866;
import net.minecraft.class_1959;
import net.minecraft.class_2135;
import net.minecraft.class_2248;
import net.minecraft.class_2314;
import net.minecraft.class_2319;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2941;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3414;
import net.minecraft.class_3446;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_3902;
import net.minecraft.class_3917;
import net.minecraft.class_3956;
import net.minecraft.class_4158;
import net.minecraft.class_4970;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5699;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_8110;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9331;
import net.minecraft.class_9360;
import net.minecraft.class_9791;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class Envelope {
    public static final String ID = "envelope";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final Registrar REGISTRAR = Register.registrar(ID);

    public static void init() {
        Blocks.init();
        BlockEntityTypes.init();
        PoiTypes.init();
        EntityTypes.init();
        EntityDataSerializers.init();
        Items.init();
        CreativeTabs.init();
        DataComponents.init();
        CriteriaTriggers.init();
        ItemSubPredicates.init();
        MenuTypes.init();
        RecipeTypes.init();
        Stats.init();
        RecipeSerializers.init();
        SoundEvents.init();
        ArgumentTypes.init();
        BuggerData.init();

        Register.serverboundPacket(ServerboundMailboxMenuInboxActionPacket.TYPE, ServerboundMailboxMenuInboxActionPacket.STREAM_CODEC);
        Register.serverboundPacket(ServerboundLetterEditPacket.TYPE, ServerboundLetterEditPacket.STREAM_CODEC);
        Register.serverboundPacket(ServerboundItemClosedPacket.TYPE, ServerboundItemClosedPacket.STREAM_CODEC);
        Register.serverboundPacket(ServerboundAddressTagApplyPacket.TYPE, ServerboundAddressTagApplyPacket.STREAM_CODEC);
        Register.serverboundPacket(ServerboundPackingMenuPresetAddressPacket.TYPE, ServerboundPackingMenuPresetAddressPacket.STREAM_CODEC);
        Register.serverboundPacket(ServerboundMailboxPlacePacket.TYPE, ServerboundMailboxPlacePacket.STREAM_CODEC);
        Register.serverboundPacket(ServerboundMailboxAddressTagApplyPacket.TYPE, ServerboundMailboxAddressTagApplyPacket.STREAM_CODEC);
        Register.serverboundPacket(ServerboundPaybackTagMenuSetSlotPacket.TYPE, ServerboundPaybackTagMenuSetSlotPacket.STREAM_CODEC);

        Register.clientboundPacket(ClientboundMailboxHasNewMailPacket.TYPE, ClientboundMailboxHasNewMailPacket.STREAM_CODEC);
        Register.clientboundPacket(ClientboundMailboxMenuSetMailPacket.TYPE, ClientboundMailboxMenuSetMailPacket.STREAM_CODEC);
        Register.clientboundPacket(ClientboundMailboxMenuMailRemovedPacket.TYPE, ClientboundMailboxMenuMailRemovedPacket.STREAM_CODEC);
        Register.clientboundPacket(ClientboundOpenLetterEditScreenPacket.TYPE, ClientboundOpenLetterEditScreenPacket.STREAM_CODEC);
        Register.clientboundPacket(ClientboundOpenLetterBlockViewScreenPacket.TYPE, ClientboundOpenLetterBlockViewScreenPacket.STREAM_CODEC);
        Register.clientboundPacket(ClientboundOpenLetterViewScreenPacket.TYPE, ClientboundOpenLetterViewScreenPacket.STREAM_CODEC);
        Register.clientboundPacket(ClientboundOpenAddressTagScreenPacket.TYPE, ClientboundOpenAddressTagScreenPacket.STREAM_CODEC);
        Register.clientboundPacket(ClientboundOpenMailboxAddressTagScreenPacket.TYPE, ClientboundOpenMailboxAddressTagScreenPacket.STREAM_CODEC);
        Register.clientboundPacket(ClientboundOpenMailboxPlacingScreenPacket.TYPE, ClientboundOpenMailboxPlacingScreenPacket.STREAM_CODEC);
        Register.clientboundPacket(ClientboundSyncDeathLockDataPacket.TYPE, ClientboundSyncDeathLockDataPacket.STREAM_CODEC);

        ServiceDropOffHandlerRegistry.register(ServiceAddress.CLOUD_DEPOSITORY, CloudDepository::handleDropOff);

        if (Mods.EVERY_COMPAT.isLoaded()) {
            EveryCompatIntegration.init();
        }

        Bugger.addTests(EnvelopeBuggerTests::create);
    }

    /**
     * Creates resource location in the mod namespace with the given path.
     */
    public static class_2960 resource(String path) {
        return class_2960.method_60655(ID, path);
    }

    @ExpectPlatform
    public static void registerServiceDropOffHandlers() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static MailDropOffResult postHandleMailDropOffEvent(MailDropOffContext context) {
        throw new AssertionError();
    }

    public static class Blocks {
        public static final Map<class_2960, Supplier<PigeonholeBlock>> PIGEONHOLES = new HashMap<>();

        public static final Supplier<PigeonholeBlock> OAK_PIGEONHOLE = pigeonhole("oak", net.minecraft.class_2246.field_10161.method_26403());
        public static final Supplier<PigeonholeBlock> SPRUCE_PIGEONHOLE = pigeonhole("spruce", net.minecraft.class_2246.field_9975.method_26403());
        public static final Supplier<PigeonholeBlock> BIRCH_PIGEONHOLE = pigeonhole("birch", net.minecraft.class_2246.field_10148.method_26403());
        public static final Supplier<PigeonholeBlock> JUNGLE_PIGEONHOLE = pigeonhole("jungle", net.minecraft.class_2246.field_10334.method_26403());
        public static final Supplier<PigeonholeBlock> ACACIA_PIGEONHOLE = pigeonhole("acacia", net.minecraft.class_2246.field_10218.method_26403());
        public static final Supplier<PigeonholeBlock> DARK_OAK_PIGEONHOLE = pigeonhole("dark_oak", net.minecraft.class_2246.field_10075.method_26403());
        public static final Supplier<PigeonholeBlock> MANGROVE_PIGEONHOLE = pigeonhole("mangrove", net.minecraft.class_2246.field_37577.method_26403());
        public static final Supplier<PigeonholeBlock> CHERRY_PIGEONHOLE = pigeonhole("cherry", net.minecraft.class_2246.field_42751.method_26403());
        public static final Supplier<PigeonholeBlock> BAMBOO_PIGEONHOLE = pigeonhole("bamboo", net.minecraft.class_2246.field_40294.method_26403());
        public static final Supplier<PigeonholeBlock> CRIMSON_PIGEONHOLE = pigeonhole("crimson", net.minecraft.class_2246.field_22126.method_26403());
        public static final Supplier<PigeonholeBlock> WARPED_PIGEONHOLE = pigeonhole("warped", net.minecraft.class_2246.field_22127.method_26403());

        public static final Supplier<MailboxBlock> MAILBOX = REGISTRAR.block("mailbox",
              () -> new MailboxBlock(class_4970.class_2251.method_9637()
                    .method_9632(4f)
                    .method_9626(class_2498.field_11547)
                    .method_31710(class_3620.field_15996)));

        public static final Supplier<PaperBoxBlock> PAPER_BOX = REGISTRAR.block("paper_box",
              () -> new PaperBoxBlock(class_4970.class_2251.method_9637()
                    .method_50012(class_3619.field_15971)
                    .method_50013()
                    .method_9632(0.3f)
                    .method_9626(SoundTypes.PAPER)
                    .method_31710(class_3620.field_15986)
              ));

        public static final Supplier<PackageBlock> PACKAGE = REGISTRAR.block("package",
              () -> new PackageBlock(class_4970.class_2251.method_9637()
                    .method_50012(class_3619.field_15971)
                    .method_50013()
                    .method_9632(0.4f)
                    .method_9626(SoundTypes.PAPER)
                    .method_31710(class_3620.field_15986)
                    .method_22488()));

        public static final Supplier<PackageBlock> SEALED_PACKAGE = REGISTRAR.block("sealed_package",
              () -> new PackageBlock(class_4970.class_2251.method_9637()
                    .method_50012(class_3619.field_15971)
                    .method_50013()
                    .method_9632(0.4f)
                    .method_9626(SoundTypes.PAPER)
                    .method_31710(class_3620.field_15986)
                    .method_22488()));

        public static final Supplier<LetterBlock> LETTER = REGISTRAR.block("letter",
              () -> new LetterBlock(class_4970.class_2251.method_9637()
                    .method_50012(class_3619.field_15971)
                    .method_9626(SoundTypes.PAPER)
                    .method_50013()
                    .method_9618()
                    .method_9634()
                    .method_22488()));
        public static final Supplier<LetterBlock> TATTERED_LETTER = REGISTRAR.block("tattered_letter",
              () -> new LetterBlock(class_4970.class_2251.method_9637()
                    .method_50012(class_3619.field_15971)
                    .method_9626(SoundTypes.PAPER)
                    .method_50013()
                    .method_9618()
                    .method_9634()
                    .method_22488()));
        public static final Supplier<LetterBlock> SERVICE_LETTER = REGISTRAR.block("service_letter",
              () -> new LetterBlock(class_4970.class_2251.method_9637()
                    .method_50012(class_3619.field_15971)
                    .method_9626(SoundTypes.PAPER)
                    .method_50013()
                    .method_9618()
                    .method_9634()
                    .method_22488()));

        private static Supplier<PigeonholeBlock> pigeonhole(String type, class_3620 color) {
            String id = type + "_pigeonhole";
            Supplier<PigeonholeBlock> block = REGISTRAR.block(id,
                  () -> new PigeonholeBlock(class_4970.class_2251.method_9630(net.minecraft.class_2246.field_20422)
                        .method_9632(2f)
                        .method_31710(color)));
            PIGEONHOLES.put(Envelope.resource(id), block);
            return block;
        }

        static void init() {
        }
    }

    public static class BlockEntityTypes {
        public static final Supplier<class_2591<MailboxBlockEntity>> MAILBOX =
              REGISTRAR.blockEntityType("mailbox", () -> REGISTRAR.newBlockEntityType(
                    MailboxBlockEntity::new, Blocks.MAILBOX.get()));

        public static final Supplier<class_2591<PigeonholeBlockEntity>> PIGEONHOLE =
              REGISTRAR.blockEntityType("pigeonhole", () -> REGISTRAR.newBlockEntityType(
                    PigeonholeBlockEntity::new, getPigeonholeBlocks()));

        public static final Supplier<class_2591<PackageBlockEntity>> PACKAGE =
              REGISTRAR.blockEntityType("package", () -> REGISTRAR.newBlockEntityType(
                    PackageBlockEntity::new, Blocks.PACKAGE.get(), Blocks.SEALED_PACKAGE.get()));

        public static final Supplier<class_2591<LetterBlockEntity>> LETTER =
              REGISTRAR.blockEntityType("letter", () -> REGISTRAR.newBlockEntityType(
                    LetterBlockEntity::new, Blocks.LETTER.get(), Blocks.TATTERED_LETTER.get(), Blocks.SERVICE_LETTER.get()));

        private static PigeonholeBlock[] getPigeonholeBlocks() {
            return Blocks.PIGEONHOLES.values().stream().map(Supplier::get).toArray(PigeonholeBlock[]::new);
        }

        static void init() {
        }
    }

    public static class PoiTypes {
        public static final class_5321<class_4158> PIGEONHOLE =
              class_5321.method_29179(net.minecraft.class_7924.field_41212, resource("pigeonhole"));

        public static final class_5321<class_4158> MAILBOX =
              class_5321.method_29179(net.minecraft.class_7924.field_41212, resource("mailbox"));

        static void init() {
            REGISTRAR.poiType(PIGEONHOLE, 0, 1, PoiTypes::getPigeonholePoiBlockStates);
            REGISTRAR.poiType(MAILBOX, 0, 1, PoiTypes::getMailboxPoiBlockStates);
        }

        private static Set<class_2680> getPigeonholePoiBlockStates() {
            return Blocks.PIGEONHOLES.values().stream()
                  .map(Supplier::get)
                  .map(b -> b.method_9595().method_11662())
                  .flatMap(Collection::stream)
                  .collect(Collectors.toSet());
        }

        private static Set<class_2680> getMailboxPoiBlockStates() {
            return Set.copyOf(Blocks.MAILBOX.get().method_9595().method_11662());
        }
    }

    public static class Items {
        public static final List<Supplier<class_1747>> PIGEONHOLES = new ArrayList<>();
        public static final Supplier<class_1747> OAK_PIGEONHOLE = pigeonhole("oak", Blocks.OAK_PIGEONHOLE);
        public static final Supplier<class_1747> SPRUCE_PIGEONHOLE = pigeonhole("spruce", Blocks.SPRUCE_PIGEONHOLE);
        public static final Supplier<class_1747> BIRCH_PIGEONHOLE = pigeonhole("birch", Blocks.BIRCH_PIGEONHOLE);
        public static final Supplier<class_1747> JUNGLE_PIGEONHOLE = pigeonhole("jungle", Blocks.JUNGLE_PIGEONHOLE);
        public static final Supplier<class_1747> ACACIA_PIGEONHOLE = pigeonhole("acacia", Blocks.ACACIA_PIGEONHOLE);
        public static final Supplier<class_1747> DARK_OAK_PIGEONHOLE = pigeonhole("dark_oak", Blocks.DARK_OAK_PIGEONHOLE);
        public static final Supplier<class_1747> MANGROVE_PIGEONHOLE = pigeonhole("mangrove", Blocks.MANGROVE_PIGEONHOLE);
        public static final Supplier<class_1747> CHERRY_PIGEONHOLE = pigeonhole("cherry", Blocks.CHERRY_PIGEONHOLE);
        public static final Supplier<class_1747> BAMBOO_PIGEONHOLE = pigeonhole("bamboo", Blocks.BAMBOO_PIGEONHOLE);
        public static final Supplier<class_1747> CRIMSON_PIGEONHOLE = pigeonhole("crimson", Blocks.CRIMSON_PIGEONHOLE);
        public static final Supplier<class_1747> WARPED_PIGEONHOLE = pigeonhole("warped", Blocks.WARPED_PIGEONHOLE);

        private static Supplier<class_1747> pigeonhole(String type, Supplier<PigeonholeBlock> block) {
            Supplier<class_1747> item = REGISTRAR.item(type + "_pigeonhole", () -> new class_1747(block.get(), new class_1792.class_1793()));
            PIGEONHOLES.add(item);
            return item;
        }

        // --

        public static final Supplier<MailboxBlockItem> MAILBOX = REGISTRAR.item("mailbox",
              () -> new MailboxBlockItem(Blocks.MAILBOX.get(), new class_1792.class_1793()));

        public static final Supplier<LetterAndQuillItem> LETTER_AND_QUILL = REGISTRAR.item("letter_and_quill",
              () -> new LetterAndQuillItem(new class_1792.class_1793().method_7889(1)));

        public static final Supplier<LetterItem> LETTER = REGISTRAR.item("letter",
              () -> new LetterItem(Blocks.LETTER.get(), new class_1792.class_1793()));
        public static final Supplier<LetterItem> TATTERED_LETTER = REGISTRAR.item("tattered_letter",
              () -> new TatteredLetterItem(Blocks.TATTERED_LETTER.get(), new class_1792.class_1793()));
        public static final Supplier<ServiceLetterItem> SERVICE_LETTER = REGISTRAR.item("service_letter",
              () -> new ServiceLetterItem(Blocks.SERVICE_LETTER.get(), new class_1792.class_1793()));

        public static final Supplier<SealedLetterItem> SEALED_LETTER = REGISTRAR.item("sealed_letter",
              () -> new SealedLetterItem(LETTER, new class_1792.class_1793()));
        public static final Supplier<SealedLetterItem> SEALED_TATTERED_LETTER = REGISTRAR.item("sealed_tattered_letter",
              () -> new SealedLetterItem(TATTERED_LETTER, new class_1792.class_1793()));
        public static final Supplier<SealedServiceLetterItem> SEALED_SERVICE_LETTER = REGISTRAR.item("sealed_service_letter",
              () -> new SealedServiceLetterItem(SERVICE_LETTER, new class_1792.class_1793()));

        public static final Supplier<PaperBoxItem> PAPER_BOX = REGISTRAR.item("paper_box",
              () -> new PaperBoxItem(Blocks.PAPER_BOX.get(), new class_1792.class_1793().method_7889(16)));
        public static final Supplier<PackageItem> PACKAGE = REGISTRAR.item("package",
              () -> new PackageItem(Blocks.PACKAGE.get(), new class_1792.class_1793().method_7889(1)));
        public static final Supplier<SealedPackageItem> SEALED_PACKAGE = REGISTRAR.item("sealed_package",
              () -> new SealedPackageItem(Blocks.SEALED_PACKAGE.get(), new class_1792.class_1793().method_7889(1)));

        public static final Supplier<PaybackTagItem> PAYBACK_TAG = REGISTRAR.item("payback_tag",
              () -> new PaybackTagItem(new class_1792.class_1793()));
        public static final Supplier<PaybackBoxItem> PAYBACK_BOX = REGISTRAR.item("payback_box",
              () -> new PaybackBoxItem(new class_1792.class_1793().method_7889(1)));
        public static final Supplier<PaybackPackageItem> PAYBACK_PACKAGE = REGISTRAR.item("payback_package",
              () -> new PaybackPackageItem(new class_1792.class_1793().method_7889(1)));

        public static final Supplier<AddressTagItem> ADDRESS_TAG = REGISTRAR.item("address_tag",
              () -> new AddressTagItem(new class_1792.class_1793()));

        public static final Map<class_1767, Supplier<SealStampItem>> DYED_SEAL_STAMPS = new LinkedHashMap<>();
        public static final Supplier<SealStampItem> SEAL_STAMP = REGISTRAR.item("seal_stamp",
              () -> new SealStampItem(stampProperties(SealMaterial.WAX)));
        public static final Supplier<SealStampItem> WHITE_SEAL_STAMP = dyedStamp(class_1767.field_7952);
        public static final Supplier<SealStampItem> LIGHT_GRAY_SEAL_STAMP = dyedStamp(class_1767.field_7967);
        public static final Supplier<SealStampItem> GRAY_SEAL_STAMP = dyedStamp(class_1767.field_7944);
        public static final Supplier<SealStampItem> BLACK_SEAL_STAMP = dyedStamp(class_1767.field_7963);
        public static final Supplier<SealStampItem> BROWN_SEAL_STAMP = dyedStamp(class_1767.field_7957);
        public static final Supplier<SealStampItem> RED_SEAL_STAMP = dyedStamp(class_1767.field_7964);
        public static final Supplier<SealStampItem> ORANGE_SEAL_STAMP = dyedStamp(class_1767.field_7946);
        public static final Supplier<SealStampItem> YELLOW_SEAL_STAMP = dyedStamp(class_1767.field_7947);
        public static final Supplier<SealStampItem> LIME_SEAL_STAMP = dyedStamp(class_1767.field_7961);
        public static final Supplier<SealStampItem> GREEN_SEAL_STAMP = dyedStamp(class_1767.field_7942);
        public static final Supplier<SealStampItem> CYAN_SEAL_STAMP = dyedStamp(class_1767.field_7955);
        public static final Supplier<SealStampItem> LIGHT_BLUE_SEAL_STAMP = dyedStamp(class_1767.field_7951);
        public static final Supplier<SealStampItem> BLUE_SEAL_STAMP = dyedStamp(class_1767.field_7966);
        public static final Supplier<SealStampItem> PURPLE_SEAL_STAMP = dyedStamp(class_1767.field_7945);
        public static final Supplier<SealStampItem> MAGENTA_SEAL_STAMP = dyedStamp(class_1767.field_7958);
        public static final Supplier<SealStampItem> PINK_SEAL_STAMP = dyedStamp(class_1767.field_7954);
        public static final Supplier<SoulboundSealStampItem> SOULBOUND_SEAL_STAMP = REGISTRAR.item("soulbound_seal_stamp",
              () -> new SoulboundSealStampItem(new class_1792.class_1793().method_7895(8).method_7889(1)));

        private static Supplier<SealStampItem> dyedStamp(class_1767 color) {
            @Nullable class_5321<SealMaterial> materialKey = SealMaterial.fromDyeColor(color);
            Preconditions.checkNotNull(materialKey,
                  "Dye color '" + color + "' doesn't have a corresponding material, or it wasn't added to SealMaterial#WAX_COLORS map.");

            Supplier<SealStampItem> item = REGISTRAR.item(color.method_15434() + "_seal_stamp",
                  () -> new SealStampItem(stampProperties(materialKey)));
            DYED_SEAL_STAMPS.put(color, item);
            return item;
        }

        public static class_1792.class_1793 stampProperties(class_5321<SealMaterial> material) {
            return new class_1792.class_1793()
                  .method_7889(1)
                  .method_57349(DataComponents.SEAL_STAMP_MATERIAL, new class_9791<>(material));
        }

        // --

        public static final Supplier<class_1826> PIGEON_SPAWN_EGG = REGISTRAR.item("pigeon_spawn_egg",
              () -> new class_1826(EntityTypes.PIGEON.get(), 0x676781, 0xB8B8CB, new class_1792.class_1793()));
        public static final Supplier<class_1826> CHARRED_PIGEON_SPAWN_EGG = REGISTRAR.item("charred_pigeon_spawn_egg",
              () -> new class_1826(EntityTypes.CHARRED_PIGEON.get(), 0x2B2223, 0xE85F00, new class_1792.class_1793()));

        static void init() {
        }
    }

    public static class CreativeTabs {
        public static final Supplier<class_1761> ENVELOPE = REGISTRAR.creativeTab("envelope", () ->
              class_1761.method_47307(class_1761.class_7915.field_41049, 0)
                    .method_47321(class_2561.method_43471("item_group.envelope.envelope"))
                    .method_47320(() -> new class_1799(Items.LETTER.get()))
                    .method_47317((params, output) -> {
                        Items.PIGEONHOLES.forEach(item -> output.method_45421(item.get()));
                        output.method_45421(Items.MAILBOX.get());
                        output.method_45421(Items.ADDRESS_TAG.get());
                        output.method_45421(Items.PAYBACK_TAG.get());

                        output.method_45421(Items.LETTER_AND_QUILL.get());
                        output.method_45421(Items.LETTER.get());
                        output.method_45421(Items.SEALED_LETTER.get());
                        output.method_45421(Items.TATTERED_LETTER.get());
                        output.method_45421(Items.SEALED_TATTERED_LETTER.get());
                        output.method_45421(Items.SERVICE_LETTER.get());
                        output.method_45421(Items.SEALED_SERVICE_LETTER.get());

                        output.method_45421(Items.PAPER_BOX.get());
                        output.method_45421(Items.PACKAGE.get());
                        output.method_45421(Items.SEALED_PACKAGE.get());

                        output.method_45421(Items.SEAL_STAMP.get());
                        Items.DYED_SEAL_STAMPS.values().forEach(stamp -> output.method_45421(stamp.get()));
                        output.method_45421(Items.SOULBOUND_SEAL_STAMP.get());

                        output.method_45421(Items.PIGEON_SPAWN_EGG.get());
                        output.method_45421(Items.CHARRED_PIGEON_SPAWN_EGG.get());
                    })
                    .method_47324());

        static void init() {
        }
    }

    public static class DataComponents {
        public static final class_9331<Address> ADDRESS_TAG_ADDRESS = REGISTRAR.dataComponentType("address_tag_address",
              b -> b.method_57881(Address.CODEC).method_57882(Address.STREAM_CODEC));

        // -- Mail

        public static final class_9331<Address> MAIL_ADDRESS_TAG = REGISTRAR.dataComponentType("mail_address_tag",
              b -> b.method_57881(Address.CODEC).method_57882(Address.STREAM_CODEC));

        public static final class_9331<PaybackRequest> MAIL_PAYBACK_TAG = REGISTRAR.dataComponentType("mail_payback_tag",
              b -> b.method_57881(PaybackRequest.CODEC).method_57882(PaybackRequest.STREAM_CODEC).method_59871());

        public static final class_9331<DeliveryInfo> MAIL_DELIVERY_INFO = REGISTRAR.dataComponentType("mail_delivery_info",
              b -> b.method_57881(DeliveryInfo.CODEC).method_57882(DeliveryInfo.STREAM_CODEC));

        // -- Letter

        public static final class_9331<LetterAndQuillContent> LETTER_AND_QUILL_CONTENT =
              REGISTRAR.dataComponentType("letter_and_quill_content",
                    b -> b.method_57881(LetterAndQuillContent.CODEC).method_57882(LetterAndQuillContent.STREAM_CODEC));
        public static final class_9331<LetterContent> LETTER_CONTENT =
              REGISTRAR.dataComponentType("letter_content",
                    b -> b.method_57881(LetterContent.CODEC).method_57882(LetterContent.STREAM_CODEC).method_59871());
        public static final class_9331<ServiceLetterMeaning> SERVICE_LETTER_MEANING =
              REGISTRAR.dataComponentType("service_letter_meaning",
                    b -> b.method_57881(ServiceLetterMeaning.CODEC).method_57882(ServiceLetterMeaning.STREAM_CODEC));

        // -- Package

        public static final class_9331<PackageContents> PACKAGE_CONTENTS = REGISTRAR.dataComponentType("package_contents",
              b -> b.method_57881(PackageContents.CODEC).method_57882(PackageContents.STREAM_CODEC));
        public static final class_9331<Integer> PACKAGE_EXPERIENCE = REGISTRAR.dataComponentType("package_experience",
              b -> b.method_57881(class_5699.field_33441).method_57882(class_9135.field_49675));

        // -- Seal

        public static final class_9331<Seal> SEAL = REGISTRAR.dataComponentType("seal",
              b -> b.method_57881(Seal.CODEC).method_57882(Seal.STREAM_CODEC).method_59871());
        public static final class_9331<class_9791<SealMaterial>> SEAL_STAMP_MATERIAL = REGISTRAR.dataComponentType("seal_stamp_material",
              b -> b.method_57881(class_9791.method_60736(Registries.SEAL_MATERIAL, SealMaterial.CODEC)).method_57882(class_9791.method_60737(Registries.SEAL_MATERIAL, SealMaterial.STREAM_CODEC)));
        public static final class_9331<class_9791<SealSymbol>> SEAL_STAMP_DIE = REGISTRAR.dataComponentType("seal_stamp_die",
              b -> b.method_57881(class_9791.method_60736(Registries.SEAL_SYMBOL, SealSymbol.CODEC)).method_57882(class_9791.method_60737(Registries.SEAL_SYMBOL, SealSymbol.STREAM_CODEC)));

        // -- Payback

        public static final class_9331<PaybackRequest> PAYBACK_TAG_CONTENTS = REGISTRAR.dataComponentType("payback_tag_contents",
              b -> b.method_57881(PaybackRequest.CODEC).method_57882(PaybackRequest.STREAM_CODEC).method_59871());
        public static final class_9331<PaybackSubject> PAYBACK_SUBJECT = REGISTRAR.dataComponentType("payback_subject",
              b -> b.method_57881(PaybackSubject.CODEC).method_57882(PaybackSubject.STREAM_CODEC).method_59871());

        // -- Misc

        public static final class_9331<class_3902> OPEN = REGISTRAR.dataComponentType("open",
              b -> b.method_57882(class_9139.method_56431(class_3902.field_17274)));
        public static final class_9331<List<Occupant>> PIGEONS = REGISTRAR.dataComponentType("pigeons",
              b -> b.method_57881(Occupant.LIST_CODEC).method_57882(Occupant.STREAM_CODEC.method_56433(class_9135.method_56363())).method_59871());

        static void init() {
        }
    }

    public static class EntityTypes {
        public static final Supplier<class_1299<Pigeon>> PIGEON = REGISTRAR.entityType("pigeon",
              Pigeon::new, class_1311.field_6294, true, builder -> builder
                    .method_17687(0.65F, 0.85F)
                    .method_55687(0.59375F)
                    .method_55689(0.4625F)
                    .method_27299(8));

        public static final Supplier<class_1299<CharredPigeon>> CHARRED_PIGEON = REGISTRAR.entityType("charred_pigeon",
              CharredPigeon::new, class_1311.field_6302, true, builder -> builder
                    .method_17687(0.65F, 0.85F)
                    .method_55687(0.59375F)
                    .method_55689(0.4625F)
                    .method_27299(8));

        public static final Supplier<class_1299<CourierBat>> COURIER_BAT = REGISTRAR.entityType("courier_bat",
              CourierBat::new, class_1311.field_6294, true, builder -> builder
                    .method_17687(0.5F, 0.9F)
                    .method_55687(0.45F)
                    .method_27299(8));

        static void init() {
        }
    }

    public static class EntityDataSerializers {
        public static final Supplier<class_2941<class_6880<PigeonVariant>>> PIGEON_VARIANT =
              REGISTRAR.entityDataSerializer("pigeon_variant", class_2941.method_56031(PigeonVariant.STREAM_CODEC));

        static void init() {
        }
    }

    public static class MenuTypes {
        public static final Supplier<class_3917<MailboxMenu>> MAILBOX =
              REGISTRAR.menuType("mailbox", MailboxMenu::fromNetwork);

        public static final Supplier<class_3917<PackingMenu>> PACKING =
              REGISTRAR.menuType("packing", PackingMenu::fromNetwork);
        public static final Supplier<class_3917<PackageMenu>> PACKAGE =
              REGISTRAR.menuType("package", PackageMenu::fromNetwork);

        public static final Supplier<class_3917<PaybackPackingMenu>> PAYBACK_PACKING =
              REGISTRAR.menuType("payback_packing", PaybackPackingMenu::fromNetwork);
        public static final Supplier<class_3917<PaybackPackageMenu>> PAYBACK_PACKAGE =
              REGISTRAR.menuType("payback_package", PaybackPackageMenu::fromNetwork);

        public static final Supplier<class_3917<PaybackTagMenu>> PAYBACK_TAG =
              REGISTRAR.menuType("payback_tag", PaybackTagMenu::fromNetwork);

        static void init() {
        }
    }

    public static class RecipeTypes {
        public static final Supplier<class_3956<MailRecipe>> MAILING = REGISTRAR.recipeType("mailing",
              () -> new class_3956<>() {
                  @Override
                  public String toString() {
                      return ID + ":mailing";
                  }
              });

        static void init() {
        }
    }

    public static class RecipeSerializers {
        public static final Supplier<class_1865<LetterCloningRecipe>> LETTER_CLONING = REGISTRAR.recipeSerializer(
              "crafting_special_letter_cloning", () -> new class_1866<>(LetterCloningRecipe::new));
        public static final Supplier<class_1865<AddressTagApplicationRecipe>> ADDRESS_TAG_APPLICATION = REGISTRAR.recipeSerializer(
              "crafting_special_address_tag_application", () -> new class_1866<>(AddressTagApplicationRecipe::new));
        public static final Supplier<class_1865<PaybackTagApplicationRecipe>> PAYBACK_TAG_APPLICATION = REGISTRAR.recipeSerializer(
              "crafting_special_payback_tag_application", () -> new class_1866<>(PaybackTagApplicationRecipe::new));
        public static final Supplier<class_1865<SealStampDyeingRecipe>> SEAL_STAMP_DYEING = REGISTRAR.recipeSerializer(
              "crafting_special_seal_stamp_dyeing", () -> new class_1866<>(SealStampDyeingRecipe::new));

        public static final Supplier<class_1865<ComponentTransferringRecipe>> COMPONENT_TRANSFERRING = REGISTRAR.recipeSerializer(
                    "component_transferring", () -> new ComponentTransferringRecipeSerializer<>(ComponentTransferringRecipe::new));

        public static final Supplier<class_1865<MailCraftingRecipe>> MAIL_CRAFTING = REGISTRAR.recipeSerializer(
              "mail_crafting", () -> new MailRecipeSerializer<>(MailCraftingRecipe::new));
        public static final Supplier<class_1865<MailLetterBroadcastingRecipe>> MAIL_LETTER_BROADCASTING = REGISTRAR.recipeSerializer(
              "mail_letter_broadcasting", MailLetterBroadcastingRecipe.Serializer::new);
        public static final Supplier<class_1865<MailPaybackRequestCancelingRecipe>> MAIL_PAYBACK_REQUEST_CANCELING = REGISTRAR.recipeSerializer(
              "mail_payback_request_canceling", MailPaybackRequestCancelingRecipe.Serializer::new);

        static void init() {
        }
    }

    public static class SoundEvents {
        public static final Supplier<class_3414> PIGEONHOLE_ENTER = register("block", "pigeonhole.enter");
        public static final Supplier<class_3414> PIGEONHOLE_EXIT = register("block", "pigeonhole.exit");
        public static final Supplier<class_3414> PIGEONHOLE_WORK = register("block", "pigeonhole.work");
        public static final Supplier<class_3414> PIGEONHOLE_WORK_MULTIPLE = register("block", "pigeonhole.work_multiple");
        public static final Supplier<class_3414> PIGEONHOLE_SCOOP = register("block", "pigeonhole.scoop");

        public static final Supplier<class_3414> MAILBOX_CONNECT = register("block", "mailbox.connect");
        public static final Supplier<class_3414> MAILBOX_OPEN = register("block", "mailbox.open");
        public static final Supplier<class_3414> MAILBOX_HATCH_OPEN = register("block", "mailbox.hatch_open");
        public static final Supplier<class_3414> MAILBOX_HATCH_CLOSE = register("block", "mailbox.hatch_close");
        public static final Supplier<class_3414> MAILBOX_MAIL_RECEIVE = register("block", "mailbox.mail_receive");
        public static final Supplier<class_3414> MAILBOX_UI_MAIL_RECEIVE = register("block", "mailbox.ui.mail_receive");

        public static final Supplier<class_3414> PAPER_PLACE = register("block", "paper.place");
        public static final Supplier<class_3414> PAPER_BREAK = register("block", "paper.break");
        public static final Supplier<class_3414> PAPER_HIT = register("block", "paper.hit");
        public static final Supplier<class_3414> PAPER_FALL = register("block", "paper.fall");
        public static final Supplier<class_3414> PAPER_STEP = register("block", "paper.step");
        public static final Supplier<class_3414> PAPER_USE = register("block", "paper.use");

        public static final Supplier<class_3414> PAPER_TEAR = register("item", "paper.tear");
        public static final Supplier<class_3414> PAPER_CRACKLE = register("item", "paper.crackle");

        public static final Supplier<class_3414> PACKAGE_PACK = register("item", "package.pack");
        public static final Supplier<class_3414> TAG_APPLY = register("item", "tag.apply");
        public static final Supplier<class_3414> SEAL_STAMP_APPLY = register("item", "seal_stamp.apply");
        public static final Supplier<class_3414> SOULBOUND_SEAL_STAMP_LOCK = register("item", "soulbound_seal_stamp.lock");
        public static final Supplier<class_3414> SOULBOUND_SEAL_STAMP_UNLOCK = register("item", "soulbound_seal_stamp.unlock");

        public static final Supplier<class_3414> COURIER_MAIL_PICKUP = register("entity", "courier.mail_pickup");
        public static final Supplier<class_3414> COURIER_APPEARED = register("entity", "courier.appeared");
        public static final Supplier<class_3414> COURIER_DISAPPEARED = register("entity", "courier.disappeared");
        public static final Supplier<class_3414> COURIER_EVADE = register("entity", "courier.evade");

        public static final Supplier<class_3414> PIGEON_AMBIENT = register("entity", "pigeon.ambient");
        public static final Supplier<class_3414> PIGEON_DEATH = register("entity", "pigeon.death");
        public static final Supplier<class_3414> PIGEON_EAT = register("entity", "pigeon.eat");
        public static final Supplier<class_3414> PIGEON_FLY = register("entity", "pigeon.fly");
        public static final Supplier<class_3414> PIGEON_HURT = register("entity", "pigeon.hurt");
        public static final Supplier<class_3414> PIGEON_STEP = register("entity", "pigeon.step");

        public static final Supplier<class_3414> CHARRED_PIGEON_AMBIENT = register("entity", "charred_pigeon.ambient");
        public static final Supplier<class_3414> CHARRED_PIGEON_DEATH = register("entity", "charred_pigeon.death");
        public static final Supplier<class_3414> CHARRED_PIGEON_FLY = register("entity", "charred_pigeon.fly");
        public static final Supplier<class_3414> CHARRED_PIGEON_HURT = register("entity", "charred_pigeon.hurt");
        public static final Supplier<class_3414> CHARRED_PIGEON_STEP = register("entity", "charred_pigeon.step");

        public static final Supplier<class_3414> VILLAGER_THROW_PIGEON_FOOD = register("entity", "villager.throw_pigeon_food");

        public static final Supplier<class_3414> IGNITE = register("generic", "ignite");

        public static final Supplier<class_3414> UI_WRITE = register("ui", "write");
        public static final Supplier<class_3414> UI_ACTION_BLOCKED = register("ui", "action_blocked");
        public static final Supplier<class_3414> UI_ERROR = register("ui", "error");

        private static Supplier<class_3414> register(String category, String key) {
            Preconditions.checkState(category != null && !category.isEmpty(), "'category' should not be empty.");
            Preconditions.checkState(key != null && !key.isEmpty(), "'key' should not be empty.");
            String path = category + "." + key;
            return REGISTRAR.soundEvent(path, () -> class_3414.method_47908(Envelope.resource(path)));
        }

        static void init() {
        }
    }

    public static class SoundTypes {
        public static final class_2498 PAPER = new DeferredSoundType(1, 1,
              SoundEvents.PAPER_BREAK,
              SoundEvents.PAPER_STEP,
              SoundEvents.PAPER_PLACE,
              SoundEvents.PAPER_HIT,
              SoundEvents.PAPER_FALL);
    }

    public static class Stats {
        public static final Supplier<class_2960> INTERACT_WITH_MAILBOX =
              REGISTRAR.stat(resource("interact_with_mailbox"), class_3446.field_16975);
        public static final Supplier<class_2960> MAIL_DELIVERIES =
              REGISTRAR.stat(resource("mail_deliveries"), class_3446.field_16975);
        public static final Supplier<class_2960> SEALS_APPLIED =
              REGISTRAR.stat(resource("seals_applied"), class_3446.field_16975);
        public static final Supplier<class_2960> SEALS_BROKEN =
              REGISTRAR.stat(resource("seals_broken"), class_3446.field_16975);
        public static final Supplier<class_2960> LETTERS_FOLDED =
              REGISTRAR.stat(resource("letters_folded"), class_3446.field_16975);
        public static final Supplier<class_2960> PACKAGES_CREATED =
              REGISTRAR.stat(resource("packages_created"), class_3446.field_16975);
        public static final Supplier<class_2960> PACKAGES_OPENED =
              REGISTRAR.stat(resource("packages_opened"), class_3446.field_16975);

        public static void init() {
        }
    }

    public static class CriteriaTriggers {
        public static Supplier<MailDeliveredTrigger> MAIL_DELIVERED = REGISTRAR.criterionTrigger("mail_delivered", MailDeliveredTrigger::new);
        public static Supplier<BreakPaperBoxWhenFallingTrigger> BREAK_PAPER_BOX_WHEN_FALLING_TRIGGER = REGISTRAR.criterionTrigger("break_paper_box_when_falling", BreakPaperBoxWhenFallingTrigger::new);
        public static Supplier<class_2135> DELIVER_WITH_PIGEON_AND_BAT = REGISTRAR.criterionTrigger("deliver_with_pigeon_and_bat", class_2135::new);
        public static Supplier<class_2135> SMOKE_PIGEONHOLE = REGISTRAR.criterionTrigger("smoke_pigeonhole", class_2135::new);
        public static Supplier<class_2135> SCOOP_DIAMOND = REGISTRAR.criterionTrigger("scoop_diamond", class_2135::new);
        public static Supplier<class_2135> SPAWN_ARCHIMEDES = REGISTRAR.criterionTrigger("spawn_archimedes", class_2135::new);

        public static void init() {
        }
    }

    public static class ItemSubPredicates {
        public static Supplier<class_9360.class_8745<ItemPackagePredicate>> PACKAGE_CONTENTS = REGISTRAR.itemSubPredicate("package_contents",
              () -> new class_9360.class_8745<>(ItemPackagePredicate.field_49805));
        public static Supplier<class_9360.class_8745<ItemOccludingBlockPredicate>> OCCLUDING_BLOCK = REGISTRAR.itemSubPredicate("occluding_block",
              () -> new class_9360.class_8745<>(ItemOccludingBlockPredicate.field_49805));

        public static void init() {
        }
    }

    public static class LootTables {
        public static final class_5321<class_52> PIGEONHOLE_WASTE =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("gameplay/pigeonhole_waste"));
        public static final class_5321<class_52> CHARRED_PIGEON_MAIL =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("gameplay/charred_pigeon_mail"));

        public static final class_5321<class_52> LOST_MAIL =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("packages/lost_mail"));
        public static final class_5321<class_52> LOST_MAIL_JUNK =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("packages/lost_mail/junk"));
        public static final class_5321<class_52> LOST_MAIL_PLANTS =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("packages/lost_mail/plants"));
        public static final class_5321<class_52> LOST_MAIL_BLOCKS =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("packages/lost_mail/blocks"));
        public static final class_5321<class_52> LOST_MAIL_METALS =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("packages/lost_mail/metals"));
        public static final class_5321<class_52> LOST_MAIL_TOOLS =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("packages/lost_mail/tools"));
        public static final class_5321<class_52> LOST_MAIL_WEAPONS =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("packages/lost_mail/weapons"));
        public static final class_5321<class_52> LOST_MAIL_VALUABLES =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("packages/lost_mail/valuables"));

        public static final class_5321<class_52> NETHER_LOST_MAIL =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("packages/nether_lost_mail"));

        public static final class_5321<class_52> COLLAPSED_MAIL_HUB_STORAGE =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("chests/collapsed_mail_hub/storage"));
        public static final class_5321<class_52> COLLAPSED_MAIL_HUB_STORAGE_MAIL =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("chests/collapsed_mail_hub/storage_mail"));
        public static final class_5321<class_52> COLLAPSED_MAIL_HUB_STORAGE_MATERIALS =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("chests/collapsed_mail_hub/storage_materials"));
        public static final class_5321<class_52> COLLAPSED_MAIL_HUB_STORAGE_STAMPS =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("chests/collapsed_mail_hub/storage_stamps"));
        public static final class_5321<class_52> COLLAPSED_MAIL_HUB_MANUFACTORY =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("chests/collapsed_mail_hub/manufactory"));
        public static final class_5321<class_52> COLLAPSED_MAIL_HUB_DISPATCHERY =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("chests/collapsed_mail_hub/dispatchery"));
        public static final class_5321<class_52> COLLAPSED_MAIL_HUB_CONSTRUCTION =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("chests/collapsed_mail_hub/construction"));
        public static final class_5321<class_52> COLLAPSED_MAIL_HUB_DOCK_NOTE =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("letters/collapsed_mail_hub/dock_note"));

        public static final class_5321<class_52> ABANDONED_MINESHAFT_INJECT =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("chests/abandoned_mineshaft_inject"));
        public static final class_5321<class_52> PILLAGER_OUTPOST_INJECT =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("chests/pillager_outpost_inject"));
        public static final class_5321<class_52> RUINED_PORTAL_INJECT =
              class_5321.method_29179(net.minecraft.class_7924.field_50079, Envelope.resource("chests/ruined_portal_inject"));
    }

    public static class Tags {
        public static class Blocks {
            public static final class_6862<class_2248> PIGEONS_SPAWNABLE_ON =
                  class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("pigeons_spawnable_on"));
            public static final class_6862<class_2248> PIGEONS_PERCHABLE_ON =
                  class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("pigeons_perchable_on"));
            public static final class_6862<class_2248> PIGEONHOLES =
                  class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("pigeonholes"));
            public static final class_6862<class_2248> PIGEONHOLES_THAT_BURN =
                  class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("pigeonholes_that_burn"));
            public static final class_6862<class_2248> BURNING =
                  class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("burning"));
            public static final class_6862<class_2248> DOVECOTE_PLAINS_REPLACEABLE =
                  class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("dovecote_plains_replaceable"));
            public static final class_6862<class_2248> DOVECOTE_SAVANNA_REPLACEABLE =
                  class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("dovecote_savanna_replaceable"));
            public static final class_6862<class_2248> DOVECOTE_TAIGA_REPLACEABLE =
                  class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("dovecote_taiga_replaceable"));
        }

        public static class Items {
            public static final class_6862<class_1792> PIGEON_FOOD =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("pigeon_food"));
            public static final class_6862<class_1792> BAT_FOOD =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("bat_food"));
            public static final class_6862<class_1792> COURIER_FOOD =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("courier_food"));

            public static final class_6862<class_1792> VILLAGER_FEEDING_PIGEON_FOOD_COMMON =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("villager_feeding_pigeon_food_common"));
            public static final class_6862<class_1792> VILLAGER_FEEDING_PIGEON_FOOD_UNCOMMON =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("villager_feeding_pigeon_food_uncommon"));
            public static final class_6862<class_1792> VILLAGER_FEEDING_PIGEON_FOOD_RARE =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("villager_feeding_pigeon_food_rare"));

            public static final class_6862<class_1792> PIGEONHOLES =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("pigeonholes"));
            public static final class_6862<class_1792> WASTE_SCOOPABLE =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("waste_scoopable"));

            public static final class_6862<class_1792> LETTERS =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("letters"));
            public static final class_6862<class_1792> PACKAGES =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("packages"));
            public static final class_6862<class_1792> SEAL_STAMPS =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("seal_stamps"));
            public static final class_6862<class_1792> REGULAR_SEAL_STAMPS =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("regular_seal_stamps"));
            public static final class_6862<class_1792> MAILABLE =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("mailable"));
            public static final class_6862<class_1792> CANNOT_BE_PACKAGED =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("cannot_be_packaged"));
            public static final class_6862<class_1792> CANNOT_BE_USED_AS_PAYBACK =
                  class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("cannot_be_used_as_payback"));
        }

        public static class EntityTypes {
            public static final class_6862<class_1299<?>> PIGEONHOLE_INHABITORS =
                  class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("pigeonhole_inhabitors"));
            public static final class_6862<class_1299<?>> SPAWNS_ARCHIMEDES =
                  class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("spawns_archimedes"));
        }

        public static class DamageTypes {
            public static final class_6862<class_8110> BYPASSES_COURIER_DELIVERY_EVASION =
                  class_6862.method_40092(net.minecraft.class_7924.field_42534, resource("bypasses_courier_delivery_evasion"));
            public static final class_6862<class_8110> SPAWNS_ARCHIMEDES =
                  class_6862.method_40092(net.minecraft.class_7924.field_42534, resource("spawns_archimedes"));
        }

        public static class Biomes {
            public static final class_6862<class_1959> ALLOWS_PIGEON_SPAWNS =
                  class_6862.method_40092(net.minecraft.class_7924.field_41236, resource("allows_pigeon_spawns"));
            public static final class_6862<class_1959> ALLOWS_CHARRED_PIGEON_SPAWNS =
                  class_6862.method_40092(net.minecraft.class_7924.field_41236, resource("allows_charred_pigeon_spawns"));

            public static final class_6862<class_1959> SPAWNS_PASSENGER_PIGEONS =
                  class_6862.method_40092(net.minecraft.class_7924.field_41236, resource("spawns_passenger_pigeons"));
        }

        public static class Structures {
            public static final class_6862<class_3195> DOVECOTE =
                  class_6862.method_40092(net.minecraft.class_7924.field_41246, resource("dovecote"));
            public static final class_6862<class_3195> PIGEONS_SPAWN_IN =
                  class_6862.method_40092(net.minecraft.class_7924.field_41246, resource("pigeons_spawn_in"));
            public static final class_6862<class_3195> ON_COLLAPSED_MAIL_HUB_EXPLORER_MAPS =
                  class_6862.method_40092(net.minecraft.class_7924.field_41246, resource("on_collapsed_mail_hub_explorer_maps"));
        }

        public static class SealImpressions {
            public static final class_6862<SealSymbol> SPECIAL =
                  class_6862.method_40092(Registries.SEAL_SYMBOL, resource("special"));
            public static final class_6862<SealSymbol> TOOLS =
                  class_6862.method_40092(Registries.SEAL_SYMBOL, resource("tools"));
        }

        public static class ServiceAddresses {
            public static final class_6862<ServiceAddressDefinition> HIDDEN =
                  class_6862.method_40092(Registries.SERVICE_ADDRESS_DEFINITION, resource("hidden"));
        }
    }

    public static class ArgumentTypes {
        public static final Supplier<class_2314<AddressArgument, class_2319<AddressArgument>.class_7219>> ADDRESS =
              REGISTRAR.commandArgumentType("address", AddressArgument.class, class_2319.method_41999(AddressArgument::all));
        public static final Supplier<class_2314<SealLockArgument, class_2319<SealLockArgument>.class_7219>> SEAL_LOCK =
              REGISTRAR.commandArgumentType("seal_lock", SealLockArgument.class, class_2319.method_41999(SealLockArgument::new));

        public static void init() {
        }
    }

    public static class Registries {
        public static final class_5321<class_2378<PigeonVariant>> PIGEON_VARIANT =
              class_5321.method_29180(resource("pigeon_variant"));

        public static final class_5321<class_2378<ServiceAddressDefinition>> SERVICE_ADDRESS_DEFINITION =
              class_5321.method_29180(resource("service_address"));

        public static final class_5321<class_2378<SealMaterial>> SEAL_MATERIAL =
              class_5321.method_29180(resource("seal_material"));
        public static final class_5321<class_2378<SealSymbol>> SEAL_SYMBOL =
              class_5321.method_29180(resource("seal_symbol"));
    }

    public static class BuggerData {
        public static final MailServiceBuggerData MAIL_SERVICE = new MailServiceBuggerData();

        public static final EntityData<PigeonholeHandler> PIGEON_PIGEONHOLE_HANDLER =
              new EntityData<>(resource("pigeon_pigeonhole_handler"), PigeonholeHandler.CODEC)
                    .handle(((entity, handler) -> {
                        if (entity instanceof Pigeon pigeon) {
                            pigeon.setPigeonholeHandler(handler);
                        }
                    }));

        public static final EntityData<MailboxHandler> COURIER_MAILBOX_HANDLER =
              new EntityData<>(resource("courier_mailbox_handler"), MailboxHandler.CODEC)
                    .handle(((entity, handler) -> {
                        if (entity instanceof PhysicalCourier courier) {
                            courier.setMailboxHandler(handler);
                        }
                    }));

        public static final OptionalEntityData<Delivery> COURIER_DELIVERY =
              new OptionalEntityData<>(resource("courier_delivery"), Delivery.CODEC)
                    .handle((entity, delivery) -> {
                        if (entity instanceof PhysicalCourier courier) {
                            courier.setDelivery(delivery.orElse(null));
                        }
                    });

        public static void init() {
        }
    }
}
