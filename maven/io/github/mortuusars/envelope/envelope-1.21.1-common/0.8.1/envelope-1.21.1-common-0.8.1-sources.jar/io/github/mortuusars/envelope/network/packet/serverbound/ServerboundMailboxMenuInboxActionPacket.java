package io.github.mortuusars.envelope.network.packet.serverbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.mortaar.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.envelope.world.inventory.MailboxMenu;
import org.jetbrains.annotations.NotNull;

public record ServerboundMailboxMenuInboxActionPacket(int index, MailboxMenu.MailAction action) implements Packet {
    public static final class_2960 ID = Envelope.resource("mailbox_menu_inbox_action");
    public static final class_8710.class_9154<ServerboundMailboxMenuInboxActionPacket> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, ServerboundMailboxMenuInboxActionPacket> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48550, ServerboundMailboxMenuInboxActionPacket::index,
            MailboxMenu.MailAction.STREAM_CODEC, ServerboundMailboxMenuInboxActionPacket::action,
            ServerboundMailboxMenuInboxActionPacket::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (!(player.field_7512 instanceof MailboxMenu menu)) {
            Envelope.LOGGER.error("Cannot handle '{}' packet: Player '{}' does not have MailboxMenu open.", ID, player);
            return false;
        }

        menu.doMailAction(player, index, action);

        return true;
    }
}
