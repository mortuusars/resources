package io.github.mortuusars.envelope.network.packet.clientbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import io.github.mortuusars.envelope.network.handler.ClientboundPacketsHandler;
import io.github.mortuusars.mortaar.network.packet.Packet;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record ClientboundOpenAddressTagScreenPacket(class_1268 hand, AllAddresses knownAddresses) implements Packet {
    public static final class_2960 ID = Envelope.resource("open_address_tag_screen");
    public static final class_9154<ClientboundOpenAddressTagScreenPacket> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, ClientboundOpenAddressTagScreenPacket> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48550.method_56432(i -> class_1268.values()[i], class_1268::ordinal), ClientboundOpenAddressTagScreenPacket::hand,
            AllAddresses.STREAM_CODEC, ClientboundOpenAddressTagScreenPacket::knownAddresses,
            ClientboundOpenAddressTagScreenPacket::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        ClientboundPacketsHandler.openAddressTagScreen(this);
        return true;
    }
}
