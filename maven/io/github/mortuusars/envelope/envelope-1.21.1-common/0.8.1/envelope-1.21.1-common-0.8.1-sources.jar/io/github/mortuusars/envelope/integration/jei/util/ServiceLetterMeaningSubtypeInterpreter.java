package io.github.mortuusars.envelope.integration.jei.util;

import io.github.mortuusars.envelope.Envelope;
import mezz.jei.api.ingredients.subtypes.ISubtypeInterpreter;
import mezz.jei.api.ingredients.subtypes.UidContext;
import net.minecraft.class_1799;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ServiceLetterMeaningSubtypeInterpreter implements ISubtypeInterpreter<class_1799> {
    @Override
    public @Nullable Object getSubtypeData(class_1799 ingredient, UidContext context) {
        return ingredient.method_57824(Envelope.DataComponents.SERVICE_LETTER_MEANING);
    }

    @Override
    public @NotNull String getLegacyStringSubtypeInfo(class_1799 ingredient, UidContext context) {
        return "";
    }
}
