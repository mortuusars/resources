package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.ServiceLetterMeaning;
import org.jetbrains.annotations.NotNull;

import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;

public class SealedServiceLetterItem extends SealedLetterItem {
    public SealedServiceLetterItem(Supplier<? extends class_1792> baseItem, class_1793 properties) {
        super(baseItem, properties);
    }

    @Override
    public @NotNull class_2561 method_7864(class_1799 stack) {
        if (stack.method_57824(Envelope.DataComponents.SERVICE_LETTER_MEANING) instanceof ServiceLetterMeaning meaning) {
            return class_2561.method_43469("item.envelope.sealed_service_letter.name", meaning.translate());
        }
        return super.method_7864(stack);
    }
}
