package io.github.mortuusars.envelope.integration.jei.category;

import com.mojang.logging.LogUtils;
import mezz.jei.api.gui.builder.ITooltipBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.widgets.IRecipeWidget;
import mezz.jei.common.util.ImmutableRect2i;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_5244;
import net.minecraft.class_8029;
import org.jetbrains.annotations.NotNull;

public class MailingRecipeInfoWidget implements IRecipeWidget {
    private final IDrawable icon;
    private final class_2561 tooltip;
    private final class_2561 info;
    private final ImmutableRect2i area;

    public MailingRecipeInfoWidget(IDrawable icon, int x, int y, class_2561 info) {
        this.icon = icon;
        this.tooltip = class_2561.method_43471("envelope.jei.info")
              .method_10852(class_5244.field_33849)
              .method_10852(info.method_27661().method_27692(class_124.field_1080));
        this.info = info;
        this.area = new ImmutableRect2i(x, y, icon.getWidth(), icon.getHeight());
    }

    @Override
    public @NotNull class_8029 getPosition() {
        return area.getScreenPosition();
    }

    @SuppressWarnings("removal")
    @Override
    public void draw(class_332 guiGraphics, double mouseX, double mouseY) {
        icon.draw(guiGraphics, 0, 0);
    }

    @Override
    public void getTooltip(ITooltipBuilder tooltip, double mouseX, double mouseY) {
        if (isMouseOver(mouseX, mouseY)) {
            tooltip.add(class_2561.method_43471("envelope.jei.info"));
            tooltip.add(this.info.method_27661().method_27692(class_124.field_1080));
        }
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        return area.contains(mouseX + area.getX(), mouseY + area.getY());
    }
}
