package io.github.mortuusars.envelope.client.renderer.entity;

import io.github.mortuusars.envelope.client.model.CourierBatModel;
import io.github.mortuusars.envelope.client.renderer.entity.layer.BatBackpackLayer;
import io.github.mortuusars.envelope.world.entity.CourierBat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_927;
import org.jetbrains.annotations.NotNull;

@Environment(EnvType.CLIENT)
public class CourierBatRenderer extends class_927<CourierBat, CourierBatModel> {
    private static final class_2960 BAT_LOCATION = class_2960.method_60656("textures/entity/bat.png");

    public CourierBatRenderer(class_5617.class_5618 context) {
        super(context, new CourierBatModel(context.method_32167(class_5602.field_27679)), 0.25F);
        method_4046(new BatBackpackLayer(this, context.method_32167(BatBackpackLayer.MODEL_LAYER)));
    }

    @Override
    public @NotNull class_2960 getTextureLocation(CourierBat entity) {
        return BAT_LOCATION;
    }
}
