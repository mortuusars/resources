package io.github.mortuusars.envelope.network.packet.serverbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.mortaar.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record ServerboundItemClosedPacket(int slot) implements Packet {
    public static final class_2960 ID = Envelope.resource("item_closed");
    public static final class_9154<ServerboundItemClosedPacket> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, ServerboundItemClosedPacket> STREAM_CODEC = class_9139.method_56434(
          class_9135.field_48550, ServerboundItemClosedPacket::slot,
          ServerboundItemClosedPacket::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (slot != -1 && player.method_31548().method_5438(slot).method_57381(Envelope.DataComponents.OPEN) != null) {
            player.method_7350();
        }
        return true;
    }
}
