package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.block.PigeonholeBlock;
import io.github.mortuusars.envelope.world.inventory.PaybackTagMenu;
import io.github.mortuusars.envelope.world.item.component.PaybackRequest;
import io.github.mortuusars.mortaar.Platform;
import io.github.mortuusars.mortaar.world.item.ApplicatorItem;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_5536;
import net.minecraft.class_5632;
import net.minecraft.class_747;
import net.minecraft.world.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;

public class PaybackTagItem extends class_1792 implements ApplicatorItem {
    public PaybackTagItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public @NotNull Optional<class_5632> method_32346(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS));
    }

    @Override
    public boolean canBeAppliedTo(class_1657 player, class_1703 menu, class_1735 slot, class_1799 carried) {
        if (!slot.method_32754(player)) {
            return false;
        }

        if (slot.method_7677().method_31573(Envelope.Tags.Items.MAILABLE)) {
            return !Objects.equals(
                  carried.method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS),
                  slot.method_7677().method_57824(Envelope.DataComponents.MAIL_PAYBACK_TAG));
        }

        if (slot.method_7677().method_31574(Envelope.Items.PAYBACK_TAG.get())) {
            return !Objects.equals(
                  carried.method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS),
                  slot.method_7677().method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS));
        }

        return false;
    }

    @Override
    public boolean method_31565(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player) {
        if (action != class_5536.field_27014) return false;
        if (!slot.method_32754(player)) return false;
        class_1799 target = slot.method_7677();

        @Nullable PaybackRequest request = stack.method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS);

        if (target.method_31573(Envelope.Tags.Items.MAILABLE)) {
            @Nullable PaybackRequest existingTag = target.method_57824(Envelope.DataComponents.MAIL_PAYBACK_TAG);
            if (request != null) {
                if (stack.method_7947() < target.method_7947()) {
                    player.method_5783(Envelope.SoundEvents.UI_ACTION_BLOCKED.get(), 1, 1);
                    return true;
                }

                if (request.equals(existingTag)) {
                    player.method_5783(Envelope.SoundEvents.UI_ACTION_BLOCKED.get(), 1, 1);
                    return true;
                }
                target.method_57379(Envelope.DataComponents.MAIL_PAYBACK_TAG, request);
            } else {
                if (existingTag == null) {
                    player.method_5783(Envelope.SoundEvents.UI_ACTION_BLOCKED.get(), 1, 1);
                    return true;
                }
                target.method_57381(Envelope.DataComponents.MAIL_PAYBACK_TAG);
            }

            slot.method_7668();
            if (request != null && !player.method_7337()) {
                stack.method_7934(target.method_7947());
            }
            player.method_5783(class_3417.field_14883.comp_349(), 1, 1);
            return true;
        }

        // Copy request from carried item to target, but only if requests are different (to not block usual stack splitting behavior)
        if (target.method_31574(Envelope.Items.PAYBACK_TAG.get())
              && !Objects.equals(request, target.method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS))) {
            target.method_57379(Envelope.DataComponents.PAYBACK_TAG_CONTENTS, request);
            player.method_5783(Envelope.SoundEvents.UI_WRITE.get(), 1, 1);
            return true;
        }

        return false;
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (player.method_21823()) {
            @Nullable PaybackRequest removedRequest = player.method_5998(hand).method_57381(Envelope.DataComponents.PAYBACK_TAG_CONTENTS);
            if (removedRequest != null) {
                player.method_5783(Envelope.SoundEvents.UI_WRITE.get(), 0.35f, 1);
                return class_1271.method_29237(player.method_5998(hand), level.method_8608());
            }
        }

        if (player instanceof class_3222 serverPlayer) {
            Platform.openMenu(
                  serverPlayer,
                  new class_747((id, inventory, pl) ->
                        new PaybackTagMenu(id, inventory, hand), class_2561.method_43471("container.envelope.payback_tag")),
                  buffer -> buffer.method_10817(hand));
            player.method_7357().method_7906(this, 5);
        }

        return class_1271.method_29237(player.method_5998(hand), level.method_8608());
    }
}