package io.github.mortuusars.envelope.world.item.component.seal;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.item.component.SealLock;
import io.github.mortuusars.mortaar.resources.Resource;
import io.github.mortuusars.mortaar.util.GameTimeId;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_4844;
import net.minecraft.class_5244;
import net.minecraft.class_5321;
import net.minecraft.class_5632;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record Seal(class_6880<SealMaterial> material, class_6880<SealSymbol> impression, class_2561 signature,
                   Optional<UUID> playerUuid, Optional<SealLock> lock) implements class_5632 {
    public static final Codec<Seal> CODEC = RecordCodecBuilder.create(i -> i.group(
          SealMaterial.CODEC.fieldOf("material").forGetter(Seal::material),
          SealSymbol.CODEC.fieldOf("impression").forGetter(Seal::impression),
          class_8824.field_46597.optionalFieldOf("signature", class_5244.field_39003).forGetter(Seal::signature),
          class_4844.field_46588.optionalFieldOf("player_id").forGetter(Seal::playerUuid),
          SealLock.CODEC.optionalFieldOf("lock").forGetter(Seal::lock)
    ).apply(i, Seal::new));

    public static final class_9139<class_9129, Seal> STREAM_CODEC = class_9139.method_56906(
          SealMaterial.STREAM_CODEC, Seal::material,
          SealSymbol.STREAM_CODEC, Seal::impression,
          class_8824.field_48540, Seal::signature,
          class_9135.method_56382(class_4844.field_48453), Seal::playerUuid,
          class_9135.method_56382(SealLock.STREAM_CODEC), Seal::lock,
          Seal::new
    );

    public String getSignatureAsId() {
        return signature.getString();
    }

    // --

    public static Builder create(class_7225.class_7874 registries) {
        return new Builder(registries);
    }

    public static Builder copy(Seal seal,class_7225.class_7874 registries) {
        return new Builder(registries)
              .material(seal.material())
              .impression(seal.impression())
              .signature(seal.signature())
              .playerUuid(seal.playerUuid().orElse(null))
              .setLock(seal.lock().orElse(null));
    }

    public static class Builder {
        protected @Nullable class_6880<SealMaterial> material;
        protected @Nullable class_6880<SealSymbol> impression;
        protected @Nullable class_2561 signature;
        protected @Nullable UUID playerUuid;
        protected @Nullable SealLock lock;

        protected class_7225.class_7874 registries;

        public Builder(class_7225.class_7874 registries) {
            this.registries = registries;
        }

        public Builder material(@Nullable class_6880<SealMaterial> material) {
            this.material = material;
            return this;
        }

        public Builder material(@Nullable class_5321<SealMaterial> material) {
            this.material = material != null ? Resource.getOrThrow(material, registries) : null;
            return this;
        }

        public Builder impression(@Nullable class_6880<SealSymbol> impression) {
            this.impression = impression;
            return this;
        }

        public Builder impression(@Nullable class_5321<SealSymbol> impression) {
            this.impression = impression != null ? Resource.getOrThrow(impression, registries) : null;
            return this;
        }

        public Builder signature(@Nullable class_2561 signature) {
            this.signature = signature;
            return this;
        }

        public Builder playerUuid(@Nullable UUID playerUuid) {
            this.playerUuid = playerUuid;
            return this;
        }

        public Builder owner(class_1657 player) {
            this.signature = class_2561.method_43470(player.method_5820());
            this.playerUuid = player.method_5667();
            return this;
        }

        public Builder setLock(@Nullable SealLock lock) {
            this.lock = lock;
            return this;
        }

        public Builder lockedBy(class_1657 player) {
            this.lock = new SealLock(player.method_5820(), GameTimeId.create(player.method_37908()));
            return this;
        }

        public Seal build() {
            return new Seal(
                  Objects.requireNonNullElseGet(material, () -> Resource.getOrThrow(SealMaterial.WAX, registries)),
                  Objects.requireNonNullElseGet(impression, () -> Resource.getOrThrow(SealSymbol.DEFAULT, registries)),
                  Objects.requireNonNullElse(signature, class_5244.field_39003),
                  Optional.ofNullable(playerUuid),
                  Optional.ofNullable(lock)
            );
        }
    }
}