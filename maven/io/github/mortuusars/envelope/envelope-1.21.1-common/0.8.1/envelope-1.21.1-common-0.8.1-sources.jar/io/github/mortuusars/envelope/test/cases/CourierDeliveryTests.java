package io.github.mortuusars.envelope.test.cases;

import com.mojang.serialization.DataResult;
import io.github.mortuusars.envelope.world.mail.delivery.*;
import io.github.mortuusars.envelope.world.item.component.Id;
import io.github.mortuusars.envelope.world.mail.address.type.CustomAddress;
import io.github.mortuusars.mortaar.bugger.test.BuggerTests;
import io.github.mortuusars.mortaar.bugger.test.Test;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public class CourierDeliveryTests extends BuggerTests {
    public CourierDeliveryTests() {
        add(new Test("TickDelivery_CallsCallbacksProperly", this::testCallbacks));
    }

    private DataResult<Boolean> testCallbacks(class_3222 player) {
        MinecraftServer server = player.method_5682();
        assert server != null;

        Delivery delivery = new Delivery(
              Id.createUnsafe(0),
              Optional.empty(),
              new CustomAddress(class_2561.method_43470("test sender")),
              new CustomAddress(class_2561.method_43470("test recipient")),
              class_1799.field_8037,
              DeliveryRoute.EMPTY,
              DeliveryPhase.STARTED,
              0,
              false
        );
        TestCourier courier = new TestCourier(delivery);

        while (!delivery.isEnded()) {
            courier.tickDelivery(server.method_30002(), delivery);
        }

        for (Map.Entry<DeliveryPhase, BitSet> check : courier.checks.entrySet()) {
            BitSet set = check.getValue();
            if (!set.get(0)) return DataResult.error(() -> check.getKey() + " - not called phaseStarted");
            if (!set.get(1)) return DataResult.error(() -> check.getKey() + " - not called phaseTicked");
            if (!set.get(2)) return DataResult.error(() -> check.getKey() + " - not called phaseCompleted");
        }

        if (!courier.endedCorrectly) {
            return DataResult.error(() -> "endDelivery was not called properly.");
        }

        return DataResult.success(true);
    }

    private static class TestCourier implements Courier {
        public final Map<DeliveryPhase, BitSet> checks = class_156.method_654(new HashMap<>(), map -> {
            for (DeliveryPhase phase : DeliveryPhase.values()) {
                map.put(phase, new BitSet());
            }
        });
        public boolean endedCorrectly;
        public Delivery delivery;

        public TestCourier(Delivery delivery) {
            this.delivery = delivery;
        }

        @Override
        public CourierProperties getCourierProperties() {
            return CourierProperties.DEFAULT;
        }

        @Override
        public @NotNull CourierOrigin getCourierOrigin() {
            return CourierOrigin.service();
        }

        @Override
        public Optional<Delivery> getCurrentDelivery() {
            return Optional.of(delivery);
        }

        @Override
        public boolean handlePhaseTransition(class_3218 level, Delivery delivery) {
            // Skip any logic and just transition linearly
            delivery.beginPhase(delivery.getPhase().next());
            return true;
        }

        @Override
        public int getPhaseDuration(class_3218 level, Delivery delivery, DeliveryPhase phase) {
            return Courier.super.getPhaseDuration(level, delivery, phase) - 1;
        }

        @Override
        public void phaseStarted(class_3218 level, Delivery delivery) {
            checks.get(delivery.getPhase()).set(0);
        }

        @Override
        public void phaseTicked(class_3218 level, Delivery delivery) {
            checks.get(delivery.getPhase()).set(1);
        }

        @Override
        public void phaseCompleted(class_3218 level, Delivery delivery) {
            checks.get(delivery.getPhase()).set(2);
        }

        @Override
        public void endDelivery(class_3218 level, Delivery delivery) {
            if (delivery.getPhase() == DeliveryPhase.FINISHED) {
                endedCorrectly = true;
            }
        }
    }
}
