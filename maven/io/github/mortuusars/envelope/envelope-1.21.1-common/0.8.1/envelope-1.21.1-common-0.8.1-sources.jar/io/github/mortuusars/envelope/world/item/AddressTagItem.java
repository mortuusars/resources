package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlock;
import io.github.mortuusars.envelope.world.item.component.PaybackRequest;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import io.github.mortuusars.envelope.network.packet.clientbound.ClientboundOpenAddressTagScreenPacket;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.mortaar.world.item.ApplicatorItem;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_5536;

public class AddressTagItem extends class_1792 implements ApplicatorItem {
    public AddressTagItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        @Nullable Address address = stack.method_57824(Envelope.DataComponents.ADDRESS_TAG_ADDRESS);
        if (address != null) {
            tooltipComponents.add(address.format()
                  .withIcon()
                  .withIconColor(Colors.ADDRESS_NEUTRAL)
                  .withColor(Colors.ADDRESS_NEUTRAL)
                  .toComponent());
        }
    }

    @Override
    public boolean canBeAppliedTo(class_1657 player, class_1703 menu, class_1735 slot, class_1799 carried) {
        if (!slot.method_32754(player)) {
            return false;
        }

        if (slot.method_7677().method_31573(Envelope.Tags.Items.MAILABLE)) {
            return !Objects.equals(
                  carried.method_57824(Envelope.DataComponents.ADDRESS_TAG_ADDRESS),
                  slot.method_7677().method_57824(Envelope.DataComponents.MAIL_ADDRESS_TAG));
        }

        if (slot.method_7677().method_31574(Envelope.Items.ADDRESS_TAG.get())) {
            return !Objects.equals(
                  carried.method_57824(Envelope.DataComponents.ADDRESS_TAG_ADDRESS),
                  slot.method_7677().method_57824(Envelope.DataComponents.ADDRESS_TAG_ADDRESS));
        }

        return false;
    }

    @Override
    public boolean method_31565(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player) {
        class_1799 target = slot.method_7677();

        if (action != class_5536.field_27014 || !slot.method_32754(player)) {
            return false;
        }

        @Nullable Address address = stack.method_57824(Envelope.DataComponents.ADDRESS_TAG_ADDRESS);

        if (target.method_31573(Envelope.Tags.Items.MAILABLE)) {
            @Nullable Address recipient = Mail.getRecipient(target).orElse(null);
            if (Objects.equals(address, recipient)) {
                player.method_5783(Envelope.SoundEvents.UI_ACTION_BLOCKED.get(), 1, 1);
                return true;
            }

            if (address != null && stack.method_7947() < target.method_7947()) {
                player.method_5783(Envelope.SoundEvents.UI_ACTION_BLOCKED.get(), 1, 1);
                return true;
            }

            class_1799 result = target.method_7972();
            Mail.setRecipient(result, address);
            Mail.removePreviousDeliveryData(result);

            if (!slot.method_7680(result)) {
                player.method_5783(Envelope.SoundEvents.UI_ACTION_BLOCKED.get(), 1, 1);
                return true;
            }

            slot.method_53512(result);

            if (address != null && !player.method_7337()) {
                stack.method_7934(target.method_7947());
            }

            player.method_5783(Envelope.SoundEvents.TAG_APPLY.get(), 1, 1);

            return true;
        }

        // Copy address from carried item to target, but only if addresses are different (to not block usual stack splitting behavior)
        if (target.method_31574(Envelope.Items.ADDRESS_TAG.get())
              && !Objects.equals(address, target.method_57824(Envelope.DataComponents.ADDRESS_TAG_ADDRESS))) {
            target.method_57379(Envelope.DataComponents.ADDRESS_TAG_ADDRESS, address);
            player.method_5783(Envelope.SoundEvents.UI_WRITE.get(), 1, 1);
            return true;
        }

        return false;
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_2680 state = context.method_8045().method_8320(context.method_8037());
        if (state.method_26204() instanceof MailboxBlock) {
            return class_1269.field_5814; // Let mailbox handle the interaction
        }

        return super.method_7884(context);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (player.method_21823()) {
            @Nullable Address removedAddress = player.method_5998(hand).method_57381(Envelope.DataComponents.ADDRESS_TAG_ADDRESS);
            if (removedAddress != null) {
                player.method_5783(Envelope.SoundEvents.UI_WRITE.get(), 0.35f, 1);
                return class_1271.method_29237(player.method_5998(hand), level.method_8608());
            }
        }

        if (player instanceof class_3222 serverPlayer) {
            AllAddresses knownAddresses = MailService.of(serverPlayer.method_51469()).getKnownAddresses();
            new ClientboundOpenAddressTagScreenPacket(hand, knownAddresses).sendToClient(serverPlayer);
            player.method_7357().method_7906(this, 5);
        }

        return class_1271.method_29237(player.method_5998(hand), level.field_9236);
    }
}
