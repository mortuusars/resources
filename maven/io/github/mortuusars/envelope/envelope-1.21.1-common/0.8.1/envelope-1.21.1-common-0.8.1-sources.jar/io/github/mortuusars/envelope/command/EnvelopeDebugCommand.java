package io.github.mortuusars.envelope.command;

import com.google.common.base.Stopwatch;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.datafixers.util.Pair;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.delivery.PhysicalCourier;
import io.github.mortuusars.envelope.world.mail.delivery.background.BackgroundCourier;
import net.minecraft.class_124;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_156;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_5575;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7924;
import net.minecraft.network.chat.*;
import java.util.List;

public class EnvelopeDebugCommand {
    public static LiteralArgumentBuilder<class_2168> commands() {
        return class_2170.method_9247("debug")
              .then(class_2170.method_9247("terminate_all_deliveries")
                    .executes(EnvelopeDebugCommand::terminateAllDeliveries))
              .then(class_2170.method_9247("expire_all_awaiting_payback")
                    .executes(EnvelopeDebugCommand::timeoutAllPaybackMail))
              .then(class_2170.method_9247("test")
                    .executes(EnvelopeDebugCommand::test));
    }

    // --

    private static boolean terminateAllDeliveriesRequiresConfirmation = true;

    private static int terminateAllDeliveries(CommandContext<class_2168> context) {
        if (terminateAllDeliveriesRequiresConfirmation) {
            terminateAllDeliveriesRequiresConfirmation = false;
            context.getSource().method_9226(() -> class_2561.method_43470(
                        "Do you really want to stop all deliveries, despawning the couriers and voiding their mail?"), true);
            context.getSource().method_9226(() -> class_2561.method_43470("[Kill Them All!]")
                  .method_27696(class_2583.field_24360
                        .method_10977(class_124.field_1061)
                        .method_10958(new class_2558(class_2558.class_2559.field_11750, "/envelope debug terminate_all_deliveries"))
                        .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Click")))), true);
        } else {
            terminateAllDeliveriesRequiresConfirmation = true;

            class_3218 level = context.getSource().method_9225();

            int count = 0;

            for (BackgroundCourier courier : level.getEnvelopeMailService().getBackgroundDelivery().getActiveCouriers()) {
                courier.setRemoved();
                count++;
            }

            for (class_1309 entity : level.method_18198(class_5575.method_31795(class_1309.class),
                  e -> e instanceof PhysicalCourier courier && courier.isDelivering())) {
                if (entity instanceof class_1308 mob && mob.method_5987()) {
                    continue;
                }
                entity.method_31472();
                count++;
            }

            if (count == 0) {
                context.getSource().method_9226(() -> class_2561.method_43470("No deliveries to terminate."), true);
            } else {
                int finalCount = count;
                context.getSource().method_9226(() -> class_2561.method_43470("Terminated '" + finalCount + "' " + (finalCount > 1 ? "deliveries." : "delivery.")), true);
            }
        }

        return 0;
    }

    private static int timeoutAllPaybackMail(CommandContext<class_2168> context) {
        class_3218 level = context.getSource().method_9225();
        MailService service = MailService.of(level);
        int returnedCount = service.getPaybackDepartment().returnAllAwaitingAsTimedOut();

        if (returnedCount > 0) {
            context.getSource().method_9226(() -> class_2561.method_43470("Returned " +
                  returnedCount + " mail awaiting payback."), true);
        } else {
            context.getSource().method_9213(class_2561.method_43470("No mail awaiting payback is returned."));
        }

        return 0;
    }

    // --

    private static int test(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_3222 player = context.getSource().method_9207();

        /* Structure test
        List<BlockPos> positions = new ArrayList<>();

        for (int i = 0; i < 50; i++) {
            BlockPos pos = locateStructure(context.getSource(), ResourceKey.create(Registries.STRUCTURE, Envelope.resource("dovecote_plains")));
            if (pos.equals(BlockPos.ZERO)) {
                continue;
            }

            positions.add(pos);
        }

        if (positions.size() < 2) {
            context.getSource().sendFailure(Component.literal("Too few positions"));
            return 0;
        }

        List<Integer> lowestDistances = new ArrayList<>();
        int totalDistance = 0;

        for (BlockPos position : positions) {
            int lowest = Integer.MAX_VALUE;
            for (BlockPos pos : positions) {
                if (!pos.equals(position)) {
                    int distance = (int) Math.sqrt(position.distSqr(pos));
                    if (distance < lowest) {
                        lowest = distance;
                    }
                }
            }
            lowestDistances.add(lowest);
            totalDistance += lowest;
        }

        double average = (double) totalDistance / positions.size();


        boolean a = true;*/


//        Component text = Component.literal("       Report to Chief\n\n  Patrol we sent to village not return. Unexpected danger possible.\n\n  Must know more. Asking reinforcements.")
//              .setStyle(Style.EMPTY.withFont(ResourceLocation.withDefaultNamespace("illageralt")));
//
//        ItemStack letter = Mail.createLetter(text)
//              .set(DataComponents.ITEM_NAME, Component.literal("Report")
//                    .withStyle(Style.EMPTY.withFont(ResourceLocation.withDefaultNamespace("illageralt")))).get();
//
//        player.addItem(letter);


//        player.level().getEntitiesOfClass(Pigeon.class, player.getBoundingBox().inflate(16))
//              .forEach(p -> p.restrictTo(player.blockPosition(), 4));
//        player.level().getEntitiesOfClass(Villager.class, player.getBoundingBox().inflate(16))
//              .forEach(p -> p.restrictTo(player.blockPosition(), 4));

        //        EquineAssuranceBureau.sendNotice(MailService.of(player.serverLevel()),
//              ServiceAddress.getOrThrow(player.registryAccess(), ServiceAddresses.EQUINE_ASSURANCE_BUREAU));

//        ItemStack item = new ItemStack(Envelope.Items.LETTER.get());
//        item.set(Envelope.DataComponents.LETTER_CONTENT,
//              new LetterContent(Component.translatable("gui.abuseReport.comments").withColor(0xFFAA7733)));
//        Mail.writeToLog(item, DeliveryRecord.sentFrom(Address.UNKNOWN, 123141L),
//              DeliveryRecord.payback(Component.literal("Test"), DeliveryRecord.MessageType.POSITIVE));
//        Mail.setSender(item, Address.UNKNOWN);
//
//        player.drop(item, false);


//        List<RecipeHolder<MailRecipe>> recipes = player.level().getRecipeManager().getAllRecipesFor(Envelope.RecipeTypes.MAILING.get());
//
//        List<ItemStack> items = List.of(
//              new ItemStack(Envelope.Items.ADDRESS_TAG.get(), 3),
//              new ItemStack(Items.RED_DYE),
//              new ItemStack(Items.RED_DYE),
//              new ItemStack(Items.RED_DYE)
//        );
//
//        SimpleRecipeInput input = new SimpleRecipeInput(items);
//        @Nullable MailRecipe recipe = null;
//
//        for (RecipeHolder<MailRecipe> holder : recipes) {
//            if (holder.value().matches(input, player.level())) {
//                recipe = holder.value();
//            }
//        }

//        MailService.of(player.serverLevel()).getDeliveryManager()
//              .startService(Delivery.draft()
//                    .deliver(Mail.createPackage(new PackageContents(List.of(new ItemStack(Items.ACACIA_LOG))))
//                          .get())
//                    .from(new Address.Block("Blue"))
//                    .to(new Address.Block("Red"))
//                    .startAtPhase(DeliveryPhase.DISPATCHING_DELIVERY));

//        ItemStack pkg = new ItemStack(Envelope.Items.PACKAGE.get());
//        pkg.set(Envelope.DataComponents.PACKAGE_CONTENTS, new PackageContents(List.of(new ItemStack(Items.FEATHER, 5))));
//        pkg.set(Envelope.DataComponents.SENDER, new Address.Block("Original-Sender"));
//        pkg.set(Envelope.DataComponents.RECIPIENT, new Address.Block("Base"));
//        pkg.set(Envelope.DataComponents.PAYBACK, Payback.createOrDefault(List.of(
//              new RequestedItem(Items.EMERALD, 3), new RequestedItem(ItemTags.LOGS, 13))));
//
//        Mail mail = new Mail(pkg);
//
//        ItemStack paybackPackage = new ItemStack(Envelope.Items.PAYBACK_PACKING_BOX.get());
//        paybackPackage.set(Envelope.DataComponents.PAYBACK_SUBJECT, new StoredItemStack(mail.getItemCopy()));
//        paybackPackage.set(Envelope.DataComponents.SENDER, Address.MAIL_SERVICE);
//        paybackPackage.set(Envelope.DataComponents.RECIPIENT, mail.getRecipient());
//
//        Containers.dropItemStack(context.getSource().getLevel(), player.getX(), player.getY(), player.getZ(), paybackPackage);

        return 0;
    }

    private static class_2338 locateStructure(class_2168 source, class_5321<class_3195> key) throws CommandSyntaxException {
        class_2378<class_3195> registry = source.method_9225().method_30349().method_30530(class_7924.field_41246);
        class_6880.class_6883<class_3195> holder = registry.method_40290(key);
        class_6885.class_6886<class_3195> holderSet = class_6885.method_40246(holder);
        class_2338 blockPos = class_2338.method_49638(source.method_9222());
        class_3218 serverLevel = source.method_9225();
        Stopwatch stopwatch = Stopwatch.createStarted(class_156.field_37250);
        Pair<class_2338, class_6880<class_3195>> pair = serverLevel.method_14178().method_12129()
              .method_12103(serverLevel, holderSet, blockPos, 100, true);
        stopwatch.stop();

        if (pair == null) {
            source.method_9213(class_2561.method_43470("Cannot find " + key.method_29177()));
            return class_2338.field_10980;
        } else {
            class_2338 pos = pair.getFirst();

            class_2561 component = class_2564.method_10885(class_2561.method_43469("chat.coordinates", pos.method_10263(), pos.method_10264(), pos.method_10260()))
                  .method_27694(
                        style -> style.method_10977(class_124.field_1060)
                              .method_10958(new class_2558(class_2558.class_2559.field_11745, "/tp @s " + pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260()))
                              .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43471("chat.coordinates.tooltip")))
                  );

            source.method_9226(() -> component, true);
            return pos;
        }
    }
}
