package io.github.mortuusars.envelope.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.envelope.command.argument.AddressArgument;
import io.github.mortuusars.envelope.command.argument.SealLockArgument;
import io.github.mortuusars.envelope.command.suggestion.AddressSuggestions;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.world.item.component.SealLock;
import io.github.mortuusars.envelope.world.level.saveddata.SealLocks;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import io.github.mortuusars.envelope.world.mail.address.type.PlayerAddress;
import io.github.mortuusars.mortaar.util.GameTimeId;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2179;
import net.minecraft.class_2287;
import net.minecraft.class_2290;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_3218;
import net.minecraft.class_5250;
import net.minecraft.class_7157;
import net.minecraft.network.chat.*;
import java.util.*;

public class EnvelopeCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 context) {
        dispatcher.register(class_2170.method_9247("envelope")
              .requires((stack) -> stack.method_9259(2))
              .then(class_2170.method_9247("mail")
                    .then(class_2170.method_9247("send")
                          .then(class_2170.method_9244("mail", class_2287.method_9776(context))
                                .executes(c -> sendMail(c,
                                      class_2287.method_9777(c, "mail"), Optional.empty(), Optional.empty()))
                                .then(class_2170.method_9244("sender", class_2179.method_9284())
                                      .executes(c -> sendMail(c,
                                            class_2287.method_9777(c, "mail"),
                                            Optional.of(parseAddress(c, class_2179.method_9285(c, "sender"))),
                                            Optional.empty()))
                                      .then(class_2170.method_9244("recipient", class_2179.method_9284())
                                            .executes(c -> sendMail(c,
                                                  class_2287.method_9777(c, "mail"),
                                                  Optional.of(parseAddress(c, class_2179.method_9285(c, "sender"))),
                                                  Optional.of(parseAddress(c, class_2179.method_9285(c, "recipient")))))))))
                    .then(class_2170.method_9247("broadcast")
                          .then(class_2170.method_9244("mail", class_2287.method_9776(context))
                                .executes(c -> broadcastMail(c, class_2287.method_9777(c, "mail"), Address.UNKNOWN))
                                .then(class_2170.method_9244("sender", class_2179.method_9284())
                                      .executes(c -> broadcastMail(c,
                                            class_2287.method_9777(c, "mail"),
                                            parseAddress(c, class_2179.method_9285(c, "sender"))))))))
              .then(class_2170.method_9247("mailbox")
                    .then(class_2170.method_9247("list")
                          .executes(EnvelopeCommand::listAllMailboxes)
                          .then(class_2170.method_9247("default")
                                .executes(EnvelopeCommand::listDefaultMailboxes)))
                    .then(class_2170.method_9247("position")
                          .then(class_2170.method_9244("address", AddressArgument.block())
                                .suggests(AddressSuggestions.block())
                                .executes(c -> mailboxPosition(c, AddressArgument.getBlock(c, "address"))))))
              .then(class_2170.method_9247("seal_lock")
                    .then(class_2170.method_9247("create")
                          .then(class_2170.method_9244("owner", StringArgumentType.word())
                                .executes(c -> createSealLock(c,
                                      Either.left(StringArgumentType.getString(c, "owner")))))
                          .then(class_2170.method_9244("lock", SealLockArgument.sealLock())
                                .executes(c -> createSealLock(c, Either.right(SealLockArgument.getSealLock(c, "lock"))))))
                    .then(class_2170.method_9247("unlock")
                          .then(class_2170.method_9244("owner", StringArgumentType.word())
                                .executes(c -> unlockSealLock(c,
                                      Either.left(StringArgumentType.getString(c, "owner")))))
                          .then(class_2170.method_9244("lock", SealLockArgument.sealLock())
                                .executes(c -> unlockSealLock(c, Either.right(SealLockArgument.getSealLock(c, "lock"))))))
                    .then(class_2170.method_9247("list")
                          .executes(EnvelopeCommand::listSealLocks)))
              .then(EnvelopeDebugCommand.commands()));
    }

    // -- Mail

    private static int sendMail(CommandContext<class_2168> context, class_2290 item, Optional<Address> from, Optional<Address> to) throws CommandSyntaxException {
        class_3218 level = context.getSource().method_9225();
        class_1799 mail = item.method_9781(1, false);


        Address recipient = to.orElse(Mail.getRecipientOrUnknown(mail));

        if (mail.method_7960()) {
            context.getSource().method_9213(class_2561.method_43470("Cannot send: mail is empty."));
            return 1;
        }

        if (recipient.equals(Address.UNKNOWN)) {
            context.getSource().method_9213(class_2561.method_43470("Cannot send: recipient is not defined."));
            return 2;
        }

        if (recipient.resolve(level.getEnvelopeMailService()).equals(Address.UNKNOWN)) {
            context.getSource().method_9213(class_2561.method_43470("Cannot send: recipient not found."));
            return 3;
        }

        MailService.of(level).getDeliveryManager()
              .startService(Delivery.draft()
                    .deliver(mail)
                    .from(from.orElse(Address.UNKNOWN))
                    .to(recipient));

        class_2561 message = class_2561.method_43470("Mail sent to ").method_10852(recipient.format().asRecipient().toComponent());
        context.getSource().method_9226(() -> message, true);

        return 0;
    }

    private static int broadcastMail(CommandContext<class_2168> context, class_2290 item, Address sender) throws CommandSyntaxException {
        class_3218 level = context.getSource().method_9225();
        MailService service = level.getEnvelopeMailService();
        class_1799 mail = item.method_9781(1, false);

        Map<PlayerAddress, BlockAddress> defaultAddresses = service.getKnownPlayers().getDefaultAddresses();

        if (defaultAddresses.isEmpty()) {
            context.getSource().method_9213(class_2561.method_43470("Cannot broadcast: no recipients."));
            return 1;
        }

        int count = 0;

        for (Map.Entry<PlayerAddress, BlockAddress> entry : defaultAddresses.entrySet()) {
            class_1799 broadcastedMail = Mail.setRecipient(mail.method_7972(), entry.getKey());
            MailService.of(level).getDeliveryManager()
                  .startService(Delivery.draft()
                        .deliver(broadcastedMail)
                        .from(sender)
                        .to(entry.getKey()));
            count++;
        }

        class_2561 message = class_2561.method_43470("Broadcasted mail to " + count + " recipient(s)");
        context.getSource().method_9226(() -> message, true);

        return 0;
    }

    private static Address parseAddress(CommandContext<class_2168> context, class_2487 tag) {
        return Address.CODEC.parse(context.getSource().method_30497().method_57093(class_2509.field_11560), tag).getOrThrow();
    }

    // -- Mailbox

    private static int listAllMailboxes(CommandContext<class_2168> context) {
        class_3218 level = context.getSource().method_9225();
        Set<BlockAddress> addresses = MailService.of(level).getMailboxes().getAllAddresses();

        if (!addresses.isEmpty()) {
            context.getSource().method_9226(() -> class_2561.method_43470("All mailboxes:"), true);
            for (BlockAddress address : addresses) {
                context.getSource().method_9226(() -> copyableAddressAndPos(address,
                      MailService.of(level).getMailboxes().getPositionOf(address)), true);
            }
        } else {
            context.getSource().method_9226(() ->
                  class_2561.method_43470("There are no known mailboxes."), true);
        }
        return 0;
    }

    private static int listDefaultMailboxes(CommandContext<class_2168> context) {
        class_3218 level = context.getSource().method_9225();

        Map<PlayerAddress, BlockAddress> defaultAddresses = MailService.of(level).getKnownPlayers().getDefaultAddresses();

        if (!defaultAddresses.isEmpty()) {
            context.getSource().method_9226(() -> class_2561.method_43470("Default addresses:"), true);

            defaultAddresses.forEach((playerAddress, address) -> {
                Optional<class_2338> position = MailService.of(level).getMailboxes().getPositionOf(address);
                context.getSource().method_9226(() -> class_2561.method_43470(playerAddress.getString())
                      .method_27693(" - ")
                      .method_10852(copyableAddressAndPos(address, position)), true);
            });
        } else {
            context.getSource().method_9226(() ->
                  class_2561.method_43470("There are no default mailboxes."), true);
        }

        return 0;
    }

    private static int mailboxPosition(CommandContext<class_2168> context, BlockAddress address) {
        class_3218 level = context.getSource().method_9225();
        if (!MailService.of(level).getMailboxes().exists(address)) {
            context.getSource().method_9213(address.getComponent().method_27693(" does not exist."));
            return 1;
        }

        MailService.of(level).getMailboxes().getPositionOf(address)
              .ifPresentOrElse(
                    pos -> context.getSource().method_9226(() -> copyableAddressAndPos(address, Optional.of(pos)), true),
                    () -> context.getSource().method_9213(address.getComponent()
                          .method_27693(" does not have a position associated with it.")));
        return 0;
    }

    private static class_5250 copyableAddressAndPos(Address address, Optional<class_2338> pos) {
        String name = address.getString();
        String posStr = pos.map(class_2338::method_23854).orElse("");
        String posToCopy = posStr.replace(",", "");

        return class_2561.method_43470(name)
              .method_27696(class_2583.field_24360
                    .method_36139(Colors.ADDRESS_NEUTRAL)
                    .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Copy Address")
                          .method_27693("\n")
                          .method_10852(class_2561.method_43470(name).method_27692(class_124.field_1080))))
                    .method_10958(new class_2558(class_2558.class_2559.field_21462, name)))
              .method_10852(class_2561.method_43470("@[" + posStr + "]").method_27696(class_2583.field_24360
                    .method_10977(class_124.field_1068)
                    .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Copy Position")
                          .method_27693("\n")
                          .method_10852(class_2561.method_43470(posToCopy).method_27692(class_124.field_1080))))
                    .method_10958(new class_2558(class_2558.class_2559.field_21462, posToCopy))));
    }

    // -- Seal Locks

    private static int createSealLock(CommandContext<class_2168> context, Either<String, SealLock> ownerOrLock) {
        class_3218 level = context.getSource().method_9225();

        SealLock lock = Either.unwrap(ownerOrLock.mapLeft(owner -> new SealLock(owner, GameTimeId.create(level))));
        if (lock.lock(level)) {
            context.getSource().method_9226(() -> {
                String text = lock.toString();
                return class_2561.method_43470("Lock created: ").method_10852(class_2561.method_43470(text)
                      .method_27696(class_2583.field_24360.method_10977(class_124.field_1075)
                            .method_30938(true)
                            .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Copy")))
                            .method_10958(new class_2558(class_2558.class_2559.field_21462, text))));
            }, true);
        } else {
            context.getSource().method_9226(() -> {
                String text = lock.toString();
                return class_2561.method_43470("Lock already exists: ").method_10852(class_2561.method_43470(text)
                      .method_27696(class_2583.field_24360.method_10977(class_124.field_1075)
                            .method_30938(true)
                            .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Copy")))
                            .method_10958(new class_2558(class_2558.class_2559.field_21462, text))));
            }, true);
        }

        return 0;
    }

    private static int unlockSealLock(CommandContext<class_2168> context, Either<String, SealLock> ownerOrLock) {
        ownerOrLock
              .ifLeft(owner -> {
                  if (owner.isBlank()) {
                      context.getSource().method_9213(class_2561.method_43470("Lock owner cannot be empty."));
                      return;
                  }

                  if (SealLock.unlockAllFrom(owner, context.getSource().method_9225())) {
                      context.getSource().method_9226(() -> class_2561.method_43470("Unlocked all locks from ")
                            .method_10852(class_2561.method_43470(owner).method_27692(class_124.field_1060)), true);
                  } else {
                      context.getSource().method_9213(class_2561.method_43470(owner + " does not have any locked locks."));
                  }
              })
              .ifRight(lock -> {
                  if (lock.unlock(context.getSource().method_9225())) {
                      context.getSource().method_9226(() -> class_2561.method_43470("Lock unlocked: ")
                            .method_10852(class_2561.method_43470(lock.toString()).method_27692(class_124.field_1060)), true);
                  } else {
                      context.getSource().method_9213(class_2561.method_43470(lock.toString()).method_27692(class_124.field_1075)
                            .method_27693(" is not locked.").method_27692(class_124.field_1061));
                  }
              });

        return 0;
    }

    private static int listSealLocks(CommandContext<class_2168> context) {
        class_3218 level = context.getSource().method_9225();
        Set<SealLock> locks = SealLocks.get(level).getLocks();

        if (locks.isEmpty()) {
            context.getSource().method_9226(() -> class_2561.method_43470("No seal locks.").method_27692(class_124.field_1061), true);
            return 0;
        }

        context.getSource().method_9226(() -> class_2561.method_43470("Showing " + locks.size() + " seal lock(s):"), true);

        for (SealLock lock : locks) {
            context.getSource().method_9226(() -> class_2561.method_43470(lock.toString())
                  .method_27696(class_2583.field_24360.method_10977(class_124.field_1075)
                        .method_30938(true)
                        .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Copy")))
                        .method_10958(new class_2558(class_2558.class_2559.field_21462, lock.toString()))), true);
        }

        return 0;
    }
}