package io.github.mortuusars.envelope.world.item.component.seal;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.mortaar.util.color.TintColor;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_9139;

public record ShadingPalette(TintColor base, TintColor highlight, TintColor shadow, TintColor side) {
    public ShadingPalette(int base, int highlight, int shadow, int side) {
        this(TintColor.of(base), TintColor.of(highlight), TintColor.of(shadow), TintColor.of(side));
    }

    public static final Codec<ShadingPalette> CODEC = RecordCodecBuilder.create(i -> i.group(
          TintColor.CODEC.fieldOf("base").forGetter(ShadingPalette::base),
          TintColor.CODEC.fieldOf("highlight").forGetter(ShadingPalette::highlight),
          TintColor.CODEC.fieldOf("shadow").forGetter(ShadingPalette::shadow),
          TintColor.CODEC.fieldOf("side").forGetter(ShadingPalette::side)
    ).apply(i, ShadingPalette::new));

    public static final class_9139<ByteBuf, ShadingPalette> STREAM_CODEC = class_9139.method_56905(
          TintColor.STREAM_CODEC, ShadingPalette::base,
          TintColor.STREAM_CODEC, ShadingPalette::highlight,
          TintColor.STREAM_CODEC, ShadingPalette::shadow,
          TintColor.STREAM_CODEC, ShadingPalette::side,
          ShadingPalette::new
    );

    public static final ShadingPalette IRON_DIE = new ShadingPalette(0xFFA0A3A9, 0xFFE5E6E8, 0xFF6C717B, 0xFFC4C5C8);
}
