package io.github.mortuusars.envelope.world.inventory;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.AddressTagItem;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.mail.address.Address;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3419;
import net.minecraft.class_3917;
import net.minecraft.class_9129;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PackingMenu extends AbstractInHandContainerMenu {
    public static final int PACK_BUTTON_ID = 0;

    private @Nullable Address presetAddress;
    protected boolean packed = false;

    protected PackingMenu(@Nullable class_3917<?> menuType, int containerId, class_1661 playerInventory, class_1268 hand) {
        super(menuType, containerId, playerInventory, hand);
    }

    public PackingMenu(int containerId, class_1661 playerInventory, class_1268 hand) {
        this(Envelope.MenuTypes.PACKING.get(), containerId, playerInventory, hand);
    }

    public static PackingMenu fromNetwork(int id, class_1661 inventory, class_9129 buffer) {
        return new PackingMenu(id, inventory, buffer.method_10818(class_1268.class));
    }

    @Override
    protected class_1263 createContainer() {
        return new class_1277(PackageContents.SLOTS);
    }

    @Override
    protected void addContainerSlots() {
        int packageSlotsX = 62;
        int packageSlotsY = 33;

        for (int row = 0; row < 2; row++) {
            for (int column = 0; column < 3; column++) {
                int index = column + row * 3;
                int x = packageSlotsX + column * 18;
                int y = packageSlotsY + row * 18;
                
                method_7621(createContainerSlot(index, x, y));
            }
        }
    }

    protected class_1735 createContainerSlot(int index, int x, int y) {
        return new class_1735(getContainer(), index, x, y) {
            @Override
            public boolean method_7680(class_1799 stack) {
                return PackageContents.canHold(stack);
            }
        };
    }

    // --

    public @Nullable Address getPresetAddress() {
        return presetAddress;
    }

    public void presetAddress(@Nullable Address address) {
        presetAddress = address;
    }

    public class_1799 getAddressTag() {
        return PlayerInventoryUtil.findFirstMatching(getPlayer(),
              stack -> stack.method_7909() instanceof AddressTagItem);
    }

    // --

    public boolean isPacked() {
        return packed;
    }

    public boolean canPack() {
        return !getContainer().method_5442();
    }

    protected void pack() {
        class_1657 player = getPlayer();

        class_1799 addressTag = getAddressTag();

        if (addressTag.method_7960()) {
            presetAddress = null;
        } else if (presetAddress != null) {
            addressTag.method_7934(1);
        }

        class_1799 result = createPackingResult();
        result.method_57381(Envelope.DataComponents.OPEN);

        getItemInHand().method_7934(1);

        if (!player.method_7270(result)) {
            player.method_7328(result, false);
        }

        player.method_37908().method_43129(null, player, Envelope.SoundEvents.PACKAGE_PACK.get(), class_3419.field_15248,
              1f, player.method_37908().method_8409().method_43057() * 0.3f + 0.85f);
        player.method_6104(getHand());
        player.method_7281(Envelope.Stats.PACKAGES_CREATED.get());
        packed = true;
    }

    protected @NotNull class_1799 createPackingResult() {
        class_1799 result = new class_1799(Envelope.Items.PACKAGE.get());
        result.method_57379(Envelope.DataComponents.PACKAGE_CONTENTS, new PackageContents(getContainer()));
        result.method_57379(Envelope.DataComponents.MAIL_ADDRESS_TAG, presetAddress);
        return result;
    }

    // --

    @Override
    public boolean method_7604(class_1657 player, int buttonId) {
        if (buttonId == PACK_BUTTON_ID) {
            if (canPack()) {
                pack();
            }
            return true;
        }

        return false;
    }

    @Override
    public void method_7595(@NotNull class_1657 player) {
        if (!isPacked()) {
            method_7607(player, getContainer());
        }

        if (getItemInHand().method_57381(Envelope.DataComponents.OPEN) != null) {
            player.method_7350();
        }

        super.method_7595(player);
    }
}