package io.github.mortuusars.envelope.world.block.mailbox;

import com.mojang.serialization.MapCodec;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.entity.CourierBat;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.network.packet.clientbound.ClientboundOpenMailboxAddressTagScreenPacket;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.item.AddressTagItem;
import io.github.mortuusars.envelope.world.mail.address.BlockAddressValidation;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import io.github.mortuusars.envelope.world.mail.address.type.PlayerAddress;
import io.github.mortuusars.envelope.world.mail.delivery.CourierOrigin;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3730;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_9062;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class MailboxBlock extends class_2237 {
    public static final MapCodec<MailboxBlock> field_46280 = method_54094(MailboxBlock::new);

    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2746 HANGING = class_2741.field_16561;
    public static final class_2746 OPEN = class_2741.field_12537;
    public static final class_2746 HAS_MAIL = class_2746.method_11825("has_mail");

    public static final class_265 SHAPE_Z = class_259.method_17786(
          class_2248.method_9541(3, 2, 3, 13, 11.5, 13),
          class_2248.method_9541(6, 11.5, 3, 10, 12, 13),
          class_2248.method_9541(2, 0, 2, 14, 2, 14));
    public static final class_265 SHAPE_X = class_259.method_17786(
          class_2248.method_9541(3, 2, 3, 13, 11.5, 13),
          class_2248.method_9541(3, 11.5, 6, 13, 12, 10),
          class_2248.method_9541(2, 0, 2, 14, 2, 14));
    public static final class_265 SHAPE_HANGING_NORTH = class_259.method_17786(
          class_2248.method_9541(2, 0, 7, 14, 2, 16),
          class_2248.method_9541(3, 2, 8, 13, 11.5, 16),
          class_2248.method_9541(6, 11.5, 8, 10, 12, 16));
    public static final class_265 SHAPE_HANGING_EAST = class_259.method_17786(
          class_2248.method_9541(0, 0, 2, 9, 2, 14),
          class_2248.method_9541(0, 2, 3, 8, 11.5, 13),
          class_2248.method_9541(0, 11.5, 6, 8, 12, 10));
    public static final class_265 SHAPE_HANGING_SOUTH = class_259.method_17786(
          class_2248.method_9541(2, 0, 0, 14, 2, 9),
          class_2248.method_9541(3, 2, 0, 13, 11.5, 8),
          class_2248.method_9541(6, 11.5, 0, 10, 12, 8));
    public static final class_265 SHAPE_HANGING_WEST = class_259.method_17786(
          class_2248.method_9541(7, 0, 2, 16, 2, 14),
          class_2248.method_9541(8, 2, 3, 16, 11.5, 13),
          class_2248.method_9541(8, 11.5, 6, 16, 12, 10));

    public MailboxBlock(class_2251 properties) {
        super(properties);
        method_9590(field_10647.method_11664()
              .method_11657(FACING, class_2350.field_11043)
              .method_11657(HANGING, false)
              .method_11657(OPEN, false)
              .method_11657(HAS_MAIL, false));
    }

    @Override
    protected @NotNull MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected @NotNull class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        if (state.method_28498(HANGING) && state.method_11654(HANGING)) {
            return switch (state.method_11654(FACING)) {
                case field_11035 -> SHAPE_HANGING_SOUTH;
                case field_11039 -> SHAPE_HANGING_WEST;
                case field_11034 -> SHAPE_HANGING_EAST;
                default -> SHAPE_HANGING_NORTH;
            };
        }

        return state.method_11654(FACING).method_10166() == class_2350.class_2351.field_11051 ? SHAPE_Z : SHAPE_X;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, HANGING, OPEN, HAS_MAIL);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2338 attachPos = context.method_8037().method_10093(context.method_8038().method_10153());
        boolean hanging = !context.method_7717()
              && context.method_8038().method_10166().method_10179()
              && context.method_8045().method_8320(attachPos).method_26206(context.method_8045(), attachPos, context.method_8038());

        return this.method_9564()
              .method_11657(FACING, hanging ? context.method_8038() : context.method_8042().method_10153())
              .method_11657(HANGING, hanging);
    }

    @Override
    public @NotNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public @NotNull class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    protected int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        if (level.method_8321(pos) instanceof MailboxBlockEntity blockEntity
              && !blockEntity.getAllMail().isEmpty()) {
            return 15;
        }
        return 0;
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        super.method_9567(level, pos, state, placer, stack);
        if (placer != null && level.method_8321(pos) instanceof MailboxBlockEntity blockEntity) {
            blockEntity.setOwner(placer.method_5667());
        }
    }

    @Override
    protected void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
        if (!state.method_26204().equals(newState.method_26204()) && level instanceof class_3218 serverLevel) {
            // Using MailboxBlockEntity#onBlockRemoved does not cover every case,
            // as block entity might not exist while the block is still placed.
            // This happens with CarryOn relocation for example, where block entity is removed first.
            // So we remove any registered mailbox at this position:
            MailService.of(serverLevel).getMailboxes().remove(pos);

            if (level.method_8321(pos) instanceof MailboxBlockEntity blockEntity) {
                blockEntity.onBlockRemoved(level, pos, state, newState);
            }
        }

        super.method_9536(state, level, pos, newState, movedByPiston);
    }

    @Override
    protected @NotNull class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        if (!MailService.operatesIn(level)) {
            player.method_7353(class_2561.method_43471("gui.envelope.mail_service.invalid_dimension")
                  .method_27692(class_124.field_1061), true);
            return class_9062.field_47728;
        }

        if (stack.method_7909() instanceof AddressTagItem) {
            if (player instanceof class_3222 serverPlayer && level.method_8321(pos) instanceof MailboxBlockEntity blockEntity) {
                AllAddresses knownAddresses = serverPlayer.method_51469().getEnvelopeMailService().getKnownAddresses();
                new ClientboundOpenMailboxAddressTagScreenPacket(hand, knownAddresses, pos, blockEntity.getAddress()).sendToClient(serverPlayer);
            }
            return class_9062.field_47728;
        }

        if (player.method_7337()
              && stack.method_31573(Envelope.Tags.Items.MAILABLE)
              && stack.method_57824(Envelope.DataComponents.MAIL_ADDRESS_TAG) instanceof BlockAddress address
              && level.method_8321(pos) instanceof MailboxBlockEntity blockEntity
              && blockEntity.getAddress().equals(address)) {
            if (!level.method_8608()) {
                class_1799 mail = Mail.asDelivered(Mail.of(stack.method_46651(1))
                      .writeToLog(DeliveryRecord.sentFrom(new PlayerAddress(player)))
                      .writeToLog(DeliveryRecord.arrivedTo(address))
                      .sender(new PlayerAddress(player))
                      .itemStack());

                if (blockEntity.addMail(mail)) {
                    player.method_5998(hand).method_7934(1);
                    blockEntity.onMailInserted(mail);
                }
            }
            return class_9062.field_47728;
        }

        if (player.method_7337()
              && stack.method_31574(class_1802.field_8688)
              && level.method_8321(pos) instanceof MailboxBlockEntity blockEntity) {
            if (!level.method_8608()) {
                if (blockEntity.getAllMail().size() > 64) {
                    blockEntity.clearMail();
                } else {
                    for (int i = 0; i < 12; i++) {
                        class_1799 mail = Mail.asDelivered(Mail.of(Envelope.Items.LETTER)
                              .sender(new BlockAddress("Address " + i))
                              .recipient(blockEntity.getAddress())
                              .writeToLog(DeliveryRecord.sentFrom(new PlayerAddress(player)))
                              .writeToLog(DeliveryRecord.arrivedTo(blockEntity.getAddress()))
                              .name(class_2561.method_43470("Letter " + i))
                              .itemStack());

                        if (blockEntity.addMail(mail)) {
                            blockEntity.onMailInserted(mail);
                        }
                    }
                }
            }
            return class_9062.field_47728;
        }

        //TODO: refactor the hell out from this:

        if (stack.method_31574(Envelope.Items.PIGEON_SPAWN_EGG.get())) {
            if (level instanceof class_3218 serverLevel) {
                if (level.method_8321(pos) instanceof MailboxBlockEntity blockEntity
                      && blockEntity.isAvailableForPickup()
                      && !blockEntity.getPigeonFoodItem().method_7960()
                      && Envelope.EntityTypes.PIGEON.get().method_47821(serverLevel,
                        pos.method_10093(state.method_11654(FACING)), class_3730.field_16465) instanceof Pigeon pigeon
                      && blockEntity.tryStartDelivery(pigeon)) {
                    if (level.method_23886() || level.method_8419() || level.method_8546()) {
                        serverLevel.method_8396(null, pos, Envelope.SoundEvents.UI_ERROR.get(), class_3419.field_15245, 1, 1);
                        player.method_7353(class_2561.method_43471("gui.envelope.mailbox.pigeon_wrong_time").method_27692(class_124.field_1061), true);
                        return class_9062.field_47728;
                    }

                    if (!player.method_7337()) {
                        pigeon.setOrigin(CourierOrigin.regular(pos));
                        stack.method_7934(1);
                    } else {
                        pigeon.setOrigin(CourierOrigin.service());
                    }
                } else {
                    serverLevel.method_8396(null, pos, Envelope.SoundEvents.UI_ERROR.get(), class_3419.field_15245, 1, 1);
                }
            }

            return class_9062.field_47728;
        }

        //TODO: Don't consume food and mail in creative
        if (stack.method_31574(class_1802.field_8727)) {
            if (!(level instanceof class_3218 serverLevel)) {
                return class_9062.field_47728;
            }

            if (!(level.method_8321(pos) instanceof MailboxBlockEntity blockEntity)) {
                serverLevel.method_8396(null, pos, Envelope.SoundEvents.UI_ERROR.get(), class_3419.field_15245, 1, 1);
                return class_9062.field_47728;
            }

            if (!blockEntity.isAvailableForPickup()) {
                serverLevel.method_8396(null, pos, Envelope.SoundEvents.UI_ERROR.get(), class_3419.field_15245, 1, 1);
                player.method_7353(class_2561.method_43471("gui.envelope.mailbox.no_mail_or_food").method_27692(class_124.field_1061), true);
                return class_9062.field_47728;
            }

            if (blockEntity.getBatFoodItem().method_7960()) {
                serverLevel.method_8396(null, pos, Envelope.SoundEvents.UI_ERROR.get(), class_3419.field_15245, 1, 1);
                player.method_7353(class_2561.method_43471("gui.envelope.mailbox.bat_wrong_food").method_27692(class_124.field_1061), true);
                return class_9062.field_47728;
            }

            if (level.method_8530() || level.method_8419() || level.method_8546()) {
                serverLevel.method_8396(null, pos, Envelope.SoundEvents.UI_ERROR.get(), class_3419.field_15245, 1, 1);
                player.method_7353(class_2561.method_43471("gui.envelope.mailbox.bat_wrong_time").method_27692(class_124.field_1061), true);
                return class_9062.field_47728;
            }

            @Nullable CourierBat bat = Envelope.EntityTypes.COURIER_BAT.get().method_47821(serverLevel, pos.method_10093(state.method_11654(FACING)), class_3730.field_16465);
            if (bat != null) {
                bat.setSpawnPos(Position.ascendTowards(level, pos, Optional.empty(),
                      Config.Server.DELIVERY_ASCEND_DISTANCE.get(), level.method_8409().method_43054()));
                bat.getMailboxHandler().setTargetPos(pos);
                if (!player.method_7337()) {
                    stack.method_7934(1);
                }
            } else {
                serverLevel.method_8396(null, pos, Envelope.SoundEvents.UI_ERROR.get(), class_3419.field_15245, 1, 1);
                player.method_7353(class_2561.method_43471("gui.envelope.mailbox.bat_spawn_failed").method_27692(class_124.field_1061), true);
            }

            return class_9062.field_47728;
        }

        return super.method_55765(stack, state, level, pos, player, hand, hitResult);
    }

    @Override
    protected @NotNull class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos,
                                                        class_1657 player, class_3965 hitResult) {
        if (!(level.method_8321(pos) instanceof MailboxBlockEntity blockEntity)) {
            return super.method_55766(state, level, pos, player, hitResult);
        }

        if (!MailService.operatesIn(level)) {
            player.method_7353(class_2561.method_43471("gui.envelope.mail_service.invalid_dimension")
                  .method_27692(class_124.field_1061), true);
            return class_1269.field_51370;
        }

        blockEntity.openMenu(player);
        player.method_7281(Envelope.Stats.INTERACT_WITH_MAILBOX.get());

        return class_1269.field_51370;
    }

    // --

    public void changeAddress(class_1657 player, class_2338 pos, class_1268 hand, String addressId) {
        if (!(player.method_37908() instanceof class_3218 level)) {
            return;
        }

        class_1799 stack = player.method_5998(hand);

        if (!(stack.method_7909() instanceof AddressTagItem)) {
            Envelope.LOGGER.error("Failed change address: item in hand is not AddressTagItem, but {}", stack);
            return;
        }

        if (!(level.method_8321(pos) instanceof MailboxBlockEntity blockEntity)) {
            Envelope.LOGGER.error("Failed change address: block entity at pos is not a MailboxBlockEntity.");
            return;
        }

        BlockAddressValidation.forMailbox(MailService.of(level).getKnownAddresses(), player)
              .test(addressId)
              .ifPresentOrElse(
                    id -> {
                        applyAddress(player, blockEntity, new BlockAddress(id), stack);
                        player.method_23667(hand, true);

                        if (!player.method_7337()) {
                            stack.method_7934(1);
                        }
                    },
                    error -> {
                        player.method_7353(error.getTranslation(), true);
                        player.method_5783(Envelope.SoundEvents.UI_ERROR.get(), 0.75f, 1f);
                    });
    }

    public static void placeBlockWithAddress(class_1657 player, class_1268 hand, class_1750 context, String addressId) {
        if (!(player.method_37908() instanceof class_3218 level)) {
            return;
        }

        class_2338 pos = context.method_8037();
        class_1799 stack = player.method_5998(hand);

        if (!(stack.method_7909() instanceof class_1747 blockItem)) {
            player.method_5783(Envelope.SoundEvents.UI_ERROR.get(), 0.75f, 1f);
            Envelope.LOGGER.error("Failed to place mailbox: item in hand is not a BlockItem, but {}", stack);
            return;
        }

        BlockAddressValidation.forMailbox(MailService.of(level).getKnownAddresses(), player)
              .test(addressId)
              .ifPresentOrElse(
                    id -> {
                        blockItem.method_7712(context);

                        if (!(level.method_8321(pos) instanceof MailboxBlockEntity blockEntity)) {
                            player.method_5783(Envelope.SoundEvents.UI_ERROR.get(), 0.75f, 1f);
                            Envelope.LOGGER.error("Failed to place mailbox: be at pos [{}] is not MailboxBlockEntity", pos.method_23854());
                            return;
                        }

                        blockEntity.method_11010().method_26204().method_9567(level, pos, blockEntity.method_11010(), player, stack);
                        applyAddress(player, blockEntity, new BlockAddress(id), stack);
                        player.method_23667(hand, true);
                    },
                    error -> {
                        player.method_7353(error.getTranslation(), true);
                        player.method_5783(Envelope.SoundEvents.UI_ERROR.get(), 0.75f, 1f);
                    });
    }

    private static void applyAddress(class_1657 player, MailboxBlockEntity blockEntity, BlockAddress address, class_1799 stack) {
        blockEntity.setAddress(address);

        if (Config.Server.MAILBOX_ADDRESS_EXPERIENCE_LEVELS_COST.get() > 0) {
            player.method_37908().method_45447(player, blockEntity.method_11016(), Envelope.SoundEvents.MAILBOX_CONNECT.get(), class_3419.field_15245);
        }

        if (!player.method_7337()) {
            player.method_7316(-Config.Server.MAILBOX_ADDRESS_EXPERIENCE_LEVELS_COST.get());
        }
    }

    // --

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new MailboxBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> blockEntityType) {
        return level.field_9236
              ? null
              : method_31618(blockEntityType, Envelope.BlockEntityTypes.MAILBOX.get(),
              (lvl, blockPos, blockState, blockEntity) -> blockEntity.serverTick(((class_3218) lvl), blockPos, state));
    }
}