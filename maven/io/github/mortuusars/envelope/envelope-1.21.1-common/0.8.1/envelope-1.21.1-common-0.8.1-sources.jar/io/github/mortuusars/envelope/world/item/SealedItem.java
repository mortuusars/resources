package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.block.PackageBlockEntity;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import io.github.mortuusars.envelope.world.item.component.seal.SealMaterial;
import io.github.mortuusars.mortaar.client.Minecrft;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5253;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface SealedItem {
    class_1935 getUnsealedItem();

    default class_3414 getUnsealingSound() {
        return Envelope.SoundEvents.PAPER_CRACKLE.get();
    }

    default class_3414 getUnsealFinishedSound() {
        return Envelope.SoundEvents.PAPER_TEAR.get();
    }

    default int getUnsealingDuration(class_1799 stack, class_1309 entity) {
        return Config.Server.SEAL_REMOVE_DURATION.get();
    }

    default boolean canRemoveSeal(class_1799 stack, class_1657 player) {
        if (stack.method_57824(Envelope.DataComponents.SEAL) instanceof Seal seal) {
            return seal.lock().map(lock -> !lock.isLockedFor(player)).orElse(true);
        }

        return true;
    }

    default @NotNull class_1271<class_1799> useSealedItem(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (!canRemoveSeal(stack, player)) {
            player.method_7353(class_2561.method_43471("gui.envelope.sealed_item.locked").method_27692(class_124.field_1061), true);
            player.method_43077(class_3417.field_37360);
            return class_1271.method_22431(stack);
        }

        player.method_6019(hand);
        return class_1271.method_22427(stack);
    }

    default class_1799 unsealByUsing(class_1799 stack, class_1937 level, @Nullable class_1309 entity) {
        if (entity instanceof class_1657 player && !canRemoveSeal(stack, player)) {
            return stack;
        }

        class_1799 unsealedStack = unseal(stack);
        onUnsealed(stack, unsealedStack, level, entity);
        return unsealedStack;
    }

    default class_1799 unseal(class_1799 stack) {
        class_1799 unsealedStack = stack.method_60503(getUnsealedItem());
        unsealedStack.method_57381(Envelope.DataComponents.SEAL);
        return unsealedStack;
    }

    default void onUnsealed(class_1799 stack, class_1799 unsealedStack, class_1937 level, @Nullable class_1309 entity) {
        if (entity != null) {
            @Nullable class_1657 player = entity instanceof class_1657 pl ? pl : null;
            level.method_43129(player, entity, getUnsealFinishedSound(), class_3419.field_15248, 1f,
                  level.method_8409().method_43057() * 0.1f + 0.8f);
        }

        if (level.method_8608()) {
            // Release use key after opening.
            // Otherwise, right click will be still held and will activate use again.
            Minecrft.releaseUseButton();
        }

        if (entity instanceof class_3222 serverPlayer) {
            serverPlayer.method_7281(Envelope.Stats.SEALS_BROKEN.get());
        }
    }

    // --

    class Client {
        public static int OVERLAY_DEFAULT_RED_COLOR = 0xFFCC4E47;
        public static int OVERLAY_LOCKED_HIGHLIGHT_COLOR = 0xFF18A2B6;
        public static int OVERLAY_GOLDEN_HIGHLIGHT_COLOR = 0xFFFFD16E;

        public static int getSealOverlayColor(class_1799 stack, int layer) {
            if (layer != 1) {
                return -1;
            }

            @Nullable Seal seal = stack.method_57824(Envelope.DataComponents.SEAL);
            if (seal != null) {
                return getSealOverlayColor(seal);
            }

            return OVERLAY_DEFAULT_RED_COLOR;
        }

        public static int getSealOverlayColor(class_2680 state, @Nullable class_1920 level, @Nullable class_2338 pos, int index) {
            if (index != 0) {
                return -1;
            }

            if (level != null && pos != null && level.method_8321(pos) instanceof PackageBlockEntity blockEntity) {
                @Nullable Seal seal = blockEntity.getPackage().method_57824(Envelope.DataComponents.SEAL);
                if (seal != null) {
                    return seal.material().comp_349().modelTintColor(); // Can't use tint animation on the block, they only calculate tint once
                }
            }

            return OVERLAY_DEFAULT_RED_COLOR;
        }

        public static int getSealOverlayColor(Seal seal) {
            int materialColor = seal.material().comp_349().modelTintColor();

            if (seal.lock().isPresent() && seal.lock().get().isLocked(Minecrft.level())) {
                double time = (Minecrft.level().method_8510() + Minecrft.get().method_60646().method_60637(true)) / 20.0;
                double beat = Math.pow((Math.sin(time * Math.PI * 2 * 1) + 1.0) * 0.5, 10);
                float delta = (float) class_3532.method_16436(beat, 0, 1);
                return class_5253.class_5254.method_48780(delta, materialColor, OVERLAY_LOCKED_HIGHLIGHT_COLOR);
            }

            if (seal.material().method_40225(SealMaterial.GOLD)) {
                double time = (Minecrft.level().method_8510() + Minecrft.get().method_60646().method_60637(true)) / 10f;
                double delta = (Math.sin(time) + 1.0) / 2.0;
                return class_5253.class_5254.method_48780((float)delta, materialColor, OVERLAY_GOLDEN_HIGHLIGHT_COLOR);
            }

            return materialColor;
        }
    }
}
