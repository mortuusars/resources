package io.github.mortuusars.envelope.test.cases;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.ServiceLetterMeaning;
import io.github.mortuusars.envelope.world.item.component.mail.DeliveryInfo;
import io.github.mortuusars.mortaar.Platform;
import io.github.mortuusars.mortaar.bugger.test.BuggerTests;
import io.github.mortuusars.mortaar.bugger.test.Test;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_3518;
import net.minecraft.class_3902;
import net.minecraft.class_9329;
import net.minecraft.class_9334;
import io.github.mortuusars.envelope.world.inventory.StackIngredient;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;

public class StackIngredientTests extends BuggerTests {
    public StackIngredientTests() {
        equality();
        itemMatching();
        tagMatching();
        componentMatching();
        matchingItemFromJson();
        matchingTagFromJson();
        matchingItemWithComponentsFromJson();
        matchingItemWithComponentsStrictFromJson();
    }

    private void equality() {
        StackIngredient ingredient = new StackIngredient(class_1802.field_8153, 3, class_9329.method_57862()
              .method_57872(class_9334.field_50076, class_3902.field_17274)
              .method_57871());

        StackIngredient ingredient2 = new StackIngredient(class_1802.field_8153, 3, class_9329.method_57862()
              .method_57872(class_9334.field_50076, class_3902.field_17274)
              .method_57871());

        add("StackIngredient_EqualsIfSame", Test.isTrue(player -> ingredient.equals(ingredient2)));
        add("StackIngredient_NotEqualsIfDifferent", Test.isFalse(player -> ingredient.equals(new StackIngredient(class_1802.field_8687, 23))));
    }

    private void itemMatching() {
        StackIngredient ingredient = new StackIngredient(class_1802.field_8153, 3);

        add("StackIngredient_ItemMatches_WhenSameCount", Test.isTrue(player -> ingredient.test(new class_1799(class_1802.field_8153, 3))));
        add("StackIngredient_ItemMatches_WhenMoreThanCount", Test.isTrue(player -> ingredient.test(new class_1799(class_1802.field_8153, 23))));
        add("StackIngredient_ItemMatches_WithRandomComponents", Test.isTrue(player -> ingredient.test(class_156.method_656(() -> {
            class_1799 stack = new class_1799(class_1802.field_8153, 3);
            stack.method_57379(class_9334.field_50076, class_3902.field_17274);
            return stack;
        }))));

        add("StackIngredient_ItemMatches_FailsWhenItemIsDifferent", Test.isFalse(player -> ingredient.test(new class_1799(class_1802.field_8360, 3))));
        add("StackIngredient_ItemMatches_FailsWhenCountIsLesser", Test.isFalse(player -> ingredient.test(new class_1799(class_1802.field_8153, 1))));
    }

    private void tagMatching() {
        StackIngredient ingredient = new StackIngredient(class_3489.field_15539, 12);

        add("StackIngredient_TagMatches_WithSameCount", Test.isTrue(player -> ingredient.test(new class_1799(class_1802.field_8583, 12))));
        add("StackIngredient_TagMatches_MoreThanCount", Test.isTrue(player -> ingredient.test(new class_1799(class_1802.field_8583, 30))));
        add("StackIngredient_TagMatches_WithRandomComponents", Test.isTrue(player -> ingredient.test(class_156.method_656(() -> {
            class_1799 stack = new class_1799(class_1802.field_8583, 12);
            stack.method_57379(class_9334.field_50076, class_3902.field_17274);
            return stack;
        }))));

        add("StackIngredient_TagMatches_FailsWhenItemIsDifferent", Test.isFalse(player -> ingredient.test(new class_1799(class_1802.field_8360, 20))));
        add("StackIngredient_TagMatches_FailsWhenCountIsLesser", Test.isFalse(player -> ingredient.test(new class_1799(class_1802.field_8583, 5))));
    }

    private void componentMatching() {
        StackIngredient ingredient = new StackIngredient(class_1802.field_8153, 3,
              class_9329.method_57862()
                    .method_57872(Envelope.DataComponents.MAIL_DELIVERY_INFO, DeliveryInfo.create().sender(MailService.of(Platform.getCurrentServerOrThrow().method_30002()).getAddress()).immutable())
                    .method_57872(class_9334.field_50076, class_3902.field_17274)
                    .method_57871());

        class_1799 stack = new class_1799(class_1802.field_8153, 3);
        stack.method_57379(Envelope.DataComponents.MAIL_DELIVERY_INFO, DeliveryInfo.create().sender(MailService.of(Platform.getCurrentServerOrThrow().method_30002()).getAddress()).immutable());
        stack.method_57379(class_9334.field_50076, class_3902.field_17274);
        add("StackIngredient_ComponentMatches", Test.isTrue(player -> ingredient.test(stack)));

        class_1799 stack2 = stack.method_7972();
        stack2.method_57381(Envelope.DataComponents.MAIL_DELIVERY_INFO);
        add("StackIngredient_ComponentMatches_failsWhenMissing", Test.isFalse(player -> ingredient.test(stack2)));
    }

    private void matchingItemFromJson() {
        add("StackIngredient_MatchesItemFromJson",
              Test.isTrue(player -> decodeFromJson("{\"item\":\"minecraft:emerald\"}").test(new class_1799(class_1802.field_8687))));
        add("StackIngredient_MatchesItemFromJson_failsWhenCountIsLesser",
              Test.isFalse(player -> decodeFromJson("{\"item\":\"minecraft:emerald\",\"count\":5}").test(new class_1799(class_1802.field_8687))));
    }

    private void matchingItemWithComponentsFromJson() {
        String json = """
              {
                "item": "minecraft:emerald",
                "count": 3,
                "components": {
                  "minecraft:fire_resistant": {},
                  "envelope:mail_delivery_info": {
                      "sender": {
                          "type": "service",
                          "definition": "envelope:mail_service"
                      }
                  },
                  "envelope:mail_address_tag": {
                      "type": "block",
                      "id": "Mortuusars Laboratory"
                  }
                }
              }
              """;
        add("StackIngredient_MatchesItemWithComponentsFromJson",
              Test.isTrue(player -> {
                  class_1799 stack = new class_1799(class_1802.field_8687, 3);
                  stack.method_57379(class_9334.field_50076, class_3902.field_17274);
                  stack.method_57379(Envelope.DataComponents.MAIL_DELIVERY_INFO, DeliveryInfo.create().sender(MailService.of(Platform.getCurrentServerOrThrow().method_30002()).getAddress()).immutable());
                  stack.method_57379(Envelope.DataComponents.MAIL_ADDRESS_TAG, new BlockAddress("Mortuusars Laboratory"));
                  return decodeFromJson(json).test(stack);
              }));
    }

    private void matchingItemWithComponentsStrictFromJson() {
        String json = """
              {
                "item": "minecraft:emerald",
                "count": 3,
                "components": {
                  "minecraft:fire_resistant": {},
                  "envelope:mail_delivery_info": {
                      "sender": {
                          "type": "service",
                          "definition": "envelope:mail_service"
                      }
                  },
                  "envelope:mail_address_tag": {
                      "type": "block",
                      "id": "Mortuusars Laboratory"
                  }
                },
                "strict": true
              }
              """;
        add("StackIngredient_MatchesItemWithComponentsStrictFromJson",
              Test.isTrue(player -> {
                  class_1799 stack = new class_1799(class_1802.field_8687, 3);
                  stack.method_57379(class_9334.field_50076, class_3902.field_17274);
                  stack.method_57379(Envelope.DataComponents.MAIL_DELIVERY_INFO, DeliveryInfo.create().sender(MailService.of(Platform.getCurrentServerOrThrow().method_30002()).getAddress()).immutable());
                  stack.method_57379(Envelope.DataComponents.MAIL_ADDRESS_TAG, new BlockAddress("Mortuusars Laboratory"));
                  return decodeFromJson(json).test(stack);
              }));

        add("StackIngredient_MatchesItemWithComponentsStrictFromJson_Fails_with_less",
              Test.isFalse(player -> {
                  class_1799 stack = new class_1799(class_1802.field_8687, 3);
                  stack.method_57379(class_9334.field_50076, class_3902.field_17274);
                  stack.method_57379(Envelope.DataComponents.MAIL_DELIVERY_INFO, DeliveryInfo.create().sender(MailService.of(Platform.getCurrentServerOrThrow().method_30002()).getAddress()).immutable());
                  return decodeFromJson(json).test(stack);
              }));

        add("StackIngredient_MatchesItemWithComponentsStrictFromJson_Fails_with_additional",
              Test.isFalse(player -> {
                  class_1799 stack = new class_1799(class_1802.field_8687, 3);
                  stack.method_57379(class_9334.field_50076, class_3902.field_17274);
                  stack.method_57379(Envelope.DataComponents.MAIL_DELIVERY_INFO, DeliveryInfo.create().sender(MailService.of(Platform.getCurrentServerOrThrow().method_30002()).getAddress()).immutable());
                  stack.method_57379(Envelope.DataComponents.MAIL_ADDRESS_TAG, new BlockAddress("Mortuusars Laboratory"));
                  stack.method_57379(Envelope.DataComponents.SERVICE_LETTER_MEANING, new ServiceLetterMeaning(class_2960.method_60654("asd:123")));
                  return decodeFromJson(json).test(stack);
              }));
    }

    private void matchingTagFromJson() {
        add("StackIngredient_MatchesTagFromJson",
              Test.isTrue(player -> decodeFromJson("{\"item\":\"#minecraft:planks\"}").test(new class_1799(class_1802.field_8191))));
        add("StackIngredient_MatchesTagFromJson_FailsWhenCountIsLesser",
              Test.isFalse(player -> decodeFromJson("{\"item\":\"#minecraft:planks\",\"count\":5}").test(new class_1799(class_1802.field_8191))));
    }

    private StackIngredient decodeFromJson(String json) {
        JsonObject obj = class_3518.method_15285(json);
        return StackIngredient.CODEC.parse(Platform.getCurrentServerOrThrow().method_30611().method_57093(JsonOps.INSTANCE), obj)
              .getOrThrow();
    }
}
