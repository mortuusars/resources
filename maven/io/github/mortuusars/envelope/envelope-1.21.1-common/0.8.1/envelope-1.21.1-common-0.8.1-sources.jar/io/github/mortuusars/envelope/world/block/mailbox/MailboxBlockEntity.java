package io.github.mortuusars.envelope.world.block.mailbox;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.packet.clientbound.ClientboundMailboxHasNewMailPacket;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.entity.CourierBat;
import io.github.mortuusars.envelope.world.mail.delivery.CourierOrigin;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import io.github.mortuusars.envelope.world.inventory.MailboxMenu;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.address.SimpleBlockAddressGenerator;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import io.github.mortuusars.envelope.world.mail.delivery.PhysicalCourier;
import io.github.mortuusars.mortaar.Platform;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.*;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1278;
import net.minecraft.class_1420;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2624;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_7225;

public class MailboxBlockEntity extends class_2624 implements Inbox, class_1278 {
    public static final int REGULAR_SLOTS = 3;
    public static final int SLOT_MAIL = 0;
    public static final int SLOT_PIGEON_FOOD = 1;
    public static final int SLOT_BAT_FOOD = 2;
    public static final int SLOT_INBOX = REGULAR_SLOTS;

    public static final int[] ALL_SLOTS = new int[]{0, 1, 2, 3};

    protected static final Logger LOGGER = LogUtils.getLogger();

    protected class_2371<class_1799> items = class_2371.method_10213(REGULAR_SLOTS, class_1799.field_8037);
    protected @NotNull UUID inboxId = UUID.randomUUID();
    protected @Nullable BlockAddress address;
    protected @Nullable UUID owner;
    protected @NotNull List<class_1799> mail = new ArrayList<>();
    protected boolean loaded = false;
    protected boolean blockRemoved = false;
    protected int batEmployCooldown;
    protected int batEmployAttempt;
    protected boolean deliveredWithPigeon;
    protected boolean deliveredWithBat;

    protected MailboxBlockEntity(class_2591<?> type, class_2338 pos, class_2680 blockState) {
        super(type, pos, blockState);
    }

    public MailboxBlockEntity(class_2338 pos, class_2680 blockState) {
        this(Envelope.BlockEntityTypes.MAILBOX.get(), pos, blockState);
    }

    @Override
    protected @NotNull class_2561 method_17823() {
        return address != null
              ? address.getComponent()
              : class_2561.method_43471("container.envelope.mailbox");
    }

    // -- Address

    public @NotNull BlockAddress getAddress() {
        return Preconditions.checkNotNull(address,
              "Address of mailbox at [" + method_11016().method_23854() + "] was not set.");
    }

    public void setAddress(@Nullable BlockAddress address) {
        @Nullable BlockAddress currentAddress = this.address;
        this.address = address;

        if (method_10997() instanceof class_3218 serverLevel && MailService.operatesIn(serverLevel)) {
            address = Objects.requireNonNullElseGet(address, () -> generateRandomAddress(serverLevel));
            address = MailService.of(serverLevel).getMailboxes().correctOrRegisterIfNeeded(address, method_11016());

            if (!address.equals(currentAddress)) {
                this.address = address;
                method_5431();
                // Syncs address to the client:
                serverLevel.method_8413(method_11016(), method_11010(), method_11010(), MailboxBlock.field_31036);
            }
        }
    }

    protected void applyAddress() {
        setAddress(this.address);
    }

    protected @NotNull BlockAddress generateRandomAddress(class_3218 level) {
        return new SimpleBlockAddressGenerator(MailService.of(level).getKnownAddresses(), 50).generate(level.method_8409());
    }

    // -- Owner

    public @Nullable UUID getOwner() {
        return owner;
    }

    public void setOwner(@Nullable UUID owner) {
        this.owner = owner;
        method_5431();
    }

    public Optional<class_1657> getOwnerPlayer() {
        if (owner == null || field_11863 == null) return Optional.empty();
        for (class_1657 player : field_11863.method_18456()) {
            if (player.method_5667().equals(owner)) {
                return Optional.of(player);
            }
        }
        return Optional.empty();
    }

    // -- Container

    @Override
    protected @NotNull class_2371<class_1799> method_11282() {
        return items;
    }

    @Override
    protected void method_11281(class_2371<class_1799> items) {
        this.items = items;
    }

    @Override
    public int method_5439() {
        return REGULAR_SLOTS + getAllMail().size();
    }

    @Override
    public @NotNull class_1799 method_5438(int slot) {
        if (slot >= SLOT_INBOX) {
            return getMail(slot - SLOT_INBOX);
        }
        return super.method_5438(slot);
    }

    public class_1799 getPigeonFoodItem() {
        return method_5438(SLOT_PIGEON_FOOD);
    }

    public class_1799 getBatFoodItem() {
        return method_5438(SLOT_BAT_FOOD);
    }

    @Override
    public @NotNull class_1799 method_5434(int slot, int amount) {
        if (slot >= SLOT_INBOX) {
            return removeMail(slot - SLOT_INBOX);
        }
        return super.method_5434(slot, amount);
    }

    @Override
    public @NotNull class_1799 method_5441(int slot) {
        if (slot >= SLOT_INBOX) {
            return removeMailNoUpdate(slot - SLOT_INBOX);
        }
        return super.method_5441(slot);
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        if (slot >= SLOT_INBOX) {
            addMail(slot - SLOT_INBOX, stack);
            return;
        }
        super.method_5447(slot, stack);
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        if (slot == SLOT_MAIL) return isSendable(stack);
        if (slot == SLOT_PIGEON_FOOD) return stack.method_31573(Envelope.Tags.Items.PIGEON_FOOD);
        if (slot == SLOT_BAT_FOOD) return stack.method_31573(Envelope.Tags.Items.BAT_FOOD);
        return false;
    }

    @Override
    public boolean method_49104(class_1263 target, int slot, class_1799 stack) {
        return slot >= SLOT_INBOX
              && target.method_43256(class_1799::method_7960); // Prevents hoppers from removing the item and placing it back
    }

    // -- WorldlyContainer

    @Override
    public int @NotNull [] method_5494(@NotNull class_2350 face) {
        return ALL_SLOTS;
    }

    @Override
    public boolean method_5492(int index, @NotNull class_1799 itemStack, @Nullable class_2350 direction) {
        if (direction == class_2350.field_11033)
            return false;
        return method_5437(index, itemStack);
    }

    @Override
    public boolean method_5493(int index, @NotNull class_1799 pStack, @NotNull class_2350 direction) {
        return index == SLOT_INBOX;
    }

    // -- Mailbox Container

    public boolean isSendable(class_1799 stack) {
        return !stack.method_7960() && stack.method_31573(Envelope.Tags.Items.MAILABLE) && stack.method_57826(Envelope.DataComponents.MAIL_ADDRESS_TAG);
    }

    public boolean isAvailableForPickup() {
        if (field_11863 == null) return false;
        return method_11010().method_11654(MailboxBlock.OPEN);
        // isSendable(getItem(SLOT_MAIL)) && !(level.isDay() ? getPigeonFoodItem() : getBatFoodItem()).isEmpty();
    }

    @Override
    protected @NotNull class_1703 method_5465(int containerId, class_1661 inventory) {
        applyAddress();
        return new MailboxMenu(containerId, inventory, method_11016(), getAddress(), getAllMail());
    }

    public void openMenu(class_1657 player) {
        if (player instanceof class_3222 serverPlayer) {
            if (getOwner() == null) {
                setOwner(player.method_5667());
            }

            Platform.openMenu(serverPlayer, this, buffer -> {
                buffer.method_10807(method_11016());
                BlockAddress.STREAM_CODEC.encode(buffer, getAddress());
                class_1799.field_48350.encode(buffer, getAllMail());
            });
            playSound(Envelope.SoundEvents.MAILBOX_OPEN.get(), 0.6f, 1.1f);
        }
    }

    @Override
    public void method_5448() {
        super.method_5448();
        mail.clear();
    }

    // -- Delivery

    public boolean tryStartDelivery(PhysicalCourier courier) {
        //noinspection PatternVariableHidesField
        if (!(method_10997() instanceof class_3218 level) || !MailService.operatesIn(level)) {
            return false;
        }

        if (courier.isDelivering()) return false;
        class_1799 mailStack = method_5438(SLOT_MAIL);
        if (!isSendable(mailStack)) return false;

        applyAddress();

        class_1799 mail = Mail.removePreviousDeliveryData(mailStack.method_46651(1));

        MailService.of(level).getDeliveryManager()
              .start(courier, Delivery.draft()
                    .deliver(mail)
                    .from(getAddress())
                    .to(Mail.getRecipientOrUnknown(mail))
                    .owner(getOwner()));

        method_5434(SLOT_MAIL, 1);
        method_5434(level.method_8530() ? SLOT_PIGEON_FOOD : SLOT_BAT_FOOD, 1);

        class_243 pos = courier.asEntity().method_19538();
        level.method_14199(class_2398.field_11204, pos.field_1352, pos.field_1351, pos.field_1350, 10, 0.3, 0.3, 0.3, 0.02);
        level.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, Envelope.SoundEvents.COURIER_MAIL_PICKUP.get(), class_3419.field_15254, 1f, 1.3f);

        if (courier.asEntity().method_5864().equals(Envelope.EntityTypes.PIGEON.get())) {
            deliveredWithPigeon = true;
        } else if (courier.asEntity().method_5864().equals(Envelope.EntityTypes.COURIER_BAT.get())) {
            deliveredWithBat = true;
        }

        if (deliveredWithPigeon && deliveredWithBat) {
            getOwnerPlayer().ifPresent(player -> {
                if (player instanceof class_3222 serverPlayer) {
                    Envelope.CriteriaTriggers.DELIVER_WITH_PIGEON_AND_BAT.get().method_9141(serverPlayer);
                }
            });
        }

        return true;
    }

    // -- Inbox

    @Override
    public int getInboxCapacity() {
        return 512;
    }

    @Override
    public @NotNull List<class_1799> getAllMail() {
        return mail;
    }

    @Override
    public void onMailInserted(class_1799 mail) {
        playSound(Envelope.SoundEvents.MAILBOX_MAIL_RECEIVE.get(), 1, 1);
    }

    @Override
    public void onMailAdded(class_1799 mail) {
        if (field_11863 instanceof class_3218 serverLevel) {
            MailboxMenu.playersWithMenu(serverLevel, getAddress())
                  .forEach(ClientboundMailboxHasNewMailPacket.INSTANCE::sendToClient);
        }
    }

    @Override
    public void onMailRemoved(int slot, class_1799 mail) {
        if (field_11863 instanceof class_3218 serverLevel) {
            MailboxMenu.executeForPlayersWithMenu(serverLevel, getAddress(), (player, menu) -> menu.onMailRemoved(slot));
        }
    }

    @Override
    public void onInboxChanged() {
        method_5431();
        if (field_11863 != null) {
            field_11863.method_8455(method_11016(), method_11010().method_26204());
        }
    }

    // As inbox can be quite large in size, we cannot store it as regular block entity data.
    // So we use dedicated inbox storage for that, and load/unload each time block entity is being loaded/unloaded.

    public void loadInbox() {
        if (field_11863 instanceof class_3218 serverLevel && !inboxId.equals(class_156.field_25140)) {
            //noinspection ConstantValue
            if (serverLevel.method_8503().method_30002() == null) {
                LOGGER.error("Cannot load inbox of mailbox {}. Overworld level is not loaded yet.\n" +
                      "If mailbox is on a sable sub-level and '/sable forceload' is used to keep it loaded - avoid this approach until https://github.com/ryanhcode/sable/issues/1633 is resolved.", address);
                return; // InboxStorage.get(serverLevel) will throw NullPointer
            }

            mail = InboxStorage.get(serverLevel).remove(inboxId)
                  .map(Inbox::getAllMail)
                  .orElseGet(ArrayList::new);
        } else {
            mail = new ArrayList<>();
        }
    }

    public void unloadInbox() {
        if (field_11863 instanceof class_3218 serverLevel && address != null && !inboxId.equals(class_156.field_25140)) {
            InboxStorage.get(serverLevel).put(inboxId, this);
        }
        mail.clear();
    }

    // -- Events

    public void serverTick(class_3218 level, class_2338 pos, class_2680 state) {
        if (!loaded) {
            onLoaded();
            loaded = true;
        }

        updateBlockStateIfNeeded();
        maybeEmployBat(level, pos);
    }

    protected boolean maybeEmployBat(class_3218 level, class_2338 pos) {
        batEmployCooldown--;

        if (batEmployCooldown > 0
              || !level.method_23886()
              || level.method_8419()
              || level.method_8546()
              || !isAvailableForPickup()
              || getBatFoodItem().method_7960()
              || level.method_8409().method_43048(Math.max(1, Config.Server.BAT_EMPLOY_INTERVAL.get() - batEmployAttempt++)) != 0) {
            return false;
        }

        @Nullable CourierBat bat = null;

        List<class_1420> batsNearby = level.method_8390(class_1420.class, new class_238(pos).method_1014(32), b -> !b.method_29504() && !b.method_31481());
        if (!batsNearby.isEmpty()) {
            class_1420 regularBat = class_156.method_32309(batsNearby, level.method_8409());
            @Nullable CourierBat courierBat = regularBat.method_29243(Envelope.EntityTypes.COURIER_BAT.get(), false);
            if (courierBat != null) {
                courierBat.setOrigin(CourierOrigin.regular(pos));
                bat = courierBat;
            }
        }

        if (bat == null
              && Config.Server.BAT_SUMMONED_TO_MAILBOX_IF_NONE_NEARBY.get()
              && (Config.Server.BAT_MAILBOX_SUMMON_IGNORES_DOMOBSPAWNING.get() || level.method_8450().method_8355(class_1928.field_19390))) {
            class_2338 spawnPos = Position.ascendTowards(level, pos, Optional.empty(),
                  Config.Server.DELIVERY_ASCEND_DISTANCE.get(), level.method_8409().method_43054());
            bat = Envelope.EntityTypes.COURIER_BAT.get().method_47821(level, spawnPos, class_3730.field_16459);
            if (bat != null) {
                bat.setSpawnPos(spawnPos);
                bat.onAppeared(level);
            }
        }

        if (bat != null) {
            bat.getMailboxHandler().setTargetPos(pos);
            batEmployCooldown = Config.Server.BAT_EMPLOY_COOLDOWN.get();
            batEmployAttempt = 0;
            return true;
        }

        return false;
    }

    protected void onLoaded() {
        applyAddress();
        if (field_11863 != null) {
            field_11863.method_8455(method_11016(), method_11010().method_26204());
        }
    }

    public void onBlockRemoved(class_1937 level, class_2338 pos, class_2680 state, class_2680 newState) {
        blockRemoved = true;
        class_1264.method_54291(state, newState, level, pos);
        clearMail();
    }

    @Override
    public void method_10996() {
        super.method_10996();
        loadInbox();
        blockRemoved = false;
    }

    @Override
    public void method_11012() {
        super.method_11012();
        if (!blockRemoved) {
            unloadInbox();
        }
    }

    @Override
    public void method_5431() {
        super.method_5431();
        updateBlockStateIfNeeded();
    }

    private void updateBlockStateIfNeeded() {
        if (!blockRemoved && !method_11015() && field_11863 instanceof class_3218 serverLevel) {
            class_2680 state = method_11010();
            boolean isOpen = state.method_11654(MailboxBlock.OPEN);
            boolean hasMail = state.method_11654(MailboxBlock.HAS_MAIL);

            boolean shouldBeOpen = !(field_11863.method_8530() ? getPigeonFoodItem() : getBatFoodItem()).method_7960() && isSendable(method_5438(SLOT_MAIL));
            boolean shouldHaveMail = !getAllMail().isEmpty();

            if (isOpen != shouldBeOpen || hasMail != shouldHaveMail) {
                serverLevel.method_8501(method_11016(), state
                      .method_11657(MailboxBlock.OPEN, shouldBeOpen)
                      .method_11657(MailboxBlock.HAS_MAIL, shouldHaveMail));

                if (isOpen != shouldBeOpen) {
                    playSound(shouldBeOpen ? Envelope.SoundEvents.MAILBOX_HATCH_OPEN.get() : Envelope.SoundEvents.MAILBOX_HATCH_CLOSE.get(),
                          0.75f, shouldBeOpen ? 1f : 0.75f);
                }
            }
        }
    }

    // -- Sync

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public @NotNull class_2487 method_16887(class_7225.class_7874 registries) {
        return method_58692(registries);
    }

    // -- Loading/Saving

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        class_1262.method_5426(tag, items, registries);
        if (address != null) tag.method_10582("address", address.getString());
        if (owner != null) tag.method_25927("owner", owner);
        if (!inboxId.equals(class_156.field_25140)) tag.method_25927("inbox_id", inboxId);
        if (batEmployCooldown > 0) tag.method_10569("bat_employ_cooldown", batEmployCooldown);
        if (batEmployAttempt > 0) tag.method_10569("bat_employ_attempt", batEmployCooldown);
        if (deliveredWithPigeon) tag.method_10556("delivered_with_pigeon", true);
        if (deliveredWithBat) tag.method_10556("delivered_with_bat", true);
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        class_1262.method_5429(tag, items, registries);
        setAddress(tag.method_10573("address", class_2520.field_33258) ? new BlockAddress(tag.method_10558("address")) : null);
        owner = tag.method_25928("owner") ? tag.method_25926("owner") : null;
        inboxId = tag.method_25928("inbox_id") ? tag.method_25926("inbox_id") : UUID.randomUUID();
        batEmployCooldown = tag.method_10550("bat_employ_cooldown");
        batEmployAttempt = tag.method_10550("bat_employ_attempt");
        deliveredWithPigeon = tag.method_10577("delivered_with_pigeon");
        deliveredWithBat = tag.method_10577("delivered_with_bat");
    }

    // -- Util

    public void playSound(class_3414 soundEvent, float volume, float pitch) {
        if (field_11863 != null) {
            field_11863.method_8396(null, method_11016(), soundEvent, class_3419.field_15245, volume, pitch);
        }
    }
}
