package io.github.mortuusars.envelope.world.item.mail;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.world.inventory.ContainerUtils;
import io.github.mortuusars.envelope.world.item.PackageItem;
import io.github.mortuusars.envelope.world.item.component.*;
import io.github.mortuusars.envelope.world.item.component.mail.DeliveryInfo;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryLog;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.item.tooltip.MailAddressTagTooltip;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.mortaar.world.item.tooltip.CompositeTooltip;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_437;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5536;
import net.minecraft.class_5632;
import net.minecraft.class_9297;
import net.minecraft.class_9334;

public final class Mail {
    private Mail() {
    }

    // -- Address

    public static Optional<Address> getSender(class_1799 stack) {
        return DeliveryInfo.of(stack).sender();
    }

    public static @NotNull Address getSenderOrElse(class_1799 stack, Address orElse) {
        return getSender(stack).orElse(orElse);
    }

    public static @NotNull Address getSenderOrUnknown(class_1799 stack) {
        return getSenderOrElse(stack, Address.UNKNOWN);
    }

    public static void setSender(@NotNull class_1799 stack, @Nullable Address sender) {
        DeliveryInfo.of(stack).mutable().sender(sender).immutableApplyTo(stack);
    }

    public static Optional<Address> getRecipient(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.MAIL_ADDRESS_TAG));
    }

    public static @NotNull Address getRecipientOrElse(class_1799 stack, Address orElse) {
        return stack.method_57825(Envelope.DataComponents.MAIL_ADDRESS_TAG, orElse);
    }

    public static @NotNull Address getRecipientOrUnknown(class_1799 stack) {
        return getRecipientOrElse(stack, Address.UNKNOWN);
    }

    public static class_1799 setRecipient(@NotNull class_1799 stack, @Nullable Address recipient) {
        stack.method_57379(Envelope.DataComponents.MAIL_ADDRESS_TAG, recipient);
        return stack;
    }

    // -- Payback

    public static class_1799 setPaybackRequest(@NotNull class_1799 stack, @Nullable PaybackRequest request) {
        stack.method_57379(Envelope.DataComponents.MAIL_PAYBACK_TAG, request);
        return stack;
    }

    // -- Returned

    public static boolean isReturned(class_1799 stack) {
        return DeliveryInfo.of(stack).isReturned();
    }

    public static class_1799 setReturned(class_1799 stack, boolean returned) {
        DeliveryInfo.of(stack).mutable().returned(returned).immutableApplyTo(stack);
        return stack;
    }

    public static class_1799 setReturned(class_1799 stack) {
        return setReturned(stack, true);
    }

    public static class_1799 returned(class_1799 mail, class_2561 message) {
        if (mail.method_7960()) {
            return mail;
        }
        writeToLog(mail, DeliveryRecord.returned(message));
        setReturned(mail);
        return mail;
    }

    // -- Log

    public static DeliveryLog getLog(class_1799 stack) {
        return DeliveryInfo.of(stack).log();
    }

    public static class_1799 setLog(class_1799 stack, DeliveryLog log) {
        return DeliveryInfo.of(stack).mutable().setLog(log).immutableApplyTo(stack);
    }

    public static class_1799 writeToLog(class_1799 stack, DeliveryRecord record) {
        return DeliveryInfo.of(stack).mutable().updateLog(log -> log.append(record)).immutableApplyTo(stack);
    }

    public static class_1799 writeToLog(class_1799 stack, DeliveryRecord... records) {
        return DeliveryInfo.of(stack).mutable().updateLog(log -> log.append(records)).immutableApplyTo(stack);
    }

    // --

    public static class_1799 removePreviousDeliveryData(class_1799 mail) {
        if (mail.method_7960()) return class_1799.field_8037;

        mail.method_57381(Envelope.DataComponents.MAIL_DELIVERY_INFO);

        return mail;
    }

    public static class_1799 removeAllDeliveryData(class_1799 mail) {
        if (mail.method_7960()) return class_1799.field_8037;

        mail.method_57381(Envelope.DataComponents.MAIL_ADDRESS_TAG);
        mail.method_57381(Envelope.DataComponents.MAIL_PAYBACK_TAG);
        return removePreviousDeliveryData(mail);
    }

    public static class_1799 asDelivered(class_1799 mail) {
        if (mail.method_7960()) return class_1799.field_8037;

        if (!isReturned(mail)) {
            DeliveryInfo.of(mail).mutable().recipient(mail.method_57824(Envelope.DataComponents.MAIL_ADDRESS_TAG)).immutableApplyTo(mail);
            mail.method_57381(Envelope.DataComponents.MAIL_ADDRESS_TAG);
            mail.method_57381(Envelope.DataComponents.MAIL_PAYBACK_TAG);
        }

        return mail;
    }

    // --

    public static MailBuilder<?> of(class_1799 stack) {
        return new MailBuilder<>(stack);
    }

    public static MailBuilder<?> of(class_1935 item) {
        return of(new class_1799(item));
    }

    public static MailBuilder<?> of(Supplier<? extends class_1935> item) {
        return of(new class_1799(item.get()));
    }

    public static MailBuilder<?> createPackage(PackageContents contents) {
        return new MailBuilder<>(Envelope.Items.PACKAGE.get())
              .set(Envelope.DataComponents.PACKAGE_CONTENTS, contents);
    }

    public static MailBuilder<?> createPackage(class_5321<class_52> lootTable) {
        return new MailBuilder<>(Envelope.Items.PACKAGE.get())
              .set(class_9334.field_49626, new class_9297(lootTable, 0L));
    }

    public static MailBuilder<?> createSealedPackage(PackageContents contents) {
        return new MailBuilder<>(Envelope.Items.SEALED_PACKAGE.get())
              .set(Envelope.DataComponents.PACKAGE_CONTENTS, contents);
    }

    public static MailBuilder<?> createSealedPackage(class_5321<class_52> lootTable) {
        return new MailBuilder<>(Envelope.Items.SEALED_PACKAGE.get())
              .set(class_9334.field_49626, new class_9297(lootTable, 0L));
    }

    /**
     * Splits items into packages, however many are required to fit all items.
     *
     * @param builder callback for each package builder, allows setting necessary data for each created package.
     */
    public static List<class_1799> createPackages(List<class_1799> items, Consumer<MailBuilder<?>> builder) {
        items = new ArrayList<>(items.stream().filter(stack -> !stack.method_7960()).toList()); // Non-empty and ensure mutability
        if (items.isEmpty()) return List.of();

        // Separate items that are already a package:
        List<class_1799> packages = new ArrayList<>();
        items.removeIf(stack -> {
            if (stack.method_7909() instanceof PackageItem) {
                packages.add(Mail.of(stack).apply(builder).itemStack());
                return true;
            }
            return false;
        });

        List<class_1799> packedPackages = ContainerUtils.split(ContainerUtils.compact(items), PackageContents.SLOTS)
              .stream()
              .map(PackageContents::new)
              .map(contents -> Mail.createPackage(contents).apply(builder).itemStack())
              .toList();

        return Stream.concat(packages.stream(), packedPackages.stream()).toList();
    }

    public static MailBuilder<?> createPaybackBox(PaybackSubject subject) {
        return new MailBuilder<>(Envelope.Items.PAYBACK_BOX.get())
              .set(Envelope.DataComponents.PAYBACK_SUBJECT, subject);
    }

    // --

    public static boolean handleShearsUse(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player) {
        if (action != class_5536.field_27014) return false;
        if (!slot.method_32754(player)) return false;
        if (!slot.method_7677().method_31573(Envelope.Tags.Items.MAILABLE)) return false;

        class_1799 result = removePreviousDeliveryData(slot.method_7677().method_7972());

        if (!class_1799.method_31577(slot.method_7677(), result)) {
            slot.method_53512(result);
            stack.method_7970(1, player, class_1304.field_6173);
            player.method_5783(class_3417.field_14975, 0.75f, 1f);
        } else {
            player.method_5783(Envelope.SoundEvents.UI_ACTION_BLOCKED.get(), 0.75f, 1f);
        }

        return true;
    }

    public static Optional<class_5632> modifyTooltipImage(class_1799 stack, Optional<class_5632> original) {
        if (stack.method_31573(Envelope.Tags.Items.MAILABLE)) {
            return CompositeTooltip.of(
                  original,
                  Optional.ofNullable(stack.method_57824(Envelope.DataComponents.MAIL_ADDRESS_TAG)).map(MailAddressTagTooltip::new),
                  Optional.ofNullable(stack.method_57824(Envelope.DataComponents.MAIL_PAYBACK_TAG))
            );
        }

        return original;
    }

    public static void appendTooltipLines(class_1799 stack, Consumer<class_2561> consumer,
                                          class_1792.class_9635 context, class_1657 player, class_1836 tooltipFlag) {
        DeliveryInfo deliveryInfo = DeliveryInfo.of(stack);
        if (!deliveryInfo.isEmpty()) {
            if (class_437.method_25442() && !deliveryInfo.log().isEmpty()) {
                consumer.accept(class_2561.method_43471("gui.envelope.delivery_log"));
                for (DeliveryRecord record : deliveryInfo.log().records()) {
                    consumer.accept(record.getDisplayComponent());
                }
            } else {
                deliveryInfo.sender().ifPresent(sender -> {
                    consumer.accept(class_2561.method_43469("gui.envelope.mail.from", sender.format().asSender().toComponent())
                          .method_27692(class_124.field_1080));
                });

                deliveryInfo.recipient().ifPresent(recipient -> {
                    consumer.accept(class_2561.method_43469("gui.envelope.mail.to", recipient.format().asRecipient().toComponent())
                          .method_27692(class_124.field_1080));
                });

                if (deliveryInfo.isReturned()) {
                    consumer.accept(class_2561.method_43471("gui.envelope.mail.returned")
                          .method_54663(Colors.TOOLTIP_RED));
                }
            }
        }
    }
}
