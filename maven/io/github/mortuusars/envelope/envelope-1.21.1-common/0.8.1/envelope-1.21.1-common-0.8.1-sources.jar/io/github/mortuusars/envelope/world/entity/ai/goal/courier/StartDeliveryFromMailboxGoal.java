package io.github.mortuusars.envelope.world.entity.ai.goal.courier;

import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlockEntity;
import io.github.mortuusars.envelope.world.entity.ai.CourierNavigation;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.delivery.PhysicalCourier;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_2338;

public class StartDeliveryFromMailboxGoal extends class_1352 {
    private final PhysicalCourier courier;

    public StartDeliveryFromMailboxGoal(PhysicalCourier courier) {
        this.courier = courier;
        method_6265(EnumSet.of(class_4134.field_18405));
    }

    @Override
    public boolean method_6264() {
        if (!MailService.operatesIn(courier.asEntity().method_37908()) || courier.isDelivering() || !courier.canStartDelivery()) {
            return false;
        }

        @Nullable class_2338 pos = courier.getMailboxHandler().getTargetPos();

        return pos != null
              && courier.closerThan(pos, CourierNavigation.getReachDistance() * 1.2f)
              && courier.asEntity().method_37908().method_8321(pos) instanceof MailboxBlockEntity blockEntity
              && blockEntity.isAvailableForPickup();
    }

    @Override
    public boolean method_6266() {
        return false;
    }

    @Override
    public void method_6269() {
        courier.getMailboxHandler().getMailboxAtCurrentPos(courier.asEntity().method_37908())
              .ifPresent(blockEntity -> {
                  blockEntity.tryStartDelivery(courier);
                  courier.getMailboxHandler().setTargetPos(null);
              });
    }
}
