package io.github.mortuusars.envelope.client.gui.tooltip;

import io.github.mortuusars.envelope.EnvelopeClient;
import io.github.mortuusars.mortaar.client.Minecrft;
import io.github.mortuusars.envelope.world.item.component.seal.SealSymbol;
import io.github.mortuusars.envelope.world.item.component.seal.ShadingPalette;
import io.github.mortuusars.mortaar.resources.Resource;
import java.util.Optional;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5321;
import net.minecraft.class_5684;
import net.minecraft.class_9791;

public class SealDieTooltipComponent implements class_5684 {
    protected final SealSymbol symbol;

    public SealDieTooltipComponent(SealSymbol symbol) {
        this.symbol = symbol;
    }

    public SealDieTooltipComponent(Optional<class_9791<SealSymbol>> symbolHolder) {
        this(getSymbol(symbolHolder));
    }

    private static SealSymbol getSymbol(Optional<class_9791<SealSymbol>> symbolHolder) {
        return symbolHolder
              .flatMap(eitherHolder -> eitherHolder.method_60739(Minecrft.registryAccess()))
              .orElseGet(() -> {
                  class_5321<SealSymbol> key = SealSymbol.firstCharOrDefault(Minecrft.player());
                  return Resource.getOrThrow(key, Minecrft.registryAccess());
              })
              .comp_349();
    }

    @Override
    public int method_32664(class_327 font) {
        return 31;
    }

    @Override
    public int method_32661() {
        return 31;
    }

    @Override
    public void method_32666(class_327 font, int x, int y, class_332 guiGraphics) {
        EnvelopeClient.getSealRenderer().renderDie(symbol, ShadingPalette.IRON_DIE, guiGraphics, x - 1, y - 1);
    }
}
