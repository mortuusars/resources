package io.github.mortuusars.envelope.world.mail.delivery;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.mortaar.util.Ticks;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_155;
import net.minecraft.class_5699;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record TravelDuration(int ticks) {
    public static final Codec<TravelDuration> CODEC =
          class_5699.field_33442.xmap(TravelDuration::new, TravelDuration::ticks);

    public static final class_9139<ByteBuf, TravelDuration> STREAM_CODEC =
          class_9135.field_49675.method_56432(TravelDuration::new, TravelDuration::ticks);

    public static final TravelDuration DEFAULT = new TravelDuration(600); // 30 sec

    public TravelDuration {
        Preconditions.checkArgument(ticks > 0, "Duration must be larger than 0.");
    }

    public int seconds() {
        return ticks / class_155.field_29702;
    }

    // --

    public static TravelDuration basedOnDistance(int distanceInBlocks, double travelSpeed) {
        distanceInBlocks = Math.min(distanceInBlocks, Config.Server.DELIVERY_TRAVEL_DURATION_DISTANCE_CAP.get());
        double seconds = distanceInBlocks / travelSpeed;
        return new TravelDuration(Math.max(1, (int) Ticks.fromSeconds(seconds)));
    }
}
