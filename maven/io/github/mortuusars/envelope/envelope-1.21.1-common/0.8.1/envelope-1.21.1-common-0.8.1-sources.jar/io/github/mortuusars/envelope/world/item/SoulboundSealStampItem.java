package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import io.github.mortuusars.envelope.world.item.component.seal.SealMaterial;
import io.github.mortuusars.mortaar.client.Minecrft;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5253;
import net.minecraft.class_5321;
import net.minecraft.class_7699;
import net.minecraft.class_9334;
import net.minecraft.class_9791;

public class SoulboundSealStampItem extends SealStampItem {
    public SoulboundSealStampItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public boolean method_45382(class_7699 enabledFeatures) {
        return super.method_45382(enabledFeatures)
              && (!Config.Server.SPEC.isLoaded() || Config.Server.SOULBOUND_SEAL_STAMP_ENABLED.get());
    }

    @Override
    public int method_31571(class_1799 stack) {
        double time = class_156.method_658() / 1000.0;
        double beat = Math.pow((Math.sin(time * Math.PI * 2 * 1) + 1.0) * 0.5, 10);
        float delta = (float) class_3532.method_16436(beat, 0, 1);
        return class_5253.class_5254.method_48780(delta, 0xFF08ABB3, 0xFF40E7FF);
    }

    // --

    @Override
    public Optional<class_9791<SealMaterial>> getMaterial(class_1799 stack) {
        return Optional.of(new class_9791<>(SealMaterial.SCULK));
    }

    @Override
    public boolean canDyeWith(class_1799 stack, class_1767 color) {
        return false;
    }

    @Override
    public boolean canApplyGold(class_1799 stack, class_1657 player) {
        return false;
    }

    @Override
    public Seal createSeal(class_1799 stack, class_1657 player) {
        if (player.method_7337()) {
            player.method_7353(class_2561.method_43471("item.envelope.soulbound_seal_stamp.error.in_creative_mode")
                  .method_27692(class_124.field_1061), true);
            return super.createSeal(stack, player);
        }

        if (Config.Server.SOULBOUND_SEAL_STAMP_CREATES_LOCK.get()) {
            return Seal.copy(super.createSeal(stack, player), player.method_56673())
                  .lockedBy(player)
                  .build();
        }

        return super.createSeal(stack, player);
    }

    @Override
    protected void onSealApplied(class_1799 stampStack, class_1657 player, SealableItem sealable, class_1799 target, Seal seal) {
        super.onSealApplied(stampStack, player, sealable, target, seal);

        player.method_37908().method_43129(null, player, Envelope.SoundEvents.SOULBOUND_SEAL_STAMP_LOCK.get(),
              class_3419.field_15248, 1f, player.method_59922().method_43057() * 0.3f + 0.85f);

        if (Config.Server.SOULBOUND_SEAL_STAMP_CREATES_LOCK.get()) {
            seal.lock().ifPresent(lock -> lock.lock(player.method_37908()));
        }

        if (Config.Server.SOULBOUND_SEAL_STAMP_CONSUMABLE.get()) {
            stampStack.method_7970(1, player, class_1304.field_6173);

            if (stampStack.method_7960()) {
                stampStack.method_7939(1); // Empty stacks do not return proper components and 'transmuteCopy' returns ItemStack.EMPTY

                class_5321<SealMaterial> originalMaterial = Optional.ofNullable(stampStack.method_57824(Envelope.DataComponents.SEAL_STAMP_MATERIAL))
                      .map(class_9791::comp_2832)
                      .orElse(SealMaterial.WAX);

                @Nullable class_1767 color = SealMaterial.colorFromMaterial(originalMaterial);

                class_1792 sealStamp = color != null
                      ? Envelope.Items.DYED_SEAL_STAMPS.getOrDefault(color, Envelope.Items.SEAL_STAMP).get()
                      : Envelope.Items.SEAL_STAMP.get();

                class_1799 newStampStack = stampStack.method_60503(sealStamp);
                newStampStack.method_57381(class_9334.field_49629);
                newStampStack.method_57381(class_9334.field_50072);

                player.method_32318(class_1657.field_49734).method_32332(newStampStack);
                player.method_37908().method_43129(null, player, class_3417.field_15075, class_3419.field_15248, 0.75f, 1f);
            }
        }
    }
}
