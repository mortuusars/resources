package io.github.mortuusars.envelope.world.mail;

import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.PersistentData;
import io.github.mortuusars.mortaar.Platform;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5455;
import net.minecraft.class_6903;
import net.minecraft.class_7225;

public class CustomMailSavedData extends class_18 {
    public static final Codec<CustomMailSavedData> CODEC = class_2487.field_25128.xmap(CustomMailSavedData::new, CustomMailSavedData::getData);
    public static final Logger LOGGER = LogUtils.getLogger();

    protected final Map<PersistentData.Type<?>, PersistentData> typedData = new HashMap<>();
    protected final class_2487 data;

    public CustomMailSavedData(class_2487 data) {
        this.data = data;
    }

    public CustomMailSavedData() {
        this.data = new class_2487();
    }

    public class_2487 getData() {
        return data;
    }

    /**
     * Gets the tag by ID.<br>
     * Don't forget to call {@link #method_80()} or {@link #set(class_2960, class_2487)} to ensure that changes will be saved.
     * @param location ID of the data.
     */
    public class_2487 get(class_2960 location) {
        return getData().method_10562(location.toString());
    }

    public void set(class_2960 location, class_2487 data) {
        getData().method_10566(location.toString(), data);
        method_80();
    }

    @SuppressWarnings("unchecked")
    public <T extends PersistentData> T getOrCreateTyped(PersistentData.Type<T> type) {
        return (T) typedData.computeIfAbsent(type, t -> {
            String key = t.id().toString();
            if (data.method_10545(key)) {
                class_5455 registryAccess = Platform.getCurrentServerOrThrow().method_30611();
                return t.codec().decode(registryAccess.method_57093(class_2509.field_11560), data.method_10562(key))
                      .ifError(e -> LOGGER.error("Cannot decode typed data '{}': {}", t, e))
                      .result()
                      .map(p -> (PersistentData) p.getFirst())
                      .orElse(t.constructor().get());
            }

            return t.constructor().get();
        });
    }

    // -- Save / Load

    private static final class_8645<CustomMailSavedData> FACTORY =
          new class_8645<>(CustomMailSavedData::new, CustomMailSavedData::load, null);

    public static CustomMailSavedData get(class_3218 level) {
        return level.method_8503().method_30002().method_17983().method_17924(FACTORY, "envelope_mail_data");
    }

    @Override
    public boolean method_79() {
        return super.method_79() || typedData.values().stream().anyMatch(PersistentData::isDirty);
    }

    @Override
    public @NotNull class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
        class_6903<class_2520> ops = registries.method_57093(class_2509.field_11560);
        for (Map.Entry<PersistentData.Type<?>, PersistentData> typedData : typedData.entrySet()) {
            if (typedData.getValue().isDirty()) {
                try {
                    data.method_10566(typedData.getKey().id().toString(), encodeTypedData(typedData.getKey(), typedData.getValue(), ops));
                    typedData.getValue().setDirty(false);
                } catch (Exception e) {
                    LOGGER.error("Cannot encode typed data '{}':", typedData.getKey(), e);
                }
            }
        }

        return CODEC.encode(this, class_2509.field_11560, tag)
              .ifError(e -> Envelope.LOGGER.error("Cannot save CustomMailSavedData: {}", e.message()))
              .result()
              .filter(t -> t instanceof class_2487)
              .map(t -> ((class_2487) t))
              .orElse(tag);
    }

    @SuppressWarnings("unchecked")
    private <T extends PersistentData> class_2520 encodeTypedData(PersistentData.Type<T> type, PersistentData data, class_6903<class_2520> ops) {
        return type.codec().encodeStart(ops, (T)data).getOrThrow();
    }

    private static CustomMailSavedData load(class_2487 tag, class_7225.class_7874 registries) {
        return CODEC.decode(class_2509.field_11560, tag)
              .ifError(e -> Envelope.LOGGER.error("Cannot load CustomMailSavedData: {}", e.message()))
              .result().map(Pair::getFirst).orElseGet(CustomMailSavedData::new);
    }
}
