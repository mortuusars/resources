package io.github.mortuusars.envelope.world.level.saveddata;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.packet.clientbound.ClientboundSyncDeathLockDataPacket;
import io.github.mortuusars.envelope.world.item.component.SealLock;
import io.github.mortuusars.mortaar.Platform;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7225;

public class SealLocks extends class_18 {
    public static final Codec<SealLocks> CODEC = RecordCodecBuilder.create(instance -> instance.group(
          Codec.list(SealLock.CODEC).xmap(Set::copyOf, List::copyOf).optionalFieldOf("locks", Set.of()).forGetter(SealLocks::getLocks)
    ).apply(instance, SealLocks::new));

    private static @Nullable SealLocks clientInstance;

    private final Set<SealLock> locks;

    protected SealLocks(Collection<SealLock> locks) {
        this.locks = new HashSet<>(locks); // Make sure it's mutable
    }

    protected SealLocks() {
        this.locks = new HashSet<>();
    }

    public Set<SealLock> getLocks() {
        return locks;
    }

    public boolean isLocked(SealLock lock) {
        return locks.contains(lock);
    }

    public boolean lock(SealLock lock) {
        if (locks.add(lock)) {
            method_80();
            return true;
        }
        return false;
    }

    public boolean unlock(SealLock lock) {
        if (locks.remove(lock)) {
            method_80();
            return true;
        }
        return false;
    }

    public boolean unlockAllFrom(String owner) {
        if (locks.removeIf(lock -> lock.owner().equalsIgnoreCase(owner))) {
            method_80();
            return true;
        }
        return false;
    }

    // --

    @Override
    public void method_78(boolean dirty) {
        super.method_78(dirty);
        if (dirty) {
            syncToAllClients();
        }
    }

    public void syncToAllClients() {
        if (Platform.getCurrentServer() != null) {
            new ClientboundSyncDeathLockDataPacket(List.copyOf(locks)).sendToAllClients();
        }
    }

    public void syncToClient(class_3222 player) {
        new ClientboundSyncDeathLockDataPacket(List.copyOf(locks)).sendToClient(player);
    }

    // -- Save / Load

    public static SealLocks get(class_1937 level) {
        if (level instanceof class_3218 serverLevel) {
            return serverLevel.method_8503().method_30002().method_17983().method_17924(factory(), "envelope_seal_locks");
        } else {
            if (clientInstance == null) {
                clientInstance = new SealLocks();
            }
            return clientInstance;
        }
    }

    public static void setClientData(class_1937 level, List<SealLock> locks) {
        Preconditions.checkArgument(level.method_8608(), "setClientData called on the server! Don't do that.");
        SealLocks data = get(level);
        data.locks.clear();
        data.locks.addAll(locks);
    }

    public static @NotNull class_8645<SealLocks> factory() {
        return new class_8645<>(
              SealLocks::new,
              (tag, provider) -> CODEC.parse(provider.method_57093(class_2509.field_11560), tag)
                    .resultOrPartial(e -> Envelope.LOGGER.error("Cannot load DeathLockSavedData: {}", e))
                    .orElse(null),
              null);
    }

    public @NotNull class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
        return (class_2487) CODEC.encode(this, registries.method_57093(class_2509.field_11560), tag)
              .resultOrPartial(e -> Envelope.LOGGER.error("Cannot save DeathLockSavedData: {}", e))
              .orElse(tag);
    }
}
