package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public interface SealableItem {
    class_1799 seal(class_1937 level, class_1799 stack, Seal seal);

    default boolean canSeal(class_1937 level, class_1799 stack) {
        return !stack.method_57826(Envelope.DataComponents.SEAL);
    }
}
