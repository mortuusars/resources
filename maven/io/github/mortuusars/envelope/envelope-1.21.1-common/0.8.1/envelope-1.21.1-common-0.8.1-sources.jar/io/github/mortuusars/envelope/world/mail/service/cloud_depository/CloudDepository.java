package io.github.mortuusars.envelope.world.mail.service.cloud_depository;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.Colors;
import io.github.mortuusars.envelope.world.item.component.ServiceLetterMeaning;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import io.github.mortuusars.envelope.world.item.component.seal.SealMaterial;
import io.github.mortuusars.envelope.world.item.component.seal.SealSymbol;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import io.github.mortuusars.envelope.world.mail.dropoff.MailDropOffContext;
import io.github.mortuusars.envelope.world.mail.dropoff.MailDropOffResult;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_3532;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_5455;
import net.minecraft.class_5819;
import net.minecraft.class_7225;
import net.minecraft.class_9334;
import net.minecraft.network.chat.*;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class CloudDepository {
    protected static final Logger LOGGER = LogUtils.getLogger();

    public static final ServiceLetterMeaning LETTER_MEANING_WITHDRAWAL_REQUEST =
          new ServiceLetterMeaning(Envelope.resource("cloud_depository/withdrawal_request"));
    public static final ServiceLetterMeaning LETTER_MEANING_STATUS_REQUEST =
          new ServiceLetterMeaning(Envelope.resource("cloud_depository/status_request"));
    public static final ServiceLetterMeaning LETTER_MEANING_EXPANSION_REQUEST =
          new ServiceLetterMeaning(Envelope.resource("cloud_depository/expansion_request"));

    public static final ServiceLetterMeaning LETTER_MEANING_STATUS_REPORT =
          new ServiceLetterMeaning(Envelope.resource("cloud_depository/status_report"));
    public static final ServiceLetterMeaning LETTER_MEANING_DEPOSIT_REPORT =
          new ServiceLetterMeaning(Envelope.resource("cloud_depository/deposit_report"));
    public static final ServiceLetterMeaning LETTER_MEANING_EXPANSION_REPORT =
          new ServiceLetterMeaning(Envelope.resource("cloud_depository/expansion_report"));

    public static final class_2561 RETURN_MESSAGE_NO_IDENTITY = class_2561.method_43471(
          "gui.envelope.delivery_log.message.cloud_depository.no_identity").method_54663(Colors.TOOLTIP_RED);
    public static final class_2561 RETURN_MESSAGE_NON_SERVICEABLE_IDENTITY = class_2561.method_43471(
          "gui.envelope.delivery_log.message.cloud_depository.non_serviceable_identity").method_54663(Colors.TOOLTIP_RED);
    public static final class_2561 RETURN_MESSAGE_STORAGE_IS_FULL = class_2561.method_43471(
          "gui.envelope.delivery_log.message.cloud_depository.storage_is_full").method_54663(Colors.TOOLTIP_RED);
    public static final class_2561 RETURN_MESSAGE_STORAGE_IS_EMPTY = class_2561.method_43471(
          "gui.envelope.delivery_log.message.cloud_depository.storage_is_empty").method_54663(Colors.TOOLTIP_RED);
    public static final class_2561 RETURN_MESSAGE_INDEX_NOT_FOUND = class_2561.method_43471(
          "gui.envelope.delivery_log.message.cloud_depository.index_not_found").method_54663(Colors.TOOLTIP_RED);
    public static final class_2561 RETURN_MESSAGE_CAPACITY_ALREADY_AT_MAX = class_2561.method_43471(
          "gui.envelope.delivery_log.message.cloud_depository.capacity_already_at_max").method_54663(Colors.TOOLTIP_RED);
    public static final class_2561 LOG_MESSAGE_DEPOSITED = class_2561.method_43471(
          "gui.envelope.delivery_log.message.cloud_depository.deposited").method_54663(Colors.TOOLTIP_GREEN);
    public static final class_2561 LOG_MESSAGE_WITHDRAWN = class_2561.method_43471(
          "gui.envelope.delivery_log.message.cloud_depository.withdrawn").method_54663(Colors.TOOLTIP_GREEN);

    protected final MailService service;
    protected final ServiceAddress address;
    protected final Seal seal;
    protected CloudDepositoryData data = null;

    public CloudDepository(MailService service) {
        this.service = service;
        this.address = ServiceAddress.getOrThrow(ServiceAddress.CLOUD_DEPOSITORY, service.getLevel().method_30349());
        this.seal = createSeal(service.getLevel().method_30349());
    }

    public MailService getService() {
        return service;
    }

    public @NotNull CloudDepositoryData getData() {
        if (data == null) {
            data = service.getPersistentData().getOrCreateTyped(CloudDepositoryData.TYPE);
        }
        return data;
    }

    public ServiceAddress getAddress() {
        return address;
    }

    public Seal getSeal() {
        return seal;
    }

    public int getTotalItemCount() {
        int count = 0;
        for (CloudDepositoryData.Account accountData : getData().accounts().values()) {
            count += accountData.getTotal();
        }
        return count;
    }

    // --

    public static MailDropOffResult handleDropOff(MailDropOffContext context) {
        return context.getService().getCloudService().handleDelivery(context);
    }

    public MailDropOffResult handleDelivery(MailDropOffContext context) {
        // Should be handled higher up the chain, but just to be safe:
        if (context.isReturned()) {
            LOGGER.info("'{}' received returned mail. Delivery: '{}'. Voiding.", context.getTarget(), context.getDelivery());
            return MailDropOffResult.CONSUME;
        }

        class_1799 mail = context.getMail();

        if (!Config.Server.SERVICE_CLOUD_DEPOSITORY_ENABLED.get()) {
            return MailDropOffResult.returned(mail, DeliveryRecord.Message.UNAVAILABLE);
        }

        if (!(mail.method_57824(Envelope.DataComponents.SEAL) instanceof Seal mailSeal)) {
            return MailDropOffResult.returned(mail, RETURN_MESSAGE_NO_IDENTITY);
        }

        String account = mailSeal.getSignatureAsId();

        if (account.isEmpty()) {
            return MailDropOffResult.returned(mail, RETURN_MESSAGE_NO_IDENTITY);
        }

        if (Config.Server.SERVICE_CLOUD_DEPOSITORY_ONLY_PLAYERS.get()
              && service.getKnownPlayers().getDataOf(account).isEmpty()) {
            return MailDropOffResult.returned(mail, RETURN_MESSAGE_NON_SERVICEABLE_IDENTITY);
        }

        if (mail.method_57824(Envelope.DataComponents.SERVICE_LETTER_MEANING) instanceof ServiceLetterMeaning meaning) {
            if (meaning.equals(LETTER_MEANING_WITHDRAWAL_REQUEST)) {
                return handleWithdrawalRequest(context, account);
            }
            if (meaning.equals(LETTER_MEANING_STATUS_REQUEST)) {
                return handleStatusRequest(context, account);
            }
            if (meaning.equals(LETTER_MEANING_EXPANSION_REQUEST)) {
                return handleExpansionRequest(context, account);
            }
            return MailDropOffResult.returned(mail, DeliveryRecord.Message.REJECTED);
        }

        return handleItemDeposit(context, account);
    }

    protected MailDropOffResult handleItemDeposit(MailDropOffContext context, String account) {
        class_1799 mail = context.getMail();
        CloudDepositoryData.Account accountData = getData().ofAccount(account);

        int capacity = accountData.getCapacity();
        if (accountData.getTotal() >= capacity) {
            return MailDropOffResult.returned(mail, RETURN_MESSAGE_STORAGE_IS_FULL);
        }

        Mail.writeToLog(mail,
              DeliveryRecord.arrivedTo(getAddress()),
              DeliveryRecord.message(LOG_MESSAGE_DEPOSITED));

        accountData.getItems().add(mail);
        getData().setDirty();

        LOGGER.debug("{} has been put into storage: {}", mail, account);

        class_1799 reply = createDepositReportLetter(context.getService(), getSeal(), mail, accountData.getTotal(), capacity);
        return MailDropOffResult.reply(reply);
    }

    protected MailDropOffResult handleWithdrawalRequest(MailDropOffContext context, String account) {
        LOGGER.debug("Received withdrawal request from: {}", account);

        CloudDepositoryData.Account accountData = getData().ofAccount(account);

        if (accountData.getItems().isEmpty()) {
            return MailDropOffResult.returned(context.getMail(), RETURN_MESSAGE_STORAGE_IS_EMPTY);
        }

        if (context.getMail().method_57824(class_9334.field_49631) instanceof class_2561 index) {
            ListIterator<class_1799> iterator = accountData.getItems().listIterator(accountData.getItems().size());

            while (iterator.hasPrevious()) {
                class_1799 item = iterator.previous();
                if (index.equals(item.method_57824(class_9334.field_49631))) {
                    iterator.remove();
                    getData().setDirty();

                    LOGGER.debug("Withdrew indexed [{}] from: {}", account, item);

                    return MailDropOffResult.reply(Mail.of(item)
                          .sender(getAddress())
                          .recipient(context.getOrigin())
                          .writeToLog(DeliveryRecord.message(LOG_MESSAGE_WITHDRAWN)).itemStack());
                }
            }

            return MailDropOffResult.returned(context.getMail(), RETURN_MESSAGE_INDEX_NOT_FOUND);
        }

        class_1799 item = accountData.getItems().removeLast();
        getData().setDirty();

        LOGGER.debug("Withdrew [{}] from: {}", account, item);

        return MailDropOffResult.reply(Mail.of(item)
              .sender(getAddress())
              .recipient(context.getOrigin())
              .writeToLog(DeliveryRecord.message(LOG_MESSAGE_WITHDRAWN)).itemStack());
    }

    protected MailDropOffResult handleStatusRequest(MailDropOffContext context, String account) {
        LOGGER.debug("Received status request from: {}", account);

        CloudDepositoryData.Account accountData = getData().ofAccount(account);

        class_1799 report = createStatusReportLetter(seal, account, accountData.getTotal(), accountData.getCapacity(),
              Config.Server.SERVICE_CLOUD_DEPOSITORY_ACCOUNT_STORAGE_MAX_CAPACITY.get(),
              accountData.getItems(), context.getLevel().method_8409());
        return MailDropOffResult.reply(Mail.of(report)
              .sender(getAddress())
              .recipient(context.getOrigin())
              .itemStack());
    }

    protected MailDropOffResult handleExpansionRequest(MailDropOffContext context, String account) {
        LOGGER.debug("Received expansion request from: {}", account);

        int maxCapacity = Config.Server.SERVICE_CLOUD_DEPOSITORY_ACCOUNT_STORAGE_MAX_CAPACITY.get();
        int increase = Config.Server.SERVICE_CLOUD_DEPOSITORY_ACCOUNT_STORAGE_CAPACITY_PER_EXPANSION.get();

        CloudDepositoryData.Account accountData = getData().ofAccount(account);
        int oldCapacity = accountData.getCapacity();

        if (accountData.getCapacity() >= maxCapacity) {
            return MailDropOffResult.returned(context.getMail(), RETURN_MESSAGE_CAPACITY_ALREADY_AT_MAX);
        }

        int newCapacity = class_3532.method_15340(accountData.getCapacity() + increase, 1, maxCapacity);
        accountData.setCapacity(newCapacity);
        getData().setDirty();

        LOGGER.debug("Increased storage capacity of account '{}' to {}", account, maxCapacity);

        int increasedBy = newCapacity - oldCapacity;

        class_1799 report = createExpansionReportLetter(seal, account, accountData.getCapacity(), maxCapacity, increasedBy);
        return MailDropOffResult.reply(Mail.of(report)
              .sender(getAddress())
              .recipient(context.getOrigin())
              .itemStack());
    }

    // --

    public static @NotNull Seal createSeal(class_5455 registryAccess) {
        return Seal.create(registryAccess)
              .material(SealMaterial.WAX)
              .impression(SealSymbol.CLOUD_DEPOSITORY)
              .signature(class_2561.method_43471("address.envelope.cloud_depository"))
              .build();
    }

    public static class_1799 createDepositReportLetter(MailService service, Seal seal, class_1799 depositedItem, int accountStorageCurrent, int accountStorageCapacity) {
        depositedItem = Mail.removeAllDeliveryData(depositedItem.method_7972());

        class_2561 depositedItemComponent = !depositedItem.method_7960()
              ? depositedItem.method_7964().method_27662().method_27696(class_2583.field_24360.method_10977(class_124.field_1079).method_30938(true).method_10949(new class_2568(class_2568.class_5247.field_24343, new class_2568.class_5249(depositedItem))))
              : class_2561.method_43471("letter.envelope.cloud_depository.deposit_report.item").method_27692(class_124.field_1079);

        class_1799 withdrawalRequestLetter = createWithdrawalRequestLetter(service.getLevel().method_30349());
        class_2561 withdrawalRequestComponent = class_2561.method_43471("letter.envelope.cloud_depository.withdrawal_request.name").method_27696(class_2583.field_24360
              .method_10977(class_124.field_1058)
              .method_30938(true)
              .method_10949(new class_2568(class_2568.class_5247.field_24343, new class_2568.class_5249(withdrawalRequestLetter))));

        return Mail.of(Envelope.Items.SEALED_SERVICE_LETTER)
              .serviceLetterMeaning(LETTER_MEANING_DEPOSIT_REPORT)
              .letterContent(class_2561.method_43469("letter.envelope.cloud_depository.deposit_report.message",
                    depositedItemComponent,
                    withdrawalRequestComponent,
                    class_2561.method_43470(accountStorageCurrent + "/" + accountStorageCapacity).method_27692(class_124.field_1079)))
              .seal(seal)
              .itemStack();
    }

    public static class_1799 createStatusReportLetter(Seal seal, String account, int accountStorageCurrent, int accountStorageCapacity,
                                                     int maxCapacity, List<class_1799> storedItems, class_5819 random) {
        List<class_1799> storedIndexableItems = storedItems.stream()
              .filter(i -> i.method_57826(class_9334.field_49631))
              .toList();

        class_2561 indexable;
        if (storedIndexableItems.isEmpty()) {
            indexable = class_2561.method_43471("letter.envelope.cloud_depository.status_report.indexable_none");
        } else {
            List<class_1799> indexablePool = new ArrayList<>(storedIndexableItems);
            class_5250 randomIndexableItems = class_2561.method_43473();
            boolean hasElements = false;

            for (int i = 0; i < Math.min(storedIndexableItems.size(), 3); i++) {
                int randomIndex = random.method_43048(indexablePool.size());
                class_1799 item = indexablePool.remove(randomIndex);
                if (hasElements) {
                    randomIndexableItems.method_27693(", ");
                }
                class_5250 itemName = item.method_7964().method_27662().method_27696(class_2583.field_24360.method_10977(class_124.field_1079).method_30938(true).method_10949(new class_2568(class_2568.class_5247.field_24343, new class_2568.class_5249(item))));
                randomIndexableItems.method_10852(itemName);
                hasElements = true;
            }

            indexable = class_2561.method_43469("letter.envelope.cloud_depository.status_report.indexable_items",
                  class_2561.method_43470(Integer.toString(storedIndexableItems.size())).method_27692(class_124.field_1079),
                  randomIndexableItems);
        }

        class_2561 expansion = accountStorageCapacity < maxCapacity
              ? class_2561.method_43469("letter.envelope.cloud_depository.status_report.expansion",
              class_2561.method_43470(Integer.toString(maxCapacity)).method_27692(class_124.field_1079))
              : class_5244.field_39003;

        return Mail.of(Envelope.Items.SEALED_SERVICE_LETTER)
              .name(class_2561.method_43471("letter.envelope.cloud_depository.status_report.name"))
              .letterContent(class_2561.method_43469("letter.envelope.cloud_depository.status_report.message",
                    class_2561.method_43470(account).method_27692(class_124.field_1079),
                    class_2561.method_43470(accountStorageCurrent + "/" + accountStorageCapacity).method_27692(class_124.field_1079),
                    indexable, expansion))
              .serviceLetterMeaning(LETTER_MEANING_STATUS_REPORT)
              .seal(seal)
              .itemStack();
    }

    public static class_1799 createExpansionReportLetter(Seal seal, String account, int accountStorageCapacity, int maxCapacity, int increasedBy) {
        class_2561 further = accountStorageCapacity < maxCapacity
              ? class_2561.method_43469("letter.envelope.cloud_depository.expansion_report.further_expansion",
              class_2561.method_43470(Integer.toString(maxCapacity)).method_27692(class_124.field_1079))
              : class_5244.field_39003;

        return Mail.of(Envelope.Items.SEALED_SERVICE_LETTER)
              .name(class_2561.method_43471("letter.envelope.cloud_depository.expansion_report.name"))
              .letterContent(class_2561.method_43469("letter.envelope.cloud_depository.expansion_report.message",
                    class_2561.method_43470(account).method_27692(class_124.field_1079),
                    class_2561.method_43470(Integer.toString(increasedBy)).method_27692(class_124.field_1079),
                    class_2561.method_43470(Integer.toString(accountStorageCapacity)).method_27692(class_124.field_1079),
                    further))
              .serviceLetterMeaning(LETTER_MEANING_EXPANSION_REPORT)
              .seal(seal)
              .itemStack();
    }

    public static class_1799 createWithdrawalRequestLetter(class_7225.class_7874 registries) {
        return Mail.of(Envelope.Items.SERVICE_LETTER)
              .letterContent(class_2561.method_43471("letter.envelope.cloud_depository.withdrawal_request.message"))
              .serviceLetterMeaning(LETTER_MEANING_WITHDRAWAL_REQUEST)
              .addressTag(ServiceAddress.getOrThrow(ServiceAddress.CLOUD_DEPOSITORY, registries))
              .itemStack();
    }

    public static class_1799 createStatusRequestLetter(class_7225.class_7874 registries) {
        return Mail.of(Envelope.Items.SERVICE_LETTER)
              .letterContent(class_2561.method_43471("letter.envelope.cloud_depository.status_request.message"))
              .serviceLetterMeaning(LETTER_MEANING_STATUS_REQUEST)
              .addressTag(ServiceAddress.getOrThrow(ServiceAddress.CLOUD_DEPOSITORY, registries))
              .itemStack();
    }

    public static class_1799 createExpansionRequestLetter(class_7225.class_7874 registries) {
        return Mail.of(Envelope.Items.SERVICE_LETTER)
              .letterContent(class_2561.method_43471("letter.envelope.cloud_depository.expansion_request.message"))
              .serviceLetterMeaning(LETTER_MEANING_EXPANSION_REQUEST)
              .addressTag(ServiceAddress.getOrThrow(ServiceAddress.CLOUD_DEPOSITORY, registries))
              .itemStack();
    }
}
