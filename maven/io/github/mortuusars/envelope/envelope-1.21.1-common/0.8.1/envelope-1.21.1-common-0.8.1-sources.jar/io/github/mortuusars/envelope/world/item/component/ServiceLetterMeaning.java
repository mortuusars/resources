package io.github.mortuusars.envelope.world.item.component;

import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_9139;

public record ServiceLetterMeaning(class_2960 id) {
    public static final Codec<ServiceLetterMeaning> CODEC =
          class_2960.field_25139.xmap(ServiceLetterMeaning::new, ServiceLetterMeaning::id);
    public static final class_9139<ByteBuf, ServiceLetterMeaning> STREAM_CODEC =
          class_2960.field_48267.method_56432(ServiceLetterMeaning::new, ServiceLetterMeaning::id);

    public class_5250 translate() {
        return class_2561.method_43471(id.method_42093("service_letter_meaning").replace("/", "."));
    }

    @Override
    public boolean equals(Object object) {
        if (object == null || getClass() != object.getClass()) return false;
        ServiceLetterMeaning that = (ServiceLetterMeaning) object;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public @NotNull String toString() {
        return "ServiceLetterMeaning{" + id + '}';
    }
}
