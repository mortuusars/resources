package io.github.mortuusars.envelope.mixin.death;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import io.github.mortuusars.envelope.world.level.saveddata.SealLocks;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

@Mixin(class_1661.class)
public abstract class InventoryMixin {
    @Shadow
    @Final
    public class_1657 player;

    @Unique
    private @Nullable class_1799 envelope$keptItem = null;

    @WrapOperation(method = "dropAll", at = @At(value = "INVOKE",
          target = "Lnet/minecraft/world/entity/player/Player;drop(Lnet/minecraft/world/item/ItemStack;ZZ)Lnet/minecraft/world/entity/item/ItemEntity;"))
    public @Nullable class_1542 onDropAllDrop(class_1657 instance, class_1799 droppedItem, boolean dropAround, boolean includeThrowerName, Operation<class_1542> original) {
        if ((instance.method_29504() || instance.field_6272)
              && droppedItem.method_57824(Envelope.DataComponents.SEAL) instanceof Seal seal
              && seal.lock().map(lock -> lock.isOwnedBy(instance) && lock.isLocked(instance.method_37908())).orElse(false)) {
            class_243 pos = instance.method_19538();
            instance.method_37908().method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, Envelope.SoundEvents.SOULBOUND_SEAL_STAMP_UNLOCK.get(), class_3419.field_15248,
                  1f, instance.method_59922().method_43057() * 0.3f + 0.85f);
            if (instance.method_37908() instanceof class_3218 serverLevel) {
                serverLevel.method_14199(class_2398.field_38002, pos.field_1352, pos.field_1351, pos.field_1350, 5, 0.3, 0.3, 0.3, 0);
            }

            class_9279 customData = droppedItem.method_57825(class_9334.field_49628, class_9279.field_49302)
                  .method_57451(tag -> tag.method_10556("envelope_keep_in_inventory_on_transfer", true));
            droppedItem.method_57379(class_9334.field_49628, customData);

            envelope$keptItem = droppedItem;
            return null;
        }
        return original.call(instance, droppedItem, dropAround, includeThrowerName);
    }

    @SuppressWarnings("unchecked")
    @WrapOperation(method = "dropAll", at = @At(value = "INVOKE", target = "Ljava/util/List;set(ILjava/lang/Object;)Ljava/lang/Object;"))
    private <E> E onDropAllSet(List<E> instance, int i, E e, Operation<E> original) {
        if (envelope$keptItem != null) {
            e = (E) envelope$keptItem;
            envelope$keptItem = null;
        }

        return original.call(instance, i, e);
    }
}
