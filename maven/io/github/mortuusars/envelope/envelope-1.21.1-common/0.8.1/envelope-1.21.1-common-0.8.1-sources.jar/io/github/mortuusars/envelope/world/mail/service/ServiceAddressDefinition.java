package io.github.mortuusars.envelope.world.mail.service;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.EnvelopeSymbols;
import io.github.mortuusars.envelope.world.mail.address.AddressLocation;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import net.minecraft.class_2561;
import net.minecraft.class_5381;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_8824;

public record ServiceAddressDefinition(class_2561 name, String icon, AddressLocation location) {
    public static final Codec<ServiceAddressDefinition> DIRECT_CODEC = RecordCodecBuilder.create(i -> i.group(
          class_8824.field_46597.fieldOf("name").forGetter(ServiceAddressDefinition::name),
          Codec.STRING.optionalFieldOf("icon", EnvelopeSymbols.ADDRESS_SERVICE).forGetter(ServiceAddressDefinition::icon),
          AddressLocation.CODEC.fieldOf("location").forGetter(ServiceAddressDefinition::location)
    ).apply(i, ServiceAddressDefinition::new));

    public static final Codec<class_6880<ServiceAddressDefinition>> CODEC =
          class_5381.method_29749(Envelope.Registries.SERVICE_ADDRESS_DEFINITION, DIRECT_CODEC);

    // --

    public static void bootstrap(class_7891<ServiceAddressDefinition> context) {
        context.method_46838(ServiceAddress.MAIL_SERVICE, new ServiceAddressDefinition(
              class_2561.method_43471("address.envelope.mail_service"),
              EnvelopeSymbols.ADDRESS_MAIL_SERVICE,
              new AddressLocation.Relative(0)));
        context.method_46838(ServiceAddress.AUTOMATED_SUPPLY_SERVICE, new ServiceAddressDefinition(
              class_2561.method_43471("address.envelope.automated_supply_service"),
              EnvelopeSymbols.ADDRESS_SERVICE,
              new AddressLocation.Relative(1000)));
        context.method_46838(ServiceAddress.CLOUD_DEPOSITORY, new ServiceAddressDefinition(
              class_2561.method_43471("address.envelope.cloud_depository"),
              EnvelopeSymbols.ADDRESS_CLOUD_DEPOSITORY,
              new AddressLocation.Relative(0)));
        context.method_46838(ServiceAddress.EQUINE_ASSURANCE_BUREAU, new ServiceAddressDefinition(
              class_2561.method_43471("address.envelope.equine_assurance_bureau"),
              EnvelopeSymbols.ADDRESS_SERVICE,
              new AddressLocation.Relative(2000)));
    }
}
