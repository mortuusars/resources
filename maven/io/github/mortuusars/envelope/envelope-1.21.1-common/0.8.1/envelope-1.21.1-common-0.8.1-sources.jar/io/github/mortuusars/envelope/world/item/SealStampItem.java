package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.inventory.tooltip.SealDieTooltip;
import io.github.mortuusars.envelope.world.item.component.seal.*;
import io.github.mortuusars.mortaar.Platform;
import io.github.mortuusars.mortaar.client.Minecrft;
import io.github.mortuusars.mortaar.resources.Resource;
import io.github.mortuusars.mortaar.util.supporter.Supporters;
import io.github.mortuusars.mortaar.world.item.ApplicatorItem;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_5536;
import net.minecraft.class_5632;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_9791;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

public class SealStampItem extends class_1792 implements ApplicatorItem {
    public SealStampItem(class_1793 properties) {
        super(properties);
    }

    // -- Material

    public Optional<class_9791<SealMaterial>> getMaterial(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.SEAL_STAMP_MATERIAL));
    }

    public class_6880<SealMaterial> getMaterialOrDefault(class_1799 stack, class_7225.class_7874 registries) {
        return getMaterial(stack)
              .flatMap(eitherHolder -> eitherHolder.method_60739(registries))
              .orElseGet(() -> Resource.getOrThrow(SealMaterial.WAX, registries));
    }

    public boolean canDyeWith(class_1799 stack, class_1767 color) {
        if (!stack.method_57826(Envelope.DataComponents.SEAL_STAMP_MATERIAL)) {
            return true;
        }

        return getMaterial(stack)
              .map(e -> !e.comp_2832().equals(SealMaterial.fromDyeColor(color)))
              .orElse(false);
    }

    public boolean canApplyGold(class_1799 stack, class_1657 player) {
        return Supporters.isEligibleForGoldenRewards(player.method_5667());
    }

    // -- Die

    public Optional<class_9791<SealSymbol>> getDie(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.SEAL_STAMP_DIE));
    }

    public class_6880<SealSymbol> getDieOrDefault(class_1799 stack, class_7225.class_7874 registries, @Nullable class_1657 player) {
        return getDie(stack)
              .flatMap(eitherHolder -> eitherHolder.method_60739(registries))
              .orElseGet(() -> Resource.getOrThrow(SealSymbol.firstCharOrDefault(player), registries));
    }

    // --

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> components, class_1836 flag) {
        class_7225.class_7874 registries = context.method_59527();
        if (flag.method_8035() && registries != null) {
            getMaterial(stack)
                  .flatMap(t -> t.method_60739(registries))
                  .flatMap(class_6880::method_40230)
                  .ifPresent(key -> {
                      components.add(class_2561.method_43470("Material: ").method_27692(class_124.field_1063)
                            .method_10852(class_2561.method_43470(key.method_29177().toString()).method_27692(class_124.field_1080)));
                  });

            getDie(stack)
                  .flatMap(t -> t.method_60739(registries))
                  .flatMap(class_6880::method_40230)
                  .ifPresent(key -> {
                      components.add(class_2561.method_43470("Die: ").method_27692(class_124.field_1063)
                            .method_10852(class_2561.method_43470(key.method_29177().toString()).method_27692(class_124.field_1080)));
                  });
        }
    }

    @Override
    public @NotNull Optional<class_5632> method_32346(class_1799 stack) {
        if (stack.method_57826(Envelope.DataComponents.SEAL_STAMP_DIE)
              || !Platform.isClient()
              || !Config.Client.HIDE_DEFAULT_SEAL_STAMP_DIE_TOOLTIP_OUTSIDE_OF_INVENTORY.get()
              || Client.isInInventory(stack)) {
            return Optional.of(new SealDieTooltip(getDie(stack)));
        }

        return Optional.empty();
    }

    @Override
    public boolean canBeAppliedTo(class_1657 player, class_1703 menu, class_1735 slot, class_1799 carried) {
        if (!slot.method_32754(player)) {
            return false;
        }

        if (slot.method_7677().method_57824(Envelope.DataComponents.SEAL) instanceof Seal existingSeal) {
            return existingSeal.getSignatureAsId().equals(player.method_5820())
                  && canApplyGold(carried, player)
                  && (existingSeal.lock().isEmpty() || !existingSeal.lock().get().isLocked(player.method_37908()));
        }

        return slot.method_7677().method_7909() instanceof SealableItem sealable && sealable.canSeal(player.method_37908(), slot.method_7677());
    }

    @Override
    public boolean method_31565(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player) {
        if (action != class_5536.field_27014) {
            return false;
        }

        if (!slot.method_32754(player)) {
            player.method_43077(Envelope.SoundEvents.UI_ACTION_BLOCKED.get());
            return true;
        }

        class_1799 target = slot.method_7677();

        if (target.method_57824(Envelope.DataComponents.SEAL) instanceof Seal existingSeal
              && existingSeal.getSignatureAsId().equals(player.method_5820())
              && canApplyGold(stack, player)
              && (existingSeal.lock().isEmpty() || !existingSeal.lock().get().isLocked(player.method_37908()))) {
            Seal newSeal = Seal.copy(existingSeal, player.method_56673())
                  .material(existingSeal.material().method_40225(SealMaterial.GOLD)
                        ? getMaterialOrDefault(stack, player.method_56673())
                        : Resource.getOrThrow(SealMaterial.GOLD, player.method_56673()))
                  .owner(player)
                  .build();

            target.method_57379(Envelope.DataComponents.SEAL, newSeal);
            slot.method_7673(target);
            player.method_5783(Envelope.SoundEvents.SEAL_STAMP_APPLY.get(), 1f, player.method_59922().method_43057() * 0.4f + 0.80f);
            return true;
        }

        if (!(target.method_7909() instanceof SealableItem sealable) || !sealable.canSeal(player.method_37908(), target)) {
            player.method_43077(Envelope.SoundEvents.UI_ACTION_BLOCKED.get());
            return true;
        }

        Seal seal = createSeal(stack, player);
        class_1799 sealResult = applySealToItem(stack, player, sealable, target, seal);
        slot.method_7673(sealResult);
        onSealApplied(stack, player, sealable, target, seal);

        return true;
    }

    // -- Seal

    public Seal createSeal(class_1799 stack, class_1657 player) {
        return Seal.create(player.method_56673())
              .material(getMaterialOrDefault(stack, player.method_56673()))
              .impression(getDieOrDefault(stack, player.method_56673(), player))
              .owner(player)
              .build();
    }

    protected class_1799 applySealToItem(class_1799 stack, class_1657 player, SealableItem sealable, class_1799 target, Seal seal) {
        return sealable.seal(player.method_37908(), target, seal);
    }

    protected void onSealApplied(class_1799 stack, class_1657 player, SealableItem sealable, class_1799 target, Seal seal) {
        player.method_5783(Envelope.SoundEvents.SEAL_STAMP_APPLY.get(), 0.75f, player.method_59922().method_43057() * 0.4f + 0.80f);
        player.method_7281(Envelope.Stats.SEALS_APPLIED.get());
    }

    // --

    public static class Client {
        public static boolean isInInventory(class_1799 stack) {
            if (Minecrft.player().field_7512 instanceof class_1703 menu) {
                for (class_1735 slot : menu.field_7761) {
                    if (slot.method_7677() == stack) {
                        return true;
                    }
                }
                return false;
            }

            for (class_1799 item : Minecrft.player().method_31548().field_7547) {
                if (item == stack) {
                    return true;
                }
            }

            return false;
        }
    }
}