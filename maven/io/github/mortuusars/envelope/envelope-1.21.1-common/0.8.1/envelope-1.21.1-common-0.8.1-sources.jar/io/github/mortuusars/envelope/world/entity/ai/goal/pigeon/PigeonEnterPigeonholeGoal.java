package io.github.mortuusars.envelope.world.entity.ai.goal.pigeon;

import io.github.mortuusars.envelope.world.block.PigeonholeBlockEntity;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.entity.ai.PigeonholeHandler;
import io.github.mortuusars.envelope.world.entity.ai.PigeonNavigation;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_2338;

public class PigeonEnterPigeonholeGoal extends class_1352 {
    private final Pigeon pigeon;

    public PigeonEnterPigeonholeGoal(Pigeon pigeon) {
        this.pigeon = pigeon;
        method_6265(EnumSet.of(class_4134.field_18405));
    }

    @Override
    public boolean method_6264() {
        if (pigeon.isDelivering() || pigeon.method_60953()) {
            return false;
        }

        @Nullable class_2338 pos = pigeon.getPigeonholeHandler().getTargetPos();

        if (pos != null
              && pigeon.getPigeonholeHandler().wantsToEnterPigeonhole(pigeon)
              && pigeon.closerThan(pos, PigeonNavigation.getReachDistance() + 0.5f)
              && pigeon.method_37908().method_8321(pos) instanceof PigeonholeBlockEntity blockEntity
              && PigeonholeHandler.isPigeonholeSafe(pigeon.method_37908(), pos)) {
            if (blockEntity.hasSpaceForAnotherOccupant()) {
                return true;
            }

            pigeon.getPigeonholeHandler().setTargetPos(null);
        }

        return false;
    }

    @Override
    public boolean method_6266() {
        return false;
    }

    @Override
    public void method_6269() {
        pigeon.getPigeonholeHandler().getPigeonholeAtTargetPos(pigeon.method_37908())
              .ifPresent(pigeonhole -> pigeonhole.addOccupant(pigeonhole.method_11016(), pigeonhole.method_11010(), pigeon));
    }
}
