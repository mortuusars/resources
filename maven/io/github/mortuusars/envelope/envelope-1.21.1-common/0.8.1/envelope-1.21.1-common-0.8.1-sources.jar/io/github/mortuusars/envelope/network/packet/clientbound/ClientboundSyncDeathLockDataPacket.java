package io.github.mortuusars.envelope.network.packet.clientbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.SealLock;
import io.github.mortuusars.envelope.world.level.saveddata.SealLocks;
import io.github.mortuusars.mortaar.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ClientboundSyncDeathLockDataPacket(List<SealLock> locks) implements Packet {
    public static final class_2960 ID = Envelope.resource("sync_death_lock_data");
    public static final class_9154<ClientboundSyncDeathLockDataPacket> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, ClientboundSyncDeathLockDataPacket> STREAM_CODEC = class_9139.method_56434(
          SealLock.STREAM_CODEC.method_56433(class_9135.method_56363()), ClientboundSyncDeathLockDataPacket::locks,
          ClientboundSyncDeathLockDataPacket::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        SealLocks.setClientData(player.method_37908(), locks);
        return true;
    }
}
