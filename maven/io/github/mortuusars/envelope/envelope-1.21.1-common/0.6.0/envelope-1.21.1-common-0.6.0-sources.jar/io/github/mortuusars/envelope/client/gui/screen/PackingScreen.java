package io.github.mortuusars.envelope.client.gui.screen;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.gui.Sprites;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.world.inventory.PackingMenu;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_344;
import net.minecraft.class_4185;
import net.minecraft.class_7919;
import net.minecraft.class_8666;

public class PackingScreen extends AbstractInHandContainerScreen<PackingMenu> {
    public static final class_2960 TEXTURE = Envelope.resource("textures/gui/packing.png");
    public static final class_8666 PACK_BUTTON_SPRITES = Sprites.threeStates(Envelope.resource("packing/pack_button"));

    protected class_344 packButton;

    public PackingScreen(PackingMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title, TEXTURE);
    }

    @Override
    protected void method_25426() {
        field_2792 = 176;
        field_2779 = 178;
        super.method_25426();

        packButton = method_37063(new class_344(field_2776 + 126, field_2800 + 40, 26, 20,
              PACK_BUTTON_SPRITES,
              this::pack,
              class_2561.method_43471("gui.envelope.package.pack")));
        packButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.envelope.package.pack")));
    }

    protected void pack(class_4185 button) {
        method_17577().method_7604(method_17577().getPlayer(), PackingMenu.PACK_BUTTON_ID);
        Minecrft.gameMode().method_2900(method_17577().field_7763, PackingMenu.PACK_BUTTON_ID);
        method_25419();
    }

    @Override
    protected void updateButtons() {
        packButton.field_22763 = !method_17577().isPacked();
        packButton.field_22764 = method_17577().canPack();
    }
}
