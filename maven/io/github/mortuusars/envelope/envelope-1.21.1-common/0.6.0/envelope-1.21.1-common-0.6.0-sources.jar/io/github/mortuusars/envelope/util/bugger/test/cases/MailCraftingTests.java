package io.github.mortuusars.envelope.util.bugger.test.cases;

import io.github.mortuusars.envelope.util.bugger.test.BuggerTests;
import io.github.mortuusars.envelope.util.bugger.test.Test;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailRecipeInput;
import io.github.mortuusars.envelope.world.item.crafting.mail.Mailing;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailCraftingRecipe;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.Address;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2371;
import net.minecraft.server.MinecraftServer;
import java.util.Arrays;

public class MailCraftingTests extends BuggerTests {
    public static final int RECIPE_EXPERIENCE = 3;
    private final MinecraftServer server;

    public MailCraftingTests(MinecraftServer server) {
        this.server = server;


        add("MailCrafting_CraftsWithoutRemainder", Test.isTrue(() -> {
            Mailing.Result result = Mailing.craft(
                  recipe(
                        class_1856.method_8091(class_1802.field_8687),
                        class_1856.method_8091(class_1802.field_8477),
                        class_1856.method_8091(class_1802.field_8477)
                  ),
                  input(
                        new class_1799(class_1802.field_8687, 6),
                        new class_1799(class_1802.field_8477, 6),
                        new class_1799(class_1802.field_8477, 6)
                  ));

            return result.input().method_59987() && result.output().size() == 1 && result.output().getFirst().method_7947() == 6;
        }));

        add("MailCrafting_CraftsWithRemainder", Test.isTrue(() -> {
            Mailing.Result result = Mailing.craft(
                  recipe(
                        class_1856.method_8091(class_1802.field_8687),
                        class_1856.method_8091(class_1802.field_8477),
                        class_1856.method_8091(class_1802.field_8477)
                  ),
                  input(
                        new class_1799(class_1802.field_8687, 16),
                        new class_1799(class_1802.field_8477, 6),
                        new class_1799(class_1802.field_8477, 6)
                  ));

            return !result.input().method_59987()
                  && result.input().items().stream().filter(stack -> !stack.method_7960()).toList().getFirst().method_7947() == 10
                  && result.output().size() == 1;
        }));

        add("MailCrafting_CraftingReturnsCorrectTotalExperience", Test.isTrue(() -> {
            Mailing.Result result = Mailing.craft(
                  recipe(
                        class_1856.method_8091(class_1802.field_8687),
                        class_1856.method_8091(class_1802.field_8477),
                        class_1856.method_8091(class_1802.field_8477)
                  ),
                  input(
                        new class_1799(class_1802.field_8687, 3),
                        new class_1799(class_1802.field_8477, 3),
                        new class_1799(class_1802.field_8477, 3)
                  ));

            return result.input().method_59987() && result.experience() == RECIPE_EXPERIENCE * 3;
        }));

        add("MailCrafting_ConsumesCorrectly", Test.isTrue(() -> {
            MailCraftingRecipe recipe = recipe(
                  class_1856.method_8091(class_1802.field_8687),
                  class_1856.method_8091(class_1802.field_8477)
            );

            MailRecipeInput input = input(
                  new class_1799(class_1802.field_8687),
                  new class_1799(class_1802.field_8477)
            );

            Mailing.consumeInputs(recipe, input);

            return input.method_59987();
        }));

        add("MailCrafting_ConsumesAndReturnsRemainder", Test.isTrue(() -> {
            MailCraftingRecipe recipe = recipe(
                  class_1856.method_8091(class_1802.field_8687),
                  class_1856.method_8091(class_1802.field_8477)
            );

            MailRecipeInput input = input(
                  new class_1799(class_1802.field_8687),
                  new class_1799(class_1802.field_8477, 3)
            );

            Mailing.consumeInputs(recipe, input);

            return input.items()
                  .stream()
                  .filter(stack -> !stack.method_7960())
                  .findAny()
                  .map(stack -> stack.method_7909() == class_1802.field_8477 && stack.method_7947() == 2)
                  .orElse(false);
        }));

        add("MailCrafting_ConsumesOnlyForOneOperation", Test.isTrue(() -> {
            MailCraftingRecipe recipe = recipe(
                  class_1856.method_8091(class_1802.field_8687),
                  class_1856.method_8091(class_1802.field_8477)
            );

            MailRecipeInput input = input(
                  new class_1799(class_1802.field_8687, 6),
                  new class_1799(class_1802.field_8477, 4)
            );

            Mailing.consumeInputs(recipe, input);

            return input.items().getFirst().method_7947() == 5 && input.items().get(1).method_7947() == 3;
        }));
    }

    // --

    private MailCraftingRecipe recipe(class_1856... ingredients) {
        return new MailCraftingRecipe(
              MailService.of(server.method_30002()).getAddress(),
              class_2371.method_10212(class_1856.field_9017, ingredients),
              new class_1799(class_1802.field_8077),
              RECIPE_EXPERIENCE);
    }

    private MailRecipeInput input(class_1799... items) {
        return new MailRecipeInput(server.method_30002().getEnvelopeMailService(), Address.UNKNOWN, Arrays.stream(items).toList());
    }
}
