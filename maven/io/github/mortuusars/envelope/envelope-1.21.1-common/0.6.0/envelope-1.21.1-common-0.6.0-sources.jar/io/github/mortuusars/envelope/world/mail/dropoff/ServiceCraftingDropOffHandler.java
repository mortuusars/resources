package io.github.mortuusars.envelope.world.mail.dropoff;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.PackageItem;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.item.crafting.mail.Mailing;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailRecipeInput;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailRecipe;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_8786;

public class ServiceCraftingDropOffHandler implements MailDropOffHandler {
    private static final Logger LOGGER = LogUtils.getLogger();

    @Override
    public MailDropOffResult handle(MailDropOffContext context) {
        if (!(context.getTarget() instanceof ServiceAddress address)) {
            return MailDropOffResult.PASS;
        }

        class_1799 mail = context.getMail();

        if (mail.method_7960()) {
            return MailDropOffResult.CONSUME;
        }

        if (context.isReturned()) {
            LOGGER.info("Crafting '{}' received returned mail. Delivery: '{}'. Voiding", address, context.getDelivery());
            return MailDropOffResult.CONSUME;
        }

        Address sender = context.getDelivery().getSender();
        if (sender.equals(address)) {
            LOGGER.info("Service Crafting Handler cannot handle mail when sender is it's own address '{}'. Voiding.", context.getDelivery());
            return MailDropOffResult.CONSUME;
        }

        PackageContents packageContents = PackageContents.of(mail);
        if (packageContents.method_59987()) {
            return MailDropOffResult.PASS;
        }

        MailRecipeInput input = new MailRecipeInput(context.getService(), sender, packageContents);

        @Nullable MailRecipe recipe = Mailing.findMatchingRecipe(address, input, context.getLevel())
              .map(class_8786::comp_1933)
              .orElse(null);
        if (recipe == null) {
            return MailDropOffResult.PASS;
        }

        Mailing.Result result = Mailing.craft(recipe, input);

        List<class_1799> results;

        if (result.output().size() == 1
              && result.output().getFirst().method_7947() == 1
              && result.output().getFirst().method_31573(Envelope.Tags.Items.MAILABLE)) {
            results = result.output();
        } else {
            results = Mail.createPackages(result.output(), pkg -> pkg.recipient(sender));
        }

        if (result.experience() > 0) {
            // It's not ideal that all experience is on one package.
            // But implementing it per package would be more complicated, and usually there's only one anyway.
            results.stream()
                  .filter(stack -> stack.method_7909() instanceof PackageItem)
                  .findFirst()
                  .ifPresent(stack -> stack.method_57379(Envelope.DataComponents.PACKAGE_EXPERIENCE, result.experience()));
        }

        return sendResults(context.getService(), address, mail, result.input().toPackageContents(), results, sender);
    }

    protected MailDropOffResult sendResults(MailService service, ServiceAddress address, class_1799 mail,
                                            PackageContents remainingInput, List<class_1799> results, Address destination) {
        boolean hasRemainder = false;

        if (!remainingInput.method_59987()) {
            class_1799 remainderPackage = mail.method_7972();
            remainderPackage.method_57379(Envelope.DataComponents.PACKAGE_CONTENTS, remainingInput);
            results.addFirst(remainderPackage);
            hasRemainder = true;
        }

        if (results.isEmpty()) {
            return MailDropOffResult.CONSUME;
        }

        results.stream()
              .skip(1)
              .forEach(pkg -> {
                  service.getDeliveryManager()
                        .startService(Delivery.draft()
                              .deliver(pkg)
                              .from(address)
                              .to(destination));
              });

        if (hasRemainder) {
            return MailDropOffResult.returned(results.getFirst(), DeliveryRecord.Message.CRAFTING_UNPROCESSED_ITEMS);
        } else {
            return MailDropOffResult.reply(Mail.of(results.getFirst()).get());
        }
    }
}