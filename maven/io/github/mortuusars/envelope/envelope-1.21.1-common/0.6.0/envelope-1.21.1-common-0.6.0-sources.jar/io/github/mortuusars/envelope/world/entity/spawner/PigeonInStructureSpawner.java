package io.github.mortuusars.envelope.world.entity.spawner;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1317;
import net.minecraft.class_1657;
import net.minecraft.class_1928;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_4153;
import net.minecraft.class_5304;
import net.minecraft.class_5819;
import net.minecraft.class_7477;

public class PigeonInStructureSpawner implements class_5304 {
    protected static final int SPAWN_ATTEMPT_DELAY = 1000;
    protected int nextAttemptDelay;

    @Override
    public int method_6445(class_3218 level, boolean spawnEnemies, boolean spawnFriendlies) {
        if (!spawnFriendlies || !level.method_8450().method_8355(class_1928.field_19390)) {
            return 0;
        }

        nextAttemptDelay--;

        if (nextAttemptDelay > 0) {
            return 0;
        }

        nextAttemptDelay = SPAWN_ATTEMPT_DELAY;

        class_1657 player = level.method_18779();
        if (player == null) {
            return 0;
        }

        class_5819 randomSource = level.field_9229;
        int x = (8 + randomSource.method_43048(24)) * (randomSource.method_43056() ? -1 : 1);
        int y = (8 + randomSource.method_43048(24)) * (randomSource.method_43056() ? -1 : 1);
        class_2338 spawnPos = player.method_24515().method_10069(x, 0, y);
        spawnPos = level.method_8598(class_2902.class_2903.field_13197, spawnPos);

        if (!level.method_8477(spawnPos)) {
            return 0;
        }

        if (class_1317.method_56558(Envelope.EntityTypes.PIGEON.get(), level, spawnPos)) {
            if (Config.Server.PIGEON_SPAWNS_IN_VILLAGE.get() && level.method_19497(spawnPos, 2)) {
                return this.spawnInVillage(level, spawnPos);
            }

            if (level.method_27056().method_57560(spawnPos, Envelope.Tags.Structures.PIGEONS_SPAWN_IN).method_16657()) {
                return this.spawnInStructure(level, spawnPos);
            }
        }

        return 0;
    }

    protected int spawnInVillage(class_3218 serverLevel, class_2338 pos) {
        int area = 48;
        if (serverLevel.method_19494().method_20252(holder ->
              holder.method_40225(class_7477.field_39291), pos, area, class_4153.class_4155.field_18488) > 4L) {
            List<Pigeon> pigeonsInArea = serverLevel.method_18467(Pigeon.class, new class_238(pos).method_1009(area, 8.0, area));
            if (pigeonsInArea.size() < 5) {
                 return spawn(serverLevel, pos);
            }
        }

        return 0;
    }

    protected int spawnInStructure(class_3218 serverLevel, class_2338 pos) {
        int area = 16;
        List<Pigeon> list = serverLevel.method_18467(Pigeon.class, new class_238(pos).method_1009(area, 8.0, area));
        return list.isEmpty() ? this.spawn(serverLevel, pos) : 0;
    }

    protected int spawn(class_3218 level, class_2338 pos) {
        @Nullable Pigeon pigeon = Envelope.EntityTypes.PIGEON.get().method_5883(level);
        if (pigeon == null) {
            return 0;
        }

        pigeon.method_5725(pos, 0.0F, 0.0F);
        pigeon.method_5943(level, level.method_8404(pos), class_3730.field_16459, null);
        level.method_30771(pigeon);
        level.method_43129(null, pigeon, Envelope.SoundEvents.PIGEON_AMBIENT.get(), class_3419.field_15254, 2, 1);
        return 1;
    }
}
