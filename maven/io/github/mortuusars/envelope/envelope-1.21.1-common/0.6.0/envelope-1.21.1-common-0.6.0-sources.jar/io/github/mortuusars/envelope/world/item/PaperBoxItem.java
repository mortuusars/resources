package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.Platform;
import io.github.mortuusars.envelope.world.block.PaperBoxBlock;
import io.github.mortuusars.envelope.world.inventory.PackingMenu;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_747;
import org.jetbrains.annotations.NotNull;

public class PaperBoxItem extends class_1747 {
    public PaperBoxItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_2680 state = context.method_8045().method_8320(context.method_8037());
        if (context.method_8036() != null && !context.method_8036().method_21823()
              && (!(state.method_26204() instanceof PaperBoxBlock) || state.method_11654(PaperBoxBlock.BOXES) >= 4)) {
            openPackingMenu(context.method_8036(), context.method_20287(), context.method_8041());
            return class_1269.field_51370;
        }

        return super.method_7884(context);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        class_1799 stack = player.method_5998(usedHand);
        openPackingMenu(player, usedHand, stack);
        return class_1271.method_22427(stack);
    }

    public boolean openPackingMenu(class_1657 player, class_1268 hand, class_1799 stack) {
        if (player instanceof class_3222 serverPlayer) {
            class_747 menuProvider = new class_747((id, inventory, pl) ->
                  new PackingMenu(id, inventory, hand), stack.method_7964());
            Platform.openMenu(serverPlayer, menuProvider, buffer ->
                  buffer.method_10817(hand));
        }

        player.method_37908().method_43129(player, player, Envelope.SoundEvents.PAPER_USE.get(), class_3419.field_15248, 0.6f, 0.95f);
        return true;
    }
}