package io.github.mortuusars.envelope.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.envelope.util.bugger.test.BuggerTests;
import io.github.mortuusars.envelope.util.bugger.test.TestResults;
import io.github.mortuusars.envelope.util.bugger.test.cases.CourierDeliveryTests;
import io.github.mortuusars.envelope.util.bugger.test.cases.MailCraftingRecipeTests;
import io.github.mortuusars.envelope.util.bugger.test.cases.MailCraftingTests;
import io.github.mortuusars.envelope.util.bugger.test.cases.StackIngredientTests;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import io.github.mortuusars.envelope.world.mail.service.EquineAssuranceBureau;
import io.github.mortuusars.envelope.world.mail.service.ServiceAddresses;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class EnvelopeDebugCommand {
    public static LiteralArgumentBuilder<class_2168> commands() {
        return class_2170.method_9247("debug")
              .then(class_2170.method_9247("expire_all_awaiting_payback")
                    .executes(EnvelopeDebugCommand::timeoutAllPaybackMail))
              .then(class_2170.method_9247("run_tests")
                    .executes(EnvelopeDebugCommand::runBuggerTests))
              .then(class_2170.method_9247("test")
                    .executes(EnvelopeDebugCommand::test));
    }

    private static int timeoutAllPaybackMail(CommandContext<class_2168> context) {
        class_3218 level = context.getSource().method_9225();
        MailService service = MailService.of(level);
        int returnedCount = service.getPaybackDepartment().returnAllAwaitingAsTimedOut();

        if (returnedCount > 0) {
            context.getSource().method_9226(() -> class_2561.method_43470("Returned " +
                  returnedCount + " mail awaiting payback."), true);
        } else {
            context.getSource().method_9213(class_2561.method_43470("No mail awaiting payback is returned."));
        }

        return 0;
    }

    private static int runBuggerTests(CommandContext<class_2168> context) {
        TestResults testResults = new BuggerTests()
              .add(new StackIngredientTests(context.getSource().method_9211()))
              .add(new CourierDeliveryTests(context.getSource().method_9211()))
              .add(new MailCraftingRecipeTests(context.getSource().method_9211()))
              .add(new MailCraftingTests(context.getSource().method_9211()))
              .run(count -> context.getSource().method_9226(() ->
                    class_2561.method_43470("Running " + count + " bugger tests."), true));

        context.getSource().method_9226(() -> class_2561.method_43470("Bugger tests finished:"), true);

        if (testResults.failed().isEmpty()) {
            context.getSource().method_9226(() -> class_2561.method_43470("All tests are passed!")
                  .method_27692(class_124.field_1060), true);
        } else {
            context.getSource().method_9226(() -> class_2561.method_43470("Passed: " + testResults.passed().size() + "\n"), true);
            context.getSource().method_9226(() -> class_2561.method_43470("Failed: " + testResults.failed().size() + ":")
                  .method_27692(class_124.field_1061), true);

            testResults.failed().forEach(failedTest -> {
                context.getSource().method_9226(() -> class_2561.method_43470(" " + failedTest.name() + ": " + failedTest.error())
                      .method_27692(class_124.field_1061), true);
            });
        }

        return 0;
    }

    // --

    private static int test(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_3222 player = context.getSource().method_9207();

        EquineAssuranceBureau.sendNotice(MailService.of(player.method_51469()),
              ServiceAddress.getOrThrow(player.method_56673(), ServiceAddresses.EQUINE_ASSURANCE_BUREAU));

//        ItemStack item = new ItemStack(Envelope.Items.LETTER.get());
//        item.set(Envelope.DataComponents.LETTER_CONTENT,
//              new LetterContent(Component.translatable("gui.abuseReport.comments").withColor(0xFFAA7733)));
//        Mail.writeToLog(item, DeliveryRecord.sentFrom(Address.UNKNOWN, 123141L),
//              DeliveryRecord.payback(Component.literal("Test"), DeliveryRecord.MessageType.POSITIVE));
//        Mail.setSender(item, Address.UNKNOWN);
//
//        player.drop(item, false);


//        List<RecipeHolder<MailRecipe>> recipes = player.level().getRecipeManager().getAllRecipesFor(Envelope.RecipeTypes.MAILING.get());
//
//        List<ItemStack> items = List.of(
//              new ItemStack(Envelope.Items.ADDRESS_TAG.get(), 3),
//              new ItemStack(Items.RED_DYE),
//              new ItemStack(Items.RED_DYE),
//              new ItemStack(Items.RED_DYE)
//        );
//
//        SimpleRecipeInput input = new SimpleRecipeInput(items);
//        @Nullable MailRecipe recipe = null;
//
//        for (RecipeHolder<MailRecipe> holder : recipes) {
//            if (holder.value().matches(input, player.level())) {
//                recipe = holder.value();
//            }
//        }

//        MailService.of(player.serverLevel()).getDeliveryManager()
//              .startService(Delivery.draft()
//                    .deliver(Mail.createPackage(new PackageContents(List.of(new ItemStack(Items.ACACIA_LOG))))
//                          .get())
//                    .from(new Address.Block("Blue"))
//                    .to(new Address.Block("Red"))
//                    .startAtPhase(DeliveryPhase.DISPATCHING_DELIVERY));

//        ItemStack pkg = new ItemStack(Envelope.Items.PACKAGE.get());
//        pkg.set(Envelope.DataComponents.PACKAGE_CONTENTS, new PackageContents(List.of(new ItemStack(Items.FEATHER, 5))));
//        pkg.set(Envelope.DataComponents.SENDER, new Address.Block("Original-Sender"));
//        pkg.set(Envelope.DataComponents.RECIPIENT, new Address.Block("Base"));
//        pkg.set(Envelope.DataComponents.PAYBACK, Payback.createOrDefault(List.of(
//              new RequestedItem(Items.EMERALD, 3), new RequestedItem(ItemTags.LOGS, 13))));
//
//        Mail mail = new Mail(pkg);
//
//        ItemStack paybackPackage = new ItemStack(Envelope.Items.PAYBACK_PACKING_BOX.get());
//        paybackPackage.set(Envelope.DataComponents.PAYBACK_SUBJECT, new StoredItemStack(mail.getItemCopy()));
//        paybackPackage.set(Envelope.DataComponents.SENDER, Address.MAIL_SERVICE);
//        paybackPackage.set(Envelope.DataComponents.RECIPIENT, mail.getRecipient());
//
//        Containers.dropItemStack(context.getSource().getLevel(), player.getX(), player.getY(), player.getZ(), paybackPackage);

        return 0;
    }
}
