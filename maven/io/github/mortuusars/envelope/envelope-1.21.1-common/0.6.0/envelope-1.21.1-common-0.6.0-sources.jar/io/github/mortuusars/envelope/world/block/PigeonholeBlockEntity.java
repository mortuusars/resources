package io.github.mortuusars.envelope.world.block;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.block.occupiable.PigeonOccupiable;
import io.github.mortuusars.envelope.world.block.occupiable.Occupant;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_7225;
import net.minecraft.class_9323;
import net.minecraft.nbt.*;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public class PigeonholeBlockEntity extends class_2586 implements PigeonOccupiable {
    protected List<Occupant.Mutable> occupants = new ArrayList<>();

    protected PigeonholeBlockEntity(class_2591<?> type, class_2338 pos, class_2680 blockState) {
        super(type, pos, blockState);
    }

    public PigeonholeBlockEntity(class_2338 pos, class_2680 blockState) {
        this(Envelope.BlockEntityTypes.PIGEONHOLE.get(), pos, blockState);
    }

    // -- Events

    public void serverTick(class_3218 level, class_2338 pos, class_2680 state) {
        tickOccupants(level, pos, state);
    }

    @Override
    public void method_5431() {
        if (Position.isFireNearby(field_11863, method_11016())) {
            releaseAllOccupants(method_10997(), method_11016(), method_11010(), ReleaseReason.EMERGENCY);
        }
        super.method_5431();
    }

    // -- Occupiable

    @Override
    public List<Occupant.Mutable> getOccupants() {
        return occupants;
    }

    @Override
    public void onOccupantReleased(class_1937 level, class_1297 entity, ReleaseReason reason) {
        if (reason == ReleaseReason.EMERGENCY) return;

        if (method_11010().method_26204() instanceof PigeonholeBlock block
              && level.field_9229.method_43058() < getWasteIncreaseChanceOnRelease(entity)) {
            block.addWaste(level, method_11016(), method_11010());
            method_5431();
        }

        if (entity instanceof Pigeon pigeon) {
            pigeon.releasedFromPigeonhole(method_11016(), method_11010(), reason); // Calling before mail sending to set home pos etc
        }
    }

    protected double getWasteIncreaseChanceOnRelease(class_1297 releasedEntity) {
        return releasedEntity instanceof Pigeon pigeon && pigeon.isTired()
              ? Config.Server.PIGEONHOLE_WASTE_INCREASE_CHANCE_AFTER_DELIVERY.get()
              : Config.Server.PIGEONHOLE_WASTE_INCREASE_CHANCE.get();
    }

    @Override
    public void onOccupantsChanged() {
        method_5431();
    }

    // -- Component

    @Override
    protected void method_57568(class_2586.class_9473 componentInput) {
        super.method_57568(componentInput);
        this.occupants.clear();
        List<Occupant> occupants = componentInput.method_58695(Envelope.DataComponents.PIGEONS, List.of());
        occupants.forEach(o -> getOccupants().add(o.toMutable()));
    }

    @Override
    protected void method_57567(class_9323.class_9324 components) {
        super.method_57567(components);
        components.method_57840(Envelope.DataComponents.PIGEONS, getImmutableOccupants());
    }

    @SuppressWarnings("deprecation")
    @Override
    public void method_57569(class_2487 tag) {
        super.method_57569(tag);
        tag.method_10551(getSerializedOccupantsName());
    }

    // -- Save/Load

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        loadOccupiable(tag, registries);
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        saveOccupiable(tag, registries);
    }

    // --

    public @NotNull class_1937 getLevelOrThrow() {
        return Objects.requireNonNull(field_11863);
    }

    public void playSound(class_3414 soundEvent, float volume, float pitch) {
        if (field_11863 != null) {
            field_11863.method_8396(null, method_11016(), soundEvent, class_3419.field_15245, volume, pitch);
        }
    }
}
