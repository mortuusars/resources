package io.github.mortuusars.envelope.world.item.crafting.mail;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.EnvelopeCodecs;
import io.github.mortuusars.envelope.world.item.component.LetterContent;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import io.github.mortuusars.envelope.world.mail.address.type.PlayerAddress;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9334;

public class MailLetterBroadcastingRecipe extends CustomMailRecipe {
    private final class_2371<class_1856> ingredients;
    private final class_1799 result = Mail.createLetter(class_2561.method_43473())
          .set(class_9334.field_50239, class_2561.method_43471("letter.envelope.broadcast_report.name"))
          .get();

    public MailLetterBroadcastingRecipe(ServiceAddress address, class_2371<class_1856> ingredients) {
        super(address);
        this.ingredients = ingredients;
    }

    @Override
    public @NotNull class_2371<class_1856> method_8117() {
        return ingredients;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return Envelope.RecipeSerializers.MAIL_LETTER_BROADCASTING.get();
    }

    @Override
    public boolean isOneCraftPerDelivery() {
        return true; // Prevent spamming and spawning tons of couriers
    }

    @Override
    public @NotNull class_1799 method_8110(class_7225.class_7874 registries) {
        return result;
    }

    @Override
    public @NotNull class_1799 assemble(MailRecipeInput input, class_7225.class_7874 registries) {
        return method_8110(registries).method_7972();
    }

    @Override
    public @NotNull class_1799 assembleWithSideEffects(MailRecipeInput input, class_7225.class_7874 registries) {
        class_1799 inputLetter = class_1799.field_8037;
        LetterContent content = LetterContent.EMPTY;
        for (class_1799 stack : input.items()) {
            if (stack.method_31573(Envelope.Tags.Items.LETTERS) && stack.method_57826(Envelope.DataComponents.LETTER_CONTENT)) {
                content = stack.method_57825(Envelope.DataComponents.LETTER_CONTENT, LetterContent.EMPTY);
                inputLetter = stack;
                break;
            }
        }

        MailService service = input.service();
        Map<PlayerAddress, BlockAddress> defaultAddresses = service.getKnownPlayers().getDefaultAddresses();

        if (content.isEmpty()) {
            LogUtils.getLogger().error("Cannot broadcast a letter: no suitable letter was provided or the letter is missing a content. {}", input);

            class_2561 reportText = class_2561.method_43473()
                  .method_10852(class_2561.method_43471("letter.envelope.broadcast_report.title").method_27692(class_124.field_1056))
                  .method_27693("\n\n")
                  .method_10852(class_2561.method_43471("letter.envelope.broadcast_report.error_no_message"))
                  .method_27693("\n\n")
                  .method_10852(class_2561.method_43469("letter.envelope.broadcast_report.total",
                        class_2561.method_43470(Integer.toString(0)).method_27692(class_124.field_1073)))
                  .method_27693("\n\n")
                  .method_10852(getAddress().getComponent());

            return Mail.of(assemble(input, registries))
                  .set(Envelope.DataComponents.LETTER_CONTENT, new LetterContent(reportText))
                  .get();
        } else if (defaultAddresses.isEmpty()
              || (defaultAddresses.size() == 1 && defaultAddresses.values().stream().findFirst().get().equals(input.sender()))) {
            class_2561 reportText = class_2561.method_43473()
                  .method_10852(class_2561.method_43471("letter.envelope.broadcast_report.title").method_27692(class_124.field_1056))
                  .method_27693("\n\n")
                  .method_10852(class_2561.method_43471("letter.envelope.broadcast_report.error_no_recipients"))
                  .method_27693("\n\n")
                  .method_10852(class_2561.method_43469("letter.envelope.broadcast_report.total",
                        class_2561.method_43470(Integer.toString(0)).method_27692(class_124.field_1073)))
                  .method_27693("\n\n")
                  .method_10852(getAddress().getComponent());

            return Mail.of(assemble(input, registries))
                  .set(Envelope.DataComponents.LETTER_CONTENT, new LetterContent(reportText))
                  .get();
        } else {
            class_1799 broadcastedLetter = Mail.createLetter(content)
                  .set(class_9334.field_49631, inputLetter.method_57824(class_9334.field_49631))
                  .sender(input.sender())
                  .get();

            int count = 0;

            for (BlockAddress recipient : defaultAddresses.values()) {
                if (recipient.equals(input.sender())) {
                    continue;
                }

                service.getDeliveryManager().startService(Delivery.draft()
                      .deliver(broadcastedLetter.method_7972())
                      .from(service.getAddress())
                      .to(recipient));

                count++;
            }

            class_2561 reportText = class_2561.method_43473()
                  .method_10852(class_2561.method_43471("letter.envelope.broadcast_report.title").method_27692(class_124.field_1056))
                  .method_27693("\n\n")
                  .method_10852(class_2561.method_43471("letter.envelope.broadcast_report.success"))
                  .method_27693("\n\n")
                  .method_10852(class_2561.method_43469("letter.envelope.broadcast_report.total",
                        class_2561.method_43470(Integer.toString(count)).method_27692(class_124.field_1073)))
                  .method_27693("\n\n")
                  .method_10852(getAddress().getComponent());

            return Mail.of(assemble(input, registries))
                  .set(Envelope.DataComponents.LETTER_CONTENT, new LetterContent(reportText))
                  .get();
        }
    }

    public static class Serializer implements class_1865<MailLetterBroadcastingRecipe> {
        public static final MapCodec<MailLetterBroadcastingRecipe> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
              ServiceAddress.DEFINITION_CODEC
                    .fieldOf("address")
                    .forGetter(MailLetterBroadcastingRecipe::getAddress),
              EnvelopeCodecs.recipeIngredients(PackageContents.SLOTS, Envelope.RecipeTypes.MAILING.get())
                    .fieldOf("ingredients")
                    .forGetter(MailLetterBroadcastingRecipe::method_8117)
        ).apply(i, MailLetterBroadcastingRecipe::new));

        public static final class_9139<class_9129, MailLetterBroadcastingRecipe> STREAM_CODEC = class_9139.method_56435(
              ServiceAddress.STREAM_CODEC, MailLetterBroadcastingRecipe::getAddress,
              class_1856.field_48355
                    .method_56433(class_9135.method_58000(PackageContents.SLOTS))
                    .method_56432(list ->
                                class_2371.method_10212(class_1856.field_9017, list.toArray(class_1856[]::new)),
                          Function.identity()), MailLetterBroadcastingRecipe::method_8117,
              MailLetterBroadcastingRecipe::new
        );

        @Override
        public @NotNull MapCodec<MailLetterBroadcastingRecipe> method_53736() {
            return CODEC;
        }

        @Override
        public @NotNull class_9139<class_9129, MailLetterBroadcastingRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }
}
