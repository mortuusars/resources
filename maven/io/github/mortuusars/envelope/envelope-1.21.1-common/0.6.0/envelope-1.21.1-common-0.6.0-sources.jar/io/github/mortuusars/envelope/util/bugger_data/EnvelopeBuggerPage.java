package io.github.mortuusars.envelope.util.bugger_data;

import io.github.mortuusars.envelope.util.bugger.Bugger;
import io.github.mortuusars.envelope.util.bugger.page.BuggerPage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

public class EnvelopeBuggerPage implements BuggerPage {
    @Override
    public String getTitle() {
        return "Envelope";
    }

    @Override
    public List<String> getLeftLines() {
        return Bugger.MAIL_SERVICE.get()
              .map(tag -> {

                  List<String> lines = new ArrayList<>(List.of(
                        "Mailboxes: " + tag.method_10550("mailboxes"),
                        "",
                        "Mail:",
                        "  Dropped: " + tag.method_10550("dropped_mail_count"),
                        "  Awaiting Payback: " + tag.method_10550("payback_pending_mail_count"),
                        "",
                        "Couriers:",
                        "  Real: " + tag.method_10550("delivering_pigeons"),
                        "  Background: " + tag.method_10550("background_delivering_pigeons"),
                        "  Finished: " + tag.method_10550("background_finished_pigeons")
                  ));

                  class_2499 deliveries = tag.method_10554("deliveries", class_2520.field_33258);
                  if (!deliveries.isEmpty()) {
                      lines.add("Deliveries:");
                      for (class_2520 delivery : deliveries) {
                          lines.add("  " + delivery.method_10714());
                      }
                  }

                  return lines;
              })
              .orElse(Collections.emptyList());
    }
}
