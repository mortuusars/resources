package io.github.mortuusars.envelope.world.mail;

import com.google.common.base.Preconditions;
import io.github.mortuusars.envelope.Platform;
import io.github.mortuusars.envelope.util.bugger.Bugger;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import io.github.mortuusars.envelope.world.mail.delivery.DeliveryManager;
import io.github.mortuusars.envelope.world.mail.delivery.background.BackgroundDelivery;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.AddressLocation;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import io.github.mortuusars.envelope.world.mail.address.type.*;
import io.github.mortuusars.envelope.world.mail.service.ServiceAddresses;
import io.github.mortuusars.envelope.world.mail.payback.PaybackDepartment;
import io.github.mortuusars.envelope.world.block.mailbox.Mailboxes;
import io.github.mortuusars.envelope.world.KnownPlayers;
import net.minecraft.class_124;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_3218;
import net.minecraft.class_5244;
import net.minecraft.class_5321;
import net.minecraft.class_9334;
import net.minecraft.network.chat.*;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class MailService {
    protected final class_3218 level;

    protected final Mailboxes mailboxes;
    protected final ServiceAddresses serviceAddresses;
    protected final DeliveryManager deliveryManager;
    protected final PaybackDepartment paybackDepartment;

    protected @Nullable KnownPlayers knownPlayers;
    protected @Nullable BackgroundDelivery backgroundDelivery;

    private MailService(class_3218 level) {
        Preconditions.checkArgument(operatesIn(level), "MailService cannot exist in the '" + level.method_27983().method_29177() + "' dimension.");
        this.level = level;
        this.mailboxes = new Mailboxes(level);
        this.serviceAddresses = new ServiceAddresses(this);
        this.deliveryManager = new DeliveryManager(this);
        this.paybackDepartment = new PaybackDepartment(this);
    }

    /**
     * It's intended to be created only once for a level. Use {@link MailService#of} to get the instance.
     */
    @ApiStatus.Internal
    public static MailService create(class_3218 level) {
        MailService service = new MailService(level);
        service.initialize();
        return service;
    }

    private void initialize() {

    }

    public static MailService of(class_3218 level) {
        return level.getEnvelopeMailService();
    }

    public static boolean operatesIn(class_5321<class_1937> dimension) {
        return dimension.equals(class_1937.field_25179);
    }

    public static boolean operatesIn(class_1937 level) {
        return operatesIn(level.method_27983());
    }

    // --

    public class_3218 getLevel() {
        return level;
    }

    public Mailboxes getMailboxes() {
        return mailboxes;
    }

    public ServiceAddresses getServiceAddresses() {
        return serviceAddresses;
    }

    public DeliveryManager getDeliveryManager() {
        return deliveryManager;
    }

    public PaybackDepartment getPaybackDepartment() {
        return paybackDepartment;
    }

    public @NotNull KnownPlayers getKnownPlayers() {
        return knownPlayers == null
              ? knownPlayers = KnownPlayers.get(level, "envelope_players")
              : knownPlayers;
    }

    public @NotNull BackgroundDelivery getBackgroundDelivery() {
        return backgroundDelivery == null
              ? backgroundDelivery = BackgroundDelivery.get(level, "envelope_background_delivery")
              : backgroundDelivery;
    }

    // -- Address

    public AllAddresses getKnownAddresses() {
        return new AllAddresses(
              getMailboxes().getAllAddresses(),
              getKnownPlayers().getDefaultAddresses().keySet(),
              getServiceAddresses().getAllAddresses()
        );
    }

    public AllAddresses getKnownAddressesOfType(@Nullable Address.Type type) {
        if (type == null) {
            return getKnownAddresses();
        }
        return switch (type) {
            case BLOCK -> AllAddresses.blocks(getMailboxes().getAllAddresses());
            case PLAYER -> AllAddresses.players(getKnownPlayers().getDefaultAddresses().keySet());
            case SERVICE -> AllAddresses.services(getServiceAddresses().getAllAddresses());
            case CUSTOM, UNKNOWN -> AllAddresses.EMPTY;
        };
    }

    public Optional<BlockAddress> getPlayerDefaultAddress(PlayerAddress playerAddress) {
        return Optional.ofNullable(getKnownPlayers().getDefaultAddresses().get(playerAddress));
    }

    public AddressLocation getLocationOf(Address address) {
        return switch (address) {
            case BlockAddress block -> getMailboxes().getPositionOf(block).map(AddressLocation::exact).orElse(AddressLocation.DEFAULT);
            case PlayerAddress player ->
                  getKnownPlayers().getDefaultAddressOf(player).map(this::getLocationOf).orElse(AddressLocation.DEFAULT);
            case ServiceAddress service -> service.getDefinition().location();
            default -> AddressLocation.DEFAULT;
        };
    }

    // --

    public void tick() {
        getBackgroundDelivery().tick(level);
        getPaybackDepartment().tick();
        getServiceAddresses().tick();

        if (level.method_8510() % 20 == 0) Bugger.MAIL_SERVICE.collectAndSendData(this);
    }

    // --

    public long getGameTime() {
        return getLevel().method_8510();
    }

    public void sendCourierDeathNotice(class_1309 courier, Delivery delivery, class_1282 damageSource) {
        Address recipient = delivery.getSender();

        if (!(recipient instanceof BlockAddress) && !(recipient instanceof PlayerAddress)) {
            return;
        }

        class_1799 letter = createCourierDeathNoticeLetter(courier, delivery, damageSource);

        getDeliveryManager().startService(Delivery.draft()
              .deliver(letter)
              .from(getAddress())
              .to(recipient));
    }

    public class_1799 createCourierDeathNoticeLetter(class_1309 courier, Delivery delivery, class_1282 damageSource) {
        class_2561 text = class_2561.method_43473()
              .method_10852(class_2561.method_43471("letter.envelope.courier_death_notice.title").method_27692(class_124.field_1056))
              .method_10852(class_2561.method_43469("letter.envelope.courier_death_notice.inform_" + courier.method_59922().method_43048(5),
                    damageSource.method_5506(courier)))
              .method_10852(class_2561.method_43469("letter.envelope.courier_death_notice.delivery." + delivery.getPhase().method_15434(),
                    delivery.getRecipient().format().withIcon().withIconColor(0xFFB5633F).withColor(0xFFB5633F).toComponent()))
              .method_10852(!delivery.getMail().method_7960()
                    ? class_2561.method_43469("letter.envelope.courier_death_notice.mail_lost_" + courier.method_59922().method_43048(6),
                    delivery.getMail().method_7964().method_27661()
                          .method_27696(class_2583.field_24360.method_30938(true)
                                .method_10949(new class_2568(class_2568.class_5247.field_24343, new class_2568.class_5249(delivery.getMail())))))
                    : class_5244.field_39003)
              .method_10852(class_2561.method_43469("letter.envelope.courier_death_notice.condolence_" + courier.method_59922().method_43048(5),
                    courier.method_5477()))
              .method_27693("\n\n")
              .method_10852(class_2561.method_43471("letter.envelope.mail_service.signature"));

        return Mail.createLetter(text)
              .set(class_9334.field_50239, class_2561.method_43471("letter.envelope.courier_death_notice.name"))
              .get();
    }

    public ServiceAddress getAddress() {
        return ServiceAddress.getOrThrow(getLevel().method_30349(), ServiceAddresses.MAIL_SERVICE);
    }

    /**
     * Common storage for mail related data that needs to persist.<br>
     * Can be used by mail entities, custom handlers, etc.
     */
    public CustomMailSavedData getPersistentData() {
        return CustomMailSavedData.get(getLevel());
    }

    // --

    public static void init() {
        Platform.registerServiceDropOffHandlers();
    }
}