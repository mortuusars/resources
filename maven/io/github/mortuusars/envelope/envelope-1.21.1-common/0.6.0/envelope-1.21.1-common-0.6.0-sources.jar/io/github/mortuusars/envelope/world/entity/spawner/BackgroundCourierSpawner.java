package io.github.mortuusars.envelope.world.entity.spawner;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import io.github.mortuusars.envelope.world.mail.delivery.PhysicalCourier;
import io.github.mortuusars.envelope.world.mail.delivery.background.BackgroundCourier;
import io.github.mortuusars.envelope.world.mail.delivery.background.BackgroundDelivery;
import io.github.mortuusars.envelope.world.mail.MailService;
import net.minecraft.class_1297;
import net.minecraft.class_156;
import net.minecraft.class_1928;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_7923;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.List;
import java.util.Optional;

public class BackgroundCourierSpawner extends Spawner {
    private static final Logger LOGGER = LogUtils.getLogger();

    public BackgroundCourierSpawner() {
        super(10);
    }

    @Override
    public boolean worksIn(class_3218 level) {
        return MailService.operatesIn(level);
    }

    @Override
    public void spawn(class_3218 level) {
        if (Config.Server.DELIVERY_SPAWNING_RESPECTS_DOMOBSPAWNING_RULE.get()
              && !level.method_8450().method_8355(class_1928.field_19390)) {
            return;
        }

        BackgroundCourier courier = selectCourier(level);
        if (courier != null) {
            trySpawn(level, courier);
        }
    }

    private @Nullable BackgroundCourier selectCourier(class_3218 level) {
        BackgroundDelivery backgroundDelivery = MailService.of(level).getBackgroundDelivery();

        List<BackgroundCourier> spawnableCouriers = backgroundDelivery.getActiveCouriers()
              .stream()
              .filter(this::canSpawn)
              .toList();

        if (spawnableCouriers.isEmpty()) {
            return null;
        }

        return class_156.method_32309(spawnableCouriers, level.method_8409());
    }

    protected boolean canSpawn(BackgroundCourier courier) {
        if (courier.getOrigin().isService()
              && courier.getDelivery().getMail().method_7960()
              && !courier.getDelivery().getPhase().isOnRecipientSide()) {
            return false; // Don't spawn service couriers when it doesn't make sense
        }

        return courier.getDelivery().getPhase().isSpawnable();
    }

    protected Optional<class_2338> getSpawnPos(class_3218 level, BackgroundCourier courier) {
        Delivery delivery = courier.getDelivery();

        int duration = courier.getPhaseDuration(level, delivery, delivery.getPhase());
        int progress = delivery.getPhaseProgress();
        float completeness = class_3532.method_15363(progress / (float) duration, 0f, 1f);

        return delivery.getRoute().getSegment(delivery.getPhase()).getCurrentLocation(completeness)
              .filter(level::method_8477)
              .map(pos -> Position.aboveGround(level, pos, 2))
              .filter(pos -> Position.isInSimulationDistance(level, pos));
    }

    protected void trySpawn(class_3218 level, BackgroundCourier backgroundCourier) {
        getSpawnPos(level, backgroundCourier)
              .ifPresent(pos -> {
                  @Nullable class_1297 entity = backgroundCourier.getSpawnableEntityData().createEntity(level);
                  backgroundCourier.setRemoved();

                  if (entity == null) {
                      return;
                  }

                  entity.method_5725(pos, entity.method_36454(), entity.method_36455());
                  level.method_30771(entity);

                  if (entity instanceof PhysicalCourier courier) {
                      courier.onAppeared(level);
                      courier.setDelivery(backgroundCourier.getDelivery());
                  } else {
                      class_2960 id = class_7923.field_41177.method_10221(entity.method_5864());
                      LOGGER.error("Failed to spawn BackgroundCourier properly: entity is not a Courier, but {}. Tag: {}",
                            id, backgroundCourier.getSpawnableEntityData().data());
                  }
              });
    }
}
