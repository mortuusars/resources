package io.github.mortuusars.envelope.world.inventory;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.clientbound.MailboxMenuMailRemovedS2CP;
import io.github.mortuusars.envelope.network.packet.clientbound.MailboxMenuSetMailS2CP;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlockEntity;
import io.github.mortuusars.envelope.world.item.component.Id;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3915;
import net.minecraft.class_3917;
import net.minecraft.class_7995;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.BiConsumer;

public class MailboxMenu extends class_1703 {
    public static final int ADDRESS_BUTTON_ID = 0;
    public static final int REFRESH_MAIL_BUTTON_ID = 1;

    protected final class_3915 hasDefault = class_3915.method_17403();
    protected final class_3915 isDefault = class_3915.method_17403();

    protected final class_1661 playerInventory;
    protected final class_1657 player;
    protected final class_2338 pos;
    protected final BlockAddress address;
    protected final MailboxBlockEntity blockEntity;

    protected List<class_1799> mail;
    protected boolean hasNewMail;

    protected MailboxMenu(@Nullable class_3917<?> menuType, int id, class_1661 playerInventory,
                          class_2338 pos, BlockAddress address, List<class_1799> mail) {
        super(menuType, id);
        this.playerInventory = playerInventory;
        this.player = playerInventory.field_7546;
        this.pos = pos;
        this.address = address;
        if (!(playerInventory.field_7546.method_37908().method_8321(pos) instanceof MailboxBlockEntity be)) {
            throw new IllegalStateException("MailboxBlockEntity is not available at " + pos);
        }
        this.blockEntity = be;
        setMail(mail);

        method_7621(new class_1735(be, MailboxBlockEntity.SLOT_FOOD, 201, 37) {
            @Override
            public boolean method_7680(class_1799 stack) {
                return be.method_5437(MailboxBlockEntity.SLOT_FOOD, stack);
            }
        });
        method_7621(new class_1735(be, MailboxBlockEntity.SLOT_MAIL, 222, 37) {
            @Override
            public boolean method_7680(class_1799 stack) {
                return be.method_5437(MailboxBlockEntity.SLOT_MAIL, stack);
            }
        });
        addPlayerSlots(playerInventory, 140, 88);
        method_17362(hasDefault);
        method_17362(isDefault);
        updateHasDefault();
        updateIsDefault();
    }

    public MailboxMenu(int id, class_1661 playerInventory, class_2338 pos, BlockAddress address, List<class_1799> mail) {
        this(Envelope.MenuTypes.MAILBOX.get(), id, playerInventory, pos, address, mail);
    }

    public static MailboxMenu fromNetwork(int id, class_1661 inventory, class_9129 buffer) {
        class_2338 mailboxPos = buffer.method_10811();
        BlockAddress address = BlockAddress.STREAM_CODEC.decode(buffer);
        List<class_1799> mail = class_1799.field_48350.decode(buffer);
        return new MailboxMenu(id, inventory, mailboxPos, address, mail);
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return getBlockEntity().method_5443(player)
              // Close menu if address changes. Easier than resyncing it to the client.
              && getBlockEntity().getAddress().equals(address);
    }

    // --

    public class_2338 getBlockPosition() {
        return pos;
    }

    public MailboxBlockEntity getBlockEntity() {
        return blockEntity;
    }

    public Address getAddress() {
        return address;
    }

    public boolean hasDefaultAddress() {
        if (player instanceof class_3222 serverPlayer) {
            return serverPlayer.method_51469().getEnvelopeMailService().getKnownPlayers()
                  .getDefaultAddressOf(player)
                  .isPresent();
        }
        return hasDefault.method_17407() == 1;
    }

    protected void updateHasDefault() {
        if (player instanceof class_3222) {
            hasDefault.method_17404(hasDefaultAddress() ? 1 : 0);
        }
    }

    public boolean isDefaultAddress() {
        if (player instanceof class_3222 serverPlayer) {
            return serverPlayer.method_51469().getEnvelopeMailService().getKnownPlayers()
                  .getDefaultAddressOf(player)
                  .map(address::equals)
                  .orElse(false);
        }
        return isDefault.method_17407() == 1;
    }

    protected void updateIsDefault() {
        if (player instanceof class_3222) {
            isDefault.method_17404(isDefaultAddress() ? 1 : 0);
        }
    }

    public List<class_1799> getMail() {
        return mail;
    }

    public void setMail(List<class_1799> mail) {
        this.mail = new ArrayList<>(mail.reversed());
        setHasNewMail(false);
    }

    public boolean hasNewMail() {
        return hasNewMail;
    }

    public void setHasNewMail(boolean hasNewMail) {
        this.hasNewMail = hasNewMail;
    }

    // --

    protected void addPlayerSlots(class_1661 playerInventory, int x, int y) {
        // Hotbar
        for (int slot = 0; slot < 9; slot++) {
            method_7621(new class_1735(playerInventory, slot, x + slot * 18, y + 58));
        }

        // Inventory
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                method_7621(new class_1735(playerInventory, (column + row * 9) + 9, x + column * 18, y + row * 18));
            }
        }
    }

    // --

    @Override
    public @NotNull class_1799 method_7601(@NotNull class_1657 player, int index) {
        class_1735 slot = field_7761.get(index);
        if (!slot.method_7681()) return class_1799.field_8037;

        class_1799 clickedStack = slot.method_7677();
        class_1799 returnedStack = clickedStack.method_7972();

        if (index < MailboxBlockEntity.REGULAR_SLOTS) {
            if (!method_7616(clickedStack, MailboxBlockEntity.REGULAR_SLOTS, field_7761.size(), true)) {
                return class_1799.field_8037;
            }
        } else if (index < field_7761.size()) {
            if (!method_7616(clickedStack, 0, MailboxBlockEntity.REGULAR_SLOTS, false))
                return class_1799.field_8037;
        }

        if (clickedStack.method_7960()) {
            slot.method_7673(class_1799.field_8037);
        } else {
            slot.method_7668();
        }

        return returnedStack;
    }

    public boolean doMailAction(class_1657 player, int index, MailAction action) {
        if (index < 0 || index >= getMail().size()) return false;

        return switch (action) {
            case PICK_UP -> pickUpMail(player, index);
            case MOVE_TO_INVENTORY -> moveMailToInventory(player, index);
            case MOVE_ALL_TO_INVENTORY -> moveAllMailToInventory(player);
        };
    }

    protected boolean pickUpMail(class_1657 player, int index) {
        if (!method_34255().method_7960()) {
            return false;
        }

        if (player.method_37908() instanceof class_3218 serverLevel) {
            method_34254(extractMail(serverLevel, index));
        }

        return true;
    }

    protected boolean moveMailToInventory(class_1657 player, int index) {
        class_1799 mail = getMail().get(index).method_7972();

        if (!PlayerInventoryUtil.canAddWholeStack(player, mail)) {
            return false;
        }

        if (player.method_37908() instanceof class_3218 serverLevel) {
            class_1799 taken = extractMail(serverLevel, index);
            if (!taken.method_7960()) {
                player.method_31548().method_7394(taken);
            }
        }

        return true;
    }

    protected boolean moveAllMailToInventory(class_1657 player) {
        boolean movedSomething = false;
        while (!getMail().isEmpty()) {
            if (!moveMailToInventory(player, 0)) {
                return movedSomething;
            }
            movedSomething = true;
        }
        return true;
    }

    protected class_1799 extractMail(class_3218 level, int index) {
        return Optional.ofNullable(Mail.getId(getMail().get(index)))
              .map(id -> getBlockEntity().removeMail(id))
              .orElse(class_1799.field_8037);
    }

    // --

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (id == ADDRESS_BUTTON_ID && player instanceof class_3222 serverPlayer) {
            serverPlayer.method_51469().getEnvelopeMailService().getKnownPlayers().setDefaultAddress(player, address);
            updateHasDefault();
            updateIsDefault();
            return true;
        }

        if (id == REFRESH_MAIL_BUTTON_ID && player instanceof class_3222 serverPlayer) {
            List<class_1799> mail = getBlockEntity().getAllMail();
            setMail(mail);
            Packets.sendToClient(new MailboxMenuSetMailS2CP(mail), serverPlayer);
            return true;
        }

        return false;
    }

    public static List<class_3222> playersWithMenu(class_3218 level, @Nullable BlockAddress address) {
        return level.method_18456().stream()
              .filter(pl -> pl.field_7512 instanceof MailboxMenu menu && menu.getAddress().equals(address))
              .toList();
    }

    public static void executeForPlayersWithMenu(class_3218 level, @Nullable BlockAddress address, BiConsumer<class_3222, MailboxMenu> action) {
        playersWithMenu(level, address).forEach(pl -> action.accept(pl, ((MailboxMenu) pl.field_7512)));
    }

    public void onMailRemoved(Id id) {
        getMail().removeIf(m -> id.equals(Mail.getId(m)));
        if (player instanceof class_3222 serverPlayer) {
            Packets.sendToClient(new MailboxMenuMailRemovedS2CP(id), serverPlayer);
        }
    }

    // --

    public enum MailAction {
        PICK_UP,
        MOVE_TO_INVENTORY,
        MOVE_ALL_TO_INVENTORY;

        public static final class_9139<ByteBuf, MailAction> STREAM_CODEC = class_9135.method_56375(
              class_7995.method_47914(MailAction::ordinal, values(), class_7995.class_7996.field_41664), MailAction::ordinal);
    }
}
