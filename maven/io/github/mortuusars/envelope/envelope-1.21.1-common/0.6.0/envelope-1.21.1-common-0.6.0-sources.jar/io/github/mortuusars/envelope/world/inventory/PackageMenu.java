package io.github.mortuusars.envelope.world.inventory;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.inventory.slot.PickupOnlySlot;
import io.github.mortuusars.envelope.world.item.PackageItem;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3917;
import net.minecraft.class_9129;

public class PackageMenu extends AbstractInHandContainerMenu {
    private final PackageContents initialContents;

    protected PackageMenu(@Nullable class_3917<?> menuType, int containerId, class_1661 inventory,
                          class_1268 hand) {
        super(menuType, containerId, inventory, hand);
        this.initialContents = PackageContents.of(getItemInHand());
    }

    public PackageMenu(int containerId, class_1661 inventory, class_1268 hand) {
        this(Envelope.MenuTypes.PACKAGE.get(), containerId, inventory, hand);
    }

    public static PackageMenu fromNetwork(int id, class_1661 inventory, class_9129 buffer) {
        return new PackageMenu(id, inventory, buffer.method_10818(class_1268.class));
    }

    public PackageContents getInitialContents() {
        return initialContents;
    }

    public boolean isDestroyedOnClose() {
        return getContainer().method_5442() || !getInitialContents().equals(new PackageContents(getContainer()));
    }

    // --

    @Override
    protected class_1263 createContainer() {
        List<class_1799> items = new ArrayList<>(PackageContents.of(getItemInHand()).copyItems());
        while (items.size() < PackageContents.SLOTS) {
            items.add(class_1799.field_8037);
        }

        return new class_1277(items.stream().limit(PackageContents.SLOTS).toArray(class_1799[]::new));
    }

    @Override
    protected void addContainerSlots() {
        int packageSlotsX = 62;
        int packageSlotsY = 33;

        for (int row = 0; row < 2; row++) {
            for (int column = 0; column < 3; column++) {
                int index = column + row * 3;
                int x = packageSlotsX + column * 18;
                int y = packageSlotsY + row * 18;

                method_7621(new PickupOnlySlot(getContainer(), index, x, y));
            }
        }
    }

    @Override
    public @NotNull class_1799 method_7601(@NotNull class_1657 player, int index) {
        if (index >= getContainer().method_5439() && index < field_7761.size()) {
            // Prevent inserting into package.
            // Otherwise, if items are the same, they will be inserted even if Slot#mayPlace is false.
            return class_1799.field_8037;
        }
        return super.method_7601(player, index);
    }

    @Override
    public void method_7595(@NotNull class_1657 player) {
        if (isDestroyedOnClose()) {
            class_1264.method_5451(player.method_37908(), player.method_24515(), getContainer());
            getContainer().method_5448();

            class_1799 stack = getItemInHand();
            onDestroyed(player, stack);
            stack.method_7934(1);

            player.method_37908().method_43129(player, player, class_3417.field_15075, class_3419.field_15248, 1, 1);
        }

        super.method_7595(player);
    }

    protected void onDestroyed(@NotNull class_1657 player, class_1799 stack) {
        if (stack.method_7909() instanceof PackageItem item) {
            item.onDestroyed(stack, player.method_37908(), player.method_19538());
        }
    }
}