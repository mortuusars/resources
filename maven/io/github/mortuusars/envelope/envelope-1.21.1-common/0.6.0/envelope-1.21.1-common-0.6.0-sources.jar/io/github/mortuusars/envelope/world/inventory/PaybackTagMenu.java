package io.github.mortuusars.envelope.world.inventory;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.inventory.slot.GhostSlot;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.component.PaybackDuration;
import io.github.mortuusars.envelope.world.item.component.PaybackRequest;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_3915;
import net.minecraft.class_3917;
import net.minecraft.class_9129;

public class PaybackTagMenu extends AbstractInHandContainerMenu {
    public static final int CONFIRM_BUTTON_ID = 0;
    public static final int DURATION_BUTTON_ID = 1;

    public static final int COUNT_START_BUTTON_ID = 100;
    public static final int INCREASE_COUNT_START_BUTTON_ID = COUNT_START_BUTTON_ID;
    public static final int INCREASE_COUNT_FAST_START_BUTTON_ID = INCREASE_COUNT_START_BUTTON_ID + PaybackRequest.SLOTS;
    public static final int DECREASE_COUNT_START_BUTTON_ID = INCREASE_COUNT_FAST_START_BUTTON_ID + PaybackRequest.SLOTS;
    public static final int DECREASE_COUNT_FAST_START_BUTTON_ID = DECREASE_COUNT_START_BUTTON_ID + PaybackRequest.SLOTS;

    protected final class_1799 targetPreview;

    protected class_3915 durationDataSlot = class_3915.method_17403();

    protected PaybackTagMenu(@Nullable class_3917<?> menuType, int containerId, class_1661 inventory, class_1268 hand) {
        super(menuType, containerId, inventory, hand);
        method_17362(durationDataSlot);

        targetPreview = getItemInHand().method_7972();

        @Nullable PaybackRequest existingRequest = getItemInHand().method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS);
        PaybackDuration duration = existingRequest != null
              ? existingRequest.duration()
              : PaybackDuration.MEDIUM;
        durationDataSlot.method_17404(duration.ordinal());
    }

    public PaybackTagMenu(int containerId, class_1661 playerInventory, class_1268 hand) {
        this(Envelope.MenuTypes.PAYBACK_TAG.get(), containerId, playerInventory, hand);
    }

    public static PaybackTagMenu fromNetwork(int id, class_1661 inventory, class_9129 buffer) {
        return new PaybackTagMenu(id, inventory, buffer.method_10818(class_1268.class));
    }

    public class_1799 getTargetPreview() {
        return targetPreview;
    }

    // --

    @Override
    protected void init() {
        playerSlotsX = 13;
        playerSlotsY = 79;
        super.init();
    }

    @Override
    protected class_1263 createContainer() {
        class_1277 container = new class_1277(PaybackRequest.SLOTS);

        if (getItemInHand().method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS) instanceof PaybackRequest request) {
            for (int slot = 0; slot < container.method_5439(); slot++) {
                Optional<StackIngredient> ingredient = request.getRequestedItem(slot);
                if (ingredient.isPresent()) {
                    container.method_5447(slot, ingredient.get().stacks()[0]);
                }
            }
        }

        container.method_5489(c -> {
            if (getPlayer().method_37908().method_8608()) {
                updateTargetPreview();
            }
        });

        return container;
    }

    @Override
    protected void addContainerSlots() {
        int slotsX = 67;
        int slotsY = 23;

        for (int row = 0; row < 2; row++) {
            for (int column = 0; column < 3; column++) {
                int index = column + row * 3;
                int x = slotsX + column * 18;
                int y = slotsY + row * 18;
                method_7621(new GhostSlot(getContainer(), index, x, y, PaybackRequest::isValid) {
                    @Override
                    public void method_48931(class_1799 newStack, class_1799 oldStack) {
                        super.method_48931(newStack, oldStack);
                        if (getPlayer().method_37908().method_8608()
                              && (newStack.method_7909() != oldStack.method_7909() || newStack.method_7947() != oldStack.method_7947())) {
                            getPlayer().method_5783(class_3417.field_15015.comp_349(), 0.15f, 2);
                        }
                    }
                });
            }
        }
    }

    // --

    @Override
    public @NotNull class_1799 method_7601(@NotNull class_1657 player, int index) {
        class_1735 slot = field_7761.get(index);
        class_1799 clickedStack = slot.method_7677();

        if (index < PackageContents.SLOTS) {
            field_7761.get(index).method_53512(class_1799.field_8037);
        } else if (index < field_7761.size()) {
            for (int i = 0; i < PaybackRequest.SLOTS; i++) {
                class_1735 paybackSlot = field_7761.get(i);
                if (paybackSlot.method_7677().method_7960() && paybackSlot.method_7680(clickedStack)) {
                    paybackSlot.method_53512(clickedStack.method_7972());
                    break;
                }
            }
        }

        return class_1799.field_8037;
    }

    @Override
    public boolean method_7604(@NotNull class_1657 player, int buttonId) {
        if (buttonId == CONFIRM_BUTTON_ID) {
            if (getContainer().method_5442()) {
                getItemInHand().method_57381(Envelope.DataComponents.PAYBACK_TAG_CONTENTS);
            } else {
                PaybackRequest request = createRequest();
                getItemInHand().method_57379(Envelope.DataComponents.PAYBACK_TAG_CONTENTS, request);
            }

            player.method_37908().method_43129(player, player, class_3417.field_14883.comp_349(), class_3419.field_15248,
                  1f, player.method_37908().method_8409().method_43057() * 0.3f + 0.85f);
            player.method_6122(getHand(), getItemInHand());
            player.method_6104(getHand());
            return true;
        }

        if (buttonId >= DURATION_BUTTON_ID && buttonId < DURATION_BUTTON_ID + PaybackDuration.values().length) {
            durationDataSlot.method_17404(buttonId - DURATION_BUTTON_ID);
            if (player.method_37908().method_8608()) {
                updateTargetPreview();
            }
            return true;
        }

        if (buttonId >= COUNT_START_BUTTON_ID && buttonId < DECREASE_COUNT_FAST_START_BUTTON_ID + PaybackRequest.SLOTS) {
            int id = buttonId - COUNT_START_BUTTON_ID;
            int slotIndex = id % PaybackRequest.SLOTS;

            boolean decrease = id >= PaybackRequest.SLOTS * 2;
            boolean fast = id % (PaybackRequest.SLOTS * 2) >= PaybackRequest.SLOTS;

            int change = (fast ? 10 : 1);
            if (decrease) {
                change *= -1;
            }

            if (field_7761.get(slotIndex) instanceof GhostSlot slot) {
                slot.setCount(class_3532.method_15340(slot.method_7677().method_7947() + change, 1, slot.method_7677().method_7914()));
            }

            return true;
        }

        return false;
    }

    @Override
    public void method_7593(int slotId, int button, class_1713 clickType, class_1657 player) {
        if (slotId < 0 || slotId >= PaybackRequest.SLOTS) {
            super.method_7593(slotId, button, clickType, player);
            return;
        }

        class_1735 paybackSlot = this.field_7761.get(slotId);

        if (method_34255().method_7960() || !paybackSlot.method_7680(method_34255())) {
            paybackSlot.method_53512(class_1799.field_8037);
            return;
        }

        class_1799 result = method_34255().method_7972();

        if (button == class_3675.field_32002) {
            if (class_1799.method_31577(paybackSlot.method_7677(), result)) {
                result.method_7939(paybackSlot.method_7677().method_7947() + 1);
            } else {
                result.method_7939(1);
            }
        }
        paybackSlot.method_53512(result);
    }

    @Override
    public boolean method_7615(class_1735 slot) {
        // Prevent dragging (QUICK_CRAFT) from working on payback slots. It's difficult to make it work correctly.
        return !(slot instanceof GhostSlot);
    }

    // --

    public PaybackDuration getPaybackDuration() {
        return PaybackDuration.BY_ID.apply(durationDataSlot.method_17407());
    }

    protected PaybackRequest createRequest() {
        class_1263 compactedContainer = ContainerUtils.compact(getContainer(), PaybackRequest.SLOTS);
        List<StackIngredient> ingredients = ContainerUtils.toList(compactedContainer, PaybackRequest.SLOTS).stream()
              .filter(i -> !i.method_7960())
              .map(StackIngredient::createFromStack)
              .toList();
        return PaybackRequest.createOrDefault(ingredients, getPaybackDuration());
    }

    protected void updateTargetPreview() {
        getTargetPreview().method_57379(Envelope.DataComponents.PAYBACK_TAG_CONTENTS,
              !getContainer().method_5442()
                    ? createRequest()
                    : null);
    }
}
