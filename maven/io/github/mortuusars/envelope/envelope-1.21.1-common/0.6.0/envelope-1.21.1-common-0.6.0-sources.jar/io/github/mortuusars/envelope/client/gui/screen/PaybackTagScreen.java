package io.github.mortuusars.envelope.client.gui.screen;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.gui.Sprites;
import io.github.mortuusars.envelope.client.gui.widget.CycleButton;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.world.GameTime;
import io.github.mortuusars.envelope.world.inventory.PaybackTagMenu;
import io.github.mortuusars.envelope.world.inventory.slot.GhostSlot;
import io.github.mortuusars.envelope.world.item.component.PaybackDuration;
import io.github.mortuusars.envelope.world.item.component.PaybackRequest;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7919;
import net.minecraft.class_8666;

public class PaybackTagScreen extends AbstractInHandContainerScreen<PaybackTagMenu> {
    public static final class_2960 TEXTURE = Envelope.resource("textures/gui/payback_tag.png");

    public static final class_8666 CONFIRM_BUTTON_SPRITES = Sprites.threeStates(Envelope.resource("payback/confirm"));

    protected CycleButton<PaybackDuration> durationButton;
    protected class_344 confirmButton;

    public PaybackTagScreen(PaybackTagMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title, TEXTURE);
    }

    @Override
    protected void method_25426() {
        field_2792 = 186;
        field_2779 = 161;
        super.method_25426();
        field_25269 = 12;

        field_25267 = (field_2792 / 2) - (field_22793.method_27525(method_25440()) / 2);

        durationButton = method_37063(createDurationButton());

        confirmButton = new class_344(field_2776 + 133, field_2800 + 31, 19, 19,
              CONFIRM_BUTTON_SPRITES,
              button -> confirm(),
              class_2561.method_43471("gui.envelope.confirm"));
        confirmButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.envelope.confirm")));
        method_37063(confirmButton);
    }

    protected CycleButton<PaybackDuration> createDurationButton() {
        Map<PaybackDuration, class_8666> durationSprites = Map.of(
              PaybackDuration.SHORT, Sprites.threeStates(Envelope.resource("payback/duration_short")),
              PaybackDuration.MEDIUM, Sprites.threeStates(Envelope.resource("payback/duration_medium")),
              PaybackDuration.LONG, Sprites.threeStates(Envelope.resource("payback/duration_long"))
        );

        Map<PaybackDuration, class_7919> durationTooltips = Map.of(
              PaybackDuration.SHORT, class_7919.method_47407(class_2561.method_43471("gui.envelope.payback_tag.duration_short")
                    .method_10852(class_5244.field_33849)
                    .method_10852(GameTime.format(PaybackDuration.SHORT.getTicks(), false).method_27692(class_124.field_1080))),
              PaybackDuration.MEDIUM, class_7919.method_47407(class_2561.method_43471("gui.envelope.payback_tag.duration_medium")
                    .method_10852(class_5244.field_33849)
                    .method_10852(GameTime.format(PaybackDuration.MEDIUM.getTicks(), false).method_27692(class_124.field_1080))),
              PaybackDuration.LONG, class_7919.method_47407(class_2561.method_43471("gui.envelope.payback_tag.duration_long")
                    .method_10852(class_5244.field_33849)
                    .method_10852(GameTime.format(PaybackDuration.LONG.getTicks(), false).method_27692(class_124.field_1080)))
        );

        return new CycleButton<>(field_2776 + 34, field_2800 + 32, 27, 16,
              Arrays.stream(PaybackDuration.values()).toList(), method_17577().getPaybackDuration(), durationSprites)
              .setTooltips(durationTooltips)
              .setLooping(true)
              .setClickSound(class_3417.field_15015.comp_349())
              .onCycle(this::changeDuration);
    }

    protected void changeDuration(PaybackDuration duration) {
        method_17577().method_7604(method_17577().getPlayer(), PaybackTagMenu.DURATION_BUTTON_ID + duration.ordinal());
        Minecrft.gameMode().method_2900(method_17577().field_7763, PaybackTagMenu.DURATION_BUTTON_ID + duration.ordinal());
    }

    protected void confirm() {
        method_17577().method_7604(method_17577().getPlayer(), PaybackTagMenu.CONFIRM_BUTTON_ID);
        Minecrft.gameMode().method_2900(method_17577().field_7763, PaybackTagMenu.CONFIRM_BUTTON_ID);
        method_25419();
    }

    @Override
    protected void method_37432() {
        PaybackDuration duration = method_17577().getPaybackDuration();
        if (durationButton.getCurrentValue() != duration) {
            durationButton.setCurrentValue(duration);
        }
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        renderTargetPreview(guiGraphics, mouseX, mouseY);
    }

    protected void renderTargetPreview(@NotNull class_332 guiGraphics, int mouseX, int mouseY) {
        class_1799 target = method_17577().getTargetPreview();
        if (target.method_7960()) {
            return;
        }

        float scale = 2f;
        int size = (int) (16 * scale);

        int x = field_2776 - size - 4;
        int y = field_2800 + 38 - size / 2;

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(x + (float) size / 2, y + (float) size / 2, 0);
        guiGraphics.method_51448().method_22905(scale, scale, scale);
        guiGraphics.method_51448().method_46416(-8, -8, 0);
        guiGraphics.method_51427(target, 0, 0);
        guiGraphics.method_51448().method_22909();

        if (method_2378(x - field_2776, y - field_2800, size, size, mouseX, mouseY)) {
            guiGraphics.method_51446(field_22793, target, mouseX, mouseY);
        }
    }

    // -- Input


    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        field_2791 = class_1799.field_8037; // Prevents fast shift-clicking moving more items that needed
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (super.method_25401(mouseX, mouseY, scrollX, scrollY)) {
            return true;
        }

        if (field_2787 != null && field_2787.field_7874 < PaybackRequest.SLOTS) {
            boolean decreasing = scrollY < 0;
            boolean fast = class_437.method_25442();
            changeRequestedItemCount(decreasing, fast);
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (super.method_25404(keyCode, scanCode, modifiers)) {
            return true;
        }

        if (field_2787 != null && field_2787.field_7874 < PaybackRequest.SLOTS) {
            if (keyCode == class_3675.field_31933 || keyCode == class_3675.field_31937) {
                changeRequestedItemCount(false, class_437.method_25442());
                return true;
            }

            if (keyCode == 333 /*KEY_SUBTRACT*/ || keyCode == class_3675.field_31941) {
                changeRequestedItemCount(true, class_437.method_25442());
                return true;
            }
        }

        return false;
    }

    @Override
    protected void method_2380(class_332 guiGraphics, int x, int y) {
        if (field_2787 instanceof GhostSlot slot && slot.method_7681()) {
            // Prevents tooltip overlapping the slot, to not obstruct the item count
            x = Math.max(x, field_2776 + slot.field_7873 + 11);
        }
        super.method_2380(guiGraphics, x, y);
    }

    @Override
    protected @NotNull List<class_2561> method_51454(class_1799 stack) {
        if (field_2787 instanceof GhostSlot slot && slot.method_7677() == stack) {
            List<class_2561> components = super.method_51454(stack);
            components.add(class_2561.method_43471("gui.envelope.payback_tag.tooltip.scroll"));
            return components;
        }
        return super.method_51454(stack);
    }

    protected void changeRequestedItemCount(boolean decreasing, boolean fast) {
        if (!(field_2787 instanceof GhostSlot)) {
            return;
        }

        int startId = decreasing ? PaybackTagMenu.DECREASE_COUNT_START_BUTTON_ID : PaybackTagMenu.INCREASE_COUNT_START_BUTTON_ID;
        int id = startId + field_2787.field_7874 + (fast ? PaybackRequest.SLOTS : 0);
        method_17577().method_7604(method_17577().getPlayer(), id);
        Minecrft.gameMode().method_2900(method_17577().field_7763, id);
    }
}
