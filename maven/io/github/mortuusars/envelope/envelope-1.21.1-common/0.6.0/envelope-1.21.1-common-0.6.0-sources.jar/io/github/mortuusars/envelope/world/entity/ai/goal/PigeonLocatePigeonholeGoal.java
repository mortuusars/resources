package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.block.PigeonholeBlockEntity;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.mail.MailService;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_4153;
import net.minecraft.class_4156;

public class PigeonLocatePigeonholeGoal extends class_1352 {
    protected final Pigeon pigeon;

    public PigeonLocatePigeonholeGoal(Pigeon pigeon) {
        this.pigeon = pigeon;
    }

    @Override
    public boolean method_6264() {
        return MailService.operatesIn(pigeon.method_37908())
              && pigeon.getPigeonholeHandler().getLocateCooldown() == 0
              && pigeon.getPigeonholeHandler().getTargetPos() == null
              && pigeon.getPigeonholeHandler().wantsToEnterPigeonhole(pigeon);
    }

    @Override
    public boolean method_6266() {
        return false;
    }

    @Override
    public void method_6269() {
        pigeon.getPigeonholeHandler().resetLocateCooldown();
        List<class_2338> pigeonholes = findNearbyPigeonholesWithSpace();
        if (!pigeonholes.isEmpty()) {
            for (class_2338 pos : pigeonholes) {
                if (!pigeon.getPigeonholeHandler().isTargetBlacklisted(pos)) {
                    pigeon.getPigeonholeHandler().setTargetPos(pos);
                    return;
                }
            }

            pigeon.getPigeonholeHandler().clearBlacklist();
            pigeon.getPigeonholeHandler().setTargetPos(pigeonholes.getFirst());
        }
    }

    private List<class_2338> findNearbyPigeonholesWithSpace() {
        class_2338 pos = pigeon.method_24515();
        class_4153 poiManager = ((class_3218) pigeon.method_37908()).method_19494();
        return poiManager.method_19125(holder ->
                    holder.method_40225(Envelope.PoiTypes.PIGEONHOLE), pos, 20, class_4153.class_4155.field_18489)
              .map(class_4156::method_19141)
              .filter(p -> pigeon.method_37908().method_8321(p) instanceof PigeonholeBlockEntity pigeonhole
                    && pigeonhole.hasSpaceForAnotherOccupant())
              .sorted(Comparator.comparingDouble(p -> p.method_10262(pos)))
              .collect(Collectors.toList());
    }
}
