package io.github.mortuusars.envelope.world.block;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.PackageItem;
import net.minecraft.class_1264;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PackageBlockEntity extends class_2586 {
    protected class_1799 item = class_1799.field_8037;
    protected boolean unpackWhenBroken = true;

    protected PackageBlockEntity(class_2591<?> type, class_2338 pos, class_2680 blockState) {
        super(type, pos, blockState);
    }

    public PackageBlockEntity(class_2338 pos, class_2680 blockState) {
        super(Envelope.BlockEntityTypes.PACKAGE.get(), pos, blockState);
    }

    // --

    public class_1799 getPackage() {
        return !item.method_7960() ? item : new class_1799(method_11010().method_26204().method_8389());
    }

    public void setPackage(class_1799 item) {
        this.item = item;
        method_5431();
    }

    public boolean unpackWhenBroken() {
        return unpackWhenBroken;
    }

    public void setUnpackWhenBroken(boolean unpackWhenBroken) {
        this.unpackWhenBroken = unpackWhenBroken;
        method_5431();
    }

    public void dropContents(class_1937 level, class_2338 pos) {
        class_1799 stack = getPackage();
        if (unpackWhenBroken() && stack.method_7909() instanceof PackageItem packageItem) {
            packageItem.destroy(stack, level, class_243.method_24953(pos), null);
        } else {
            class_1264.method_5449(level, pos.method_10263(), pos.method_10264(), pos.method_10260(), stack);
        }
        method_5431();
    }

    // -- Sync

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public @NotNull class_2487 method_16887(class_7225.class_7874 registries) {
        return method_58692(registries);
    }

    // --

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        if (!item.method_7960()) {
            tag.method_10566("Package", item.method_57376(registries, new class_2487()));
        }
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        if (tag.method_10573("Package", class_2487.field_33260)) {
            item = class_1799.method_57360(registries, tag.method_10562("Package")).orElse(class_1799.field_8037);
        }
    }
}
