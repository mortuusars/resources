package io.github.mortuusars.envelope.world.block.mailbox;

import com.mojang.serialization.MapCodec;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.Id;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.clientbound.OpenMailboxAddressTagScreenS2CP;
import io.github.mortuusars.envelope.world.mail.delivery.CourierOrigin;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.item.AddressTagItem;
import io.github.mortuusars.envelope.world.mail.address.BlockAddressValidation;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import io.github.mortuusars.envelope.world.mail.address.type.PlayerAddress;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3730;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_9062;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class MailboxBlock extends class_2237 {
    public static final MapCodec<MailboxBlock> field_46280 = method_54094(MailboxBlock::new);

    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2746 OPEN = class_2741.field_12537;

    public static final class_265 SHAPE = class_2248.method_9541(1, 0, 1, 15, 14, 15);

    public MailboxBlock(class_2251 properties) {
        super(properties);
        method_9590(field_10647.method_11664()
              .method_11657(FACING, class_2350.field_11043)
              .method_11657(OPEN, false));
    }

    @Override
    protected @NotNull MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected @NotNull class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected @NotNull class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, OPEN);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(FACING, context.method_8042().method_10153());
    }

    @Override
    public @NotNull class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public @NotNull class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    protected int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        if (level.method_8321(pos) instanceof MailboxBlockEntity blockEntity
              && !blockEntity.getAllMail().isEmpty()) {
            return 15;
        }
        return 0;
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        super.method_9567(level, pos, state, placer, stack);
        if (placer != null && level.method_8321(pos) instanceof MailboxBlockEntity blockEntity) {
            blockEntity.setOwner(placer.method_5667());
        }
    }

    @Override
    protected void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
        if (!state.method_26204().equals(newState.method_26204()) && level instanceof class_3218 serverLevel) {
            // Using MailboxBlockEntity#onBlockRemoved does not cover every case,
            // as block entity might not exist while the block is still placed.
            // This happens with CarryOn relocation for example, where block entity is removed first.
            // So we remove any registered mailbox at this position:
            MailService.of(serverLevel).getMailboxes().remove(pos);

            if (level.method_8321(pos) instanceof MailboxBlockEntity blockEntity) {
                blockEntity.onBlockRemoved(level, pos, state, newState);
            }
        }

        super.method_9536(state, level, pos, newState, movedByPiston);
    }

    @Override
    protected @NotNull class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        if (!MailService.operatesIn(level)) {
            player.method_7353(class_2561.method_43470("Mail Service does not operate in this dimension.")
                  .method_27692(class_124.field_1061), true);
            return class_9062.field_47728;
        }

        if (stack.method_7909() instanceof AddressTagItem) {
            if (player instanceof class_3222 serverPlayer && level.method_8321(pos) instanceof MailboxBlockEntity blockEntity) {
                AllAddresses knownAddresses = serverPlayer.method_51469().getEnvelopeMailService().getKnownAddresses();
                Packets.sendToClient(new OpenMailboxAddressTagScreenS2CP(hand, knownAddresses, pos, blockEntity.getAddress()), serverPlayer);
            }
            return class_9062.field_47728;
        }

        if (player.method_7337()
              && stack.method_31573(Envelope.Tags.Items.MAILABLE)
              && stack.method_57824(Envelope.DataComponents.MAIL_RECIPIENT) instanceof BlockAddress address
              && level.method_8321(pos) instanceof MailboxBlockEntity blockEntity
              && blockEntity.getAddress().equals(address)) {
            if (level instanceof class_3218) {
                class_1799 mail = Mail.of(stack.method_46651(1))
                      .writeToLog(DeliveryRecord.sentFrom(new PlayerAddress(player)))
                      .writeToLog(DeliveryRecord.arrivedTo(address))
                      .sender(new PlayerAddress(player))
                      .id(Id.create(level))
                      .get();
                if (blockEntity.addMail(mail)) {
                    player.method_5998(hand).method_7934(1);
                    blockEntity.onMailInserted(mail);
                }
            }
            return class_9062.field_47728;
        }

        if (stack.method_31574(Envelope.Items.PIGEON_SPAWN_EGG.get())) {
            if (level instanceof class_3218 serverLevel) {
                if (level.method_8321(pos) instanceof MailboxBlockEntity blockEntity
                      && blockEntity.isAvailableForPickup()
                      && Envelope.EntityTypes.PIGEON.get().method_47821(serverLevel,
                        pos.method_10093(state.method_11654(FACING)), class_3730.field_16465) instanceof Pigeon pigeon
                      && blockEntity.tryStartDelivery(pigeon)) {
                    if (player.method_7337()) {
                        pigeon.setOrigin(CourierOrigin.service());
                    } else {
                        pigeon.setOrigin(CourierOrigin.regular(pos));
                        stack.method_7934(1);
                    }
                } else {
                    serverLevel.method_8396(null, pos, class_3417.field_14624.comp_349(), class_3419.field_15245, 1, 1);
                }
            }

            return class_9062.field_47728;
        }

        return super.method_55765(stack, state, level, pos, player, hand, hitResult);
    }

    @Override
    protected @NotNull class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos,
                                                        class_1657 player, class_3965 hitResult) {
        if (!MailService.operatesIn(level)) {
            player.method_7353(class_2561.method_43470("Mail Service does not operate in this dimension.")
                  .method_27692(class_124.field_1061), true);
            return class_1269.field_51370;
        }

        if (level.method_8321(pos) instanceof MailboxBlockEntity blockEntity) {
            blockEntity.openMenu(player);
        }

        return class_1269.field_51370;
    }

    // --

    public void changeAddress(class_1657 player, class_2338 pos, class_1268 hand, String addressId) {
        if (!(player.method_37908() instanceof class_3218 level)) {
            return;
        }

        class_1799 stack = player.method_5998(hand);

        if (!(stack.method_7909() instanceof AddressTagItem)) {
            Envelope.LOGGER.error("Failed change address: item in hand is not AddressTagItem, but {}", stack);
            return;
        }

        if (!(level.method_8321(pos) instanceof MailboxBlockEntity blockEntity)) {
            Envelope.LOGGER.error("Failed change address: block entity at pos is not a MailboxBlockEntity.");
            return;
        }

        BlockAddressValidation.forMailbox(MailService.of(level).getKnownAddresses(), player)
              .test(addressId)
              .ifPresentOrElse(
                    id -> {
                        applyAddress(player, blockEntity, new BlockAddress(id), stack);
                        player.method_23667(hand, true);

                        if (!player.method_7337()) {
                            stack.method_7934(1);
                        }
                    },
                    error -> {
                        player.method_7353(error.getTranslation(), true);
                        player.method_5783(class_3417.field_14624.comp_349(), 0.75f, 1f);
                    });
    }

    public static void placeBlockWithAddress(class_1657 player, class_1268 hand, class_1750 context, String addressId) {
        if (!(player.method_37908() instanceof class_3218 level)) {
            return;
        }

        class_2338 pos = context.method_8037();
        class_1799 stack = player.method_5998(hand);

        if (!(stack.method_7909() instanceof class_1747 blockItem)) {
            player.method_5783(class_3417.field_14624.comp_349(), 0.75f, 1f);
            Envelope.LOGGER.error("Failed to place mailbox: item in hand is not a BlockItem, but {}", stack);
            return;
        }

        BlockAddressValidation.forMailbox(MailService.of(level).getKnownAddresses(), player)
              .test(addressId)
              .ifPresentOrElse(
                    id -> {
                        blockItem.method_7712(context);

                        if (!(level.method_8321(pos) instanceof MailboxBlockEntity blockEntity)) {
                            player.method_5783(class_3417.field_14624.comp_349(), 0.75f, 1f);
                            Envelope.LOGGER.error("Failed to place mailbox: be at pos [{}] is not MailboxBlockEntity", pos.method_23854());
                            return;
                        }

                        blockEntity.method_11010().method_26204().method_9567(level, pos, blockEntity.method_11010(), player, stack);
                        applyAddress(player, blockEntity, new BlockAddress(id), stack);
                        player.method_23667(hand, true);
                    },
                    error -> {
                        player.method_7353(error.getTranslation(), true);
                        player.method_5783(class_3417.field_14624.comp_349(), 0.75f, 1f);
                    });
    }

    private static void applyAddress(class_1657 player, MailboxBlockEntity blockEntity, BlockAddress address, class_1799 stack) {
        blockEntity.setAddress(address);

        if (Config.Server.MAILBOX_ADDRESS_EXPERIENCE_LEVELS_COST.get() > 0) {
            player.method_37908().method_45447(player, blockEntity.method_11016(), class_3417.field_15119, class_3419.field_15245);
        }

        if (!player.method_7337()) {
            player.method_7316(-Config.Server.MAILBOX_ADDRESS_EXPERIENCE_LEVELS_COST.get());
        }
    }

    // --

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new MailboxBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> blockEntityType) {
        return level.field_9236
              ? null
              : method_31618(blockEntityType, Envelope.BlockEntityTypes.MAILBOX.get(),
              (lvl, blockPos, blockState, blockEntity) -> blockEntity.serverTick(((class_3218) lvl), blockPos, state));
    }
}