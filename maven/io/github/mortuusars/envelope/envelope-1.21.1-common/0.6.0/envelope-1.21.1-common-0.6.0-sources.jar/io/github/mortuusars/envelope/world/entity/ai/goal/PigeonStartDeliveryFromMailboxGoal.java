package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlockEntity;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.mail.MailService;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import org.jetbrains.annotations.Nullable;

public class PigeonStartDeliveryFromMailboxGoal extends class_1352 {
    private final Pigeon pigeon;

    public PigeonStartDeliveryFromMailboxGoal(Pigeon pigeon) {
        this.pigeon = pigeon;
    }

    @Override
    public boolean method_6264() {
        if (!MailService.operatesIn(pigeon.method_37908()) || pigeon.isDelivering() || !pigeon.canStartDelivery()) {
            return false;
        }

        @Nullable class_2338 pos = pigeon.getMailboxHandler().getTargetPos();

        return pos != null
              && pos.method_19769(pigeon.method_19538(), 2.0)
              && pigeon.method_37908().method_8321(pos) instanceof MailboxBlockEntity blockEntity
              && blockEntity.isAvailableForPickup();
    }

    @Override
    public boolean method_6266() {
        return false;
    }

    @Override
    public void method_6269() {
        pigeon.getMailboxHandler().getMailboxAtCurrentPos(pigeon.method_37908())
              .ifPresent(blockEntity -> {
                  blockEntity.tryStartDelivery(pigeon);
                  pigeon.getMailboxHandler().setTargetPos(null);
              });
    }
}
