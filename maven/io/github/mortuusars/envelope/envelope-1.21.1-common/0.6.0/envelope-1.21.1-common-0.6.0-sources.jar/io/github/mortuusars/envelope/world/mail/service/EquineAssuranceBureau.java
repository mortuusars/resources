package io.github.mortuusars.envelope.world.mail.service;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.Ticks;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.crafting.mail.MailRecipe;
import io.github.mortuusars.envelope.world.item.crafting.mail.Mailing;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.envelope.world.mail.address.type.BlockAddress;
import io.github.mortuusars.envelope.world.mail.address.type.ServiceAddress;
import io.github.mortuusars.envelope.world.mail.address.type.PlayerAddress;
import io.github.mortuusars.envelope.world.mail.delivery.Delivery;
import net.minecraft.class_124;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_8786;
import net.minecraft.class_9334;
import net.minecraft.network.chat.*;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

public class EquineAssuranceBureau {
    private static final class_2960 RECIPE_ID = Envelope.resource("mailing/equine_insurance_bureau/golden_horse_armor");

    public static void tick(MailService service, ServiceAddress address) {
        if (!Config.Server.SERVICE_EQUINE_BUREAU_NOTICE_SENDING_ENABLED.get()) {
            return;
        }

        long currentTime = service.getGameTime();
        class_2487 data = service.getPersistentData().get(ServiceAddresses.EQUINE_ASSURANCE_BUREAU.method_29177());
        long lastSendTime = data.method_10537("last_send_time");

        long days = service.getLevel().method_8532() / 24000L;
        long interval = Ticks.fromMinutes(Config.Server.SERVICE_EQUINE_BUREAU_NOTICE_SENDING_BASE_INTERVAL_MINUTES.get())
              + days * Ticks.fromMinutes(Config.Server.SERVICE_EQUINE_BUREAU_NOTICE_SENDING_ADDITIONAL_INTERVAL_PER_DAY_MINUTES.get());

        if (currentTime - lastSendTime < interval) {
            return;
        }

        double chance = Config.Server.SERVICE_EQUINE_BUREAU_NOTICE_SENDING_CHANCE_PER_TICK.get();
        if (service.getLevel().method_8409().method_43058() >= chance) {
            return;
        }

        if (sendNotice(service, address) > 0) {
            data.method_10544("last_send_time", service.getGameTime());
            service.getPersistentData().set(ServiceAddresses.EQUINE_ASSURANCE_BUREAU.method_29177(), data);
        }
    }

    public static int sendNotice(MailService service, ServiceAddress address) {
        Map<PlayerAddress, BlockAddress> defaultAddresses = service.getKnownPlayers().getDefaultAddresses();
        if (defaultAddresses.isEmpty()) {
            return 0;
        }

        Optional<class_8786<MailRecipe>> recipe = Mailing.getAllRecipesOf(address, service.getLevel())
              .filter(recipeHolder -> recipeHolder.comp_1932().equals(RECIPE_ID))
              .findFirst();
        if (recipe.isEmpty()) {
            return 0;
        }

        class_1799 letter = createLetter(recipe.get());

        int count = 0;

        for (PlayerAddress playerAddress : defaultAddresses.keySet()) {
            service.getDeliveryManager().startService(Delivery.draft()
                  .deliver(letter.method_7972())
                  .from(address)
                  .to(playerAddress));
            count++;
        }

        return count;
    }

    public static class_1799 createLetter(class_8786<MailRecipe> recipe) {
        class_1277 inputContainer = new class_1277(PackageContents.SLOTS);

        recipe.comp_1933().method_8117().stream()
              .map(i -> Arrays.stream(i.method_8105()).findFirst())
              .filter(Optional::isPresent)
              .forEach(item -> inputContainer.method_5491(item.get()));

        class_5250 requiredItems = class_2561.method_43473();
        boolean multiple = false;

        for (class_1799 stack : inputContainer.method_24514()) {
            class_2583 style = createItemStyle(stack);

            if (multiple) {
                requiredItems.method_27693(", ");
            }

            if (stack.method_7947() > 1) {
                requiredItems.method_10852(class_2561.method_43470(stack.method_7947() + "x ").method_27696(style));
            }

            requiredItems.method_10852(stack.method_7964().method_27661().method_27696(style));

            multiple = true;
        }

        class_2561 body = class_2561.method_43469("letter.envelope.equine_assurance_notice.body", requiredItems);

        return Mail.createLetter(body)
              .set(class_9334.field_50239, class_2561.method_43471("letter.envelope.equine_assurance_notice.name"))
              .get();
    }

    private static class_2583 createItemStyle(class_1799 stack) {
        return class_2583.field_24360
              .method_10977(class_124.field_1079)
              .method_30938(true)
              .method_10949(new class_2568(class_2568.class_5247.field_24343, new class_2568.class_5249(stack)));
    }
}
