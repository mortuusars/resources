package io.github.mortuusars.envelope.world.inventory;

import com.google.common.base.Preconditions;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_5699;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9329;

public record RequestedItem(Either<class_6862<class_1792>, class_6880<class_1792>> item, int count, class_9329 components) {
    public static final Codec<RequestedItem> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.xor(class_6862.method_40093(class_7924.field_41197), class_1799.field_47312)
                      .fieldOf("item")
                      .forGetter(RequestedItem::item),
                class_5699.method_48766(1, 99)
                      .fieldOf("count").orElse(1)
                      .forGetter(RequestedItem::count),
                class_9329.field_49595
                      .optionalFieldOf("components", class_9329.field_49597)
                      .forGetter(RequestedItem::components))
          .apply(i, RequestedItem::new));

    public static final class_9139<class_9129, RequestedItem> STREAM_CODEC = class_9139.method_56436(
          class_9135.method_57995(
                class_2960.field_48267.method_56432(id -> class_6862.method_40092(class_7924.field_41197, id), class_6862::comp_327),
                class_9135.method_56383(class_7924.field_41197)), RequestedItem::item,
          class_9135.field_49675, RequestedItem::count,
          class_9329.field_49596, RequestedItem::components,
          RequestedItem::new
    );

    public static final RequestedItem DEFAULT = new RequestedItem(class_1802.field_8687);

    public RequestedItem {
        Preconditions.checkArgument(count >= 1 && count <= 99, "Count must be in range 1-99.");
    }

    public RequestedItem(class_6862<class_1792> tag, int count, class_9329 components) {
        this(Either.left(tag), count, components);
    }

    public RequestedItem(class_6862<class_1792> tag, int count) {
        this(tag, count, class_9329.field_49597);
    }

    public RequestedItem(class_6862<class_1792> tag) {
        this(tag, 1);
    }

    // Item#builtInRegistryHolder is most likely deprecated because mojang wants us to get it through ItemStack#getItemHolder.
    // Same deprecations are present in other places, like Block for example.
    @SuppressWarnings("deprecation")
    public RequestedItem(class_1935 item, int count, class_9329 components) {
        this(Either.right(item.method_8389().method_40131()), count, components);
    }

    public RequestedItem(class_1935 item, int count) {
        this(item, count, class_9329.field_49597);
    }

    public RequestedItem(class_1935 item) {
        this(item, 1);
    }

    // --

    public List<class_1792> items() {
        return this.item().map(
              tag -> class_7923.field_41178.method_40266(tag)
                    .map(named -> named.method_40239()
                          .map(class_6880::comp_349)
                          .toList())
                    .orElse(List.of(class_1802.field_8077)),
              itemHolder -> List.of(itemHolder.comp_349()));
    }

    // --

    public boolean matches(class_1799 stack) {
        return typeMatches(stack)
              && countEquals(stack)
              && componentsMatch(stack);
    }

    public boolean typeMatches(class_1799 stack) {
        return item.map(stack::method_31573, stack::method_41406);
    }

    public boolean countMatches(class_1799 stack) {
        return stack.method_7947() >= Math.min(count(), stack.method_7914());
    }

    public boolean countEquals(class_1799 stack) {
        return stack.method_7947() == Math.min(count(), stack.method_7914());
    }

    public boolean componentsMatch(class_1799 stack) {
        return components().method_57864(stack);
    }
}