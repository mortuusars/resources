package io.github.mortuusars.envelope.world.item.component;

import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import io.github.mortuusars.envelope.Envelope;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_5632;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class PackageContents implements class_5632 {
    public static final int SLOTS = 6;

    public static final Codec<PackageContents> CODEC = class_1799.field_49266.listOf(0, SLOTS)
            .xmap(PackageContents::new, PackageContents::getItemsForSerialization);
    public static final class_9139<class_9129, PackageContents> STREAM_CODEC = class_1799.field_49268
            .method_56433(class_9135.method_58000(SLOTS))
            .method_56432(PackageContents::new, PackageContents::getItemsForReading);

    public static final PackageContents EMPTY = new PackageContents(Collections.emptyList());

    private final List<class_1799> items;

    public PackageContents(List<class_1799> items) {
        this.items = class_2371.method_10213(SLOTS, class_1799.field_8037);
        for (int i = 0; i < Math.min(items.size(), SLOTS); i++) {
            this.items.set(i, items.get(i));
        }
    }

    public static PackageContents createFrom(class_1263 container) {
        List<class_1799> items = new ArrayList<>();
        for (int i = 0; i < Math.min(container.method_5439(), SLOTS); i++) {
            items.add(container.method_5438(i));
        }
        return new PackageContents(items);
    }

    public static PackageContents from(class_1799 stack) {
        return stack.method_57825(Envelope.DataComponents.PACKAGE_CONTENTS, EMPTY);
    }

    // --

    public int size() {
        return items.size();
    }

    public List<class_1799> getItemsForReading() {
        return items;
    }

    /**
     * Removes trailing empty items.
     */
    private List<class_1799> getItemsForSerialization() {
        List<class_1799> list = new ArrayList<>(items);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (!list.get(i).method_7960()) {
                break;
            }
            list.remove(i);
        }
        return list;
    }

    public class_1799 getItemForReading(int index) {
        return index < size() ? items.get(index) : class_1799.field_8037;
    }

    public List<class_1799> copyItems() {
        return Lists.transform(this.items, class_1799::method_7972);
    }

    // --

    @SuppressWarnings("deprecation")
    public boolean equals(Object another) {
        return this == another ||
              (another instanceof PackageContents packageContents
                    && class_1799.method_57362(this.items, packageContents.items));
    }

    @SuppressWarnings("deprecation")
    public int hashCode() {
        return class_1799.method_57361(this.items);
    }

    public String toString() {
        return "PackageContents" + this.items;
    }

    public boolean isEmpty() {
        return this.equals(EMPTY) || getItemsForReading().isEmpty() || getItemsForReading().stream().allMatch(class_1799::method_7960);
    }
}
