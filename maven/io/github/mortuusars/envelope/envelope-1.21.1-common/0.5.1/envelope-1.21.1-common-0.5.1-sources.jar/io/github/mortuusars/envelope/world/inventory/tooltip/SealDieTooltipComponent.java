package io.github.mortuusars.envelope.world.inventory.tooltip;

import io.github.mortuusars.envelope.world.item.component.seal.SealImpression;
import java.util.Optional;
import net.minecraft.class_5632;
import net.minecraft.class_6880;

public record SealDieTooltipComponent(Optional<class_6880<SealImpression>> impression) implements class_5632 {
}
