package io.github.mortuusars.envelope.world.entity.ai;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.util.bugger.Bugger;
import io.github.mortuusars.envelope.world.block.PigeonholeBlockEntity;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_5819;

public class PigeonholeHandler {
    public static final int MAX_BLACKLISTED_TARGETS = 3;
    public static final int DEFAULT_LOCATE_COOLDOWN = 200;

    public static final Codec<PigeonholeHandler> CODEC = RecordCodecBuilder.create(i -> i.group(
          class_2338.field_25064.optionalFieldOf("current_pos").forGetter(o -> Optional.ofNullable(o.getTargetPos())),
          class_2338.field_25064.optionalFieldOf("last_release_pos").forGetter(o -> Optional.ofNullable(o.getLastReleasePos())),
          Codec.INT.optionalFieldOf("locate_cooldown", 0).forGetter(PigeonholeHandler::getLocateCooldown),
          Codec.INT.optionalFieldOf("want_cooldown", 0).forGetter(PigeonholeHandler::getWantCooldown),
          Codec.INT.optionalFieldOf("enter_cooldown", 0).forGetter(PigeonholeHandler::getEnterCooldown)
    ).apply(i, PigeonholeHandler::new));

    protected final List<class_2338> blacklistedPositions = new ArrayList<>();

    protected @Nullable class_2338 targetPos;
    protected @Nullable class_2338 lastReleasePos;
    protected int locateCooldown;
    protected int wantCooldown;
    protected int enterCooldown;

    public PigeonholeHandler(Optional<class_2338> targetPos, Optional<class_2338> lastReleasePos,
                             int locateCooldown, int wantCooldown, int enterCooldown) {
        this.targetPos = targetPos.orElse(null);
        this.lastReleasePos = lastReleasePos.orElse(null);
        this.locateCooldown = locateCooldown;
        this.wantCooldown = wantCooldown;
        this.enterCooldown = enterCooldown;
    }

    public PigeonholeHandler() {
        this(Optional.empty(), Optional.empty(), 0, 0, 0);
    }

    public @Nullable class_2338 getTargetPos() {
        return targetPos;
    }

    public void setTargetPos(@Nullable class_2338 targetPos) {
        this.targetPos = targetPos;
    }

    public @Nullable class_2338 getLastReleasePos() {
        return lastReleasePos;
    }

    public PigeonholeHandler setLastReleasePos(@Nullable class_2338 lastReleasePos) {
        this.lastReleasePos = lastReleasePos;
        return this;
    }

    public int getEnterCooldown() {
        return enterCooldown;
    }

    public void setEnterCooldown(int cooldown) {
        this.enterCooldown = cooldown;
    }

    public int getWantCooldown() {
        return wantCooldown;
    }

    public void setWantCooldown(int cooldown) {
        this.wantCooldown = cooldown;
    }

    public void setDefaultWantCooldown() {
        setWantCooldown(Config.Server.PIGEON_MIN_TICKS_OUTSIDE_PIGEONHOLE.get());
    }

    public void setRandomWantCooldownUpToDefault(class_5819 random) {
        setWantCooldown(random.method_43048(Config.Server.PIGEON_MIN_TICKS_OUTSIDE_PIGEONHOLE.get()));
    }

    public int getLocateCooldown() {
        return locateCooldown;
    }

    public void setLocateCooldown(int cooldown) {
        this.locateCooldown = cooldown;
    }

    public void resetLocateCooldown() {
        setLocateCooldown(DEFAULT_LOCATE_COOLDOWN);
    }

    // --

    public void tick(Pigeon pigeon, class_1937 level) {
        if (wantCooldown > 0) {
            wantCooldown--;
        }
        if (locateCooldown > 0) {
            locateCooldown--;
        }

        if (level instanceof class_3218 && pigeon.field_6012 % 20 == 0) {
            if (!isPigeonholeValid(level, pigeon.method_24515())) {
                setTargetPos(null);
            }
            Bugger.PIGEON_PIGEONHOLE_HANDLER.send(pigeon.method_5628(), this);
        }
    }

    // --

    public Optional<PigeonholeBlockEntity> getPigeonholeAtCurrentPos(class_1937 level) {
        @Nullable class_2338 pos = getTargetPos();
        if (pos != null && level.method_8477(pos) && level.method_8321(pos) instanceof PigeonholeBlockEntity be) {
            return Optional.of(be);
        }
        return Optional.empty();
    }

    public boolean wantsToEnterPigeonhole(Pigeon pigeon) {
        if (getEnterCooldown() > 0) return false;
        class_1937 level = pigeon.method_37908();
        boolean wouldPreferInside = level.method_23886() || level.method_8419() || level.method_8546();
        boolean tiredOfOutside = pigeon.isTired() || getWantCooldown() <= 0;
        return (wouldPreferInside || tiredOfOutside);
    }

    public boolean isPigeonholeValid(class_1937 level, class_2338 entityPos) {
        @Nullable class_2338 currentPos = getTargetPos();
        if (currentPos == null) return false;
        if (!entityPos.method_19771(currentPos, 32)) return false;
        return level.method_8321(currentPos) instanceof PigeonholeBlockEntity;
    }

    public boolean isTargetBlacklisted(class_2338 pos) {
        return this.blacklistedPositions.contains(pos);
    }

    private void blacklistTarget(class_2338 pos) {
        this.blacklistedPositions.add(pos);

        while (this.blacklistedPositions.size() > MAX_BLACKLISTED_TARGETS) {
            this.blacklistedPositions.removeFirst();
        }
    }

    public void clearBlacklist() {
        this.blacklistedPositions.clear();
    }

    public void dropAndBlacklistPigeonhole() {
        if (getTargetPos() != null) {
            blacklistTarget(getTargetPos());
        }

        dropPigeonhole();
    }

    public void dropPigeonhole() {
        setTargetPos(null);
        resetLocateCooldown();
    }

    @Override
    public String toString() {
        return "PigeonholeHandler{" +
              "currentPos=" + targetPos +
              ", lastReleasePos=" + lastReleasePos +
              ", locateCooldown=" + locateCooldown +
              ", wantCooldown=" + wantCooldown +
              ", enterCooldown=" + enterCooldown +
              '}';
    }
}
