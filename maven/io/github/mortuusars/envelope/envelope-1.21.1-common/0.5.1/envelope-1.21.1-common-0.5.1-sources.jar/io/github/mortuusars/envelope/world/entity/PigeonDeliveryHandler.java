package io.github.mortuusars.envelope.world.entity;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.util.Ticks;
import io.github.mortuusars.envelope.world.delivery.CourierOrigin;
import io.github.mortuusars.envelope.world.delivery.Delivery;
import io.github.mortuusars.envelope.world.delivery.DeliveryHandler;
import io.github.mortuusars.envelope.world.delivery.phase.DeliveryPhase;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;

public class PigeonDeliveryHandler implements DeliveryHandler {
    private final Pigeon pigeon;

    public PigeonDeliveryHandler(Pigeon pigeon) {
        this.pigeon = pigeon;
    }

    public Pigeon pigeon() {
        return pigeon;
    }

    @Override
    public CourierOrigin getOrigin() {
        return pigeon.getOrigin();
    }

    @Override
    public int getPhaseDuration(class_3218 level, Delivery delivery, DeliveryPhase phase) {
        return switch (phase) {
            // Longer approach/depart phases to allow for pathfinding to finish
            case DEPARTING_SENDER, APPROACHING_RECIPIENT, DEPARTING_RECIPIENT, APPROACHING_SENDER -> 30 * Ticks.SECOND;
            default -> DeliveryHandler.super.getPhaseDuration(level, delivery, phase);
        };
    }

    @Override
    public void phaseStarted(class_3218 level, Delivery delivery) {
        DeliveryHandler.super.phaseStarted(level, delivery);
        if (delivery.getPhase().isTraveling()) {
            pigeon().transitionToBackground(level);
        }
        pigeon().onDeliveryChanged();
    }

    @Override
    public boolean handlePhaseTransition(class_3218 level, Delivery delivery) {
        if (delivery.getPhase() == DeliveryPhase.DEPARTING_SENDER && !hasReachedSegmentEndPos(delivery)) {
            Mail.writeToLog(delivery.getMail(), DeliveryRecord.returned(DeliveryRecord.Message.UNABLE_TO_REACH));
            delivery.setPhaseAndResetProgress(DeliveryPhase.APPROACHING_SENDER);
            return true;
        }

        if (delivery.getPhase() == DeliveryPhase.APPROACHING_RECIPIENT && !hasReachedSegmentEndPos(delivery)) {
            Mail.writeToLog(delivery.getMail(), DeliveryRecord.returned(DeliveryRecord.Message.UNABLE_TO_REACH));
            delivery.setPhaseAndResetProgress(DeliveryPhase.DEPARTING_RECIPIENT);
            return true;
        }

        return DeliveryHandler.super.handlePhaseTransition(level, delivery);
    }

    @Override
    public void endDelivery(class_3218 level, Delivery delivery) {
        if (!delivery.getMail().method_7960()) {
            pigeon().method_5775(delivery.getMail().method_7972());
            Pigeon.LOGGER.info("{} has dropped undelivered mail on the ground.", pigeon().method_5477().getString());
            delivery.setMail(class_1799.field_8037);
        }

        pigeon().setDelivery(null);

        if (pigeon().getOrigin().isService()) {
            pigeon().onVanished(level);
            pigeon().method_31472();
        } else {
            pigeon().setOrigin(null);
            pigeon().getPigeonholeHandler().setTargetPos(pigeon().getPigeonholeHandler().getLastReleasePos());
            // Prevent Pigeon entering Pigeonhole immediately:
            pigeon().getPigeonholeHandler().setWantCooldown(20);
            pigeon().setTiredTicks(Config.Server.PIGEON_TIRED_AFTER_DELIVERY_TICKS.get());
        }
    }

    protected boolean hasReachedSegmentEndPos(Delivery delivery) {
        return delivery.getRoute().getSegment(delivery.getPhase()).endPos()
              .map(pos -> pigeon().hasReachedTarget(pos))
              .orElse(true);
    }
}
