package io.github.mortuusars.envelope.world.mail.address;

import com.mojang.datafixers.util.Either;
import io.github.mortuusars.envelope.util.EnvelopeSymbols;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3544;
import net.minecraft.class_5244;
import net.minecraft.class_5250;

public class AddressFormatter {
    public static final int NEUTRAL_COLOR = 0xFFE6CB98;
    public static final int SENDER_COLOR = 0xFF7AB5E1;
    public static final int RECIPIENT_COLOR = 0xFFE8AD77;

    protected final Address address;
    protected boolean icon = false;
    protected String iconSeparator = EnvelopeSymbols.SMALL_SPACE;
    protected Either<class_124, class_2583> iconStyle = Either.right(class_2583.field_24360);
    protected Either<class_124, class_2583> textStyle = Either.right(class_2583.field_24360);
    protected int maxLength = Integer.MAX_VALUE;

    protected AddressFormatter(Address address) {
        this.address = address;
    }

    public static AddressFormatter of(Address address) {
        return new AddressFormatter(address);
    }

    // --

    public AddressFormatter asNeutral() {
        return this
              .withIcon()
              .withIconColor(NEUTRAL_COLOR)
              .withColor(NEUTRAL_COLOR);
    }

    public AddressFormatter asSender() {
        return this
              .withIcon()
              .withIconColor(SENDER_COLOR)
              .withColor(SENDER_COLOR);
    }

    public AddressFormatter asRecipient() {
        return this
              .withIcon()
              .withIconColor(RECIPIENT_COLOR)
              .withColor(RECIPIENT_COLOR);
    }

    // --

    public AddressFormatter withIcon() {
        this.icon = true;
        return this;
    }

    public AddressFormatter withIconSeparator(String separator) {
        this.iconSeparator = separator;
        return this;
    }

    public AddressFormatter withIconColor(class_124 formatting) {
        this.iconStyle = Either.left(formatting);
        return this;
    }

    public AddressFormatter withIconStyle(class_2583 style) {
        this.iconStyle = Either.right(style);
        return this;
    }

    public AddressFormatter withIconColor(int color) {
        this.iconStyle = Either.right(class_2583.field_24360.method_36139(color));
        return this;
    }

    public AddressFormatter withColor(class_124 formatting) {
        this.textStyle = Either.left(formatting);
        return this;
    }

    public AddressFormatter withStyle(class_2583 style) {
        this.textStyle = Either.right(style);
        return this;
    }

    public AddressFormatter withColor(int color) {
        this.textStyle = Either.right(class_2583.field_24360.method_36139(color));
        return this;
    }

    public AddressFormatter withMaxLength(int maxLength) {
        this.maxLength = maxLength;
        return this;
    }

    // --

    public class_5250 toComponent() {
        class_5250 addressComponent;
        if (maxLength < Integer.MAX_VALUE) {
            String string = class_3544.method_34963(address.toString(), maxLength, true);
            addressComponent = class_2561.method_43470(string);
        } else {
            addressComponent = address.getName();
        }
        addressComponent = addressComponent.method_27696(createStyle(textStyle));

        if (icon) {
            return class_2561.method_43473()
                  .method_10852(class_2561.method_43470(getIcon(address)).method_27696(createStyle(iconStyle)))
                  .method_27693(iconSeparator)
                  .method_10852(addressComponent);
        }

        return addressComponent;
    }

    @Override
    public String toString() {
        String addressString = class_3544.method_34963(address.toString(), maxLength, true);

        String addressText = textStyle.left()
              .map(formatting -> formatting + addressString + class_124.field_1070)
              .orElse(addressString);

        if (icon) {
            String icon = iconStyle.left()
                  .map(formatting -> formatting + getIcon(address) + class_124.field_1070)
                  .orElse(getIcon(address));
            return icon + iconSeparator + addressText;
        }

        return addressText;
    }

    protected class_2583 createStyle(Either<class_124, class_2583> style) {
        return style.map(class_2583.field_24360::method_27706, Function.identity());
    }

    // --

    public static @NotNull String getIcon(Address address) {
        if (address.equals(Address.UNKNOWN)) return EnvelopeSymbols.ADDRESS_UNKNOWN;
        if (address.equals(Address.MAIL_SERVICE)) return EnvelopeSymbols.ADDRESS_MAIL_SERVICE;
        return switch (address.type()) {
            case BLOCK -> EnvelopeSymbols.ADDRESS_BLOCK;
            case PLAYER -> EnvelopeSymbols.ADDRESS_PLAYER;
            case ENTITY -> EnvelopeSymbols.ADDRESS_ENTITY;
        };
    }

    public static @NotNull class_2561 fullSender(@Nullable Address sender) {
        if (sender == null) return class_5244.field_39003;
        return class_2561.method_43471("gui.envelope.mail.sender").method_27692(class_124.field_1080)
              .method_27693(": ").method_27692(class_124.field_1080)
              .method_10852(sender.format().asSender().toComponent());
    }

    public static @NotNull class_2561 fullRecipient(@Nullable Address recipient) {
        if (recipient == null) return class_5244.field_39003;
        return class_2561.method_43471("gui.envelope.mail.recipient").method_27692(class_124.field_1080)
              .method_27693(": ").method_27692(class_124.field_1080)
              .method_10852(recipient.format().asRecipient().toComponent());
    }

    public static @NotNull class_2561 senderToRecipient(@Nullable Address sender, @Nullable Address recipient) {
        if (sender == null && recipient == null) return class_5244.field_39003;

        if (sender != null) {
            if (recipient == null) {
                recipient = Address.UNKNOWN;
            }

            return sender.format().asSender().withMaxLength(25).toComponent()
                  .method_10852(class_2561.method_43470(" " + EnvelopeSymbols.SMALL_FILLED_ARROW_RIGHT + " ").method_27692(class_124.field_1080))
                  .method_10852(recipient.format().asRecipient().withMaxLength(25).toComponent());
        }

        return recipient.format().asRecipient().toComponent();
    }
}
