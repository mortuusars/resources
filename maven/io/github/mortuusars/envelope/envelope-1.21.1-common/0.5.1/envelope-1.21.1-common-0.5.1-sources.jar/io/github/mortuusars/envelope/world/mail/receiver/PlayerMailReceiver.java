package io.github.mortuusars.envelope.world.mail.receiver;

import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.service.MailService;
import net.minecraft.class_1799;
import net.minecraft.class_3218;

public class PlayerMailReceiver implements MailReceiver {
    private final Address.Player address;

    public PlayerMailReceiver(Address.Player address) {
        this.address = address;
    }

    @Override
    public class_1799 receiveMail(class_3218 level, class_1799 mail) {
        return MailService.of(level).getPlayers().getDefaultAddressOf(address)
              .map(MailboxMailReceiver::new)
              .map(receiver -> receiver.receiveMail(level, mail))
              .orElseGet(() -> returned(mail, DeliveryRecord.Message.RECIPIENT_NOT_FOUND));
    }
}