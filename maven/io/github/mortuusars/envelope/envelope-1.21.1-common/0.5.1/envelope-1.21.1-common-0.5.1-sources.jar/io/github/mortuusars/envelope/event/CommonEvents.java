package io.github.mortuusars.envelope.event;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.block.dispenser.PlaceBlockDispenseItemBehavior;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_3218;

public class CommonEvents {
    public static void commonSetup() {
        PlaceBlockDispenseItemBehavior placeBlockBehavior = new PlaceBlockDispenseItemBehavior();
        class_2315.method_10009(Envelope.Items.PACKAGE.get(), placeBlockBehavior);
        class_2315.method_10009(Envelope.Items.SEALED_PACKAGE.get(), placeBlockBehavior);
    }

    public static void levelTick(class_1937 level) {
    }

    /**
     * Fired before level data storage is saved.
     */
    public static void saveLevelData(class_3218 level) {
    }

    public static void entityLeaveLevel(class_1937 level, class_1297 entity) {
    }
}
