package io.github.mortuusars.envelope.world.entity.ai;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.util.bugger.Bugger;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlockEntity;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class MailboxHandler {
    public static final int MAX_BLACKLISTED_TARGETS = 3;
    public static final int DEFAULT_LOCATE_COOLDOWN = 100;

    public static final Codec<MailboxHandler> CODEC = RecordCodecBuilder.create(i -> i.group(
          class_2338.field_25064.optionalFieldOf("target_pos").forGetter(o -> Optional.ofNullable(o.getTargetPos())),
          Codec.INT.optionalFieldOf("locate_cooldown", 0).forGetter(MailboxHandler::getLocateCooldown)
    ).apply(i, MailboxHandler::new));

    protected final List<class_2338> blacklistedPositions = new ArrayList<>();

    protected @Nullable class_2338 targetPos;
    protected int locateCooldown;

    public MailboxHandler(Optional<class_2338> targetPos, int locateCooldown) {
        this.targetPos = targetPos.orElse(null);
        this.locateCooldown = locateCooldown;
    }

    public MailboxHandler() {
        this(Optional.empty(), 0);
    }

    public @Nullable class_2338 getTargetPos() {
        return targetPos;
    }

    public void setTargetPos(@Nullable class_2338 targetPos) {
        this.targetPos = targetPos;
    }

    public int getLocateCooldown() {
        return locateCooldown;
    }

    public void setLocateCooldown(int cooldown) {
        this.locateCooldown = cooldown;
    }

    public void resetLocateCooldown() {
        setLocateCooldown(DEFAULT_LOCATE_COOLDOWN);
    }

    // --

    public void tick(Pigeon pigeon, class_1937 level) {
        if (locateCooldown > 0) {
            locateCooldown--;
        }

        if (level instanceof class_3218 && pigeon.field_6012 % 20 == 0) {
            if (!isMailboxValid(level, pigeon.method_24515())) {
                setTargetPos(null);
            }
            Bugger.PIGEON_MAILBOX_HANDLER.send(pigeon.method_5628(), this);
        }
    }

    public boolean canStartDelivery(Pigeon pigeon) {
        return !pigeon.isTired();
    }

    // --

    public Optional<MailboxBlockEntity> getMailboxAtCurrentPos(class_1937 level) {
        @Nullable class_2338 pos = getTargetPos();
        if (pos != null && level.method_8477(pos) && level.method_8321(pos) instanceof MailboxBlockEntity be) {
            return Optional.of(be);
        }
        return Optional.empty();
    }

    public boolean isMailboxValid(class_1937 level, class_2338 entityPos) {
        @Nullable class_2338 currentPos = getTargetPos();
        if (currentPos == null) return false;
        if (!entityPos.method_19771(currentPos, 32)) return false;
        return level.method_8321(currentPos) instanceof MailboxBlockEntity blockEntity
              && blockEntity.isAvailableForPickup();
    }

    public boolean isTargetBlacklisted(class_2338 pos) {
        return this.blacklistedPositions.contains(pos);
    }

    private void blacklistTarget(class_2338 pos) {
        this.blacklistedPositions.add(pos);

        while (this.blacklistedPositions.size() > MAX_BLACKLISTED_TARGETS) {
            this.blacklistedPositions.removeFirst();
        }
    }

    public void clearBlacklist() {
        this.blacklistedPositions.clear();
    }

    public void dropAndBlacklistMailbox() {
        if (getTargetPos() != null) {
            blacklistTarget(getTargetPos());
        }

        dropMailbox();
    }

    public void dropMailbox() {
        setTargetPos(null);
        resetLocateCooldown();
    }

    @Override
    public String toString() {
        return "MailboxHandler{" +
              ", targetPos=" + targetPos +
              ", locateCooldown=" + locateCooldown +
              '}';
    }
}
