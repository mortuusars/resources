package io.github.mortuusars.envelope.compat.jei;

import io.github.mortuusars.envelope.Envelope;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import net.minecraft.class_2960;
import org.jetbrains.annotations.NotNull;

@JeiPlugin
public class EnvelopeJeiPlugin implements IModPlugin {
    private static final class_2960 ID = Envelope.resource("jei_plugin");

    @Override
    public @NotNull class_2960 getPluginUid() {
        return ID;
    }
}