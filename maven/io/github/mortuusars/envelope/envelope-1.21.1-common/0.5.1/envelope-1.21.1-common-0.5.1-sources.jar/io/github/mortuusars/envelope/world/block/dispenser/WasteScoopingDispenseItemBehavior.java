package io.github.mortuusars.envelope.world.block.dispenser;

import io.github.mortuusars.envelope.world.block.PigeonholeBlock;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2680;
import net.minecraft.class_2969;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.NotNull;

public class WasteScoopingDispenseItemBehavior extends class_2969 {
    public static final WasteScoopingDispenseItemBehavior INSTANCE = new WasteScoopingDispenseItemBehavior();

    @Override
    protected @NotNull class_1799 method_10135(class_2342 blockSource, class_1799 item) {
        class_3218 level = blockSource.comp_1967();
        class_2338 blockPos = blockSource.comp_1968().method_10093(blockSource.comp_1969().method_11654(class_2315.field_10918));
        method_27955(tryScoopWaste(level, blockPos));
        if (method_27954()) {
            item.method_7956(1, level, null, i -> {
            });
        }

        return item;
    }

    protected boolean tryScoopWaste(class_3218 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        if (state.method_26204() instanceof PigeonholeBlock && state.method_11654(PigeonholeBlock.WASTE_LEVEL) >= PigeonholeBlock.MAX_WASTE_LEVEL) {
            level.method_8396(null, pos, class_3417.field_14883.comp_349(), class_3419.field_15245, 1.0F, 1.0F);
            //TODO: waste loot table
            class_2315.method_36992(level, pos, state.method_11654(PigeonholeBlock.FACING), new class_1799(class_1802.field_8324));
            level.method_8652(pos, state.method_11657(PigeonholeBlock.WASTE_LEVEL, 0), class_2248.field_31036);
            return true;
        }

        return false;
    }
}
