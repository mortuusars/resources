package io.github.mortuusars.envelope.client.gui.tooltip;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;

public class PackageTooltipComponent implements class_5684 {
    public static final class_2960 BACKGROUND_SPRITE = Envelope.resource("container/package/background");
    protected static final int BG_WIDTH = 58;
    protected static final int BG_HEIGHT = 40;

    protected final PackageContents packageContents;

    public PackageTooltipComponent(PackageContents packageContents) {
        this.packageContents = packageContents;
    }

    @Override
    public int method_32664(class_327 font) {
        return BG_WIDTH;
    }

    @Override
    public int method_32661() {
        return BG_HEIGHT + 3;
    }

    @Override
    public void method_32666(class_327 font, int x, int y, class_332 guiGraphics) {
        guiGraphics.method_52706(BACKGROUND_SPRITE, x, y, BG_WIDTH, BG_HEIGHT);

        for (int row = 0; row < 2; row++) {
            for (int column = 0; column < 3; column++) {
                int slotIndex = (column + row * 3);
                int slotX = x + column * 18 + 3;
                int slotY = y + row * 18 + 3;
                class_1799 stack = packageContents.getItemForReading(slotIndex);
                guiGraphics.method_51428(stack, slotX, slotY, slotIndex);
                guiGraphics.method_51431(font, stack, slotX, slotY);
            }
        }
    }
}
