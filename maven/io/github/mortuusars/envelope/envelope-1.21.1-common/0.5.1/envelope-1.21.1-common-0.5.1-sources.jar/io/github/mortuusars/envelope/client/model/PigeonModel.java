package io.github.mortuusars.envelope.client.model;

import com.google.common.collect.ImmutableList;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.util.EasingFunction;
import net.minecraft.class_3532;
import net.minecraft.class_4592;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PigeonModel extends class_4592<Pigeon> {
    private final class_630 root;

    private final class_630 head;
    private final class_630 beak;
    private final class_630 hat;

    private final class_630 body;
    private final class_630 backpackStraps;
    private final class_630 backpackBag;

    private final class_630 leftLeg;
    private final class_630 rightLeg;
    private final class_630 tail;
    private final class_630 leftWing;
    private final class_630 rightWing;

    public PigeonModel(class_630 root) {
        // bodyYOffset = 24 * (babyBodyScale - 1)
        // babyYHeadOffset = I have not been able to crack the code. so have a magic number instead.
        super(true, 6.7F, 0, 1.75F, 2.1F, 24F * 1.1F);
        this.root = root;

        head = root.method_32086("head");
        beak = head.method_32086("beak");
        hat = head.method_32086("hat");

        body = root.method_32086("body");
        backpackStraps = body.method_32086("backpack_straps");
        backpackBag = body.method_32086("backpack_bag");

        leftLeg = root.method_32086("left_leg");
        rightLeg = root.method_32086("right_leg");
        tail = root.method_32086("tail");
        leftWing = root.method_32086("left_wing");
        rightWing = root.method_32086("right_wing");
    }

    public static class_5607 createLayerDefinition() {
        class_5609 mesh = new class_5609();
        class_5610 part = mesh.method_32111();

        class_5610 head = part.method_32117("head",
              class_5606.method_32108()
                    .method_32101(0, 14)
                    .method_32098(-3.0F, -4.0F, -5.0F, 6.0F, 6.0F, 6.0F, class_5605.field_27715),
              class_5603.method_32090(0.0F, 16.0F, -1.0F));

        class_5610 beak = head.method_32117("beak",
              class_5606.method_32108()
                    .method_32101(0, 14)
                    .method_32098(-1.0F, -1.0F, -1.0F, 2.0F, 2.0F, 1.0F, new class_5605(0.01F))
                    .method_32101(0, 16)
                    .method_32098(0.0F, 0.0F, -2.0F, 0.0F, 1.0F, 1.0F, class_5605.field_27715),
              class_5603.method_32090(0.0F, -1.0F, -5.0F));

        class_5610 hat = head.method_32117("hat",
              class_5606.method_32108()
                    .method_32101(1, 46)
                    .method_32098(-3.5F, -2.0F, -3.5F, 7.0F, 2.0F, 7.0F, class_5605.field_27715)
                    .method_32101(0, 55)
                    .method_32098(-3.5F, 0.0F, -4.5F, 7.0F, 1.0F, 8.0F, class_5605.field_27715),
              class_5603.method_32091(0.0F, -4.0F, -2.0F, -0.1745F, 0.0F, 0.0F));

        class_5610 body = part.method_32117("body",
              class_5606.method_32108()
                    .method_32101(0, 0)
                    .method_32098(-4.0F, -8.0F, -4.0F, 8.0F, 6.0F, 8.0F, class_5605.field_27715),
              class_5603.method_32090(0.0F, 24.05F, 0.0F));

        class_5610 backpackStraps = body.method_32117("backpack_straps",
              class_5606.method_32108()
                    .method_32101(32, 50)
                    .method_32098(-4.0F, -3.0F, -4.0F, 8.0F, 6.0F, 8.0F, new class_5605(0, 0.01F, 0.01F)),
              class_5603.method_32090(0.0F, -5.0F, 0.0F));

        class_5610 backpackBag = body.method_32117("backpack_bag",
              class_5606.method_32108()
                    .method_32101(32, 38)
                    .method_32098(-5.0F, -3.0F, -3.0F, 10.0F, 6.0F, 6.0F, class_5605.field_27715),
              class_5603.method_32091(0.0F, -9.0F, 2.0F, 0.7854F, 0.0F, 0.0F));


        class_5610 leftLeg = part.method_32117("left_leg", class_5606.method_32108()
                    .method_32101(9, 26)
                    .method_32098(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 0.0F, class_5605.field_27715)
                    .method_32101(6, 28)
                    .method_32098(-1.0F, 2.0F, -3.0F, 3.0F, 0.0F, 3.0F, class_5605.field_27715),
              class_5603.method_32090(1.0F, 22.0F, 1.0F));

        class_5610 rightLeg = part.method_32117("right_leg", class_5606.method_32108()
                    .method_32101(7, 26)
                    .method_32098(-1.0F, 0.0F, 0.0F, 1.0F, 2.0F, 0.0F, class_5605.field_27715)
                    .method_32101(0, 28)
                    .method_32098(-2.0F, 2.0F, -3.0F, 3.0F, 0.0F, 3.0F, class_5605.field_27715),
              class_5603.method_32090(-1.0F, 22.0F, 1.0F));

        class_5610 tail = part.method_32117("tail",
              class_5606.method_32108()
                    .method_32101(24, 0)
                    .method_32098(-3.0F, 0.0F, -1.0F, 6.0F, 5.0F, 1.0F, class_5605.field_27715),
              class_5603.method_32091(0.0F, 19.0F, 4.0F, 0.7854F, 0.0F, 0.0F));

        class_5610 leftWing = part.method_32117("left_wing",
              class_5606.method_32108()
                    .method_32101(46, 3).method_32096()
                    .method_32098(-1.0F, 0.0F, -3.0F, 1.0F, 4.0F, 6.0F, class_5605.field_27715).method_32106(false),
              class_5603.method_32091(4.0F, 17.0F, 0.0F, 0.0F, 0.0F, -0.3927F));

        class_5610 rightWing = part.method_32117("right_wing",
              class_5606.method_32108()
                    .method_32101(32, 3)
                    .method_32098(0.0F, 0.0F, -3.0F, 1.0F, 4.0F, 6.0F, class_5605.field_27715),
              class_5603.method_32091(-4.0F, 17.0F, 0.0F, 0.0F, 0.0F, 0.3927F));

        return class_5607.method_32110(mesh, 64, 64);
    }

    public void setupAnim(Pigeon pigeon, float limbSwing, float limbSwingAmount, float bob, float netHeadYaw, float headPitch) {
        root.method_32088().forEach(class_630::method_41923);

        head.field_3654 = headPitch * (float) (Math.PI / 180.0);
        head.field_3675 = netHeadYaw * (float) (Math.PI / 180.0);

        switch (getState(pigeon)) {
            case FLYING -> {
                leftWing.field_3674 = -bob;
                rightWing.field_3674 = bob;

                leftLeg.field_3654 = 0.75f * limbSwingAmount;
                leftLeg.field_3675 = -0.15f;
                rightLeg.field_3654 = 0.75f * limbSwingAmount;
                rightLeg.field_3675 = 0.15f;

                // Rock back and forth
                float anim = ((pigeon.field_6012 + Minecrft.get().method_60646().method_60637(true)) % 60) / 60;
                anim *= 2;
                if (anim > 1) {
                    anim = 2 - anim;
                }
                anim = ((float) EasingFunction.EASE_IN_OUT_QUAD.ease(anim));
                body.field_3654 = anim * 0.1f;
                head.field_3654 = -anim * 0.05f;
                head.field_3655 -= 0.75F * (anim);

                leftWing.field_3654 += (anim * 0.2f);
                leftWing.field_3656 -= 0.35F * (anim);
                leftWing.field_3655 -= 0.5F * (anim);

                rightWing.field_3654 += (anim * 0.2f);
                rightWing.field_3656 -= 0.35F * (anim);
                rightWing.field_3655 -= 0.5F * (anim);

                tail.field_3654 += (limbSwingAmount * 0.75F) + (anim * 0.1f);
                tail.field_3656 -= 0.35F * (anim);
                tail.field_3655 -= 0.5F * (anim);
            }
            case STANDING -> {
                leftWing.field_3674 = -0.3927F;
                rightWing.field_3674 = 0.3927F;
                leftLeg.field_3654 = class_3532.method_15362(limbSwing * 0.6662F + (float) Math.PI) * 1.4F * limbSwingAmount;
                rightLeg.field_3654 = class_3532.method_15362(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
            }
            case SITTING -> {
                body.field_3656 += 1.9F;
                head.field_3656 += pigeon.method_6109() ? 1.9F : 2.9F;

                leftWing.field_3674 = -0.2F;
                rightWing.field_3674 = 0.2F;
                leftWing.field_3656 += 2;
                rightWing.field_3656 += 2;

                tail.field_3654 = 0.75f;
            }
        }
    }

    public PigeonModel.State getState(@Nullable Pigeon pigeon) {
        if (pigeon == null) return State.STANDING;
        if (pigeon.isSitting()) return State.SITTING;
        return pigeon.method_6581() ? State.FLYING : State.STANDING;
    }

    @Override
    protected @NotNull Iterable<class_630> method_22946() {
        return ImmutableList.of(head);
    }

    @Override
    protected @NotNull Iterable<class_630> method_22948() {
        return ImmutableList.of(body, rightLeg, leftLeg, rightWing, leftWing, tail);
    }

    public enum State {
        FLYING,
        STANDING,
        SITTING
    }
}
