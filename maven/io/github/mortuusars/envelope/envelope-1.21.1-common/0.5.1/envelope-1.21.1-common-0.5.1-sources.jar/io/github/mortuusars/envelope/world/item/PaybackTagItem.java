package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.PlatformHelper;
import io.github.mortuusars.envelope.world.block.PigeonholeBlock;
import io.github.mortuusars.envelope.world.inventory.PaybackTagMenu;
import io.github.mortuusars.envelope.world.inventory.RequestedItem;
import io.github.mortuusars.envelope.world.item.component.RequestedPayback;
import io.github.mortuusars.envelope.world.item.component.PaybackTagContents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_5536;
import net.minecraft.class_5632;
import net.minecraft.class_747;
import net.minecraft.class_9323;
import net.minecraft.class_9329;
import net.minecraft.world.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class PaybackTagItem extends class_1792 implements ApplicatorItem {
    public PaybackTagItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public @NotNull Optional<class_5632> method_32346(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS));
    }

    @Override
    public boolean method_31565(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player) {
        if (action != class_5536.field_27014) return false;
        if (!slot.method_32754(player)) return false;
        if (!slot.method_7677().method_31573(Envelope.Tags.Items.MAILABLE)) return false;

        PaybackTagContents contents = stack.method_57825(Envelope.DataComponents.PAYBACK_TAG_CONTENTS, PaybackTagContents.EMPTY);
        @Nullable RequestedPayback existingRequestedPayback = slot.method_7677().method_57824(Envelope.DataComponents.MAIL_REQUESTED_PAYBACK);

        if (contents.isEmpty()) {
            if (existingRequestedPayback == null) {
                return true; // do nothing
            }
            slot.method_7677().method_57381(Envelope.DataComponents.MAIL_REQUESTED_PAYBACK);
        } else {
            RequestedPayback requestedPayback = createPayback(player.method_37908(), stack);
            if (existingRequestedPayback != null && existingRequestedPayback.equals(requestedPayback)) {
                return true; // do nothing
            }
            slot.method_7677().method_57379(Envelope.DataComponents.MAIL_REQUESTED_PAYBACK, requestedPayback);
        }

        slot.method_7668();
        stack.method_7934(1);
        player.method_5783(class_3417.field_14883.comp_349(), 1, 1);
        return true;
    }

    public RequestedPayback createPayback(class_1937 level, class_1799 stack) {
        PaybackTagContents tagContents = stack.method_57825(Envelope.DataComponents.PAYBACK_TAG_CONTENTS, PaybackTagContents.DEFAULT);

        List<RequestedItem> requestedItems = tagContents.getItemsForReading().stream()
              .limit(RequestedPayback.SLOTS)
              .filter(item -> !item.method_7960())
              .map(this::createRequestedItemFromStack)
              .toList();

        return RequestedPayback.createOrDefault(requestedItems);
    }

    public RequestedItem createRequestedItemFromStack(class_1799 stack) {
        if (stack.method_7960()) {
            Envelope.LOGGER.warn("Tried to create RequestedItem from empty ItemStack.");
            return RequestedItem.DEFAULT;
        }

        class_9323 defaultComponents = new class_1799(stack.method_7909(), stack.method_7947()).method_57353();
        class_9323 components = stack.method_7972().method_57353();
        class_9323 uniqueComponents = components.method_57828(type ->
              !Objects.equals(components.method_57829(type), defaultComponents.method_57829(type)));
        return new RequestedItem(stack.method_7909(), stack.method_7947(), class_9329.method_57865(uniqueComponents));
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_2680 state = context.method_8045().method_8320(context.method_8037());
        if (state.method_26204() instanceof PigeonholeBlock) {
            return class_1269.field_5814;
        }

        return super.method_7884(context);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        if (player instanceof class_3222 serverPlayer) {
            PlatformHelper.openMenu(
                  serverPlayer,
                  new class_747((id, inventory, pl) ->
                        new PaybackTagMenu(id, inventory, usedHand), class_2561.method_43471("container.envelope.payback_tag")),
                  buffer -> buffer.method_10817(usedHand));
            player.method_7357().method_7906(this, 3);
        }

        return class_1271.method_29237(player.method_5998(usedHand), level.field_9236);
    }

    @Override
    public boolean shouldRenderTooltipWhileCarrying(class_1937 level, class_1799 carried, class_1799 hovered) {
        return true;
    }
}