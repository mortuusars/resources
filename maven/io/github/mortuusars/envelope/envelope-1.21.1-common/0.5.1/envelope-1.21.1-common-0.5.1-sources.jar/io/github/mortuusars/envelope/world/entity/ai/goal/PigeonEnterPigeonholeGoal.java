package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.block.PigeonholeBlockEntity;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import org.jetbrains.annotations.Nullable;

public class PigeonEnterPigeonholeGoal extends class_1352 {
    private final Pigeon pigeon;

    public PigeonEnterPigeonholeGoal(Pigeon pigeon) {
        this.pigeon = pigeon;
    }

    @Override
    public boolean method_6264() {
        if (pigeon.isDelivering()) {
            return false;
        }

        @Nullable class_2338 pos = pigeon.getPigeonholeHandler().getTargetPos();

        if (pos != null
              && pigeon.getPigeonholeHandler().wantsToEnterPigeonhole(pigeon)
              && pos.method_19769(pigeon.method_19538(), 2.0)
              && !Position.isFireNearby(pigeon.method_37908(), pos)
              && pigeon.method_37908().method_8321(pos) instanceof PigeonholeBlockEntity blockEntity) {
            if (blockEntity.hasSpaceForAnotherOccupant()) {
                return true;
            }

            pigeon.getPigeonholeHandler().setTargetPos(null);
        }

        return false;
    }

    @Override
    public boolean method_6266() {
        return false;
    }

    @Override
    public void method_6269() {
        pigeon.getPigeonholeHandler().getPigeonholeAtCurrentPos(pigeon.method_37908())
              .ifPresent(pigeonhole -> pigeonhole.addOccupant(pigeonhole.method_11016(), pigeonhole.method_11010(), pigeon));
    }
}
