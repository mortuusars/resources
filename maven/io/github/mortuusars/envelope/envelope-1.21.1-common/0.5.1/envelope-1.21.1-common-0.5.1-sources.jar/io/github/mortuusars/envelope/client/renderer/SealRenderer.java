package io.github.mortuusars.envelope.client.renderer;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.seal.*;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public class SealRenderer {
    public static final class_2960 IRON_DIE_TEXTURE = Envelope.resource("textures/gui/seal/die/iron.png");

    public void render(Seal seal, class_332 guiGraphics, int x, int y) {
        SealMaterial material = seal.material().comp_349();
        ShadingPalette colors = material.impressionPalette();

        class_2960 materialTexture = material.texture();
        class_2960 impressionTexture = seal.impression().comp_349().texture();

        // Background
        guiGraphics.method_25290(materialTexture, x, y, 0, 0, 30, 30, 30, 30);

        // Side
        colors.side().setShaderColor();
        guiGraphics.method_25290(impressionTexture, x + 1, y + 2, 0, 0, 30, 30, 30, 30);
        guiGraphics.method_25290(impressionTexture, x, y + 2, 0, 0, 30, 30, 30, 30);
        guiGraphics.method_25290(impressionTexture, x - 1, y + 2, 0, 0, 30, 30, 30, 30);
        guiGraphics.method_25290(impressionTexture, x + 1, y + 1, 0, 0, 30, 30, 30, 30);
        guiGraphics.method_25290(impressionTexture, x, y + 1, 0, 0, 30, 30, 30, 30);
        guiGraphics.method_25290(impressionTexture, x - 1, y + 1, 0, 0, 30, 30, 30, 30);
        guiGraphics.method_25290(impressionTexture, x + 1, y, 0, 0, 30, 30, 30, 30);
        guiGraphics.method_25290(impressionTexture, x, y, 0, 0, 30, 30, 30, 30);
        guiGraphics.method_25290(impressionTexture, x - 1, y, 0, 0, 30, 30, 30, 30);
        guiGraphics.method_25290(impressionTexture, x + 1, y - 1, 0, 0, 30, 30, 30, 30);
        guiGraphics.method_25290(impressionTexture, x, y - 1, 0, 0, 30, 30, 30, 30);
        guiGraphics.method_25290(impressionTexture, x - 1, y - 1, 0, 0, 30, 30, 30, 30);
        guiGraphics.method_25290(impressionTexture, x, y - 2, 0, 0, 30, 30, 30, 30);

        // Shadow
        colors.shadow().setShaderColor();
        guiGraphics.method_25290(impressionTexture, x, y + 1, 0, 0, 30, 30, 30, 30);

        // Highlight
        colors.highlight().setShaderColor();
        guiGraphics.method_25290(impressionTexture, x, y - 1, 0, 0, 30, 30, 30, 30);

        // Base
        colors.base().setShaderColor();
        guiGraphics.method_25290(impressionTexture, x, y, 0, 0, 30, 30, 30, 30);

        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    public void renderDie(SealImpression impression, ShadingPalette colors, class_332 guiGraphics, int x, int y) {
        class_2960 impressionTexture = impression.texture();

        // Background
        guiGraphics.method_25290(IRON_DIE_TEXTURE, x, y, 0, 0, 30, 30, 30, 30);

        // textureWidth parameter is negative to flip the impression texture on the X axis

        // Side
        colors.side().setShaderColor();
        guiGraphics.method_25290(impressionTexture, x + 1, y + 1, 0, 0, 30, 30, -30, 30);
        guiGraphics.method_25290(impressionTexture, x, y + 1, 0, 0, 30, 30, -30, 30);
        guiGraphics.method_25290(impressionTexture, x - 1, y + 1, 0, 0, 30, 30, -30, 30);
        guiGraphics.method_25290(impressionTexture, x + 1, y, 0, 0, 30, 30, -30, 30);
        guiGraphics.method_25290(impressionTexture, x, y, 0, 0, 30, 30, -30, 30);
        guiGraphics.method_25290(impressionTexture, x - 1, y, 0, 0, 30, 30, -30, 30);
        guiGraphics.method_25290(impressionTexture, x + 1, y - 1, 0, 0, 30, 30, -30, 30);
        guiGraphics.method_25290(impressionTexture, x, y - 1, 0, 0, 30, 30, -30, 30);
        guiGraphics.method_25290(impressionTexture, x - 1, y - 1, 0, 0, 30, 30, -30, 30);
        guiGraphics.method_25290(impressionTexture, x + 1, y - 2, 0, 0, 30, 30, -30, 30);
        guiGraphics.method_25290(impressionTexture, x, y - 2, 0, 0, 30, 30, -30, 30);
        guiGraphics.method_25290(impressionTexture, x - 1, y - 2, 0, 0, 30, 30, -30, 30);

        // Highlight
        colors.highlight().setShaderColor();
        guiGraphics.method_25290(impressionTexture, x, y + 1, 0, 0, 30, 30, -30, 30);

        // Shadow
        colors.shadow().setShaderColor();
        guiGraphics.method_25290(impressionTexture, x, y - 1, 0, 0, 30, 30, -30, 30);

        // Base
        colors.base().setShaderColor();
        guiGraphics.method_25290(impressionTexture, x, y, 0, 0, 30, 30, -30, 30);

        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    // Have you seen someone rendering textures this way? Now you have.
    // Patent Pending ™
}
