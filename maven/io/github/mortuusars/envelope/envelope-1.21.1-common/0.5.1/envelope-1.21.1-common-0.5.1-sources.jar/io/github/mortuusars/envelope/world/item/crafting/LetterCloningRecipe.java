package io.github.mortuusars.envelope.world.item.crafting;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.LetterAndQuillItem;
import io.github.mortuusars.envelope.world.item.LetterItem;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_9694;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class LetterCloningRecipe extends class_1852 {
	public LetterCloningRecipe(class_7710 category) {
		super(category);
	}

	public boolean matches(class_9694 input, class_1937 level) {
		int copies = 0;
		class_1799 sourceStack = class_1799.field_8037;

		for (class_1799 stack : input.method_59989()) {
            if (stack.method_7960()) {
				continue;
            }

            if (stack.method_7909() instanceof LetterItem) {
                if (!sourceStack.method_7960()) {
                    return false;
                }
                sourceStack = stack;
            } else {
                if (!(stack.method_7909() instanceof LetterAndQuillItem)) {
                    return false;
                }

                copies++;
            }
        }

		return !sourceStack.method_7960() && copies > 0;
	}

	public @NotNull class_1799 assemble(class_9694 input, class_7225.class_7874 registries) {
		int copies = 0;
		class_1799 sourceStack = class_1799.field_8037;

		for (class_1799 stack : input.method_59989()) {
            if (stack.method_7960()) {
				continue;
            }

			if (stack.method_7909() instanceof LetterItem) {
                if (!sourceStack.method_7960()) {
                    return class_1799.field_8037;
                }

                sourceStack = stack;
            } else {
				if (!(stack.method_7909() instanceof LetterAndQuillItem)) {
                    return class_1799.field_8037;
                }

                copies++;
            }
        }

		if (!sourceStack.method_7960() && copies > 0) {
			class_1799 result = sourceStack.method_46651(copies);
			result.method_57381(Envelope.DataComponents.LETTER_TATTERED);
			Mail.removePreviousDeliveryData(result);
			result.method_57381(Envelope.DataComponents.MAIL_RECIPIENT);
			result.method_57381(Envelope.DataComponents.MAIL_REQUESTED_PAYBACK);
			return result;
		}

        return class_1799.field_8037;
    }

	public @NotNull class_2371<class_1799> getRemainingItems(class_9694 input) {
		class_2371<class_1799> items = class_2371.method_10213(input.method_59983(), class_1799.field_8037);

		for (int i = 0; i < items.size(); i++) {
			class_1799 stack = input.method_59984(i);
			@Nullable class_1792 remainingItem = stack.method_7909().method_7858();
			if (remainingItem != null) {
				items.set(i, new class_1799(remainingItem));
			} else if (stack.method_7909() instanceof LetterItem) {
				items.set(i, stack.method_46651(1));
				break;
			}
		}

		return items;
	}

	@Override
	public @NotNull class_1865<?> method_8119() {
		return Envelope.RecipeSerializers.LETTER_CLONING.get();
	}

	@Override
	public boolean method_8113(int width, int height) {
		return width >= 3 && height >= 3;
	}
}
