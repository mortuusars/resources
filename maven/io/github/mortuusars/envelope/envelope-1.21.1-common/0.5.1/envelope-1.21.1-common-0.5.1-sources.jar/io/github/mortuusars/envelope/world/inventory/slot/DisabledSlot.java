package io.github.mortuusars.envelope.world.inventory.slot;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class DisabledSlot extends class_1735 {
    private boolean active = true;

    public DisabledSlot(class_1263 container, int slot, int x, int y) {
        super(container, slot, x, y);
    }

    @Override
    public boolean method_7674(class_1657 player) {
        return false;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return false;
    }

    @Override
    public boolean method_7682() {
        return active;
    }

    public DisabledSlot setActive(boolean active) {
        this.active = active;
        return this;
    }
}
