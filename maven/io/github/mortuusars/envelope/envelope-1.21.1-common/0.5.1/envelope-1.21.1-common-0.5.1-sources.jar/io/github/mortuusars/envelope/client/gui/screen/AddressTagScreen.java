package io.github.mortuusars.envelope.client.gui.screen;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.gui.Sprites;
import io.github.mortuusars.envelope.client.gui.widget.AddressBoxSuggestions;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.AddressFormatter;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.serverbound.AddressTagApplyC2SP;
import net.minecraft.class_1109;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_342;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_7919;
import net.minecraft.class_8666;
import net.minecraft.client.gui.components.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class AddressTagScreen extends class_437 {
    public static final class_2960 TEXTURE = Envelope.resource("textures/gui/address_tag.png");

    public static final class_8666 CONFIRM_BUTTON_SPRITES =
          Sprites.threeStates(Envelope.resource("address_tag/confirm_button"));

    protected final class_1268 hand;
    protected final class_1799 tag;
    protected final AllAddresses knownAddresses;
    protected Optional<Address> existingAddress;

    protected int imageWidth, imageHeight;
    protected int leftPos, topPos;
    protected int titleLabelX, titleLabelY;

    protected class_342 addressBox;
    protected AddressBoxSuggestions suggestions;
    protected class_344 confirmButton;

    protected Optional<Address> matchedKnownAddress = Optional.empty();
    protected @Nullable String currentSuggestion;

    public AddressTagScreen(class_1268 hand, AllAddresses knownAddresses, class_2561 title) {
        super(title);
        this.hand = hand;
        this.tag = Minecrft.player().method_5998(hand).method_7972(); // Copying to not cause client/server desync if edits are canceled.
        this.knownAddresses = knownAddresses;
        this.existingAddress = Optional.ofNullable(tag.method_57824(Envelope.DataComponents.ADDRESS));
    }

    @Override
    protected void method_25426() {
        imageWidth = 186;
        imageHeight = 40;
        leftPos = (field_22789 - imageWidth) / 2;
        topPos = (field_22790 - imageHeight) / 2;
        titleLabelX = leftPos + 12;
        titleLabelY = topPos + 6;

        addressBox = new class_342(field_22793, leftPos + 26, topPos + 21, 125, 9, class_2561.method_43473());
        addressBox.method_1852(getInitialAddressValue());
        addressBox.method_1880(Address.MAX_LENGTH);
        addressBox.method_1868(0xFFFFFFFF);
        addressBox.method_1863(this::addressTextChanged);
        addressBox.method_1858(false);
        addressBox.method_1856(false);
        method_37063(addressBox);

        suggestions = new AddressBoxSuggestions(addressBox, getAddressesForSuggestions(), 6);
        suggestions.update();

        confirmButton = new class_344(leftPos + 158, topPos + 17, 16, 16, CONFIRM_BUTTON_SPRITES,
              button -> confirm(), class_2561.method_43471("gui.envelope.confirm"));
        confirmButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.envelope.confirm")));
        method_37063(confirmButton);

        method_48265(addressBox);

        addressTextChanged(addressBox.method_1882());
    }

    // --

    protected class_1799 getTargetPreview() {
        return tag;
    }

    // -- Address

    protected String getCurrentAddressId() {
        return addressBox.method_1882().trim();
    }

    protected String getInitialAddressValue() {
        @Nullable Address address = tag.method_57824(Envelope.DataComponents.ADDRESS);
        if (address != null) {
            return address.toString();
        }
        return "";
    }

    protected Optional<Address> getMatchedKnownAddress() {
        return matchedKnownAddress;
    }

    protected Optional<Address> getOrCreateAddressFromCurrentValue() {
        String addressId = getCurrentAddressId().trim();
        if (addressId.isBlank()) {
            return Optional.empty();
        }

        return getMatchedKnownAddress().or(() -> Optional.of(new Address.Block(addressId)));
    }

    protected AllAddresses getAddressesForSuggestions() {
        return knownAddresses;
    }

    protected boolean isRenaming() {
        return existingAddress.isPresent();
    }

    protected boolean isCurrentIdSameAsExistingAddress() {
        String currentAddressId = getCurrentAddressId().trim();
        return existingAddress.map(address -> address.matches(currentAddressId)).orElse(false);
    }

    protected void updateItem() {
        getOrCreateAddressFromCurrentValue().ifPresentOrElse(
              value -> tag.method_57379(Envelope.DataComponents.ADDRESS, value),
              () -> tag.method_57381(Envelope.DataComponents.ADDRESS));
    }

    // -- Events

    protected void addressTextChanged(String text) {
        String addressId = text.trim();
        matchedKnownAddress = knownAddresses.byName(addressId);
        updateItem();

//        boolean showSuggestion = matchedKnownAddress.isPresent() || text.isBlank();
//        @Nullable String suggestion = !showSuggestion ? getAutocompleteSuggestion(text) : null;
//        currentSuggestion = suggestion;
//        if (suggestion != null && !suggestion.equalsIgnoreCase(addressBox.getValue())) {
//            addressBox.setSuggestion(suggestion.substring(addressBox.getValue().length()));
//        } else {
//            addressBox.setSuggestion(suggestion);
//        }

        suggestions.update();
    }

    protected boolean confirm() {
        if (!isCurrentIdSameAsExistingAddress()) {
            Minecrft.get().method_1483().method_4873(class_1109.method_4758(class_3417.field_17484, 1f));
            int slot = this.hand == class_1268.field_5808 ? Minecrft.player().method_31548().field_7545 : class_1661.field_30639;
            Packets.sendToServer(new AddressTagApplyC2SP(slot, getOrCreateAddressFromCurrentValue()));
        }
        close();
        return true;
    }

    @Override
    public void method_25410(class_310 minecraft, int width, int height) {
        // Prevent contents reset when window is resized
        String text = addressBox.method_1882();
        int cursorPosition = addressBox.method_1881();
        super.method_25410(minecraft, width, height);
        addressBox.method_1852(text);
        addressBox.method_1875(cursorPosition);
        suggestions.update();
    }

    protected void close() {
        method_25419();
    }

    // -- Render

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(0.0F, 0.0F, 200.0F);
        suggestions.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        guiGraphics.method_51448().method_22909();

        renderLabels(guiGraphics);
        renderAddressIcon(guiGraphics, mouseX, mouseY, partialTick);
        renderTargetPreview(guiGraphics, mouseX, mouseY);
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        method_52752(guiGraphics);
        guiGraphics.method_25302(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);
    }

    protected void renderLabels(@NotNull class_332 guiGraphics) {
        guiGraphics.method_51439(field_22793, field_22785, titleLabelX, titleLabelY, 0xFF3C3C3C, false);
    }

    protected void renderAddressIcon(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        Address address = getMatchedKnownAddress().orElse(Address.UNKNOWN);

        int color = !address.equals(Address.UNKNOWN) ? 0xFFFFEAC2 : 0x88FFEAC2;
        guiGraphics.method_51433(field_22793, AddressFormatter.getIcon(address), leftPos + 17, topPos + 21, color, true);

        if (address != Address.UNKNOWN && isHovering(15, 20, 9, 9, mouseX, mouseY)) {
            guiGraphics.method_51438(field_22793, address.type().translate(), mouseX, mouseY);
        }
    }

    protected void renderTargetPreview(@NotNull class_332 guiGraphics, int mouseX, int mouseY) {
        class_1799 target = getTargetPreview();
        if (target.method_7960()) {
            return;
        }

        float scale = 2f;
        int size = (int) (16 * scale);

        int x = leftPos - size - 4;
        int y = topPos + (imageHeight - size) / 2;

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(x + (float) size / 2, y + (float) size / 2, 0);
        guiGraphics.method_51448().method_22905(scale, scale, scale);
        guiGraphics.method_51448().method_46416(-8, -8, 0);
        guiGraphics.method_51427(target, 0, 0);
        guiGraphics.method_51448().method_22909();

        if (isHovering(x - leftPos, y - topPos, size, size, mouseX, mouseY)) {
            guiGraphics.method_51446(field_22793, target, mouseX, mouseY);
        }
    }

    // -- Input

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (suggestions.method_25404(keyCode, scanCode, modifiers)) {
            return true;
        }

        if (keyCode == class_3675.field_31958) {
            close();
            return true;
        }

        if (keyCode == class_3675.field_31957 || keyCode == class_3675.field_31980) {
            if (confirm()) {
                Minecrft.get().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1f));
            }
            return true;
        }

        if (keyCode == class_3675.field_31948 && currentSuggestion != null) {
            addressBox.method_1852(currentSuggestion);
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (suggestions.method_25402(mouseX, mouseY, button)) {
            return true;
        }

        if (button == class_3675.field_32002 && addressBox.method_25405(mouseX, mouseY)) {
            if (!addressBox.method_1882().isEmpty()) {
                addressBox.method_1852("");
            }
            return true;
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        suggestions.method_16014(mouseX, mouseY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (suggestions.method_25401(mouseX, mouseY, scrollX, scrollY)) {
            return true;
        }
        return super.method_25401(mouseX, mouseY, scrollX, scrollY);
    }

    // --

    @Override
    public boolean method_25421() {
        return false;
    }

    /**
     * Used by mixin to change EditBox suggestion color.
     */
    public int getSuggestionTextColor() {
        return 0x88FFFFFF;
    }

    protected boolean isHovering(int x, int y, int width, int height, int mouseX, int mouseY) {
        return mouseX >= leftPos + x && mouseX < leftPos + x + width
              && mouseY >= topPos + y && mouseY < topPos + y + height;
    }
}