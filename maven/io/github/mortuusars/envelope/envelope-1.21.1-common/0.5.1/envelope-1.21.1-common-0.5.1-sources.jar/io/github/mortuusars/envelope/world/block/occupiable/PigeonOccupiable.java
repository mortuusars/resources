package io.github.mortuusars.envelope.world.block.occupiable;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

public interface PigeonOccupiable extends Occupiable {
    @Override
    default boolean canBeOccupiedBy(class_1297 entity) {
        return entity.method_5864().method_20210(Envelope.Tags.EntityTypes.PIGEONHOLE_INHABITORS);
    }

    @Override
    default class_3414 getOccupantEnterSound(class_1297 entity) {
        return class_3417.field_20609;
    }

    @Override
    default class_3414 getOccupantExitSound(class_1297 entity) {
        return class_3417.field_20610;
    }

    @Override
    default class_3414 getOccupantWorkSound() {
        return Envelope.SoundEvents.PIGEON_AMBIENT.get();
    }

    @Override
    default int getMinimumTicksInsideForOccupant(class_1297 entity) {
        return Config.Server.PIGEON_MIN_TICKS_INSIDE_PIGEONHOLE.get();
    }

    @Override
    default String getSerializedOccupantsName() {
        return "pigeons";
    }

    @Override
    default void cleanupOccupantEntityTag(class_2487 tag) {
        Pigeon.IGNORED_TAGS.forEach(tag::method_10551);
    }
}
