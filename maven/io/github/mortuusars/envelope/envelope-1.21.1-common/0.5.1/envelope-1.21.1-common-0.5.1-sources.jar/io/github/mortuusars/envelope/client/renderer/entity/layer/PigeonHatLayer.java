package io.github.mortuusars.envelope.client.renderer.entity.layer;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.model.PigeonModel;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5599;
import net.minecraft.class_5601;

public class PigeonHatLayer extends class_3887<Pigeon, PigeonModel> {
    public static final class_5601 PIGEON_HAT = new class_5601(Envelope.resource("pigeon_hat"), "main");

    public static final class_2960 TEXTURE = Envelope.resource("textures/entity/pigeon/pigeon_hat.png");

    protected final PigeonModel model;

    public PigeonHatLayer(class_3883<Pigeon, PigeonModel> renderer, class_5599 modelSet) {
        super(renderer);
        model = new PigeonModel(modelSet.method_32072(PIGEON_HAT));
    }

    @Override
    public void render(class_4587 poseStack, class_4597 buffer, int packedLight, Pigeon pigeon, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!pigeon.method_6109() && pigeon.hasMailmanHat()) {
            method_23196(method_17165(), model,TEXTURE, poseStack, buffer, packedLight, pigeon,
                  limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, partialTick, -1);
        }
    }
}
