package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.PlatformHelper;
import io.github.mortuusars.envelope.world.inventory.PackingMenu;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_747;
import org.jetbrains.annotations.NotNull;

public class PackingBoxItem extends class_1792 implements PackingBox {
    public PackingBoxItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public boolean method_31568() {
        return false;
    }

    // --

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        class_1799 stack = player.method_5998(usedHand);
        openPackingGui(player, usedHand, stack);
        return class_1271.method_29237(stack, level.field_9236);
    }

    public boolean openPackingGui(class_1657 player, class_1268 hand, class_1799 stack) {
        if (player instanceof class_3222 serverPlayer) {
            PlatformHelper.openMenu(serverPlayer,
                  new class_747((id, inventory, pl) ->
                        new PackingMenu(id, inventory, hand), stack.method_7964()),
                  buffer -> buffer.method_10817(hand));
        }

        player.method_37908().method_43129(player, player, Envelope.SoundEvents.PAPER_USE.get(), class_3419.field_15248, 0.6f, 0.95f);
        return true;
    }
}
