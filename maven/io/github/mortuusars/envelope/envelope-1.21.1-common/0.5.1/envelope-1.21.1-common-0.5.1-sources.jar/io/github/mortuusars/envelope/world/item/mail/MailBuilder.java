package io.github.mortuusars.envelope.world.item.mail;

import com.google.common.base.Preconditions;
import io.github.mortuusars.envelope.world.item.component.Id;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryLog;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.mail.address.Address;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.UnaryOperator;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_9322;
import net.minecraft.class_9323;
import net.minecraft.class_9331;

public class MailBuilder<T extends MailBuilder<T>> implements class_9322 {
    private final @NotNull class_1799 item;

    public MailBuilder(@NotNull class_1799 item) {
        Preconditions.checkNotNull(item);
        this.item = item;
    }

    public MailBuilder(@NotNull class_1792 item) {
        Preconditions.checkNotNull(item);
        this.item = new class_1799(item);
    }

    @SuppressWarnings("unchecked")
    T self() {
        return (T) this;
    }

    public T id(Id id) {
        Mail.setId(item, id);
        return self();
    }

    public T sender(Address sender) {
        Mail.setSender(item, sender);
        return self();
    }

    public T recipient(Address recipient) {
        Mail.setRecipient(item, recipient);
        return self();
    }

    public T setLog(DeliveryLog log) {
        Mail.setLog(item, log);
        return self();
    }

    public T writeToLog(DeliveryRecord record) {
        Mail.writeToLog(item, record);
        return self();
    }

    public T writeToLog(DeliveryRecord.Builder record) {
        Mail.writeToLog(item, record);
        return self();
    }

    // --

    @Override
    public @NotNull class_9323 method_57353() {
        return item.method_57353();
    }

    public <V> T set(class_9331<V> type, @Nullable V value) {
        item.method_57379(type, value);
        return self();
    }

    public <V> T update(class_9331<V> type, V defaultValue, @NotNull UnaryOperator<V> updater) {
        item.method_57368(type, defaultValue, updater);
        return self();
    }

    // --

    public @NotNull class_1799 get() {
        return item;
    }
}