package io.github.mortuusars.envelope.world.mail.receiver;

import io.github.mortuusars.envelope.world.item.mail.Mail;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;

public interface MailReceiver {
    class_1799 receiveMail(class_3218 level, class_1799 mail);

    default class_1799 returned(class_1799 mail, class_2561 message) {
        Mail.writeToLog(mail, DeliveryRecord.returned(message));
        Mail.setReturned(mail);
        return mail;
    }
}