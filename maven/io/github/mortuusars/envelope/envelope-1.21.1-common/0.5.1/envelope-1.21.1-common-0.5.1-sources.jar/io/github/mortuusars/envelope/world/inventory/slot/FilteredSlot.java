package io.github.mortuusars.envelope.world.inventory.slot;

import java.util.function.Predicate;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class FilteredSlot extends class_1735 {
    private final Predicate<class_1799> filter;

    public FilteredSlot(class_1263 container, int slot, int x, int y, Predicate<class_1799> filter) {
        super(container, slot, x, y);
        this.filter = filter;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return filter.test(stack);
    }
}
