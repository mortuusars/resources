package io.github.mortuusars.envelope.mixin.fox_tatter;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.LetterItem;
import io.github.mortuusars.envelope.world.item.SealedLetterItem;
import net.minecraft.class_1799;
import net.minecraft.class_3902;
import net.minecraft.class_4019;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_4019.class)
public class FoxMixin {
    @ModifyVariable(method = "spitOutItem", at = @At("HEAD"), argsOnly = true)
    private class_1799 onSpitOutItem(class_1799 stack) {
        if (stack.method_7909() instanceof LetterItem || stack.method_7909() instanceof SealedLetterItem) {
            stack.method_57379(Envelope.DataComponents.LETTER_TATTERED, class_3902.field_17274);
        }
        return stack;
    }
}
