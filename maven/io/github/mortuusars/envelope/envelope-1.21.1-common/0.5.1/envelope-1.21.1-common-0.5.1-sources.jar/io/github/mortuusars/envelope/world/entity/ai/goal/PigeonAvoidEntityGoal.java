package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.world.entity.Pigeon;
import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1338;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_5493;
import net.minecraft.class_5530;
import net.minecraft.class_5535;

public class PigeonAvoidEntityGoal<T extends class_1309> extends class_1338<T> {
    private final Pigeon pigeon;

    public PigeonAvoidEntityGoal(Pigeon pigeon, Class<T> entityClassToAvoid, float maxDistance,
                                 double walkSpeedModifier, double sprintSpeedModifier) {
        super(pigeon, entityClassToAvoid, maxDistance, walkSpeedModifier, sprintSpeedModifier);
        this.pigeon = pigeon;
    }

    public PigeonAvoidEntityGoal(Pigeon pigeon, Class<T> entityClassToAvoid, Predicate<class_1309> avoidPredicate,
                                 float maxDistance, double walkSpeedModifier, double sprintSpeedModifier, Predicate<class_1309> predicateOnAvoidEntity) {
        super(pigeon, entityClassToAvoid, avoidPredicate, maxDistance, walkSpeedModifier, sprintSpeedModifier, predicateOnAvoidEntity);
        this.pigeon = pigeon;
    }

    public PigeonAvoidEntityGoal(Pigeon pigeon, Class<T> entityClassToAvoid, float maxDistance, double walkSpeedModifier,
                                 double sprintSpeedModifier, Predicate<class_1309> predicateOnAvoidEntity) {
        super(pigeon, entityClassToAvoid, maxDistance, walkSpeedModifier, sprintSpeedModifier, predicateOnAvoidEntity);
        this.pigeon = pigeon;
    }

    public boolean isAvoiding() {
        return field_6390 != null;
    }

    @Override
    public boolean method_6264() {
        if (!super.method_6264() && field_6390 != null) {
            class_243 pos = getPosAway(this.field_6391, 6, 3, this.field_6390.method_19538());
            if (pos == null) return false;
            if (this.field_6390.method_5649(pos.field_1352, pos.field_1351, pos.field_1350) < this.field_6390.method_5858(this.field_6391)) return false;
            if (pos.method_10214() < field_6391.method_23318()) return false;

            this.field_6387 = this.field_6394.method_6352(pos.field_1352, pos.field_1351, pos.field_1350, 0);
            return this.field_6387 != null;
        }

        return false;
    }

    @Nullable
    public static class_243 getPosAway(class_1314 mob, int radius, int yRange, class_243 vectorPosition) {
        class_243 awayVector = mob.method_19538().method_1020(vectorPosition);
        boolean isWithinRestriction = class_5493.method_31517(mob, radius);
        return class_5535.method_31538(mob, () -> {
            class_2338 blockPos = class_5530.method_31505(mob, radius, yRange, 3, awayVector.field_1352, awayVector.field_1350, 1, isWithinRestriction);
            return blockPos != null && !class_5493.method_31518(mob, blockPos) ? blockPos : null;
        });
    }
}