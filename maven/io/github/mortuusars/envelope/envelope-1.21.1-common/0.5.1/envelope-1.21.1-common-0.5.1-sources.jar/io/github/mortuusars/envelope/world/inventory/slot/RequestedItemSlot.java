package io.github.mortuusars.envelope.world.inventory.slot;

import io.github.mortuusars.envelope.world.inventory.RequestedItem;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_156;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class RequestedItemSlot extends class_1735 {
    private final RequestedItem requestedItem;
    private class_1799 preview = class_1799.field_8037;
    private long previewLastChange = 0;
    private int previewTagIndex = 0;

    public RequestedItemSlot(class_1263 container, int slot, int x, int y, RequestedItem requestedItem) {
        super(container, slot, x, y);
        this.requestedItem = requestedItem;
    }

    public RequestedItem getRequestedItem() {
        return requestedItem;
    }

    public class_1799 getRequestedItemPreview() {
        if (class_156.method_658() - previewLastChange > 1500) {
            class_1792 item = getRequestedItem().item().map(
                  tag -> {
                      List<class_1792> items = class_7923.field_41178.method_40266(tag)
                            .map(named -> named.method_40239()
                                  .map(class_6880::comp_349)
                                  .toList())
                            .orElse(List.of(class_1802.field_8077));

                      if (items.isEmpty()) {
                          items = List.of(class_1802.field_8077);
                      }

                      if (previewTagIndex >= items.size()) {
                          previewTagIndex = 0;
                      }

                      return items.get(previewTagIndex++);
                  },
                  class_6880::comp_349
            );

            previewLastChange = class_156.method_658();

            preview = new class_1799(item, requestedItem.count());
            preview.method_57366(requestedItem.components().method_57870());
        }

        return preview;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return requestedItem.typeMatches(stack) && requestedItem.componentsMatch(stack);
    }

    @Override
    public int method_7675() {
        return requestedItem.count();
    }
}
