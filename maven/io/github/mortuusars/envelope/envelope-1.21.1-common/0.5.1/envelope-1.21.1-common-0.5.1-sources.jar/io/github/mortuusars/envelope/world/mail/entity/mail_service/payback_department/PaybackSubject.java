package io.github.mortuusars.envelope.world.mail.entity.mail_service.payback_department;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.item.component.Id;
import io.github.mortuusars.envelope.world.mail.address.Address;
import net.minecraft.class_1799;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record PaybackSubject(Id id, class_1799 mail, Address returnAddress, long timeoutTick) {
    public static final Codec<PaybackSubject> CODEC = RecordCodecBuilder.create(i -> i.group(
          Id.CODEC.fieldOf("id").forGetter(PaybackSubject::id),
          class_1799.field_24671.fieldOf("mail").forGetter(PaybackSubject::mail),
          Address.CODEC.fieldOf("return_address").forGetter(PaybackSubject::returnAddress),
          Codec.LONG.fieldOf("timeout_tick").forGetter(PaybackSubject::timeoutTick)
    ).apply(i, PaybackSubject::new));

    public static final class_9139<class_9129, PaybackSubject> STREAM_CODEC = class_9139.method_56905(
          Id.STREAM_CODEC, PaybackSubject::id,
          class_1799.field_48349, PaybackSubject::mail,
          Address.STREAM_CODEC, PaybackSubject::returnAddress,
          class_9135.field_48551, PaybackSubject::timeoutTick,
          PaybackSubject::new
    );
}