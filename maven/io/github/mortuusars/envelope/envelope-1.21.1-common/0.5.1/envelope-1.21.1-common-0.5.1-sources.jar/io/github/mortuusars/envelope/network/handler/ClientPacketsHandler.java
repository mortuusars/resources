package io.github.mortuusars.envelope.network.handler;

import io.github.mortuusars.envelope.client.gui.screen.*;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.network.packet.clientbound.*;
import io.github.mortuusars.envelope.world.item.LetterAndQuillItem;
import io.github.mortuusars.envelope.world.item.AddressTagItem;
import io.github.mortuusars.envelope.world.item.LetterItem;
import io.github.mortuusars.envelope.world.item.MailboxBlockItem;
import net.minecraft.class_1799;
import net.minecraft.class_2561;

public class ClientPacketsHandler {
    public static void openLetterEditScreen(OpenLetterEditScreenS2CP packet) {
        class_1799 itemInHand = Minecrft.player().method_5998(packet.hand());
        if (itemInHand.method_7909() instanceof LetterAndQuillItem) {
            Minecrft.get().method_1507(new LetterEditScreen(itemInHand, packet.hand()));
        }
    }

    public static void openLetterViewScreen(OpenLetterViewScreenS2CP packet) {
        class_1799 itemInHand = Minecrft.player().method_5998(packet.hand());
        if (itemInHand.method_7909() instanceof LetterItem) {
            Minecrft.get().method_1507(new LetterViewScreen(itemInHand, packet.hand()));
        }
    }

    public static void openAddressTagScreen(OpenAddressTagScreenS2CP packet) {
        if (Minecrft.player().method_5998(packet.hand()).method_7909() instanceof AddressTagItem) {
            AddressTagScreen screen = new AddressTagScreen(packet.hand(), packet.knownAddresses(),
                  class_2561.method_43471("gui.envelope.address_tag.title"));
            Minecrft.get().method_1507(screen);
        }
    }

    public static void openMailboxPlacingScreen(OpenMailboxPlacingScreenS2CP packet) {
        if (Minecrft.player().method_5998(packet.hand()).method_7909() instanceof MailboxBlockItem) {
            MailboxPlacingScreen screen = new MailboxPlacingScreen(packet.hand(), packet.knownAddresses(),
                  packet.hitResult(), class_2561.method_43471("gui.envelope.mailbox_choose_address.title"));
            Minecrft.get().method_1507(screen);
        }
    }

    public static void openMailboxAddressTagScreen(OpenMailboxAddressTagScreenS2CP packet) {
        if (Minecrft.player().method_5998(packet.hand()).method_7909() instanceof AddressTagItem) {
            MailboxChangeAddressScreen screen = new MailboxChangeAddressScreen(packet.hand(),
                  packet.knownAddresses(), packet.pos(), packet.currentAddress(),
                  class_2561.method_43471("gui.envelope.mailbox_change_address.title"));
            Minecrft.get().method_1507(screen);
        }
    }
}