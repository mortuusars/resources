package io.github.mortuusars.envelope.client.gui.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.gui.Sprites;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.world.inventory.PackingMenu;
import io.github.mortuusars.envelope.world.inventory.PaybackPackingMenu;
import io.github.mortuusars.envelope.world.inventory.slot.DisabledSlot;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_465;
import net.minecraft.class_5244;
import net.minecraft.class_7919;
import net.minecraft.class_8666;

public class PackingScreen extends class_465<PackingMenu> {
    public static final class_2960 TEXTURE = Envelope.resource("textures/gui/packing.png");
    public static final class_8666 PACK_BUTTON_SPRITES = Sprites.threeStates(Envelope.resource("packing_box/pack_button"));

    protected class_344 packButton;

    public PackingScreen(PackingMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected void method_25426() {
        field_2792 = 176;
        field_2779 = 178;
        super.method_25426();
        field_25270 = field_2779 - 94;

        packButton = method_37063(new class_344(field_2776 + 126, field_2800 + 40, 26, 20,
              PACK_BUTTON_SPRITES,
              button -> pack(),
              class_2561.method_43471("gui.envelope.package.pack")));
        packButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.envelope.package.pack")
                .method_10852(class_5244.field_33849)
                .method_10852(class_2561.method_43469("gui.envelope.package.pack.tooltip.packs_remaining",
                        getPrettyPacksRemaining()))));
    }

    protected String getPrettyPacksRemaining() {
        int count = method_17577().getPackage().getRemainingPacks(method_17577().getBoxStack());
        if (count > 99) {
            return ">99";
        }
        return Integer.toString(count);
    }

    protected void pack() {
        method_17577().method_7604(method_17577().getPlayer(), PackingMenu.PACK_BUTTON_ID);
        Minecrft.gameMode().method_2900(method_17577().field_7763, PackingMenu.PACK_BUTTON_ID);
        method_25419();
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        method_2380(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        packButton.field_22764 = method_17577().needsPacking() && method_17577().canPack();
        guiGraphics.method_25302(TEXTURE, field_2776, field_2800, 0, 0, field_2792, field_2779);

        if (method_17577().isPackageDestroyedOnClose()) {
            guiGraphics.method_25302(TEXTURE, field_2776 + 45, field_2800 + 17, 0, 178, 86, 64);
        }
    }

    @Override
    protected void method_2385(class_332 guiGraphics, class_1735 slot) {
        super.method_2385(guiGraphics, slot);

        if (slot instanceof DisabledSlot) {
            guiGraphics.method_51448().method_22903();
            guiGraphics.method_51448().method_46416(0, 0, 300);
            RenderSystem.enableBlend();
            guiGraphics.method_25302(TEXTURE, slot.field_7873 - 1, slot.field_7872 - 1, 176, 0, 18, 18);
            RenderSystem.disableBlend();
            guiGraphics.method_51448().method_22909();
        }
    }
}
