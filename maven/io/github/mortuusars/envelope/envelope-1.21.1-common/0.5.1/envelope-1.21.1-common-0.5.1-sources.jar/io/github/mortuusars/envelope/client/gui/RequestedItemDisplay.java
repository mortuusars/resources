package io.github.mortuusars.envelope.client.gui;

import io.github.mortuusars.envelope.world.inventory.RequestedItem;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class RequestedItemDisplay {
    private final RequestedItem requestedItem;

    public RequestedItemDisplay(RequestedItem requestedItem) {
        this.requestedItem = requestedItem;
    }

    public class_1799 getDisplayedItem() {
        List<class_1792> items = requestedItem.items();
        int index = (int)(class_156.method_658() / 1000) % items.size();

        class_1792 item = items.get(index);
        class_1799 stack = new class_1799(item, requestedItem.count());
        stack.method_57366(requestedItem.components().method_57870());
        return stack;
    }
}
