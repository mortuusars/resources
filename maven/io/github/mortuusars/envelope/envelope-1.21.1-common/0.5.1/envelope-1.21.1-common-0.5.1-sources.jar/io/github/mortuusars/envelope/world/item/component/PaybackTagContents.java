package io.github.mortuusars.envelope.world.item.component;

import com.mojang.serialization.Codec;
import io.github.mortuusars.envelope.world.inventory.ContainerUtils;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_5632;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record PaybackTagContents(List<class_1799> items) implements class_5632 {
    public static final int SLOTS = RequestedPayback.SLOTS;

    public static final Codec<PaybackTagContents> CODEC = class_1799.field_49266.listOf(0, SLOTS)
          .xmap(PaybackTagContents::new, PaybackTagContents::getItemsForReading);

    public static final class_9139<class_9129, PaybackTagContents> STREAM_CODEC = class_1799.field_49268
          .method_56433(class_9135.method_58000(SLOTS))
          .method_56432(PaybackTagContents::new, PaybackTagContents::getItemsForReading);

    public static final PaybackTagContents EMPTY = new PaybackTagContents(Collections.emptyList());
    public static final PaybackTagContents DEFAULT = new PaybackTagContents(List.of(new class_1799(class_1802.field_8687)));

    public static PaybackTagContents create(class_1263 container) {
        class_1263 compactedContainer = ContainerUtils.compact(container, SLOTS);
        List<class_1799> items = ContainerUtils.toList(compactedContainer, SLOTS).stream().filter(i -> !i.method_7960()).toList();
        return new PaybackTagContents(items);
    }

    // --

    public int size() {
        return items.size();
    }

    public boolean isEmpty() {
        return this.equals(EMPTY) || items.isEmpty() || items.stream().allMatch(class_1799::method_7960);
    }

    public List<class_1799> getItemsForReading() {
        return items;
    }

    public class_1799 getItemForReading(int index) {
        return index < size() ? items.get(index) : class_1799.field_8037;
    }

    @SuppressWarnings("deprecation")
    public boolean equals(Object another) {
        return this == another ||
              (another instanceof PaybackTagContents contents
                    && class_1799.method_57362(this.items, contents.items));
    }

    @SuppressWarnings("deprecation")
    public int hashCode() {
        return class_1799.method_57361(this.items);
    }
}
