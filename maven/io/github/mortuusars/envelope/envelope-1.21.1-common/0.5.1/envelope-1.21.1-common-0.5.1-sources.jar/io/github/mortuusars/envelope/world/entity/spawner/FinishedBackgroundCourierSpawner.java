package io.github.mortuusars.envelope.world.entity.spawner;

import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.delivery.background.FinishedBackgroundCourier;
import io.github.mortuusars.envelope.world.delivery.background.BackgroundDelivery;
import io.github.mortuusars.envelope.world.service.MailService;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_156;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_5304;

public class FinishedBackgroundCourierSpawner implements class_5304 {
    protected static final int SPAWN_ATTEMPT_DELAY = 10;
    protected int nextAttemptDelay;

    @Override
    public int method_6445(class_3218 level, boolean spawnEnemies, boolean spawnFriendlies) {
        nextAttemptDelay--;
        if (nextAttemptDelay > 0) {
            return 0;
        }

        nextAttemptDelay = SPAWN_ATTEMPT_DELAY;

        BackgroundDelivery backgroundDelivery = MailService.of(level).getBackgroundDelivery();
        List<FinishedBackgroundCourier> couriers = backgroundDelivery.getFinishedCouriers();

        if (couriers.isEmpty()) {
            return 0;
        }

        FinishedBackgroundCourier courier = class_156.method_32309(couriers, level.method_8409());

        @Nullable class_2338 spawnPos = Position.findNearbyHeightmapSpawnPosition(level, courier.spawnPos(), 2);
        if (spawnPos == null) {
            return 0;
        }

        @Nullable class_1297 entity = courier.entityData().createEntity(level);
        if (entity == null) {
            return 0;
        }

        entity.method_5725(spawnPos, entity.method_36454(), entity.method_36455());
        level.method_30771(entity);

        if (!courier.undeliveredMail().method_7960()) {
            entity.method_5775(courier.undeliveredMail());
        }

        backgroundDelivery.removeFinishedCourier(courier);
        return 0;
    }
}