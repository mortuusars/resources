package io.github.mortuusars.envelope.network.packet;

import io.github.mortuusars.envelope.network.packet.serverbound.*;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class C2SPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
                 new class_8710.class_9155<>(MailboxMenuInboxActionC2SP.TYPE, MailboxMenuInboxActionC2SP.STREAM_CODEC),
                 new class_8710.class_9155<>(LetterEditC2SP.TYPE, LetterEditC2SP.STREAM_CODEC),
                 new class_8710.class_9155<>(LetterViewScreenClosedS2CP.TYPE, LetterViewScreenClosedS2CP.STREAM_CODEC),
                 new class_8710.class_9155<>(AddressTagApplyC2SP.TYPE, AddressTagApplyC2SP.STREAM_CODEC),
                 new class_8710.class_9155<>(MailboxPlaceC2SP.TYPE, MailboxPlaceC2SP.STREAM_CODEC),
                 new class_8710.class_9155<>(MailboxAddressTagApplyC2SP.TYPE, MailboxAddressTagApplyC2SP.STREAM_CODEC)
        );
    }
}