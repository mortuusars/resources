package io.github.mortuusars.envelope.util.bugger.test.cases;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.bugger.test.BuggerTests;
import io.github.mortuusars.envelope.util.bugger.test.Test;
import io.github.mortuusars.envelope.world.inventory.RequestedItem;
import io.github.mortuusars.envelope.world.mail.address.Address;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3489;
import net.minecraft.class_3518;
import net.minecraft.class_3902;
import net.minecraft.class_9329;
import net.minecraft.server.MinecraftServer;

public class RequestedItemTests extends BuggerTests {
    private final MinecraftServer server;

    public RequestedItemTests(MinecraftServer server) {
        this.server = server;
        itemMatching();
        tagMatching();
        componentMatching();
        matchingItemFromJson();
        matchingTagFromJson();
        matchingItemWithComponentsFromJson();
    }

    private void itemMatching() {
        RequestedItem requestedItem = new RequestedItem(class_1802.field_8153, 3);

        add("RequestedItem_simpleMatching", Test.isTrue(() -> requestedItem.matches(new class_1799(class_1802.field_8153, 3))));
        add("RequestedItem_simpleMatching_failsWhenItemIsDifferent", Test.isFalse(() -> requestedItem.matches(new class_1799(class_1802.field_8360, 3))));
        add("RequestedItem_simpleMatching_failsWhenCountIsLesser", Test.isFalse(() -> requestedItem.matches(new class_1799(class_1802.field_8153, 1))));
        add("RequestedItem_simpleMatching_failsWhenMoreThanCount", Test.isFalse(() -> requestedItem.matches(new class_1799(class_1802.field_8153, 5))));

        class_1799 stack = new class_1799(class_1802.field_8153, 3);
        stack.method_57379(Envelope.DataComponents.LETTER_TATTERED, class_3902.field_17274);
        stack.method_57379(Envelope.DataComponents.PACKAGE_TIMES_PACKED, 5);
        add("RequestedItem_simpleMatching_withRandomComponents", Test.isTrue(() -> requestedItem.matches(stack)));
    }

    private void tagMatching() {
        RequestedItem requestedItem = new RequestedItem(class_3489.field_15539, 12);

        add("RequestedItem_simpleMatching", Test.isTrue(() -> requestedItem.matches(new class_1799(class_1802.field_8583, 12))));
        add("RequestedItem_simpleMatching_failsWhenItemIsDifferent", Test.isFalse(() -> requestedItem.matches(new class_1799(class_1802.field_8360, 20))));
        add("RequestedItem_simpleMatching_failsWhenCountIsLesser", Test.isFalse(() -> requestedItem.matches(new class_1799(class_1802.field_8583, 5))));
        add("RequestedItem_simpleMatching_failsWhenMoreThanCount", Test.isFalse(() -> requestedItem.matches(new class_1799(class_1802.field_8583, 30))));

        class_1799 stack = new class_1799(class_1802.field_8583, 12);
        stack.method_57379(Envelope.DataComponents.LETTER_TATTERED, class_3902.field_17274);
        stack.method_57379(Envelope.DataComponents.PACKAGE_TIMES_PACKED, 5);
        add("RequestedItem_simpleMatching_withRandomComponents", Test.isTrue(() -> requestedItem.matches(stack)));
    }

    private void componentMatching() {
        RequestedItem requestedItem = new RequestedItem(class_1802.field_8153, 3, class_9329.method_57862()
              .method_57872(Envelope.DataComponents.MAIL_SENDER, Address.MAIL_SERVICE)
              .method_57872(Envelope.DataComponents.LETTER_TATTERED, class_3902.field_17274)
              .method_57872(Envelope.DataComponents.PACKAGE_TIMES_PACKED, 5)
              .method_57871());

        class_1799 stack = new class_1799(class_1802.field_8153, 3);
        stack.method_57379(Envelope.DataComponents.MAIL_SENDER, Address.MAIL_SERVICE);
        stack.method_57379(Envelope.DataComponents.LETTER_TATTERED, class_3902.field_17274);
        stack.method_57379(Envelope.DataComponents.PACKAGE_TIMES_PACKED, 5);
        add("RequestedItem_componentMatching", Test.isTrue(() -> requestedItem.matches(stack)));

        class_1799 stack2 = stack.method_7972();
        stack2.method_57381(Envelope.DataComponents.MAIL_SENDER);
        add("RequestedItem_componentMatching_failsWhenMissing", Test.isFalse(() -> requestedItem.matches(stack2)));
    }

    private void matchingItemFromJson() {
        add("RequestedItem_matchingItemFromJson_simple",
              Test.isTrue(() -> decodeFromJson("{\"item\":\"minecraft:emerald\"}").matches(new class_1799(class_1802.field_8687))));
        add("RequestedItem_matchingItemFromJson_failsWhenCountIsLesser",
              Test.isFalse(() -> decodeFromJson("{\"item\":\"minecraft:emerald\",\"count\":5}").matches(new class_1799(class_1802.field_8687))));
    }

    private void matchingItemWithComponentsFromJson() {
        String json = """
              {
                "item": "minecraft:emerald",
                "count": 3,
                "components": {
                  "envelope:letter_tattered": {},
                  "envelope:mail_sender": {
                      "type": "entity",
                      "id": "Mail Service"
                  },
                  "envelope:mail_recipient": {
                      "type": "block",
                      "id": "Mortuusars Laboratory"
                  }
                }
              }
              """;
        add("RequestedItem_matchingItemWithComponentsFromJson_simple",
              Test.isTrue(() -> {
                  class_1799 stack = new class_1799(class_1802.field_8687, 3);
                  stack.method_57379(Envelope.DataComponents.LETTER_TATTERED, class_3902.field_17274);
                  stack.method_57379(Envelope.DataComponents.MAIL_SENDER, Address.MAIL_SERVICE);
                  stack.method_57379(Envelope.DataComponents.MAIL_RECIPIENT, new Address.Block("Mortuusars Laboratory"));
                  return decodeFromJson(json).matches(stack);
              }));
    }

    private void matchingTagFromJson() {
        add("RequestedItem_matchingTagFromJson_simple",
              Test.isTrue(() -> decodeFromJson("{\"item\":\"#minecraft:planks\"}").matches(new class_1799(class_1802.field_8191))));
        add("RequestedItem_matchingTagFromJson_failsWhenCountIsLesser",
              Test.isFalse(() -> decodeFromJson("{\"item\":\"#minecraft:planks\",\"count\":5}").matches(new class_1799(class_1802.field_8191))));
    }

    private static RequestedItem decodeFromJson(String json) {
        JsonObject obj = class_3518.method_15285(json);
        return RequestedItem.CODEC.parse(JsonOps.INSTANCE, obj).getOrThrow();
    }
}
