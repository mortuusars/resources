package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.world.inventory.tooltip.SealDieTooltipComponent;
import io.github.mortuusars.envelope.world.item.component.seal.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_5244;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5536;
import net.minecraft.class_5632;
import net.minecraft.class_6880;

public class SealStampItem extends class_1792 implements ApplicatorItem {
    public SealStampItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        if (tooltipFlag.method_8035()) {
            //TODO: Something is wrong with getting impressions here. Server is crashing due to client class loading.
            // Maybe use context.registries() here? Or just extract into inner class.
            class_2960 texture = getImpressionOrDefault(stack, Minecrft.registryAccess(), null).comp_349().textureId();
            tooltipComponents.add(class_2561.method_43470("Impression:").method_27692(class_124.field_1063)
                  .method_10852(class_5244.field_41874)
                  .method_10852(class_2561.method_43470(texture.toString()).method_27692(class_124.field_1080)));
        }
    }

    @Override
    public @NotNull Optional<class_5632> method_32346(class_1799 stack) {
        return Optional.of(new SealDieTooltipComponent(Optional.ofNullable(stack.method_57824(Envelope.DataComponents.SEAL_STAMP_IMPRESSION))));
    }

    @Override
    public boolean shouldRenderTooltipWhileCarrying(class_1937 level, class_1799 carried, class_1799 hovered) {
        return hovered.method_57826(Envelope.DataComponents.SEAL)
              || (hovered.method_7909() instanceof Sealable sealable && sealable.canSeal(level, hovered));
    }

    @Override
    public boolean method_31565(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player) {
        if (action != class_5536.field_27014) {
            return false;
        }

        if (!slot.method_32754(player)) {
            player.method_43077(class_3417.field_14762);
            return true;
        }

        class_1799 target = slot.method_7677();

        @Nullable Seal existingSeal = target.method_57824(Envelope.DataComponents.SEAL);
        if (existingSeal != null && canApplyGold(stack, player)) {
            class_5321<SealMaterial> currentMaterial = existingSeal.material().method_40230().orElse(SealMaterial.RED_WAX);
            class_5321<SealMaterial> newMaterial = currentMaterial == SealMaterial.RED_WAX ? SealMaterial.GOLD : SealMaterial.RED_WAX;

            class_6880<SealMaterial> material = SealMaterial.getHolder(player.method_56673(), newMaterial);

            target.method_57379(Envelope.DataComponents.SEAL, new Seal(material, existingSeal.impression(), existingSeal.signature()));
            slot.method_7673(target);
            player.method_43077(class_3417.field_14920);
            return true;
        }

        if (!(target.method_7909() instanceof Sealable sealable) || !sealable.canSeal(player.method_37908(), target)) {
            player.method_43077(class_3417.field_14762);
            return true;
        }

        class_1799 sealResult = sealable.seal(player.method_37908(), target, createSeal(stack, player));
        slot.method_7673(sealResult);
        player.method_43077(class_3417.field_14920);
        //TODO: sealed stat

        return true;
    }

    public Seal createSeal(class_1799 stack, class_1657 player) {
        return new Seal(
              SealMaterial.getHolder(player.method_56673(), SealMaterial.RED_WAX),
              getImpressionOrDefault(stack, player.method_56673(), player),
              player.method_5477());
    }

    public Optional<class_6880<SealImpression>> getImpression(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.SEAL_STAMP_IMPRESSION));
    }

    public class_6880<SealImpression> getImpressionOrDefault(class_1799 stack, class_5455 registryAccess, @Nullable class_1657 player) {
        return getImpression(stack).orElseGet(() ->
              SealImpression.getHolder(registryAccess, SealImpression.firstCharOrDefault(player)));
    }

    protected boolean canApplyGold(class_1799 stack, class_1657 player) {
        //TODO: patreon supporters
        return false;
    }
}