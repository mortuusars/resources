package io.github.mortuusars.envelope.client.gui.screen;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlockEntity;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryLog;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.client.gui.Sprites;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.serverbound.MailboxMenuInboxActionC2SP;
import io.github.mortuusars.envelope.world.inventory.MailboxMenu;
import io.github.mortuusars.envelope.world.mail.address.AddressFormatter;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_344;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_768;
import net.minecraft.class_7919;
import net.minecraft.class_8666;

public class MailboxScreen extends class_465<MailboxMenu> {
    public static final class_2960 TEXTURE = Envelope.resource("textures/gui/mailbox.png");

    public static final class_8666 ADDRESS_BUTTON_SPRITES = Sprites.normalAndHighlighted(Envelope.resource("mailbox/address_button"));
    public static final class_8666 ADDRESS_ATTENTION_BUTTON_SPRITES = Sprites.normalAndHighlighted(Envelope.resource("mailbox/address_attention_button"), Envelope.resource("mailbox/address_button_highlighted"));
    public static final class_8666 ADDRESS_DEFAULT_BUTTON_SPRITES = Sprites.normalAndHighlighted(Envelope.resource("mailbox/address_default_button"));

    public static final class_8666 REGULAR_MAIL_BUTTON_SPRITES = Sprites.threeStates(Envelope.resource("mailbox/mail_button"));

    public static final class_8666 ICON_ADDRESS_BLOCK_SPRITES = Sprites.normalAndHighlighted(Envelope.resource("mailbox/icon_block"));
    public static final class_8666 ICON_ADDRESS_PLAYER_SPRITES = Sprites.normalAndHighlighted(Envelope.resource("mailbox/icon_player"));
    public static final class_8666 ICON_ADDRESS_ENTITY_SPRITES = Sprites.normalAndHighlighted(Envelope.resource("mailbox/icon_entity"));
    public static final class_8666 ICON_ADDRESS_MAIL_SERVICE_SPRITES = Sprites.normalAndHighlighted(Envelope.resource("mailbox/icon_mail_service"));
    public static final class_8666 ICON_ADDRESS_UNKNOWN_SPRITES = Sprites.normalAndHighlighted(Envelope.resource("mailbox/icon_unknown"));
    public static final class_8666 ICON_RETURNED_SPRITES = Sprites.normalAndHighlighted(Envelope.resource("mailbox/icon_returned"));
    public static final class_8666 ICON_REJECTED_SPRITES = Sprites.normalAndHighlighted(Envelope.resource("mailbox/icon_rejected"));
    public static final class_8666 ICON_UNCLAIMED_SPRITES = Sprites.normalAndHighlighted(Envelope.resource("mailbox/icon_unclaimed"));

    public static final class_8666 NEW_MAIL_INDICATOR_SPRITES = Sprites.normalOnly(Envelope.resource("mailbox/new_mail_indicator"));

    protected static final int SCROLL_THUMB_TOP_HEIGHT = 3;
    protected static final int SCROLL_THUMB_MID_HEIGHT = 2;
    protected static final int SCROLL_THUMB_BOT_HEIGHT = 2;
    protected static final int SCROLL_THUMB_Y_OFFSET = SCROLL_THUMB_TOP_HEIGHT + SCROLL_THUMB_MID_HEIGHT + SCROLL_THUMB_BOT_HEIGHT;

    protected static final int MAX_INBOX_MAIL_BUTTONS = 8;

    protected class_2561 inboxLabel = class_2561.method_43471("gui.envelope.mailbox.inbox");
    protected class_2561 sendLabel = class_2561.method_43471("gui.envelope.mailbox.send");

    @Nullable
    protected class_1799 hoveredMail;

    protected class_344 addressButton;
    protected class_344 addressAttentionButton;
    protected class_344 addressDefaultButton;
    protected class_344 newMailButton;

    protected class_768 mailArea = new class_768(0, 0, 0, 0);
    protected class_768 scrollBarArea = new class_768(0, 0, 0, 0);
    protected class_768 scrollThumb = new class_768(0, 0, 0, 0);
    protected int scroll = 0;
    protected int scrollAtDragStart = 0;
    protected boolean isDraggingScrollbar = false;
    protected double dragDelta = 0;

    public MailboxScreen(MailboxMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
    }

    // --

    @Override
    protected void method_25426() {
        field_2792 = 308;
        field_2779 = 170;
        field_25267 = Math.max(17, (field_2792 / 2) - (field_22793.method_27525(field_22785) / 2) + 5);
        field_25268 = -10;
        field_25269 = 140;
        field_25270 = field_2779 - 94;
        super.method_25426();
        mailArea = new class_768(field_2776 + 8, field_2800 + 18, 117, 144);
        scrollBarArea = new class_768(field_2776 + 128, field_2800 + 18, 6, 144);

        addressButton = new class_344(field_2776 + field_25267 - 11, field_2800 - 11, 10, 10,
              ADDRESS_BUTTON_SPRITES,
              button -> setAsDefaultAddress(),
              class_2561.method_43471("gui.envelope.mailbox.address"));
        addressButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.envelope.mailbox.address")
              .method_27693("\n")
              .method_10852(class_2561.method_43471("gui.envelope.mailbox.address.tooltip"))));
        method_37063(addressButton);

        addressAttentionButton = new class_344(field_2776 + field_25267 - 11, field_2800 - 11, 10, 10,
              ADDRESS_ATTENTION_BUTTON_SPRITES,
              button -> setAsDefaultAddress(),
              class_2561.method_43471("gui.envelope.mailbox.address"));
        addressAttentionButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.envelope.mailbox.address")
              .method_27693("\n")
              .method_10852(class_2561.method_43471("gui.envelope.mailbox.address.tooltip"))));
        method_37063(addressAttentionButton);

        addressDefaultButton = new class_344(field_2776 + field_25267 - 11, field_2800 - 11, 10, 10, ADDRESS_DEFAULT_BUTTON_SPRITES, btn -> {
        });
        addressDefaultButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.envelope.mailbox.address.default")
              .method_27693("\n")
              .method_10852(class_2561.method_43471("gui.envelope.mailbox.address.default.tooltip"))));
        addressDefaultButton.field_22763 = false;
        method_37063(addressDefaultButton);

        newMailButton = new class_344(field_2776 + 7, field_2800 + 6, 8, 8,
              NEW_MAIL_INDICATOR_SPRITES,
              button -> {
                  refreshMail();
                  scrollTo(0);
              });
        newMailButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.envelope.mailbox.mail.tooltip.new_mail")
              .method_27693("\n")
              .method_10852(class_2561.method_43471("gui.envelope.mailbox.mail.tooltip.new_mail.click_to_refresh"))));
        method_37063(newMailButton);

        updateButtons();
    }

    protected void setAsDefaultAddress() {
        Minecrft.gameMode().method_2900(method_17577().field_7763, MailboxMenu.ADDRESS_BUTTON_ID);
    }

    protected void refreshMail() {
        Minecrft.gameMode().method_2900(method_17577().field_7763, MailboxMenu.REFRESH_MAIL_BUTTON_ID);
    }

    protected void updateScrollThumb() {
        int minSize = SCROLL_THUMB_TOP_HEIGHT + SCROLL_THUMB_MID_HEIGHT + SCROLL_THUMB_BOT_HEIGHT;

        int totalButtons = method_17577().getMail().size();
        float ratio = MAX_INBOX_MAIL_BUTTONS / (float) Math.max(totalButtons, 1);
        int size = class_3532.method_15340(class_3532.method_15386(scrollBarArea.method_3320() * ratio), minSize, scrollBarArea.method_3320());
        int midSize = size - SCROLL_THUMB_TOP_HEIGHT - SCROLL_THUMB_BOT_HEIGHT;
        int correctedMidSize = Math.max(midSize - (midSize % SCROLL_THUMB_MID_HEIGHT), SCROLL_THUMB_MID_HEIGHT);
        size = SCROLL_THUMB_TOP_HEIGHT + correctedMidSize + SCROLL_THUMB_BOT_HEIGHT;

        float topRowPos = (float) scroll / Math.max(1, totalButtons - MAX_INBOX_MAIL_BUTTONS);
        int pos = (int) class_3532.method_37959(topRowPos, 0f, 1f, 0f, scrollBarArea.method_3320() - size);

        scrollThumb = new class_768(scrollBarArea.method_3321(), scrollBarArea.method_3322() + pos, scrollBarArea.method_3319(), size);
    }

    protected void updateButtons() {
        addressButton.field_22764 = !method_17577().isDefaultAddress() && method_17577().hasDefaultAddress();
        addressAttentionButton.field_22764 = !method_17577().hasDefaultAddress();
        addressDefaultButton.field_22764 = method_17577().isDefaultAddress();
        newMailButton.field_22764 = method_17577().hasNewMail();
    }

    // --

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        method_2380(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void method_2385(class_332 guiGraphics, class_1735 slot) {
        super.method_2385(guiGraphics, slot);

        // Extend slot highlight for mail slot to cover whole rectangle (mail slot is slightly bigger):

        int mouseX = (int) (Minecrft.get().field_1729.method_1603()
              * (double) Minecrft.get().method_22683().method_4486()
              / (double) Minecrft.get().method_22683().method_4480());
        int mouseY = (int) (Minecrft.get().field_1729.method_1604()
              * (double) Minecrft.get().method_22683().method_4502()
              / (double) Minecrft.get().method_22683().method_4507());

        if (slot.method_7682() && slot.method_34266() == MailboxBlockEntity.SLOT_MAIL
              && method_2378(slot.field_7873, slot.field_7872, 16, 16, mouseX, mouseY)) {
            guiGraphics.method_51740(class_1921.method_51785(), slot.field_7873 - 1, slot.field_7872 - 1,
                  slot.field_7873 + 17, slot.field_7872, 0x80FFFFFF, 0x80FFFFFF, 0);
            guiGraphics.method_51740(class_1921.method_51785(), slot.field_7873 - 1, slot.field_7872,
                  slot.field_7873, slot.field_7872 + 16, 0x80FFFFFF, 0x80FFFFFF, 0);
            guiGraphics.method_51740(class_1921.method_51785(), slot.field_7873 + 16, slot.field_7872,
                  slot.field_7873 + 17, slot.field_7872 + 16, 0x80FFFFFF, 0x80FFFFFF, 0);
            guiGraphics.method_51740(class_1921.method_51785(), slot.field_7873 - 1, slot.field_7872 + 16,
                  slot.field_7873 + 17, slot.field_7872 + 17, 0x80FFFFFF, 0x80FFFFFF, 0);
        }
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        hoveredMail = null;

        guiGraphics.method_25290(TEXTURE, field_2776, field_2800, 0, 0, field_2792, field_2779, 512, 256);

        int addressBarX = field_25267 - 18;
        int addressBarWidth = field_2792 - (addressBarX * 2);
        // Left
        guiGraphics.method_25290(TEXTURE, field_2776 + addressBarX, field_2800 - 15, 0, field_2779, 5, 15, 512, 256);
        // Middle
        guiGraphics.method_25290(TEXTURE, field_2776 + addressBarX + 5, field_2800 - 15, 5, field_2779, addressBarWidth - 10, 15, 512, 256);
        // Right
        guiGraphics.method_25290(TEXTURE, field_2776 + addressBarX + addressBarWidth - 5, field_2800 - 15, 303, field_2779, 5, 15, 512, 256);

        List<class_1799> mail = method_17577().getMail();

        if (!mail.isEmpty()) {
            scroll = Math.clamp(scroll, 0, Math.max(0, mail.size() - MAX_INBOX_MAIL_BUTTONS));

            for (int i = 0; i < Math.min(mail.size(), MAX_INBOX_MAIL_BUTTONS); i++) {
                int index = i + scroll;

                class_1799 item = mail.get(index);
                int x = 8;
                int y = 18 + 18 * i;
                boolean isHovering = method_2378(x + 1, y + 1, 115, 16, mouseX, mouseY);
                if (isHovering) {
                    hoveredMail = item;
                }
                renderMailButton(guiGraphics, partialTick, mouseX, mouseY, item, field_2776 + x, field_2800 + y);
            }
        } else if (this.hashCode() % 20 == 0) {
            // Sad face
            guiGraphics.method_25290(TEXTURE, field_2776 + 59, field_2800 + 92, 348, 0, 17, 9, 512, 256);
        }

        class_1735 foodSlot = method_17577().method_7611(MailboxBlockEntity.SLOT_FOOD);
        if (!foodSlot.method_7681()) {
            guiGraphics.method_25290(TEXTURE, field_2776 + foodSlot.field_7873, field_2800 + foodSlot.field_7872, 314, 0, 16, 16, 512, 256);
        }
        class_1735 mailSlot = method_17577().method_7611(MailboxBlockEntity.SLOT_MAIL);
        if (!mailSlot.method_7681()) {
            guiGraphics.method_25290(TEXTURE, field_2776 + mailSlot.field_7873 - 1, field_2800 + mailSlot.field_7872 - 1, 330, 0, 18, 18, 512, 256);
        }

        renderScrollBar(guiGraphics, partialTick, mouseX, mouseY);
    }

    @Override
    protected void method_2388(class_332 guiGraphics, int mouseX, int mouseY) {
        guiGraphics.method_51439(field_22793, field_22785, field_25267, field_25268, 0x404040, false);

        int inboxLabelX = 68 - field_22793.method_27525(inboxLabel) / 2;
        guiGraphics.method_51439(field_22793, inboxLabel, inboxLabelX, 6, 0x404040, false);

        if (method_17577().getMail().isEmpty()) {
            class_2561 empty = class_2561.method_43471("gui.envelope.mailbox.empty");
            int emptyLabelX = 68 - field_22793.method_27525(empty) / 2;
            guiGraphics.method_51439(field_22793, empty, emptyLabelX, 80, 0x606060, false);
        }

        int sendLabelX = 220 - field_22793.method_27525(sendLabel) / 2;
        guiGraphics.method_51439(field_22793, sendLabel, sendLabelX, 6, 0x404040, false);

        guiGraphics.method_51439(field_22793, field_29347, field_25269, field_25270, 0x404040, false);
    }

    protected void renderMailButton(class_332 guiGraphics, float partialTick, int mouseX, int mouseY, class_1799 mail, int x, int y) {
        boolean isHovered = hoveredMail == mail;

        guiGraphics.method_52707(REGULAR_MAIL_BUTTON_SPRITES.method_52729(true, isHovered), x, y, 0, 117, 18);

        guiGraphics.method_51427(mail, x + 2, y + 1);

        class_8666 iconSprites = getDisplayedIcon(mail);
        class_2960 iconSprite = isHovered ? iconSprites.comp_1606() : iconSprites.comp_1604();
        guiGraphics.method_52707(iconSprite, x + 23, y + 4, 0, 10, 10);

        String sender = getDisplayedSender(mail).getName().getString();
        if (field_22793.method_1727(sender) > 76) {
            sender = field_22793.method_27523(sender, 72) + "...";
        }
        guiGraphics.method_51433(field_22793, sender, x + 36, y + 5, 0xFF886447, false);
    }

    protected void renderScrollBar(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        updateScrollThumb();

        int state = 0;
        if (!canScroll()) {
            state = 2;
        } else if (isDraggingScrollbar || isMouseOver(scrollThumb, mouseX, mouseY)) {
            state = 1;
        }

        // Top
        guiGraphics.method_25290(TEXTURE, scrollThumb.method_3321(), scrollThumb.method_3322(),
              308, state * SCROLL_THUMB_Y_OFFSET, scrollThumb.method_3319(), SCROLL_THUMB_TOP_HEIGHT, 512, 256);

        // Middle
        int middlePartsCount = (scrollThumb.method_3320() - SCROLL_THUMB_TOP_HEIGHT - SCROLL_THUMB_BOT_HEIGHT) / SCROLL_THUMB_MID_HEIGHT;

        for (int i = 0; i < middlePartsCount; i++) {
            guiGraphics.method_25290(TEXTURE, scrollThumb.method_3321(),
                  scrollThumb.method_3322() + SCROLL_THUMB_TOP_HEIGHT + i * SCROLL_THUMB_MID_HEIGHT,
                  308, state * SCROLL_THUMB_Y_OFFSET + SCROLL_THUMB_TOP_HEIGHT,
                  scrollThumb.method_3319(), SCROLL_THUMB_MID_HEIGHT, 512, 256);
        }

        // Bottom
        guiGraphics.method_25290(TEXTURE, scrollThumb.method_3321(), scrollThumb.method_3322() + SCROLL_THUMB_TOP_HEIGHT + (middlePartsCount * SCROLL_THUMB_MID_HEIGHT),
              308, SCROLL_THUMB_TOP_HEIGHT + SCROLL_THUMB_MID_HEIGHT + state * SCROLL_THUMB_Y_OFFSET,
              scrollThumb.method_3319(), SCROLL_THUMB_BOT_HEIGHT, 512, 256);

        if (!canScroll()) {
            // Special case to make scroll thumb fill remaining gap in the bottom
            guiGraphics.method_25290(TEXTURE, scrollThumb.method_3321(), scrollThumb.method_3322() + SCROLL_THUMB_TOP_HEIGHT + (middlePartsCount * SCROLL_THUMB_MID_HEIGHT) + 1,
                  308, SCROLL_THUMB_TOP_HEIGHT + SCROLL_THUMB_MID_HEIGHT + state * SCROLL_THUMB_Y_OFFSET,
                  scrollThumb.method_3319(), SCROLL_THUMB_BOT_HEIGHT, 512, 256);
        }
    }

    @Override
    protected void method_2380(class_332 guiGraphics, int x, int y) {
        super.method_2380(guiGraphics, x, y);

        if (hoveredMail != null) {
            renderMailTooltip(guiGraphics, x, y, hoveredMail);
        }
    }

    protected void renderMailTooltip(class_332 guiGraphics, int x, int y, class_1799 hoveredMail) {
        if (x >= field_2776 + 8 && x < field_2776 + 28) {
            guiGraphics.method_51437(field_22793, method_51454(hoveredMail), hoveredMail.method_32347(), x, y);
            return;
        }

        if (x >= field_2776 + 31 && x < field_2776 + 41) {
            guiGraphics.method_51438(field_22793, getDisplayedIconName(hoveredMail), x, y);
            return;
        }

        List<class_2561> tooltip = new ArrayList<>();

        // Show full sender address if it doesn't fit on the widget
        Address sender = getDisplayedSender(hoveredMail);
        if (field_22793.method_1727(sender.toString()) > 76) {
            tooltip.add(AddressFormatter.of(sender)
                  .withIcon()
                  .withIconColor(AddressFormatter.NEUTRAL_COLOR)
                  .withColor(class_124.field_1068)
                  .toComponent());
        }

        DeliveryLog deliveryLog = Mail.getLog(hoveredMail);
        if (!deliveryLog.isEmpty()) {
            tooltip.add(class_2561.method_43471("gui.envelope.delivery_log"));
            for (DeliveryRecord record : deliveryLog.records()) {
                tooltip.add(record.toComponent(Minecrft.level().method_8510()));
            }
        }

        if (!tooltip.isEmpty()) {
            guiGraphics.method_51437(field_22793, tooltip, Optional.empty(), x, y);
        }
    }

    // -- Scroll

    public boolean canScroll() {
        return method_17577().getMail().size() > MAX_INBOX_MAIL_BUTTONS;
    }

    public void scroll(int amount) {
        scrollTo(scroll + amount);
    }

    public void scrollTo(int buttonIndex) {
        int maxScrollWhenAtEnd = Math.max(0, method_17577().getMail().size() - MAX_INBOX_MAIL_BUTTONS);
        scroll = class_3532.method_15340(buttonIndex, 0, maxScrollWhenAtEnd);
    }

    // -- Input


    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == class_3675.field_31989) {
            scroll(Integer.MIN_VALUE);
            return true;
        }
        if (keyCode == class_3675.field_31988) {
            scroll(Integer.MAX_VALUE);
            return true;
        }
        if (keyCode == class_3675.field_31932) {
            scroll(-1);
            return true;
        }
        if (keyCode == class_3675.field_31982) {
            scroll(1);
            return true;
        }


        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == class_3675.field_32000 && hoveredMail != null) {
            int index = method_17577().getMail().indexOf(hoveredMail);
            if (index == -1) return false;

            MailboxMenu.MailAction action = MailboxMenu.MailAction.PICK_UP;
            if (class_437.method_25442()) {
                if (class_437.method_25441()) {
                    action = MailboxMenu.MailAction.MOVE_ALL_TO_INVENTORY;
                } else {
                    action = MailboxMenu.MailAction.MOVE_TO_INVENTORY;
                }
            }

            if (method_17577().doMailAction(Minecrft.player(), index, action)) {
                Minecrft.player().method_5783(class_3417.field_14883.comp_349(), 1, 1);
                Packets.sendToServer(new MailboxMenuInboxActionC2SP(index, action));
            }
        }

        if (canScroll()) {
            if (isMouseOver(scrollThumb, mouseX, mouseY)) {
                method_25398(true);
                isDraggingScrollbar = true;
                dragDelta = 0;
                scrollAtDragStart = scroll;
                return true;
            } else if (isMouseOver(scrollBarArea, mouseX, mouseY)) {
                int direction = mouseY < scrollThumb.method_3322() ? -1 : 1;
                scroll(MAX_INBOX_MAIL_BUTTONS * direction);
                return true;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        isDraggingScrollbar = false;
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (!isDraggingScrollbar || button != class_3675.field_32000) {
            return super.method_25403(mouseX, mouseY, button, dragX, dragY);
        }

        dragDelta += dragY;

        double threshold = (double) scrollBarArea.method_3320() / Math.max(method_17577().getMail().size(), 1);
        int amount = (int) (dragDelta / threshold);
        if (amount != 0 || scroll != scrollAtDragStart) {
            scrollTo(scrollAtDragStart + amount);
        }

        return true;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (isMouseOver(mailArea, mouseX, mouseY) || isMouseOver(scrollBarArea, mouseX, mouseY)) {
            scroll((int) -scrollY);
            return true;
        }
        return false;
    }

    // --

    protected class_8666 getDisplayedIcon(class_1799 mail) {
        if (Mail.isReturned(mail)) return ICON_RETURNED_SPRITES;
        Address sender = Mail.getSenderOrUnknown(mail);
        if (sender.equals(Address.UNKNOWN)) return ICON_ADDRESS_UNKNOWN_SPRITES;
        if (sender.equals(Address.MAIL_SERVICE)) return ICON_ADDRESS_MAIL_SERVICE_SPRITES;
        return switch (sender.type()) {
            case BLOCK -> ICON_ADDRESS_BLOCK_SPRITES;
            case PLAYER -> ICON_ADDRESS_PLAYER_SPRITES;
            case ENTITY -> ICON_ADDRESS_ENTITY_SPRITES;
        };
    }

    protected class_2561 getDisplayedIconName(class_1799 mail) {
        if (Mail.isReturned(mail)) return class_2561.method_43471("gui.envelope.mail.returned");
        Address sender = Mail.getSenderOrUnknown(mail);
        if (sender.equals(Address.UNKNOWN)) return class_2561.method_43471("address.envelope.unknown");
        if (sender.equals(Address.MAIL_SERVICE)) return class_2561.method_43471("address.envelope.mail_service");
        return switch (sender.type()) {
            case BLOCK -> class_2561.method_43471("address.envelope.type.block");
            case PLAYER -> class_2561.method_43471("address.envelope.type.player");
            case ENTITY -> class_2561.method_43471("address.envelope.type.entity");
        };
    }

    protected Address getDisplayedSender(class_1799 mail) {
        return Mail.getSenderOrUnknown(mail);
    }

    // --

    protected boolean isMouseOver(class_768 rect, double mouseX, double mouseY) {
        return mouseX >= rect.method_3321() && mouseX < rect.method_3321() + rect.method_3319()
              && mouseY >= rect.method_3322() && mouseY < rect.method_3322() + rect.method_3320();
    }
}
