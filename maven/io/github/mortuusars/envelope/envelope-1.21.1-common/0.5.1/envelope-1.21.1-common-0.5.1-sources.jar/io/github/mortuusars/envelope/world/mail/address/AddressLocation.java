package io.github.mortuusars.envelope.world.mail.address;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.delivery.TravelDuration;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public interface AddressLocation {
    int ASCEND_DISTANCE = 16;

    Optional<class_2338> getPosition();
    int getDistanceTo(class_2338 pos);

    default int getDistanceTo(Optional<class_2338> pos) {
        return pos.map(this::getDistanceTo).orElse(Config.Server.DELIVERY_DEFAULT_DISTANCE.get());
    }

    default TravelDuration getTravelDurationTo(class_2338 pos) {
        return TravelDuration.basedOnDistance(getDistanceTo(pos));
    }

    default TravelDuration getTravelDurationTo(Optional<class_2338> pos) {
        return TravelDuration.basedOnDistance(getDistanceTo(pos));
    }

    default Optional<class_2338> getNearestHub() {
        return getPosition().map(pos -> Position.snapToGrid(pos, 1024).method_33096(320));
    }

    default Optional<class_2338> ascendTowards(class_1937 level, Optional<class_2338> targetPos) {
        return getPosition().map(pos -> targetPos
              .map(blockPos -> Position.ascendTowards(pos, blockPos, ASCEND_DISTANCE))
              .orElseGet(() -> Position.towardsRandomHorizontalDirection(pos, ASCEND_DISTANCE, hashCode())))
              .map(pos -> Position.aboveGround(level, pos, 5));
    }

    // --

    static AddressLocation exact(class_2338 pos) {
        return new Exact(pos);
    }

    record Exact(@NotNull class_2338 pos) implements AddressLocation {
        @Override
        public Optional<class_2338> getPosition() {
            return Optional.of(pos);
        }

        @Override
        public int getDistanceTo(class_2338 pos) {
            return Position.getDistanceBetween(this.pos, pos);
        }
    }

    AddressLocation VIRTUAL = new AddressLocation() {
        @Override
        public Optional<class_2338> getPosition() {
            return Optional.empty();
        }

        @Override
        public int getDistanceTo(class_2338 pos) {
            class_2338 virtualPos = Position.snapToGrid(pos, 2048);
            return Position.getDistanceBetween(virtualPos, pos);
        }
    };

    AddressLocation UNKNOWN = new AddressLocation() {
        @Override
        public Optional<class_2338> getPosition() {
            return Optional.empty();
        }

        @Override
        public int getDistanceTo(class_2338 pos) {
            return Config.Server.DELIVERY_DEFAULT_DISTANCE.get();
        }
    };
}
