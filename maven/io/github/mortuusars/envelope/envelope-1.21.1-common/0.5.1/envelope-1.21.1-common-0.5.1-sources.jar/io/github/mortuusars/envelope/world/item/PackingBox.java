package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import net.minecraft.class_1799;

public interface PackingBox {
    default int getTimesPacked(class_1799 stack) {
        return stack.method_57825(Envelope.DataComponents.PACKAGE_TIMES_PACKED, 0);
    }

    default int getRemainingPacks(class_1799 stack) {
        return Config.Server.PACKAGE_PACK_LIMIT.get() - getTimesPacked(stack);
    }

    default boolean canPack(class_1799 stack) {
        return getTimesPacked(stack) < Config.Server.PACKAGE_PACK_LIMIT.get();
    }

    default boolean shouldBeDestroyedWhenEmpty(class_1799 stack) {
        return !canPack(stack);
    }

    default boolean canInsert(class_1799 stack) {
        return stack.method_7909().method_31568() && !stack.method_31573(Envelope.Tags.Items.CANNOT_BE_PACKAGED);
    }
}
