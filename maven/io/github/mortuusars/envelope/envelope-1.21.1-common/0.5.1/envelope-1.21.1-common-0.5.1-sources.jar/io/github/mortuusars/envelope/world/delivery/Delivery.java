package io.github.mortuusars.envelope.world.delivery;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.delivery.phase.DeliveryPhase;
import io.github.mortuusars.envelope.world.delivery.route.DeliveryRoute;
import io.github.mortuusars.envelope.world.item.component.Id;
import io.github.mortuusars.envelope.world.mail.address.Address;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_4844;

public class Delivery {
    public static final Codec<Delivery> CODEC = RecordCodecBuilder.create(i -> i.group(
          Id.CODEC.fieldOf("id").forGetter(Delivery::getId),
          class_4844.field_25122.optionalFieldOf("owner").forGetter(Delivery::getOwner),
          Address.CODEC.fieldOf("sender").forGetter(Delivery::getSender),
          Address.CODEC.fieldOf("recipient").forGetter(Delivery::getRecipient),
          class_1799.field_49266.optionalFieldOf("mail", class_1799.field_8037).forGetter(Delivery::getMail),
          DeliveryRoute.CODEC.optionalFieldOf("route", DeliveryRoute.EMPTY).forGetter(Delivery::getRoute),
          DeliveryPhase.CODEC.optionalFieldOf("phase", DeliveryPhase.STARTED).forGetter(Delivery::getPhase),
          Codec.intRange(0, Integer.MAX_VALUE).optionalFieldOf("phase_progress", 0).forGetter(Delivery::getPhaseProgress),
          Codec.BOOL.optionalFieldOf("ended", false).forGetter(Delivery::isEnded)
    ).apply(i, Delivery::new));

    private final Id id;
    private final Optional<UUID> owner;
    private final Address sender;
    private final Address recipient;
    private class_1799 mail;
    private DeliveryRoute route;
    private DeliveryPhase phase;
    private int phaseProgress;
    private boolean ended;

    public Delivery(Id id, Optional<UUID> owner, Address sender, Address recipient, class_1799 mail,
                    DeliveryRoute route, DeliveryPhase phase, int phaseProgress, boolean ended) {
        this.id = id;
        this.owner = owner;
        this.sender = sender;
        this.recipient = recipient;
        this.mail = mail;
        this.route = route;
        this.phase = phase;
        this.phaseProgress = phaseProgress;
        this.ended = ended;
    }

    public static DeliveryDraft draft() {
        return new DeliveryDraft();
    }

    // --

    public Id getId() {
        return id;
    }

    public Optional<UUID> getOwner() {
        return owner;
    }

    public Address getSender() {
        return sender;
    }

    public Address getRecipient() {
        return recipient;
    }

    public class_1799 getMail() {
        return mail;
    }

    public Delivery setMail(class_1799 mail) {
        this.mail = mail;
        return this;
    }

    public DeliveryRoute getRoute() {
        return route;
    }

    public void setRoute(DeliveryRoute route) {
        this.route = route;
    }

    public void updateRoute(class_3218 level) {
        setRoute(DeliveryRoute.build(level, getSender(), getRecipient()));
    }

    public DeliveryPhase getPhase() {
        return phase;
    }

    public void setPhase(DeliveryPhase phase, int progress) {
        this.phase = phase;
        setPhaseProgress(progress);
    }

    public void setPhaseAndResetProgress(DeliveryPhase phase) {
        setPhase(phase, 0);
    }

    public int getPhaseProgress() {
        return phaseProgress;
    }

    public void setPhaseProgress(int progress) {
        this.phaseProgress = Math.max(0, progress);
    }

    public void incrementCurrentPhaseProgress() {
        phaseProgress++;
    }

    public void end() {
        this.ended = true;
    }

    // --

    public boolean isEnded() {
        return ended;
    }

//    public boolean hasResult() {
//        return getPhase().ordinal() >= DeliveryPhase.RETURNING_TO_SENDER.ordinal()
//              && !mail.isEmpty()
//              && Mail.getStatus(mail) == MailStatus.REGULAR;
//    }

    // --

    @Override
    public String toString() {
        return "Delivery{" +
              "sender=" + sender +
              ", recipient=" + recipient +
              ", mail=" + mail +
              ", phase=" + phase +
              ", progress=" + phaseProgress +
              '}';
    }
}