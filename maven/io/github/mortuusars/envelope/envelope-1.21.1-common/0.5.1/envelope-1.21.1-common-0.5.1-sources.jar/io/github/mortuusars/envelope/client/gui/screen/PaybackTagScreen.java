package io.github.mortuusars.envelope.client.gui.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.gui.Sprites;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.world.inventory.PaybackTagMenu;
import io.github.mortuusars.envelope.world.inventory.slot.DisabledSlot;
import io.github.mortuusars.envelope.world.item.component.RequestedPayback;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_7919;
import org.jetbrains.annotations.NotNull;

public class PaybackTagScreen extends class_465<PaybackTagMenu> {
    public static final class_2960 TEXTURE = Envelope.resource("textures/gui/payback_tag.png");

    protected class_344 confirmButton;

    public PaybackTagScreen(PaybackTagMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected void method_25426() {
        field_2792 = 186;
        field_2779 = 154;
        super.method_25426();
        field_25270 = field_2779 - 94;
        field_25269 = 12;

        field_25267 = (field_2792 / 2) - (field_22793.method_27525(method_25440()) / 2);

        confirmButton = new class_344(field_2776 + 128, field_2800 + 28, 19, 19,
              Sprites.CONFIRM_BUTTON_SPRITES, button -> confirm(), class_2561.method_43471("gui.envelope.confirm"));
        confirmButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.envelope.confirm")));
        method_37063(confirmButton);
    }

    protected void confirm() {
        method_17577().method_7604(method_17577().getPlayer(), PaybackTagMenu.CONFIRM_BUTTON_ID);
        Minecrft.gameMode().method_2900(method_17577().field_7763, PaybackTagMenu.CONFIRM_BUTTON_ID);
        method_25419();
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        renderTargetPreview(guiGraphics, mouseX, mouseY);
        method_2380(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        guiGraphics.method_25302(TEXTURE, field_2776, field_2800, 0, 0, field_2792, field_2779);
    }

    @Override
    protected void method_2385(class_332 guiGraphics, class_1735 slot) {
        super.method_2385(guiGraphics, slot);

        if (slot instanceof DisabledSlot) {
            guiGraphics.method_51448().method_22903();
            guiGraphics.method_51448().method_46416(0, 0, 300);
            RenderSystem.enableBlend();
            guiGraphics.method_25302(TEXTURE, slot.field_7873 - 1, slot.field_7872 - 1, 186, 0, 18, 18);
            RenderSystem.disableBlend();
            guiGraphics.method_51448().method_22909();
        }

//        if (slot.index < Payback.SLOTS) {
//            guiGraphics.pose().pushPose();
//            guiGraphics.pose().translate(0, 0, 300);
//            RenderSystem.enableBlend();
//            guiGraphics.blit(TEXTURE, slot.x - 1, slot.y - 1, 186, 18, 18, 18);
//            RenderSystem.disableBlend();
//            guiGraphics.pose().popPose();
//        }
    }

    protected void renderTargetPreview(@NotNull class_332 guiGraphics, int mouseX, int mouseY) {
        class_1799 target = method_17577().getTag().getItemStack();
        if (target.method_7960()) {
            return;
        }

        float scale = 2f;
        int size = (int) (16 * scale);

        int x = field_2776 - size - 4;
        int y = field_2800 + 36 - size / 2;

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(x + (float) size / 2, y + (float) size / 2, 0);
        guiGraphics.method_51448().method_22905(scale, scale, scale);
        guiGraphics.method_51448().method_46416(-8, -8, 0);
        guiGraphics.method_51427(target, 0, 0);
        guiGraphics.method_51448().method_22909();

        if (method_2378(x - field_2776, y - field_2800, size, size, mouseX, mouseY)) {
            guiGraphics.method_51446(field_22793, target, mouseX, mouseY);
        }
    }

    // -- Input

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (super.method_25401(mouseX, mouseY, scrollX, scrollY)) {
            return true;
        }

        if (field_2787 != null && field_2787.field_7874 < RequestedPayback.SLOTS) {
            boolean decreasing = scrollY < 0;
            boolean fast = class_437.method_25442();
            changeRequestedItemCount(decreasing, fast);
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (super.method_25404(keyCode, scanCode, modifiers)){
            return true;
        }

        if (field_2787 != null && field_2787.field_7874 < RequestedPayback.SLOTS) {
            if (keyCode == class_3675.field_31933 || keyCode == class_3675.field_31937) {
                changeRequestedItemCount(false, class_437.method_25442());
                return true;
            }

            if (keyCode == 333 /*KEY_SUBTRACT*/ || keyCode == class_3675.field_31941) {
                changeRequestedItemCount(true, class_437.method_25442());
                return true;
            }
        }

        return false;
    }

    protected void changeRequestedItemCount(boolean decreasing, boolean fast) {
        if (field_2787 == null) return;
        int startId = decreasing ? PaybackTagMenu.DECREASE_COUNT_START_BUTTON_ID : PaybackTagMenu.INCREASE_COUNT_START_BUTTON_ID;
        int id = startId + field_2787.field_7874 + (fast ? RequestedPayback.SLOTS : 0);
        method_17577().method_7604(method_17577().getPlayer(), id);
        Minecrft.gameMode().method_2900(method_17577().field_7763, id);
    }
}
