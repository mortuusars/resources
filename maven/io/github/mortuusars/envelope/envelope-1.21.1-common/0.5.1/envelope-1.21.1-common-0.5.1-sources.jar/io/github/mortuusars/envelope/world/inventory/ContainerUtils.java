package io.github.mortuusars.envelope.world.inventory;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1799;

public class ContainerUtils {
    public static class_1263 compact(class_1263 container, int maxSlots) {
        class_1277 compactedContainer = new class_1277(maxSlots);
        for (int slot = 0; slot < Math.min(maxSlots, container.method_5439()); slot++) {
            class_1799 stack = container.method_5438(slot);
            compactedContainer.method_5491(stack);
        }
        return compactedContainer;
    }

    public static class_1263 compact(class_1263 container) {
        return compact(container, container.method_5439());
    }

    public static List<class_1799> toList(class_1263 container, int maxSlots) {
        List<class_1799> items = new ArrayList<>();
        for (int i = 0; i < Math.min(container.method_5439(), maxSlots); i++) {
            items.add(container.method_5438(i));
        }
        return items;
    }
}
