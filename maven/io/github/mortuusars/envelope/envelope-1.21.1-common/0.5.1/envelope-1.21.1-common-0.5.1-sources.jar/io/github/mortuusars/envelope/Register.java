package io.github.mortuusars.envelope;

import com.mojang.brigadier.arguments.ArgumentType;
import dev.architectury.injectables.annotations.ExpectPlatform;
import org.jetbrains.annotations.NotNull;

import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_179;
import net.minecraft.class_1792;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2248;
import net.minecraft.class_2314;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2941;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3414;
import net.minecraft.class_3446;
import net.minecraft.class_3917;
import net.minecraft.class_3956;
import net.minecraft.class_4158;
import net.minecraft.class_5321;
import net.minecraft.class_9129;
import net.minecraft.class_9331;
import net.minecraft.class_9360;
import net.minecraft.class_9695;

public class Register {
    @ExpectPlatform
    public static <T extends class_2248> Supplier<T> block(String id, Supplier<T> supplier) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T extends class_2591<E>, E extends class_2586> Supplier<T> blockEntityType(String id, Supplier<T> sup) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T extends class_2586> class_2591<T> newBlockEntityType(Register.BlockEntitySupplier<T> blockEntitySupplier, class_2248... validBlocks) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static Supplier<class_4158> poiType(class_5321<class_4158> key, int ticketCount, int searchDistance, Supplier<Set<class_2680>> states) {
        throw new AssertionError();
    }

    @FunctionalInterface
    public interface BlockEntitySupplier<T extends class_2586> {

        @NotNull T create(class_2338 pos, class_2680 state);
    }

    @ExpectPlatform
    public static <T extends class_1792> Supplier<T> item(String id, Supplier<T> supplier) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T extends class_1297> Supplier<class_1299<T>> entityType(String id, class_1299.class_4049<T> factory,
                                                                        class_1311 category, float width, float height,
                                                                        int clientTrackingRange, boolean velocityUpdates, int updateInterval) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T extends class_1297> Supplier<class_1299<T>> entityType(String id, class_1299.class_4049<T> factory, class_1311 category,
                                                                        boolean receiveVelocityUpdates, Consumer<class_1299.class_1300<T>> typeBuilder) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void entityDataSerializer(String id, class_2941<?> serializer) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T extends class_3414> Supplier<T> soundEvent(String id, Supplier<T> supplier) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T extends class_3917<E>, E extends class_1703> Supplier<T> menuType(String id, Register.MenuTypeSupplier<E> supplier) {
        throw new AssertionError();
    }

    @FunctionalInterface
    public interface MenuTypeSupplier<T extends class_1703> {
        @NotNull T create(int windowId, class_1661 playerInv, class_9129 extraData);
    }

    @ExpectPlatform
    public static <T extends class_1860<I>, I extends class_9695> Supplier<class_3956<T>> recipeType(String name, Supplier<class_3956<T>> supplier) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static Supplier<class_1865<?>> recipeSerializer(String name, Supplier<class_1865<?>> supplier) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T extends class_179<?>> Supplier<T> criterionTrigger(String name, Supplier<T> supplier) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T extends class_9360.class_8745<?>> Supplier<T> itemSubPredicate(String name, Supplier<T> supplier) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <A extends ArgumentType<?>, T extends class_2314.class_7217<A>, I extends class_2314<A, T>>
    Supplier<class_2314<A, T>> commandArgumentType(String id, Class<A> infoClass, I argumentTypeInfo) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T extends class_3037> Supplier<class_3031<?>> worldGenFeature(String name, Supplier<class_3031<T>> featureSupplier) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T> class_9331<T> dataComponentType(String name, Consumer<class_9331.class_9332<T>> builderConsumer) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static <T extends class_2396<? extends class_2394>> Supplier<T> particleType(String name, Supplier<T> supplier) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static Supplier<class_2960> stat(class_2960 location, class_3446 formatter) {
        throw new AssertionError();
    }
}
