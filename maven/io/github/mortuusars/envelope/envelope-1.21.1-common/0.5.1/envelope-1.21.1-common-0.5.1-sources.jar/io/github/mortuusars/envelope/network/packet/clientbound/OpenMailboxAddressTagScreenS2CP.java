package io.github.mortuusars.envelope.network.packet.clientbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.envelope.network.handler.ClientPacketsHandler;
import io.github.mortuusars.envelope.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

public record OpenMailboxAddressTagScreenS2CP(class_1268 hand,
                                              AllAddresses knownAddresses,
                                              class_2338 pos,
                                              Address.Block currentAddress) implements Packet {
    public static final class_2960 ID = Envelope.resource("open_mailbox_address_tag_screen");
    public static final class_9154<OpenMailboxAddressTagScreenS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, OpenMailboxAddressTagScreenS2CP> STREAM_CODEC = class_9139.method_56905(
            class_9135.field_48550.method_56432(i -> class_1268.values()[i], class_1268::ordinal), OpenMailboxAddressTagScreenS2CP::hand,
            AllAddresses.STREAM_CODEC, OpenMailboxAddressTagScreenS2CP::knownAddresses,
            class_2338.field_48404, OpenMailboxAddressTagScreenS2CP::pos,
            Address.Block.STREAM_CODEC, OpenMailboxAddressTagScreenS2CP::currentAddress,
            OpenMailboxAddressTagScreenS2CP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        ClientPacketsHandler.openMailboxAddressTagScreen(this);
        return true;
    }
}
