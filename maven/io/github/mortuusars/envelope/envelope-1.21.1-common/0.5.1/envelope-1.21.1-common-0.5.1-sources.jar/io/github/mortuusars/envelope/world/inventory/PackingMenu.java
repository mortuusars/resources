package io.github.mortuusars.envelope.world.inventory;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.inventory.slot.DisabledSlot;
import io.github.mortuusars.envelope.world.item.PackingBox;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3917;
import net.minecraft.class_9129;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class PackingMenu extends class_1703 {
    public static final int PACK_BUTTON_ID = 0;

    private final class_1657 player;
    private final class_1268 hand;
    private final int packageSlot;
    private final class_1799 packageStack;
    private final PackingBox packingBox;
    private final PackageContents initialPackageContents;
    private final boolean canPack;
    private final class_1277 packageContainer;

    protected boolean packed = false;

    protected PackingMenu(@Nullable class_3917<?> menuType, int containerId, class_1661 playerInventory, class_1268 hand) {
        super(menuType, containerId);
        this.player = playerInventory.field_7546;
        this.hand = hand;
        this.packageSlot = hand == class_1268.field_5810 ? class_1661.field_30639 : playerInventory.field_7545;
        this.packageStack = playerInventory.method_5438(packageSlot);
        this.packingBox = (PackingBox) packageStack.method_7909();
        this.initialPackageContents = PackageContents.from(packageStack);
        this.canPack = packingBox.canPack(packageStack);
        this.packageContainer = createPackageContainer();
        init();
    }

    public PackingMenu(int containerId, class_1661 playerInventory, class_1268 hand) {
        this(Envelope.MenuTypes.PACKAGE.get(), containerId, playerInventory, hand);
    }

    public static PackingMenu fromNetwork(int id, class_1661 inventory, class_9129 buffer) {
        return new PackingMenu(id, inventory, buffer.method_10818(class_1268.class));
    }

    protected void init() {
        addPackageSlots();
        addPlayerSlots(player.method_31548(), 8, 96, packageSlot);
    }

    // --

    protected @NotNull class_1277 createPackageContainer() {
        final class_1277 packageContainer;
        List<class_1799> items = new ArrayList<>(PackageContents.from(packageStack).copyItems());
        while (items.size() < PackageContents.SLOTS) {
            items.add(class_1799.field_8037);
        }

        packageContainer = new class_1277(items.toArray(class_1799[]::new));
        return packageContainer;
    }

    protected void addPackageSlots() {
        int packageSlotsX = 62;
        int packageSlotsY = 33;

        for (int row = 0; row < 2; row++) {
            for (int column = 0; column < 3; column++) {
                int index = column + row * 3;
                int x = packageSlotsX + column * 18;
                int y = packageSlotsY + row * 18;
                method_7621(new class_1735(packageContainer, index, x, y) {
                    @Override
                    public boolean method_7680(class_1799 stack) {
                        return getPackage().canInsert(stack);
                    }
                });
            }
        }
    }

    protected void addPlayerSlots(class_1263 inventory, int x, int y, int packageSlot) {
        // Hotbar
        for (int index = 0; index < 9; index++) {
            int slotX = x + index * 18;
            int slotY = y + 58;
            method_7621(index == packageSlot
                  ? new DisabledSlot(inventory, index, slotX, slotY)
                  : new class_1735(inventory, index, slotX, slotY));
        }

        // Inventory
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                int index = (column + row * 9) + 9;
                int slotX = x + column * 18;
                int slotY = y + row * 18;
                method_7621(index == packageSlot
                      ? new DisabledSlot(inventory, index, slotX, slotY)
                      : new class_1735(inventory, index, slotX, slotY));
            }
        }
    }

    // --

    public class_1657 getPlayer() {
        return player;
    }

    public class_1268 getHand() {
        return hand;
    }

    public int getPackageSlot() {
        return packageSlot;
    }

    public class_1799 getBoxStack() {
        return packageStack;
    }

    public PackingBox getPackage() {
        return packingBox;
    }

    public PackageContents getInitialPackageContents() {
        return initialPackageContents;
    }

    protected @NotNull PackageContents getPackageContentsFromItem() {
        return PackageContents.from(getBoxStack());
    }

    public boolean canPack() {
        return canPack;
    }

    public class_1277 getPackageContainer() {
        return packageContainer;
    }

    public boolean needsPacking() {
        if (packed) {
            return false;
        }

        PackageContents contents = PackageContents.createFrom(packageContainer);
        return !contents.isEmpty();
    }

    public boolean isContainerEmpty() {
        return packageContainer.method_5442();
    }

    public boolean isPackageDestroyedOnClose() {
        return !canPack && (needsPacking() || isContainerEmpty());
    }

    // --

    @Override
    public @NotNull class_1799 method_7601(@NotNull class_1657 player, int index) {
        class_1735 slot = field_7761.get(index);
        class_1799 clickedStack = slot.method_7677();

        if (index < PackageContents.SLOTS) {
            if (!method_7616(clickedStack, PackageContents.SLOTS, field_7761.size(), true))
                return class_1799.field_8037;
        } else if (index < field_7761.size()) {
            if (!method_7616(clickedStack, 0, PackageContents.SLOTS, false))
                return class_1799.field_8037;
        }

        packageContainer.method_5431();

        return class_1799.field_8037;
    }

    @Override
    public boolean method_7604(@NotNull class_1657 player, int buttonId) {
        if (buttonId == PACK_BUTTON_ID && canPack()) {
            pack(player);
            return true;
        }

        return false;
    }

    protected void pack(@NotNull class_1657 player) {
        class_1799 stack = createPackingResult();
        stack.method_57379(Envelope.DataComponents.PACKAGE_CONTENTS, PackageContents.createFrom(packageContainer));
        stack.method_57379(Envelope.DataComponents.PACKAGE_TIMES_PACKED,
              stack.method_57825(Envelope.DataComponents.PACKAGE_TIMES_PACKED, 0) + 1);

        player.method_6122(getHand(), stack);
        player.method_37908().method_43129(null, player, class_3417.field_14883.comp_349(), class_3419.field_15248,
              1f, player.method_37908().method_8409().method_43057() * 0.3f + 0.85f);
        packed = true;
    }

    protected class_1799 createPackingResult() {
        class_1799 stack = getBoxStack().method_60503(Envelope.Items.PACKAGE.get());
        Mail.removePreviousDeliveryData(stack);
        return stack;
    }

    @Override
    public void method_7595(@NotNull class_1657 player) {
        if (!packed && player instanceof class_3222 serverPlayer) {
            for (class_1799 stack : PackageContents.createFrom(packageContainer).copyItems()) {
                player.method_7328(stack, true);
            }
            getBoxStack().method_57381(Envelope.DataComponents.PACKAGE_CONTENTS);

            if (getPackage().shouldBeDestroyedWhenEmpty(getBoxStack())) {
                player.method_5998(hand).method_7934(1);
                serverPlayer.method_51469().method_43129(null, serverPlayer,
                      class_3417.field_15075, class_3419.field_15248, 1, 1);
            }
        }

        super.method_7595(player);
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return player.method_5998(hand).method_7909() instanceof PackingBox;
    }
}