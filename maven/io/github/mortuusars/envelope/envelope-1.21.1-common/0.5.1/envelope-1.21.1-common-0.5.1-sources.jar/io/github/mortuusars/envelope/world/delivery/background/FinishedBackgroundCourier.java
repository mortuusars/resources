package io.github.mortuusars.envelope.world.delivery.background;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.entity.SpawnableEntityData;
import net.minecraft.class_1799;
import net.minecraft.class_2338;

public record FinishedBackgroundCourier(SpawnableEntityData entityData, class_2338 spawnPos, class_1799 undeliveredMail) {
    public static final Codec<FinishedBackgroundCourier> CODEC = RecordCodecBuilder.create(instance -> instance.group(
          SpawnableEntityData.CODEC.fieldOf("entity").forGetter(FinishedBackgroundCourier::entityData),
          class_2338.field_25064.fieldOf("spawn_pos").forGetter(FinishedBackgroundCourier::spawnPos),
          class_1799.field_49266.optionalFieldOf("undelivered_mail", class_1799.field_8037).forGetter(FinishedBackgroundCourier::undeliveredMail)
    ).apply(instance, FinishedBackgroundCourier::new));
}
