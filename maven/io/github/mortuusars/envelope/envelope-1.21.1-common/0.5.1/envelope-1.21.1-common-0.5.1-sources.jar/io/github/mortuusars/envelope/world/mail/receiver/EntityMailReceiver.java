package io.github.mortuusars.envelope.world.mail.receiver;

import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.service.MailService;
import net.minecraft.class_1799;
import net.minecraft.class_3218;

public class EntityMailReceiver implements MailReceiver {
    private final Address.Entity address;

    public EntityMailReceiver(Address.Entity address) {
        this.address = address;
    }

    @Override
    public class_1799 receiveMail(class_3218 level, class_1799 mail) {
        return MailService.of(level).getMailEntities().byAddress(address)
              .map(entity -> entity.receiveMail(level, mail))
              .orElseGet(() -> returned(mail, DeliveryRecord.Message.RECIPIENT_NOT_FOUND));
    }
}