package io.github.mortuusars.envelope.client.gui.tooltip;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.gui.RequestedItemDisplay;
import io.github.mortuusars.envelope.world.inventory.RequestedItem;
import io.github.mortuusars.envelope.world.item.component.RequestedPayback;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;

public record PaybackTooltipComponent(RequestedPayback requestedPayback) implements class_5684 {
    public static final class_2960 SLOT_SPRITE = Envelope.resource("tooltip/payback/slot");

    private static final class_1799 PAYBACK_TAG = new class_1799(Envelope.Items.PAYBACK_TAG.get());

    @Override
    public int method_32664(class_327 font) {
        return 16 + (18 * requestedPayback().items().size()) + 5;
    }

    @Override
    public int method_32661() {
        return 23;
    }

    @Override
    public void method_32666(class_327 font, int x, int y, class_332 guiGraphics) {
        guiGraphics.method_55231(PAYBACK_TAG, x - 1, y + 3, 0);

        int slots = requestedPayback().items().size();

        for (int i = 0; i < slots; i++) {
            RequestedItem requestedItem = requestedPayback().items().get(i);
            RequestedItemDisplay display = new RequestedItemDisplay(requestedItem);
            class_1799 stack = display.getDisplayedItem();

            int slotX = x + 17 + 2 + (i * 18);
            int slotY = y + 2;

            if (i == 0) {
                // Left border
                guiGraphics.method_52708(SLOT_SPRITE, 22, 22, 0, 0, slotX - 2, y, 2, 22);
            }

            if (i == slots - 1) {
                // Right border
                guiGraphics.method_52708(SLOT_SPRITE, 22, 22, 20, 0, slotX + 18, y, 2, 22);
            }

            guiGraphics.method_52708(SLOT_SPRITE, 22, 22, 2, 0, slotX, y, 18, 22);
            guiGraphics.method_55231(stack, slotX + 1, slotY + 1, 0);
            guiGraphics.method_51431(font, stack, slotX + 1, slotY + 1);

            if (requestedItem.item().left().isPresent()) {
                guiGraphics.method_51448().method_46416(0, 0, 200);
                guiGraphics.method_51433(font, "#", slotX + 1 + 19 - 2 - font.method_1727("#"), y + 1, 0xFFFFFFFF, true);
            }
        }
    }
}
