package io.github.mortuusars.envelope.world.service;

import com.mojang.authlib.GameProfile;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.mail.address.Address;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import net.minecraft.class_1657;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_3218;
import net.minecraft.class_5699;
import net.minecraft.class_7225;

public class Players extends class_18 {
    public static final Codec<Players> CODEC = Codec.unboundedMap(Codec.STRING, PlayerData.CODEC)
          .xmap(Players::new, Players::getData);

    protected final Map<String, PlayerData> data;
//    protected @Nullable Map<UUID, PlayerData> dataById;
//    protected @Nullable Map<Address.Player, PlayerData> dataByAddress;
    protected @Nullable Set<Address.Player> addresses;
    protected @Nullable Map<Address.Player, Address.Block> defaultAddresses;

    public Players(Map<String, PlayerData> data) {
        this.data = new HashMap<>(data); // Make sure it's modifiable
    }

    public Players() {
        this(Collections.emptyMap());
    }

    protected Map<String, PlayerData> getData() {
        return data;
    }

    // --

    public void add(class_1657 player) {
        data.computeIfAbsent(player.method_5820(), name -> new PlayerData(player.method_7334()));
        method_80();
    }

    public void remove(String name) {
        if (data.remove(name) != null) {
            method_80();
        }
    }

    public void clear() {
        data.clear();
        method_80();
    }

    // --

    public Optional<PlayerData> getDataOf(String playerName) {
        return Optional.ofNullable(data.get(playerName));
    }

    // --

    public Optional<Address.Block> getDefaultAddressOf(class_1657 player) {
        return getDataOf(player.method_5820()).flatMap(PlayerData::getDefaultAddress);
    }

    public Optional<Address.Block> getDefaultAddressOf(Address.Player playerAddress) {
        return getDataOf(playerAddress.toString()).flatMap(PlayerData::getDefaultAddress);
    }

    public void setDefaultAddress(class_1657 player, Address.Block address) {
        update(player, data -> data.setDefaultAddress(address));
    }

    public void renameDefaultAddress(Address.Block oldAddress, Address.Block newAddress) {
        getData().values().forEach(data -> {
            if (data.getDefaultAddress().map(a -> a.equals(oldAddress)).orElse(false)) {
                data.setDefaultAddress(newAddress);
            }
        });
        method_80();
    }

    public void removeDefaultAddress(Address.Block address) {
        getData().values().forEach(data -> {
            if (data.getDefaultAddress().map(a -> a.equals(address)).orElse(false)) {
                data.setDefaultAddress(null);
            }
        });
        method_80();
    }

    // --

    public void update(class_1657 player, Consumer<PlayerData> updater) {
        data.compute(player.method_5820(), (name, data) -> {
            if (data == null) {
                data = new PlayerData(player.method_7334());
            }
            updater.accept(data);
            return data;
        });
        method_80();
    }

//    public Optional<UUID> getUuid(String name) {
//        return Optional.ofNullable(map.get(name));
//    }
//
//    public Optional<UUID> getUuid(Address.Player address) {
//        return Optional.ofNullable(map.get(address.id()));
//    }
//
//    public Optional<String> getName(UUID uuid) {
//        for (var entry : map.entrySet()) {
//            if (Objects.equals(entry.getValue(), uuid)) {
//                return Optional.ofNullable(entry.getKey());
//            }
//        }
//        return Optional.empty();
//    }

    // --

    public @NotNull Set<Address.Player> getAllAddresses() {
        if (addresses == null) {
            addresses = data.keySet().stream()
                  .map(Address.Player::new)
                  .collect(Collectors.toSet());
        }
        return addresses;
    }

    public Map<Address.Player, Address.Block> getDefaultAddresses() {
        if (defaultAddresses == null) {
            defaultAddresses = new HashMap<>();
            getData().forEach((name, data) ->
                  data.getDefaultAddress().ifPresent(defaultAddress -> defaultAddresses.put(data.getAddress(), defaultAddress)));
        }
        return defaultAddresses;
    }

    @Override
    public void method_80() {
        super.method_80();
        resetCache();
    }

    protected void resetCache() {
        addresses = null;
        defaultAddresses = null;
    }

    // -- Save / Load

    public static Players get(class_3218 level, String name) {
        return level.method_17983().method_17924(factory(), name);
    }

    @Override
    public @NotNull class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
        return CODEC.encode(this, class_2509.field_11560, tag)
                .ifError(e -> Envelope.LOGGER.error("Cannot save KnownPlayers: {}", e.message()))
                .result()
                .filter(t -> t instanceof class_2487)
                .map(t -> ((class_2487) t))
                .orElse(tag);
    }

    private static Players load(class_2487 tag, class_7225.class_7874 registries) {
        return CODEC.decode(class_2509.field_11560, tag)
                .ifError(e -> Envelope.LOGGER.error("Cannot load KnownPlayers: {}", e.message()))
                .result().map(Pair::getFirst).orElseGet(Players::new);
    }

    private static class_8645<Players> factory() {
        return new class_8645<>(Players::new, Players::load, null);
    }

    // --

    public static class PlayerData {
        public static final Codec<PlayerData> CODEC = RecordCodecBuilder.create(i -> i.group(
              class_5699.field_45076.codec().fieldOf("profile").forGetter(PlayerData::getProfile),
              Address.Block.STRING_CODEC.optionalFieldOf("default_address").forGetter(PlayerData::getDefaultAddress)
        ).apply(i, PlayerData::new));

        protected final GameProfile profile;
        protected final Address.Player address;
        protected Optional<Address.Block> defaultAddress;

        public PlayerData(GameProfile profile, Optional<Address.Block> defaultAddress) {
            this.profile = profile;
            this.address = new Address.Player(profile.getName());
            this.defaultAddress = defaultAddress;
        }

        public PlayerData(GameProfile profile) {
            this(profile, Optional.empty());
        }

        public GameProfile getProfile() {
            return profile;
        }

        public Address.Player getAddress() {
            return address;
        }

        public Optional<Address.Block> getDefaultAddress() {
            return defaultAddress;
        }

        public void setDefaultAddress(@Nullable Address.Block address) {
            this.defaultAddress = Optional.ofNullable(address);
        }
    }
}
