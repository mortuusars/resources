package io.github.mortuusars.envelope.world.entity;

import com.mojang.serialization.Codec;
import org.jetbrains.annotations.NotNull;

import java.util.function.IntFunction;
import net.minecraft.class_3542;
import net.minecraft.class_5819;
import net.minecraft.class_6007;
import net.minecraft.class_6008;
import net.minecraft.class_6012;
import net.minecraft.class_7995;

public enum PigeonVariant implements class_3542 {
    GRAY(0, "gray"),
    BROWN(1, "brown"),
    WHITE(2, "white"),
    PASSENGER(3, "passenger");

    public static final Codec<PigeonVariant> CODEC =
          class_3542.method_28140(PigeonVariant::values);
    private static final IntFunction<PigeonVariant> BY_ID =
          class_7995.method_47914(PigeonVariant::getId, values(), class_7995.class_7996.field_41666);

    public static final class_6012<class_6008.class_6010<PigeonVariant>> SERVICE_POOL = class_6012.method_34989(
          new class_6008.class_6010<>(GRAY, class_6007.method_34977(16)),
          new class_6008.class_6010<>(BROWN, class_6007.method_34977(8)),
          new class_6008.class_6010<>(WHITE, class_6007.method_34977(4)),
          new class_6008.class_6010<>(PASSENGER, class_6007.method_34977(2))
    );

    public static final class_6012<class_6008.class_6010<PigeonVariant>> REGULAR_BIOME_POOL = class_6012.method_34989(
          new class_6008.class_6010<>(GRAY, class_6007.method_34977(10)),
          new class_6008.class_6010<>(BROWN, class_6007.method_34977(4)),
          new class_6008.class_6010<>(WHITE, class_6007.method_34977(1))
    );

    public static final class_6012<class_6008.class_6010<PigeonVariant>> HAS_PASSENGER_PIGEON_BIOME_POOL = class_6012.method_34989(
          new class_6008.class_6010<>(PASSENGER, class_6007.method_34977(16)),
          new class_6008.class_6010<>(GRAY, class_6007.method_34977(6)),
          new class_6008.class_6010<>(BROWN, class_6007.method_34977(4)),
          new class_6008.class_6010<>(WHITE, class_6007.method_34977(1))
    );

    private final int id;
    private final String name;

    PigeonVariant(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return this.id;
    }

    @Override
    public @NotNull String method_15434() {
        return this.name;
    }

    public static PigeonVariant byId(int id) {
        return BY_ID.apply(id);
    }

    // --

    public static PigeonVariant getRandomRegular(class_5819 random) {
        return REGULAR_BIOME_POOL.method_34992(random).orElseThrow().comp_2542();
    }

    public static PigeonVariant getRandomPassengerPriority(class_5819 random) {
        return HAS_PASSENGER_PIGEON_BIOME_POOL.method_34992(random).orElseThrow().comp_2542();
    }

    public static PigeonVariant getRandomService(class_5819 random) {
        return SERVICE_POOL.method_34992(random).orElseThrow().comp_2542();
    }
}
