package io.github.mortuusars.envelope.world.service;

import com.google.common.base.Preconditions;
import io.github.mortuusars.envelope.util.bugger.Bugger;
import io.github.mortuusars.envelope.util.result.Result;
import io.github.mortuusars.envelope.world.delivery.Delivery;
import io.github.mortuusars.envelope.world.delivery.background.BackgroundDelivery;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.AddressLocation;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import io.github.mortuusars.envelope.world.mail.entity.MailEntities;
import io.github.mortuusars.envelope.world.mail.entity.MailEntity;
import io.github.mortuusars.envelope.world.mail.entity.mail_service.MailServiceEntity;
import io.github.mortuusars.envelope.world.mail.entity.mail_service.payback_department.PaybackDepartment;
import io.github.mortuusars.envelope.world.mail.receiver.EntityMailReceiver;
import io.github.mortuusars.envelope.world.mail.receiver.MailboxMailReceiver;
import io.github.mortuusars.envelope.world.mail.receiver.PlayerMailReceiver;
import io.github.mortuusars.envelope.world.block.mailbox.Mailboxes;
import net.minecraft.class_124;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_3218;
import net.minecraft.class_5244;
import net.minecraft.class_9334;
import net.minecraft.network.chat.*;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class MailService {
    protected final class_3218 level;

    protected final Mailboxes mailboxes;
    protected final MailEntities mailEntities;
    protected final MailServiceEntity mailServiceEntity;
    protected final PaybackDepartment paybackDepartment;
    protected final DeliveryManager deliveryManager;

    protected @Nullable Players players;
    protected @Nullable BackgroundDelivery backgroundDelivery;

    private MailService(class_3218 level) {
        Preconditions.checkArgument(level.method_27983() == class_1937.field_25179, "MailService can exist only on overworld level.");
        this.level = level;
        this.mailboxes = new Mailboxes(level);
        this.mailEntities = new MailEntities();
        this.mailServiceEntity = new MailServiceEntity(this);
        this.paybackDepartment = new PaybackDepartment(this);
        this.deliveryManager = new DeliveryManager(this);

        this.mailEntities.register(mailServiceEntity);
    }

    /**
     * It's intended to be created only once for a level. Use {@link MailService#of} to get the instance.
     */
    @ApiStatus.Internal
    public static MailService create(class_3218 level) {
        return new MailService(level);
    }

    public static MailService of(class_3218 level) {
        return level.getEnvelopeMailService();
    }

    // --

    public class_3218 getLevel() {
        return level;
    }

    public Mailboxes getMailboxes() {
        return mailboxes;
    }

    public MailEntities getMailEntities() {
        return mailEntities;
    }

    public MailServiceEntity getMailService() {
        return mailServiceEntity;
    }

    public PaybackDepartment getPaybackDepartment() {
        return paybackDepartment;
    }

    public @NotNull Players getPlayers() {
        return players == null
              ? players = Players.get(level, "envelope_players")
              : players;
    }

    public @NotNull BackgroundDelivery getBackgroundDelivery() {
        return backgroundDelivery == null
              ? backgroundDelivery = BackgroundDelivery.get(level, "envelope_background_delivery")
              : backgroundDelivery;
    }

    public DeliveryManager getDeliveryManager() {
        return deliveryManager;
    }

    // -- Address

    public AllAddresses getKnownAddresses() {
        return new AllAddresses(
              getMailboxes().getAllAddresses(),
              getPlayers().getDefaultAddresses().keySet(),
              getMailEntities().getAllAddresses()
        );
    }

    public AllAddresses getKnownAddressesOfType(@Nullable Address.Type type) {
        if (type == null) {
            return getKnownAddresses();
        }
        return switch (type) {
            case BLOCK -> AllAddresses.blocks(getMailboxes().getAllAddresses());
            case PLAYER -> AllAddresses.players(getPlayers().getDefaultAddresses().keySet());
            case ENTITY -> AllAddresses.entities(getMailEntities().getAllAddresses());
        };
    }

    public Optional<Address.Block> getPlayerDefaultAddress(Address.Player playerAddress) {
        return Optional.ofNullable(getPlayers().getDefaultAddresses().get(playerAddress));
    }

    /**
     * @return "final" address. Mainly for getting default block address of a player.
     */
    public Address resolve(Address address) {
        if (address instanceof Address.Player playerAddress) {
            return getPlayerDefaultAddress(playerAddress).map(Address.class::cast).orElse(address);
        }
        return address;
    }

    public AddressLocation getLocationOf(Address address) {
        return address.map(
                    block -> getMailboxes().getPositionOf(block).map(AddressLocation::exact),
                    player -> getPlayers().getDefaultAddressOf(player).map(this::getLocationOf),
                    entity -> getMailEntities().byAddress(entity).map(MailEntity::getLocation))
              .orElse(AddressLocation.UNKNOWN);
    }

    // --

    public class_1799 deliverMail(Address address, class_1799 mail) {
        if (mail.method_7960()) return mail;
        return address.map(MailboxMailReceiver::new, PlayerMailReceiver::new, EntityMailReceiver::new).receiveMail(level, mail);
    }

    // --

    public void tick() {
        getBackgroundDelivery().tick(level);
        getPaybackDepartment().tick();

        if (level.method_8510() % 20 == 0) Bugger.MAIL_SERVICE.collectAndSendData(this);
    }

    // --

    public long getGameTime() {
        return getLevel().method_8510();
    }

    public static boolean operatesIn(class_1937 level) {
        return level.method_27983() == class_1937.field_25179;
    }

    public Result<DeliveryManager.StartedDelivery> sendCourierDeathNotice(class_1309 entity, Delivery delivery, class_1282 damageSource) {
        if (!(delivery.getSender() instanceof Address.Block address)) {
            return null;
        }

        class_1799 letter = createCourierDeathNoticeLetter(entity, delivery, damageSource);

        return getDeliveryManager().startService(Delivery.draft()
              .deliver(letter)
              .from(Address.MAIL_SERVICE)
              .to(address));
    }

    public class_1799 createCourierDeathNoticeLetter(class_1309 entity, Delivery delivery, class_1282 damageSource) {
        class_2561 text = class_2561.method_43473()
              .method_10852(class_2561.method_43471("letter.envelope.courier_death_notice.title").method_27692(class_124.field_1056))
              .method_10852(class_2561.method_43469("letter.envelope.courier_death_notice.inform_" + entity.method_59922().method_43048(5),
                          damageSource.method_5506(entity)))
              .method_10852(class_2561.method_43469("letter.envelope.courier_death_notice.delivery." + delivery.getPhase().method_15434(),
                    delivery.getRecipient().format().withIcon().withIconColor(0xFFB5633F).withColor(0xFFB5633F).toComponent()))
              .method_10852(!delivery.getMail().method_7960()
                    ? class_2561.method_43469("letter.envelope.courier_death_notice.mail_lost_" + entity.method_59922().method_43048(6),
                    delivery.getMail().method_7964().method_27661()
                          .method_27696(class_2583.field_24360.method_30938(true)
                                .method_10949(new class_2568(class_2568.class_5247.field_24343, new class_2568.class_5249(delivery.getMail())))))
                    : class_5244.field_39003)
              .method_10852(class_2561.method_43469("letter.envelope.courier_death_notice.condolence_" + entity.method_59922().method_43048(5),
                    entity.method_5477()))
              .method_10852(class_2561.method_43471("letter.envelope.courier_death_notice.signature"));

        return Mail.createLetter(text)
              .set(class_9334.field_49631, class_2561.method_43471("letter.envelope.courier_death_notice.name"))
              .get();
    }
}