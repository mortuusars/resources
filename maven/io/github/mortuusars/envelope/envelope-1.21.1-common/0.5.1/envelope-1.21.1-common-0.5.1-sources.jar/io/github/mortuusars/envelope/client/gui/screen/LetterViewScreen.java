package io.github.mortuusars.envelope.client.gui.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.serverbound.LetterViewScreenClosedS2CP;
import io.github.mortuusars.envelope.util.ItemAndStack;
import io.github.mortuusars.envelope.world.item.LetterItem;
import io.github.mortuusars.envelope.world.item.component.LetterContent;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5481;

public class LetterViewScreen extends class_437 {
    public static final class_2960 REGULAR_TEXTURE = Envelope.resource("textures/gui/letter.png");
    public static final class_2960 TATTERED_TEXTURE = Envelope.resource("textures/gui/letter_tattered.png");
    public static final class_2960 TATTERED_OVERLAY = Envelope.resource("textures/gui/letter_tattered_overlay.png");

    protected final ItemAndStack<LetterItem> letter;
    protected final class_1268 hand;
    protected final boolean isTattered;

    protected int imageWidth, imageHeight, leftPos, topPos;
    protected int maxTextWidth;
    protected int maxTextHeight;
    protected int maxTextLines;

    protected List<class_5481> lines;

    public LetterViewScreen(class_1799 letter, class_1268 hand) {
        super(class_2561.method_43473());
        this.letter = new ItemAndStack<>(letter);
        this.hand = hand;
        this.isTattered = letter.method_57826(Envelope.DataComponents.LETTER_TATTERED);
    }

    @Override
    public boolean method_25421() {
        return Config.Server.LETTER_PAUSE.get();
    }

    @Override
    protected void method_25426() {
        imageWidth = 176;
        imageHeight = 192;
        leftPos = (field_22789 - imageWidth) / 2;
        topPos = (field_22790 - imageHeight) / 2;
        maxTextWidth = 142;
        maxTextHeight = 144;
        maxTextLines = maxTextHeight / field_22793.field_2000;
        createLines(letter.method_57825(Envelope.DataComponents.LETTER_CONTENT, LetterContent.EMPTY).text());
    }

    protected void createLines(class_2561 text) {
        lines = field_22793.method_1728(text, maxTextWidth);
        if (lines.size() > maxTextLines) {
            lines = new ArrayList<>(lines);
            int lastLineIndex = maxTextLines - 1;
            class_5481 ellipsis = class_5244.field_39678.method_30937();
            lines.set(lastLineIndex, class_5481.method_30742(lines.get(lastLineIndex), ellipsis));
            lines.set(lastLineIndex + 1, class_5481.method_30742(ellipsis, lines.get(lastLineIndex + 1)));
        }
    }

    // -- Render

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        final int x = leftPos + 17;
        final int y = topPos + 21;
        int textColor = 0xFF7B593D;

        for (int i = 0; i < Math.min(lines.size(), maxTextLines); i++) {
            guiGraphics.method_51430(field_22793, lines.get(i), x, y + i * field_22793.field_2000, textColor, false);
        }

        if (isTattered) {
            RenderSystem.enableBlend();
            guiGraphics.method_51448().method_22903();
            guiGraphics.method_51448().method_46416(0, 0, 200);
            guiGraphics.method_25302(TATTERED_OVERLAY, leftPos, topPos, 0, 0, imageWidth, imageHeight);
            guiGraphics.method_51448().method_22909();
            RenderSystem.disableBlend();
        }

        @Nullable class_2583 style = getComponentStyleAt(mouseX, mouseY);
        if (style != null && style.method_10969() != null) {
            guiGraphics.method_51441(field_22793, style, mouseX, mouseY);
        } else {
            if (lines.size() > maxTextLines
                  && mouseX >= x && mouseX < x + maxTextWidth
                  && mouseY >= y && mouseY < y + maxTextHeight) {
                List<class_5481> leftovers = lines.stream().skip(maxTextLines).toList();
                guiGraphics.method_51447(field_22793, leftovers, mouseX, mouseY);
            }
        }
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.method_52752(guiGraphics);
        class_2960 texture = isTattered ? TATTERED_TEXTURE : REGULAR_TEXTURE;
        guiGraphics.method_25302(texture, leftPos, topPos, 0, 0, imageWidth, imageHeight);
    }

    @Nullable
    public class_2583 getComponentStyleAt(double mouseX, double mouseY) {
        if (lines.isEmpty()
              || mouseX < leftPos + 17 || mouseX >= leftPos + 17 + maxTextWidth
              || mouseY < topPos + 21 || mouseY >= topPos + 21 + maxTextHeight) {
            return null;
        }

        int x = (int)mouseX - (leftPos + 17);
        int y = (int)mouseY - (topPos + 21);

        int linesCount = Math.min(lines.size(), maxTextLines);
        if (y < field_22793.field_2000 * linesCount + linesCount) {
            int clickedLine = y / field_22793.field_2000;
            if (clickedLine >= 0 && clickedLine < lines.size()) {
                class_5481 text = lines.get(clickedLine);
                return field_22793.method_27527().method_30876(text, x);
            }

            return null;
        }

        return null;
    }

    @Override
    public void method_25419() {
        super.method_25419();
        int slot = this.hand == class_1268.field_5808 ? Minecrft.player().method_31548().field_7545 : class_1661.field_30639;
        Packets.sendToServer(new LetterViewScreenClosedS2CP(slot));
    }

    // -- Input

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (class_310.method_1551().field_1690.field_1822.method_1417(keyCode, scanCode)) {
            this.method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public boolean method_25402(double x, double y, int button) {
        if (button == 0) {
            @Nullable class_2583 style = getComponentStyleAt(x, y);
            if (method_25430(style)) {
                return true;
            }
        }

        return super.method_25402(x, y, button);
    }

    public boolean method_25430(@Nullable class_2583 style) {
        if (style == null) {
            return false;
        }

        @Nullable class_2558 clickEvent = style.method_10970();
        if (clickEvent == null) {
            return false;
        }

        boolean handled = method_25430(style);
        if (handled && clickEvent.method_10845() == class_2558.class_2559.field_11750) {
            method_25419();
        }

        return handled;
    }
}
