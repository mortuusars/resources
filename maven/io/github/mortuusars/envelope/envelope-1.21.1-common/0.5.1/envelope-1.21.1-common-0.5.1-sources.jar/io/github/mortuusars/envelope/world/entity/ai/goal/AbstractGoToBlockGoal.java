package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlock;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.entity.ai.MailboxHandler;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_2338;

public abstract class AbstractGoToBlockGoal extends class_1352 {
    public static final int MAX_TRAVELLING_TICKS = 600;
    public static final int TICKS_BEFORE_DROP = 60;
    protected final Pigeon pigeon;
    protected int travellingTicks;
    protected int ticksStuck;

    public AbstractGoToBlockGoal(Pigeon pigeon) {
        this.pigeon = pigeon;
        this.travellingTicks = pigeon.method_37908().field_9229.method_43048(10);
        method_6265(EnumSet.of(class_4134.field_18405));
    }

    public abstract @Nullable class_2338 getBlockPos();

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public boolean method_6264() {
        @Nullable class_2338 pos = getBlockPos();
        return pos != null
              && !pigeon.method_18410()
              && !pigeon.hasReachedTarget(pos)
              && !Position.isFireNearby(pigeon.method_37908(), pos);
    }

    @Override
    public void method_6269() {
        travellingTicks = 0;
        ticksStuck = 0;
        super.method_6269();
    }

    @Override
    public void method_6270() {
        this.travellingTicks = 0;
        this.ticksStuck = 0;
        pigeon.method_5942().method_6340();
        pigeon.method_5942().method_23965();
    }
}
