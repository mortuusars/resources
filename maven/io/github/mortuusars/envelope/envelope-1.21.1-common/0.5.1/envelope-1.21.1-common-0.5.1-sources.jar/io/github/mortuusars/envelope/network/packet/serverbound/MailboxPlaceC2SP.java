package io.github.mortuusars.envelope.network.packet.serverbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.packet.Packet;
import io.github.mortuusars.envelope.util.EnvelopeStreamCodecs;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlock;
import io.github.mortuusars.envelope.world.item.MailboxBlockItem;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3965;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record MailboxPlaceC2SP(class_1268 hand, String address, class_3965 hitResult) implements Packet {
    public static final class_2960 ID = Envelope.resource("mailbox_place");
    public static final class_9154<MailboxPlaceC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, MailboxPlaceC2SP> STREAM_CODEC = class_9139.method_56436(
          class_9135.field_48550.method_56432(i -> class_1268.values()[i], class_1268::ordinal), MailboxPlaceC2SP::hand,
          class_9135.field_48554, MailboxPlaceC2SP::address,
          EnvelopeStreamCodecs.BLOCK_HIT_RESULT, MailboxPlaceC2SP::hitResult,
          MailboxPlaceC2SP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        class_1799 mailbox = player.method_5998(hand);

        if (mailbox.method_7960() || !(mailbox.method_7909() instanceof MailboxBlockItem blockItem)) {
            Envelope.LOGGER.error("Cannot handle {} packet: {} is not a valid mailbox item.", ID, mailbox);
            return false;
        }

        class_1750 context = new class_1750(player, hand, mailbox, hitResult);
        MailboxBlock.placeBlockWithAddress(player, hand, context, address);
        return true;
    }
}
