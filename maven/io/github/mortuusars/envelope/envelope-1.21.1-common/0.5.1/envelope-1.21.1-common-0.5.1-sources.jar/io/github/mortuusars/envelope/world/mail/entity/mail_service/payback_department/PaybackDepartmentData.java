package io.github.mortuusars.envelope.world.mail.entity.mail_service.payback_department;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.Id;
import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

public class PaybackDepartmentData extends class_18 {
    public static final Codec<PaybackDepartmentData> CODEC = RecordCodecBuilder.create(i -> i.group(
          Codec.unboundedMap(Id.CODEC, PaybackSubject.CODEC)
                .optionalFieldOf("payback_pending", Collections.emptyMap())
                .forGetter(PaybackDepartmentData::getPaybackPendingSubjects)
    ).apply(i, PaybackDepartmentData::new));

    private final Map<Id, PaybackSubject> paybackPendingSubjects;

    public PaybackDepartmentData(Map<Id, PaybackSubject> paybackPendingSubjects) {
        this.paybackPendingSubjects = new HashMap<>(paybackPendingSubjects); // Make sure it's mutable
    }

    public PaybackDepartmentData() {
        this.paybackPendingSubjects = new HashMap<>();
    }

    public Map<Id, PaybackSubject> getPaybackPendingSubjects() {
        return paybackPendingSubjects;
    }

    // -- Save / Load

    public static PaybackDepartmentData get(class_3218 level, String name) {
        return level.method_17983().method_17924(factory(), name);
    }

    public @NotNull class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
        return CODEC.encode(this, registries.method_57093(class_2509.field_11560), tag)
              .ifError(e -> Envelope.LOGGER.error("Cannot save PaybackDepartmentData: {}", e.message()))
              .result()
              .filter(t -> t instanceof class_2487)
              .map(t -> ((class_2487) t))
              .orElse(tag);
    }

    private static PaybackDepartmentData load(class_2487 tag, class_7225.class_7874 registries) {
        return CODEC.decode(registries.method_57093(class_2509.field_11560), tag)
              .ifError(e -> Envelope.LOGGER.error("Cannot load PaybackDepartmentData: {}", e.message()))
              .result()
              .map(Pair::getFirst)
              .orElseGet(PaybackDepartmentData::new);
    }

    private static class_18.class_8645<PaybackDepartmentData> factory() {
        return new class_18.class_8645<>(PaybackDepartmentData::new, PaybackDepartmentData::load, null);
    }
}
