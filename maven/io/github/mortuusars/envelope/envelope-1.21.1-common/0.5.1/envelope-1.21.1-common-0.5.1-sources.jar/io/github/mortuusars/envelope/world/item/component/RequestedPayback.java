package io.github.mortuusars.envelope.world.item.component;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.inventory.RequestedItem;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_5632;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record RequestedPayback(List<RequestedItem> items) implements class_5632 {
    public static final int SLOTS = 6;
    public static final RequestedPayback DEFAULT = new RequestedPayback(List.of(RequestedItem.DEFAULT));

    public static final Codec<RequestedPayback> CODEC =
          Codec.list(RequestedItem.CODEC, 1, 6).xmap(RequestedPayback::new, RequestedPayback::items);

    public static final class_9139<class_9129, RequestedPayback> STREAM_CODEC =
          RequestedItem.STREAM_CODEC.method_56433(class_9135.method_58000(6)).method_56432(RequestedPayback::new, RequestedPayback::items);

    public RequestedPayback {
        Preconditions.checkArgument(!items.isEmpty(), "Payback must have at least one requested item.");
    }

    public static Optional<RequestedPayback> create(List<RequestedItem> items) {
        return !items.isEmpty() ? Optional.of(new RequestedPayback(items)) : Optional.empty();
    }

    public static RequestedPayback createOrDefault(List<RequestedItem> items) {
        return !items.isEmpty() ? new RequestedPayback(items) : DEFAULT;
    }

    // --

    public boolean matches(class_1263 container) {
        for (int slot = 0; slot < items().size(); slot++) {
            RequestedItem requestedItem = items().get(slot);
            if (slot >= container.method_5439()) {
                return false;
            }
            class_1799 stack = container.method_5438(slot);
            if (!requestedItem.matches(stack)) {
                return false;
            }
        }

        return true;
    }

    public boolean matches(PackageContents packageContents) {
        for (int slot = 0; slot < items().size(); slot++) {
            RequestedItem requestedItem = items().get(slot);
            if (slot >= packageContents.size()) {
                return false;
            }
            class_1799 stack = packageContents.getItemForReading(slot);
            if (!requestedItem.matches(stack)) {
                return false;
            }
        }

        return true;
    }

    public Optional<RequestedItem> getRequestedItem(int index) {
        return index < items.size() ? Optional.of(items.get(index)) : Optional.empty();
    }

    // --

    public static boolean isValidPaybackItem(class_1799 stack) {
        return Envelope.Items.PACKING_BOX.get().canInsert(stack) && !stack.method_31573(Envelope.Tags.Items.CANNOT_BE_USED_AS_PAYBACK);
    }
}
