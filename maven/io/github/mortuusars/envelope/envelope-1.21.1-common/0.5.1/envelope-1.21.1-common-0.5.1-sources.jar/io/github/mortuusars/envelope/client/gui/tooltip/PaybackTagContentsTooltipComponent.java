package io.github.mortuusars.envelope.client.gui.tooltip;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.PaybackTagContents;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;

public record PaybackTagContentsTooltipComponent(PaybackTagContents contents) implements class_5684 {
    public static final class_2960 SLOT_SPRITE = Envelope.resource("tooltip/payback/slot");

    @Override
    public int method_32664(class_327 font) {
        return !contents.isEmpty() ? 18 * contents().items().size() + 4 : 0 ;
    }

    @Override
    public int method_32661() {
        return !contents.isEmpty() ? 24 : 0;
    }

    @Override
    public void method_32666(class_327 font, int x, int y, class_332 guiGraphics) {
        if (contents.isEmpty()) {
            return;
        }

        List<class_1799> items = contents().items().stream().filter(i -> !i.method_7960()).toList();
        int slots = items.size();

        for (int i = 0; i < slots; i++) {
            class_1799 stack = items.get(i);

            int slotX = x + 2 + (i * 18);
            int slotY = y + 2;

            if (i == 0) {
                // Left border
                guiGraphics.method_52708(SLOT_SPRITE, 22, 22, 0, 0, slotX - 2, y, 2, 22);
            }

            if (i == slots - 1) {
                // Right border
                guiGraphics.method_52708(SLOT_SPRITE, 22, 22, 20, 0, slotX + 18, y, 2, 22);
            }

            guiGraphics.method_52708(SLOT_SPRITE, 22, 22, 2, 0, slotX, y, 18, 22);
            guiGraphics.method_55231(stack, slotX + 1, slotY + 1, 0);
            guiGraphics.method_51431(font, stack, slotX + 1, slotY + 1);
        }
    }
}
