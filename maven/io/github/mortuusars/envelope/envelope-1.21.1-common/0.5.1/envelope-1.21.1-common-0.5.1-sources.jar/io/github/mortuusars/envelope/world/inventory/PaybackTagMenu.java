package io.github.mortuusars.envelope.world.inventory;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.util.ItemAndStack;
import io.github.mortuusars.envelope.world.inventory.slot.DisabledSlot;
import io.github.mortuusars.envelope.world.inventory.slot.FilteredSlot;
import io.github.mortuusars.envelope.world.item.PaybackTagItem;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.component.RequestedPayback;
import io.github.mortuusars.envelope.world.item.component.PaybackTagContents;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3917;
import net.minecraft.class_9129;

public class PaybackTagMenu extends class_1703 {
    public static final int CONFIRM_BUTTON_ID = 0;

    public static final int COUNT_START_BUTTON_ID = 100;
    public static final int INCREASE_COUNT_START_BUTTON_ID = COUNT_START_BUTTON_ID;
    public static final int INCREASE_COUNT_FAST_START_BUTTON_ID = INCREASE_COUNT_START_BUTTON_ID + PaybackTagContents.SLOTS;
    public static final int DECREASE_COUNT_START_BUTTON_ID = INCREASE_COUNT_FAST_START_BUTTON_ID + PaybackTagContents.SLOTS;
    public static final int DECREASE_COUNT_FAST_START_BUTTON_ID = DECREASE_COUNT_START_BUTTON_ID + PaybackTagContents.SLOTS;

    private final class_1657 player;
    private final class_1268 hand;
    private final int tagSlot;
    private final ItemAndStack<class_1792> tagStack;
    private final class_1277 paybackContainer;

    protected PaybackTagMenu(@Nullable class_3917<?> menuType, int containerId, class_1661 playerInventory, class_1268 hand) {
        super(menuType, containerId);
        this.player = playerInventory.field_7546;
        this.hand = hand;
        this.tagSlot = hand == class_1268.field_5810 ? class_1661.field_30639 : playerInventory.field_7545;
        this.tagStack = new ItemAndStack<>(playerInventory.method_5438(tagSlot));
        this.paybackContainer = createPaybackContainer();

        addPaybackSlots();
        addPlayerSlots(playerInventory, 13, 72, tagSlot);
    }

    public PaybackTagMenu(int containerId, class_1661 playerInventory, class_1268 hand) {
        this(Envelope.MenuTypes.PAYBACK_TAG.get(), containerId, playerInventory, hand);
    }

    public static PaybackTagMenu fromNetwork(int id, class_1661 inventory, class_9129 buffer) {
        return new PaybackTagMenu(id, inventory, buffer.method_10818(class_1268.class));
    }

    // --

    protected class_1277 createPaybackContainer() {
        List<class_1799> items = new ArrayList<>();

        @Nullable PaybackTagContents paybackTagContents = tagStack.method_57824(Envelope.DataComponents.PAYBACK_TAG_CONTENTS);
        if (paybackTagContents != null) {
            for (int i = 0; i < Math.min(paybackTagContents.size(), PaybackTagContents.SLOTS); i++) {
                items.add(paybackTagContents.getItemForReading(i));
            }
        }

        while (items.size() < PaybackTagContents.SLOTS) {
            items.add(class_1799.field_8037);
        }

        return new class_1277(items.toArray(class_1799[]::new));
    }

    protected void addPaybackSlots() {
        int slotsX = 67;
        int slotsY = 20;

        for (int row = 0; row < 2; row++) {
            for (int column = 0; column < 3; column++) {
                int index = column + row * 3;
                int x = slotsX + column * 18;
                int y = slotsY + row * 18;
                method_7621(new FilteredSlot(paybackContainer, index, x, y, RequestedPayback::isValidPaybackItem));
            }
        }
    }

    protected void addPlayerSlots(class_1263 inventory, int x, int y, int tagSlot) {
        // Hotbar
        for (int index = 0; index < 9; index++) {
            int slotX = x + index * 18;
            int slotY = y + 58;
            method_7621(index == tagSlot
                  ? new DisabledSlot(inventory, index, slotX, slotY)
                  : new class_1735(inventory, index, slotX, slotY));
        }

        // Inventory
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                int index = (column + row * 9) + 9;
                int slotX = x + column * 18;
                int slotY = y + row * 18;
                method_7621(index == tagSlot
                      ? new DisabledSlot(inventory, index, slotX, slotY)
                      : new class_1735(inventory, index, slotX, slotY));
            }
        }
    }

    // --

    public class_1657 getPlayer() {
        return player;
    }

    public class_1268 getHand() {
        return hand;
    }

    public int getTagSlot() {
        return tagSlot;
    }

    public ItemAndStack<class_1792> getTag() {
        return tagStack;
    }

    // --

    @Override
    public @NotNull class_1799 method_7601(@NotNull class_1657 player, int index) {
        class_1735 slot = field_7761.get(index);
        class_1799 clickedStack = slot.method_7677();

        if (index < PackageContents.SLOTS) {
            paybackContainer.method_5447(index, class_1799.field_8037);
            paybackContainer.method_5431();
        }
        else if (index < field_7761.size()) {
            for (int i = 0; i < PaybackTagContents.SLOTS; i++) {
                class_1735 paybackSlot = field_7761.get(i);
                if (paybackSlot.method_7677().method_7960() && paybackSlot.method_7680(clickedStack)) {
                    paybackSlot.method_7673(clickedStack.method_7972());
                    paybackSlot.method_7668();
                    break;
                }
            }
        }

        return class_1799.field_8037;
    }

    @Override
    public boolean method_7604(@NotNull class_1657 player, int buttonId) {
        if (buttonId == CONFIRM_BUTTON_ID) {
            PaybackTagContents contents = PaybackTagContents.create(paybackContainer);
            if (contents.isEmpty()) {
                getTag().remove(Envelope.DataComponents.PAYBACK_TAG_CONTENTS);
            } else {
                getTag().set(Envelope.DataComponents.PAYBACK_TAG_CONTENTS, contents);
            }
            player.method_37908().method_43129(player, player, class_3417.field_14883.comp_349(), class_3419.field_15248,
                  1f, player.method_37908().method_8409().method_43057() * 0.3f + 0.85f);
            player.method_6122(getHand(), getTag().getItemStack());
            return true;
        }

        if (buttonId >= COUNT_START_BUTTON_ID) {
            int id = buttonId - COUNT_START_BUTTON_ID;
            int slotIndex = id % PaybackTagContents.SLOTS;

            boolean decrease = id >= PaybackTagContents.SLOTS * 2;
            boolean fast = id % (PaybackTagContents.SLOTS * 2) >= PaybackTagContents.SLOTS;

            int change = (fast ? 5 : 1);
            if (decrease) {
                change *= -1;
            }

            class_1799 stack = paybackContainer.method_5438(slotIndex);
            stack.method_7939(class_3532.method_15340(stack.method_7947() + change, 1, stack.method_7914()));
            paybackContainer.method_5431();
        }

        return false;
    }

    @Override
    public void method_7593(int slotId, int button, class_1713 clickType, class_1657 player) {
        if (slotId < 0 || slotId >= PaybackTagContents.SLOTS) {
            super.method_7593(slotId, button, clickType, player);
            return;
        }

        class_1735 paybackSlot = this.field_7761.get(slotId);

        if (!method_34255().method_7960() && paybackSlot.method_7680(method_34255())) {
            class_1799 result = method_34255().method_7972();

            if (button == 1) {
                if (class_1799.method_31577(paybackSlot.method_7677(), result)) {
                    result.method_7939(paybackSlot.method_7677().method_7947() + 1);
                } else {
                    result.method_7939(1);
                }
            }
            paybackSlot.method_7673(result);
        } else {
            paybackSlot.method_7673(class_1799.field_8037);
        }
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return player.method_5998(hand).method_7909() instanceof PaybackTagItem;
    }
}
