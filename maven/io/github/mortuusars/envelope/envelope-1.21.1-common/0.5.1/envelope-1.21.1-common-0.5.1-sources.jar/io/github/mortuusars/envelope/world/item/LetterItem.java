package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.clientbound.OpenLetterViewScreenS2CP;
import io.github.mortuusars.envelope.world.item.component.LetterContent;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import org.jetbrains.annotations.NotNull;

public class LetterItem extends class_1792 implements Sealable {
    public LetterItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        class_1799 stack = player.method_5998(usedHand);
        stack.method_57379(Envelope.DataComponents.LETTER_CONTENT,
              stack.method_57825(Envelope.DataComponents.LETTER_CONTENT, LetterContent.EMPTY).withUnfolded(true));
        player.method_7357().method_7906(this, 3);

        if (player instanceof class_3222 serverPlayer) {
            Packets.sendToClient(new OpenLetterViewScreenS2CP(usedHand), serverPlayer);
        }

        level.method_43129(player, player, Envelope.SoundEvents.PAPER_CRACKLE.get(), class_3419.field_15248, 1, 1);
        return class_1271.method_29237(stack, level.field_9236);
    }

    @Override
    public class_1799 seal(class_1937 level, class_1799 stack, Seal seal) {
        class_1799 sealedLetter = stack.method_60503(Envelope.Items.SEALED_LETTER.get());
        sealedLetter.method_57379(Envelope.DataComponents.SEAL, seal);
        return sealedLetter;
    }
}