package io.github.mortuusars.envelope.world.item.component.mail.log;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.world.GameTime;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.AddressFormatter;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3542;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_7995;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.network.chat.*;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public record DeliveryRecord(Type type, Optional<Address> address, Optional<Long> timestamp,
                             Optional<class_2561> message, MessageType messageType) {
    public static final Codec<DeliveryRecord> CODEC = RecordCodecBuilder.create(i -> i.group(
          Type.CODEC.fieldOf("type").forGetter(DeliveryRecord::type),
          Address.CODEC.optionalFieldOf("address").forGetter(DeliveryRecord::address),
          Codec.LONG.optionalFieldOf("timestamp").forGetter(DeliveryRecord::timestamp),
          class_8824.field_46597.optionalFieldOf("message").forGetter(DeliveryRecord::message),
          MessageType.CODEC.optionalFieldOf("message_type", MessageType.NEUTRAL).forGetter(DeliveryRecord::messageType)
    ).apply(i, DeliveryRecord::new));

    public static final class_9139<class_9129, DeliveryRecord> STREAM_CODEC = class_9139.method_56906(
          Type.STREAM_CODEC, DeliveryRecord::type,
          class_9135.method_56382(Address.STREAM_CODEC), DeliveryRecord::address,
          class_9135.method_56382(class_9135.field_48551), DeliveryRecord::timestamp,
          class_9135.method_56382(class_8824.field_48540), DeliveryRecord::message,
          MessageType.STREAM_CODEC, DeliveryRecord::messageType,
          DeliveryRecord::new
    );

    // --

    public static DeliveryRecord sentFrom(@NotNull Address address, long timestamp) {
        Preconditions.checkNotNull(address);
        return new DeliveryRecord(Type.SENT, Optional.of(address), Optional.of(timestamp),
              Optional.empty(), MessageType.NEUTRAL);
    }

    public static DeliveryRecord arrivedTo(@NotNull Address address, long timestamp) {
        Preconditions.checkNotNull(address);
        return new DeliveryRecord(Type.ARRIVED, Optional.of(address), Optional.of(timestamp),
              Optional.empty(), MessageType.NEUTRAL);
    }

    public static DeliveryRecord returned(class_2561 reason) {
        Preconditions.checkNotNull(reason);
        return new DeliveryRecord(Type.RETURNED, Optional.of(Address.MAIL_SERVICE), Optional.empty(),
              Optional.of(reason), MessageType.NEGATIVE);
    }

    public static DeliveryRecord payback(@NotNull class_2561 message, MessageType type) {
        return new DeliveryRecord(Type.PAYBACK, Optional.empty(), Optional.empty(),
              Optional.of(message), type);
    }

    // --

    public class_5250 toComponent(long gameTime) {
        int addressColor = switch (type()) {
            case SENT -> AddressFormatter.SENDER_COLOR;
            case ARRIVED -> AddressFormatter.RECIPIENT_COLOR;
            case RETURNED, PAYBACK, CUSTOM -> AddressFormatter.NEUTRAL_COLOR;
        };

        class_2561 addressComponent = this.address.map(a -> a.format()
                    .withIcon()
                    .withIconColor(addressColor)
                    .withColor(addressColor)
                    .toComponent())
              .orElse(class_2561.method_43473());

        class_5250 messageComponent = class_2561.method_43473().method_10852(message.orElse(class_5244.field_39003))
              .method_27696(messageType().getStyle());

        class_2561 elapsedTimeComponent = timestamp.map(time -> GameTime.formatLargest(gameTime - time, false)
              .method_27692(class_124.field_1063)).orElse(class_2561.method_43473());

        return class_2561.method_43469("gui.envelope.delivery_log.record." + this.type().method_15434(),
              addressComponent, messageComponent, elapsedTimeComponent).method_27692(class_124.field_1080);
    }

    // --

    public static class Builder {
        private final Type type;
        private Optional<Address> address = Optional.empty();
        private Optional<Long> timestamp = Optional.empty();
        private Optional<class_2561> message = Optional.empty();
        private MessageType messageType = MessageType.NEUTRAL;

        public Builder(Type type) {
            this.type = type;
        }

        public Builder address(Address address) {
            this.address = Optional.of(address);
            return this;
        }

        public Builder at(long timestamp) {
            this.timestamp = Optional.of(timestamp);
            return this;
        }

        public Builder message(class_2561 message) {
            this.message = Optional.ofNullable(message);
            return this;
        }

        public Builder messageType(MessageType messageType) {
            this.messageType = messageType;
            return this;
        }

        public DeliveryRecord build() {
            return new DeliveryRecord(type, address, timestamp, message, messageType);
        }
    }

    // --

    public enum Type implements class_3542 {
        SENT("sent"),
        ARRIVED("arrived"),
        RETURNED("returned"),
        PAYBACK("payback"),
        CUSTOM("custom");

        public static final Codec<Type> CODEC = class_3542.method_28140(Type::values);
        public static final class_9139<ByteBuf, Type> STREAM_CODEC = class_9135.method_56375(
              class_7995.method_47914(Type::ordinal, Type.values(), class_7995.class_7996.field_41664), Type::ordinal);

        private final String name;

        Type(String name) {
            this.name = name;
        }

        @Override
        public @NotNull String method_15434() {
            return name;
        }

        public class_5250 translate() {
            return class_2561.method_43471("gui.envelope.delivery_log.record." + method_15434());
        }
    }

    public interface Message {
        class_2561 RECIPIENT_NOT_FOUND = class_2561.method_43471("gui.envelope.delivery_log.message.returned_recipient_not_found");
        class_2561 RECIPIENT_INBOX_IS_FULL = class_2561.method_43471("gui.envelope.delivery_log.message.returned_recipient_inbox_is_full");
        class_2561 UNABLE_TO_REACH = class_2561.method_43471("gui.envelope.delivery_log.message.returned_unable_to_reach");
        class_2561 REJECTED = class_2561.method_43471("gui.envelope.delivery_log.message.returned_rejected");

        class_2561 PAYBACK_FULFILLED = class_2561.method_43471("gui.envelope.delivery_log.message.payback_fulfilled");
        class_2561 RETURNED_PAYBACK_SUBJECT_NOT_FOUND = class_2561.method_43471("gui.envelope.delivery_log.message.returned_payback_subject_not_found");
        class_2561 RETURNED_PAYBACK_IS_NOT_VALID = class_2561.method_43471("gui.envelope.delivery_log.message.returned_payback_is_not_valid");
        class_2561 RETURNED_PAYBACK_EXPIRED = class_2561.method_43471("gui.envelope.delivery_log.message.returned_payback_expired");
    }

    public enum MessageType implements class_3542 {
        NEUTRAL("neutral", class_2583.field_24360.method_10977(class_124.field_1080)),
        POSITIVE("positive", class_2583.field_24360.method_36139(0xFF75DC7C)),
        NEGATIVE("negative", class_2583.field_24360.method_36139(0xFFE48174));

        public static final Codec<MessageType> CODEC = class_3542.method_28140(MessageType::values);
        public static final class_9139<ByteBuf, MessageType> STREAM_CODEC = class_9135.method_56375(
              class_7995.method_47914(MessageType::ordinal, MessageType.values(), class_7995.class_7996.field_41664), MessageType::ordinal);

        private final String name;
        private final class_2583 style;

        MessageType(String name, class_2583 style) {
            this.name = name;
            this.style = style;
        }

        @Override
        public @NotNull String method_15434() {
            return name;
        }

        public class_2583 getStyle() {
            return style;
        }
    }
}
