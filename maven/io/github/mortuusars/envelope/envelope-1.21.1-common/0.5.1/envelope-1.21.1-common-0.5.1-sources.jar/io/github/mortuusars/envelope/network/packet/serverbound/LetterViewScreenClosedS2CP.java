package io.github.mortuusars.envelope.network.packet.serverbound;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.network.packet.Packet;
import io.github.mortuusars.envelope.world.item.LetterItem;
import io.github.mortuusars.envelope.world.item.component.LetterContent;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record LetterViewScreenClosedS2CP(int slot) implements Packet {
    public static final class_2960 ID = Envelope.resource("letter_view_screen_closed");
    public static final class_9154<LetterViewScreenClosedS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, LetterViewScreenClosedS2CP> STREAM_CODEC = class_9139.method_56434(
          class_9135.field_48550, LetterViewScreenClosedS2CP::slot,
          LetterViewScreenClosedS2CP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        class_1799 stack = player.method_31548().method_5438(slot);

        if (stack.method_7909() instanceof LetterItem) {
            LetterContent content = stack.method_57825(Envelope.DataComponents.LETTER_CONTENT, LetterContent.EMPTY)
                  .withUnfolded(false);

            if (content.isEmpty()) {
                stack.method_57381(Envelope.DataComponents.LETTER_CONTENT);
            } else {
                stack.method_57379(Envelope.DataComponents.LETTER_CONTENT, content);
            }

            player.method_7357().method_7906(stack.method_7909(), 3);

            return true;
        } else {
            return false;
        }
    }
}
