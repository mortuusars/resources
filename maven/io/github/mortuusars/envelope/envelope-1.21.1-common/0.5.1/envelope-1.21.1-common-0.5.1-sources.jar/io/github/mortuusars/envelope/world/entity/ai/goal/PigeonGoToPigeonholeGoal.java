package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import io.github.mortuusars.envelope.world.entity.ai.PigeonholeHandler;
import net.minecraft.class_11;
import net.minecraft.class_2338;
import org.jetbrains.annotations.Nullable;

public class PigeonGoToPigeonholeGoal extends AbstractGoToBlockGoal {
    @Nullable
    protected class_11 lastPath;

    public PigeonGoToPigeonholeGoal(Pigeon pigeon) {
        super(pigeon);
    }

    @Override
    public @Nullable class_2338 getBlockPos() {
        return pigeon.getPigeonholeHandler().getTargetPos();
    }

    @Override
    public boolean method_6264() {
        return super.method_6264()
              && pigeon.getPigeonholeHandler().wantsToEnterPigeonhole(pigeon)
              && pigeon.method_37908().method_8320(pigeon.getPigeonholeHandler().getTargetPos()).method_26164(Envelope.Tags.Blocks.PIGEONHOLES)
              && !Position.isFireNearby(pigeon.method_37908(), pigeon.getPigeonholeHandler().getTargetPos());
    }

    @Override
    public void method_6268() {
        PigeonholeHandler handler = pigeon.getPigeonholeHandler();

        if (handler.getTargetPos() == null) return;

        travellingTicks++;
        if (travellingTicks > method_38847(MAX_TRAVELLING_TICKS)) {
            handler.dropAndBlacklistPigeonhole();
            return;
        }

        if (pigeon.method_5942().method_23966()) {
            return;
        }

        if (!pigeon.closerThan(handler.getTargetPos(), 16)) {
            if (!pigeon.method_24515().method_19771(handler.getTargetPos(), 32)) {
                handler.dropPigeonhole();
            } else {
                pigeon.pathfindRandomlyTowards(handler.getTargetPos());
            }
        } else {
            boolean canReach = pigeon.pathfindDirectlyTowards(handler.getTargetPos());
            if (!canReach) {
                handler.dropAndBlacklistPigeonhole();
            } else if (lastPath != null && lastPath.method_41(pigeon.method_5942().method_6345())) {
                ticksStuck++;
                if (ticksStuck > TICKS_BEFORE_DROP) {
                    handler.dropPigeonhole();
                    ticksStuck = 0;
                }
            } else {
                lastPath = pigeon.method_5942().method_6345();
            }
        }
    }
}
