package io.github.mortuusars.envelope.world.entity.ai.goal;

import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlock;
import io.github.mortuusars.envelope.world.entity.Pigeon;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5530;

public class PigeonDeliverMailGoal extends class_1352 {
    protected final Pigeon pigeon;

    public PigeonDeliverMailGoal(Pigeon pigeon) {
        this.pigeon = pigeon;
        method_6265(EnumSet.of(class_4134.field_18405));
    }

    public Pigeon pigeon() {
        return pigeon;
    }

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public boolean method_6264() {
        return pigeon.isDelivering();
    }

    @Override
    public void method_6270() {
        pigeon.setDelivery(null);
        pigeon.method_5942().method_6340();
        pigeon.method_5942().method_23965();
    }

    @Override
    public void method_6268() {
        if (!(pigeon.method_37908() instanceof class_3218 level)) {
            return;
        }

        pigeon.getCurrentDelivery().ifPresent(delivery -> {
            pigeon().getDeliveryHandler().tickDelivery(level, delivery);

            delivery.getRoute().getSegment(delivery.getPhase()).endPos()
                  .ifPresentOrElse(pos -> {
                      if (delivery.getPhase().isDescending()) {
                          class_2680 state = level.method_8320(pos);
                          if (state.method_26204() instanceof MailboxBlock) {
                              pos.method_10093(state.method_11654(MailboxBlock.FACING));
                          }
                      }

                      if ((delivery.getPhase().isAscending() || delivery.getPhase().isDescending())
                            && pigeon.hasReachedTarget(pos)) {
                          // Complete the phase instantly
                          delivery.setPhaseProgress(pigeon().getDeliveryHandler().getPhaseDuration(level, delivery, delivery.getPhase()));
                          return;
                      }

                      if (!pigeon.method_5942().method_23966() || !pos.equals(pigeon.method_5942().method_6355())) {
                          pigeon.pathfindDirectlyTowards(pos);
                      }
                  }, () -> {
                      @Nullable class_243 randomPos = class_5530.method_31504(pigeon, 8, 4, -2,
                            pigeon.method_23317(), pigeon.method_23321(), (float) (Math.PI / 2));
                      if (randomPos != null && level.method_8409().method_43057() < 0.1f) {
                          pigeon.pathfindDirectlyTowards(class_2338.method_49638(randomPos));
                      }
                  });
        });
    }
}