package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.block.mailbox.MailboxBlock;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.AddressFormatter;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.clientbound.OpenAddressTagScreenS2CP;
import io.github.mortuusars.envelope.world.service.MailService;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_5536;

public class AddressTagItem extends class_1792 implements ApplicatorItem {
    public AddressTagItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        @Nullable Address address = stack.method_57824(Envelope.DataComponents.ADDRESS);
        if (address != null) {
            tooltipComponents.add(address.format()
                  .withIcon()
                  .withIconColor(AddressFormatter.NEUTRAL_COLOR)
                  .withColor(AddressFormatter.NEUTRAL_COLOR)
                  .toComponent());
        }
    }

    @Override
    public boolean method_31565(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player) {
        class_1799 target = slot.method_7677();

        if (action != class_5536.field_27014
              || !slot.method_32754(player)
              || !target.method_31573(Envelope.Tags.Items.MAILABLE)) {
            return false;
        }

        @Nullable Address address = stack.method_57824(Envelope.DataComponents.ADDRESS);
        @Nullable Address recipient = Mail.getRecipient(target).orElse(null);
        if (Objects.equals(address, recipient)) {
            return true; // Do nothing
        }

        class_1799 result = target.method_7972();
        Mail.setRecipient(result, address);
        Mail.removePreviousDeliveryData(result);

        if (!slot.method_7680(result)) {
            player.method_5783(class_3417.field_14624.comp_349(), 1, 1);
            return true;
        }

        slot.method_53512(result);

        if (address != null) {
            stack.method_7934(1);
        }

        player.method_5783(class_3417.field_14883.comp_349(), 1, 1);

        return true;
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_2680 state = context.method_8045().method_8320(context.method_8037());
        if (state.method_26204() instanceof MailboxBlock) {
            return class_1269.field_5814; // Let mailbox handle the interaction
        }

        return super.method_7884(context);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        if (player instanceof class_3222 serverPlayer) {
            AllAddresses knownAddresses = MailService.of(serverPlayer.method_51469()).getKnownAddresses();
            Packets.sendToClient(new OpenAddressTagScreenS2CP(usedHand, knownAddresses), serverPlayer);
            player.method_7357().method_7906(this, 6);
        }

        return class_1271.method_29237(player.method_5998(usedHand), level.field_9236);
    }

    @Override
    public boolean shouldRenderTooltipWhileCarrying(class_1937 level, class_1799 carried, class_1799 hovered) {
        return true;
    }
}
