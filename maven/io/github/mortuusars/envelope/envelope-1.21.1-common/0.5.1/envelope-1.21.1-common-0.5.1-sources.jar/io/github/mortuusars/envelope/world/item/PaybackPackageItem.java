package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.world.GameTime;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.mail.entity.mail_service.payback_department.PaybackSubject;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_5632;

public class PaybackPackageItem extends class_1792 {
    public PaybackPackageItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public boolean method_31568() {
        return false;
    }

    @Override
    public @NotNull Optional<class_5632> method_32346(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.PACKAGE_CONTENTS));
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        @Nullable PaybackSubject subject = stack.method_57824(Envelope.DataComponents.PAYBACK_SUBJECT);
        if (subject != null && !subject.mail().method_7960()) {
            tooltipComponents.add(class_2561.method_43470("⌛ ")
                  .method_10852(GameTime.formatLargest(subject.timeoutTick() - Minecrft.level().method_8510(), false))
                  .method_27696(DeliveryRecord.MessageType.NEGATIVE.getStyle()));
        }
    }

    // --

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        stack = stack.method_60503(Envelope.Items.PAYBACK_PACKING_BOX.get());
        player.method_6122(hand, stack);

        ((PaybackPackingBoxItem)stack.method_7909()).openPackingGui(player, hand, stack);

        return class_1271.method_22427(stack);
    }
}