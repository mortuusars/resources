package io.github.mortuusars.envelope.event;

import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public class ServerEvents {
    public static void serverStarted(MinecraftServer server) {
    }

    public static void serverTick(MinecraftServer server) {
    }

    public static void playerLogin(class_3222 player) {
        player.method_51469().getEnvelopeMailService().getPlayers().add(player);
    }
}
