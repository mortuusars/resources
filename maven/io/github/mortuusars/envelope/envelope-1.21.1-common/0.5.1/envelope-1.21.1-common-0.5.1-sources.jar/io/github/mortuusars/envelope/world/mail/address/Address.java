package io.github.mortuusars.envelope.world.mail.address;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.envelope.util.result.Error;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.IntFunction;
import net.minecraft.class_2561;
import net.minecraft.class_3542;
import net.minecraft.class_5250;
import net.minecraft.class_7995;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public interface Address {
    int MAX_LENGTH = 40;

    Codec<String> ID_CODEC = Codec.STRING.xmap(String::trim, String::trim).validate(Address::validate);
    Codec<Address> CODEC = Type.CODEC.dispatch(Address::type, Type::getCodec);
    class_9139<class_9129, Address> STREAM_CODEC = Type.STREAM_CODEC.method_56440(Address::type, Type::getStreamCodec);

    Address.Entity MAIL_SERVICE = new Entity("Mail Service", class_2561.method_43471("address.envelope.mail_service"));
    Address UNKNOWN = new Entity("Unknown", class_2561.method_43471("address.envelope.unknown"));

    Type type();

    String id();

    /**
     * @return "Display" name of an address. For Block and Player addresses that's just id.<br>
     * Entity address returns its translation, if present.
     */
    String toString();

    /**
     * @return "Display" name of an address. For Block and Player addresses that's just id.<br>
     * Entity address returns its translation, if present.
     */
    default class_5250 getName() {
        return class_2561.method_43470(id());
    }

    // --

    /**
     * Compares "display" name of a current address to the given string (ignoring the case).<br>
     * Nothing special for Block and Player addresses, but Entity address will be compared by its translation, if present.
     *
     * @return {@code true} if names look the same (ignoring the case).
     */
    default boolean matches(String name) {
        return toString().equalsIgnoreCase(name);
    }

    /**
     * Shortcut for {@link Address#matches(String)}
     */
    default boolean matches(Address address) {
        return matches(address.toString());
    }

    // --

    default AddressFormatter format() {
        return AddressFormatter.of(this);
    }

    default <R> R map(Function<Block, R> ifBlock, Function<Player, R> ifPlayer, Function<Entity, R> ifEntity) {
        return switch (this) {
            case Block block -> ifBlock.apply(block);
            case Player player -> ifPlayer.apply(player);
            case Entity entity -> ifEntity.apply(entity);
            default -> throw new IllegalStateException("Unknown type of address. " + this.getClass());
        };
    }

    // --

    static @NotNull DataResult<String> validate(String id) {
        return AddressValidation.id()
              .test(id)
              .map(DataResult::success, Error::asDataResult);
    }

    // --

    enum Type implements class_3542 {
        BLOCK(0, "block", Block.CODEC, Block.STREAM_CODEC),
        PLAYER(1, "player", Player.CODEC, Player.STREAM_CODEC),
        ENTITY(2, "entity", Entity.CODEC, Entity.STREAM_CODEC);

        public static final Codec<Type> CODEC = class_3542.method_28140(Type::values);
        public static final IntFunction<Type> BY_ID = class_7995.method_47914(Type::getId, values(), class_7995.class_7996.field_41664);
        public static final class_9139<class_9129, Type> STREAM_CODEC = class_9135.method_56375(BY_ID, Type::ordinal).method_56430();

        private final int id;
        private final String name;
        private final MapCodec<? extends Address> codec;
        private final class_9139<class_9129, ? extends Address> streamCodec;

        Type(int id, String name, MapCodec<? extends Address> codec, class_9139<class_9129, ? extends Address> streamCodec) {
            this.id = id;
            this.name = name;
            this.codec = codec;
            this.streamCodec = streamCodec;
        }

        public int getId() {
            return id;
        }

        @Override
        public @NotNull String method_15434() {
            return name;
        }

        public MapCodec<? extends Address> getCodec() {
            return codec;
        }

        public class_9139<class_9129, ? extends Address> getStreamCodec() {
            return streamCodec;
        }

        public class_5250 translate() {
            return class_2561.method_43471("address.envelope.type." + method_15434());
        }
    }

    record Block(String id) implements Address {
        public static final MapCodec<Block> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
              ID_CODEC.fieldOf("id").forGetter(Block::id)
        ).apply(instance, Block::new));

        public static final Codec<Block> STRING_CODEC = Codec.STRING.xmap(Block::new, Block::id);

        public static final class_9139<class_9129, Block> STREAM_CODEC =
              class_9135.field_48554.method_56432(Block::new, Block::id).method_56430();

        public Block {
            validate(id).getOrThrow();
        }

        @Override
        public Type type() {
            return Type.BLOCK;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Block that = (Block) o;
            return this.id.equalsIgnoreCase(that.id);
        }

        @Override
        public int hashCode() {
            return ("b" + id.toLowerCase(Locale.ROOT)).hashCode();
        }

        @Override
        public String toString() {
            return id;
        }
    }

    record Player(String id) implements Address {
        public static final MapCodec<Player> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
              ID_CODEC.fieldOf("id").forGetter(Player::id)
        ).apply(instance, Player::new));

        public static final class_9139<class_9129, Player> STREAM_CODEC =
              class_9135.field_48554.method_56432(Player::new, Player::id).method_56430();

        public Player {
            validate(id).getOrThrow();
        }

        public Player(net.minecraft.class_1657 player) {
            this(player.method_5820());
        }

        @Override
        public Type type() {
            return Type.PLAYER;
        }

        @Override
        public String toString() {
            return id;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Player that = (Player) o;
            return this.id.equalsIgnoreCase(that.id);
        }

        @Override
        public int hashCode() {
            return ("p" + id.toLowerCase(Locale.ROOT)).hashCode();
        }
    }

    /**
     * Due to how address matching is implemented (by display name), and how choosing address in GUIs, etc, works -<br>
     * using translations in Entity addresses works as it should.<br>
     */
    record Entity(String id, Optional<class_2561> displayName) implements Address {
        public static final MapCodec<Entity> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
              ID_CODEC.fieldOf("id").forGetter(Entity::id),
              class_8824.field_46597.optionalFieldOf("display_name").forGetter(Entity::displayName)
        ).apply(instance, Entity::new));

        public static final class_9139<class_9129, Entity> STREAM_CODEC = class_9139.method_56435(
              class_9135.field_48554, Entity::id,
              class_9135.method_56382(class_8824.field_48540), Entity::displayName,
              Entity::new
        );

        public Entity {
            validate(id).getOrThrow();
        }

        public Entity(String id, @NotNull class_2561 displayName) {
            this(id, Optional.of(displayName));
        }

        public Entity(String id) {
            this(id, Optional.empty());
        }

        @Override
        public Type type() {
            return Type.ENTITY;
        }

        @Override
        public class_5250 getName() {
            return displayName.map(class_2561::method_27662).orElseGet(Address.super::getName);
        }

        @Override
        public String toString() {
            return getName().getString();
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Entity that = (Entity) o;
            return this.id.equalsIgnoreCase(that.id);
        }

        @Override
        public int hashCode() {
            return ("e" + id.toLowerCase(Locale.ROOT)).hashCode();
        }
    }
}
