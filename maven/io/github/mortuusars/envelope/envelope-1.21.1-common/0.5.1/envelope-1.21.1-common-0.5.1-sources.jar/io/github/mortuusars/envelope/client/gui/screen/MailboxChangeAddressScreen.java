package io.github.mortuusars.envelope.client.gui.screen;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.client.util.Minecrft;
import io.github.mortuusars.envelope.world.mail.address.Address;
import io.github.mortuusars.envelope.world.mail.address.AllAddresses;
import io.github.mortuusars.envelope.network.Packets;
import io.github.mortuusars.envelope.network.packet.serverbound.MailboxAddressTagApplyC2SP;
import io.github.mortuusars.envelope.world.item.AddressTagItem;
import java.util.Optional;
import net.minecraft.class_1109;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class MailboxChangeAddressScreen extends AbstractMailboxAddressScreen {
    protected final class_2338 pos;
    protected final class_2680 state;
    protected final class_2586 blockEntity;

    public MailboxChangeAddressScreen(class_1268 hand, AllAddresses knownAddresses,
                                      class_2338 pos, Address.Block existingAddress,
                                      class_2561 title) {
        super(hand, knownAddresses, Optional.ofNullable(existingAddress), title);
        this.pos = pos;
        this.state = player.method_37908().method_8320(pos);
        this.blockEntity = player.method_37908().method_8321(pos);
    }

    @Override
    protected class_1799 getTargetPreview() {
        return new class_1799(state.method_26204().method_8389());
    }

    @Override
    protected void onConfirm() {
        Minecrft.get().method_1483().method_4873(class_1109.method_4758(class_3417.field_17484, 1f));
        if (Config.Server.MAILBOX_ADDRESS_EXPERIENCE_LEVELS_COST.get() > 0) {
            player.method_37908().method_45447(player, pos, class_3417.field_15119, class_3419.field_15245);
        }
        Packets.sendToServer(new MailboxAddressTagApplyC2SP(hand, getCurrentAddressId().trim(), pos));
    }

    @Override
    protected boolean stillValid() {
        return player.method_5998(hand).method_7909() instanceof AddressTagItem
              && class_1263.method_49105(blockEntity, player);
    }
}