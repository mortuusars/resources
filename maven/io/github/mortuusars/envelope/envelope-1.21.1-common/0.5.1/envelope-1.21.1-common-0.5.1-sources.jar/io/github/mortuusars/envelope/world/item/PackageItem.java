package io.github.mortuusars.envelope.world.item;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.item.component.PackageContents;
import io.github.mortuusars.envelope.world.item.component.seal.Seal;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1277;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_173;
import net.minecraft.class_174;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5632;
import net.minecraft.class_8567;
import net.minecraft.class_9297;
import net.minecraft.class_9334;
import net.minecraft.world.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

public class PackageItem extends class_1747 implements PackingBox, Sealable {
    public PackageItem(class_2248 block, class_1793 properties) {
        super(block, properties);
    }

    @Override
    public boolean method_31568() {
        return false;
    }

    @Override
    public @NotNull Optional<class_5632> method_32346(class_1799 stack) {
        return Optional.ofNullable(stack.method_57824(Envelope.DataComponents.PACKAGE_CONTENTS));
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> components, class_1836 tooltipFlag) {
        super.method_7851(stack, context, components, tooltipFlag);

        if (shouldBeDestroyedWhenEmpty(stack)) {
            components.add(class_2561.method_43470("⚠").method_54663(0xFFE48174));
        }

        @Nullable class_9297 loot = stack.method_57824(class_9334.field_49626);
        if (tooltipFlag.method_8035() && loot != null) {
            components.add(class_2561.method_43470("Loot Table: ").method_27692(class_124.field_1063)
                  .method_10852(class_2561.method_43470(loot.comp_2414().method_29177().toString()).method_27692(class_124.field_1063)));
        }
    }

    // --

    @Override
    public int method_7881(class_1799 stack, class_1309 entity) {
        return Config.Server.PACKAGE_LAST_OPEN_ANIMATION.get() && shouldBeDestroyedWhenEmpty(stack) ? 15 : 0;
    }

    @Override
    public @NotNull class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8950;
    }

    @Override
    public @NotNull class_3414 method_21830() {
        return Envelope.SoundEvents.PAPER_TEAR.get();
    }

    // --

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        if (!context.method_8046()) {
            return class_1269.field_5811;
        }
        return super.method_7884(context);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (Config.Server.PACKAGE_LAST_OPEN_ANIMATION.get() && shouldBeDestroyedWhenEmpty(stack)) {
            player.method_6019(hand);
            return class_1271.method_22427(stack);
        } else {
            return class_1271.method_22427(open(level, player, hand, stack));
        }
    }

    @Override
    public @NotNull class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 entity) {
        if (entity instanceof class_1657 player) {
            return open(level, player, player.method_6058(), stack);
        }
        return super.method_7861(stack, level, entity);
    }

    // --

    protected class_1799 open(class_1937 level, class_1657 player, class_1268 hand, class_1799 stack) {
        stack = stack.method_60503(Envelope.Items.PACKING_BOX.get());
        Mail.removePreviousDeliveryData(stack);

        unpackLootTableIfPresent(stack, level, player.method_24515(), player);

        level.method_43129(player, player, Envelope.SoundEvents.PAPER_TEAR.get(), class_3419.field_15248, 1, 1);

        if (stack.method_7909() instanceof PackingBoxItem packingBox) {
            packingBox.openPackingGui(player, hand, stack);
        } else {
            Envelope.LOGGER.error("Cannot open packing box gui. Stack {} is not a PackingBoxItem.", stack.method_7964().getString());
        }
        return stack;
    }

    protected void unpackLootTableIfPresent(class_1799 stack, class_1937 level, class_2338 pos, @Nullable class_1657 player) {
        @Nullable class_9297 loot = stack.method_57824(class_9334.field_49626);
        if (level instanceof class_3218 serverLevel && loot != null) {
            class_5321<class_52> table = loot.comp_2414();
            class_52 lootTable = serverLevel.method_8503().method_58576().method_58295(table);

            class_8567.class_8568 builder = new class_8567.class_8568(serverLevel)
                  .method_51874(class_181.field_24424, class_243.method_24953(pos));

            if (player != null) {
                builder.method_51871(player.method_7292()).method_51874(class_181.field_1226, player);
            }

            class_1277 container = new class_1277(PackageContents.SLOTS);
            lootTable.method_329(container, builder.method_51875(class_173.field_1179), loot.comp_2415());

            if (stack.method_57826(Envelope.DataComponents.PACKAGE_CONTENTS)) {
                Envelope.LOGGER.warn("Unpacking container loot into the Package, that already has contents inside. " +
                      "Loot will override the contents.");
            }

            if (player instanceof class_3222 serverPlayer) {
                class_174.field_24479.method_27993(serverPlayer, table);
            }

            stack.method_57381(class_9334.field_49626);
            stack.method_57379(Envelope.DataComponents.PACKAGE_CONTENTS, PackageContents.createFrom(container));
        }
    }

    public List<class_1799> unpack(class_1799 stack, class_1937 level, class_2338 pos, @Nullable class_1657 player) {
        unpackLootTableIfPresent(stack, level, pos, player);
        PackageContents contents = stack.method_57825(Envelope.DataComponents.PACKAGE_CONTENTS, PackageContents.EMPTY);
        stack.method_57381(Envelope.DataComponents.PACKAGE_CONTENTS);
        return contents.copyItems();
    }

    // --

    @Override
    public class_1799 seal(class_1937 level, class_1799 stack, Seal seal) {
        class_1799 sealedLetter = stack.method_60503(Envelope.Items.SEALED_PACKAGE.get());
        sealedLetter.method_57379(Envelope.DataComponents.SEAL, seal);
        return sealedLetter;
    }
}