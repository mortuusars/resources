package io.github.mortuusars.envelope.util.bugger_data;

import io.github.mortuusars.envelope.util.bugger.Bugger;
import io.github.mortuusars.envelope.util.bugger.page.BuggerPage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

public class EnvelopeBuggerPage implements BuggerPage {
    @Override
    public String getTitle() {
        return "Envelope";
    }

    @Override
    public List<String> getLeftLines() {
        return Bugger.MAIL_SERVICE.get()
              .map(tag -> {
                  int realPigeons = tag.method_10550("delivering_pigeons");
                  int backgroundPigeons = tag.method_10550("background_delivering_pigeons");
                  int backgroundFinishedPigeons = tag.method_10550("background_finished_pigeons");

                  List<String> lines = new ArrayList<>(List.of(
                        "Mailboxes: " + tag.method_10550("mailboxes"),
                        "",
                        "Mail Awaiting Payback: " + tag.method_10550("payback_pending_mail"),
                        "",
                        "Couriers:",
                        "  Real: " + realPigeons,
                        "  Background: " + backgroundPigeons,
                        "  Finished: " + backgroundFinishedPigeons,
                        ""
                  ));



                  class_2499 deliveries = tag.method_10554("deliveries", class_2520.field_33258);
                  if (!deliveries.isEmpty()) {
                      lines.add("Deliveries:");
                      for (class_2520 delivery : deliveries) {
                          lines.add("  " + delivery.method_10714());
                      }
                  }

                  return lines;
              })
              .orElse(Collections.emptyList());
    }
}
