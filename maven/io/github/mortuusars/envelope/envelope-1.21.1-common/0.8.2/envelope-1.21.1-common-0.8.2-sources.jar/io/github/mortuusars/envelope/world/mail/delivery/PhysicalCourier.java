package io.github.mortuusars.envelope.world.mail.delivery;

import io.github.mortuusars.envelope.Config;
import io.github.mortuusars.envelope.Envelope;
import io.github.mortuusars.envelope.world.Position;
import io.github.mortuusars.envelope.world.entity.ai.CourierNavigation;
import io.github.mortuusars.envelope.world.entity.ai.MailboxHandler;
import io.github.mortuusars.envelope.world.item.component.mail.log.DeliveryRecord;
import io.github.mortuusars.envelope.world.item.mail.Mail;
import io.github.mortuusars.envelope.world.mail.delivery.background.BackgroundCourier;
import io.github.mortuusars.envelope.world.entity.spawning.SpawnableEntityData;
import io.github.mortuusars.envelope.world.mail.MailService;
import io.github.mortuusars.mortaar.util.Ticks;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1314;
import net.minecraft.class_1408;
import net.minecraft.class_1429;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5531;

public interface PhysicalCourier extends Courier {
    SpawnableEntityData toSpawnableCourierData();

    MailboxHandler getMailboxHandler();

    void setMailboxHandler(MailboxHandler mailboxHandler);

    void setDelivery(Delivery delivery);

    default boolean canStartDelivery() {
        return true;
    }

    default void startDelivery(Delivery delivery) {
        if (getCurrentDelivery().isPresent()) {
            LOGGER.warn("Starting new delivery when the courier is already delivering. This might be an error.");
        }
        setDelivery(delivery);
        asEntity().method_5848();
    }

    @Override
    default int getPhaseDuration(class_3218 level, Delivery delivery, DeliveryPhase phase) {
        return switch (phase) {
            // Longer approach/depart phases to allow for pathfinding to finish
            case DEPARTING_SENDER, APPROACHING_RECIPIENT, DEPARTING_RECIPIENT, APPROACHING_SENDER ->
                  class_3532.method_15386(Ticks.fromSeconds(40) * (Config.Server.DELIVERY_ASCEND_DISTANCE.get() / 24f));
            default -> Courier.super.getPhaseDuration(level, delivery, phase);
        };
    }

    @Override
    default void phaseStarted(class_3218 level, Delivery delivery) {
        Courier.super.phaseStarted(level, delivery);
        if (delivery.getPhase().isTraveling()) {
            if (asEntity().method_31481()) {
                LOGGER.error("Cannot transition entity to background: entity is removed.");
                asEntity().method_31472();
                return;
            }
            if (asEntity().method_5765()) {
                LOGGER.error("Cannot transition entity to background: entity is passenger.");
                asEntity().method_31472();
                return;
            }
            transitionToBackground(level);
        }
        onDeliveryChanged();
    }

    default void onDeliveryChanged() {
    }

    @Override
    default boolean handlePhaseTransition(class_3218 level, Delivery delivery) {
        if (delivery.getPhase() == DeliveryPhase.DEPARTING_SENDER && !hasReachedSegmentEndPos(delivery)) {
            Mail.returned(delivery.getMail(), DeliveryRecord.Message.UNABLE_TO_REACH);
            delivery.beginPhase(DeliveryPhase.APPROACHING_SENDER);
            return true;
        }

        if (delivery.getPhase() == DeliveryPhase.APPROACHING_RECIPIENT && !hasReachedSegmentEndPos(delivery)) {
            Mail.returned(delivery.getMail(), DeliveryRecord.Message.UNABLE_TO_REACH);
            delivery.beginPhase(DeliveryPhase.DEPARTING_RECIPIENT);
            return true;
        }

        return Courier.super.handlePhaseTransition(level, delivery);
    }

    default void diedWhileDelivering(class_3218 level, class_1282 damageSource, Delivery delivery) {
        class_1314 entity = asEntity();

        String message = damageSource.method_5506(entity).getString();
        String carriedItem = !delivery.getMail().method_7960()
              ? " a " + delivery.getMail().method_7964().getString()
              : "";
        String addresses = delivery.getSender().getString()
              + " to "
              + delivery.getRecipient().getString();
        String service = getCourierOrigin().isService() ? "Service " : "";
        Envelope.LOGGER.info("{}{} at [{}] while delivering{} from {}!", service, message, entity.method_24515().method_23854(), carriedItem, addresses);

        if (shouldSendDeathNotice()) {
            MailService.of(level).sendCourierDeathNotice(entity, delivery, damageSource);
        }

        if (!delivery.getMail().method_7960()) {
            class_1799 mail = delivery.getPhase().isOnRecipientSide()
                  ? Mail.asDelivered(delivery.getMail())
                  : delivery.getMail();
            entity.method_5775(mail);
            delivery.setMail(class_1799.field_8037);
        }
    }

    default boolean shouldSendDeathNotice() {
        return !getCourierOrigin().isService();
    }

    default boolean canEat(class_1799 food) {
        return asEntity() instanceof class_1429 animal && animal.method_6481(food);
    }

    default BackgroundCourier transitionToBackground(class_3218 level) {
        Delivery delivery = getCurrentDelivery().orElseThrow(() -> new IllegalStateException("Cannot transition: courier is not delivering."));
        BackgroundCourier backgroundCourier = new BackgroundCourier(toSpawnableCourierData(), getCourierProperties(), getCourierOrigin(), delivery);
        MailService.of(level).getBackgroundDelivery().addCourier(backgroundCourier);
        onVanished(level);
        ((class_1297) this).method_31472();
        return backgroundCourier;
    }

    default void onAppeared(class_3218 level) {
        class_243 pos = ((class_1297) this).method_19538();
        sendLongDistanceParticles(level, getTransitionParticle(), pos.field_1352, pos.field_1351, pos.field_1350, 16, 0.1, 0.1, 0.1, 0.05);
        level.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, Envelope.SoundEvents.COURIER_APPEARED.get(), class_3419.field_15254, 1, 1);
    }

    default class_2394 getTransitionParticle() {
        return class_2398.field_11204;
    }

    default void onVanished(class_3218 level) {
        class_243 pos = ((class_1297) this).method_19538();
        sendLongDistanceParticles(level, getTransitionParticle(), pos.field_1352, pos.field_1351, pos.field_1350, 16, 0.1, 0.1, 0.1, 0.05);
        level.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, Envelope.SoundEvents.COURIER_DISAPPEARED.get(), class_3419.field_15254, 1, 1);
    }

    default <T extends class_2394> void sendLongDistanceParticles(class_3218 level, T type, double posX, double posY, double posZ,
                                                                       int particleCount, double xOffset, double yOffset, double zOffset, double speed) {
        for (class_3222 player : level.method_18456()) {
            level.method_14166(player, type, true, posX, posY, posZ, particleCount,
                  (float) xOffset, (float) yOffset, (float) zOffset, (float) speed);
        }
    }

    default class_1314 asEntity() {
        return (class_1314) this;
    }

    default boolean hasReachedTarget(class_2338 localPos) {
        return CourierNavigation.hasReachedTarget(this, localPos, CourierNavigation.getReachDistance());
    }

    default boolean hasReachedTarget(class_2338 localPos, double distance) {
        return CourierNavigation.hasReachedTarget(this, localPos, distance);
    }

    default boolean hasReachedSegmentEndPos(Delivery delivery) {
        return delivery.getRoute().getSegment(delivery.getPhase()).endPos()
              .map(endPos -> hasReachedTarget(
                    CourierNavigation.getSegmentApproachTarget(asEntity().method_37908(), endPos, delivery.getPhase())))
              .orElse(true);
    }

    default boolean closerThan(class_2338 localPos, double distance) {
        return CourierNavigation.isWithinReach(this, localPos, distance);
    }

    default boolean pathfindDirectlyTowards(class_2338 localPos) {
        class_2338 navigationPos = CourierNavigation.getNavigationPos(this, localPos);
        class_1408 navigation = asEntity().method_5942();
        navigation.method_23964(10.0F);
        navigation.method_58160(navigationPos.method_10263(), navigationPos.method_10264(), navigationPos.method_10260(), 1, 1);
        return navigation.method_6345() != null && navigation.method_6345().method_21655();
    }

    default void pathfindRandomlyTowards(class_2338 localPos) {
        class_1314 entity = asEntity();

        class_243 vec3 = Position.getGlobalCenter(entity.method_37908(), localPos).method_1023(0, 0.5, 0);
        int i = 0;
        class_2338 blockPos = entity.method_24515();
        int j = (int) vec3.field_1351 - blockPos.method_10264();
        if (j > 2) {
            i = 4;
        } else if (j < -2) {
            i = -4;
        }

        int k = 6;
        int l = 8;
        int m = blockPos.method_19455(Position.getNavigationPos(entity.method_37908(), localPos));
        if (m < 15) {
            k = m / 2;
            l = m / 2;
        }

        class_243 pos = class_5531.method_31508(entity, k, l, i, vec3, (float) (Math.PI / 10));
        if (pos != null) {
            entity.method_5942().method_23964(1.0F);
            entity.method_5942().method_6337(pos.field_1352, pos.field_1351, pos.field_1350, 1);
        }
    }
}