package io.github.mortuusars.horseman.world.summoning;

import com.google.common.base.Preconditions;
import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import net.minecraft.class_11352;
import net.minecraft.class_11368;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1324;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7444;
import net.minecraft.class_8942;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public class Summoning {
    protected final SummoningStorage storage;

    public Summoning(MinecraftServer server) {
        storage = server.method_30002().method_17983().method_17924(SummoningStorage.TYPE);
    }

    public SummoningStorage getStorage() {
        return storage;
    }

    public boolean isBound(class_1496 horse) {
        return horse.getHorsemanBoundData() != null;
    }

    public @Nullable StoredBoundHorse getBoundHorse(UUID owner, class_5321<class_7444> instrument) {
        return getStorage().getBoundHorses().getOrDefault(owner, Collections.emptyMap()).get(instrument);
    }

    public @Nullable StoredBoundHorse getBoundHorse(class_1657 owner, class_5321<class_7444> instrument) {
        return getBoundHorse(owner.method_5667(), instrument);
    }

    public Map<class_5321<class_7444>, StoredBoundHorse> getStoredHorsesOf(UUID owner) {
        return getStorage().getBoundHorses().computeIfAbsent(owner, id -> new HashMap<>());
    }

    public Map<class_5321<class_7444>, StoredBoundHorse> getStoredHorsesOf(class_1657 owner) {
        return getStoredHorsesOf(owner.method_5667());
    }

    protected void addOrUpdateBoundHorse(class_1496 horse) {
        @Nullable BoundData data = horse.getHorsemanBoundData();
        if (data == null) {
            Horseman.LOGGER.warn("Tried to update a horse that does not have a bound data. Horse: {}", horse);
            return;
        }
        getStoredHorsesOf(data.owner()).put(data.instrument(), new StoredBoundHorse(horse));
        getStorage().method_80();
    }

    // --

    public void bind(class_3218 level, class_1496 horse, class_1657 player, class_5321<class_7444> instrument) {
        unbindExistingHorse(level, player, instrument);
        horse.setHorsemanBoundData(new BoundData(player, instrument));
        addOrUpdateBoundHorse(horse);
    }

    public void unbindHorse(class_3218 level, StoredBoundHorse boundHorse) {
        boundHorse.boundData().ifPresent(data -> {
            getStoredHorsesOf(data.owner()).remove(data.instrument());
        });
        if (tryFindLoadedHorse(level, boundHorse.uuid()) instanceof class_1496 loadedHorse) {
            loadedHorse.setHorsemanBoundData(null);
        } else {
            getStorage().getUnboundHorses().add(boundHorse.uuid());
        }
        getStorage().method_80();
    }

    public void unbindExistingHorse(class_3218 level, class_1657 player, class_5321<class_7444> instrument) {
        @Nullable StoredBoundHorse boundHorse = getBoundHorse(player, instrument);
        if (boundHorse != null) {
            unbindHorse(level, boundHorse);
        }
    }

    // -- Calling

    public CallResult call(class_3222 player, class_5321<class_7444> instrument) {
        class_3218 level = player.method_51469();
        @Nullable StoredBoundHorse boundHorse = getBoundHorse(player, instrument);

        if (boundHorse == null) return CallResult.NO_BOUND_HORSE;
        if (boundHorse.isDead()) return CallResult.HORSE_IS_DEAD;

        @Nullable class_1496 existingHorse = tryFindLoadedHorse(level, boundHorse.uuid());
        if (existingHorse != null) {
            if (!isBound(existingHorse)) {
                return CallResult.ERROR_HORSE_IS_NOT_BOUND;
            }

            addOrUpdateBoundHorse(existingHorse); // Update before calling to have the latest state
            boundHorse = getBoundHorse(player, instrument); // Re-query updated state
            Preconditions.checkNotNull(boundHorse); // Should not be null as we check if the horse isBound above.
        }

        if (!dimensionsAreValid(player, boundHorse)) return CallResult.INVALID_DIMENSION;
        if (!isInRange(player, boundHorse)) return CallResult.TOO_FAR;

        if (existingHorse != null && canWalkInsteadOfResummoning(player, existingHorse)) {
            return walkToPlayer(player, existingHorse);
        }

        return summonHorse(player, boundHorse);
    }

    protected CallResult walkToPlayer(class_3222 player, class_1496 horse) {
        class_1324 followRangeAttribute = horse.method_5996(class_5134.field_23717);
        if (followRangeAttribute != null) {
            followRangeAttribute.method_6192(Config.Server.HORSE_SUMMONING_MAX_WALKING_DISTANCE.get());
        }

        horse.method_5942().method_6335(player, Config.Server.HORSE_SUMMONING_WALK_MOVEMENT_SPEED.get());
        addOrUpdateBoundHorse(horse);

        Horseman.CriteriaTriggers.HORSE_SUMMONED.get().trigger(player, horse);

        return CallResult.SUCCESS;
    }

    protected CallResult summonHorse(class_3222 player, @NotNull StoredBoundHorse boundHorse) {
        class_3218 level = player.method_51469();

        class_11368 input = class_11352.method_71417(class_8942.field_60348, level.method_30349(), boundHorse.tag());
        Optional<class_1299<?>> type = class_1299.method_17684(input);
        if (type.isEmpty()) {
            Horseman.LOGGER.error("Failed to get the type from a stored boundHorse data. " +
                    "'id' probably wasn't saved properly. Tag '{}'.", boundHorse.tag());
            return CallResult.ERROR_ENTITY_NOT_CREATED;
        }

        @Nullable class_1297 entity = type.get().method_5883(player.method_51469(), class_3730.field_16471);
        if (!(entity instanceof class_1496 newHorse)) {
            Horseman.LOGGER.error("Created entity isn't an AbstractHorse but {}. Something went wrong.", entity);
            return CallResult.ERROR_ENTITY_NOT_CREATED;
        }

        newHorse.method_5651(input);
        newHorse.method_5826(UUID.randomUUID());
        newHorse.method_5814(player.method_23317(), player.method_23318(), player.method_23321());

        if (!hasSpaceFor(level, player, newHorse)) return CallResult.NO_SPACE;

        player.method_51469().method_8649(newHorse);

        removeOldBoundHorse(level, boundHorse);
        addOrUpdateBoundHorse(newHorse);

        Horseman.CriteriaTriggers.HORSE_SUMMONED.get().trigger(player, newHorse);

        return CallResult.SUCCESS;
    }

    // -- Conditions

    protected boolean dimensionsAreValid(class_1657 player, StoredBoundHorse boundHorse) {
        return switch (Config.Server.HORSE_SUMMONING_DIMENSION_HANDLING.get()) {
            case ANY -> true;
            case SAME -> boundHorse.isInSameDimension(player);
            case WHITELIST -> {
                String playerDimension = player.method_37908().method_27983().method_29177().toString();
                yield Config.Server.HORSE_SUMMONING_DIMENSIONS.get().stream()
                        .anyMatch(dimension -> dimension.equals(playerDimension));
            }
            case BLACKLIST -> {
                String playerDimension = player.method_37908().method_27983().method_29177().toString();
                yield Config.Server.HORSE_SUMMONING_DIMENSIONS.get().stream()
                        .noneMatch(dimension -> dimension.equals(playerDimension));
            }
        };
    }

    protected boolean isInRange(class_1657 player, StoredBoundHorse boundHorse) {
        int maxDistance = Config.Server.HORSE_SUMMONING_MAX_DISTANCE.get();
        if (maxDistance < 0) return true;
        int distance = (int) boundHorse.position().method_1022(player.method_19538());
        return distance <= maxDistance;
    }

    protected boolean canWalkInsteadOfResummoning(class_1657 player, class_1496 horse) {
        return player.method_37908().method_27983().equals(horse.method_37908().method_27983())
                && player.method_5739(horse) < Config.Server.HORSE_SUMMONING_MAX_WALKING_DISTANCE.get();
    }

    protected boolean hasSpaceFor(class_3218 level, class_1657 player, class_1496 horse) {
        StoredBoundHorse boundHorse = new StoredBoundHorse(horse);
        class_11368 input = class_11352.method_71417(class_8942.field_60348, level.method_30349(), boundHorse.tag());
        Optional<class_1299<?>> type = class_1299.method_17684(input);
        if (type.isEmpty()) return false;

        @Nullable class_1297 entity = type.get().method_5883(player.method_37908(), class_3730.field_16471);
        if (!(entity instanceof class_1496 newHorse)) return false;

        newHorse.method_5651(input);
        newHorse.method_5826(UUID.randomUUID());
        newHorse.method_5814(player.method_23317(), player.method_23318(), player.method_23321());

        return !newHorse.method_5757();
    }

    // -- Events

    public boolean onHorseLoaded(class_3218 level, class_1496 horse) {
        if (!isBound(horse)) return false;

        UUID entityUUID = horse.method_5667();

        if (getStorage().getHorsesToRemove().contains(entityUUID)) {
            getStorage().getHorsesToRemove().remove(entityUUID);
            getStorage().getUnboundHorses().remove(entityUUID);
            horse.method_5772();
            return true; // Prevent loading
        }

        if (getStorage().getUnboundHorses().contains(entityUUID)) {
            horse.setHorsemanBoundData(null);
            getStorage().getUnboundHorses().remove(entityUUID);
        }

        getStorage().method_80();

        return false;
    }

    // Also called when horse has died.
    public void onHorseUnloaded(class_3218 level, class_1496 horse) {
        if (isBound(horse)) {
            addOrUpdateBoundHorse(horse);
            if (horse.method_29504() && horse.method_5797() == null) {
                Horseman.LOGGER.info("Bound horse has died at [{}, {}, {}].", (int)horse.method_23317(), (int)horse.method_23318(), (int)horse.method_23321());
            }
        }
    }

    // -- Util

    protected @Nullable class_1496 tryFindLoadedHorse(class_3218 level, UUID entityUuid) {
        for (class_3218 dimension : level.method_8503().method_3738()) {
            if (dimension.method_66347(entityUuid) instanceof class_1496 horse) {
                return horse;
            }
        }
        return null;
    }

    protected void removeOldBoundHorse(class_3218 level, @NotNull StoredBoundHorse boundHorse) {
        boolean removed = false;

        // Remove already loaded horse immediately:
        for (class_3218 dimension : level.method_8503().method_3738()) {
            @Nullable class_1297 existingHorse = dimension.method_66347(boundHorse.uuid());
            if (existingHorse != null) {
                existingHorse.method_31472();
                removed = true;
                break;
            }
        }

        if (!removed) {
            // Old entity will be removed when it tries to load:
            getStorage().getHorsesToRemove().add(boundHorse.uuid());
        }

        getStorage().method_80();
    }
}
