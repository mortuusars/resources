package io.github.mortuusars.horseman.world.summoning;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.*;
import net.minecraft.class_10741;
import net.minecraft.class_18;
import net.minecraft.class_4844;
import net.minecraft.class_5321;
import net.minecraft.class_7444;
import net.minecraft.class_7924;

public class SummoningStorage extends class_18 {
    public static final Codec<Map<class_5321<class_7444>, StoredBoundHorse>> PLAYER_HORSES_CODEC =
            Codec.unboundedMap(class_5321.method_39154(class_7924.field_41275), StoredBoundHorse.CODEC);

    public static final Codec<SummoningStorage> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.unboundedMap(class_4844.field_25122, PLAYER_HORSES_CODEC).optionalFieldOf("bound_horses", new HashMap<>()).forGetter(SummoningStorage::getBoundHorses),
            Codec.list(class_4844.field_25122).optionalFieldOf("unbound_horses", new ArrayList<>()).forGetter(SummoningStorage::getUnboundHorses),
            Codec.list(class_4844.field_25122).optionalFieldOf("horses_to_remove", new ArrayList<>()).forGetter(SummoningStorage::getHorsesToRemove)
    ).apply(instance, SummoningStorage::new));

    @SuppressWarnings("DataFlowIssue")
    public static final class_10741<SummoningStorage> TYPE = new class_10741<>(
            "horseman_horse_calling",
            SummoningStorage::new,
            CODEC,
            null // Thanks mojang for mod-friendly code
    );

    protected final Map<UUID, Map<class_5321<class_7444>, StoredBoundHorse>> boundHorses;
    protected final List<UUID> unboundHorses;
    protected final List<UUID> horsesToRemove;

    private SummoningStorage(Map<UUID, Map<class_5321<class_7444>, StoredBoundHorse>> boundHorses,
                             List<UUID> unboundHorses, List<UUID> horsesToRemove) {
        this.boundHorses = boundHorses;
        this.unboundHorses = unboundHorses;
        this.horsesToRemove = horsesToRemove;
        method_80();
    }

    private SummoningStorage() {
        this(new HashMap<>(), new ArrayList<>(), new ArrayList<>());
        method_80();
    }

    // --

    public Map<UUID, Map<class_5321<class_7444>, StoredBoundHorse>> getBoundHorses() {
        return boundHorses;
    }

    public List<UUID> getUnboundHorses() {
        return unboundHorses;
    }

    public List<UUID> getHorsesToRemove() {
        return horsesToRemove;
    }


    // --

//    public static @NotNull SummoningStorage loadOrCreate(MinecraftServer server) {
//        return server.overworld().getDataStorage().computeIfAbsent(SummoningStorage.factory(), "horseman_horse_calling");
//    }

//    private static DataProvider.Factory<SummoningStorage> factory() {
//        return new DataProvider.Factory<>(SummoningStorage::new, SummoningStorage::load, null);
//    }

//    private static SummoningStorage load(CompoundTag tag, HolderLookup.Provider provider) {
//        try {
//            CompoundTag boundHorsesTag = tag.getCompound("BoundHorses");
//            Map<UUID, Map<ResourceKey<Instrument>, StoredBoundHorse>> boundHorses = new HashMap<>();
//            for (String uuidStr : boundHorsesTag.getAllKeys()) {
//                UUID uuid = UUID.fromString(uuidStr);
//                CompoundTag innerTag = boundHorsesTag.getCompound(uuidStr);
//
//                Map<ResourceKey<Instrument>, StoredBoundHorse> innerMap = new HashMap<>();
//                for (String instrumentString : innerTag.getAllKeys()) {
//                    ResourceLocation location = ResourceLocation.parse(instrumentString);
//                    ResourceKey<Instrument> instrumentKey = ResourceKey.create(Registries.INSTRUMENT, location);
//
//                    CompoundTag horseTag = innerTag.getCompound(instrumentString);
//                    @Nullable StoredBoundHorse horse = StoredBoundHorse.load(horseTag);
//
//                    if (horse != null) {
//                        innerMap.put(instrumentKey, horse);
//                    }
//                }
//
//                boundHorses.put(uuid, innerMap);
//            }
//
//            ArrayList<UUID> unboundHorses = new ArrayList<>();
//            ListTag unboundHorsesListTag = tag.getList("UnboundHorses", Tag.TAG_INT_ARRAY);
//            for (Tag unboundUUID : unboundHorsesListTag) {
//                unboundHorses.add(NbtUtils.loadUUID(unboundUUID));
//            }
//
//            ArrayList<UUID> horsesToRemove = new ArrayList<>();
//            ListTag horsesToRemoveListTag = tag.getList("HorsesToRemove", Tag.TAG_INT_ARRAY);
//            for (Tag toRemoveUUID : horsesToRemoveListTag) {
//                horsesToRemove.add(NbtUtils.loadUUID(toRemoveUUID));
//            }
//
//            return new SummoningStorage(boundHorses, unboundHorses, horsesToRemove);
//        } catch (Exception e) {
//            Horseman.LOGGER.error("Failed to load HorseCallingStorage: ", e);
//            return new SummoningStorage();
//        }
//    }
//
//    @Override
//    public @NotNull CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
//        CompoundTag boundHorsesTag = new CompoundTag();
//        for (Map.Entry<UUID, Map<ResourceKey<Instrument>, StoredBoundHorse>> outerEntry : boundHorses.entrySet()) {
//            UUID uuid = outerEntry.getKey();
//            Map<ResourceKey<Instrument>, StoredBoundHorse> innerMap = outerEntry.getValue();
//
//            CompoundTag innerTag = new CompoundTag();
//            for (Map.Entry<ResourceKey<Instrument>, StoredBoundHorse> innerEntry : innerMap.entrySet()) {
//                ResourceKey<Instrument> key = innerEntry.getKey();
//                StoredBoundHorse horse = innerEntry.getValue();
//
//                CompoundTag horseTag = horse.save(new CompoundTag());
//
//                innerTag.put(key.location().toString(), horseTag);
//            }
//
//            boundHorsesTag.put(uuid.toString(), innerTag);
//        }
//        tag.put("BoundHorses", boundHorsesTag);
//
//        ListTag unboundHorsesListTag = new ListTag();
//        for (UUID uuid : unboundHorses) {
//            unboundHorsesListTag.add(NbtUtils.createUUID(uuid));
//        }
//        tag.put("UnboundHorses", unboundHorsesListTag);
//
//        ListTag entitiesToRemoveListTag = new ListTag();
//        for (UUID uuid : horsesToRemove) {
//            entitiesToRemoveListTag.add(NbtUtils.createUUID(uuid));
//        }
//        tag.put("HorsesToRemove", entitiesToRemoveListTag);
//
//        return tag;
//    }
}
