package io.github.mortuusars.horseman.mixin.less_wander;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.horseman.world.LessWanderingHorse;
import net.minecraft.class_1314;
import net.minecraft.class_1379;
import net.minecraft.class_1394;
import net.minecraft.class_1496;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1394.class)
public abstract class WaterAvoidingRandomStrollGoalMixin extends class_1379 {
    public WaterAvoidingRandomStrollGoalMixin(class_1314 mob, double speedModifier) {
        super(mob, speedModifier);
    }

    @ModifyReturnValue(method = "getPosition", at = @At("RETURN"))
    private class_243 onGetPosition(class_243 original) {
        if (original != null
                && LessWanderingHorse.isEnabled()
                && field_6566 instanceof class_1496 horse
                && horse.method_66672()
                && !field_6566.method_5799() // Allow horse to escape water. But this does not seem to be working in vanilla.
                && field_6566 instanceof LessWanderingHorse lessWanderingHorse
                && lessWanderingHorse.horseman$isOutsideWanderingLimit(original)) {
            return null; // Stay at current pos
        }

        return original;
    }
}
