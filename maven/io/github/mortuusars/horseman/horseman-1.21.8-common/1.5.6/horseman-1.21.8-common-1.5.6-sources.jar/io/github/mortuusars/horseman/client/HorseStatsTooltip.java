package io.github.mortuusars.horseman.client;

import io.github.mortuusars.horseman.Config;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.stream.Collectors;
import net.minecraft.class_1498;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3489;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.class_5481;
import net.minecraft.class_5684;
import net.minecraft.class_8001;
import net.minecraft.class_9779;

public class HorseStatsTooltip {
    public static void render(class_332 guiGraphics, class_9779 deltaTracker) {
        if (!Config.Common.HORSE_STATS_TOOLTIP.get()) return;
        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1690.field_1842
                || minecraft.field_1687 == null
                || minecraft.field_1724 == null
                || minecraft.field_1724.method_7325()
                || minecraft.field_1755 != null
                || !(minecraft.field_1765 instanceof class_3966 entityHitResult)
                || !(entityHitResult.method_17782() instanceof class_1498 horse)
                || (!minecraft.field_1724.method_6047().method_31573(class_3489.field_49938)
                    && !minecraft.field_1724.method_6079().method_31573(class_3489.field_49938))) {
            return;
        }

        NumberFormat numberFormat = DecimalFormat.getNumberInstance();
        numberFormat.setMinimumFractionDigits(0);
        numberFormat.setMaximumFractionDigits(2);

        ArrayList<class_5481> lines = new ArrayList<>();
        lines.add(class_2561.method_43471("gui.horseman.horse_stats_tooltip.stats").method_30937());

        float health = horse.method_6063();
        lines.add(class_2561.method_43469("gui.horseman.horse_stats_tooltip.health", numberFormat.format(health)).method_30937());

        if (horse.method_6127().method_45331(class_5134.field_23728)) {
            double jumpHeight = getJumpHeight(horse.method_45326(class_5134.field_23728));
            lines.add(class_2561.method_43469("gui.horseman.horse_stats_tooltip.jump_height", numberFormat.format(jumpHeight)).method_30937());
        }

        if (horse.method_6127().method_45331(class_5134.field_23719)) {
            double blocksPerSecond = horse.method_45326(class_5134.field_23719) * 42.16;
            lines.add(class_2561.method_43469("gui.horseman.horse_stats_tooltip.speed", numberFormat.format(blocksPerSecond)).method_30937());
        }

        int x = minecraft.method_22683().method_4486() / 2 + 8;
        int y = minecraft.method_22683().method_4502() / 2 - (int)(lines.size() / 2f * 9f);
        guiGraphics.method_51435(minecraft.field_1772, lines.stream().map(class_5684::method_32662).collect(Collectors.toList()),
                x, y + 10, class_8001.field_41687, null);
    }

    private static double getJumpHeight(double jumpStrength) {
        return -0.1817584952 * jumpStrength * jumpStrength * jumpStrength + 3.689713992 * jumpStrength * jumpStrength +
                2.128599134 * jumpStrength - 0.343930367;
    }
}
