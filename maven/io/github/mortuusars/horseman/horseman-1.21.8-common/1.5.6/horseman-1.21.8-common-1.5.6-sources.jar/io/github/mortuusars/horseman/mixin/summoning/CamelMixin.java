package io.github.mortuusars.horseman.mixin.summoning;

import io.github.mortuusars.horseman.world.item.CopperHornItem;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_7689;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_7689.class)
public class CamelMixin {
    @Inject(method = "mobInteract", at = @At("HEAD"), cancellable = true)
    private void onMobInteract(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        // Allow Copper Horn to process its interaction logic:
        if (player.method_21823() && player.method_5998(hand).method_7909() instanceof CopperHornItem) {
            cir.setReturnValue(class_1269.field_5811);
        }
    }
}
