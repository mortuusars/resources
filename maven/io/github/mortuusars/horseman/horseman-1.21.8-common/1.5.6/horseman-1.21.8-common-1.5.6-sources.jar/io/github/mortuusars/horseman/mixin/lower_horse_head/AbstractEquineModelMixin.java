package io.github.mortuusars.horseman.mixin.lower_horse_head;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.client.HorseRenderUtils;
import net.minecraft.class_10019;
import net.minecraft.class_549;
import net.minecraft.class_583;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_549.class, priority = 950)
public abstract class AbstractEquineModelMixin<T extends class_10019> extends class_583<T> {
    @Shadow @Final protected class_630 headParts;

    public AbstractEquineModelMixin(class_630 root) {
        super(root);
    }

    @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/EquineRenderState;)V", at = @At("RETURN"))
    private void onSetupAnim(T state, CallbackInfo ci) {
        if (state instanceof HorseRenderUtils.HorsemanEquineRenderState horsemanState
                && horsemanState.getHorsemanRiddenByPlayerInFirstPerson()) {
            int headXRotOffset = Config.Client.HORSE_HEAD_PITCH_OFFSET.get();
            if (headXRotOffset > 0) {
                this.headParts.field_3654 = Math.min(this.headParts.field_3654 + (headXRotOffset / 100f), 1.5f);
            }

            int headYOffset = Config.Client.HORSE_HEAD_Y_OFFSET.get();
            if (headYOffset > 0) {
                this.headParts.field_3656 += headYOffset;
            }
        }
    }
}
