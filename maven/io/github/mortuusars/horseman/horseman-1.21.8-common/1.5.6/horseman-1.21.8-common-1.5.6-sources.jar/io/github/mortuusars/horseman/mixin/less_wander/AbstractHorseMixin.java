package io.github.mortuusars.horseman.mixin.less_wander;

import io.github.mortuusars.horseman.world.LessWanderingHorse;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_1496;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1496.class)
public abstract class AbstractHorseMixin extends class_1429 implements LessWanderingHorse {
    @Unique
    @Nullable
    private class_243 horseman$wanderAnchor = null;

    protected AbstractHorseMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Override
    public @Nullable class_243 horseman$getWanderAnchor() {
        return horseman$wanderAnchor;
    }

    @Override
    public void horseman$setWanderAnchor(@Nullable class_243 pos) {
        horseman$wanderAnchor = pos;
    }

    // --

    @Inject(method = "addAdditionalSaveData", at = @At("RETURN"))
    protected void addAdditionalSaveData(class_11372 output, CallbackInfo ci) {
        if (horseman$wanderAnchor != null && LessWanderingHorse.isEnabled()) {
            output.method_71463("HorsemanWanderAnchorX", horseman$wanderAnchor.field_1352);
            output.method_71463("HorsemanWanderAnchorY", horseman$wanderAnchor.field_1351);
            output.method_71463("HorsemanWanderAnchorZ", horseman$wanderAnchor.field_1350);
        }
    }

    @Inject(method = "readAdditionalSaveData", at = @At("RETURN"))
    protected void readAdditionalSaveData(class_11368 input, CallbackInfo ci) {
        if (!LessWanderingHorse.isEnabled()) return;

        double x = input.method_71422("HorsemanWanderAnchorX", 0.0);
        double y = input.method_71422("HorsemanWanderAnchorY", 0.0);
        double z = input.method_71422("HorsemanWanderAnchorZ", 0.0);

        if (x != 0.0 && y != 0.0 && z != 0.0) {
            horseman$wanderAnchor = new class_243(x, y, z);
        }
    }
}
