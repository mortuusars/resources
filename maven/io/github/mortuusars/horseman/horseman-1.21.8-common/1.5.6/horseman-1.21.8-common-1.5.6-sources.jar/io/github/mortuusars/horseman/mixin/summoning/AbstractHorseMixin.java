package io.github.mortuusars.horseman.mixin.summoning;

import io.github.mortuusars.horseman.world.summoning.BoundData;
import io.github.mortuusars.horseman.world.summoning.SummonableHorse;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import io.github.mortuusars.horseman.world.item.CopperHornItem;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1496.class)
public abstract class AbstractHorseMixin extends class_1429 implements SummonableHorse {
    protected AbstractHorseMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    // --

    @Unique
    private @Nullable BoundData horseman$boundData = null;

    @SuppressWarnings("AddedMixinMembersNamePattern")
    @Override
    public BoundData getHorsemanBoundData() {
        return horseman$boundData;
    }

    @SuppressWarnings("AddedMixinMembersNamePattern")
    @Override
    public void setHorsemanBoundData(@Nullable BoundData data) {
        horseman$boundData = data;
    }

    // --

    @Inject(method = "addAdditionalSaveData", at = @At("RETURN"))
    protected void onAddAdditionalSaveData(class_11372 output, CallbackInfo ci) {
        if (horseman$boundData != null) {
            output.method_71468("HorsemanBoundData", BoundData.CODEC, horseman$boundData);
        }
    }

    @Inject(method = "readAdditionalSaveData", at = @At("RETURN"))
    protected void onReadAdditionalSaveData(class_11368 input, CallbackInfo ci) {
        horseman$boundData = input.method_71426("HorsemanBoundData", BoundData.CODEC).orElse(null);
    }

    // --

    @Inject(method = "mobInteract", at = @At("HEAD"), cancellable = true)
    private void onMobInteract(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        // Allow Copper Horn to process its interaction logic:
        if (player.method_21823() && player.method_5998(hand).method_7909() instanceof CopperHornItem) {
            cir.setReturnValue(class_1269.field_5811);
        }
    }
}
