package io.github.mortuusars.horseman.fabric.mixin.mount_gui;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_310;
import net.minecraft.class_329;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value = class_329.class)
public abstract class GuiMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Shadow
    protected abstract boolean willPrioritizeJumpInfo();

    @Shadow
    protected abstract int getVisibleVehicleHeartRows(int vehicleHealth);

    @Shadow
    protected abstract int getVehicleMaxHearts(@Nullable class_1309 vehicle);

    @Shadow
    @Nullable
    protected abstract class_1309 getPlayerVehicleWithHealth();

    @Unique
    private long horseman$lastTickHorseInWater = -1;

    @WrapOperation(method = "renderPlayerHealth", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;getVehicleMaxHearts(Lnet/minecraft/world/entity/LivingEntity;)I"))
    private int renderPlayerHealth_getVehicleMaxHearts(class_329 instance, class_1309 vehicle, Operation<Integer> original) {
        if (!Config.Client.IMPROVED_MOUNT_GUI.get()) return original.call(instance, vehicle);
        return 0; // Forces hunger bar rendering, because it is not rendered when vehicle hearts is not 0.
    }

    @ModifyVariable(method = "renderVehicleHealth", at = @At(value = "STORE"), ordinal = 2)
    private int renderVehicleHealth(int y) {
        if (Config.Client.IMPROVED_MOUNT_GUI.get()
              && class_310.method_1551().field_1761 != null
              && class_310.method_1551().field_1761.method_2908()) {
            y -= 10; // Make room for hunger bar
        }
        return y;
    }

    @WrapOperation(method = "getAirBubbleYLine", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;getVisibleVehicleHeartRows(I)I"))
    private int getAirYLine(class_329 instance, int vehicleHealth, Operation<Integer> original) {
        if (!Config.Client.IMPROVED_MOUNT_GUI.get()
              || minecraft.field_1724 == null
              || minecraft.field_1724.method_45773() == null) {
            return original.call(instance, vehicleHealth);
        }

        return getVisibleVehicleHeartRows(getVehicleMaxHearts(getPlayerVehicleWithHealth()));
    }

    @ModifyVariable(method = "nextContextualInfoState", at = @At(value = "STORE"), ordinal = 1)
    private boolean shouldChooseJumpBar(boolean willChooseJumpBar) {
        if (!Config.Client.IMPROVED_MOUNT_GUI.get() || (minecraft.field_1724 != null && minecraft.field_1724.method_68878())) {
            return willChooseJumpBar;
        }

        if (minecraft.field_1724 != null && minecraft.field_1724.method_45773() instanceof class_1496 horse) {
            if (horse.method_5799()) {
                horseman$lastTickHorseInWater = minecraft.field_1724.method_73183().method_75260();
            }

            if (minecraft.field_1687 != null && minecraft.field_1687.method_75260() - horseman$lastTickHorseInWater < 10) {
                return false;
            }
        }

        return willChooseJumpBar && willPrioritizeJumpInfo();
    }
}