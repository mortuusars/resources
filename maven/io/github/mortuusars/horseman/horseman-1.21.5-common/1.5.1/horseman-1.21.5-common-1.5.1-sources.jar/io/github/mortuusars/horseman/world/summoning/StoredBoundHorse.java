package io.github.mortuusars.horseman.world.summoning;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1299;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_4844;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public record StoredBoundHorse(Optional<BoundData> boundData, class_2487 tag, UUID uuid,
                               class_243 position, class_5321<class_1937> dimension, boolean isDead) {

    public static final Codec<StoredBoundHorse> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            BoundData.CODEC.optionalFieldOf("bound_data").forGetter(StoredBoundHorse::boundData),
            class_2487.field_25128.fieldOf("tag").forGetter(StoredBoundHorse::tag),
            class_4844.field_25122.fieldOf("uuid").forGetter(StoredBoundHorse::uuid),
            class_243.field_38277.fieldOf("position").forGetter(StoredBoundHorse::position),
            class_5321.method_39154(class_7924.field_41223).fieldOf("dimension").forGetter(StoredBoundHorse::dimension),
            Codec.BOOL.optionalFieldOf("is_dead", false).forGetter(StoredBoundHorse::isDead)
    ).apply(instance, StoredBoundHorse::new));

    public StoredBoundHorse(class_1496 horse) {
        this(Optional.ofNullable(horse.getHorsemanBoundData()), saveToTag(horse), horse.method_5667(),
                horse.method_19538(), horse.method_37908().method_27983(), horse.method_29504());
    }

    public static class_2487 saveToTag(class_1496 horse) {
        class_2487 tag = new class_2487();
        tag.method_10582("id", class_1299.method_5890(horse.method_5864()).toString());
        horse.method_5647(tag);
        return tag;
    }

    // --

    public boolean isInSameDimension(class_1657 player) {
        return isInSameDimension(player.method_37908().method_27983());
    }

    public boolean isInSameDimension(class_5321<class_1937> dimension) {
        return dimension().equals(dimension);
    }

    // --

//    public CompoundTag save(CompoundTag tag) {
//        if (this.boundData != null) {
//            tag.put("BoundData", this.boundData.save(new CompoundTag()));
//        }
//        tag.put("Tag", this.tag);
//        tag.putUUID("EntityUUID", this.entityUuid);
//        tag.putDouble("PosX", this.position.x);
//        tag.putDouble("PosY", this.position.y);
//        tag.putDouble("PosZ", this.position.z);
//        tag.putString("Dimension", this.dimension.location().toString());
//        tag.putBoolean("IsDead", this.isDead);
//        return tag;
//    }
//
//    public static @Nullable StoredBoundHorse load(CompoundTag tag) {
//        try {
//            @Nullable BoundData boundData = BoundData.load(tag.getCompound("BoundData"));
//            CompoundTag storedTag = tag.getCompound("Tag");
//            UUID entityUUID = tag.getUUID("EntityUUID");
//            Vec3 position = new Vec3(tag.getDouble("PosX"), tag.getDouble("PosY"), tag.getDouble("PosZ"));
//            ResourceKey<Level> dimension = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(tag.getString("Dimension")));
//            boolean isDead = tag.getBoolean("IsDead");
//            return new StoredBoundHorse(boundData, storedTag, entityUUID, position, dimension, isDead);
//        } catch (Exception e) {
//            Horseman.LOGGER.error("Failed to load StoredBoundHorse: ", e);
//            return null;
//        }
//    }
}
