package io.github.mortuusars.horseman.mixin.transparent_mount;

import io.github.mortuusars.horseman.client.TransparentMount;
import net.minecraft.class_10042;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_10042.class)
public abstract class LivingEntityRenderStateMixin implements TransparentMount.RenderState {
    @Unique private float horseman$opacity = 1f;

    @Override
    public float horseman$getOpacity() {
        return horseman$opacity;
    }

    @Override
    public void horseman$setOpacity(float opacity) {
        horseman$opacity = class_3532.method_15363(opacity, 0, 1);
    }
}
