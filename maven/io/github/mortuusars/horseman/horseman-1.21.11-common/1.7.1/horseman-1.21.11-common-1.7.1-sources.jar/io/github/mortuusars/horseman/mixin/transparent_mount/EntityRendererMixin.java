package io.github.mortuusars.horseman.mixin.transparent_mount;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.horseman.client.TransparentMount;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
public class EntityRendererMixin {
    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void extractRenderState(class_1297 entity, class_10017 state, float partialTick, CallbackInfo ci) {
        if (class_310.method_1551().field_1724 != null && entity instanceof class_1309 livingEntity) {
            ((TransparentMount.RenderState)state).horseman$setOpacity(TransparentMount.getOpacity(livingEntity));
        }
    }

    @ModifyReturnValue(method = "getShadowStrength", at = @At("RETURN"))
    private float getShadowStrength(float original, @Local(argsOnly = true) class_10017 renderState) {
        if (renderState instanceof TransparentMount.RenderState state) {
            // Reduce shadow strength, so it doesn't look that jarring when mount is transparent.
            return original * state.horseman$getOpacity();
        }
        return original;
    }
}
