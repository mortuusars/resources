package io.github.mortuusars.horseman.mixin.transparent_mount;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import io.github.mortuusars.horseman.client.TransparentMount;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_898.class)
public class EntityRenderDispatcherMixin {
    @WrapMethod(method = "submit")
    public void onSubmit(class_10017 renderState, class_12075 cameraRenderState, double camX, double camY, double camZ, class_4587 poseStack, class_11659 nodeCollector, Operation<Void> original) {
        // Store opacity to use later in layers, where render state is not available.
        TransparentMount.storedOpacity = renderState instanceof TransparentMount.RenderState state ? state.horseman$getOpacity() : 1f;
        original.call(renderState, cameraRenderState, camX, camY, camZ, poseStack, nodeCollector);
        TransparentMount.storedOpacity = 1f;
    }
}
