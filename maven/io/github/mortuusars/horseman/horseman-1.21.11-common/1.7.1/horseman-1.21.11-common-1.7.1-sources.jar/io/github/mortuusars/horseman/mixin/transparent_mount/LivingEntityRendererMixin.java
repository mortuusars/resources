package io.github.mortuusars.horseman.mixin.transparent_mount;

import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.horseman.client.TransparentMount;
import net.minecraft.class_10042;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_922.class)
public class LivingEntityRendererMixin {
    @Inject(method = "getRenderType",
          at = @At(value = "INVOKE",
                target = "Lnet/minecraft/client/model/EntityModel;renderType(Lnet/minecraft/resources/Identifier;)Lnet/minecraft/client/renderer/rendertype/RenderType;"),
          cancellable = true)
    private void getRenderType(class_10042 renderState, boolean visible, boolean translucent, boolean glowing,
                                 CallbackInfoReturnable<class_1921> cir, @Local class_2960 identifier) {
        if (renderState instanceof TransparentMount.RenderState state) {
            float opacity = state.horseman$getOpacity();
            if (opacity > 0f || opacity < 1f) {
                cir.setReturnValue(class_12249.method_76000(identifier));
            }
        }
    }

    @ModifyArg(method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
          at = @At(value = "INVOKE",
                target = "Lnet/minecraft/client/renderer/SubmitNodeCollector;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/rendertype/RenderType;IIILnet/minecraft/client/renderer/texture/TextureAtlasSprite;ILnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)V"),
          index = 6)
    private int modifyColor(int colorArgb, @Local(argsOnly = true) class_10042 renderState) {
        if (renderState instanceof TransparentMount.RenderState state) {
            return TransparentMount.applyOpacity(colorArgb, state.horseman$getOpacity());
        }
        return colorArgb;
    }

    @Inject(method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
          at = @At("HEAD"),
          cancellable = true)
    private void stopRendering(class_10042 renderState, class_4587 poseStack, class_11659 submitNodeCollector,
                               class_12075 cameraRenderState, CallbackInfo ci) {
        if (renderState instanceof TransparentMount.RenderState state && state.horseman$getOpacity() <= 0f) {
            ci.cancel();
        }
    }
}
