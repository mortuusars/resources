package io.github.mortuusars.horseman.mixin.fix_water_jump_meter;

import com.mojang.authlib.GameProfile;
import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1316;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public abstract class LocalPlayerMixin extends class_1657 {
    public LocalPlayerMixin(class_1937 level, GameProfile gameProfile) {
        super(level, gameProfile);
    }

    @Shadow public abstract float getJumpRidingScale();

    @Shadow @Nullable
    public abstract class_1316 jumpableVehicle();

    @Shadow private float jumpRidingScale;
    @Shadow private int jumpRidingTicks;
    @Unique
    private long horseman$lastTickHorseInWater = -1;

    @Inject(method = "aiStep", at = @At(value = "RETURN"))
    private void aiStep(CallbackInfo ci) {
        if (!Config.Client.PREVENT_JUMPING_IN_WATER.get()) return;

        class_1316 vehicle = jumpableVehicle();

        if (vehicle instanceof class_1496 horse) {
            if (horse.method_5799()) {
                horseman$lastTickHorseInWater = method_73183().method_75260();
            }

            if (getJumpRidingScale() > 0 && method_73183().method_75260() - horseman$lastTickHorseInWater < 10) {
                jumpRidingScale = 0;
                jumpRidingTicks = 0;
            }
        }
    }
}
