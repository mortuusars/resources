package io.github.mortuusars.horseman.mixin.switch_inventory;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.client.SwitchInventory;
import net.minecraft.class_1109;
import net.minecraft.class_11908;
import net.minecraft.class_12348;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_344;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_7919;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_465.class)
public abstract class AbstractContainerScreenMixin extends class_437 {
    @Shadow protected int leftPos;
    @Shadow protected int topPos;

    protected AbstractContainerScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        if (!SwitchInventory.isEnabled()) return;
        if (class_310.method_1551().field_1761 == null) return;

        if (((Object) this) instanceof class_12348) {
            SwitchInventory.restoreMousePosIfNeeded();

            class_344 switchButton = new class_344(leftPos + Config.Client.INVENTORY_SWITCH_HORSE_BUTTON_X.get(),
                  topPos + Config.Client.INVENTORY_SWITCH_HORSE_BUTTON_Y.get(), 14, 15,
                  SwitchInventory.SWITCH_BUTTON_LEFT_SPRITES,
                  b -> SwitchInventory.switchToInventory(((class_465<?>)(Object) this)));

            switchButton.method_47400(class_7919.method_47407(class_2561.method_43469("gui.horseman.switch_inventory.button.to_inventory.tooltip",
                  class_2561.method_43470(class_310.method_1551().field_1690.field_1822.method_16007().getString()).method_27692(class_124.field_1080)
            )));

            method_37063(switchButton);
        }
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void onKeyPressed(class_11908 event, CallbackInfoReturnable<Boolean> cir) {
        if (!SwitchInventory.isEnabled()) return;

        class_310 minecraft = class_310.method_1551();

        if (((class_465<?>) (Object) this) instanceof class_12348<?>
                && minecraft.field_1690.field_1822.method_1417(event)
                && minecraft.method_74188()) {
            SwitchInventory.switchToInventory(((class_465<?>)(Object) this));
            minecraft.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1));
            cir.setReturnValue(true);
        }
    }
}