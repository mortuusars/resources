package io.github.mortuusars.horseman.client;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_9848;

public class TransparentMount {
    // This is for setting correct opacity for some render layers. We don't have access to render state in those places.
    public static float storedOpacity = 1f;

    public static float getOpacity(class_1309 entity) {
        class_310 mc = class_310.method_1551();

        if (!Config.Client.TRANSPARENT_MOUNT_ENABLED.get()
              || mc.field_1724 == null
              || !mc.field_1690.method_31044().method_31034()
              || !entity.method_5626(mc.field_1724)
              || (Config.Client.TRANSPARENT_MOUNT_ONLY_HORSES.get() && !(entity instanceof class_1496))) {
            return 1.0f;
        }

        int startAngle = Config.Client.TRANSPARENT_MOUNT_START_ANGLE.get();

        float angle = mc.field_1724.field_6004;
        if (angle < startAngle) return 1.0f;

        float maxTransparency = Config.Client.TRANSPARENT_MOUNT_MAX_OPACITY.get().floatValue();
        int endAngle = Config.Client.TRANSPARENT_MOUNT_END_ANGLE.get();

        float delta = (Math.min(angle, endAngle) - startAngle) / (endAngle - startAngle);
        return class_3532.method_16439(delta, 1.0f, maxTransparency);
    }

    public static int applyOpacity(int colorArgb, float opacity) {
        if (opacity <= 0f || opacity >= 1f) {
            return colorArgb;
        }

        return class_9848.method_61318(opacity, class_9848.method_65101(colorArgb), class_9848.method_65102(colorArgb), class_9848.method_65103(colorArgb));
    }

    public interface RenderState {
        float horseman$getOpacity();
        void horseman$setOpacity(float opacity);
    }
}
