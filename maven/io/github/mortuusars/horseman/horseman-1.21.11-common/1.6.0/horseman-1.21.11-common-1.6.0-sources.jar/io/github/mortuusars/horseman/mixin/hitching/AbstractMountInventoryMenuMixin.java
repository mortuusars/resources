package io.github.mortuusars.horseman.mixin.hitching;

import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.world.HitchableHorse;
import io.github.mortuusars.horseman.world.menu.LeadSlot;
import net.minecraft.class_12343;
import net.minecraft.class_1263;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3917;
import net.minecraft.world.inventory.*;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_12343.class)
public abstract class AbstractMountInventoryMenuMixin extends class_1703 {
    @Shadow @Final protected class_1309 mount;

    @Shadow @Final protected class_1263 mountContainer;

    protected AbstractMountInventoryMenuMixin(@Nullable class_3917<?> menuType, int containerId) {
        super(menuType, containerId);
    }

    /**
     * When Lead stack in player inventory is shift-clicked - splits only one item from clicked stack and inserts into Lead slot.
     * On Forge it's mostly a QOL thing (it will work without it, but not stop moving the rest of a stack in other slots),
     * but on Fabric without this mixin it's possible to insert 64 items into a slot with stack size of 1.
     * Fabric does not check slot limits when inserting.
     */
    @Inject(method = "quickMoveStack", at = @At(value = "HEAD"), cancellable = true)
    private void onQuickMoveStack(class_1657 player, int index, CallbackInfoReturnable<class_1799> cir) {
        if (!(this.mount instanceof HitchableHorse hitchableHorse)) return;
        if (!HitchableHorse.shouldHaveLeadSlot(hitchableHorse)) return;
        if (index < this.mountContainer.method_5439() + 1) return;

        class_1735 slot = this.field_7761.get(index);
        if (!slot.method_7681()) {
            return;
        }

        if (slot instanceof LeadSlot) {
            return;
        }

        class_1799 clickedStack = slot.method_7677();
        if (!clickedStack.method_31574(class_1802.field_8719)) {
            return;
        }

        class_1799 clickedStackCopy = clickedStack.method_7972();

        LeadSlot leadSlot = null;
        for (class_1735 s : field_7761) {
            if (s instanceof LeadSlot ls) {
                leadSlot = ls;
            }
        }
        if (leadSlot == null) {
            Horseman.LOGGER.error("LeadSlot is not found. Something went wrong. Try without other mods and report to github.");
            return;
        }

        if (!leadSlot.method_7680(clickedStack)) {
            return;
        }

        class_1799 movedStack = clickedStack.method_46651(1);

        if (!leadSlot.method_7677().method_7960()) {
            if (!method_7616(clickedStack, 3, this.mountContainer.method_5439(), false)) {
                cir.setReturnValue(class_1799.field_8037);
                return;
            }

            if (clickedStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            if (clickedStack.method_7947() == clickedStackCopy.method_7947()) {
                cir.setReturnValue(class_1799.field_8037);
                return;
            }

            slot.method_7667(player, clickedStack);

            cir.setReturnValue(class_1799.field_8037);
            return;
        }

        clickedStack.method_7934(1);
        leadSlot.method_53512(movedStack);

        if (clickedStack.method_7960()) {
            slot.method_53512(class_1799.field_8037);
        } else {
            slot.method_7668();
        }

        if (clickedStack.method_7947() == clickedStackCopy.method_7947()) {
            cir.setReturnValue(class_1799.field_8037);
            return;
        }

        slot.method_7667(player, clickedStack);

        cir.setReturnValue(class_1799.field_8037);
    }
}
