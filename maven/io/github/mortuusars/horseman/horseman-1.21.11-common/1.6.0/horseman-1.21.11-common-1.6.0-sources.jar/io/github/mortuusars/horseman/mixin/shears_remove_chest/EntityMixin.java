package io.github.mortuusars.horseman.mixin.shears_remove_chest;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1492;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_4048;
import net.minecraft.class_5712;
import net.minecraft.class_6880;
import net.minecraft.class_9064;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1297.class)
public abstract class EntityMixin {
    @Shadow
    public abstract void gameEvent(class_6880<class_5712> gameEvent, @Nullable class_1297 entity);

    @Shadow
    public abstract void playSound(class_3414 sound);

    @Shadow
    private class_4048 dimensions;

    @Shadow
    public abstract class_1937 level();

    @Shadow
    public abstract @Nullable class_1542 spawnAtLocation(class_3218 level, class_1799 stack, class_243 offset);

    @ModifyReturnValue(method = "attemptToShearEquipment", at = @At("RETURN"))
    private boolean attemptToShearEquipment(boolean original,
                                            @Local(argsOnly = true) class_1657 player,
                                            @Local(argsOnly = true) class_1268 hand,
                                            @Local(argsOnly = true) class_1799 stack,
                                            @Local(argsOnly = true) class_1308 mob) {
        if (original) return true;
        if (!Config.Server.HORSE_SHEARS_REMOVE_CHEST.get()) return false;
        if (!(mob instanceof class_1492 chestedHorse)) return false;
        if (!chestedHorse.method_6703()) return false;

        stack.method_7970(1, player, hand.method_73186());
        class_243 offset = dimensions.comp_2188().method_71766(class_9064.field_47743);
        gameEvent(class_5712.field_28730, player);
        playSound(class_3417.field_59992);
        if (level() instanceof class_3218 serverLevel) {
            for (int i = 0; i < chestedHorse.field_6962.method_5439(); i++) {
                spawnAtLocation(serverLevel, chestedHorse.field_6962.method_5438(i), offset);
                chestedHorse.field_6962.method_5447(i, class_1799.field_8037);
            }
            spawnAtLocation(serverLevel, new class_1799(class_1802.field_8106), offset);
            chestedHorse.method_6704(false);
            chestedHorse.method_6721();

            class_174.field_61057.method_30097((class_3222) player, stack, mob);
        }

        return true;

    }
}
