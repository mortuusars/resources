package io.github.mortuusars.horseman;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.horseman.advancement.HorseSummonedTrigger;
import io.github.mortuusars.horseman.world.item.CopperHornItem;
import io.github.mortuusars.horseman.world.item.crafting.recipe.ComponentTransferringRecipe;
import io.github.mortuusars.horseman.world.item.crafting.recipe.serializer.ComponentTransferringRecipeSerializer;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3446;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class Horseman {
    public static final String ID = "horseman";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static void init() {
        Blocks.init();
        BlockEntityTypes.init();
        EntityTypes.init();
        Items.init();
        MenuTypes.init();
        RecipeSerializers.init();
        CriteriaTriggers.init();
        SoundEvents.init();
        ArgumentTypes.init();
    }

    /**
     * Creates resource location in the mod namespace with the given path.
     */
    public static class_2960 resource(String path) {
        return class_2960.method_60655(ID, path);
    }

    public static class EntityAttributes {
        public static final class_2960 MOUNTED_STEP_HEIGHT = Horseman.resource("mounted-step-height");
        public static final class_2960 MOUNTED_BREAK_SPEED = Horseman.resource("mounted-break-speed");
    }

    public static class Blocks {
        static void init() {
        }
    }

    public static class BlockEntityTypes {
        static void init() {
        }
    }

    public static class Items {
        public static final Supplier<CopperHornItem> COPPER_HORN = Register.item("copper_horn",
                CopperHornItem::new, new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8907));

        static void init() {
        }
    }

    public static class EntityTypes {
        static void init() {
        }
    }

    public static class MenuTypes {
        static void init() {
        }
    }

    public static class RecipeSerializers {
        public static final Supplier<class_1865<ComponentTransferringRecipe>> COMPONENT_TRANSFERRING = Register.recipeSerializer(
                "component_transferring", () -> new ComponentTransferringRecipeSerializer<>(
                        "component_transferring", "source", ComponentTransferringRecipe::new));

        static void init() {
        }
    }

    public static class SoundEvents {
        public static final Supplier<class_3414> COPPER_HORN_TOOT = register("item", "copper_horn.toot");
        public static final Supplier<class_3414> COPPER_HORN_TOOT_FAIL = register("item", "copper_horn.toot_fail");

        private static Supplier<class_3414> register(String category, String key) {
            Preconditions.checkState(category != null && !category.isEmpty(), "'category' should not be empty.");
            Preconditions.checkState(key != null && !key.isEmpty(), "'key' should not be empty.");
            String path = category + "." + key;
            return Register.soundEvent(path, () -> class_3414.method_47908(Horseman.resource(path)));
        }

        static void init() {
        }
    }

    public static class Stats {
        private static final Map<class_2960, class_3446> STATS = new HashMap<>();

        private static class_2960 register(class_2960 location, class_3446 formatter) {
            STATS.put(location, formatter);
            return location;
        }

        public static void register() {
            STATS.forEach((location, formatter) -> {
                class_2378.method_10230(class_7923.field_41183, location, location);
                net.minecraft.class_3468.field_15419.method_14955(location, formatter);
            });
        }
    }

    public static class CriteriaTriggers {
        public static final Supplier<HorseSummonedTrigger> HORSE_SUMMONED = Register.criterionTrigger("horse_summoned", HorseSummonedTrigger::new);

        public static void init() {
        }
    }

    public static class Tags {
        public static class Items {
        }

        public static class Blocks {
        }

        public static class EntityTypes {
            public static final class_6862<class_1299<?>> CANNOT_BE_HITCHED = class_6862.method_40092(class_7924.field_41266, resource("cannot_be_hitched"));
            public static final class_6862<class_1299<?>> CANNOT_SWIM = class_6862.method_40092(class_7924.field_41266, resource("cannot_swim"));
            public static final class_6862<class_1299<?>> FORBIDS_HORSES = class_6862.method_40092(class_7924.field_41266, resource("forbids_horses"));
            public static final class_6862<class_1299<?>> SUMMONABLE = class_6862.method_40092(class_7924.field_41266, resource("summonable"));
        }
    }

    public static class ArgumentTypes {
        public static void init() {
        }
    }
}
