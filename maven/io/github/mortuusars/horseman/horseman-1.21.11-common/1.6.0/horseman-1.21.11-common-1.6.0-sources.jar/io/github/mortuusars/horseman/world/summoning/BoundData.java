package io.github.mortuusars.horseman.world.summoning;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_4844;

public record BoundData(UUID owner) {
    public static final Codec<BoundData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_4844.field_25122.fieldOf("owner").forGetter(BoundData::owner)
    ).apply(instance, BoundData::new));

    public BoundData(class_1657 player) {
        this(player.method_5667());
    }

    public boolean isBoundTo(UUID uuid) {
        return owner().equals(uuid);
    }

    public boolean isBoundTo(class_1657 player) {
        return isBoundTo(player.method_5667());
    }
}