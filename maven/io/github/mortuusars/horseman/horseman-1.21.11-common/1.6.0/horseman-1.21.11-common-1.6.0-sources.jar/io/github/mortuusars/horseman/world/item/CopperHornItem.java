package io.github.mortuusars.horseman.world.item;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.HorsemanServer;
import io.github.mortuusars.horseman.world.summoning.HorseSummoningResult;
import net.minecraft.class_10712;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_5712;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;

public class CopperHornItem extends class_1792 {
    public CopperHornItem(class_1793 properties) {
        super(properties);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void method_67187(class_1799 stack, class_9635 context, class_10712 tooltipDisplay,
                                Consumer<class_2561> tooltip, class_1836 flag) {
        if (Config.Client.COPPER_HORN_SHOW_TOOLTIP_DETAILS.get()) {
            if (class_310.method_1551().method_74187()) {
                tooltip.accept(class_2561.method_43471("item.horseman.copper_horn.tooltip.bind"));
                tooltip.accept(class_2561.method_43471("item.horseman.copper_horn.tooltip.summon"));
            } else {
                tooltip.accept(class_2561.method_43471("item.horseman.tooltip.hold_shift_for_details"));
            }
        }
    }

    @Override
    public @NotNull class_1269 method_7847(class_1799 stack, class_1657 player, class_1309 target, class_1268 usedHand) {
        if (!player.method_21823() || !(target instanceof class_1496 horse)) return class_1269.field_5811;
        if (player.method_7357().method_7904(stack)) return class_1269.field_5814;
        if (!horse.method_5864().method_20210(Horseman.Tags.EntityTypes.SUMMONABLE)) return class_1269.field_5811;
        if (!horse.method_6727()) return class_1269.field_5811;
        if (!(player.method_73183() instanceof class_3218 level)) return class_1269.field_5812;

        if (horse.getHorsemanBoundData() != null) {
            if (!horse.getHorsemanBoundData().isBoundTo(player)) {
                player.method_7353(class_2561.method_43471(
                        "gui.horseman.summoning.cannot_bind.already_bound_to_another_player"), true);
                return class_1269.field_5814;
            }

            // Update bind just in case
            HorsemanServer.getSummoning().bind(level, horse, player);
            horse.method_6748();
            level.method_43129(null, horse, class_3417.field_14947, class_3419.field_15254, 1, 1);
            addCooldown(player, stack);
            return class_1269.field_5812;
        }

        HorsemanServer.getSummoning().bind(level, horse, player);
        level.method_65096(class_2398.field_11224, target.method_23317(), target.method_23318() + 0.75, target.method_23321(), 10, 0.6, 0.6, 0.6, 0.1);

        horse.method_6748();
        level.method_43129(null, horse, class_3417.field_14947, class_3419.field_15254, 1, 1);

        player.method_6019(usedHand);
        play(player.method_73183(), player, 1.2F);
        addCooldown(player, stack);

        return class_1269.field_5812;
    }

    @Override
    public @NotNull class_1269 method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        class_1799 itemInHand = player.method_5998(usedHand);

        player.method_6019(usedHand);

        if (player instanceof class_3222 serverPlayer) {
            HorseSummoningResult result = HorsemanServer.getSummoning().summonBoundHorseTo(serverPlayer);

            if (Config.Server.COPPER_HORN_ERROR_MESSAGES.get() && result.getMessage() instanceof class_2561 message) {
                player.method_7353(message, true);
            }

            if ((result != HorseSummoningResult.SUCCESS && result != HorseSummoningResult.HORSE_IS_DEAD)
                  && Config.Server.COPPER_HORN_FAIL_SOUND.get()) {
                level.method_43129(null, player, Horseman.SoundEvents.COPPER_HORN_TOOT_FAIL.get(),
                      class_3419.field_15248, 1f, player.method_59922().method_43057() * 0.1f + 0.95f);
            } else {
                play(level, player, player.method_59922().method_43057() * 0.1f + 0.95f);
            }
        }

        addCooldown(player, itemInHand);
        player.method_7259(class_3468.field_15372.method_14956(this));
        return class_1269.field_21466;
    }

    protected void addCooldown(class_1657 player, class_1799 stack) {
        player.method_7357().method_62835(stack, Config.Server.COPPER_HORN_COOLDOWN.get());
    }

    protected void play(class_1937 level, class_1657 player, float pitch) {
        float volume = Config.Server.COPPER_HORN_SOUND_RANGE.get() / 16.0F;
        level.method_43129(null, player, Horseman.SoundEvents.COPPER_HORN_TOOT.get(), class_3419.field_15248, volume, pitch);
        level.method_32888(class_5712.field_39415, player.method_73189(), class_5712.class_7397.method_43285(player));
    }
}
