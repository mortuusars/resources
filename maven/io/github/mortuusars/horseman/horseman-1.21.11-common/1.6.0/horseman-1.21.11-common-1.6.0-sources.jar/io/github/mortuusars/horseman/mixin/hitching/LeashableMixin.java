package io.github.mortuusars.horseman.mixin.hitching;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import io.github.mortuusars.horseman.world.HitchableHorse;
import net.minecraft.class_1297;
import net.minecraft.class_1935;
import net.minecraft.class_3218;
import net.minecraft.class_9817;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_9817.class)
public interface LeashableMixin {
    @Inject(method = "setLeashedTo(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/entity/Entity;Z)V", at = @At("RETURN"))
    private static <E extends class_1297 & class_9817> void setLeashedTo(E entity, class_1297 leashHolder, boolean broadcastPacket, CallbackInfo ci) {
        if (broadcastPacket && entity instanceof HitchableHorse horse && entity.method_73183() instanceof class_3218) {
            HitchableHorse.syncHorseDataToTrackingClients(horse);
        }
    }

    @Inject(method = "dropLeash(Lnet/minecraft/world/entity/Entity;ZZ)V", at = @At("HEAD"))
    private static <E extends class_1297 & class_9817> void onDropLeash(E entity, boolean broadcastPacket, boolean dropItem,
                                                       CallbackInfo ci, @Share("preventDrop") LocalBooleanRef preventDrop) {
        if (!(entity instanceof HitchableHorse horse)) return;

        boolean hitched = HitchableHorse.isHitched(horse);

        HitchableHorse.setHitched(horse, false);
        if (!entity.method_73183().method_8608()) {
            HitchableHorse.syncHorseDataToTrackingClients(horse);
        }

        preventDrop.set(hitched);
    }

    @WrapWithCondition(method = "dropLeash(Lnet/minecraft/world/entity/Entity;ZZ)V", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/entity/Entity;spawnAtLocation(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/level/ItemLike;)Lnet/minecraft/world/entity/item/ItemEntity;"))
    private static boolean preventLeadDrop(class_1297 instance, class_3218 level, class_1935 item, @Share("preventDrop") LocalBooleanRef preventDrop) {
        return !preventDrop.get();
    }
}
