package io.github.mortuusars.horseman.world.summoning;

import net.minecraft.class_2561;
import org.jetbrains.annotations.Nullable;

public enum HorseSummoningResult {
    SUCCESS,
    NO_BOUND_HORSE,
    HORSE_IS_DEAD,
    TOO_FAR,
    INVALID_DIMENSION,
    NO_SPACE,
    ERROR_HORSE_IS_NOT_BOUND,
    ERROR_ENTITY_NOT_CREATED;

    public @Nullable class_2561 getMessage() {
        return switch (this) {
            case SUCCESS -> null;
            case NO_BOUND_HORSE -> class_2561.method_43471("gui.horseman.summoning.cannot_summon.no_bound_horse");
            case HORSE_IS_DEAD -> class_2561.method_43471("gui.horseman.summoning.cannot_summon.dead");
            case TOO_FAR -> class_2561.method_43471("gui.horseman.summoning.cannot_summon.too_far");
            case INVALID_DIMENSION ->
                  class_2561.method_43471("gui.horseman.summoning.cannot_summon.in_other_dimension");
            case NO_SPACE -> class_2561.method_43471("gui.horseman.summoning.cannot_summon.no_space");
            case ERROR_HORSE_IS_NOT_BOUND, ERROR_ENTITY_NOT_CREATED ->
                  class_2561.method_43471("gui.horseman.summoning.cannot_summon.wrong_or_defective_horse");
        };
    }
}
