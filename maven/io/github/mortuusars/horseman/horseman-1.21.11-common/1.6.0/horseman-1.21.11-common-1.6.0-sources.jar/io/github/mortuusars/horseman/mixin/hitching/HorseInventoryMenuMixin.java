package io.github.mortuusars.horseman.mixin.hitching;

import io.github.mortuusars.horseman.world.HitchableHorse;
import io.github.mortuusars.horseman.world.menu.LeadSlot;
import net.minecraft.class_12343;
import net.minecraft.class_1263;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1724;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1724.class)
public abstract class HorseInventoryMenuMixin extends class_12343 {
    protected HorseInventoryMenuMixin(int id, class_1661 inventory, class_1263 container, class_1309 mount) {
        super(id, inventory, container, mount);
    }

    @Inject(method = "<init>",
            at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/inventory/HorseInventoryMenu;addSlot(Lnet/minecraft/world/inventory/Slot;)Lnet/minecraft/world/inventory/Slot;",
            ordinal = 1, shift = At.Shift.AFTER))
    private void onInit(int containerId, class_1661 inventory, class_1263 horseContainer, class_1496 horse, int columns, CallbackInfo ci) {
        if (!(horse instanceof HitchableHorse hitchableHorse)) return;
        if (!HitchableHorse.shouldHaveLeadSlot(hitchableHorse)) return;

        method_7621(new LeadSlot(hitchableHorse.horseman$getLeadAccess(), 0, 8, 54) {
            @Override
            public boolean method_7680(@NotNull class_1799 stack) {
                return HitchableHorse.mayPlaceInLeadSlot(hitchableHorse, stack);
            }

            @Override
            public boolean method_7674(@NotNull class_1657 player) {
                class_1799 stack = this.method_7677();
                return !stack.method_31574(class_1802.field_8719) || !HitchableHorse.isHitched(hitchableHorse);
            }

            @Override
            public boolean method_7682() {
                // Making it active on client to keep rendering the slot.
                return horse.method_73183().method_8608() || HitchableHorse.isLeadSlotActive(hitchableHorse);
            }
        });
    }
}
