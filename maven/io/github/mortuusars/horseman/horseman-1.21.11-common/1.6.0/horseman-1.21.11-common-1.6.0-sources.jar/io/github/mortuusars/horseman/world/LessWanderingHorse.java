package io.github.mortuusars.horseman.world;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface LessWanderingHorse {
    static boolean isEnabled() {
        return Config.Server.SADDLED_HORSE_WANDER_RADIUS.get() >= 0;
    }

    @Nullable class_243 horseman$getWanderAnchor();
    void horseman$setWanderAnchor(@Nullable class_243 pos);

    default boolean horseman$isOutsideWanderingLimit(@NotNull class_243 pos) {
        @Nullable class_243 anchor = horseman$getWanderAnchor();
        if (anchor == null) {
            return false;
        }

        int maxWanderDistance = getMaxWanderDistance();
        double distance = anchor.method_1022(pos);

        // Update anchor when far from current anchor position. For cases when horse was moved by minecart, etc.
        // This will prevent it from staying completely still when brought outside of it's wander radius.
        if (distance > maxWanderDistance + getAnchorUpdateThreshold()) {
            horseman$setWanderAnchor(((class_1297)this).method_73189());
            return false;
        }

        return distance > maxWanderDistance;
    }

    static int getMaxWanderDistance() {
        return Config.Server.SADDLED_HORSE_WANDER_RADIUS.get();
    }

    static int getAnchorUpdateThreshold() {
        return 20;
    }
}
