package io.github.mortuusars.horseman.world.summoning;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.*;
import net.minecraft.class_10741;
import net.minecraft.class_18;
import net.minecraft.class_4844;

public class SummoningStorage extends class_18 {
    public static final Codec<SummoningStorage> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.unboundedMap(class_4844.field_41525, StoredBoundHorse.CODEC)
                  .optionalFieldOf("bound_horses", new HashMap<>())
                  .forGetter(SummoningStorage::getBoundHorses),
            Codec.list(class_4844.field_25122)
                  .optionalFieldOf("unbound_horses", new ArrayList<>())
                  .forGetter(SummoningStorage::getUnboundHorses),
            Codec.list(class_4844.field_25122)
                  .optionalFieldOf("horses_to_remove", new ArrayList<>())
                  .forGetter(SummoningStorage::getHorsesToRemove)
    ).apply(instance, SummoningStorage::new));

    @SuppressWarnings("DataFlowIssue")
    public static final class_10741<SummoningStorage> TYPE = new class_10741<>(
            "horseman_horse_calling",
            SummoningStorage::new,
            CODEC,
            null // Thanks mojang for mod-friendly code
    );

    protected final Map<UUID, StoredBoundHorse> boundHorses;
    protected final List<UUID> unboundHorses;
    protected final List<UUID> horsesToRemove;

    private SummoningStorage(Map<UUID, StoredBoundHorse> boundHorses,
                             List<UUID> unboundHorses,
                             List<UUID> horsesToRemove) {
        this.boundHorses = new HashMap<>(boundHorses); // Make sure it's mutable
        this.unboundHorses = new ArrayList<>(unboundHorses); // Make sure it's mutable
        this.horsesToRemove = new ArrayList<>(horsesToRemove); // Make sure it's mutable
        method_80();
    }

    private SummoningStorage() {
        this(Collections.emptyMap(), Collections.emptyList(), Collections.emptyList());
        method_80();
    }

    // --

    public Map<UUID, StoredBoundHorse> getBoundHorses() {
        return boundHorses;
    }

    public List<UUID> getUnboundHorses() {
        return unboundHorses;
    }

    public List<UUID> getHorsesToRemove() {
        return horsesToRemove;
    }
}
