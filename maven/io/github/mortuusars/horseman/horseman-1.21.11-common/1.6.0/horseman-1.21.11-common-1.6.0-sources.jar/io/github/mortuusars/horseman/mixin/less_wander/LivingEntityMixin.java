package io.github.mortuusars.horseman.mixin.less_wander;

import io.github.mortuusars.horseman.world.LessWanderingHorse;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 {
    public LivingEntityMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "onEquipItem", at = @At("RETURN"))
    private void onEquipItem(class_1304 slot, class_1799 oldItem, class_1799 newItem, CallbackInfo ci) {
        if (LessWanderingHorse.isEnabled() && this instanceof LessWanderingHorse lessWanderingHorse && slot == class_1304.field_55946 && !newItem.method_7960()) {
            lessWanderingHorse.horseman$setWanderAnchor(method_73189());
        }
    }

    @Inject(method = "stopRiding", at = @At("HEAD"))
    private void onStopRiding(CallbackInfo ci) {
        if (LessWanderingHorse.isEnabled() && method_5854() instanceof LessWanderingHorse horse) {
            horse.horseman$setWanderAnchor(method_5854().method_73189());
        }
    }
}
