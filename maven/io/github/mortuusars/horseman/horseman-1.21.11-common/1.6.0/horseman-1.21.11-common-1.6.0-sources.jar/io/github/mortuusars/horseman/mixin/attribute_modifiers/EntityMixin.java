package io.github.mortuusars.horseman.mixin.attribute_modifiers;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import net.minecraft.class_1297;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1496;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Adds attribute modifiers to player & horse while mounted to
 * - increase horse's StepHeight by 10% (when enabled)
 * - remove BreakSpeed debuff from not being grounded (when enabled)
 */
@Mixin(value = class_1297.class, priority = 950)
public abstract class EntityMixin {
    @Shadow public abstract class_1937 level();

    @Shadow @Nullable public abstract class_1297 getVehicle();

    @Inject(method = "startRiding(Lnet/minecraft/world/entity/Entity;ZZ)Z",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;addPassenger(Lnet/minecraft/world/entity/Entity;)V"))
    private void startRiding(class_1297 vehicle, boolean force, boolean sendGameEvent, CallbackInfoReturnable<Boolean> cir) {
        if (!(((class_1297)(Object) this) instanceof class_3222 player)) return;

        if (vehicle instanceof class_1496 horse) {
            double stepHeightModifier = Config.Server.HORSE_STEP_HEIGHT_MODIFIER.get();
            if (stepHeightModifier != 0) {
                @Nullable class_1324 instance = horse.method_5996(class_5134.field_47761);
                if (instance != null && instance.method_6199(Horseman.EntityAttributes.MOUNTED_STEP_HEIGHT) == null) {
                    instance.method_26835(new class_1322(Horseman.EntityAttributes.MOUNTED_STEP_HEIGHT,
                            stepHeightModifier, class_1322.class_1323.field_6328));
                }
            }
        }

        double breakSpeedModifier = Config.Server.MOUNTED_BLOCK_BREAK_SPEED_MODIFIER.get();
        if (breakSpeedModifier != 0) {
            @Nullable class_1324 instance = player.method_5996(class_5134.field_49076);
            if (instance != null && instance.method_6199(Horseman.EntityAttributes.MOUNTED_BREAK_SPEED) == null) {
                instance.method_26835(new class_1322(Horseman.EntityAttributes.MOUNTED_BREAK_SPEED,
                        breakSpeedModifier, class_1322.class_1323.field_6330));
            }
        }
    }

    @Inject(method = "removeVehicle", at = @At(value = "HEAD"))
    private void removeVehicle(CallbackInfo ci) {
        if (!(((class_1297)(Object) this) instanceof class_3222 player)) return;

        if (getVehicle() instanceof class_1496 horse && horse.method_5685().size() == 1) {
            @Nullable class_1324 instance = horse.method_5996(class_5134.field_47761);
            if (instance != null) {
                instance.method_6200(Horseman.EntityAttributes.MOUNTED_STEP_HEIGHT);
            }
        }

        @Nullable class_1324 instance = player.method_5996(class_5134.field_49076);
        if (instance != null) {
            instance.method_6200(Horseman.EntityAttributes.MOUNTED_BREAK_SPEED);
        }
    }
}