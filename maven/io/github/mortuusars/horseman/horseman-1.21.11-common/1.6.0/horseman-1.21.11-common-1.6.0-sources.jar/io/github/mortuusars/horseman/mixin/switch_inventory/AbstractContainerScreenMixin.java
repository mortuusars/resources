package io.github.mortuusars.horseman.mixin.switch_inventory;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.client.SwitchInventory;
import net.minecraft.class_1109;
import net.minecraft.class_11908;
import net.minecraft.class_124;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_344;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_490;
import net.minecraft.class_491;
import net.minecraft.class_7919;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_465.class)
public abstract class AbstractContainerScreenMixin extends class_437 {
    @Shadow protected int leftPos;
    @Shadow protected int topPos;

    protected AbstractContainerScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void onKeyPressed(class_11908 event, CallbackInfoReturnable<Boolean> cir) {
        if (!Config.Client.INVENTORY_SWITCH_ENABLED.get()) return;

        if (((class_465<?>) (Object) this) instanceof class_491
                && class_310.method_1551().field_1690.field_1822.method_1417(event)
                && class_310.method_1551().method_74188()) {
            SwitchInventory.switchFromHorse(((class_465<?>)(Object) this));
            class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1));
            cir.setReturnValue(true);
        }

        if (((Object) this) instanceof class_490
                && class_310.method_1551().field_1724 != null && class_310.method_1551().field_1724.method_45773() instanceof class_1496
                && class_310.method_1551().field_1690.field_1822.method_1417(event)
                && class_310.method_1551().method_74188()) {
            SwitchInventory.switchFromInventory((class_465<?>)(Object) this);
            class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1));
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "init", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        if (!Config.Client.INVENTORY_SWITCH_ENABLED.get()) return;
        if (class_310.method_1551().field_1761 == null) return;

        if (((Object) this) instanceof class_491) {
            if (SwitchInventory.mouseX != null && SwitchInventory.mouseY != null) {
                GLFW.glfwSetCursorPos(class_310.method_1551().method_22683().method_4490(), SwitchInventory.mouseX, SwitchInventory.mouseY);
                // Clear remembered cursor pos after setting, to not apply it again when not needed:
                SwitchInventory.mouseX = null;
                SwitchInventory.mouseY = null;
            }

            class_344 button = new class_344(leftPos + Config.Client.INVENTORY_SWITCH_HORSE_BUTTON_X.get(),
                    topPos + Config.Client.INVENTORY_SWITCH_HORSE_BUTTON_Y.get(), 14, 15,
                    SwitchInventory.SWITCH_BUTTON_SPRITES,
                    b -> SwitchInventory.switchFromHorse(((class_465<?>)(Object) this)));

            button.method_47400(class_7919.method_47407(class_2561.method_43469("gui.horseman.switch_inventory.button.from_horse.tooltip",
                class_2561.method_43470(class_310.method_1551().field_1690.field_1822.method_16007().getString()).method_27692(class_124.field_1080)
            )));

            method_37063(button);
        }

        if (((class_465<?>)(Object) this) instanceof class_490
            && class_310.method_1551().field_1761.method_2895()) {

            class_344 button = new class_344(leftPos + Config.Client.INVENTORY_SWITCH_PLAYER_BUTTON_X.get(),
                    topPos + Config.Client.INVENTORY_SWITCH_PLAYER_BUTTON_Y.get(), 14, 15,
                    SwitchInventory.SWITCH_BUTTON_SPRITES,
                    b -> SwitchInventory.switchFromInventory(((class_465<?>)(Object) this)));

            class_2561 vehicleName = class_310.method_1551().field_1724 != null
                    && class_310.method_1551().field_1724.method_5854() instanceof class_1309 entity
                    ? entity.method_5477()
                    : class_2561.method_43471("gui.horseman.switch_inventory.button.from_inventory..tooltip.mount");

            button.method_47400(class_7919.method_47407(class_2561.method_43469("gui.horseman.switch_inventory.button.from_inventory.tooltip",
                    vehicleName,
                    class_2561.method_43470(class_310.method_1551().field_1690.field_1822.method_16007().getString()).method_27692(class_124.field_1080)
            )));

            method_37063(button);
        }
    }
}