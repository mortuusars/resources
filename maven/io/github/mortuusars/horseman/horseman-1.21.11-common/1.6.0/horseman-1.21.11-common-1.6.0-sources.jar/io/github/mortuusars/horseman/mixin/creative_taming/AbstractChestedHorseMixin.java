package io.github.mortuusars.horseman.mixin.creative_taming;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_10192;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1492;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1492.class)
public abstract class AbstractChestedHorseMixin extends class_1496 {
    protected AbstractChestedHorseMixin(class_1299<? extends class_1496> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "mobInteract", at = @At("HEAD"), cancellable = true)
    private void onMobInteract(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        if (Config.Server.HORSE_CREATIVE_TAMING.get()
                && player.method_68878()
                && player.method_5998(hand).method_58694(class_9334.field_54196) instanceof class_10192 equippable
                && equippable.comp_3174() == class_1304.field_55946
                && method_5805()
                && !method_66672()
                && !method_6727()
                && !method_6109()) {
            if (!method_73183().method_8608()) {
                method_6752(player);
            }
            cir.setReturnValue(class_1269.field_5812);
        }
    }
}
