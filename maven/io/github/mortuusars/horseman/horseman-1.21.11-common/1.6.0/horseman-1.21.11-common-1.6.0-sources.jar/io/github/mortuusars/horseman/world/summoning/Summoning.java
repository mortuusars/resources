package io.github.mortuusars.horseman.world.summoning;

import com.google.common.base.Preconditions;
import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.world.HitchableHorse;
import net.minecraft.class_11352;
import net.minecraft.class_11368;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1324;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_5134;
import net.minecraft.class_8942;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public class Summoning {
    protected final SummoningStorage storage;

    public Summoning(MinecraftServer server) {
        storage = server.method_30002().method_17983().method_17924(SummoningStorage.TYPE);
    }

    public SummoningStorage getStorage() {
        return storage;
    }

    public boolean isBound(class_1496 horse) {
        return horse.getHorsemanBoundData() != null;
    }

    public @Nullable StoredBoundHorse getHorseBoundTo(UUID owner) {
        return getStorage().getBoundHorses().get(owner);
    }

    public @Nullable StoredBoundHorse getHorseBoundTo(class_1657 owner) {
        return getHorseBoundTo(owner.method_5667());
    }

    protected void addOrUpdateBoundHorse(class_1496 horse) {
        @Nullable BoundData data = horse.getHorsemanBoundData();
        if (data == null) {
            Horseman.LOGGER.warn("Tried to update a horse that does not have a bound data. Horse: {}", horse);
            return;
        }
        getStorage().getBoundHorses().put(data.owner(), new StoredBoundHorse(horse));
        getStorage().method_80();
        Horseman.LOGGER.debug("Updated Stored Horse to [{}]", horse.method_5667());
    }

    // --

    public void bind(class_3218 level, class_1496 horse, class_1657 player) {
        unbindExistingHorse(level, player);
        horse.setHorsemanBoundData(new BoundData(player));
        addOrUpdateBoundHorse(horse);
    }

    public void unbindHorse(class_3218 level, StoredBoundHorse boundHorse) {
        boundHorse.boundData().ifPresent(data -> {
            getStorage().getBoundHorses().remove(data.owner());
        });
        if (tryFindLoadedHorse(level, boundHorse.uuid()) instanceof class_1496 loadedHorse) {
            loadedHorse.setHorsemanBoundData(null);
        } else {
            getStorage().getUnboundHorses().add(boundHorse.uuid());
        }
        getStorage().method_80();
    }

    public void unbindExistingHorse(class_3218 level, class_1657 player) {
        @Nullable StoredBoundHorse boundHorse = getHorseBoundTo(player);
        if (boundHorse != null) {
            unbindHorse(level, boundHorse);
        }
    }

    // -- Calling

    public HorseSummoningResult summonBoundHorseTo(class_3222 player) {
        class_3218 level = player.method_51469();
        @Nullable StoredBoundHorse boundHorse = getHorseBoundTo(player);

        if (boundHorse == null) return HorseSummoningResult.NO_BOUND_HORSE;
        if (boundHorse.isDead()) return HorseSummoningResult.HORSE_IS_DEAD;

        @Nullable class_1496 existingHorse = tryFindLoadedHorse(level, boundHorse.uuid());
        if (existingHorse != null) {
            if (!isBound(existingHorse)) {
                return HorseSummoningResult.ERROR_HORSE_IS_NOT_BOUND;
            }

            addOrUpdateBoundHorse(existingHorse); // Update before calling to have the latest state
            boundHorse = getHorseBoundTo(player); // Re-query updated state
            Preconditions.checkNotNull(boundHorse); // Should not be null as we check if the horse isBound above.
        }

        if (!dimensionsAreValid(player, boundHorse)) return HorseSummoningResult.INVALID_DIMENSION;
        if (!isInRange(player, boundHorse)) return HorseSummoningResult.TOO_FAR;

        if (existingHorse != null && canWalkInsteadOfResummoning(player, existingHorse)) {
            return walkToPlayer(player, existingHorse);
        }

        return summonHorse(player, boundHorse);
    }

    protected HorseSummoningResult walkToPlayer(class_3222 player, class_1496 horse) {
        // Leashed horses would not react to calling. So we are unhitching to allow it to move.
        // (but only hitched, regular leashed will stay, to not drop leash far away from player)
        if (horse instanceof HitchableHorse hitchableHorse && HitchableHorse.isHitched(hitchableHorse)) {
            horse.method_65894();
        }

        class_1324 followRangeAttribute = horse.method_5996(class_5134.field_23717);
        if (followRangeAttribute != null) {
            followRangeAttribute.method_6192(Config.Server.HORSE_SUMMONING_MAX_WALKING_DISTANCE.get());
        }

        horse.method_5942().method_6335(player, Config.Server.HORSE_SUMMONING_WALK_MOVEMENT_SPEED.get());
        addOrUpdateBoundHorse(horse);

        Horseman.CriteriaTriggers.HORSE_SUMMONED.get().trigger(player, horse);

        return HorseSummoningResult.SUCCESS;
    }

    protected HorseSummoningResult summonHorse(class_3222 player, @NotNull StoredBoundHorse boundHorse) {
        class_3218 level = player.method_51469();

        class_11368 input = class_11352.method_71417(class_8942.field_60348, level.method_30349(), boundHorse.tag());
        Optional<class_1299<?>> type = class_1299.method_17684(input);
        if (type.isEmpty()) {
            Horseman.LOGGER.error("Failed to get the type from a stored boundHorse data. " +
                    "'id' probably wasn't saved properly. Tag '{}'.", boundHorse.tag());
            return HorseSummoningResult.ERROR_ENTITY_NOT_CREATED;
        }

        @Nullable class_1297 entity = type.get().method_5883(player.method_51469(), class_3730.field_16471);
        if (!(entity instanceof class_1496 newHorse)) {
            Horseman.LOGGER.error("Created entity isn't an AbstractHorse but {}. Something went wrong.", entity);
            return HorseSummoningResult.ERROR_ENTITY_NOT_CREATED;
        }

        newHorse.method_5651(input);
        newHorse.method_5826(UUID.randomUUID());
        newHorse.method_5814(player.method_23317(), player.method_23318(), player.method_23321());

        if (!hasSpaceFor(level, player, newHorse)) return HorseSummoningResult.NO_SPACE;

        removeOldBoundHorse(level, boundHorse);
        addOrUpdateBoundHorse(newHorse);

        player.method_51469().method_8649(newHorse);
        Horseman.CriteriaTriggers.HORSE_SUMMONED.get().trigger(player, newHorse);

        Horseman.LOGGER.debug("{} has summoned Horse [{}]", player.method_5820(), newHorse.method_5667());

        return HorseSummoningResult.SUCCESS;
    }

    // -- Conditions

    protected boolean dimensionsAreValid(class_1657 player, StoredBoundHorse boundHorse) {
        return switch (Config.Server.HORSE_SUMMONING_DIMENSION_HANDLING.get()) {
            case ANY -> true;
            case SAME -> boundHorse.isInSameDimension(player);
            case WHITELIST -> {
                String playerDimension = player.method_73183().method_27983().method_29177().toString();
                yield Config.Server.HORSE_SUMMONING_DIMENSIONS.get().stream()
                        .anyMatch(dimension -> dimension.equals(playerDimension));
            }
            case BLACKLIST -> {
                String playerDimension = player.method_73183().method_27983().method_29177().toString();
                yield Config.Server.HORSE_SUMMONING_DIMENSIONS.get().stream()
                        .noneMatch(dimension -> dimension.equals(playerDimension));
            }
        };
    }

    protected boolean isInRange(class_1657 player, StoredBoundHorse boundHorse) {
        int maxDistance = Config.Server.HORSE_SUMMONING_MAX_DISTANCE.get();
        if (maxDistance < 0) return true;
        int distance = (int) boundHorse.position().method_1022(player.method_73189());
        return distance <= maxDistance;
    }

    protected boolean canWalkInsteadOfResummoning(class_1657 player, class_1496 horse) {
        return player.method_73183().method_27983().equals(horse.method_73183().method_27983())
                && player.method_5739(horse) < Config.Server.HORSE_SUMMONING_MAX_WALKING_DISTANCE.get();
    }

    protected boolean hasSpaceFor(class_3218 level, class_1657 player, class_1496 horse) {
        StoredBoundHorse boundHorse = new StoredBoundHorse(horse);
        class_11368 input = class_11352.method_71417(class_8942.field_60348, level.method_30349(), boundHorse.tag());
        Optional<class_1299<?>> type = class_1299.method_17684(input);
        if (type.isEmpty()) return false;

        @Nullable class_1297 entity = type.get().method_5883(player.method_73183(), class_3730.field_16471);
        if (!(entity instanceof class_1496 newHorse)) return false;

        newHorse.method_5651(input);
        newHorse.method_5826(UUID.randomUUID());
        newHorse.method_5814(player.method_23317(), player.method_23318(), player.method_23321());

        return !newHorse.method_5757();
    }

    // -- Events

    public boolean onHorseLoaded(class_3218 level, class_1496 horse) {
        if (!isBound(horse)) return false;

        UUID entityUUID = horse.method_5667();

        if (getStorage().getHorsesToRemove().contains(entityUUID)) {
            horse.setHorsemanBoundData(null); // Remove data to avoid re-updating in onHorseUnloaded
            getStorage().getHorsesToRemove().remove(entityUUID);
            getStorage().getUnboundHorses().remove(entityUUID);
            getStorage().method_80();
            horse.method_5772();
            Horseman.LOGGER.debug("Horse [{}] is discarded", entityUUID);
            return true; // Prevent loading
        }

        if (getStorage().getUnboundHorses().contains(entityUUID)) {
            horse.setHorsemanBoundData(null);
            getStorage().getUnboundHorses().remove(entityUUID);
            getStorage().method_80();
            Horseman.LOGGER.debug("Unbound Horse [{}] data is cleared.", entityUUID);
        }

        return false;
    }

    // Also called when horse has died.
    public void onHorseUnloaded(class_3218 level, class_1496 horse) {
        if (isBound(horse)) {
            addOrUpdateBoundHorse(horse);
            if (horse.method_29504() && horse.method_5797() == null) {
                Horseman.LOGGER.info("Bound horse has died at [{}, {}, {}].", (int)horse.method_23317(), (int)horse.method_23318(), (int)horse.method_23321());
            }
        }
    }

    // -- Util

    protected @Nullable class_1496 tryFindLoadedHorse(class_3218 level, UUID entityUuid) {
        for (class_3218 dimension : level.method_8503().method_3738()) {
            if (dimension.method_66347(entityUuid) instanceof class_1496 horse) {
                return horse;
            }
        }
        return null;
    }

    protected void removeOldBoundHorse(class_3218 level, @NotNull StoredBoundHorse boundHorse) {
        boolean removed = false;

        // Remove already loaded horse immediately:
        for (class_3218 dimension : level.method_8503().method_3738()) {
            @Nullable class_1297 existingHorse = dimension.method_66347(boundHorse.uuid());
            if (existingHorse != null) {
                existingHorse.method_31472();
                Horseman.LOGGER.info("Loaded Bound Horse [{}] is discarded", boundHorse.uuid());
                removed = true;
                break;
            }
        }

        if (!removed) {
            // Old entity will be removed when it tries to load:
            getStorage().getHorsesToRemove().add(boundHorse.uuid());
            getStorage().method_80();
            Horseman.LOGGER.info("Bound Horse [{}] is scheduled to be removed next time it loads into the world.", boundHorse.uuid());
        }
    }
}
