package io.github.mortuusars.horseman.mixin.hitching;

import io.github.mortuusars.horseman.world.HitchableHorse;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1496;
import net.minecraft.class_1530;
import net.minecraft.class_1532;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_9691;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1532.class)
public abstract class LeashKnotEntityMixin extends class_9691 {
    @Shadow
    public abstract void playPlacementSound();

    protected LeashKnotEntityMixin(class_1299<? extends class_1530> entityType, class_1937 level) {
        super(entityType, level);
    }

    /**
     * Hitch a horse to an existing knot, without removing it first.
     */
    @Inject(method = "interact", at = @At("HEAD"), cancellable = true)
    private void onInteract(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        if (player.method_5668() instanceof class_1496 horse
                && horse instanceof HitchableHorse hitchableHorse) {
            if (HitchableHorse.isHitched(hitchableHorse)) {
                horse.method_65894();
                this.method_43077(class_3417.field_60854);
                cir.setReturnValue(class_1269.field_5812);
            } else if (HitchableHorse.canHitch(hitchableHorse)) {
                horse.method_60964(player, true);
                HitchableHorse.setHitched(hitchableHorse, true);

                if (!method_73183().method_8608()) {
                    HitchableHorse.syncHorseDataToTrackingClients(hitchableHorse);
                    playPlacementSound();
                }
            }
        }
    }
}
