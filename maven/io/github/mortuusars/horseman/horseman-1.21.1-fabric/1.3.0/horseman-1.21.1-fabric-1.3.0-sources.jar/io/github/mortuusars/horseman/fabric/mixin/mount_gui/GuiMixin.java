package io.github.mortuusars.horseman.fabric.mixin.mount_gui;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1309;
import net.minecraft.class_1316;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value = class_329.class)
public abstract class GuiMixin {
    @Shadow
    protected abstract int getVisibleVehicleHeartRows(int vehicleHealth);

    @Shadow
    @Nullable
    protected abstract class_1309 getPlayerVehicleWithHealth();

    @Shadow
    protected abstract int getVehicleMaxHearts(class_1309 vehicle);

    @Shadow protected abstract boolean isExperienceBarVisible();

    @Unique
    private long horseman$lastTickVehicleInWater = -1;

    @Redirect(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;jumpableVehicle()Lnet/minecraft/world/entity/PlayerRideableJumping;"))
    private class_1316 renderHotbarAndDecorations_jumpableVehicle(class_746 player) {
        @Nullable class_1316 vehicle = player.method_45773();

        if (!Config.Client.IMPROVED_MOUNT_GUI.get()) return vehicle;

        class_310 mc = class_310.method_1551();

        if (mc.field_1761 == null || !mc.field_1761.method_2913()) return vehicle;

        if (vehicle instanceof class_1309 entity && entity.method_5799()) {
            horseman$lastTickVehicleInWater = player.method_37908().method_8510();
        }

        if (vehicle != null && !mc.field_1690.field_1903.method_1434() && player.method_3151() <= 0
                || (player.method_37908().method_8510() - horseman$lastTickVehicleInWater < 10)) {
            return null; // Prevent jump bar from rendering.
        }

        return vehicle;
    }

    @Redirect(method = "renderPlayerHealth", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;getVehicleMaxHearts(Lnet/minecraft/world/entity/LivingEntity;)I"))
    private int renderPlayerHealth_getVehicleMaxHearts(class_329 instance, class_1309 entity) {
        if (!Config.Client.IMPROVED_MOUNT_GUI.get()) return getVehicleMaxHearts(entity);
        return 0; // Forces hunger bar rendering, because it is not rendered when vehicle hearts is not 0.
    }

    @Redirect(method = "renderPlayerHealth", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;getVisibleVehicleHeartRows(I)I"))
    private int renderPlayerHealth_getVisibleVehicleHeartRows(class_329 instance, int hearts) {
        if (!Config.Client.IMPROVED_MOUNT_GUI.get()) return getVisibleVehicleHeartRows(hearts);
        // 'hears' will be 0 here, due to it being set in 'renderPlayerHealth_getVehicleMaxHearts'.
        class_1309 livingEntity = getPlayerVehicleWithHealth();
        int vehicleHearts = getVehicleMaxHearts(livingEntity);
        return getVisibleVehicleHeartRows(vehicleHearts);
    }

    @ModifyVariable(method = "renderVehicleHealth", at = @At(value = "STORE"), ordinal = 2)
    private int renderVehicleHealth(int y) {
        if (Config.Client.IMPROVED_MOUNT_GUI.get()
                && class_310.method_1551().field_1761 != null
                && class_310.method_1551().field_1761.method_2908()) {
            y -= 10; // Make room for hunger bar
        }
        return y;
    }

    @ModifyReturnValue(method = "isExperienceBarVisible", at = @At("RETURN"))
    private boolean isExperienceBarVisible(boolean original) {
        if (!Config.Client.IMPROVED_MOUNT_GUI.get()) return original;
        class_310 mc = class_310.method_1551();
        if (mc.field_1761 == null || !mc.field_1761.method_2913() || mc.field_1687 == null || mc.field_1724 == null) return original;
        if (!mc.field_1690.field_1903.method_1434() && mc.field_1724.method_3151() <= 0
                || mc.field_1687.method_8510() - horseman$lastTickVehicleInWater < 10) {
            return true;
        }
        return original;
    }

    @Redirect(method = "renderExperienceLevel", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;isExperienceBarVisible()Z"))
    private boolean renderExperienceLevel(class_329 instance) {
        if (!Config.Client.IMPROVED_MOUNT_GUI.get()) return isExperienceBarVisible();
        // Always render exp level:
        return class_310.method_1551().field_1761 != null && class_310.method_1551().field_1761.method_2913();
    }
}
