package io.github.mortuusars.horseman.advancement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_1496;
import net.minecraft.class_2048;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public class HorseSummonedTrigger extends class_4558<HorseSummonedTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player, class_1496 horse) {
        this.method_22510(player, triggerInstance ->
                triggerInstance.matches(player, horse));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  Optional<class_2048> horse) implements SimpleInstance {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                        class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::player),
                        class_2048.field_45746.optionalFieldOf("horse").forGetter(TriggerInstance::horse))
                .apply(instance, TriggerInstance::new));

        public boolean matches(class_3222 player, class_1496 horse) {
            return (this.horse.isEmpty() || this.horse.get().method_8909(player.method_51469(), horse.method_73189(), horse));
        }
    }
}