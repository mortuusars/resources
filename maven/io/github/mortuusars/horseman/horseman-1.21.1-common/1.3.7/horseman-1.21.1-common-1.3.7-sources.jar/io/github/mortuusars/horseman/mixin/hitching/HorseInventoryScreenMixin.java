package io.github.mortuusars.horseman.mixin.hitching;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.client.LeadOnHorse;
import io.github.mortuusars.horseman.world.HitchableHorse;
import io.github.mortuusars.horseman.world.menu.LeadSlot;
import net.minecraft.class_1496;
import net.minecraft.class_1661;
import net.minecraft.class_1724;
import net.minecraft.class_1735;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_491;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_491.class)
public abstract class HorseInventoryScreenMixin extends class_465<class_1724> {
    @Shadow
    @Final
    private class_1496 horse;
    @Unique
    private static final class_2960 LEAD_SLOT_TEXTURE = Horseman.resource("textures/gui/lead_slot.png");

    public HorseInventoryScreenMixin(class_1724 menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
    }

    @Inject(method = "render", at = @At(value = "RETURN"))
    private void onRender(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (!(this.horse instanceof HitchableHorse hitchableHorse)) return;

        if (HitchableHorse.shouldHaveLeadSlot(hitchableHorse)) {
            if (!HitchableHorse.isHitched(hitchableHorse)) return;

            for (class_1735 slot : method_17577().field_7761) {
                if (slot instanceof LeadSlot && slot.method_7677().method_31574(class_1802.field_8719)) {
                    // Darken the slot
                    int leftPos = (this.field_22789 - this.field_2792) / 2;
                    int topPos = (this.field_22790 - this.field_2779) / 2;
                    RenderSystem.enableBlend();
                    RenderSystem.defaultBlendFunc();
                    guiGraphics.method_25291(LEAD_SLOT_TEXTURE, leftPos + slot.field_7873 - 1, topPos + slot.field_7872 - 1, 350, 0, 18, 18, 18, 256, 256);
                    RenderSystem.disableBlend();
                }
            }
        } else if (HitchableHorse.requiresLead() && HitchableHorse.hasLead(hitchableHorse)) {
            LeadOnHorse.renderInventory(guiGraphics, mouseX, mouseY, partialTick, field_2776, field_2800, this.horse);
        }
    }

    @Inject(method = "renderBg", at = @At(value = "RETURN"))
    private void onRenderBg(class_332 guiGraphics, float partialTick, int mouseX, int mouseY, CallbackInfo ci) {
        if (!(this.horse instanceof HitchableHorse hitchableHorse)) return;

        if (HitchableHorse.shouldHaveLeadSlot(hitchableHorse)) {
            int leftPos = (this.field_22789 - this.field_2792) / 2;
            int topPos = (this.field_22790 - this.field_2779) / 2;
            guiGraphics.method_25302(LEAD_SLOT_TEXTURE, leftPos + 7, topPos + 53, 0, 0, 18, 18);
        }
    }
}
