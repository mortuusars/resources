package io.github.mortuusars.horseman.mixin.render;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalFloatRef;
import io.github.mortuusars.horseman.client.HorseRenderUtils;
import net.minecraft.class_1498;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4073;
import net.minecraft.class_5253;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(value = class_4073.class, priority = 950)
public abstract class HorseArmorLayerMixin {
    @WrapOperation(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/animal/horse/Horse;FFFFFF)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/RenderType;entityCutoutNoCull(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/renderer/RenderType;"))
    class_1921 makeRenderLayerTranslucent(class_2960 location, Operation<class_1921> original, @Local(argsOnly = true) class_1498 horse, @Share("alpha") LocalFloatRef alpha) {
        float a = HorseRenderUtils.getAlpha(horse);
        alpha.set(a);
        if (a < 1.0) {
            return class_1921.method_23580(location);
        }
        return original.call(location);
    }

    @ModifyArg(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/animal/horse/Horse;FFFFFF)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/HorseModel;renderToBuffer(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;III)V"),
            index = 4)
    int setOpacityForRender(int color, @Share("alpha") LocalFloatRef alpha) {
        int a = class_5253.class_5254.method_27762(color);
        a = class_3532.method_15340((int)(a * alpha.get()), 0, 255);
        return class_5253.class_5254.method_58144(a, color);
    }
}