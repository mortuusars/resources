package io.github.mortuusars.horseman.mixin.momentum;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 {
    @Shadow
    public abstract float getSpeed();

    public LivingEntityMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "getFlyingSpeed", at = @At("RETURN"), cancellable = true)
    private void onGetFlyingSpeed(CallbackInfoReturnable<Float> cir) {
        class_1309 entity = (class_1309) (Object) this;
        if (entity instanceof class_1496
                && Config.Server.INCREASE_HORSE_AIRBORNE_SPEED.get()
                && method_5642() instanceof class_1657) {
            float delta = Config.Server.INCREASE_HORSE_AIRBORNE_SPEED_AMOUNT.get().floatValue();
            float vanillaSpeed = cir.getReturnValue();
            float groundSpeed = getSpeed() * 0.216f;
            cir.setReturnValue(class_3532.method_16439(delta, vanillaSpeed, groundSpeed));
        }
    }

    @Inject(method = "travelRidden", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;travel(Lnet/minecraft/world/phys/Vec3;)V"))
    private void onTravelRidden(class_1657 player, class_243 travelVector, CallbackInfo ci) {
        class_1309 entity = (class_1309) (Object) this;
        if (entity instanceof class_1496 horse
                && Config.Server.HORSE_FAST_STEP_DOWN.get()
                && method_5642() instanceof class_1657
                && Horseman.shouldHorseStepDown(horse)) {
            // Applies downward momentum to connect with the ground faster and regain running speed.
            entity.method_45319(new class_243(0, -0.5, 0));
        }
    }
}