package io.github.mortuusars.horseman.mixin.render;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalFloatRef;
import io.github.mortuusars.horseman.client.HorseRenderUtils;
import net.minecraft.class_1498;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_5167;
import net.minecraft.class_5253;
import net.minecraft.class_549;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value = class_5167.class, priority = 960)
public abstract class HorseMarkingLayerMixin extends class_3887<class_1498, class_549<class_1498>> {
    public HorseMarkingLayerMixin(class_3883<class_1498, class_549<class_1498>> renderer) {
        super(renderer);
    }

    @WrapOperation(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/animal/horse/Horse;FFFFFF)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/RenderType;entityTranslucent(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/renderer/RenderType;"))
    class_1921 makeRenderLayerTranslucent(class_2960 location, Operation<class_1921> original, @Local(argsOnly = true) class_1498 horse, @Share("alpha") LocalFloatRef alpha) {
        float a = HorseRenderUtils.getAlpha(horse);
        alpha.set(a);
        if (a < 1.0) {
            return class_1921.method_23580(location);
        }
        return original.call(location);
    }

    @WrapOperation(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/animal/horse/Horse;FFFFFF)V",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/HorseModel;renderToBuffer(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;II)V"))
    private void renderWithOpacity(class_549<?> instance, class_4587 poseStack, class_4588 vertexConsumer,
                                int packedLight, int packedOverlay, Operation<Void> original, @Share("alpha") LocalFloatRef alpha) {
        float aVal = alpha.get();
        if (aVal < 1.0f) {
            int a = class_3532.method_15340((int)(255 * aVal), 0, 255);
            method_17165().method_2828(poseStack, vertexConsumer, packedLight, class_4608.field_21444, class_5253.class_5254.method_58144(a, 0xFFFFFF));
        } else {
            original.call(instance, poseStack, vertexConsumer, packedLight, packedOverlay);
        }
    }
}