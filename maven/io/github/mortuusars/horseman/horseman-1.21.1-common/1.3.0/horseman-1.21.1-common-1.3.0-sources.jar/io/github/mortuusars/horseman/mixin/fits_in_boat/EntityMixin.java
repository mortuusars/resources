package io.github.mortuusars.horseman.mixin.fits_in_boat;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1297;
import net.minecraft.class_1496;
import net.minecraft.class_1690;
import net.minecraft.class_238;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1297.class)
public class EntityMixin {
    @ModifyReturnValue(method = "getBoundingBox", at = @At("RETURN"))
    private class_238 onGetBoundingBox(class_238 original) {
        if (!Config.Server.HORSE_IN_BOAT.get()) return original;
        if (((class_1297)(Object)this) instanceof class_1496 horse && horse.method_5854() instanceof class_1690) {
            return original.method_35580(0.1f, 0, 0.1f);
        }
        return original;
    }
}
