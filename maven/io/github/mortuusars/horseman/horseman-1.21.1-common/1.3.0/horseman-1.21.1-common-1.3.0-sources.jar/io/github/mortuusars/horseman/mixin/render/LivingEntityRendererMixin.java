package io.github.mortuusars.horseman.mixin.render;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalIntRef;
import io.github.mortuusars.horseman.client.HorseRenderUtils;
import net.minecraft.class_1309;
import net.minecraft.class_1472;
import net.minecraft.class_1496;
import net.minecraft.class_1767;
import net.minecraft.class_1921;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5253;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_897;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_922.class, priority = 950)
public abstract class LivingEntityRendererMixin<T extends class_1309, M extends class_583<T>> extends class_897<T> {
    protected LivingEntityRendererMixin(class_5617.class_5618 context) {
        super(context);
    }

    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At("HEAD") )
    void setAlpha(T entity, float entityYaw, float partialTicks, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci, @Share("alpha") LocalIntRef alpha) {
        if (entity instanceof class_1496) {
            alpha.set(HorseRenderUtils.getAlpha(entity));
        }
    }

    @ModifyArg(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/EntityModel;renderToBuffer(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;III)V"),
            index = 4)
    int setOpacityAndChromaForRender(int color, @Local(argsOnly = true) class_1309 entity, @Share("alpha") LocalIntRef alpha) {
        if (entity instanceof class_1496) {
            if (HorseRenderUtils.isJeb(entity)) {
                int index = entity.field_6012 / 25 + entity.method_5628();
                int dyesCount = class_1767.values().length;
                int currentIndex = index % dyesCount;
                int nextIndex = (index + 1) % dyesCount;
                float transition = ((float)(entity.field_6012 % 25) + class_310.method_1551().method_60646().method_60637(true)) / 25.0F;
                int currentColor = class_1472.method_6634(class_1767.method_7791(currentIndex));
                int nextColor = class_1472.method_6634(class_1767.method_7791(nextIndex));
                color = class_5253.class_5254.method_48780(transition, currentColor, nextColor);
                // increase brightness because the horse texture is a bit dark
                color = class_5253.class_5254.method_57173(
                        Math.min(class_5253.class_5254.method_27765(color) * 2, 255),
                        Math.min(class_5253.class_5254.method_27766(color) * 2, 255),
                        Math.min(class_5253.class_5254.method_27767(color) * 2, 255));
            }

            int a = class_5253.class_5254.method_27762(color);
            a = class_3532.method_15340((int)(a * (alpha.get() / 255f)), 0, 255);
            return class_5253.class_5254.method_58144(a, color);
        } else {
            return color;
        }
    }

    @Inject(method = "getRenderType", at = @At("HEAD"), cancellable = true)
    private void getRenderType(T entity, boolean bodyVisible, boolean translucent, boolean glowing,
                               CallbackInfoReturnable<class_1921> cir, @Share("alpha") LocalIntRef alphaRef) {
        if (entity instanceof class_1496 && alphaRef.get() != 255) {
            cir.setReturnValue(class_1921.method_23580(method_3931(entity)));
        }
    }
}