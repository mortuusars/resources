package io.github.mortuusars.horseman.client;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class HorseRenderUtils {
    public static boolean isJeb(class_1309 entity) {
        return Config.Client.JEB_HORSE.get() && entity.method_5797() != null && entity.method_5797().getString().equals("jeb_");
    }

    public static int getAlpha(class_1309 entity) {
        if (!Config.Client.TRANSPARENT_HORSE_ENABLED.get()) return 255;

        if (!Config.Client.TRANSPARENT_HORSE_ENABLED.get()
                || class_310.method_1551().field_1724 == null
                || !class_310.method_1551().field_1690.method_31044().method_31034()
                || !(entity instanceof class_1496 horse)
                || !class_310.method_1551().field_1724.equals(horse.method_5642())) {
            return 255;
        }

        int startAngle = Config.Client.TRANSPARENT_HORSE_START_ANGLE.get();

        float angle = class_310.method_1551().field_1724.field_6004;
        if (angle < startAngle) return 255;

        int maxTransparency = Config.Client.TRANSPARENT_HORSE_MAX_TRANSPARENCY.get();
        int endAngle = Config.Client.TRANSPARENT_HORSE_END_ANGLE.get();

        float delta = (Math.min(angle, endAngle) - startAngle) / (endAngle - startAngle);
        return (int) class_3532.method_16439(delta, 255, maxTransparency);
    }
}
