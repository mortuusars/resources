package io.github.mortuusars.horseman.mixin.leash_sounds;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import net.minecraft.class_1297;
import net.minecraft.class_3419;
import net.minecraft.class_9817;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_9817.class)
public interface LeashableMixin {
    @Inject(method = "tickLeash", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Leashable;leashTooFarBehaviour()V"))
    private static <E extends class_1297 & class_9817> void tickLeash(E entity, CallbackInfo ci) {
        if (Config.Server.LEASH_KNOT_SOUNDS.get()) {
            entity.method_37908().method_43129(null, entity, Horseman.SoundEvents.LEASH_BREAK.get(), class_3419.field_15254, 1f, 1f);
        }
    }
}
