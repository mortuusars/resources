package io.github.mortuusars.horseman.world.item.crafting.recipe.serializer;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.horseman.world.item.crafting.recipe.ComponentTransferringRecipe;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2371;
import net.minecraft.class_3955;
import net.minecraft.class_7710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;

public class ComponentTransferringRecipeSerializer<T extends ComponentTransferringRecipe> implements class_1865<T> {
    private final MapCodec<T> codec;
    private final class_9139<class_9129, T> streamCodec;

    public ComponentTransferringRecipeSerializer(String recipeName, String sourceName, RecipeConstructor<T> constructor) {
        this.codec = createCodec(recipeName, sourceName, constructor);
        this.streamCodec = createStreamCodec(constructor);
    }

    public ComponentTransferringRecipeSerializer(String serializedSourceIngredientName, RecipeConstructor<T> constructor) {
        this("component_transferring", serializedSourceIngredientName, constructor);
    }

    public ComponentTransferringRecipeSerializer(RecipeConstructor<T> constructor) {
        this("component_transferring", "source_ingredient", constructor);
    }

    protected @NotNull MapCodec<T> createCodec(String recipeTypeName, String sourceIngredientName, RecipeConstructor<T> constructor) {
        return RecordCodecBuilder.mapCodec(
                instance -> instance.group(
                        class_7710.field_40252.fieldOf("category").orElse(class_7710.field_40251).forGetter(class_3955::method_45441),
                        class_1856.field_46096.fieldOf(sourceIngredientName).forGetter(ComponentTransferringRecipe::getSourceIngredient),
                        class_1856.field_46096
                                .listOf()
                                .fieldOf("ingredients")
                                .flatXmap(
                                        list -> {
                                            if (list.isEmpty()) {
                                                return DataResult.error(() -> "No ingredients for %s recipe".formatted(recipeTypeName));
                                            } else {
                                                return list.size() > 9
                                                        ? DataResult.error(() -> ("Too many ingredients for %s recipe. Maximum is: %s".formatted(9, recipeTypeName)))
                                                        : DataResult.success(class_2371.method_10212(class_1856.field_9017, list.toArray(new class_1856[0])));
                                            }
                                        },
                                        DataResult::success
                                )
                                .forGetter(ComponentTransferringRecipe::method_8117),
                        class_1799.field_51397.fieldOf("result").forGetter(ComponentTransferringRecipe::getResult)
                ).apply(instance, constructor::create)
        );
    }

    protected @NotNull class_9139<class_9129, T> createStreamCodec(RecipeConstructor<T> constructor) {
        return class_9139.method_56905(
                class_7710.field_48353, class_3955::method_45441,
                class_1856.field_48355, ComponentTransferringRecipe::getSourceIngredient,
                class_9135.method_56376(class_2371::method_37434, class_1856.field_48355), ComponentTransferringRecipe::method_8117,
                class_1799.field_48349, ComponentTransferringRecipe::getResult,
                constructor::create);
    }

    @Override
    public @NotNull MapCodec<T> method_53736() {
        return codec;
    }

    @Override
    public @NotNull class_9139<class_9129, T> method_56104() {
        return streamCodec;
    }

    @FunctionalInterface
    public interface RecipeConstructor<T extends ComponentTransferringRecipe> {
        T create(class_7710 arg, class_1856 sourceIngredient, class_2371<class_1856> ingredients, class_1799 result);
    }
}
