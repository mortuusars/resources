package io.github.mortuusars.horseman.integration.jei;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.integration.jei.recipe.ComponentTransferringShapelessExtension;
import io.github.mortuusars.horseman.integration.jei.subtypes.InstrumentSubtypeInterpreter;
import io.github.mortuusars.horseman.world.item.crafting.recipe.ComponentTransferringRecipe;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.registration.*;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import org.jetbrains.annotations.NotNull;

import java.util.List;

@JeiPlugin
public class HorsemanJeiPlugin implements IModPlugin {
    private static final class_2960 ID = Horseman.resource("jei_plugin");

    @Override
    public @NotNull class_2960 getPluginUid() {
        return ID;
    }

    @Override
    public void registerItemSubtypes(ISubtypeRegistration registration) {
        // Adds all horns with all instruments to JEI. Otherwise, only one will show up.
        registration.registerSubtypeInterpreter(Horseman.Items.COPPER_HORN.get(), InstrumentSubtypeInterpreter.INSTANCE);
    }

    @Override
    public void registerRecipes(@NotNull IRecipeRegistration registration) {
        if (Config.Client.SHOW_JEI_INFORMATION.get()) {
            registration.addItemStackInfo(List.of(new class_1799(Horseman.Items.COPPER_HORN.get())),
                    class_2561.method_43471("horseman.jei.info.copper_horn1"),
                    class_2561.method_43471("horseman.jei.info.copper_horn2"),
                    class_2561.method_43471("horseman.jei.info.copper_horn3"));
        }
    }

    @Override
    public void registerVanillaCategoryExtensions(IVanillaCategoryExtensionRegistration registration) {
        registration.getCraftingCategory().addExtension(ComponentTransferringRecipe.class, new ComponentTransferringShapelessExtension());
    }
}