package io.github.mortuusars.horseman.integration.jei.subtypes;

import mezz.jei.api.ingredients.subtypes.ISubtypeInterpreter;
import mezz.jei.api.ingredients.subtypes.UidContext;
import net.minecraft.class_1799;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class InstrumentSubtypeInterpreter implements ISubtypeInterpreter<class_1799> {
	public static final InstrumentSubtypeInterpreter INSTANCE = new InstrumentSubtypeInterpreter();

	private InstrumentSubtypeInterpreter() { }

	@Override
	public @Nullable Object getSubtypeData(class_1799 ingredient, UidContext context) {
		if (context == UidContext.Recipe) return null; // Show all in recipe lookup
		return ingredient.method_57824(class_9334.field_49612);
	}

	@Override
	public @NotNull String getLegacyStringSubtypeInfo(class_1799 itemStack, UidContext context) {
		return "";
	}
}
