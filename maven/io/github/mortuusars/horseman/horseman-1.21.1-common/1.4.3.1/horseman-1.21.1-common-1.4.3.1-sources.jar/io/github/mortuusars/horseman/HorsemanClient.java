package io.github.mortuusars.horseman;

import net.minecraft.class_2960;
import net.minecraft.class_5272;

public class HorsemanClient {
    public static void init() {
        class_5272.method_27879(Horseman.Items.COPPER_HORN.get(), class_2960.method_60656("tooting"),
                (stack, level, entity, seed) -> entity != null && entity.method_6115() && entity.method_6030() == stack ? 1.0F : 0.0F);
    }
}
