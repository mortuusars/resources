package io.github.mortuusars.horseman.integration.jei.recipe;

import io.github.mortuusars.horseman.world.item.crafting.recipe.ComponentTransferringRecipe;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.ingredient.ICraftingGridHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.category.extensions.vanilla.crafting.ICraftingCategoryExtension;
import net.minecraft.class_1799;
import net.minecraft.class_8786;
import java.util.List;
import java.util.stream.Collectors;

public class ComponentTransferringShapelessExtension implements ICraftingCategoryExtension<ComponentTransferringRecipe> {
    @Override
    public void setRecipe(class_8786<ComponentTransferringRecipe> recipeHolder, IRecipeLayoutBuilder builder,
                          ICraftingGridHelper craftingGridHelper, IFocusGroup focuses) {
        ComponentTransferringRecipe recipe = recipeHolder.comp_1933();

        List<List<class_1799>> inputs = recipe.method_8117().stream()
                .map(ingredient -> List.of(ingredient.method_8105()))
                .collect(Collectors.toList());

        inputs.addFirst(List.of(recipe.getSourceIngredient().method_8105()));

        class_1799 resultItem = recipe.getResult();

        int width = getWidth(recipeHolder);
        int height = getHeight(recipeHolder);
        craftingGridHelper.createAndSetInputs(builder, inputs, width, height);
        craftingGridHelper.createAndSetOutputs(builder, List.of(resultItem));
    }
}