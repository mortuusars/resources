package io.github.mortuusars.horseman.mixin.fix_moved_wrongly;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1496;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(class_3244.class)
public abstract class ServerGamePacketListenerImplMixin {
    @Shadow public class_3222 player;

    @ModifyConstant(method = "handleMoveVehicle", constant = @Constant(doubleValue = 0.0625))
    private double onHandleMoveVehicle(double value) {
        if (player.method_5668() instanceof class_1496 && Config.Common.FIX_HORSE_MOVED_WRONGLY.get())
            return 0.36;
        return value;
    }
}
