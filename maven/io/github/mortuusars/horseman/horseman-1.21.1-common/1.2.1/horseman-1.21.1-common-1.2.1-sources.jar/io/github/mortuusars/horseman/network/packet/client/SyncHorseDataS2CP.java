package io.github.mortuusars.horseman.network.packet.client;

import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.network.handler.ClientPacketsHandler;
import io.github.mortuusars.horseman.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record SyncHorseDataS2CP(int entityId, class_1799 leadStack, boolean isHitched) implements Packet {
    public static final class_2960 ID = Horseman.resource("sync_horse_data");
    public static final class_9154<SyncHorseDataS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, SyncHorseDataS2CP> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48550, SyncHorseDataS2CP::entityId,
            class_1799.field_49268, SyncHorseDataS2CP::leadStack,
            class_9135.field_48547, SyncHorseDataS2CP::isHitched,
            SyncHorseDataS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        ClientPacketsHandler.syncHorseData(this);
        return true;
    }
}
