package io.github.mortuusars.horseman.mixin;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1496;
import net.minecraft.class_310;
import net.minecraft.class_4592;
import net.minecraft.class_549;
import net.minecraft.class_5498;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_549.class, priority = 950)
public abstract class HorseModelMixin extends class_4592<class_1496> {
    @Shadow @Final protected class_630 headParts;

    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/animal/horse/AbstractHorse;FFFFF)V", at = @At("RETURN"))
    private void onSetupAnim(class_1496 entity, float limbSwing, float limbSwingAmount,
                             float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci) {
        if (class_310.method_1551().field_1690.method_31044() == class_5498.field_26664
                && class_310.method_1551().field_1724 != null && entity.method_5626(class_310.method_1551().field_1724)) {
            int headXRotOffset = Config.Client.HORSE_HEAD_PITCH_OFFSET.get();
            if (headXRotOffset > 0) {
                this.headParts.field_3654 = Math.min(this.headParts.field_3654 + (headXRotOffset / 100f), 1.5f);
            }

            int headYOffset = Config.Client.HORSE_HEAD_Y_OFFSET.get();
            if (headYOffset > 0) {
                this.headParts.field_3656 += headYOffset;
            }
        }
    }
}
