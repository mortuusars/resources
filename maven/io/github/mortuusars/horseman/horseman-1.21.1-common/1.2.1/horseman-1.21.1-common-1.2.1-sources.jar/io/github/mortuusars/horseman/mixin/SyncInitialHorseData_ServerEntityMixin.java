package io.github.mortuusars.horseman.mixin;

import io.github.mortuusars.horseman.world.HitchableHorse;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_3231;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3231.class)
public class SyncInitialHorseData_ServerEntityMixin {
    @Shadow @Final private class_1297 entity;

    @Inject(method = "addPairing", at = @At("RETURN"))
    private void onSendPairingData(class_3222 player, CallbackInfo ci) {
        if (this.entity instanceof HitchableHorse horse && HitchableHorse.isEnabled() && HitchableHorse.isHitchable(horse)) {
            HitchableHorse.syncHorseDataToClient(horse, player);
        }
    }
}
