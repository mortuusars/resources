package io.github.mortuusars.horseman.world.menu;

import net.minecraft.class_1263;
import net.minecraft.class_1735;

public class LeadSlot extends class_1735 {
    public LeadSlot(class_1263 container, int slot, int x, int y) {
        super(container, slot, x, y);
    }

    @Override
    public int method_7675() {
        return 1;
    }
}
