package io.github.mortuusars.horseman;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_241;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3446;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;


public class Horseman {
    public static final String ID = "horseman";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static void init() {
        Blocks.init();
        BlockEntityTypes.init();
        EntityTypes.init();
        Items.init();
        MenuTypes.init();
        RecipeSerializers.init();
        SoundEvents.init();
        ArgumentTypes.init();
    }

    public static boolean shouldHorseStepDown(class_1496 horse) {
        class_1937 level = horse.method_37908();
        class_2338 pos = horse.method_24515();
        return !horse.method_24828()
                && !horse.method_6763()
                && horse.field_6017 > 0f
                && horse.field_6017 < 0.2f
                && !level.method_8320(pos.method_10074()).method_26220(level, pos.method_10074()).method_1110()
                || (Config.Common.HORSE_FAST_STEP_DOWN_TWO_BLOCKS.get()
                && !level.method_8320(pos.method_10087(2)).method_26220(level, pos.method_10087(2)).method_1110());
    }

    /**
     * Creates resource location in the mod namespace with the given path.
     */
    public static class_2960 resource(String path) {
        return class_2960.method_60655(ID, path);
    }

    public static class_241 handleRiddenRotation(class_1496 horse, class_1309 rider) {
        if (!Config.Common.HORSE_FREE_CAMERA.get() || !(rider instanceof class_1657 player) || player.field_6212 != 0 || player.field_6250 != 0) {
            return null;
        }

        float threshold = Config.Common.HORSE_FREE_CAMERA_ANGLE_THRESHOLD.get().floatValue();

        float rotationDifference = (player.method_36454() - horse.method_36454() + 540) % 360 - 180;

        if (Math.abs(rotationDifference) > threshold) {
            // Rotate the horse towards the player
            return new class_241(player.method_36455() * 0.5f, player.method_36454() - Math.signum(rotationDifference) * threshold);
        }
        else {
            return new class_241(player.method_36455() * 0.5f, horse.method_36454());
        }
    }

    public static class Blocks {
        static void init() {
        }
    }

    public static class BlockEntityTypes {
        static void init() {
        }
    }

    public static class Items {
        static void init() {
        }
    }

    public static class EntityTypes {
        static void init() {
        }
    }

    public static class MenuTypes {
        static void init() {
        }
    }

    public static class RecipeSerializers {
        static void init() {
        }
    }

    public static class SoundEvents {
        private static Supplier<class_3414> register(String category, String key) {
            Preconditions.checkState(category != null && !category.isEmpty(), "'category' should not be empty.");
            Preconditions.checkState(key != null && !key.isEmpty(), "'key' should not be empty.");
            String path = category + "." + key;
            return Register.soundEvent(path, () -> class_3414.method_47908(Horseman.resource(path)));
        }

        static void init() {
        }
    }

    public static class Stats {
        private static final Map<class_2960, class_3446> STATS = new HashMap<>();

        private static class_2960 register(class_2960 location, class_3446 formatter) {
            STATS.put(location, formatter);
            return location;
        }

        public static void register() {
            STATS.forEach((location, formatter) -> {
                class_2378.method_10230(class_7923.field_41183, location, location);
                net.minecraft.class_3468.field_15419.method_14955(location, formatter);
            });
        }
    }

    public static class Advancements {
        public static void register() {
        }
    }

    public static class Tags {
        public static class Items {
        }

        public static class Blocks {
        }

        public static class EntityTypes {
            public static final class_6862<class_1299<?>> CANNOT_BE_HITCHED = class_6862.method_40092(class_7924.field_41266, resource("cannot_be_hitched"));
        }
    }

    public static class ArgumentTypes {
        public static void init() {
        }
    }
}
