package io.github.mortuusars.horseman.mixin;

import io.github.mortuusars.horseman.world.HitchableHorse;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1804;
import net.minecraft.class_1820;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
public abstract class MobMixin extends class_1309 {
    protected MobMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

//    @ModifyVariable(method = "dropLeash", at = @At("HEAD"), ordinal = 1, argsOnly = true)
//    private boolean shouldDropLeash(boolean dropItem) {
//        return dropItem && this instanceof HitchableHorse horse ? !HitchableHorse.isHitched(horse) : dropItem;
//    }
//
//    @Inject(method = "dropLeash", at = @At(value = "RETURN"))
//    private void onDropLeash(boolean broadcastPacket, boolean dropItem, CallbackInfo ci) {
//        if (this instanceof HitchableHorse horse) {
//            HitchableHorse.setHitched(horse, false);
//            if (!horse.horseman$asHorse().level().isClientSide()) {
//                HitchableHorse.syncHorseDataToTrackingClients(horse);
//            }
//        }
//    }

    @Inject(method = "checkAndHandleImportantInteractions", at = @At(value = "HEAD"), cancellable = true)
    private void onCheckAndHandleImportantInteractions(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        if (!(this instanceof HitchableHorse horse)
                || !horse.horseman$asHorse().method_6727()
                || horse.horseman$asHorse().method_6109()
                || !HitchableHorse.isEnabled()) {
            return;
        }

        class_1799 itemInHand = player.method_5998(hand);

        if (itemInHand.method_7909() instanceof class_1820 && !player.method_21823() && HitchableHorse.hasLead(horse)) {
            if (HitchableHorse.isHitched(horse)) {
                horse.horseman$asHorse().method_5932(true, false);
            }
            if (!method_37908().field_9236) {
                class_1799 leadStack = HitchableHorse.getLead(horse);
                method_5775(leadStack);
            }
            method_37908().method_43129(player, player, class_3417.field_14975, class_3419.field_15248, 0.8f, 1f);
            HitchableHorse.setLead(horse, class_1799.field_8037);
            if (!method_37908().field_9236) {
                HitchableHorse.syncHorseDataToTrackingClients(horse);
            }
            cir.setReturnValue(class_1269.method_29236(method_37908().field_9236));
            return;
        }

        if (itemInHand.method_7909() instanceof class_1804 && player.method_21823()
                && HitchableHorse.isHitchable(horse) && !HitchableHorse.hasLead(horse)) {
            class_1799 leadStack = itemInHand.method_7971(1);
            HitchableHorse.setLead(horse, leadStack);
            player.method_6104(hand);
            cir.setReturnValue(class_1269.method_29236(method_37908().field_9236));
            method_37908().method_43129(player, player, class_3417.field_15062, class_3419.field_15248, 0.8f, 1f);
            return;
        }
    }
}
