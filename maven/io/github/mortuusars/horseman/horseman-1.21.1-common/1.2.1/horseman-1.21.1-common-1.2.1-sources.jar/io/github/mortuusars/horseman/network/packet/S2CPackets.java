package io.github.mortuusars.horseman.network.packet;

import io.github.mortuusars.horseman.network.packet.client.SyncHorseDataS2CP;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class S2CPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
                new class_8710.class_9155<>(SyncHorseDataS2CP.TYPE, SyncHorseDataS2CP.STREAM_CODEC)
        );
    }
}
