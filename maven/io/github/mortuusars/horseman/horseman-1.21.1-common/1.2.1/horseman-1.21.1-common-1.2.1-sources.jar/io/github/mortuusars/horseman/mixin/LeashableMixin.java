package io.github.mortuusars.horseman.mixin;

import io.github.mortuusars.horseman.world.HitchableHorse;
import net.minecraft.class_1297;
import net.minecraft.class_1802;
import net.minecraft.class_2740;
import net.minecraft.class_3218;
import net.minecraft.class_9817;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(class_9817.class)
public interface LeashableMixin {
    /**
     * I haven't found a better way than overwriting whole method.
     * @author Horseman - mortuusars
     * @reason Prevent Lead dropping when horse is hitched.
     */
    @Overwrite
    private static <E extends class_1297 & class_9817> void dropLeash(E entity, boolean broadcastPacket, boolean dropItem) {
        @Nullable HitchableHorse horse = entity instanceof HitchableHorse ? ((HitchableHorse) entity) : null;
        boolean isHitched = horse != null && HitchableHorse.isHitched(horse);

        if (isHitched) {
            dropItem = false;
        }

        class_9817.class_9818 leashData = entity.method_60955();
        if (leashData != null && leashData.field_52217 != null) {
            entity.method_60960(null);

            if (horse != null) {
                HitchableHorse.setHitched(horse, false);
                if (!entity.method_37908().field_9236) {
                    HitchableHorse.syncHorseDataToTrackingClients(horse);
                }
            }

            if (!entity.method_37908().field_9236 && dropItem) {
                entity.method_5706(class_1802.field_8719);
            }

            if (broadcastPacket && entity.method_37908() instanceof class_3218 serverLevel) {
                serverLevel.method_14178().method_18754(entity, new class_2740(entity, null));
            }
        }
    }
}
