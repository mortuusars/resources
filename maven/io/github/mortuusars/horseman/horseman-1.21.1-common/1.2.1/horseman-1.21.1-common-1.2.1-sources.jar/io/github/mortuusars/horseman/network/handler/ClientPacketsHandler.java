package io.github.mortuusars.horseman.network.handler;

import io.github.mortuusars.horseman.world.HitchableHorse;
import net.minecraft.class_310;
import io.github.mortuusars.horseman.network.packet.client.SyncHorseDataS2CP;

public class ClientPacketsHandler {
    private static void executeOnMainThread(Runnable runnable) {
        class_310.method_1551().execute(runnable);
    }

    public static void syncHorseData(SyncHorseDataS2CP packet) {
        if (class_310.method_1551().field_1687 == null) return;
        executeOnMainThread(() -> {
            if (class_310.method_1551().field_1687.method_8469(packet.entityId()) instanceof HitchableHorse hitchableHorse) {
                hitchableHorse.horseman$setLead(packet.leadStack());
                hitchableHorse.horseman$setHitched(packet.isHitched());
            }
        });
    }
}
