package io.github.mortuusars.horseman.network.packet;

import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class CommonPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
        );
    }
}
