package io.github.mortuusars.horseman.network;


import com.google.common.base.Preconditions;
import dev.architectury.injectables.annotations.ExpectPlatform;
import io.github.mortuusars.horseman.network.packet.Packet;
import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_3324;

public class Packets {
    @ExpectPlatform
    public static void sendToServer(Packet packet) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToClient(Packet packet, class_3222 player) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToAllClients(Packet packet) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void sendToPlayersTrackingEntity(class_1297 entity, Packet packet) {
        throw new AssertionError();
    }

    public static void sendToClients(Packet packet, class_3324 playerList, @Nullable class_3222 excludedPlayer) {
        for (class_3222 player : playerList.method_14571()) {
            if (player != excludedPlayer)
                sendToClient(packet, player);
        }
    }

    public static void sendToClients(Packet packet, class_3222 origin, Predicate<class_3222> filter) {
        Preconditions.checkState(origin.method_5682() != null, "Server cannot be null");
        for (class_3222 player : origin.method_5682().method_3760().method_14571()) {
            if (filter.test(player))
                sendToClient(packet, player);
        }
    }

    public static void sendToOtherClients(Packet packet, class_3222 excludedPlayer) {
        sendToClients(packet, excludedPlayer, serverPlayer -> !serverPlayer.equals(excludedPlayer));
    }

    public static void sendToOtherClients(Packet packet, class_3222 excludedPlayer, Predicate<class_3222> filter) {
        sendToClients(packet, excludedPlayer, serverPlayer -> !serverPlayer.equals(excludedPlayer) && filter.test(serverPlayer));
    }
}