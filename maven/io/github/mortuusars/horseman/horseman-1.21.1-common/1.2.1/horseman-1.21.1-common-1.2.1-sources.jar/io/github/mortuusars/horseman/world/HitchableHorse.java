package io.github.mortuusars.horseman.world;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.network.Packets;
import io.github.mortuusars.horseman.network.packet.client.SyncHorseDataS2CP;
import net.minecraft.class_1263;
import net.minecraft.class_1496;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3222;

public interface HitchableHorse {
    class_1799 horseman$getLead();
    void horseman$setLead(class_1799 stack);
    boolean horseman$isHitched();
    void horseman$setHitched(boolean hitched);
    class_1263 horseman$getLeadAccess();

    default boolean horseman$hasLead() {
        return !horseman$getLead().method_7960();
    }

    default class_1496 horseman$asHorse() {
        return ((class_1496) this);
    }

    // --

    static boolean isEnabled() {
        return Config.Common.HORSE_HITCH.get();
    }

    static boolean requiresLead() {
        return Config.Common.HORSE_HITCH_REQUIRES_LEAD.get();
    }

    /**
     * Basically every horse that is saddleable supports hitching. In vanilla the only exception is LLama.
     * Technically we can also use horse#isSaddleable here, but that would hard-limit it.
     * Maybe some mod adds non-saddleable horse that would benefit from hitching.
     */
    static boolean isHitchable(HitchableHorse horse) {
        return horse.horseman$asHorse().method_6727()
                && !horse.horseman$asHorse().method_6109()
                && !horse.horseman$asHorse().method_5864().method_20210(Horseman.Tags.EntityTypes.CANNOT_BE_HITCHED);
    }

    // --

    static boolean canHitch(HitchableHorse horse) {
        return isEnabled() && isHitchable(horse) && !horse.horseman$asHorse().method_60953()
                && (!requiresLead() || hasLead(horse));
    }

    static boolean isHitched(HitchableHorse horse) {
        return horse.horseman$isHitched();
    }

    static void setHitched(HitchableHorse horse, boolean hitched) {
        horse.horseman$setHitched(hitched);
    }

    // --

    static class_1799 getLead(HitchableHorse horse) {
        return horse.horseman$getLead();
    }

    static void setLead(HitchableHorse horse, class_1799 leadStack) {
        horse.horseman$setLead(leadStack);
    }

    static boolean hasLead(HitchableHorse horse) {
        return horse.horseman$hasLead();
    }

    // -- Lead in inventory

    static boolean shouldHaveLeadSlot(HitchableHorse horse) {
        return isEnabled() && requiresLead() && Config.Common.HORSE_HITCH_INVENTORY_SLOT.get() && isHitchable(horse);
    }

    static boolean mayPlaceInLeadSlot(HitchableHorse horse, class_1799 stack) {
        return stack.method_31574(class_1802.field_8719);
    }

    static boolean isLeadSlotActive(HitchableHorse horse) {
        return !isHitched(horse);
    }

    // --

    static void syncHorseDataToClient(HitchableHorse horse, class_3222 player) {
        Packets.sendToClient(new SyncHorseDataS2CP(horse.horseman$asHorse().method_5628(), getLead(horse), isHitched(horse)), player);
    }

    static void syncHorseDataToTrackingClients(HitchableHorse horse) {
        Packets.sendToPlayersTrackingEntity(horse.horseman$asHorse(), new SyncHorseDataS2CP(
                horse.horseman$asHorse().method_5628(), getLead(horse), isHitched(horse)));
    }
}
