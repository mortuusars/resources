package io.github.mortuusars.horseman.mixin.switch_inventory;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.client.SwitchInventory;
import net.minecraft.class_1109;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1661;
import net.minecraft.class_1723;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_344;
import net.minecraft.class_437;
import net.minecraft.class_485;
import net.minecraft.class_490;
import net.minecraft.class_7919;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_490.class)
public abstract class InventoryScreenMixin extends class_485<class_1723> {
    @Unique
    private @Nullable class_344 horseman$playerInventorySwitchButton;

    public InventoryScreenMixin(class_1723 menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
    }

    @Inject(method = "init", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        if (!SwitchInventory.isEnabled()
              || class_310.method_1551().field_1761 == null
              || !class_310.method_1551().field_1761.method_2895()) {
            return;
        }

        if ((class_437) this instanceof class_490 inventoryScreen) {
            horseman$playerInventorySwitchButton = new class_344(
                  field_2776 + Config.Client.INVENTORY_SWITCH_PLAYER_BUTTON_X.get(),
                  field_2800 + Config.Client.INVENTORY_SWITCH_PLAYER_BUTTON_Y.get(),
                  14,
                  15,
                  SwitchInventory.SWITCH_BUTTON_RIGHT_SPRITES,
                  b -> SwitchInventory.switchToMount(inventoryScreen));

            class_2561 vehicleName = class_310.method_1551().field_1724 != null
                  && class_310.method_1551().field_1724.method_5854() instanceof class_1297 entity
                  ? entity.method_5477()
                  : class_2561.method_43471("gui.horseman.switch_inventory.button.to_mount.tooltip.mount");

            horseman$playerInventorySwitchButton.method_47400(class_7919.method_47407(class_2561.method_43469("gui.horseman.switch_inventory.button.to_mount.tooltip",
                  vehicleName,
                  class_2561.method_43470(class_310.method_1551().field_1690.field_1822.method_16007().getString())
                        .method_27692(class_124.field_1080)
            )));

            method_37063(horseman$playerInventorySwitchButton);
        }
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (horseman$playerInventorySwitchButton != null) {
            // Update button pos to adjust to recipe book ui opening/closing
            horseman$playerInventorySwitchButton.method_46421(field_2776 + Config.Client.INVENTORY_SWITCH_PLAYER_BUTTON_X.get());
        }
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void onKeyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        if (!SwitchInventory.isEnabled()
              || class_310.method_1551().field_1761 == null
              || !class_310.method_1551().field_1761.method_2895()) {
            return;
        }

        class_310 minecraft = class_310.method_1551();

        //noinspection ConstantValue
        if (((class_437)this instanceof class_490)
              && minecraft.field_1690.field_1822.method_1417(keyCode, scanCode)
              && class_437.method_25441()) {
            SwitchInventory.switchToMount(this);
            minecraft.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1));
            cir.setReturnValue(true);
        }
    }
}