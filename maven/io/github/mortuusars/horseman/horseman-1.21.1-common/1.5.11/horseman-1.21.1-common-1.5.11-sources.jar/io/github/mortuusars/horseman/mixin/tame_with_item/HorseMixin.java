package io.github.mortuusars.horseman.mixin.tame_with_item;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1496;
import net.minecraft.class_1498;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1498.class)
public class HorseMixin extends class_1496 {
    protected HorseMixin(class_1299<? extends class_1496> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "mobInteract", at = @At("HEAD"), cancellable = true)
    private void onMobInteract(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        if (!Config.Server.HORSE_ALLOW_TAMING_WITH_ITEM_IN_HAND.get()) return;
        if (player.method_21823() || method_5782() || method_6109() || method_6727() || method_6481(player.method_5998(hand))) return;
        if (!player.method_5998(hand).method_7960()) {
            method_6726(player);
            cir.setReturnValue(class_1269.field_5812);
        }
    }
}
