package io.github.mortuusars.horseman;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1799;

public class PlatformHelper {
    @ExpectPlatform
    public static boolean canShear(class_1799 stack) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isModLoaded(String modId) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isModLoading(String modId) {
        throw new AssertionError();
    }
}
