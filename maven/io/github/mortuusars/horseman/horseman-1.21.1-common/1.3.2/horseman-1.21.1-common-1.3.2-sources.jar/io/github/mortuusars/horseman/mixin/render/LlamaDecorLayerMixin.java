package io.github.mortuusars.horseman.mixin.render;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalFloatRef;
import io.github.mortuusars.horseman.client.HorseRenderUtils;
import net.minecraft.class_1501;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5253;
import net.minecraft.class_578;
import net.minecraft.class_988;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_988.class, priority = 950)
public abstract class LlamaDecorLayerMixin {
    @Shadow @Final private class_578<class_1501> model;

    @WrapOperation(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/animal/horse/Llama;FFFFFF)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/RenderType;entityCutoutNoCull(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/renderer/RenderType;"))
    class_1921 makeRenderLayerTranslucent(class_2960 location, Operation<class_1921> original, @Local(argsOnly = true) class_1501 llama, @Share("alpha") LocalFloatRef alpha) {
        float a = HorseRenderUtils.getAlpha(llama);
        alpha.set(a);
        if (a >= 1.0) return original.call(location);
        return class_1921.method_23689(location);
    }

    @Inject(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/animal/horse/Llama;FFFFFF)V",
    at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/LlamaModel;renderToBuffer(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;II)V"),
            cancellable = true)
    private void onRender(class_4587 poseStack, class_4597 buffer, int packedLight, class_1501 livingEntity,
                          float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks,
                          float netHeadYaw, float headPitch, CallbackInfo ci, @Local class_4588 vertexConsumer, @Share("alpha") LocalFloatRef alpha) {
        int a = class_3532.method_15340((int)(255 * (alpha.get() / 255f)), 0, 255);
        model.method_2828(poseStack, vertexConsumer, packedLight, class_4608.field_21444, class_5253.class_5254.method_58144(a, 0xFFFFFF));
        ci.cancel();
    }
}