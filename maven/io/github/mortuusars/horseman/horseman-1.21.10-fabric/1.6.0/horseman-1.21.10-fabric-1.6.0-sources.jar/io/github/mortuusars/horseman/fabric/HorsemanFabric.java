package io.github.mortuusars.horseman.fabric;

import fuzs.forgeconfigapiport.fabric.api.v5.ConfigRegistry;
import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.HorsemanServer;
import io.github.mortuusars.horseman.network.fabric.FabricC2SPackets;
import io.github.mortuusars.horseman.network.fabric.FabricS2CPackets;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1496;
import net.minecraft.class_3218;
import net.minecraft.class_7706;
import net.minecraft.server.MinecraftServer;
import net.neoforged.fml.config.ModConfig;
import org.jetbrains.annotations.Nullable;

public class HorsemanFabric implements ModInitializer {
    // Server field to access when no other objects are available to get it from.
    public static @Nullable MinecraftServer server = null;

    @Override
    public void onInitialize() {
        Horseman.init();

        ConfigRegistry.INSTANCE.register(Horseman.ID, ModConfig.Type.SERVER, Config.Server.SPEC);
        ConfigRegistry.INSTANCE.register(Horseman.ID, ModConfig.Type.COMMON, Config.Common.SPEC);
        ConfigRegistry.INSTANCE.register(Horseman.ID, ModConfig.Type.CLIENT, Config.Client.SPEC);

        Horseman.Stats.register();

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(content -> {
            content.method_45421(Horseman.Items.COPPER_HORN.get());
        });

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            HorsemanServer.serverStarted(server);
            HorsemanFabric.server = server;
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            HorsemanServer.serverStopped(server);
            HorsemanFabric.server = null;
        });

        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            try {
                if (entity instanceof class_1496 horse && world instanceof class_3218 level) {
                    if (HorsemanServer.getSummoning().onHorseLoaded(level, horse)) {
                        horse.method_31472();
                    }
                }
            } catch (Exception e) {
                Horseman.LOGGER.warn("Failed to handle Horseman's entityLoad event. {}.", e.getMessage());
            }
        });

        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
            try {
                if (entity instanceof class_1496 horse && world instanceof class_3218 level) {
                    HorsemanServer.getSummoning().onHorseUnloaded(level, horse);
                }
            } catch (Exception e) {
                Horseman.LOGGER.warn("Failed to handle Horseman's entityUnload event. {}.", e.getMessage());
            }
        });

        FabricC2SPackets.register();
        FabricS2CPackets.register();
    }
}
