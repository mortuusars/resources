package io.github.mortuusars.horseman.fabric;

import com.mojang.brigadier.arguments.ArgumentType;
import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.Register;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.command.v2.ArgumentTypeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1703;
import net.minecraft.class_179;
import net.minecraft.class_1792;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_2248;
import net.minecraft.class_2314;
import net.minecraft.class_2378;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3414;
import net.minecraft.class_3917;
import net.minecraft.class_3956;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9331;
import net.minecraft.class_9331.class_9332;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class RegisterImpl {
    public static <T extends class_2248> Supplier<T> block(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41175, Horseman.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_2591<E>, E extends class_2586> Supplier<T> blockEntityType(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41181, Horseman.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_2586> class_2591<T> newBlockEntityType(Register.BlockEntitySupplier<T> blockEntitySupplier, class_2248... validBlocks) {
        return FabricBlockEntityTypeBuilder.create(blockEntitySupplier::create, validBlocks).build();
    }

    public static <T extends class_1792> Supplier<T> item(String id, Function<class_1792.class_1793, T> func, class_1792.class_1793 properties) {
        class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, Horseman.resource(id));
        T item = func.apply(properties.method_63686(itemKey));
        T registeredItem = class_2378.method_39197(class_7923.field_41178, itemKey, item);
        return () -> registeredItem;
    }

    public static <T extends class_1297> Supplier<class_1299<T>> entityType(String id, class_1299.class_4049<T> factory,
                                                                        class_1311 category, float width, float height,
                                                                        int clientTrackingRange, boolean velocityUpdates, int updateInterval) {
        class_1299<T> type = class_2378.method_10230(class_7923.field_41177, Horseman.resource(id),
                class_1299.class_1300.method_5903(factory, category)
                        .method_17687(width, height)
                        .method_27299(clientTrackingRange)
                        .alwaysUpdateVelocity(velocityUpdates)
                        .method_27300(updateInterval)
                        .method_5905(class_5321.method_29179(class_7924.field_41266, Horseman.resource(id))));
        return () -> type;
    }

    public static <T extends class_1297> Supplier<class_1299<T>> entityType(String id, class_1299.class_4049<T> factory, class_1311 category, boolean receiveVelocityUpdates, Consumer<class_1299.class_1300<T>> typeBuilder) {
        class_1299.class_1300<T> builder = class_1299.class_1300.method_5903(factory, category);
        typeBuilder.accept(builder);
        builder.alwaysUpdateVelocity(receiveVelocityUpdates);
        class_1299<T> type = class_2378.method_10230(class_7923.field_41177, Horseman.resource(id), builder.method_5905(class_5321.method_29179(class_7924.field_41266, Horseman.resource(id))));
        return () -> type;
    }

    public static <T extends class_3414> Supplier<T> soundEvent(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41172, Horseman.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_3917<E>, E extends class_1703> Supplier<class_3917<E>> menuType(String id, Register.MenuTypeSupplier<E> supplier) {
        ExtendedScreenHandlerType<E, byte[]> type = new ExtendedScreenHandlerType<>((syncId, inventory, data) -> {
            class_9129 buffer = new class_9129(Unpooled.wrappedBuffer(data), inventory.field_7546.method_56673());
            E menu = supplier.create(syncId, inventory, buffer);
            buffer.release();
            return menu;
        }, class_9135.field_48987.method_56439(Function.identity()));

        class_2378.method_10230(class_7923.field_41187, Horseman.resource(id), type);

        return () -> {
            return type;
        };
    }

    public static Supplier<class_3956<?>> recipeType(String id, Supplier<class_3956<?>> supplier) {
        class_3956<?> obj = class_2378.method_10230(class_7923.field_41188, Horseman.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_1852> Supplier<class_1865<T>> recipeSerializer(String name, Supplier<class_1865<T>> supplier) {
        class_1865<T> obj = class_2378.method_10230(class_7923.field_41189, Horseman.resource(name), supplier.get());
        return () -> obj;
    }

    public static <T extends class_179<?>> Supplier<T> criterionTrigger(String name, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_47496, Horseman.resource(name), supplier.get());
        return () -> obj;
    }

    public static <A extends ArgumentType<?>, T extends class_2314.class_7217<A>, I extends class_2314<A, T>>
    Supplier<class_2314<A, T>> commandArgumentType(String id, Class<A> infoClass, I argumentTypeInfo) {
        ArgumentTypeRegistry.registerArgumentType(Horseman.resource(id), infoClass, argumentTypeInfo);
        return () -> argumentTypeInfo;
    }

    public static <T extends class_3037> Supplier<class_3031<?>> worldGenFeature(String name, Supplier<class_3031<T>> featureSupplier) {
        class_3031<T> feature = class_2378.method_10226(class_7923.field_41144, name, featureSupplier.get());
        return () -> feature;
    }

    public static <T> class_9331<T> dataComponentType(String name, Consumer<class_9331.class_9332<T>> builderConsumer) {
        var builder = class_9331.<T>method_57873();
        builderConsumer.accept(builder);
        var componentType = builder.method_57880();
        return class_2378.method_10230(class_7923.field_49658, Horseman.resource(name), componentType);
    }

    public static <T extends class_2396<? extends class_2394>> Supplier<T> particleType(String name, Supplier<T> supplier) {
        T particleType = class_2378.method_10226(class_7923.field_41180, name, supplier.get());
        return () -> particleType;
    }
}
