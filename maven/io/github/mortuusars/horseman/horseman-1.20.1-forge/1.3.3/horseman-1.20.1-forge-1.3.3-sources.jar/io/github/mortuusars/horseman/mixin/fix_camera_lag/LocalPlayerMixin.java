package io.github.mortuusars.horseman.mixin.fix_camera_lag;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.mojang.authlib.GameProfile;
import io.github.mortuusars.horseman.Config;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin extends Player {
    public LocalPlayerMixin(Level level, BlockPos pos, float yRot, GameProfile gameProfile) {
        super(level, pos, yRot, gameProfile);
    }

    @ModifyReturnValue(method = "getViewYRot", at = @At("RETURN"))
    private float onGetViewYRot(float original) {
        return m_20159_() && Config.Client.FIX_MOUNTED_CAMERA_LAG.get() ? m_146908_() : original;
    }
}
