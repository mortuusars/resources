package io.github.mortuusars.horseman.mixin;

import io.github.mortuusars.horseman.Config;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.AgeableListModel;
import net.minecraft.client.model.HorseModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = HorseModel.class, priority = 950)
public abstract class HorseModelMixin extends AgeableListModel<AbstractHorse> {
    @Shadow @Final protected ModelPart headParts;

    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/animal/horse/AbstractHorse;FFFFF)V", at = @At("RETURN"))
    private void onSetupAnim(AbstractHorse entity, float limbSwing, float limbSwingAmount,
                             float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci) {
        if (Minecraft.m_91087_().f_91066_.m_92176_() == CameraType.FIRST_PERSON
                && Minecraft.m_91087_().f_91074_ != null && entity.m_20363_(Minecraft.m_91087_().f_91074_)) {
            int headXRotOffset = Config.Client.HORSE_HEAD_PITCH_OFFSET.get();
            if (headXRotOffset > 0) {
                this.headParts.f_104203_ = Math.min(this.headParts.f_104203_ + (headXRotOffset / 100f), 1.5f);
            }

            int headYOffset = Config.Client.HORSE_HEAD_Y_OFFSET.get();
            if (headYOffset > 0) {
                this.headParts.f_104201_ += headYOffset;
            }
        }
    }
}
