package io.github.mortuusars.horseman.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.PlatformHelper;
import io.github.mortuusars.horseman.data.HitchableHorse;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.horse.AbstractChestedHorse;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractChestedHorse.class)
public abstract class AbstractChestedHorseMixin extends AbstractHorse implements HitchableHorse {
    @Shadow public abstract boolean hasChest();

    @Shadow public abstract int getInventoryColumns();

    @Shadow public abstract void setChest(boolean chested);

    protected AbstractChestedHorseMixin(EntityType<? extends AbstractHorse> entityType, Level level) {
        super(entityType, level);
    }

    /**
     * +1 for Lead slot.
     * {@link AbstractHorseMixin} also has this change, so we should only add +1 if it's not calling the super method.
     */
    @ModifyReturnValue(method = "getInventorySize", at = @At("RETURN"))
    private int onGetInventorySize(int original) {
        return HitchableHorse.shouldHaveLeadSlot(this) && hasChest() ? original + 1 : original;
    }

    @Inject(method = "mobInteract", at = @At("HEAD"), cancellable = true)
    private void onMobInteract(Player player, InteractionHand hand, CallbackInfoReturnable<InteractionResult> cir) {
        if (!Config.Common.HORSE_SHEARS_REMOVE_CHEST.get() || m_20160_() || m_6162_()
                || !m_30614_() || !hasChest() || player.m_36341_()) {
            return;
        }

        ItemStack itemInHand = player.m_21120_(hand);
        if (PlatformHelper.canShear(itemInHand)) {
            if (m_9236_().f_46443_) {
                cir.setReturnValue(InteractionResult.SUCCESS);
                return;
            }

            int chestInventorySize = 3 * getInventoryColumns();
            SimpleContainer dropContainer = new SimpleContainer(chestInventorySize);

            for (int i = 0; i < dropContainer.m_6643_(); i++) {
                ItemStack stack = f_30520_.m_8020_(2 + i);
                dropContainer.m_6836_(i, stack);
            }

            Containers.m_18998_(m_9236_(), this, dropContainer);
            Containers.m_18992_(m_9236_(), this.m_20185_(), this.m_20186_(), this.m_20189_(), new ItemStack(Items.f_42009_));

            // Move lead to a correct slot (always last). Same as in AbstractHorseMixin#createInventory but in reverse.
            if (HitchableHorse.shouldHaveLeadSlot(this)) {
                int leadSlot = HitchableHorse.getLeadSlotIndex(this);
                ItemStack leadStack = f_30520_.m_8020_(leadSlot);
                if (!leadStack.m_41619_()) {
                    f_30520_.m_6836_(2, leadStack);
                    f_30520_.m_6836_(leadSlot, ItemStack.f_41583_);
                }
            }

            m_5496_(SoundEvents.f_12344_, 1.0f, (this.f_19796_.m_188501_() - this.f_19796_.m_188501_()) * 0.2f + 1.0f);
            setChest(false);
            m_30625_();

            cir.setReturnValue(InteractionResult.SUCCESS);
        }
    }
}
