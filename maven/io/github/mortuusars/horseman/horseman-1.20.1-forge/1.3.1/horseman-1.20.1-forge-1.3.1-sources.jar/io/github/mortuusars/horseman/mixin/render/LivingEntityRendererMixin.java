package io.github.mortuusars.horseman.mixin.render;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import io.github.mortuusars.horseman.client.HorseRenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.item.DyeColor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = LivingEntityRenderer.class, priority = 950)
public abstract class LivingEntityRendererMixin<T extends LivingEntity, M extends EntityModel<T>> extends EntityRenderer<T> {
    protected LivingEntityRendererMixin(EntityRendererProvider.Context context) {
        super(context);
    }

    @Redirect(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/EntityModel;renderToBuffer(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;IIFFFF)V"))
    private void onRender(EntityModel<?> instance, PoseStack poseStack, VertexConsumer vertexConsumer,
                          int packedLight, int packedOverlay, float r, float g, float b, float a,
                          @Local(argsOnly = true) T entity) {
        if (entity instanceof AbstractHorse) {
            if (HorseRenderUtils.isJeb(entity)) {
                int index = entity.f_19797_ / 25 + entity.m_19879_();
                int dyesCount = DyeColor.values().length;
                int currentIndex = index % dyesCount;
                int nextIndex = (index + 1) % dyesCount;
                float transition = ((float) (entity.f_19797_ % 25) + Minecraft.m_91087_().m_91297_()) / 25.0F;
                float[] currentColors = Sheep.m_29829_(DyeColor.m_41053_(currentIndex));
                float[] nextColors = Sheep.m_29829_(DyeColor.m_41053_(nextIndex));

                r = currentColors[0] * (1.0F - transition) + nextColors[0] * transition;
                g = currentColors[1] * (1.0F - transition) + nextColors[1] * transition;
                b = currentColors[2] * (1.0F - transition) + nextColors[2] * transition;

                // increase brightness because the horse texture is a bit dark
                r = Mth.m_14036_(r * 2, 0, 1);
                g = Mth.m_14036_(g * 2, 0, 1);
                b = Mth.m_14036_(b * 2, 0, 1);
            }

            double alphaVal = HorseRenderUtils.getAlpha(entity);
            if (alphaVal != 0.0) {
                a = (float) Mth.m_14008_(a * (alphaVal - 0.1), 0.0, 1.0);
            }
        }

        instance.m_7695_(poseStack, vertexConsumer, packedLight, packedOverlay, r, g, b, a);
    }

    @Inject(method = "getRenderType", at = @At("HEAD"), cancellable = true)
    private void getRenderType(T entity, boolean bodyVisible, boolean translucent, boolean glowing,
                               CallbackInfoReturnable<RenderType> cir) {
        if (entity instanceof AbstractHorse && HorseRenderUtils.getAlpha(entity) != 1.0) {
            cir.setReturnValue(RenderType.m_110473_(m_5478_(entity)));
        }
    }
}