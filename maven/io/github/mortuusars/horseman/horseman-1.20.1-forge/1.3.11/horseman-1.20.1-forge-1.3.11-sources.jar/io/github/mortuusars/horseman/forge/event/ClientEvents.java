package io.github.mortuusars.horseman.forge.event;

import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.client.ImprovedMountGui;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.jetbrains.annotations.Nullable;

public class ClientEvents {
    @Mod.EventBusSubscriber(modid = Horseman.ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModBus {
        @SubscribeEvent
        public static void registerGuiOverlays(RegisterGuiOverlaysEvent event) {
            event.registerAbove(VanillaGuiOverlay.EXPERIENCE_BAR.id(), "horseman_xp_bar",
                    (gui, guiGraphics, partialTick, screenWidth, screenHeight) -> {
                        if (!ImprovedMountGui.isEnabled()) return;
                        @Nullable LocalPlayer player = Minecraft.m_91087_().f_91074_;
                        @Nullable MultiPlayerGameMode gameMode = Minecraft.m_91087_().f_91072_;
                        if (player != null && player.m_245714_() != null && gameMode != null && gameMode.m_105288_()) {
                            gui.setupOverlayRenderState(true, false);
                            gui.m_280276_(guiGraphics, screenWidth / 2 - 91);
                        }
                    });

            event.registerAbove(VanillaGuiOverlay.FOOD_LEVEL.id(), "horseman_food_level",
                    (gui, guiGraphics, partialTick, screenWidth, screenHeight) -> {
                        @Nullable MultiPlayerGameMode gameMode = Minecraft.m_91087_().f_91072_;
                        if (!ImprovedMountGui.isEnabled() || gui.getMinecraft().f_91066_.f_92062_
                                || gameMode == null || !gameMode.m_105205_()) return;
                        @Nullable LocalPlayer player = Minecraft.m_91087_().f_91074_;
                        if (player != null && player.m_245714_() != null) {
                            gui.setupOverlayRenderState(true, false);
                            gui.renderFood(screenWidth, screenHeight, guiGraphics);
                        }
                    });
        }
    }

    public static class ForgeBus {

    }
}
