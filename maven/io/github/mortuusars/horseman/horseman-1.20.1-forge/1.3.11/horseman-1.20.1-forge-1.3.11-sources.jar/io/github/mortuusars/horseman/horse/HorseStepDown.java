package io.github.mortuusars.horseman.horse;

import io.github.mortuusars.horseman.Config;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class HorseStepDown {
    public static boolean shouldHorseStepDown(AbstractHorse horse) {
        if (!Config.Common.HORSE_FAST_STEP_DOWN.get()) return false;
        if (!(horse.m_6688_() instanceof Player)) return false;
        if (horse.m_20096_() || horse.m_30616_()) return false;
        return horse.f_19789_ > 0.0 && horse.f_19789_ < 0.2 && canStepDownOnBlock(horse);
    }

    private static boolean canStepDownOnBlock(AbstractHorse horse) {
        Level level = horse.m_9236_();
        BlockPos pos = horse.m_20183_();
        if (!level.m_8055_(pos.m_7495_()).m_60812_(level, pos.m_7495_()).m_83281_()) return true;
        return Config.Common.HORSE_FAST_STEP_DOWN_TWO_BLOCKS.get()
                && !level.m_8055_(pos.m_6625_(2)).m_60812_(level, pos.m_6625_(2)).m_83281_();
    }
}
