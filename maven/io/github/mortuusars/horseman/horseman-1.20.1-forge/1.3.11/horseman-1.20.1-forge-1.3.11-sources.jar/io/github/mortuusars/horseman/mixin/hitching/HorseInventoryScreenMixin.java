package io.github.mortuusars.horseman.mixin.hitching;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.client.LeadOnHorse;
import io.github.mortuusars.horseman.horse.HitchableHorse;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.HorseInventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.HorseInventoryMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HorseInventoryScreen.class)
public abstract class HorseInventoryScreenMixin extends AbstractContainerScreen<HorseInventoryMenu> {
    @Shadow
    @Final
    private AbstractHorse horse;
    @Unique
    private static final ResourceLocation LEAD_SLOT_TEXTURE = Horseman.resource("textures/gui/lead_slot.png");

    public HorseInventoryScreenMixin(HorseInventoryMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Inject(method = "render", at = @At(value = "RETURN"))
    private void onRender(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (!(this.horse instanceof HitchableHorse hitchableHorse)) return;

        if (HitchableHorse.shouldHaveLeadSlot(hitchableHorse)) {
            if (!HitchableHorse.isHitched(hitchableHorse)) return;

            int slotIndex = HitchableHorse.getLeadSlotIndex(hitchableHorse);
            Slot slot = m_6262_().f_38839_.get(slotIndex);
            if (slot.m_7993_().m_150930_(Items.f_42655_)) {
                // Darken the slot
                int leftPos = (this.f_96543_ - this.f_97726_) / 2;
                int topPos = (this.f_96544_ - this.f_97727_) / 2;
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                guiGraphics.m_280398_(LEAD_SLOT_TEXTURE, leftPos + slot.f_40220_ - 1, topPos + slot.f_40221_ - 1, 350, 0, 18, 18, 18, 256, 256);
                RenderSystem.disableBlend();
            }
        } else if (HitchableHorse.requiresLead() && HitchableHorse.hasLead(hitchableHorse)) {
            LeadOnHorse.renderInventory(guiGraphics, mouseX, mouseY, partialTick, f_97735_, f_97736_, this.horse);
        }
    }

    @Inject(method = "renderBg", at = @At(value = "RETURN"))
    private void onRenderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY, CallbackInfo ci) {
        if (!(this.horse instanceof HitchableHorse hitchableHorse)) return;

        if (HitchableHorse.shouldHaveLeadSlot(hitchableHorse)) {
            int leftPos = (this.f_96543_ - this.f_97726_) / 2;
            int topPos = (this.f_96544_ - this.f_97727_) / 2;
            guiGraphics.m_280218_(LEAD_SLOT_TEXTURE, leftPos + 7, topPos + 53, 0, 0, 18, 18);
        }
    }
}
