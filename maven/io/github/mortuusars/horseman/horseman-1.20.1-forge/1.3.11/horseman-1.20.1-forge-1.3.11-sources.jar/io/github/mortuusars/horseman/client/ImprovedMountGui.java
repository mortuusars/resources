package io.github.mortuusars.horseman.client;

import io.github.mortuusars.horseman.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;

public class ImprovedMountGui {
    private static long vehicleInWaterLastTick = -1;

    public static boolean shouldRenderJumpBar() {
        Minecraft mc = Minecraft.m_91087_();
        if (mc.f_91072_ == null || !mc.f_91072_.m_105288_()) return false;
        if (mc.f_91073_ == null || mc.f_91074_ == null || mc.f_91074_.m_245714_() == null) return false;

        if (mc.f_91074_.m_245714_() instanceof LivingEntity entity && entity.m_20069_()) {
            vehicleInWaterLastTick = mc.f_91073_.m_46467_();
        }

        boolean isJumping = mc.f_91066_.f_92089_.m_90857_() || mc.f_91074_.m_108634_() > 0;
        return isJumping && (mc.f_91073_.m_46467_() - vehicleInWaterLastTick >= 10);
    }

    public static boolean isEnabled() {
        return Config.Client.IMPROVED_MOUNT_GUI.get();
    }
}
