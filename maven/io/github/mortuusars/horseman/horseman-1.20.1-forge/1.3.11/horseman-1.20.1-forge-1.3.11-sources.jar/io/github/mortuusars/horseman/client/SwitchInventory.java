package io.github.mortuusars.horseman.client;

import io.github.mortuusars.horseman.Horseman;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

public class SwitchInventory {
    public static final ResourceLocation BUTTON_TEXTURE = Horseman.resource("textures/gui/switch_inventory_button.png");

    public static @Nullable Double mouseX, mouseY;

    public static void switchFromHorse(AbstractContainerScreen<?> screen) {
        if (Minecraft.m_91087_().f_91074_ == null) return;

        double cursorX = Minecraft.m_91087_().f_91067_.m_91589_();
        double cursorY = Minecraft.m_91087_().f_91067_.m_91594_();

        screen.m_7379_();
        Minecraft.m_91087_().m_91152_(new InventoryScreen(Minecraft.m_91087_().f_91074_));

        // Move cursor to previous position, as setScreen resets it to center every time:
        Minecraft.m_91087_().execute(() -> {
            GLFW.glfwSetCursorPos(Minecraft.m_91087_().m_91268_().m_85439_(), cursorX, cursorY);
        });
    }

    public static void switchFromInventory(AbstractContainerScreen<?> screen) {
        if (Minecraft.m_91087_().f_91074_ == null) return;
        // Cannot move cursor like from mount, because screen is opened later due to it being sent from server.
        // So we remember pos here, and set it when screen is initialized.
        mouseX = Minecraft.m_91087_().f_91067_.m_91589_();
        mouseY = Minecraft.m_91087_().f_91067_.m_91594_();

        screen.m_7379_();
        Minecraft.m_91087_().f_91074_.m_108628_();
    }
}
