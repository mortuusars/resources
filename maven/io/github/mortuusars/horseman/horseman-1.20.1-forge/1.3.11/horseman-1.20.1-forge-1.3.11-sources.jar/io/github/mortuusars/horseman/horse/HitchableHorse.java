package io.github.mortuusars.horseman.horse;

import com.google.common.base.Preconditions;
import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.network.Packets;
import io.github.mortuusars.horseman.network.packet.client.SyncHorseDataS2CP;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.animal.horse.AbstractChestedHorse;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

public interface HitchableHorse {
    ItemStack horseman$getLead();
    void horseman$setLead(ItemStack stack);
    boolean horseman$isHitched();
    void horseman$setHitched(boolean hitched);

    default boolean horseman$hasLead() {
        return !horseman$getLead().m_41619_();
    }

    default AbstractHorse horseman$asHorse() {
        return ((AbstractHorse) this);
    }

    // --

    static boolean isEnabled() {
        return Config.Common.HORSE_HITCH.get();
    }

    static boolean requiresLead() {
        return Config.Common.HORSE_HITCH_REQUIRES_LEAD.get();
    }

    /**
     * Basically every horse that is saddleable supports hitching. In vanilla the only exception is LLama.
     * Technically we can also use horse#isSaddleable here, but that would hard-limit it.
     * Maybe some mod adds non-saddleable horse that would benefit from hitching.
     */
    static boolean isHitchable(HitchableHorse horse) {
        return !horse.horseman$asHorse().m_6095_().m_204039_(Horseman.Tags.EntityTypes.CANNOT_BE_HITCHED);
    }

    // --

    static boolean canHitch(HitchableHorse horse) {
        return isEnabled() && isHitchable(horse) && !horse.horseman$asHorse().m_21523_() && (!requiresLead() || hasLead(horse));
    }

    static boolean isHitched(HitchableHorse horse) {
        return horse.horseman$isHitched();
    }

    static void setHitched(HitchableHorse horse, boolean hitched) {
        horse.horseman$setHitched(hitched);
    }

    // --

    static ItemStack getLead(HitchableHorse horse) {
        return horse.horseman$getLead();
    }

    static void setLead(HitchableHorse horse, ItemStack leadStack) {
        horse.horseman$setLead(leadStack);
    }

    static boolean hasLead(HitchableHorse horse) {
        return horse.horseman$hasLead();
    }

    // -- Lead in inventory

    static boolean shouldHaveLeadSlot(HitchableHorse horse) {
        return isEnabled() && requiresLead() && Config.Common.HORSE_HITCH_INVENTORY_SLOT.get() && isHitchable(horse);
    }

    static int getLeadSlotIndex(HitchableHorse horse) {
        Preconditions.checkState(shouldHaveLeadSlot(horse),
                "Tried to get lead slot index when the hitching is disabled or horse cannot be hitched.");

        if (horse instanceof AbstractChestedHorse chestedHorse && chestedHorse.m_30502_()) {
            int columns = ((AbstractChestedHorse) horse).m_7488_();
            return 2 + columns * 3;
        } else {
            return 2;
        }
    }

    static boolean mayPlaceInLeadSlot(HitchableHorse horse, ItemStack stack) {
        return stack.m_150930_(Items.f_42655_);
    }

    static boolean isLeadSlotActive(HitchableHorse horse) {
        return !isHitched(horse);
    }

    // --

    static void syncHorseDataToClient(HitchableHorse horse, ServerPlayer player) {
        Packets.sendToClient(new SyncHorseDataS2CP(horse.horseman$asHorse().m_19879_(),
                getHorseInventory(horse), getLead(horse), isHitched(horse)), player);
    }

    static void syncHorseDataToTrackingClients(HitchableHorse horse) {
        Packets.sendToPlayersTrackingEntity(horse.horseman$asHorse(), new SyncHorseDataS2CP(
                horse.horseman$asHorse().m_19879_(), getHorseInventory(horse), getLead(horse), isHitched(horse)));
    }

    private static List<ItemStack> getHorseInventory(HitchableHorse horse) {
        SimpleContainer inventory = horse.horseman$asHorse().f_30520_;
        List<ItemStack> items = new ArrayList<>();
        for (int i = 0; i < inventory.m_6643_(); i++) {
            items.add(inventory.m_8020_(i));
        }
        return items;
    }
}
