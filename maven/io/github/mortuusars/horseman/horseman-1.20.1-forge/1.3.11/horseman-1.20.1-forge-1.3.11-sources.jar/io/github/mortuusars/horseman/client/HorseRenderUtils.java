package io.github.mortuusars.horseman.client;

import io.github.mortuusars.horseman.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.horse.AbstractHorse;

public class HorseRenderUtils {
    public static boolean isJeb(LivingEntity entity) {
        return Config.Client.JEB_HORSE.get() && entity.m_7770_() != null && entity.m_7770_().getString().equals("jeb_");
    }

    public static double getAlpha(LivingEntity entity) {
        if (!Config.Client.TRANSPARENT_HORSE_ENABLED.get()
                || Minecraft.m_91087_().f_91074_ == null
                || !Minecraft.m_91087_().f_91066_.m_92176_().m_90612_()
                || !(entity instanceof AbstractHorse horse)
                || !Minecraft.m_91087_().f_91074_.equals(horse.m_6688_())) {
            return 1.0;
        }

        int startAngle = Config.Client.TRANSPARENT_HORSE_START_ANGLE.get();

        float angle = Minecraft.m_91087_().f_91074_.f_19860_;
        if (angle < startAngle) return 1.0;

        double maxTransparency = Config.Client.TRANSPARENT_HORSE_MAX_OPACITY.get();
        int endAngle = Config.Client.TRANSPARENT_HORSE_END_ANGLE.get();

        float delta = (Math.min(angle, endAngle) - startAngle) / (endAngle - startAngle);
        return Mth.m_14139_(delta, 1.0, maxTransparency);
    }
}
