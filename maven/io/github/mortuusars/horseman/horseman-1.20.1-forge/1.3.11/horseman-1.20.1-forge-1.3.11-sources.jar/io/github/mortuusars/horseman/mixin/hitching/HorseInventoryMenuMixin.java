package io.github.mortuusars.horseman.mixin.hitching;

import io.github.mortuusars.horseman.horse.HitchableHorse;
import net.minecraft.world.Container;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.HorseInventoryMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(HorseInventoryMenu.class)
public abstract class HorseInventoryMenuMixin extends AbstractContainerMenu {
    @Shadow @Final private Container horseContainer;
    @Shadow @Final private AbstractHorse horse;
    @Unique
    private boolean horseman$leadSlotAdded = false;

    protected HorseInventoryMenuMixin(@Nullable MenuType<?> menuType, int containerId) {
        super(menuType, containerId);
    }

    /**
     * We cannot mixin with "INVOKE" into constructors on forge apparently, so adding Lead slot here is likely the only option.
     * It should come before chest slots for Shift+Clicking to work properly.
     * Unfortunately we cannot change (or at least not easily) indexes of chest slots,
     * so Lead slot index will be after chest slots (for inventory, it's still added before then in order)
     */
    @Inject(method = "hasChest", at = @At(value = "HEAD"))
    private void onHasChest(AbstractHorse horse, CallbackInfoReturnable<Boolean> cir) {
        if (horseman$leadSlotAdded) return;
        if (!(horse instanceof HitchableHorse hitchableHorse)) return;
        if (!HitchableHorse.shouldHaveLeadSlot(hitchableHorse)) return;

        int leadSlotIndex = HitchableHorse.getLeadSlotIndex(hitchableHorse);
        m_38897_(new Slot(this.horseContainer, leadSlotIndex, 8, 54) {
            @Override
            public boolean m_5857_(ItemStack stack) {
                return HitchableHorse.mayPlaceInLeadSlot(hitchableHorse, stack);
            }

            @Override
            public boolean m_8010_(Player player) {
                ItemStack stack = this.m_7993_();
                return !stack.m_150930_(Items.f_42655_) || !HitchableHorse.isHitched(hitchableHorse);
            }

            @Override
            public int m_6641_() {
                return 1;
            }

            @Override
            public boolean m_6659_() {
                // Making it active on client to keep rendering the slot.
                return horse.m_9236_().f_46443_ || HitchableHorse.isLeadSlotActive(hitchableHorse);
            }
        });
        horseman$leadSlotAdded = true;
    }

    /**
     * When Lead stack in player inventory is shift-clicked - splits only one item from clicked stack and inserts into Lead slot.
     * On Forge it's mostly a QOL thing (it will work without it, but not stop moving the rest of a stack in other slots),
     * but on Fabric without this mixin it's possible to insert 64 items into a slot with stack size of 1.
     * Fabric does not check slot limits when inserting.
     */
    @Inject(method = "quickMoveStack", at = @At(value = "HEAD"), cancellable = true)
    private void onQuickMoveStack(Player player, int index, CallbackInfoReturnable<ItemStack> cir) {
        if (!(this.horse instanceof HitchableHorse hitchableHorse)) return;
        if (!HitchableHorse.shouldHaveLeadSlot(hitchableHorse)) return;
        if (index < this.horseContainer.m_6643_()) return;

        Slot slot = this.f_38839_.get(index);
        if (!slot.m_6657_()) {
            return;
        }

        ItemStack clickedStack = slot.m_7993_();
        if (!clickedStack.m_150930_(Items.f_42655_)) {
            return;
        }

        ItemStack clickedStackCopy = clickedStack.m_41777_();

        Slot leadSlot = m_38853_(2);
        if (!leadSlot.m_5857_(clickedStack)) {
            return;
        }

        ItemStack movedStack = clickedStack.m_255036_(1);

        if (!leadSlot.m_7993_().m_41619_()) {
            if (!m_38903_(clickedStack, 3, this.horseContainer.m_6643_(), false)) {
                cir.setReturnValue(ItemStack.f_41583_);
                return;
            }

            if (clickedStack.m_41619_()) {
                slot.m_269060_(ItemStack.f_41583_);
            } else {
                slot.m_6654_();
            }

            if (clickedStack.m_41613_() == clickedStackCopy.m_41613_()) {
                cir.setReturnValue(ItemStack.f_41583_);
                return;
            }

            slot.m_142406_(player, clickedStack);

            cir.setReturnValue(ItemStack.f_41583_);
            return;
        }

        clickedStack.m_41774_(1);
        this.f_38839_.get(2).m_269060_(movedStack);

        if (clickedStack.m_41619_()) {
            slot.m_269060_(ItemStack.f_41583_);
        } else {
            slot.m_6654_();
        }

        if (clickedStack.m_41613_() == clickedStackCopy.m_41613_()) {
            cir.setReturnValue(ItemStack.f_41583_);
            return;
        }

        slot.m_142406_(player, clickedStack);

        cir.setReturnValue(ItemStack.f_41583_);
    }
}
