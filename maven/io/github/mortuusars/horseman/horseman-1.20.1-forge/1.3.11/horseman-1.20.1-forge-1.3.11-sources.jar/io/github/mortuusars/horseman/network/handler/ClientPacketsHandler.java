package io.github.mortuusars.horseman.network.handler;

import io.github.mortuusars.horseman.horse.HitchableHorse;
import io.github.mortuusars.horseman.network.packet.client.SyncHorseDataS2CP;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.item.ItemStack;

public class ClientPacketsHandler {
    private static void executeOnMainThread(Runnable runnable) {
        Minecraft.m_91087_().execute(runnable);
    }

    public static void syncHorseData(SyncHorseDataS2CP packet) {
        if (Minecraft.m_91087_().f_91073_ == null) return;
        executeOnMainThread(() -> {
            if (Minecraft.m_91087_().f_91073_.m_6815_(packet.entityId()) instanceof AbstractHorse horse) {
                for (int i = 0; i < packet.inventory().size(); i++) {
                    ItemStack itemStack = packet.inventory().get(i);
                    if (i < horse.f_30520_.m_6643_()) {
                        horse.f_30520_.m_6836_(i, itemStack);
                    }
                }

                if (horse instanceof HitchableHorse hitchableHorse) {
                    hitchableHorse.horseman$setHitched(packet.isHitched());
                    hitchableHorse.horseman$setLead(packet.leadStack());
                }
            }
        });
    }
}
