package io.github.mortuusars.horseman.mixin.hitching;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.horseman.data.HitchableHorse;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.horse.AbstractChestedHorse;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractHorse.class)
public abstract class AbstractHorseMixin extends Animal implements HitchableHorse {
    @Shadow protected abstract int getInventorySize();
    @Shadow public SimpleContainer inventory;

    @Unique
    protected boolean horseman$isHitched = false;
    @Unique
    protected ItemStack horseman$builtInLead = ItemStack.f_41583_;

    protected AbstractHorseMixin(EntityType<? extends Animal> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    public ItemStack horseman$getLead() {
        if (!HitchableHorse.isEnabled()) {
            return ItemStack.f_41583_;
        }

        if (HitchableHorse.shouldHaveLeadSlot(this)) {
            return inventory.m_8020_(HitchableHorse.getLeadSlotIndex(this));
        } else {
            return horseman$builtInLead;
        }
    }

    @Override
    public void horseman$setLead(ItemStack stack) {
        if (HitchableHorse.shouldHaveLeadSlot(this)) {
            inventory.m_6836_(HitchableHorse.getLeadSlotIndex(this), stack);
        } else {
            horseman$builtInLead = stack;
        }
    }

    @Override
    public boolean horseman$isHitched() {
        return m_21523_() && horseman$isHitched;
    }

    @Override
    public void horseman$setHitched(boolean hitched) {
        horseman$isHitched = hitched;
    }

    // --

    /**
     * Add +1 for the lead slot. {@link AbstractChestedHorseMixin} should also be changed as it overrides this method.
     */
    @ModifyReturnValue(method = "getInventorySize", at = @At("RETURN"))
    private int onGetInventorySize(int original) {
        return HitchableHorse.shouldHaveLeadSlot(this) ? original + 1 : original;
    }

    /**
     * All hitching stuff is hacky, but this is beyond stupid and just waiting to brake something.
     * This is done to move the Lead to a correct slot after chest has been put on a horse.
     * Lead slot is always the last one, and when placing a chest it will change from 2 to 17.
     * And if we don't move the item, it will appear in first chest slot.
     */
    @Inject(method = "createInventory", at = @At(value = "HEAD"))
    private void onCreateInventory(CallbackInfo ci) {
        AbstractHorse horse = (AbstractHorse)(Object)this;
        if (horse instanceof AbstractChestedHorse chestedHorse
                && chestedHorse.m_30502_()
                && getInventorySize() > inventory.m_6643_()
                && HitchableHorse.shouldHaveLeadSlot(this)) {
            @Nullable SimpleContainer prevInventory = inventory;
            inventory = new SimpleContainer(getInventorySize());
            if (prevInventory != null) {
                prevInventory.m_19181_(horse);
                int slots = Math.min(prevInventory.m_6643_(), this.inventory.m_6643_());
                for (int i = 0; i < slots; ++i) {
                    ItemStack itemStack = prevInventory.m_8020_(i);
                    if (itemStack.m_41619_()) continue;
                    this.inventory.m_6836_(i, itemStack.m_41777_());
                }

                // Swap lead that's now in the wrong slot to last inventory slot.
                if (inventory.m_8020_(2).m_150930_(Items.f_42655_)) {
                    ItemStack lastItem = inventory.m_8020_(inventory.m_6643_() - 1);
                    inventory.m_6836_(inventory.m_6643_() - 1, inventory.m_8020_(2));
                    inventory.m_6836_(2, lastItem);
                }
            }
        }
    }

    // Drops the Lead if it's not in inventory (slot is disabled)
    @Inject(method = "dropEquipment", at = @At(value = "RETURN"))
    private void onDropEquipment(CallbackInfo ci) {
        if (HitchableHorse.isEnabled() && HitchableHorse.requiresLead()
                && !HitchableHorse.shouldHaveLeadSlot(this)
                && HitchableHorse.hasLead(this)) {
            m_19983_(HitchableHorse.getLead(this));
            HitchableHorse.setLead(this, ItemStack.f_41583_);
        }
    }

    // --

    @Inject(method = "addAdditionalSaveData", at = @At("RETURN"))
    protected void onAddAdditionalSaveData(CompoundTag tag, CallbackInfo ci) {
        ItemStack leadStack = horseman$getLead();
        if (!leadStack.m_41619_()) {
            tag.m_128365_("HorsemanLeadItem", leadStack.m_41739_(new CompoundTag()));
        }

        if (horseman$isHitched()) {
            tag.m_128379_("HorsemanHitched", true);
        }
    }

    @Inject(method = "readAdditionalSaveData", at = @At("RETURN"))
    protected void onReadAdditionalSaveData(CompoundTag tag, CallbackInfo ci) {
        if (tag.m_128425_("HorsemanLeadItem", Tag.f_178203_)) {
            ItemStack leadStack = ItemStack.m_41712_(tag.m_128469_("HorsemanLeadItem"));

            // Backwards compat with <=1.1.4
            if (leadStack.m_41783_() != null && leadStack.m_41783_().m_128441_("PreventLeadDrop")) {
                HitchableHorse.setHitched(this, true);
                leadStack.m_41783_().m_128473_("PreventLeadDrop");
                if (leadStack.m_41783_().m_128456_()) {
                    leadStack.m_41751_(null);
                }
            }

            horseman$setLead(leadStack);
        }

        horseman$isHitched = tag.m_128471_("HorsemanHitched");
    }
}
