package io.github.mortuusars.horseman.mixin.hitching;

import io.github.mortuusars.horseman.data.HitchableHorse;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.LeadItem;
import net.minecraft.world.item.ShearsItem;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Mob.class)
public abstract class MobMixin extends LivingEntity {
    protected MobMixin(EntityType<? extends LivingEntity> entityType, Level level) {
        super(entityType, level);
    }

    @ModifyVariable(method = "dropLeash", at = @At("HEAD"), ordinal = 1, argsOnly = true)
    private boolean shouldDropLeash(boolean dropLeash) {
        return dropLeash && this instanceof HitchableHorse horse ? !HitchableHorse.isHitched(horse) : dropLeash;
    }

    @Inject(method = "dropLeash", at = @At(value = "RETURN"))
    private void onDropLeash(boolean broadcastPacket, boolean dropLeash, CallbackInfo ci) {
        if (this instanceof HitchableHorse horse) {
            HitchableHorse.setHitched(horse, false);
            if (!horse.horseman$asHorse().m_9236_().m_5776_()) {
                HitchableHorse.syncHorseDataToTrackingClients(horse);
            }
        }
    }

    @Inject(method = "checkAndHandleImportantInteractions", at = @At(value = "HEAD"), cancellable = true)
    private void onCheckAndHandleImportantInteractions(Player player, InteractionHand hand, CallbackInfoReturnable<InteractionResult> cir) {
        if (!(this instanceof HitchableHorse horse)
                || !horse.horseman$asHorse().m_30614_()
                || horse.horseman$asHorse().m_6162_()
                || !HitchableHorse.isEnabled()) {
            return;
        }

        ItemStack itemInHand = player.m_21120_(hand);

        if (itemInHand.m_41720_() instanceof ShearsItem && !player.m_36341_() && HitchableHorse.hasLead(horse)) {
            if (HitchableHorse.isHitched(horse)) {
                horse.horseman$asHorse().m_21455_(true, false);
            }
            if (!m_9236_().f_46443_) {
                ItemStack leadStack = HitchableHorse.getLead(horse);
                m_19983_(leadStack);
            }
            m_9236_().m_6269_(player, player, SoundEvents.f_12344_, SoundSource.PLAYERS, 0.8f, 1f);
            HitchableHorse.setLead(horse, ItemStack.f_41583_);
            if (!m_9236_().f_46443_) {
                HitchableHorse.syncHorseDataToTrackingClients(horse);
            }
            cir.setReturnValue(InteractionResult.m_19078_(m_9236_().f_46443_));
            return;
        }

        if (itemInHand.m_41720_() instanceof LeadItem && player.m_36341_()
                && HitchableHorse.isHitchable(horse) && !HitchableHorse.hasLead(horse)) {
            ItemStack leadStack = itemInHand.m_41620_(1);
            HitchableHorse.setLead(horse, leadStack);
            player.m_6674_(hand);
            cir.setReturnValue(InteractionResult.m_19078_(m_9236_().f_46443_));
            m_9236_().m_6269_(player, player, SoundEvents.f_12087_, SoundSource.PLAYERS, 0.8f, 1f);
            return;
        }
    }
}
