package io.github.mortuusars.horseman.mixin.switch_inventory;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.client.SwitchInventory;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.HorseInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractContainerScreen.class)
public abstract class AbstractContainerScreenMixin extends Screen {
    @Shadow
    protected int leftPos;
    @Shadow
    protected int topPos;

    protected AbstractContainerScreenMixin(Component title) {
        super(title);
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void onKeyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        if (((AbstractContainerScreen<?>) (Object) this) instanceof HorseInventoryScreen
              && Config.Client.INVENTORY_TOGGLE_ENABLED.get()
              && Minecraft.m_91087_().f_91066_.f_92092_.m_90832_(keyCode, scanCode)
              && Screen.m_96637_()) {
            SwitchInventory.switchFromHorse(((AbstractContainerScreen<?>) (Object) this));
            Minecraft.m_91087_().m_91106_().m_120367_(SimpleSoundInstance.m_263171_(SoundEvents.f_12490_, 1));
            cir.setReturnValue(true);
        }

        if (((Object) this) instanceof InventoryScreen
              && Config.Client.INVENTORY_TOGGLE_ENABLED.get()
              && Minecraft.m_91087_().f_91074_ != null && Minecraft.m_91087_().f_91074_.m_245714_() instanceof AbstractHorse
              && Minecraft.m_91087_().f_91066_.f_92092_.m_90832_(keyCode, scanCode)
              && Screen.m_96637_()) {
            SwitchInventory.switchFromInventory((AbstractContainerScreen<?>) (Object) this);
            Minecraft.m_91087_().m_91106_().m_120367_(SimpleSoundInstance.m_263171_(SoundEvents.f_12490_, 1));
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "init", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        if (Minecraft.m_91087_().f_91072_ == null) return;

        if (!Config.Client.INVENTORY_TOGGLE_ENABLED.get()) {
            return;
        }

        if (((Object) this) instanceof HorseInventoryScreen) {
            if (SwitchInventory.mouseX != null && SwitchInventory.mouseY != null) {
                GLFW.glfwSetCursorPos(Minecraft.m_91087_().m_91268_().m_85439_(), SwitchInventory.mouseX, SwitchInventory.mouseY);
                // Clear remembered cursor pos after setting, to not apply it again when not needed:
                SwitchInventory.mouseX = null;
                SwitchInventory.mouseY = null;
            }

            ImageButton button = new ImageButton(
                  leftPos + Config.Client.INVENTORY_TOGGLE_HORSE_BUTTON_X.get(),
                  topPos + Config.Client.INVENTORY_TOGGLE_HORSE_BUTTON_Y.get(),
                  14, 15,
                  0, 0, 15,
                  SwitchInventory.BUTTON_TEXTURE,
                  256, 256,
                  b -> SwitchInventory.switchFromHorse(((AbstractContainerScreen<?>) (Object) this)));

            button.m_257544_(Tooltip.m_257550_(Component.m_237110_("gui.horseman.switch_inventory.button.from_horse.tooltip",
                  Component.m_237113_(Minecraft.m_91087_().f_91066_.f_92092_.m_90863_().getString()).m_130940_(ChatFormatting.GRAY)
            )));

            m_142416_(button);
        }

        if (((AbstractContainerScreen<?>) (Object) this) instanceof InventoryScreen
              && Minecraft.m_91087_().f_91072_.m_105292_()) {

            ImageButton button = new ImageButton(
                  leftPos + Config.Client.INVENTORY_TOGGLE_PLAYER_BUTTON_X.get(),
                  topPos + Config.Client.INVENTORY_TOGGLE_PLAYER_BUTTON_Y.get(),
                  14, 15,
                  0, 0, 15,
                  SwitchInventory.BUTTON_TEXTURE,
                  256, 256,
                  b -> SwitchInventory.switchFromInventory(((AbstractContainerScreen<?>) (Object) this)));

            Component vehicleName = Minecraft.m_91087_().f_91074_ != null
                  && Minecraft.m_91087_().f_91074_.m_20202_() instanceof LivingEntity entity
                  ? entity.m_7755_()
                  : Component.m_237115_("gui.horseman.switch_inventory.button.from_inventory..tooltip.mount");

            button.m_257544_(Tooltip.m_257550_(Component.m_237110_("gui.horseman.switch_inventory.button.from_inventory.tooltip",
                  vehicleName,
                  Component.m_237113_(Minecraft.m_91087_().f_91066_.f_92092_.m_90863_().getString()).m_130940_(ChatFormatting.GRAY)
            )));

            m_142416_(button);
        }
    }
}

