package io.github.mortuusars.horseman.mixin.fix_running_back;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1297;
import net.minecraft.class_1496;
import net.minecraft.class_1937;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_1297.class, priority = 950)
public abstract class EntityMixin {
    @Shadow public abstract class_1937 level();

    @Shadow @Nullable public abstract class_1297 getVehicle();

    @Inject(method = "removeVehicle", at = @At(value = "HEAD"))
    private void removeVehicle(CallbackInfo ci) {
        if (Config.Server.FIX_RUNNING_BACK_AFTER_DISMOUNT.get() &&
                getVehicle() instanceof class_1496 horse && horse.method_5685().size() == 1) {
            horse.method_5942().method_6340();
        }
    }
}