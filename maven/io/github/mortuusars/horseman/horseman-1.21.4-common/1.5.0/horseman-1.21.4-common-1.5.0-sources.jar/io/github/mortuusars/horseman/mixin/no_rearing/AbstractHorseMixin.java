package io.github.mortuusars.horseman.mixin.no_rearing;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value = class_1496.class, priority = 950)
public abstract class AbstractHorseMixin {
    @Shadow public abstract boolean isJumping();
    @Shadow public abstract boolean isTamed();
    @Shadow public abstract class_1309 getControllingPassenger();

    @ModifyReturnValue(method = "isStanding", at = @At("RETURN"))
    private boolean isStanding(boolean original) {
        if (Config.Server.HORSE_PREVENT_REARING_WHEN_RIDING.get()
            && !isJumping()
            && isTamed()
            && getControllingPassenger() != null) {
            return false;
        }
        return original;
    }
}