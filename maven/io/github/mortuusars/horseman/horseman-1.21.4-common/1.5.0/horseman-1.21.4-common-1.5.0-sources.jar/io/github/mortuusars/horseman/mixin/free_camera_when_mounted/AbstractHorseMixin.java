package io.github.mortuusars.horseman.mixin.free_camera_when_mounted;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_241;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1496.class)
public abstract class AbstractHorseMixin extends class_1429 {
    protected AbstractHorseMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "getRiddenRotation", at = @At(value = "HEAD"), cancellable = true)
    private void onGetRiddenRotation(class_1309 entity, CallbackInfoReturnable<class_241> cir) {
        class_1496 horse = (class_1496)(Object)this;
        if (!Config.Server.HORSE_FREE_CAMERA.get() || !(entity instanceof class_1657 player) || player.field_6212 != 0 || player.field_6250 != 0) {
            return;
        }

        float threshold = Config.Server.HORSE_FREE_CAMERA_ANGLE_THRESHOLD.get().floatValue();

        float rotationDifference = (player.method_36454() - horse.method_36454() + 540) % 360 - 180;

        if (Math.abs(rotationDifference) > threshold) {
            // Rotate the horse following player's rotation, with offset
            cir.setReturnValue(new class_241(player.method_36455() * 0.5f, player.method_36454() - Math.signum(rotationDifference) * threshold));
        }
        else {
            cir.setReturnValue(new class_241(player.method_36455() * 0.5f, horse.method_36454()));
        }
    }
}
