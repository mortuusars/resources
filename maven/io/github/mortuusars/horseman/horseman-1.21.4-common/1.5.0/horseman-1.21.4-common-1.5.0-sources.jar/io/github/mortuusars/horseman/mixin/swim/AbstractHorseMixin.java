package io.github.mortuusars.horseman.mixin.swim;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3486;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_1496.class)
public abstract class AbstractHorseMixin extends class_1429 {
    protected AbstractHorseMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "getRiddenInput", at = @At(value = "RETURN"))
    private void getRiddenInput(class_1657 player, class_243 travelVector, CallbackInfoReturnable<class_243> cir) {
        if (Config.Server.HORSE_SWIM_WHEN_RIDDEN.get()
                && !method_5864().method_20210(Horseman.Tags.EntityTypes.CANNOT_SWIM)
                && player.field_6282
                && method_5799()
                && method_5861(class_3486.field_15517) > 0) {
            method_18799(method_18798().method_1031(0.0, 0.04, 0.0));
        }
    }
}