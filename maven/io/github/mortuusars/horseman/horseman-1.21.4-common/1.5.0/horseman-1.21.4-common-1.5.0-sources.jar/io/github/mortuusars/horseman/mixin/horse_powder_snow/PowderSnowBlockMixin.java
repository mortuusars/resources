package io.github.mortuusars.horseman.mixin.horse_powder_snow;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1297;
import net.minecraft.class_1496;
import net.minecraft.class_1802;
import net.minecraft.class_5635;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_5635.class)
public abstract class PowderSnowBlockMixin {
    @ModifyReturnValue(method = "canEntityWalkOnPowderSnow", at = @At("RETURN"))
    private static boolean canEntityWalkOnPowderSnow(boolean original, @Local(argsOnly = true) class_1297 entity) {
        return original ||
                (Config.Server.LEATHER_HORSE_ARMOR_POWDER_SNOW.get()
                        && entity instanceof class_1496 horse
                        && horse.method_56676().method_31574(class_1802.field_18138));
    }
}
