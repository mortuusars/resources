package io.github.mortuusars.horseman.mixin.ride_though_leaves;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.world.LeavesCollisionMode;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2397;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_3727;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_4970.class)
public abstract class BlockBehaviourMixin {
    @ModifyReturnValue(method = "getCollisionShape", at = @At("RETURN"))
    protected class_265 getCollisionShape(class_265 original,
                                           @Local(argsOnly = true) class_2680 state,
                                           @Local(argsOnly = true) class_1922 level,
                                           @Local(argsOnly = true) class_2338 pos,
                                           @Local(argsOnly = true) class_3726 context) {
        if (!Config.Server.SPEC.isLoaded()) return original;
        LeavesCollisionMode collisionMode = Config.Server.LEAVES_COLLISION_MODE_WHEN_MOUNTED.get();
        if (collisionMode == LeavesCollisionMode.FULL) return original;

        if (state.method_26204() instanceof class_2397
                && context instanceof class_3727 entityContext
                && entityContext.method_32480() instanceof class_1496 horse
                && horse.method_5642() instanceof class_1657) {

            if (collisionMode == LeavesCollisionMode.IGNORE_LOWEST_BLOCK
                    && level.method_8320(pos.method_10074()).method_26204() instanceof class_2397) {
                return original;
            }

            return class_259.method_1073();
        }

        return original;
    }
}
