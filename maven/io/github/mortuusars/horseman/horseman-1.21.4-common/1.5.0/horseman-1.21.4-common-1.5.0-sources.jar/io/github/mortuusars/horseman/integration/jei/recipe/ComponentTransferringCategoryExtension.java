package io.github.mortuusars.horseman.integration.jei.recipe;

import io.github.mortuusars.horseman.world.item.crafting.recipe.ComponentTransferringRecipe;
import mezz.jei.api.recipe.category.extensions.vanilla.crafting.ICraftingCategoryExtension;
import net.minecraft.class_10295;
import net.minecraft.class_10300;
import net.minecraft.class_10301;
import net.minecraft.class_10302;
import net.minecraft.class_3955;
import net.minecraft.class_8786;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class ComponentTransferringCategoryExtension implements ICraftingCategoryExtension<class_3955> {
	@Override
	public boolean isHandled(class_8786<class_3955> recipeHolder) {
		return recipeHolder.comp_1933() instanceof ComponentTransferringRecipe;
	}

	@Override
	public @NotNull List<class_10302> getIngredients(class_8786<class_3955> recipeHolder) {
		List<class_10295> displays = recipeHolder.comp_1933().method_64664();
		if (displays.isEmpty()) {
			return List.of();
		}
		class_10295 display = displays.getFirst();
		if (display instanceof class_10300 shapedCraftingRecipeDisplay) {
			return shapedCraftingRecipeDisplay.comp_3270();
		} else if (display instanceof class_10301 shapelessCraftingRecipeDisplay) {
			return shapelessCraftingRecipeDisplay.comp_3271();
		} else {
			return List.of();
		}
	}
}
