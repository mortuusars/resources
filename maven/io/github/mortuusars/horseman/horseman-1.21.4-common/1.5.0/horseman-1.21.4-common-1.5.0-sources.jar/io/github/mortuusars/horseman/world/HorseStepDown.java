package io.github.mortuusars.horseman.world;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public class HorseStepDown {
    public static boolean shouldHorseStepDown(class_1496 horse) {
        if (!Config.Server.HORSE_FAST_STEP_DOWN.get()) return false;
        if (!(horse.method_5642() instanceof class_1657)) return false;
        if (horse.method_24828() || horse.method_6763()) return false;
        return horse.field_6017 > 0.0 && horse.field_6017 < 0.2 && canStepDownOnBlock(horse);
    }

    private static boolean canStepDownOnBlock(class_1496 horse) {
        class_1937 level = horse.method_37908();
        class_2338 pos = horse.method_24515();
        if (!level.method_8320(pos.method_10074()).method_26220(level, pos.method_10074()).method_1110()) return true;
        return Config.Server.HORSE_FAST_STEP_DOWN_TWO_BLOCKS.get()
                && !level.method_8320(pos.method_10087(2)).method_26220(level, pos.method_10087(2)).method_1110();
    }
}
