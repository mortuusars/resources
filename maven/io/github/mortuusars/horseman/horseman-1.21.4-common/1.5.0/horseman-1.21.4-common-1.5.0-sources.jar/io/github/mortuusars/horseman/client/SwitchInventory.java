package io.github.mortuusars.horseman.client;

import io.github.mortuusars.horseman.Horseman;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_490;
import net.minecraft.class_8666;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

public class SwitchInventory {
    public static final class_8666 SWITCH_BUTTON_SPRITES = new class_8666(
            Horseman.resource("switch_inventory_button"),
            Horseman.resource("switch_inventory_button_disabled"),
            Horseman.resource("switch_inventory_button_highlighted"));

    public static @Nullable Double mouseX, mouseY;

    public static void switchFromHorse(class_465<?> screen) {
        if (class_310.method_1551().field_1724 == null) return;

        double cursorX = class_310.method_1551().field_1729.method_1603();
        double cursorY = class_310.method_1551().field_1729.method_1604();

        screen.method_25419();
        class_310.method_1551().method_1507(new class_490(class_310.method_1551().field_1724));

        // Move cursor to previous position, as setScreen resets it to center every time:
        class_310.method_1551().execute(() -> {
            GLFW.glfwSetCursorPos(class_310.method_1551().method_22683().method_4490(), cursorX, cursorY);
        });
    }

    public static void switchFromInventory(class_465<?> screen) {
        if (class_310.method_1551().field_1724 == null) return;
        // Cannot move cursor like from mount, because screen is opened later due to it being sent from server.
        // So we remember pos here, and set it when screen is initialized.
        mouseX = class_310.method_1551().field_1729.method_1603();
        mouseY = class_310.method_1551().field_1729.method_1604();

        screen.method_25419();
        class_310.method_1551().field_1724.method_3132();
    }
}
