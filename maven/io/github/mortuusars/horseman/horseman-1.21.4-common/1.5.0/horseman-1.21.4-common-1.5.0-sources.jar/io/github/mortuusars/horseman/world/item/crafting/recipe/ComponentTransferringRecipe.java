package io.github.mortuusars.horseman.world.item.crafting.recipe;

import io.github.mortuusars.horseman.Horseman;
import net.minecraft.class_10295;
import net.minecraft.class_10301;
import net.minecraft.class_10302;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1852;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_9694;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class ComponentTransferringRecipe extends class_1852 {
    private final class_1856 sourceIngredient;
    private final class_2371<class_1856> ingredients;
    private final class_1799 result;

    public ComponentTransferringRecipe(class_7710 category, class_1856 sourceIngredient, class_2371<class_1856> ingredients, class_1799 result) {
        super(category);
        this.sourceIngredient = sourceIngredient;
        this.ingredients = ingredients;
        this.result = result;
    }

    @Override
    public @NotNull class_1865<ComponentTransferringRecipe> method_8119() {
        return Horseman.RecipeSerializers.COMPONENT_TRANSFERRING.get();
    }

    public @NotNull class_1856 getSourceIngredient() {
        return sourceIngredient;
    }

    public @NotNull class_2371<class_1856> getIngredients() {
        return ingredients;
    }

    public @NotNull class_1799 getResultItem(class_7225.class_7874 registries) {
        return getResult();
    }

    public @NotNull class_1799 getResult() {
        return result;
    }

    @Override
    public boolean matches(class_9694 input, class_1937 level) {
        if (getSourceIngredient().method_65799() || ingredients.isEmpty())
            return false;

        List<class_1856> unmatchedIngredients = new ArrayList<>(ingredients);
        unmatchedIngredients.addFirst(getSourceIngredient());

        int itemsInCraftingGrid = 0;

        for (int i = 0; i < input.method_59983(); i++) {
            class_1799 stack = input.method_59984(i);
            if (!stack.method_7960())
                itemsInCraftingGrid++;

            if (itemsInCraftingGrid > ingredients.size() + 1)
                return false;

            if (!unmatchedIngredients.isEmpty()) {
                for (int j = 0; j < unmatchedIngredients.size(); j++) {
                    if (unmatchedIngredients.get(j).method_8093(stack)) {
                        unmatchedIngredients.remove(j);
                        break;
                    }
                }
            }
        }

        return unmatchedIngredients.isEmpty() && itemsInCraftingGrid == ingredients.size() + 1;
    }

    @Override
    public @NotNull class_1799 assemble(class_9694 input, class_7225.class_7874 registries) {
        for (int index = 0; index < input.method_59983(); index++) {
            class_1799 itemStack = input.method_59984(index);

            if (getSourceIngredient().method_8093(itemStack)) {
                return itemStack.method_60503(getResultItem(registries).method_7909());
            }
        }

        return getResultItem(registries);
    }

    @Override
    public @NotNull List<class_10295> method_64664() {
        ArrayList<class_10302> list = new ArrayList<>(ingredients.stream().map(class_1856::method_64673).toList());
        list.addFirst(sourceIngredient.method_64673());
        return List.of(new class_10301(list, new class_10302.class_10306(this.result.method_7909()), new class_10302.class_10306(class_1802.field_8465)));
    }
}
