package io.github.mortuusars.horseman.mixin.leash_sounds;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1532;
import net.minecraft.class_1657;
import net.minecraft.class_3419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1532.class)
public abstract class LeashFenceKnotEntityMixin {
    @Inject(method = "interact", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/decoration/LeashFenceKnotEntity;discard()V"))
    private void interact(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        if (Config.Server.LEASH_KNOT_SOUNDS.get()) {
            class_1532 e = ((class_1532) (Object) this);
            e.method_37908().method_43128(null, e.method_23317(), e.method_23318(), e.method_23321(),
                    Horseman.SoundEvents.LEASH_UNTIED.get(), class_3419.field_15254, 1f, 1f);
        }
    }
}
