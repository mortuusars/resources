package io.github.mortuusars.horseman.world.summoning;

import io.github.mortuusars.horseman.Horseman;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7444;
import net.minecraft.class_7924;

public record BoundData(UUID owner, class_5321<class_7444> instrument) {
    public BoundData(class_1657 player, class_5321<class_7444> instrument) {
        this(player.method_5667(), instrument);
    }

    public boolean isBoundTo(UUID uuid) {
        return owner().equals(uuid);
    }

    public boolean isBoundTo(class_1657 player) {
        return isBoundTo(player.method_5667());
    }

    // --

    public class_2487 save(class_2487 tag) {
        tag.method_25927("HorsemanCallingOwner", owner);
        tag.method_10582("HorsemanCallingInstrument", instrument.method_29177().toString());
        return tag;
    }

    public static @Nullable BoundData load(class_2487 tag) {
        if (!tag.method_10573("HorsemanCallingOwner", class_2520.field_33261)) return null;
        if (!tag.method_10573("HorsemanCallingInstrument", class_2520.field_33258)) return null;

        return new BoundData(tag.method_25926("HorsemanCallingOwner"),
                getResourceKey1(tag, "HorsemanCallingInstrument", class_7924.field_41275));
    }

    @SuppressWarnings("SameParameterValue")
    private static <T> class_5321<T> getResourceKey1(class_2487 tag, String key, class_5321<class_2378<T>> registry) {
        String string = tag.method_10558(key);
        try {
            return class_5321.method_29179(registry, class_2960.method_60654(string));
        } catch (Exception e) {
            Horseman.LOGGER.error("Cannot parse '{}' from '{}'.", key, string, e);
            return null;
        }
    }
}