package io.github.mortuusars.horseman.mixin.lower_horse_head;

import io.github.mortuusars.horseman.client.HorseRenderUtils;
import net.minecraft.class_10019;
import net.minecraft.class_1496;
import net.minecraft.class_310;
import net.minecraft.class_5498;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_875;
import net.minecraft.class_9990;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings("deprecation")
@Mixin(class_875.class)
public abstract class AbstractHorseRendererMixin <T extends class_1496, S extends class_10019, M extends class_583<? super S>>
        extends class_9990<T, S, M> {
    public AbstractHorseRendererMixin(class_5617.class_5618 context, M adultModel, M babyModel, float scale) {
        super(context, adultModel, babyModel, scale);
    }

    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/animal/horse/AbstractHorse;Lnet/minecraft/client/renderer/entity/state/EquineRenderState;F)V",
            at = @At("RETURN"))
    private void extractRenderState(T abstractHorse, S equineRenderState, float f, CallbackInfo ci) {
        if (equineRenderState instanceof HorseRenderUtils.HorsemanEquineRenderState horsemanState) {
            boolean riddenByPlayerInFirstPerson = class_310.method_1551().field_1690.method_31044() == class_5498.field_26664
                    && class_310.method_1551().field_1724 != null && abstractHorse.method_5626(class_310.method_1551().field_1724);
            horsemanState.setHorsemanRiddenByPlayerInFirstPerson(riddenByPlayerInFirstPerson);
        }
    }
}
