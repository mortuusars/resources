package io.github.mortuusars.horseman.mixin.hitching;

import io.github.mortuusars.horseman.world.HitchableHorse;
import net.minecraft.class_1263;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_8181;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1496.class)
public abstract class AbstractHorseMixin extends class_1429 implements HitchableHorse {
    @Unique
    protected final class_1263 horseman$leadAccess = horseman$createLeadAccess(this.horseman$asHorse());
    @Unique
    protected class_1799 horseman$leadItem = class_1799.field_8037;
    @Unique
    protected boolean horseman$isHitched = false;

    protected AbstractHorseMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Override
    public class_1799 horseman$getLead() {
        return horseman$leadItem;
    }

    @Override
    public void horseman$setLead(class_1799 stack) {
        horseman$leadItem = stack;
    }

    @Override
    public boolean horseman$isHitched() {
        return method_60953() && horseman$isHitched;
    }

    @Override
    public void horseman$setHitched(boolean hitched) {
        horseman$isHitched = hitched;
    }

    @Override
    public class_1263 horseman$getLeadAccess() {
        return horseman$leadAccess;
    }

    // --

    // Drops the Lead if it's not in inventory (slot is disabled)
    @Inject(method = "dropEquipment", at = @At(value = "RETURN"))
    private void onDropEquipment(class_3218 level, CallbackInfo ci) {
        if (HitchableHorse.hasLead(this)) {
            method_5775(level, HitchableHorse.getLead(this));
            HitchableHorse.setLead(this, class_1799.field_8037);
        }
    }

    // --

    @Inject(method = "addAdditionalSaveData", at = @At("RETURN"))
    protected void onAddAdditionalSaveData(class_2487 tag, CallbackInfo ci) {
        class_1799 leadStack = horseman$getLead();
        if (!leadStack.method_7960()) {
            tag.method_10566("HorsemanLeadItem", leadStack.method_57358(method_56673()));
        }

        if (horseman$isHitched()) {
            tag.method_10556("HorsemanHitched", true);
        }
    }

    @Inject(method = "readAdditionalSaveData", at = @At("RETURN"))
    protected void onReadAdditionalSaveData(class_2487 tag, CallbackInfo ci) {
        if (tag.method_10573("HorsemanLeadItem", class_2520.field_33260)) {
            class_1799 leadStack = class_1799.method_57360(method_56673(), tag.method_10562("HorsemanLeadItem")).orElse(class_1799.field_8037);
            horseman$setLead(leadStack);
        }

        horseman$isHitched = tag.method_10577("HorsemanHitched");
    }

    // --

    @Unique
    private static class_1263 horseman$createLeadAccess(class_1496 horse) {
        return new class_8181() {
            private final class_1496 ownerHorse = horse;

            @Override
            public @NotNull class_1799 method_54079() {
                return ((HitchableHorse) horse).horseman$getLead();
            }

            @Override
            public void method_54077(class_1799 item) {
                ((HitchableHorse) horse).horseman$setLead(item);
            }

            @Override
            public void method_5431() {
            }

            @Override
            public boolean method_5443(class_1657 player) {
                return player.method_5854() == ownerHorse || player.method_56094(ownerHorse, 4.0);
            }
        };
    }
}
