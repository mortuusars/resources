package io.github.mortuusars.horseman.mixin.creative_taming;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1492;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1816;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1492.class)
public abstract class AbstractChestedHorseMixin extends class_1496 {
    protected AbstractChestedHorseMixin(class_1299<? extends class_1496> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "mobInteract", at = @At("HEAD"), cancellable = true)
    private void onMobInteract(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        if (Config.Server.HORSE_CREATIVE_TAMING.get()
                && player.method_7337()
                && player.method_5998(hand).method_7909() instanceof class_1816
                && method_5805()
                && !method_6725()
                && !method_6727()
                && !method_6109()) {
            if (!method_37908().field_9236) {
                method_6752(player);
            }
            cir.setReturnValue(class_1269.field_5812);
        }
    }
}
