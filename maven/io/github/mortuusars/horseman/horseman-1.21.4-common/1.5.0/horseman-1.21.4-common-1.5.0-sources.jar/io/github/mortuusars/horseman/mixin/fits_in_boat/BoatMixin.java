package io.github.mortuusars.horseman.mixin.fits_in_boat;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import net.minecraft.class_10255;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1496;
import net.minecraft.class_1937;
import net.minecraft.class_8836;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_10255.class)
public abstract class BoatMixin extends class_8836 {
    public BoatMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyReturnValue(method = "hasEnoughSpaceFor", at = @At("RETURN"))
    private boolean hasEnoughSpaceFor(boolean original, @Local(argsOnly = true) class_1297 entity) {
        return (Config.Server.HORSE_IN_BOAT.get()
                && entity instanceof class_1496
                && !entity.method_5864().method_20210(Horseman.Tags.EntityTypes.FORBIDS_HORSES)) || original;
    }
}
