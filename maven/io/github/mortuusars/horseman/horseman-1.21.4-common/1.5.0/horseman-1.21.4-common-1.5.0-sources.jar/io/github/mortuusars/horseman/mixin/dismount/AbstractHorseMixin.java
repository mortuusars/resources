package io.github.mortuusars.horseman.mixin.dismount;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1496;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1496.class)
public abstract class AbstractHorseMixin extends class_1429 {
    @Shadow
    @Nullable
    protected abstract class_243 getDismountLocationInDirection(class_243 direction, class_1309 passenger);

    protected AbstractHorseMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "getDismountLocationForPassenger", at = @At("HEAD"), cancellable = true)
    private void getDismountLocation(class_1309 passenger, CallbackInfoReturnable<class_243> cir) {
        if (Config.Server.DISMOUNT_TOWARDS_VIEW_DIRECTION.get()) {
            class_243 escapeVector = method_24826(method_17681(), passenger.method_17681(), passenger.method_36454());
            @Nullable class_243 location = getDismountLocationInDirection(escapeVector, passenger);
            if (location != null) {
                cir.setReturnValue(location);
            }
        }
    }
}
