package io.github.mortuusars.horseman.mixin.fix_camera_lag;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.mojang.authlib.GameProfile;
import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_746.class)
public abstract class LocalPlayerMixin extends class_1657 {
    public LocalPlayerMixin(class_1937 level, class_2338 pos, float yRot, GameProfile gameProfile) {
        super(level, pos, yRot, gameProfile);
    }

    @ModifyReturnValue(method = "getViewYRot", at = @At("RETURN"))
    private float onGetViewYRot(float original) {
        return Config.Client.FIX_MOUNTED_CAMERA_LAG.get() && method_5854() instanceof class_1496 ? method_36454() : original;
    }
}
