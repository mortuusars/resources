package io.github.mortuusars.horseman.mixin.less_wander;

import io.github.mortuusars.horseman.world.LessWanderingHorse;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_1496;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1496.class)
public abstract class AbstractHorseMixin extends class_1429 implements LessWanderingHorse {
    @Unique
    @Nullable
    private class_243 horseman$wanderAnchor = null;

    protected AbstractHorseMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Override
    public @Nullable class_243 horseman$getWanderAnchor() {
        return horseman$wanderAnchor;
    }

    @Override
    public void horseman$setWanderAnchor(@Nullable class_243 pos) {
        horseman$wanderAnchor = pos;
    }

    // --

    @Inject(method = "equipSaddle", at = @At("RETURN"))
    protected void equipSaddle(class_3419 source, CallbackInfo ci) {
        if (LessWanderingHorse.isEnabled()) {
            horseman$wanderAnchor = this.method_19538();
        }
    }

    // --

    @Inject(method = "addAdditionalSaveData", at = @At("RETURN"))
    protected void addAdditionalSaveData(class_2487 tag, CallbackInfo ci) {
        if (horseman$wanderAnchor != null && LessWanderingHorse.isEnabled()) {
            tag.method_10549("HorsemanWanderAnchorX", horseman$wanderAnchor.field_1352);
            tag.method_10549("HorsemanWanderAnchorY", horseman$wanderAnchor.field_1351);
            tag.method_10549("HorsemanWanderAnchorZ", horseman$wanderAnchor.field_1350);
        }
    }

    @Inject(method = "readAdditionalSaveData", at = @At("RETURN"))
    protected void readAdditionalSaveData(class_2487 tag, CallbackInfo ci) {
        if (!LessWanderingHorse.isEnabled()) return;

        @Nullable Double x = null;
        @Nullable Double y = null;
        @Nullable Double z = null;

        if (tag.method_10573("HorsemanWanderAnchorX", class_2520.field_33256)) {
            x = tag.method_10574("HorsemanWanderAnchorX");
        }
        if (tag.method_10573("HorsemanWanderAnchorY", class_2520.field_33256)) {
            y = tag.method_10574("HorsemanWanderAnchorY");
        }
        if (tag.method_10573("HorsemanWanderAnchorZ", class_2520.field_33256)) {
            z = tag.method_10574("HorsemanWanderAnchorZ");
        }

        if (x != null && y != null && z != null) {
            horseman$wanderAnchor = new class_243(x, y, z);
        }
    }
}
