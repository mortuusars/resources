package io.github.mortuusars.horseman.network.handler;

import io.github.mortuusars.horseman.horse.HitchableHorse;
import io.github.mortuusars.horseman.network.packet.client.SyncHorseDataS2CP;
import net.minecraft.class_1496;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public class ClientPacketsHandler {
    private static void executeOnMainThread(Runnable runnable) {
        class_310.method_1551().execute(runnable);
    }

    public static void syncHorseData(SyncHorseDataS2CP packet) {
        if (class_310.method_1551().field_1687 == null) return;
        executeOnMainThread(() -> {
            if (class_310.method_1551().field_1687.method_8469(packet.entityId()) instanceof class_1496 horse) {
                for (int i = 0; i < packet.inventory().size(); i++) {
                    class_1799 itemStack = packet.inventory().get(i);
                    if (i < horse.field_6962.method_5439()) {
                        horse.field_6962.method_5447(i, itemStack);
                    }
                }

                if (horse instanceof HitchableHorse hitchableHorse) {
                    hitchableHorse.horseman$setHitched(packet.isHitched());
                    hitchableHorse.horseman$setLead(packet.leadStack());
                }
            }
        });
    }
}
