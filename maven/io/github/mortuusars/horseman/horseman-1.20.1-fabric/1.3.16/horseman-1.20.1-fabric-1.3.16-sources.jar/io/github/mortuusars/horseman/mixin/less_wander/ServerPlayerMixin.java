package io.github.mortuusars.horseman.mixin.less_wander;

import com.mojang.authlib.GameProfile;
import io.github.mortuusars.horseman.world.LessWanderingHorse;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3222.class)
public abstract class ServerPlayerMixin extends class_1657 {
    public ServerPlayerMixin(class_1937 level, class_2338 pos, float yRot, GameProfile gameProfile) {
        super(level, pos, yRot, gameProfile);
    }

    @Inject(method = "stopRiding", at = @At("HEAD"))
    private void onStopRiding(CallbackInfo ci) {
        if (LessWanderingHorse.isEnabled() && method_5854() instanceof LessWanderingHorse horse) {
            horse.horseman$setWanderAnchor(method_5854().method_19538());
        }
    }
}
