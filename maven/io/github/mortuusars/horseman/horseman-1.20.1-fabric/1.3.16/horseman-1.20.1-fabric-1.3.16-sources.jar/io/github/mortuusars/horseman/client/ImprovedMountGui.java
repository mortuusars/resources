package io.github.mortuusars.horseman.client;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1309;
import net.minecraft.class_310;

public class ImprovedMountGui {
    private static long vehicleInWaterLastTick = -1;

    public static boolean shouldRenderJumpBar() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1761 == null || !mc.field_1761.method_2913()) return false;
        if (mc.field_1687 == null || mc.field_1724 == null || mc.field_1724.method_45773() == null) return false;

        if (mc.field_1724.method_45773() instanceof class_1309 entity && entity.method_5799()) {
            vehicleInWaterLastTick = mc.field_1687.method_8510();
        }

        boolean isJumping = mc.field_1690.field_1903.method_1434() || mc.field_1724.method_3151() > 0;
        return isJumping && (mc.field_1687.method_8510() - vehicleInWaterLastTick >= 10);
    }

    public static boolean isEnabled() {
        return Config.Client.IMPROVED_MOUNT_GUI.get();
    }
}
