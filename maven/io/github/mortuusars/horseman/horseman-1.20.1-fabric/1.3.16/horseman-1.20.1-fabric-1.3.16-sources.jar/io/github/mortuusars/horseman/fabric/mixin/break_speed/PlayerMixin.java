package io.github.mortuusars.horseman.fabric.mixin.break_speed;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

// Disable break speed debuff for not being grounded (while mounted)
@Mixin(value = class_1657.class, priority = 950)
public abstract class PlayerMixin extends class_1309 {
    protected PlayerMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyReturnValue(method = "getDestroySpeed", at = @At("RETURN"))
    private float getDestroySpeed(float original) {
        if (!this.method_24828() && this.method_5668() instanceof class_1496 && Config.Common.MOUNTED_BLOCK_BREAK_SPEED_MODIFIER.get() != 0)
            return original * Config.Common.MOUNTED_BLOCK_BREAK_SPEED_MODIFIER.get().floatValue();
        return original;
    }
}