package io.github.mortuusars.horseman.mixin.hitching;

import io.github.mortuusars.horseman.horse.HitchableHorse;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1804;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2354;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2354.class)
public class FenceBlockMixin {
    @Inject(method = "use", at = @At("HEAD"), cancellable = true)
    private void onUse(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand,
                       class_3965 hit, CallbackInfoReturnable<class_1269> cir) {
        if (player.method_5668() instanceof class_1496 horse
                && horse instanceof HitchableHorse hitchableHorse
                && HitchableHorse.canHitch(hitchableHorse)) {
            horse.method_5954(player, true);
            HitchableHorse.setHitched(hitchableHorse, true);
            if (!level.field_9236) {
                class_1269 result = class_1804.method_7994(player, level, pos);
                HitchableHorse.syncHorseDataToTrackingClients(hitchableHorse);
                cir.setReturnValue(result);
            } else {
                cir.setReturnValue(class_1269.field_5812);
            }
        }
    }
}
