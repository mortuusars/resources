package io.github.mortuusars.horseman.network.fabric;

import io.github.mortuusars.horseman.network.PacketDirection;
import io.github.mortuusars.horseman.network.packet.IPacket;
import io.github.mortuusars.horseman.network.packet.client.SyncHorseDataS2CP;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2540;
import net.minecraft.class_310;
import net.minecraft.class_634;
import java.util.function.Function;

public class ClientPackets {
    public static void registerS2CPackets() {
        ClientPlayNetworking.registerGlobalReceiver(SyncHorseDataS2CP.ID, new ClientHandler(SyncHorseDataS2CP::fromBuffer));
    }

    public static void sendToServer(IPacket packet) {
        ClientPlayNetworking.send(packet.getId(), packet.toBuffer(PacketByteBufs.create()));
    }

    private record ClientHandler(Function<class_2540, IPacket> decodeFunction) implements ClientPlayNetworking.PlayChannelHandler {
        @Override
        public void receive(class_310 client, class_634 handler, class_2540 buf, PacketSender responseSender) {
            IPacket packet = decodeFunction.apply(buf);
            packet.handle(PacketDirection.TO_CLIENT, null);
        }
    }
}
