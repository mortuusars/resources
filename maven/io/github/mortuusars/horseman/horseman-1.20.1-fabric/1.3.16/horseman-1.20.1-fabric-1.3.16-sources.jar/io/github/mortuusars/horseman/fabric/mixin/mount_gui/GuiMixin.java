package io.github.mortuusars.horseman.fabric.mixin.mount_gui;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.mortuusars.horseman.PlatformHelper;
import io.github.mortuusars.horseman.client.ImprovedMountGui;
import net.minecraft.class_1309;
import net.minecraft.class_1316;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_329.class)
public abstract class GuiMixin {
    @Shadow
    protected abstract int getVisibleVehicleHeartRows(int vehicleHealth);

    @Shadow
    @Nullable
    protected abstract class_1309 getPlayerVehicleWithHealth();

    @Shadow
    protected abstract int getVehicleMaxHearts(class_1309 vehicle);

    @Shadow
    public abstract void renderExperienceBar(class_332 guiGraphics, int x);

    @Shadow
    private int screenWidth;
    @Shadow
    private int screenHeight;

    @Shadow
    public abstract class_327 getFont();

    @WrapOperation(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;jumpableVehicle()Lnet/minecraft/world/entity/PlayerRideableJumping;"))
    private class_1316 renderHotbarAndDecorations_jumpableVehicle(class_746 instance, Operation<class_1316> original) {
        @Nullable class_1316 vehicle = original.call(instance);
        if (!ImprovedMountGui.isEnabled()) return vehicle;
        class_310 mc = class_310.method_1551();
        if (mc.field_1761 == null || !mc.field_1761.method_2913()) return vehicle;
        if (!ImprovedMountGui.shouldRenderJumpBar()) return null; // Prevent jump bar from rendering.
        return vehicle;
    }

    @WrapOperation(method = "renderPlayerHealth", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;getVehicleMaxHearts(Lnet/minecraft/world/entity/LivingEntity;)I"))
    private int renderPlayerHealth_getVehicleMaxHearts(class_329 instance, class_1309 entity, Operation<Integer> original) {
        if (!ImprovedMountGui.isEnabled()) return original.call(instance, entity);
        return 0; // Forces hunger bar rendering, because it is not rendered when vehicle hearts is not 0.
    }

    @WrapOperation(method = "renderPlayerHealth", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;getVisibleVehicleHeartRows(I)I"))
    private int renderPlayerHealth_getVisibleVehicleHeartRows(class_329 instance, int vehicleHealth, Operation<Integer> original) {
        if (!ImprovedMountGui.isEnabled()) return original.call(instance, vehicleHealth);
        // 'hearts' will be 0 here, due to it being set in 'renderPlayerHealth_getVehicleMaxHearts'.
        class_1309 livingEntity = getPlayerVehicleWithHealth();
        int vehicleHearts = getVehicleMaxHearts(livingEntity);
        return getVisibleVehicleHeartRows(vehicleHearts);
    }

    @ModifyVariable(method = "renderVehicleHealth", at = @At(value = "STORE"), ordinal = 2)
    private int renderVehicleHealth(int y) {
        if (ImprovedMountGui.isEnabled()
                && class_310.method_1551().field_1761 != null
                && class_310.method_1551().field_1761.method_2908()) {
            y -= 10; // Make room for hunger bar
        }
        return y;
    }

    @Inject(method = "renderJumpMeter", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiling/ProfilerFiller;pop()V"))
    private void renderJumpMeter(class_1316 rideable, class_332 guiGraphics, int x, CallbackInfo ci) {
        if (!ImprovedMountGui.isEnabled()) return;

        // This method renders xp level number when jumping

        class_636 gameMode = class_310.method_1551().field_1761;
        if (gameMode != null && gameMode.method_2913() && class_310.method_1551().field_1724 != null) {
            if (PlatformHelper.isModLoaded("immediatelyfast")) {
                // Render manually with ImmediatelyFast, because calling `renderExperienceBar` causes issues with it.
                if (class_310.method_1551().field_1724.field_7520 > 0) {
                    class_310.method_1551().method_16011().method_15396("expLevel");
                    String string = "" + class_310.method_1551().field_1724.field_7520;
                    int k = (screenWidth - getFont().method_1727(string)) / 2;
                    int l = screenHeight - 31 - 4;
                    guiGraphics.method_51433(this.getFont(), string, k + 1, l, 0, false);
                    guiGraphics.method_51433(this.getFont(), string, k - 1, l, 0, false);
                    guiGraphics.method_51433(this.getFont(), string, k, l + 1, 0, false);
                    guiGraphics.method_51433(this.getFont(), string, k, l - 1, 0, false);
                    guiGraphics.method_51433(this.getFont(), string, k, l, 8453920, false);
                }
            } else {
                renderExperienceBar(guiGraphics, x);
            }
        }
    }

    @WrapOperation(method = "renderExperienceBar", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;getXpNeededForNextLevel()I"))
    private int renderExperienceBar(class_746 instance, Operation<Integer> original) {
        if (ImprovedMountGui.isEnabled()
                && class_310.method_1551().field_1761 != null && class_310.method_1551().field_1761.method_2913()
                && ImprovedMountGui.shouldRenderJumpBar()) {
            return -1; // Prevent bar from rendering, but keep level number.
        }

        return original.call(instance);
    }
}
