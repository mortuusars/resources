package io.github.mortuusars.horseman.network.packet.client;

import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.network.PacketDirection;
import io.github.mortuusars.horseman.network.handler.ClientPacketsHandler;
import io.github.mortuusars.horseman.network.packet.IPacket;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public record SyncHorseDataS2CP(int entityId, List<class_1799> inventory, class_1799 leadStack, boolean isHitched) implements IPacket {
    public static final class_2960 ID = Horseman.resource("sync_horse_data");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10804(entityId);
        buffer.method_10804(inventory.size());
        for (class_1799 itemStack : inventory) {
            buffer.method_10793(itemStack);
        }
        buffer.method_10793(leadStack);
        buffer.writeBoolean(isHitched);
        return buffer;
    }

    public static SyncHorseDataS2CP fromBuffer(class_2540 buffer) {
        int entityId = buffer.method_10816();
        int inventorySize = buffer.method_10816();
        List<class_1799> inventory = new ArrayList<>();
        for (int i = 0; i < inventorySize; i++) {
            inventory.add(buffer.method_10819());
        }
        return new SyncHorseDataS2CP(entityId, inventory, buffer.method_10819(), buffer.readBoolean());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        ClientPacketsHandler.syncHorseData(this);
        return true;
    }
}
