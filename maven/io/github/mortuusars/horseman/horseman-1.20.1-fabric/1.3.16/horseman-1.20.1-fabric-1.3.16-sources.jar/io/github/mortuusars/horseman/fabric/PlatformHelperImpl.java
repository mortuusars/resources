package io.github.mortuusars.horseman.fabric;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1820;

public class PlatformHelperImpl {
    public static boolean canShear(class_1799 stack) {
        return stack.method_7909() instanceof class_1820;
    }

    public static boolean canStrip(class_1799 stack) {
        return stack.method_7909() instanceof class_1743;
    }

    public static boolean isModLoaded(String modId) {
        return FabricLoader.getInstance().isModLoaded(modId);
    }

    /**
     * This method is here because on forge checking if mod is loaded at mixin apply time is different (LoadingModList vs ModList)
     * But on fabric we can use the same code.
     */
    public static boolean isModLoading(String modId) {
        return isModLoaded(modId);
    }
}
