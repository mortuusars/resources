package io.github.mortuusars.horseman.horse;

import com.google.common.base.Preconditions;
import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.Horseman;
import io.github.mortuusars.horseman.network.Packets;
import io.github.mortuusars.horseman.network.packet.client.SyncHorseDataS2CP;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1277;
import net.minecraft.class_1492;
import net.minecraft.class_1496;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3222;

public interface HitchableHorse {
    class_1799 horseman$getLead();
    void horseman$setLead(class_1799 stack);
    boolean horseman$isHitched();
    void horseman$setHitched(boolean hitched);

    default boolean horseman$hasLead() {
        return !horseman$getLead().method_7960();
    }

    default class_1496 horseman$asHorse() {
        return ((class_1496) this);
    }

    // --

    static boolean isEnabled() {
        return Config.Common.HORSE_HITCH.get();
    }

    static boolean requiresLead() {
        return Config.Common.HORSE_HITCH_REQUIRES_LEAD.get();
    }

    /**
     * Basically every horse that is saddleable supports hitching. In vanilla the only exception is LLama.
     * Technically we can also use horse#isSaddleable here, but that would hard-limit it.
     * Maybe some mod adds non-saddleable horse that would benefit from hitching.
     */
    static boolean isHitchable(HitchableHorse horse) {
        return !horse.horseman$asHorse().method_5864().method_20210(Horseman.Tags.EntityTypes.CANNOT_BE_HITCHED);
    }

    // --

    static boolean canHitch(HitchableHorse horse) {
        return isEnabled() && isHitchable(horse) && !horse.horseman$asHorse().method_5934() && (!requiresLead() || hasLead(horse));
    }

    static boolean isHitched(HitchableHorse horse) {
        return horse.horseman$isHitched();
    }

    static void setHitched(HitchableHorse horse, boolean hitched) {
        horse.horseman$setHitched(hitched);
    }

    // --

    static class_1799 getLead(HitchableHorse horse) {
        return horse.horseman$getLead();
    }

    static void setLead(HitchableHorse horse, class_1799 leadStack) {
        horse.horseman$setLead(leadStack);
    }

    static boolean hasLead(HitchableHorse horse) {
        return horse.horseman$hasLead();
    }

    // -- Lead in inventory

    static boolean shouldHaveLeadSlot(HitchableHorse horse) {
        return isEnabled() && requiresLead() && Config.Common.HORSE_HITCH_INVENTORY_SLOT.get() && isHitchable(horse);
    }

    static int getLeadSlotIndex(HitchableHorse horse) {
        Preconditions.checkState(shouldHaveLeadSlot(horse),
                "Tried to get lead slot index when the hitching is disabled or horse cannot be hitched.");

        if (horse instanceof class_1492 chestedHorse && chestedHorse.method_6703()) {
            int columns = ((class_1492) horse).method_6702();
            return 2 + columns * 3;
        } else {
            return 2;
        }
    }

    static int getPackagedLeadSlotIndex(HitchableHorse horse){
        Preconditions.checkState(shouldHaveLeadSlot(horse),
                "Tried to get lead slot index when the hitching is disabled or horse cannot be hitched.");

        return horse.horseman$asHorse().field_6962.method_5439() - 1;
    }

    static boolean mayPlaceInLeadSlot(HitchableHorse horse, class_1799 stack) {
        return stack.method_31574(class_1802.field_8719);
    }

    static boolean isLeadSlotActive(HitchableHorse horse) {
        return !isHitched(horse);
    }

    // --

    static void syncHorseDataToClient(HitchableHorse horse, class_3222 player) {
        Packets.sendToClient(new SyncHorseDataS2CP(horse.horseman$asHorse().method_5628(),
                getHorseInventory(horse), getLead(horse), isHitched(horse)), player);
    }

    static void syncHorseDataToTrackingClients(HitchableHorse horse) {
        Packets.sendToPlayersTrackingEntity(horse.horseman$asHorse(), new SyncHorseDataS2CP(
                horse.horseman$asHorse().method_5628(), getHorseInventory(horse), getLead(horse), isHitched(horse)));
    }

    private static List<class_1799> getHorseInventory(HitchableHorse horse) {
        class_1277 inventory = horse.horseman$asHorse().field_6962;
        List<class_1799> items = new ArrayList<>();
        for (int i = 0; i < inventory.method_5439(); i++) {
            items.add(inventory.method_5438(i));
        }
        return items;
    }
}
