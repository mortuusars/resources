package io.github.mortuusars.horseman.mixin.rotate_horse_when_mounting;

import io.github.mortuusars.horseman.Config;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1496.class)
public abstract class AbstractHorseMixin extends class_1429 {
    protected AbstractHorseMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "doPlayerRide", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;setYRot(F)V"), cancellable = true)
    private void onDoPlayerRide(class_1657 player, CallbackInfo ci) {
        if (Config.Common.ROTATE_HORSE_INSTEAD_OF_PLAYER.get()) {
            method_36456(player.method_36454());
            method_36457(player.method_36455());
            player.method_5804(this);
            ci.cancel();
        }
    }
}
