package io.github.mortuusars.horseman.fabric;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1820;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;

public class PlatformHelperImpl {
    public static boolean canShear(class_1799 stack) {
        return stack.method_7909() instanceof class_1820;
    }

    public static boolean canStrip(class_1799 stack) {
        return stack.method_7909() instanceof class_1743;
    }

    public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_2540> extraDataWriter) {
        LoadingWeirdness.openMenu(serverPlayer, menuProvider, extraDataWriter);
    }

    public static boolean isModLoaded(String modId) {
        return FabricLoader.getInstance().isModLoaded(modId);
    }

    /**
     * This method is here because on forge checking if mod is loaded at mixin apply time is different (LoadingModList vs ModList)
     * But on fabric we can use the same code.
     */
    public static boolean isModLoading(String modId) {
        return isModLoaded(modId);
    }

    /**
     * This is separated to not crash on game loading, possibly because class getting initialized fully and screen factory is loaded too early.
     * I may be stupid for not knowing this ahead of time, but this is f*ing bonkers.
     * At least it's not taken whole day of head bashing to figure it out.
     */
    public static class LoadingWeirdness {
        public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_2540> extraDataWriter) {
            ExtendedScreenHandlerFactory extendedScreenHandlerFactory = new ExtendedScreenHandlerFactory() {
                @Nullable
                @Override
                public class_1703 createMenu(int i, @NotNull class_1661 inventory, @NotNull class_1657 player) {
                    return menuProvider.createMenu(i, inventory, player);
                }

                @Override
                public @NotNull class_2561 getDisplayName() {
                    return menuProvider.method_5476();
                }

                @Override
                public void writeScreenOpeningData(class_3222 player, class_2540 buffer) {
                    extraDataWriter.accept(buffer);
                }
            };

            serverPlayer.method_17355(extendedScreenHandlerFactory);
        }
    }
}
