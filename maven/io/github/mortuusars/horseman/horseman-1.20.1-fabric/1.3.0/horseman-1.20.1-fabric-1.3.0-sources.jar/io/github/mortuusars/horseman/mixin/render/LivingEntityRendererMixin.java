package io.github.mortuusars.horseman.mixin.render;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalDoubleRef;
import com.llamalad7.mixinextras.sugar.ref.LocalIntRef;
import io.github.mortuusars.horseman.client.HorseRenderUtils;
import net.minecraft.class_1309;
import net.minecraft.class_1472;
import net.minecraft.class_1496;
import net.minecraft.class_1767;
import net.minecraft.class_1921;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_897;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_922.class, priority = 950)
public abstract class LivingEntityRendererMixin<T extends class_1309, M extends class_583<T>> extends class_897<T> {
    protected LivingEntityRendererMixin(class_5617.class_5618 context) {
        super(context);
    }

    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At("HEAD"))
    void setAlpha(T entity, float entityYaw, float partialTicks, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci, @Share("alpha") LocalDoubleRef alpha) {
        if (entity instanceof class_1496) {
            alpha.set(HorseRenderUtils.getAlpha(entity));
        }
    }

    @Redirect(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/EntityModel;renderToBuffer(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;IIFFFF)V"))
    private void onRender(class_583<?> instance, class_4587 poseStack, class_4588 vertexConsumer,
                          int packedLight, int packedOverlay, float r, float g, float b, float a, @Local(argsOnly = true) T entity, @Share("alpha") LocalDoubleRef alpha) {
        if (entity instanceof class_1496) {
            if (HorseRenderUtils.isJeb(entity)) {
                int index = entity.field_6012 / 25 + entity.method_5628();
                int dyesCount = class_1767.values().length;
                int currentIndex = index % dyesCount;
                int nextIndex = (index + 1) % dyesCount;
                float transition = ((float) (entity.field_6012 % 25) + class_310.method_1551().method_1534()) / 25.0F;
                float[] currentColors = class_1472.method_6634(class_1767.method_7791(currentIndex));
                float[] nextColors = class_1472.method_6634(class_1767.method_7791(nextIndex));

                r = currentColors[0] * (1.0F - transition) + nextColors[0] * transition;
                g = currentColors[1] * (1.0F - transition) + nextColors[1] * transition;
                b = currentColors[2] * (1.0F - transition) + nextColors[2] * transition;

                // increase brightness because the horse texture is a bit dark
                r = class_3532.method_15363(r * 2, 0, 1);
                g = class_3532.method_15363(g * 2, 0, 1);
                b = class_3532.method_15363(b * 2, 0, 1);
            }

            a = (float) class_3532.method_15350(a * alpha.get(), 0.0, 1.0);
        }

        instance.method_2828(poseStack, vertexConsumer, packedLight, packedOverlay, r, g, b, a);
    }

    @Inject(method = "getRenderType", at = @At("HEAD"), cancellable = true)
    private void getRenderType(T entity, boolean bodyVisible, boolean translucent, boolean glowing,
                               CallbackInfoReturnable<class_1921> cir, @Share("alpha") LocalDoubleRef alphaRef) {
        if (entity instanceof class_1496 && alphaRef.get() != 1.0) {
            cir.setReturnValue(class_1921.method_23580(method_3931(entity)));
        }
    }
}