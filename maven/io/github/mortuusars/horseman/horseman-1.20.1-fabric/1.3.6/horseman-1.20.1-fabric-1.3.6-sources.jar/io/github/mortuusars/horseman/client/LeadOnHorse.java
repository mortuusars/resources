package io.github.mortuusars.horseman.client;

import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.data.HitchableHorse;
import net.minecraft.class_1496;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class LeadOnHorse {
    public static void renderInventory(class_332 guiGraphics, int mouseX, int mouseY, float partialTick,
                                       int leftPos, int topPos, class_1496 horse) {
        if (Config.Client.HORSE_HITCH_RENDER_LEAD_WITHOUT_SLOT.get() && horse instanceof HitchableHorse hitchableHorse) {
            guiGraphics.method_51448().method_22903();
            guiGraphics.method_51427(hitchableHorse.horseman$getLead(), leftPos + 62, topPos + 18);
            guiGraphics.method_51448().method_22909();

            if (mouseX >= leftPos + 62 && mouseX < leftPos + 62 + 16 && mouseY >= topPos + 18 && mouseY < topPos + 18 + 16) {
                guiGraphics.method_51438(class_310.method_1551().field_1772, class_2561.method_43470("Has Hitching Lead"), mouseX, mouseY);
            }
        }
    }
}
