package io.github.mortuusars.horseman.mixin.hitching;

import io.github.mortuusars.horseman.data.HitchableHorse;
import net.minecraft.class_1263;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1724;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3917;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1724.class)
public abstract class HorseInventoryMenuMixin extends class_1703 {
    @Shadow @Final private class_1263 horseContainer;
    @Shadow @Final private class_1496 horse;
    @Unique
    private boolean horseman$leadSlotAdded = false;

    protected HorseInventoryMenuMixin(@Nullable class_3917<?> menuType, int containerId) {
        super(menuType, containerId);
    }

    /**
     * We cannot mixin with "INVOKE" into constructors on forge apparently, so adding Lead slot here is likely the only option.
     * It should come before chest slots for Shift+Clicking to work properly.
     * Unfortunately we cannot change (or at least not easily) indexes of chest slots,
     * so Lead slot index will be after chest slots (for inventory, it's still added before then in order)
     */
    @Inject(method = "hasChest", at = @At(value = "HEAD"))
    private void onHasChest(class_1496 horse, CallbackInfoReturnable<Boolean> cir) {
        if (horseman$leadSlotAdded) return;
        if (!(horse instanceof HitchableHorse hitchableHorse)) return;
        if (!HitchableHorse.shouldHaveLeadSlot(hitchableHorse)) return;

        int leadSlotIndex = HitchableHorse.getLeadSlotIndex(hitchableHorse);
        method_7621(new class_1735(this.horseContainer, leadSlotIndex, 8, 54) {
            @Override
            public boolean method_7680(class_1799 stack) {
                return HitchableHorse.mayPlaceInLeadSlot(hitchableHorse, stack);
            }

            @Override
            public boolean method_7674(class_1657 player) {
                class_1799 stack = this.method_7677();
                return !stack.method_31574(class_1802.field_8719) || !HitchableHorse.isHitched(hitchableHorse);
            }

            @Override
            public int method_7675() {
                return 1;
            }

            @Override
            public boolean method_7682() {
                // Making it active on client to keep rendering the slot.
                return horse.method_37908().field_9236 || HitchableHorse.isLeadSlotActive(hitchableHorse);
            }
        });
        horseman$leadSlotAdded = true;
    }

    /**
     * When Lead stack in player inventory is shift-clicked - splits only one item from clicked stack and inserts into Lead slot.
     * On Forge it's mostly a QOL thing (it will work without it, but not stop moving the rest of a stack in other slots),
     * but on Fabric without this mixin it's possible to insert 64 items into a slot with stack size of 1.
     * Fabric does not check slot limits when inserting.
     */
    @Inject(method = "quickMoveStack", at = @At(value = "HEAD"), cancellable = true)
    private void onQuickMoveStack(class_1657 player, int index, CallbackInfoReturnable<class_1799> cir) {
        if (!(this.horse instanceof HitchableHorse hitchableHorse)) return;
        if (!HitchableHorse.shouldHaveLeadSlot(hitchableHorse)) return;
        if (index < this.horseContainer.method_5439()) return;

        class_1735 slot = this.field_7761.get(index);
        if (!slot.method_7681()) {
            return;
        }

        class_1799 clickedStack = slot.method_7677();
        if (!clickedStack.method_31574(class_1802.field_8719)) {
            return;
        }

        class_1799 clickedStackCopy = clickedStack.method_7972();

        class_1735 leadSlot = method_7611(2);
        if (!leadSlot.method_7680(clickedStack)) {
            return;
        }

        class_1799 movedStack = clickedStack.method_46651(1);

        if (!leadSlot.method_7677().method_7960()) {
            if (!method_7616(clickedStack, 3, this.horseContainer.method_5439(), false)) {
                cir.setReturnValue(class_1799.field_8037);
                return;
            }

            if (clickedStack.method_7960()) {
                slot.method_48931(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            if (clickedStack.method_7947() == clickedStackCopy.method_7947()) {
                cir.setReturnValue(class_1799.field_8037);
                return;
            }

            slot.method_7667(player, clickedStack);

            cir.setReturnValue(class_1799.field_8037);
            return;
        }

        clickedStack.method_7934(1);
        this.field_7761.get(2).method_48931(movedStack);

        if (clickedStack.method_7960()) {
            slot.method_48931(class_1799.field_8037);
        } else {
            slot.method_7668();
        }

        if (clickedStack.method_7947() == clickedStackCopy.method_7947()) {
            cir.setReturnValue(class_1799.field_8037);
            return;
        }

        slot.method_7667(player, clickedStack);

        cir.setReturnValue(class_1799.field_8037);
    }
}
