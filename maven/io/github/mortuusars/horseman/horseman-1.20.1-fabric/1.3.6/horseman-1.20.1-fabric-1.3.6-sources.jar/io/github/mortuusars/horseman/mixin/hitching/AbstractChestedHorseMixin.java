package io.github.mortuusars.horseman.mixin.hitching;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.horseman.data.HitchableHorse;
import net.minecraft.class_1299;
import net.minecraft.class_1492;
import net.minecraft.class_1496;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1492.class)
public abstract class AbstractChestedHorseMixin extends class_1496 implements HitchableHorse {
    @Shadow public abstract boolean hasChest();

    protected AbstractChestedHorseMixin(class_1299<? extends class_1496> entityType, class_1937 level) {
        super(entityType, level);
    }

    /**
     * +1 for Lead slot.
     * {@link AbstractHorseMixin} also has this change, so we should only add +1 if it's not calling the super method.
     */
    @ModifyReturnValue(method = "getInventorySize", at = @At("RETURN"))
    private int onGetInventorySize(int original) {
        return HitchableHorse.shouldHaveLeadSlot(this) && hasChest() ? original + 1 : original;
    }
}