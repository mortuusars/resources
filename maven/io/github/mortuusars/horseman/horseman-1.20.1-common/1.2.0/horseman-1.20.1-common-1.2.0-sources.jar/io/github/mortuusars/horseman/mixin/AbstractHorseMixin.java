package io.github.mortuusars.horseman.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.data.HitchableHorse;
import net.minecraft.class_1277;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1492;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_241;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1496.class)
public abstract class AbstractHorseMixin extends class_1429 implements HitchableHorse {
    @Shadow protected abstract int getInventorySize();
    @Shadow public class_1277 inventory;

    @Unique
    protected boolean horseman$isHitched = false;
    @Unique
    protected class_1799 horseman$builtInLead = class_1799.field_8037;

    protected AbstractHorseMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Override
    public class_1799 horseman$getLead() {
        if (!HitchableHorse.isEnabled()) {
            return class_1799.field_8037;
        }

        if (HitchableHorse.shouldHaveLeadSlot(this)) {
            return inventory.method_5438(HitchableHorse.getLeadSlotIndex(this));
        } else {
            return horseman$builtInLead;
        }
    }

    @Override
    public void horseman$setLead(class_1799 stack) {
        if (HitchableHorse.shouldHaveLeadSlot(this)) {
            inventory.method_5447(HitchableHorse.getLeadSlotIndex(this), stack);
        } else {
            horseman$builtInLead = stack;
        }
    }

    @Override
    public boolean horseman$isHitched() {
        return method_5934() && horseman$isHitched;
    }

    @Override
    public void horseman$setHitched(boolean hitched) {
        horseman$isHitched = hitched;
    }

    // --

    /**
     * Add +1 for the lead slot. {@link AbstractChestedHorseMixin} should also be changed as it overrides this method.
     */
    @ModifyReturnValue(method = "getInventorySize", at = @At("RETURN"))
    private int onGetInventorySize(int original) {
        return HitchableHorse.shouldHaveLeadSlot(this) ? original + 1 : original;
    }

    /**
     * All hitching stuff is hacky, but this is beyond stupid and just waiting to brake something.
     * This is done to move the Lead to a correct slot after chest has been put on a horse.
     * Lead slot is always the last one, and when placing a chest it will change from 2 to 17.
     * And if we don't move the item, it will appear in first chest slot.
     */
    @Inject(method = "createInventory", at = @At(value = "HEAD"))
    private void onCreateInventory(CallbackInfo ci) {
        class_1496 horse = (class_1496)(Object)this;
        if (horse instanceof class_1492 chestedHorse
                && chestedHorse.method_6703()
                && getInventorySize() > inventory.method_5439()
                && HitchableHorse.shouldHaveLeadSlot(this)) {
            @Nullable class_1277 prevInventory = inventory;
            inventory = new class_1277(getInventorySize());
            if (prevInventory != null) {
                prevInventory.method_5488(horse);
                int slots = Math.min(prevInventory.method_5439(), this.inventory.method_5439());
                for (int i = 0; i < slots; ++i) {
                    class_1799 itemStack = prevInventory.method_5438(i);
                    if (itemStack.method_7960()) continue;
                    this.inventory.method_5447(i, itemStack.method_7972());
                }

                // Swap lead that's now in the wrong slot to last inventory slot.
                if (inventory.method_5438(2).method_31574(class_1802.field_8719)) {
                    class_1799 lastItem = inventory.method_5438(inventory.method_5439() - 1);
                    inventory.method_5447(inventory.method_5439() - 1, inventory.method_5438(2));
                    inventory.method_5447(2, lastItem);
                }
            }
        }
    }

    // Drops the Lead if it's not in inventory (slot is disabled)
    @Inject(method = "dropEquipment", at = @At(value = "RETURN"))
    private void onDropEquipment(CallbackInfo ci) {
        if (HitchableHorse.isEnabled() && HitchableHorse.requiresLead()
                && !HitchableHorse.shouldHaveLeadSlot(this)
                && HitchableHorse.hasLead(this)) {
            method_5775(HitchableHorse.getLead(this));
            HitchableHorse.setLead(this, class_1799.field_8037);
        }
    }

    // --

    @Inject(method = "doPlayerRide", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;setYRot(F)V"), cancellable = true)
    private void onDoPlayerRide(class_1657 player, CallbackInfo ci) {
        if (Config.Common.ROTATE_HORSE_INSTEAD_OF_PLAYER.get()) {
            this.method_36456(player.method_36454());
            this.method_36457(player.method_36455());
            player.method_5804(this);
            ci.cancel();
        }
    }

    @Inject(method = "getRiddenRotation", at = @At(value = "HEAD"), cancellable = true)
    private void onGetRiddenRotation(class_1309 entity, CallbackInfoReturnable<class_241> cir) {
        class_1496 horse = (class_1496)(Object)this;
        if (!Config.Common.HORSE_FREE_CAMERA.get() || !(entity instanceof class_1657 player) || player.field_6212 != 0 || player.field_6250 != 0) {
            return;
        }

        float threshold = Config.Common.HORSE_FREE_CAMERA_ANGLE_THRESHOLD.get().floatValue();

        float rotationDifference = (player.method_36454() - horse.method_36454() + 540) % 360 - 180;

        if (Math.abs(rotationDifference) > threshold) {
            // Rotate the horse following player's rotation, with offset
            cir.setReturnValue(new class_241(player.method_36455() * 0.5f, player.method_36454() - Math.signum(rotationDifference) * threshold));
        }
        else {
            cir.setReturnValue(new class_241(player.method_36455() * 0.5f, horse.method_36454()));
        }
    }

    // --

    @Inject(method = "addAdditionalSaveData", at = @At("RETURN"))
    protected void onAddAdditionalSaveData(class_2487 tag, CallbackInfo ci) {
        class_1799 leadStack = horseman$getLead();
        if (!leadStack.method_7960()) {
            tag.method_10566("HorsemanLeadItem", leadStack.method_7953(new class_2487()));
        }

        if (horseman$isHitched()) {
            tag.method_10556("HorsemanHitched", true);
        }
    }

    @Inject(method = "readAdditionalSaveData", at = @At("RETURN"))
    protected void onReadAdditionalSaveData(class_2487 tag, CallbackInfo ci) {
        if (tag.method_10573("HorsemanLeadItem", class_2520.field_33260)) {
            class_1799 leadStack = class_1799.method_7915(tag.method_10562("HorsemanLeadItem"));

            // Backwards compat with <=1.1.4
            if (leadStack.method_7969() != null && leadStack.method_7969().method_10545("PreventLeadDrop")) {
                HitchableHorse.setHitched(this, true);
                leadStack.method_7969().method_10551("PreventLeadDrop");
                if (leadStack.method_7969().method_33133()) {
                    leadStack.method_7980(null);
                }
            }

            horseman$setLead(leadStack);
        }

        horseman$isHitched = tag.method_10577("HorsemanHitched");
    }
}
