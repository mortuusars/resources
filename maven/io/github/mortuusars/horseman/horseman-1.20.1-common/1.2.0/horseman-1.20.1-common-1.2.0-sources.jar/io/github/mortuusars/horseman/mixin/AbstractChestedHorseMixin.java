package io.github.mortuusars.horseman.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.horseman.Config;
import io.github.mortuusars.horseman.PlatformHelper;
import io.github.mortuusars.horseman.data.HitchableHorse;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1277;
import net.minecraft.class_1299;
import net.minecraft.class_1492;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1492.class)
public abstract class AbstractChestedHorseMixin extends class_1496 implements HitchableHorse {
    @Shadow public abstract boolean hasChest();

    @Shadow public abstract int getInventoryColumns();

    @Shadow public abstract void setChest(boolean chested);

    protected AbstractChestedHorseMixin(class_1299<? extends class_1496> entityType, class_1937 level) {
        super(entityType, level);
    }

    /**
     * +1 for Lead slot.
     * {@link AbstractHorseMixin} also has this change, so we should only add +1 if it's not calling the super method.
     */
    @ModifyReturnValue(method = "getInventorySize", at = @At("RETURN"))
    private int onGetInventorySize(int original) {
        return HitchableHorse.shouldHaveLeadSlot(this) && hasChest() ? original + 1 : original;
    }

    @Inject(method = "mobInteract", at = @At("HEAD"), cancellable = true)
    private void onMobInteract(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        if (!Config.Common.HORSE_SHEARS_REMOVE_CHEST.get() || method_5782() || method_6109()
                || !method_6727() || !hasChest() || player.method_21823()) {
            return;
        }

        class_1799 itemInHand = player.method_5998(hand);
        if (PlatformHelper.canShear(itemInHand)) {
            if (method_37908().field_9236) {
                cir.setReturnValue(class_1269.field_5812);
                return;
            }

            int chestInventorySize = 3 * getInventoryColumns();
            class_1277 dropContainer = new class_1277(chestInventorySize);

            for (int i = 0; i < dropContainer.method_5439(); i++) {
                class_1799 stack = field_6962.method_5438(2 + i);
                dropContainer.method_5447(i, stack);
            }

            class_1264.method_5452(method_37908(), this, dropContainer);
            class_1264.method_5449(method_37908(), this.method_23317(), this.method_23318(), this.method_23321(), new class_1799(class_1802.field_8106));

            // Move lead to a correct slot (always last). Same as in AbstractHorseMixin#createInventory but in reverse.
            if (HitchableHorse.shouldHaveLeadSlot(this)) {
                int leadSlot = HitchableHorse.getLeadSlotIndex(this);
                class_1799 leadStack = field_6962.method_5438(leadSlot);
                if (!leadStack.method_7960()) {
                    field_6962.method_5447(2, leadStack);
                    field_6962.method_5447(leadSlot, class_1799.field_8037);
                }
            }

            method_5783(class_3417.field_14975, 1.0f, (this.field_5974.method_43057() - this.field_5974.method_43057()) * 0.2f + 1.0f);
            setChest(false);
            method_6721();

            cir.setReturnValue(class_1269.field_5812);
        }
    }
}
