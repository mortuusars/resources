package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.exposure.client.sound.UniqueSoundManager;
import org.jetbrains.annotations.NotNull;

public record UniqueSoundStopS2CP(String id, class_3414 sound) implements Packet {
    public static final class_2960 ID = Exposure.resource("unique_sound_stop");
    public static final class_8710.class_9154<UniqueSoundStopS2CP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_9129, UniqueSoundStopS2CP> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48554, UniqueSoundStopS2CP::id,
            class_3414.field_48278, UniqueSoundStopS2CP::sound,
            UniqueSoundStopS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        UniqueSoundManager.stop(id, sound);
        return true;
    }
}
