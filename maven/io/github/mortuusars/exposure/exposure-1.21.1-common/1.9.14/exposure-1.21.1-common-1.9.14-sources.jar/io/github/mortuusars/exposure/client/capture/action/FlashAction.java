package io.github.mortuusars.exposure.client.capture.action;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.block.FlashBlock;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_5819;

public class FlashAction implements CaptureAction {
    private final class_1297 cameraHolder;
    private long initializedAt;

    public FlashAction(class_1297 cameraHolder) {
        this.cameraHolder = cameraHolder;
    }

    @Override
    public int requiredDelayTicks() {
        return Config.Client.FLASH_CAPTURE_DELAY_TICKS.get(); // This is important. Without a delay flash effect might not apply in time.
    }

    @Override
    public void initialize() {
        initializedAt = cameraHolder.method_37908().method_8510();
    }

    @Override
    public void beforeCapture() {
        long ticksDelay = cameraHolder.method_37908().method_8510() - initializedAt;
        if (ticksDelay > FlashBlock.LIFETIME_TICKS) {
            Exposure.LOGGER.warn("Capturing with delay of '{}' ticks can be too long for a flash to have an effect. " +
                    "The flash might disappear in that time.", ticksDelay);
        }
    }

    @Override
    public void afterCapture() {
        // Spawning particles after capture because they will be visible on a frame otherwise.
        class_1937 level = cameraHolder.method_37908();
        class_243 pos = cameraHolder.method_19538();
        class_243 lookAngle = cameraHolder.method_5720();
        pos = pos.method_1031(0, 1.1, 0).method_1019(lookAngle.method_1021(0.8));

        class_5819 r = level.method_8409();
        for (int i = 0; i < 3; i++) {
            level.method_8406(class_2398.field_11207,
                    pos.field_1352 + r.method_43057() - 0.5f,
                    pos.field_1351 + r.method_43057() + 0.15f,
                    pos.field_1350 + r.method_43057() - 0.5f,
                    lookAngle.field_1352 * 0.025f + r.method_43057() * 0.025f,
                    lookAngle.field_1351 * 0.025f + r.method_43057() * 0.025f,
                    lookAngle.field_1350 * 0.025f + r.method_43057() * 0.025f);
        }
    }
}
