package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public class ExportStopS2CP implements Packet {
    public static final ExportStopS2CP INSTANCE = new ExportStopS2CP();

    public static final class_2960 ID = Exposure.resource("export_stop");
    public static final class_9154<ExportStopS2CP> TYPE = new class_9154<>(ID);
    public static final class_9139<class_2540, ExportStopS2CP> STREAM_CODEC = class_9139.method_56431(INSTANCE);

    private ExportStopS2CP() { }

    @Override

    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        ClientPacketsHandler.stopExportTask();
        return true;
    }
}
