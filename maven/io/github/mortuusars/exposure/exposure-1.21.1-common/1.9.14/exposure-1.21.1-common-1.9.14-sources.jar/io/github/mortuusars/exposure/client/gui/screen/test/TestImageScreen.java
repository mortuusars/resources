package io.github.mortuusars.exposure.client.gui.screen.test;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.client.capture.Capture;
import io.github.mortuusars.exposure.client.capture.action.CaptureAction;
import io.github.mortuusars.exposure.client.capture.palettizer.Palettizer;
import io.github.mortuusars.exposure.client.image.Image;
import io.github.mortuusars.exposure.client.image.modifier.ImageEffect;
import io.github.mortuusars.exposure.client.image.renderable.RenderableImage;
import io.github.mortuusars.exposure.client.render.image.RenderCoordinates;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.util.UnixTimestamp;
import io.github.mortuusars.exposure.util.color.Color;
import io.github.mortuusars.exposure.world.camera.film.properties.Levels;
import io.github.mortuusars.exposure.world.camera.component.ShutterSpeed;
import net.minecraft.class_1109;
import net.minecraft.class_124;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7940;
import net.minecraft.client.gui.components.*;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

public class TestImageScreen extends class_437 {
    protected float scale = 1f;

    protected boolean isCapturing;
    @Nullable
    protected Image image;
    @Nullable
    protected RenderableImage renderableImage;

    protected List<class_339> rightPaneWidgets = new ArrayList<>();

    protected Slider sizeSlider;

    protected ShutterSpeedSlider shutterSpeedSlider;
    protected Slider exposureSlider;
    protected Slider contrastSlider;

    protected Slider shadowsSlider;
    protected Slider midtonesSlider;
    protected Slider highlightsSlider;
    protected Slider blackSlider;
    protected Slider whiteSlider;

    protected Slider balanceRedSlider;
    protected Slider balanceGreenSlider;
    protected Slider balanceBlueSlider;

    protected Slider hueSlider;
    protected Slider saturationSlider;
    protected Slider brightnessSlider;

    protected Slider noiseSlider;
    protected class_4286 bw;
    protected class_4286 aged;

    protected float rightPaneScroll = 0f;
    protected long applyEditsAt = -1;

    public TestImageScreen() {
        super(class_2561.method_43473());
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    protected void method_25426() {
        int sliderWidth = 120;
        int sliderHeight = 15;
        int spacingInGroup = 1;
        int spacingBetweenGroups = 4;
        int screenEdgeMargin = 5;
        int labelXOffset = 3;

        int x = field_22789 - sliderWidth - screenEdgeMargin;
        int labelX = x + labelXOffset;
        int y = screenEdgeMargin;

        rightPaneWidgets.clear();

        sizeSlider = new Slider(x, y, sliderWidth, sliderHeight,
                320, 1, 2048, 0, "Size", v -> onChanged());
        method_37063(sizeSlider);
        rightPaneWidgets.add(sizeSlider);
        y += sizeSlider.method_25364();
        y += spacingBetweenGroups;


        class_7940 toneLabel = new class_7940(labelX, y, class_2561.method_43470("Tone"), field_22793);
        method_37060(toneLabel);
        rightPaneWidgets.add(toneLabel);
        y += field_22793.field_2000;

        shutterSpeedSlider = new ShutterSpeedSlider(x, y, sliderWidth, sliderHeight, "Shutter Speed",
                Exposure.Items.CAMERA.get().getAvailableShutterSpeeds(), ShutterSpeed.DEFAULT, v -> onChanged());
        shutterSpeedSlider.setHorizontalGradient(0x44000000, 0x44FFFFFF);
        method_37063(shutterSpeedSlider);
        rightPaneWidgets.add(shutterSpeedSlider);
        y += shutterSpeedSlider.method_25364();
        y += spacingInGroup;

        exposureSlider = new Slider(x, y, sliderWidth, sliderHeight,
                0, -4, 4, 2, "Sensitivity", v -> onChanged());
        exposureSlider.setHorizontalGradient(0x44000000, 0x44FFFFFF);
        method_37063(exposureSlider);
        rightPaneWidgets.add(exposureSlider);
        y += exposureSlider.method_25364();
        y += spacingInGroup;

        contrastSlider = new Slider(x, y, sliderWidth, sliderHeight,
                0, -1, 1, 2, "Contrast", v -> onChanged());
        contrastSlider.setHorizontalGradient(0x44FFFFFF, 0x44000000);
        method_37063(contrastSlider);
        rightPaneWidgets.add(contrastSlider);
        y += contrastSlider.method_25364();
        y += spacingBetweenGroups;


        class_7940 levelsLabel = new class_7940(labelX, y, class_2561.method_43470("Levels"), field_22793);
        method_37060(levelsLabel);
        rightPaneWidgets.add(levelsLabel);
        y += field_22793.field_2000;

        shadowsSlider = new Slider(x, y, sliderWidth, sliderHeight,
                0, 0, 255, 0, "Shadows", v -> onChanged());
        shadowsSlider.setHorizontalGradient(0x44FFFFFF, 0x44000000);
        method_37063(shadowsSlider);
        rightPaneWidgets.add(shadowsSlider);
        y += shadowsSlider.method_25364();
        y += spacingInGroup;

        midtonesSlider = new Slider(x, y, sliderWidth, sliderHeight,
                128, 0, 255, 0, "Midtones", v -> onChanged());
        midtonesSlider.setHorizontalGradient(0x44FFFFFF, 0x44000000);
        method_37063(midtonesSlider);
        rightPaneWidgets.add(midtonesSlider);
        y += shadowsSlider.method_25364();
        y += spacingInGroup;

        highlightsSlider = new Slider(x, y, sliderWidth, sliderHeight,
                255, 0, 255, 0, "Highlights", v -> onChanged());
        highlightsSlider.setHorizontalGradient(0x44FFFFFF, 0x44000000);
        method_37063(highlightsSlider);
        rightPaneWidgets.add(highlightsSlider);
        y += shadowsSlider.method_25364();
        y += spacingInGroup;

        blackSlider = new Slider(x, y, sliderWidth, sliderHeight,
                0, 0, 255, 0, "Black", v -> onChanged());
        blackSlider.setHorizontalGradient(0x44000000, 0x44FFFFFF);
        method_37063(blackSlider);
        rightPaneWidgets.add(blackSlider);
        y += shadowsSlider.method_25364();
        y += spacingInGroup;

        whiteSlider = new Slider(x, y, sliderWidth, sliderHeight,
                255, 0, 255, 0, "White", v -> onChanged());
        whiteSlider.setHorizontalGradient(0x44000000, 0x44FFFFFF);
        method_37063(whiteSlider);
        rightPaneWidgets.add(whiteSlider);
        y += shadowsSlider.method_25364();
        y += spacingBetweenGroups;


        class_7940 hsbLabel = new class_7940(labelX, y, class_2561.method_43470("HSB"), field_22793);
        method_37060(hsbLabel);
        rightPaneWidgets.add(hsbLabel);
        y += field_22793.field_2000;

        hueSlider = new Slider(x, y, sliderWidth, sliderHeight,
                0, -1, 1, 2, "Hue", v -> onChanged());
        hueSlider.setHorizontalGradient(0x44FF0000, 0x44FF00FF);
        method_37063(hueSlider);
        rightPaneWidgets.add(hueSlider);
        y += shadowsSlider.method_25364();
        y += spacingInGroup;

        saturationSlider = new Slider(x, y, sliderWidth, sliderHeight,
                0, -1, 1, 2, "Saturation", v -> onChanged());
        saturationSlider.setHorizontalGradient(0x44777777, 0x44FF2211);
        method_37063(saturationSlider);
        rightPaneWidgets.add(saturationSlider);
        y += shadowsSlider.method_25364();
        y += spacingInGroup;

        brightnessSlider = new Slider(x, y, sliderWidth, sliderHeight,
                0, -1, 1, 2, "Brightness", v -> onChanged());
        brightnessSlider.setHorizontalGradient(0x44000000, 0x44FFFFFF);
        method_37063(brightnessSlider);
        rightPaneWidgets.add(brightnessSlider);
        y += shadowsSlider.method_25364();
        y += spacingBetweenGroups;

        class_7940 colorBalanceLabel = new class_7940(labelX, y, class_2561.method_43470("Color Balance"), field_22793);
        method_37060(colorBalanceLabel);
        rightPaneWidgets.add(colorBalanceLabel);
        y += field_22793.field_2000;

        balanceRedSlider = new Slider(x, y, sliderWidth, sliderHeight,
                0, -1, 1, 2, "Red", v -> onChanged());
        balanceRedSlider.setHorizontalGradient(0x4400FFFF, 0x44FF0000);
        method_37063(balanceRedSlider);
        rightPaneWidgets.add(balanceRedSlider);
        y += shadowsSlider.method_25364();
        y += spacingInGroup;

        balanceGreenSlider = new Slider(x, y, sliderWidth, sliderHeight,
                0, -1, 1, 2, "Green", v -> onChanged());
        balanceGreenSlider.setHorizontalGradient(0x44FF00FF, 0x4400FF00);
        method_37063(balanceGreenSlider);
        rightPaneWidgets.add(balanceGreenSlider);
        y += shadowsSlider.method_25364();
        y += spacingInGroup;

        balanceBlueSlider = new Slider(x, y, sliderWidth, sliderHeight,
                0, -1, 1, 2, "Blue", v -> onChanged());
        balanceBlueSlider.setHorizontalGradient(0x44FFFF00, 0x440000FF);
        method_37063(balanceBlueSlider);
        rightPaneWidgets.add(balanceBlueSlider);
        y += shadowsSlider.method_25364();
        y += spacingBetweenGroups;


        class_7940 effectsLabel = new class_7940(labelX, y, class_2561.method_43470("Effects"), field_22793);
        method_37060(effectsLabel);
        rightPaneWidgets.add(effectsLabel);
        y += field_22793.field_2000;

        noiseSlider = new Slider(x, y, sliderWidth, sliderHeight,
                0, 0, 1, 2, "Noise", v -> onChanged());
        noiseSlider.setHorizontalGradient(0x44777777, 0x44FFFFFF);
        method_37063(noiseSlider);
        rightPaneWidgets.add(noiseSlider);
        y += shadowsSlider.method_25364();
        y += spacingBetweenGroups;

        bw = class_4286.method_54787(class_2561.method_43470("BW"), field_22793)
                .method_54789(x, y)
                .method_54791((checkbox, bl) -> onChanged())
                .method_54788();
        method_37063(bw);
        rightPaneWidgets.add(bw);

        aged = class_4286.method_54787(class_2561.method_43470("AGED"), field_22793)
                .method_54789(x + bw.method_25368() + class_4185.field_46856, y)
                .method_54791((checkbox, bl) -> onChanged())
                .method_54788();
        method_37063(aged);
        rightPaneWidgets.add(aged);


        class_4185 capture = class_4185.method_46430(class_2561.method_43470("CAPTURE"), b -> capture())
                .method_46437(60, class_4185.field_39501)
                .method_46433(screenEdgeMargin, field_22790 - class_4185.field_39501 - screenEdgeMargin)
                .method_46431();
        method_37063(capture);

        if (image == null) {
            capture();
        }
    }

    protected void capture() {
        if (isCapturing) {
            Minecrft.get().method_1483().method_4873(class_1109.method_4758(Exposure.SoundEvents.CAMERA_GENERIC_CLICK.get(), 1f));
            Minecrft.player().method_7353(class_2561.method_43470("Capture is in progress."), false);
            return;
        }
        isCapturing = true;

        Minecrft.get().method_1483().method_4873(class_1109.method_4758(Exposure.SoundEvents.SHUTTER_OPEN.get(), 1f));

        ExposureClient.cycles().enqueueTask(Capture.of(Capture.screenshot(), CaptureAction.hideGui())
                .handleErrorAndGetResult(err -> Minecrft.execute(() ->
                        Minecrft.player().method_7353(err.casual().method_27692(class_124.field_1061), false)))
                .thenAsync(ImageEffect.Crop.SQUARE_CENTER::modify)
                .onError(err -> Minecrft.execute(() ->
                        Minecrft.player().method_7353(err.casual().method_27692(class_124.field_1061), false)))
                .accept(this::setImage));
    }

    protected void applyEdits() {
        if (renderableImage == null) {
            Minecrft.get().method_1483().method_4873(class_1109.method_4758(Exposure.SoundEvents.CAMERA_GENERIC_CLICK.get(), 1f));
            Minecrft.player().method_7353(class_2561.method_43470("No image to modify."), false);
            return;
        }

        try {
            renderableImage = RenderableImage.of("test_image", image)
                    .modifyWith(ImageEffect.Resize.to(sizeSlider.getValue().intValue()))
                    .modifyWith(ImageEffect.exposure(shutterSpeedSlider.getShutterSpeed().getBrightness() * (exposureSlider.getValue().floatValue() + 1f)))
                    .modifyWith(ImageEffect.contrast(contrastSlider.getValue().floatValue()))
                    .modifyWith(ImageEffect.levels(new Levels(
                            shadowsSlider.getValue().intValue(),
                            midtonesSlider.getValue().intValue(),
                            highlightsSlider.getValue().intValue(),
                            blackSlider.getValue().intValue(),
                            whiteSlider.getValue().intValue())))
                    .modifyWith(ImageEffect.hsb(
                            hueSlider.getValue().floatValue(),
                            saturationSlider.getValue().floatValue(),
                            brightnessSlider.getValue().floatValue()))
                    .modifyWith(ImageEffect.colorBalance(
                            balanceRedSlider.getValue().floatValue(),
                            balanceGreenSlider.getValue().floatValue(),
                            balanceBlueSlider.getValue().floatValue()))
                    .modifyWith(ImageEffect.noise(noiseSlider.getValue().floatValue()))
                    .modifyWith(ImageEffect.optional(bw.method_20372(), ImageEffect.BLACK_AND_WHITE))
                    .modifyWith(image -> Palettizer.DITHERED.palettize(image,
                            ColorPalettes.getDefault(Minecrft.registryAccess()).comp_349()), "palette")
                    .modifyWith(ImageEffect.optional(aged.method_20372(), ImageEffect.AGED));
            ExposureClient.imageRenderer().clearCacheOf("test_image");
        } catch (Exception e) {
            Minecrft.get().method_1483().method_4873(class_1109.method_4758(Exposure.SoundEvents.CAMERA_GENERIC_CLICK.get(), 1f));
            Minecrft.player().method_7353(class_2561.method_43470("Failed to apply edits. " + e.getMessage()), false);
            Exposure.LOGGER.error("Failed to apply edits: ", e);
        }
        applyEditsAt = -1;
    }

    protected void onChanged() {
        applyEditsAt = UnixTimestamp.Milliseconds.now()/* + 10*/;
    }

    private void setImage(Image image) {
        if (this.image != null) this.image.close();
        if (this.renderableImage != null) this.renderableImage.close();

        this.image = image;
        this.renderableImage = RenderableImage.of("test_image", image);
        applyEdits();
        ExposureClient.imageRenderer().clearCacheOf("test_image");
        Minecrft.get().method_1483().method_4873(class_1109.method_4758(Exposure.SoundEvents.SHUTTER_CLOSE.get(), 1f));
        isCapturing = false;
    }

    // --

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        fillHorizontalGradient(guiGraphics, field_22789 - 100, -500, field_22789, field_22790 + 500, 0x00000000, 0xBB111111);

        if (isCapturing) {
            String txt = "Capturing...";
            guiGraphics.method_25303(field_22793, txt, field_22789 / 2 - field_22793.method_1727(txt) / 2, field_22790 / 2 - 4, 0xFFFFFFFF);
            return;
        }

        if (renderableImage == null) {
            String txt = "<No Image>";
            guiGraphics.method_25303(field_22793, txt, field_22789 / 2 - field_22793.method_1727(txt) / 2, field_22790 / 2 - 4, 0xFFFFFFFF);
            return;
        }

        if (applyEditsAt > 0 && UnixTimestamp.Milliseconds.now() >= applyEditsAt) {
            applyEdits();
        }

        guiGraphics.method_51448().method_22903();
        float size = field_22790 * 0.8f * scale;
        guiGraphics.method_51448().method_46416(field_22789 / 2f - size / 2f, field_22790 / 2f - size / 2f, -100);

        float borderPercent = 0.02f;
        guiGraphics.method_25294(class_3532.method_15375(-size * borderPercent), class_3532.method_15375(-size * borderPercent),
                class_3532.method_15386(size + (size * borderPercent)), class_3532.method_15386(size + (size * borderPercent)), 0xFFFFFFFF);
        guiGraphics.method_51448().method_22905(size, size, size);


        class_4597.class_4598 bufferSource = class_310.method_1551().method_22940().method_23000();
        ExposureClient.imageRenderer().render(renderableImage, guiGraphics.method_51448(), bufferSource, RenderCoordinates.DEFAULT, Color.WHITE);
        bufferSource.method_22993();
        guiGraphics.method_51448().method_22909();
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (super.method_25401(mouseX, mouseY, scrollX, scrollY)) {
            return true;
        }

        int value = class_3532.method_17822(scrollY);

        if (mouseX > field_22789 - 100 && !rightPaneWidgets.isEmpty()) {
            int yChange = value * 14;

            if (yChange > 0 && rightPaneWidgets.getFirst().method_46427() >= 5) {
                return true;
            }
            if (yChange < 0 && rightPaneWidgets.getLast().method_46427() + rightPaneWidgets.getLast().method_25364() <= field_22790 - 5) {
                return true;
            }

            for (class_339 widget : rightPaneWidgets) {
                widget.method_46419(widget.method_46427() + yChange);
                if (widget.method_46427() < 5 || widget.method_46427() + widget.method_25364() > field_22790 - 5) {
                    widget.field_22764 = false;
                } else {
                    widget.field_22764 = true;
                }
            }

            return true;
        }

        scale = class_3532.method_15363(scale + 0.2f * value, 0.2f, 2f);

        return true;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (super.method_25403(mouseX, mouseY, button, dragX, dragY)) return true;

        if (button != class_3675.field_32002) return false;

        // Dragging the view with mouse:
        double fov = Minecrft.options().method_41808().method_41753();
        int windowWidth = Minecrft.get().method_22683().method_4506();
        int windowHeight = Minecrft.get().method_22683().method_4506();
        double xRot = (dragY / windowHeight) * fov;
        double yRot = (dragX / windowWidth) * (fov * ((double) windowHeight / windowWidth));
        Minecrft.player().method_5872(-yRot * 20, -xRot * 20);

        return true;
    }

    private void fillHorizontalGradient(class_332 guiGraphics, int x1, int y1, int x2, int y2, int colorFrom, int colorTo) {
        class_4588 consumer = guiGraphics.method_51450().getBuffer(class_1921.method_51784());
        Matrix4f matrix4f = guiGraphics.method_51448().method_23760().method_23761();
        consumer.method_22918(matrix4f, (float) x1, (float) y1, 0).method_39415(colorFrom);
        consumer.method_22918(matrix4f, (float) x1, (float) y2, 0).method_39415(colorFrom);
        consumer.method_22918(matrix4f, (float) x2, (float) y2, 0).method_39415(colorTo);
        consumer.method_22918(matrix4f, (float) x2, (float) y1, 0).method_39415(colorTo);
    }
}
