package io.github.mortuusars.exposure.advancements.predicate;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1297;
import net.minecraft.class_1321;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_7376;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public record TamedPredicate(boolean isTamed) implements class_7376 {
    public static final MapCodec<TamedPredicate> CODEC = RecordCodecBuilder.mapCodec(
            instance -> instance.group(Codec.BOOL.fieldOf("is_tamed").forGetter(TamedPredicate::isTamed))
                    .apply(instance, TamedPredicate::new)
    );

    @Override
    public @NotNull MapCodec<? extends class_7376> method_58152() {
        return CODEC;
    }

    @Override
    public boolean method_22497(class_1297 entity, class_3218 level, @Nullable class_243 position) {
        return entity instanceof class_1321 animal && animal.method_6181() == isTamed;
    }
}
