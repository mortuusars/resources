package io.github.mortuusars.exposure.mixin;

import net.minecraft.class_1263;
import net.minecraft.class_3722;
import net.minecraft.class_3913;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3722.class)
public interface LecternBlockEntityAccessor {
    @Accessor("bookAccess")
    class_1263 getBookAccess();

    @Accessor("dataAccess")
    class_3913 getDataAccess();
}
