package io.github.mortuusars.exposure.client.input;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.client.camera.CameraClient;
import io.github.mortuusars.exposure.client.util.Minecrft;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class KeyboardHandler {
    @Nullable
    private static class_304 openCameraControlsKey = null;

    public static void registerKeymappings(Function<class_304, class_304> registerFunction) {
        class_304 keyMapping = new class_304("key.exposure.camera_controls",
                class_3675.field_16237.method_1444(), "category.exposure");

        openCameraControlsKey = registerFunction.apply(keyMapping);
    }

    public static boolean handleKeyPress(long windowId, int key, int scanCode, int action, int modifiers) {
        return Minecrft.get().field_1724 != null
                && CameraClient.viewfinder() != null
                && CameraClient.viewfinder().keyPressed(key, scanCode, action, modifiers);
    }

    public static class_304 getCameraControlsKey() {
        Preconditions.checkState(openCameraControlsKey != null,
                "Viewfinder Controls key mapping was not registered");

        return openCameraControlsKey.method_1415() ? class_310.method_1551().field_1690.field_1832 : openCameraControlsKey;
    }
}
