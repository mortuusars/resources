package io.github.mortuusars.exposure.world.camera.frame;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.netty.buffer.ByteBuf;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_3544;
import net.minecraft.class_4844;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class Photographer {
    public static final Photographer EMPTY = new Photographer("", class_156.field_25140);

    public static final Codec<Photographer> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                    Codec.STRING.optionalFieldOf("name", "").forGetter(Photographer::name),
                    class_4844.field_46588.optionalFieldOf("uuid", class_156.field_25140).forGetter(Photographer::uuid))
            .apply(instance, Photographer::new));

    public static final class_9139<ByteBuf, Photographer> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48554, Photographer::name,
            class_4844.field_48453, Photographer::uuid,
            Photographer::new
    );

    private final String name;
    private final UUID uuid;

    private Photographer(String name, UUID uuid) {
        this.name = name;
        this.uuid = uuid;
    }

    public Photographer(CameraHolder cameraHolder) {
        class_1297 owner = cameraHolder.getExposureAuthorEntity();
        this.name = owner instanceof class_1657 ? owner.method_5820() : class_1299.method_5890(owner.method_5864()).toString();
        // UUID of non-player entities are not recorded because they are usually short-lived.
        this.uuid = owner instanceof class_1657 ? owner.method_5667() : class_156.field_25140;
    }

    public boolean matches(class_1297 entity) {
        return uuid.equals(entity.method_5667());
    }

    public boolean isPlayer() {
        return !class_3544.method_57181(name) && !uuid.equals(class_156.field_25140);
    }

    public boolean isNPC() {
        return !class_3544.method_57181(name) && uuid.equals(class_156.field_25140);
    }

    public boolean isEmpty() {
        return this.equals(EMPTY);
    }

    public String name() {
        return name;
    }

    public UUID uuid() {
        return uuid;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (Photographer) obj;
        return Objects.equals(this.name, that.name) &&
                Objects.equals(this.uuid, that.uuid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, uuid);
    }

    @Override
    public String toString() {
        return "Photographer[" +
                "name=" + name + ", " +
                "uuid=" + uuid + ']';
    }

}
