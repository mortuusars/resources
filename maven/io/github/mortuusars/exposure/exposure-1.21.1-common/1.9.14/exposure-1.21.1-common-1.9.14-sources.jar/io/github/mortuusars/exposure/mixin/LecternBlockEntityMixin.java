package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.world.item.AlbumItem;
import io.github.mortuusars.exposure.world.item.SignedAlbumItem;
import net.minecraft.class_1799;
import net.minecraft.class_3722;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3722.class)
public abstract class LecternBlockEntityMixin {
    @Shadow public abstract class_1799 getBook();

    @Inject(method = "hasBook", at = @At("HEAD"), cancellable = true)
    private void onHasBook(CallbackInfoReturnable<Boolean> cir) {
        if (getBook().method_7909() instanceof AlbumItem || getBook().method_7909() instanceof SignedAlbumItem) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "getPageCount", at = @At("HEAD"), cancellable = true)
    private static void onGetPageCount(class_1799 stack, CallbackInfoReturnable<Integer> cir) {
        if (stack.method_7909() instanceof AlbumItem albumItem) {
            cir.setReturnValue(albumItem.getContent(stack).pages().size());
        }
        else if (stack.method_7909() instanceof SignedAlbumItem signedAlbumItem) {
            cir.setReturnValue(signedAlbumItem.getContent(stack).pages().size());
        }
    }
}
