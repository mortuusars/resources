package io.github.mortuusars.exposure.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.exposure.Config;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Optional;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import net.minecraft.class_6880;

@Mixin(class_1844.class)
public abstract class PotionContentsMixin {
    @Shadow public abstract Optional<class_6880<class_1842>> potion();

    @ModifyReturnValue(method = "getColor()I", at = @At("RETURN"))
    private int onGetColor(int original) {
        if (!Config.Common.DIFFERENT_DEVELOPING_POTION_COLORS.get() || original != 0xFF385DC6) { // Default color
            return original;
        }

        if (potion().isPresent()) {
            if (potion().get().comp_349().equals(class_1847.field_8967.comp_349())) {
                return 0xFF424D8F;
            }

            if (potion().get().comp_349().equals(class_1847.field_8999.comp_349())) {
                return 0xFF653594;
            }

            if (potion().get().comp_349().equals(class_1847.field_8985.comp_349())) {
                return 0xFF3E7782;
            }
        }

        return original;
    }
}
