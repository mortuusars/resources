package io.github.mortuusars.exposure.commands.argument;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.mortuusars.exposure.Exposure;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2172;
import net.minecraft.class_2232;
import net.minecraft.class_2960;

public class ColorPaletteArgument extends class_2232 {
    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        class_2172 provider = (class_2172) context.getSource();
        Set<class_2960> keys = provider.method_30497().method_30530(Exposure.Registries.COLOR_PALETTE).method_10235();
        return class_2172.method_9270(keys, builder);
    }
}
