package io.github.mortuusars.exposure.client.gui.screen.element;

import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_8666;

public class ToggleImageButton extends class_344 {
    protected final class_8666 onSprites;
    protected final Consumer<Boolean> onToggled;
    protected boolean state;

    public ToggleImageButton(int x, int y, int width, int height, class_8666 offSprites, class_8666 onSprites,
                             Consumer<Boolean> onToggled) {
        super(x, y, width, height, offSprites, b -> {});
        this.onSprites = onSprites;
        this.onToggled = onToggled;
    }

    public boolean isOn() {
        return state;
    }

    public boolean isOff() {
        return !isOn();
    }

    public void toggle() {
        this.state = !state;
        onToggled.accept(this.state);
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public <T> T mapState(Function<Boolean, T> mappingFunction) {
        return mappingFunction.apply(state);
    }

    @Override
    public void method_25306() {
        toggle();
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        class_8666 sprites = isOn() ? onSprites : this.field_45356;
        class_2960 resourceLocation = sprites.method_52729(this.method_37303(), this.method_25367());
        guiGraphics.method_52706(resourceLocation, this.method_46426(), this.method_46427(), this.field_22758, this.field_22759);
    }
}
