package io.github.mortuusars.exposure.client.capture.action;

import net.minecraft.class_310;

public class HideGuiAction implements CaptureAction {
    private boolean hideGuiBeforeCapture;

    @Override
    public void beforeCapture() {
        hideGuiBeforeCapture = class_310.method_1551().field_1690.field_1842;
        class_310.method_1551().field_1690.field_1842 = true;
    }

    @Override
    public void afterCapture() {
        class_310.method_1551().field_1690.field_1842 = hideGuiBeforeCapture;
    }
}
