package io.github.mortuusars.exposure.client.image.modifier.pixel;

import com.google.common.base.Preconditions;
import net.minecraft.class_3532;
import net.minecraft.class_5253;

public class ColorBalanceEffect implements PixelEffect {
    protected final float r, g, b;

    /**
     * 0 means no change.
     */
    public ColorBalanceEffect(float r, float g, float b) {
        Preconditions.checkArgument(r >= -1 && r <= 1, "r must be in -1 to 1 range.");
        Preconditions.checkArgument(g >= -1 && g <= 1, "g must be in -1 to 1 range.");
        Preconditions.checkArgument(b >= -1 && b <= 1, "b must be in -1 to 1 range.");
        this.r = r;
        this.g = g;
        this.b = b;
    }

    @Override
    public String getIdentifier() {
        return "color-balance-r%s-g%s-b%s".formatted(r, g, b);
    }

    public int modify(int colorARGB) {
        if (r == 0f && g == 0f && b == 0f) return colorARGB;

        int alpha = class_5253.class_5254.method_27762(colorARGB);
        int red = class_5253.class_5254.method_27765(colorARGB);
        int green = class_5253.class_5254.method_27766(colorARGB);
        int blue = class_5253.class_5254.method_27767(colorARGB);

        red = class_3532.method_15340(class_3532.method_15375(red * (r + 1)), 0, 255);
        green = class_3532.method_15340(class_3532.method_15375(green * (g + 1)), 0, 255);
        blue = class_3532.method_15340(class_3532.method_15375(blue * (b + 1)), 0, 255);

        return class_5253.class_5254.method_27764(alpha, red, green, blue);
    }

    @Override
    public String toString() {
        return "ColorBalance{" +
                "r=" + r +
                ", g=" + g +
                ", b=" + b +
                '}';
    }
}
