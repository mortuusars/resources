package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record CameraStandTurnC2SP(int entityId, double yRot, double xRot) implements Packet {
    public static final class_2960 ID = Exposure.resource("camera_stand_turn");
    public static final class_9154<CameraStandTurnC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, CameraStandTurnC2SP> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48550, CameraStandTurnC2SP::entityId,
            class_9135.field_48553, CameraStandTurnC2SP::yRot,
            class_9135.field_48553, CameraStandTurnC2SP::xRot,
            CameraStandTurnC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (!(player.method_37908().method_8469(entityId) instanceof CameraStandEntity stand)) return false;
        if (player.equals(stand.operator()) || stand.getOwnerPlayer().map(pl -> pl.equals(player)).orElse(false)) {
            stand.method_5872(yRot, xRot);
        }
        return true;
    }
}