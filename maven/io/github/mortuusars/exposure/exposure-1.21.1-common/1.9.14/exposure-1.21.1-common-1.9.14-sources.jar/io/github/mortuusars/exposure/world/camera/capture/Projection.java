package io.github.mortuusars.exposure.world.camera.capture;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2540;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record Projection(String path, DitherMode mode) {
    public static final Codec<Projection> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("path").forGetter(Projection::path),
            DitherMode.CODEC.optionalFieldOf("mode", DitherMode.DITHERED).forGetter(Projection::mode)
    ).apply(instance, Projection::new));

    public static final class_9139<class_2540, Projection> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48554, Projection::path,
            DitherMode.STREAM_CODEC, Projection::mode,
            Projection::new
    );
}
