
package io.github.mortuusars.exposure.world.item.component.album;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SignedAlbumContent(String title, String author, List<SignedAlbumPage> pages) {
    public static final Codec<SignedAlbumContent> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("title").forGetter(SignedAlbumContent::title),
            Codec.STRING.fieldOf("author").forGetter(SignedAlbumContent::author),
            SignedAlbumPage.CODEC.sizeLimitedListOf(AlbumContent.MAX_PAGES).fieldOf("pages").forGetter(SignedAlbumContent::pages)
    ).apply(instance, SignedAlbumContent::new));

    public static final class_9139<class_9129, SignedAlbumContent> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48554, SignedAlbumContent::title,
            class_9135.field_48554, SignedAlbumContent::author,
            SignedAlbumPage.STREAM_CODEC.method_56433(class_9135.method_58000(AlbumContent.MAX_PAGES)), SignedAlbumContent::pages,
            SignedAlbumContent::new
    );

    public static final SignedAlbumContent EMPTY = new SignedAlbumContent("", "", Collections.emptyList());

    public SignedAlbumContent {
        Preconditions.checkArgument(pages.size() <= AlbumContent.MAX_PAGES,
                "Too many pages for signed album. Max is " + AlbumContent.MAX_PAGES);
    }
}
