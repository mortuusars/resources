package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.clientbound.CameraStandSetRotationsS2CP;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_3231;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3231.class)
public class ServerEntityMixin {
    @Shadow @Final private class_1297 entity;

    // We need to send stand's full rotation values, because vanilla packets have limited data (bytes as rotations, for example).

    @Inject(method = "addPairing", at = @At("RETURN"))
    private void onAddPairing(class_3222 player, CallbackInfo ci) {
        if (this.entity instanceof CameraStandEntity stand) {
            Packets.sendToClient(new CameraStandSetRotationsS2CP(stand.method_5628(), stand.method_36454(), stand.method_36455()), player);
        }
    }

    @Inject(method = "sendChanges", at = @At("RETURN"))
    private void onSendChanges(CallbackInfo ci) {
        if (this.entity instanceof CameraStandEntity stand) {
            stand.syncRotationToClientsIfNeeded();
        }
    }
}
