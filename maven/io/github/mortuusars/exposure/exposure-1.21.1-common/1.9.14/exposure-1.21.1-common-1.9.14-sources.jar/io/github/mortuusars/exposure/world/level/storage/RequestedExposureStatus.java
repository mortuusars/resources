package io.github.mortuusars.exposure.world.level.storage;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public enum RequestedExposureStatus {
    NOT_REQUESTED,
    AWAITED,
    TIMED_OUT,
    INVALID_ID,
    NOT_FOUND,
    CANNOT_LOAD,
    SUCCESS,
    NEEDS_REFRESH;

    public static final class_9139<ByteBuf, RequestedExposureStatus> STREAM_CODEC = class_9135.method_56375(
            id -> RequestedExposureStatus.values()[id], RequestedExposureStatus::ordinal
    );
}
