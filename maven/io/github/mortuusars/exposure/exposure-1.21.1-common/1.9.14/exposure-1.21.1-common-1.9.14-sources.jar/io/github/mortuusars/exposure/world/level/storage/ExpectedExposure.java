package io.github.mortuusars.exposure.world.level.storage;

import java.util.function.BiConsumer;
import net.minecraft.class_3222;

public record ExpectedExposure(String id, long timeoutAt, BiConsumer<class_3222, String> onReceived) {
    public boolean isTimedOut(long currentUnixTimeSeconds) {
        return currentUnixTimeSeconds > timeoutAt;
    }
}
