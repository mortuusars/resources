package io.github.mortuusars.exposure.world.item.camera;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.camera.component.ShutterSpeed;
import io.github.mortuusars.exposure.server.CameraInstance;
import io.github.mortuusars.exposure.server.CameraInstances;
import io.github.mortuusars.exposure.world.sound.Sound;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_5712;
import org.apache.logging.log4j.util.TriConsumer;

public class Shutter {
    protected TriConsumer<CameraHolder, class_3218, class_1799> onOpen = (entity, level, stack) -> { };
    protected TriConsumer<CameraHolder, class_3218, class_1799> onClosed = (entity, level, stack) -> { };

    public void onOpen(TriConsumer<CameraHolder, class_3218, class_1799> onOpen) {
        this.onOpen = onOpen;
    }

    /**
     * Will not be executed when closing time should've been "long" ago.
     * When camera wasn't in inventory at the time of closing, for example.
     */
    public void onClosed(TriConsumer<CameraHolder, class_3218, class_1799> onClosed) {
        this.onClosed = onClosed;
    }

    public ShutterState getState(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.SHUTTER_STATE, ShutterState.CLOSED);
    }

    public void setState(class_1799 stack, ShutterState shutterState) {
        stack.method_57379(Exposure.DataComponents.SHUTTER_STATE, shutterState);
    }

    public boolean isOpen(class_1799 stack) {
        return getState(stack).isOpen();
    }

    public boolean shouldClose(class_1799 stack, long gameTime) {
        ShutterState state = getState(stack);
        boolean projecting = CameraInstances.getOptional(stack).map(CameraInstance::isWaitingForProjection).orElse(false);
        return state.isOpen() && !projecting && gameTime >= state.getCloseTick();
    }

    /**
     * @return true if shutter state has changed.
     */
    public boolean tick(CameraHolder holder, class_3218 level, class_1799 stack) {
        long gameTime = holder.asHolderEntity().method_37908().method_8510();
        if (shouldClose(stack, gameTime)) {
            ShutterState state = getState(stack);
            if (gameTime - state.getCloseTick() > 200) {
                setState(stack, ShutterState.CLOSED);
            } else {
                close(holder, level, stack);
            }
            return true;
        }
        return false;
    }

    public void open(CameraHolder holder, class_3218 level, class_1799 stack, ShutterSpeed shutterSpeed) {
        setState(stack, ShutterState.open(level.method_8510(), shutterSpeed));
        holder.asHolderEntity().method_32876(class_5712.field_28146);
        playOpenSound(holder);
        onOpen.accept(holder, level, stack);
    }

    public void close(CameraHolder holder, class_3218 level, class_1799 stack) {
        setState(stack, ShutterState.closed());
        holder.asHolderEntity().method_32876(class_5712.field_28146);
        playCloseSound(holder);
        onClosed.accept(holder, level, stack);
    }

    public void playOpenSound(CameraHolder holder) {
        class_1297 entity = holder.asHolderEntity();
        Sound.play(entity, Exposure.SoundEvents.SHUTTER_OPEN.get(), entity.method_5634(), 0.7f, 1.1f, 0.2f);
    }

    public void playCloseSound(CameraHolder holder) {
        class_1297 entity = holder.asHolderEntity();
        Sound.play(entity, Exposure.SoundEvents.SHUTTER_CLOSE.get(), entity.method_5634(), 0.7f, 1.1f, 0.2f);
    }
}
