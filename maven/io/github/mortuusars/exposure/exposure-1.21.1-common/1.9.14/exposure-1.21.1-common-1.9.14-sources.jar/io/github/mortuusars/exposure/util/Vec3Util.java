package io.github.mortuusars.exposure.util;

import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class Vec3Util {
    public static List<class_243> getProbeVectors(class_243 direction, float offsetDegrees) {
        // World up vector
        class_243 upVector = new class_243(0, 1, 0);

        // Calculate right vector (cross product of forward and up)
        class_243 rightVector = direction.method_1036(upVector).method_1029();
        if (class_3532.method_20390(rightVector.method_1033(), 0)) {
            // Handle edge case: looking straight up or down
            rightVector = new class_243(1, 0, 0).method_1036(direction).method_1029();
        }

        // Calculate adjusted up vector (orthogonal to forward and right)
        upVector = rightVector.method_1036(direction).method_1029();

        float offsetRadians = (float) Math.toRadians(offsetDegrees);

        class_243 topLeft = calculateOffsetDirection(direction, upVector, rightVector, offsetRadians, offsetRadians);
        class_243 topRight = calculateOffsetDirection(direction, upVector, rightVector, -offsetRadians, offsetRadians);
        class_243 bottomLeft = calculateOffsetDirection(direction, upVector, rightVector, offsetRadians, -offsetRadians);
        class_243 bottomRight = calculateOffsetDirection(direction, upVector, rightVector, -offsetRadians, -offsetRadians);

        return Stream.of(direction, topLeft, topRight, bottomLeft, bottomRight).toList();
    }

    public static class_243 calculateOffsetDirection(class_243 forward, class_243 up, class_243 right, double horizontalOffset, double verticalOffset) {
        class_243 horizontalRotated = rotateVector(forward, up, horizontalOffset);
        return rotateVector(horizontalRotated, right, verticalOffset).method_1029();
    }

    public static class_243 rotateVector(class_243 vec, class_243 axis, double angle) {
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        double dot = vec.method_1026(axis);
        return vec.method_1021(cos)
                .method_1019(axis.method_1036(vec).method_1021(sin))
                .method_1019(axis.method_1021(dot * (1 - cos)));
    }
}
