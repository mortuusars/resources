package io.github.mortuusars.exposure.client.image.modifier.pixel;

import net.minecraft.class_5253;

public class MultiplyEffect implements PixelEffect {
    protected final int multiplyColor;

    public MultiplyEffect(int multiplyColor) {
        this.multiplyColor = multiplyColor;
    }

    @Override
    public String getIdentifier() {
        return multiplyColor != 0 ? "multiply-" + Integer.toHexString(multiplyColor) : "";
    }

    public int modify(int colorARGB) {
        if (multiplyColor == 0) return colorARGB;

        int alpha = class_5253.class_5254.method_27762(colorARGB);
        int red = class_5253.class_5254.method_27765(colorARGB);
        int green = class_5253.class_5254.method_27766(colorARGB);
        int blue = class_5253.class_5254.method_27767(colorARGB);

        int tintAlpha = class_5253.class_5254.method_27762(colorARGB);
        int tintRed = class_5253.class_5254.method_27765(colorARGB);
        int tintGreen = class_5253.class_5254.method_27766(colorARGB);
        int tintBlue = class_5253.class_5254.method_27767(colorARGB);

        alpha = Math.min(255, (alpha * tintAlpha) / 255);
        red = Math.min(255, (red * tintRed) / 255);
        green = Math.min(255, (green * tintGreen) / 255);
        blue = Math.min(255, (blue * tintBlue) / 255);

        return class_5253.class_5254.method_27764(alpha, green, red, blue);
    }
}
