package io.github.mortuusars.exposure.world.camera;

import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.network.packet.clientbound.ActiveCameraOnStandSetS2CP;
import io.github.mortuusars.exposure.world.entity.CameraOperator;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import net.minecraft.class_1799;

public class CameraOnStand extends Camera {
    protected final CameraOperator cameraOperator;
    protected final CameraStandEntity cameraStand;

    public CameraOnStand(CameraOperator cameraOperator, CameraStandEntity cameraStand, CameraId id) {
        super(cameraStand, id);
        this.cameraOperator = cameraOperator;
        this.cameraStand = cameraStand;
    }

    public CameraOperator getOperator() {
        return cameraOperator;
    }

    public CameraStandEntity getStand() {
        return cameraStand;
    }

    @Override
    public class_1799 getItemStack() {
        return cameraStand.getCamera();
    }

    @Override
    public void release() {
        getStand().release();
    }

    @Override
    public Packet createSyncPacket() {
        return new ActiveCameraOnStandSetS2CP(cameraOperator.asOperatorEntity().method_5628(), cameraStand.method_5628(), id);
    }
}
