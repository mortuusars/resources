package io.github.mortuusars.exposure.world.camera;

import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.network.packet.clientbound.ActiveCameraInHandSetS2CP;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import net.minecraft.class_1268;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

public class CameraInHand extends Camera {
    protected final class_1268 hand;

    public CameraInHand(CameraHolder holder, CameraId cameraId, class_1268 hand) {
        super(holder, cameraId);
        this.hand = hand;
        if (!(holder instanceof class_1309)) {
            throw new IllegalStateException("Only LivingEntity can hold camera in hand."
                    + class_1299.method_5890(holder.asHolderEntity().method_5864()) + " does snot have hands.");
        }
    }

    @Override
    public class_1799 getItemStack() {
        return ((class_1309) getHolder()).method_5998(getHand());
    }

    @Override
    public boolean deactivate() {
        if (super.deactivate()) return true;

        class_1268 oppositeHand = getHand() == class_1268.field_5808
                ? class_1268.field_5810
                : class_1268.field_5808;
        class_1799 itemInHand = ((class_1309) getHolder()).method_5998(oppositeHand);
        if (getId().matches(itemInHand) && itemInHand.method_7909() instanceof CameraItem cameraItem && cameraItem.isActive(itemInHand)) {
            cameraItem.deactivate(getHolder().asHolderEntity(), itemInHand);
            return true;
        }

        if (getHolder() instanceof class_1657 player) {
            for (class_1799 stack : player.method_31548().field_7547) {
                if (getId().matches(stack) && stack.method_7909() instanceof CameraItem cameraItem && cameraItem.isActive(stack)) {
                    cameraItem.deactivate(getHolder().asHolderEntity(), stack);
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public Packet createSyncPacket() {
        return new ActiveCameraInHandSetS2CP(getHolder().asHolderEntity().method_5628(), getId(), getHand());
    }

    public class_1268 getHand() {
        return hand;
    }

    // --

    public static @Nullable CameraInHand find(CameraHolder holder) {
        if (holder.asHolderEntity() instanceof class_1309 entity) {
            for (class_1268 hand : class_1268.values()) {
                class_1799 itemInHand = entity.method_5998(hand);
                if (itemInHand.method_7909() instanceof CameraItem cameraItem) {
                    return new CameraInHand(holder, cameraItem.getOrCreateId(itemInHand), hand);
                }
            }
        }
        return null;
    }
}