package io.github.mortuusars.exposure.client.image.modifier.pixel;

import com.google.common.base.Preconditions;
import java.util.Random;
import net.minecraft.class_3532;
import net.minecraft.class_5253;

public class NoiseEffect implements PixelEffect {
    protected final Random random = new Random();
    protected final float intensity;

    public NoiseEffect(float intensity) {
        Preconditions.checkArgument(intensity >= 0 && intensity <= 1, "intensity should be in 0-1 range.");
        this.intensity = intensity;
    }

    @Override
    public String getIdentifier() {
        return "noise-" + intensity;
    }

    public int modify(int colorARGB) {
        int alpha = class_5253.class_5254.method_27762(colorARGB);
        int red = class_5253.class_5254.method_27765(colorARGB);
        int green = class_5253.class_5254.method_27766(colorARGB);
        int blue = class_5253.class_5254.method_27767(colorARGB);

        float brightness = (0.299f * red + 0.587f * green + 0.114f * blue) / 255f;

        // Less noise in bright areas
        float intensity = this.intensity * (1f - (brightness));
        intensity = class_3532.method_16439(0.25f, intensity, this.intensity);

        int noise = (int) (random.nextGaussian() * intensity * 155);
        int rNoise = (int) (random.nextGaussian() * intensity * 100);
        int gNoise = (int) (random.nextGaussian() * intensity * 100);
        int bNoise = (int) (random.nextGaussian() * intensity * 100);

        red = class_3532.method_15340(red + noise + rNoise, 0, 255);
        green = class_3532.method_15340(green + noise + gNoise, 0, 255);
        blue = class_3532.method_15340(blue + noise + bNoise, 0, 255);

        return class_5253.class_5254.method_27764(alpha, red, green, blue);
    }
}
