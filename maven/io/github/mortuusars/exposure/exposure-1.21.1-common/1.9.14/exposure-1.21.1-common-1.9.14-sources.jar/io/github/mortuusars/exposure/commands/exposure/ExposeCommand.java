package io.github.mortuusars.exposure.commands.exposure;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.network.packet.clientbound.CaptureStartS2CP;
import io.github.mortuusars.exposure.world.camera.capture.CaptureParameters;
import io.github.mortuusars.exposure.world.camera.capture.CaptureType;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import io.github.mortuusars.exposure.network.Packets;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2179;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_3222;
import net.minecraft.class_6903;

public class ExposeCommand {
    public static LiteralArgumentBuilder<class_2168> get() {
        return class_2170.method_9247("expose")
                .then(class_2170.method_9244("capture_properties", class_2179.method_9284())
                        .executes(context -> expose(context, class_2179.method_9285(context, "capture_properties"))));
    }

    private static int expose(CommandContext<class_2168> context, class_2487 properties) throws CommandSyntaxException {
        class_3222 player = context.getSource().method_9207();

        if (!properties.method_10573("id", class_2487.field_33258)) {
            properties.method_10582("id", ExposureIdentifier.createId(player));
        }

        CaptureParameters captureParameters;

        try {
            class_6903<class_2520> ops = class_6903.method_46632(class_2509.field_11560, context.getSource().method_30497());
            captureParameters = CaptureParameters.CODEC.decode(ops, properties).getOrThrow().getFirst();
        } catch (Exception e) {
            context.getSource().method_9213(class_2561.method_43470("Cannot decode properties: " + e.getMessage()));
            return 0;
        }

        String exposureId = captureParameters.exposureId();
        Frame frame = Frame.EMPTY.toMutable().setIdentifier(ExposureIdentifier.id(exposureId)).toImmutable();

        Supplier<class_2561> msg = () -> {
            class_1799 photograph = new class_1799(Exposure.Items.PHOTOGRAPH.get());
            photograph.method_57379(Exposure.DataComponents.PHOTOGRAPH_FRAME, frame);

            return class_2561.method_43470("Exposed: ")
                    .method_10852(class_2561.method_43470(exposureId)
                            .method_27696(class_2583.field_24360
                                    .method_10958(new class_2558(class_2558.class_2559.field_11750,
                                            "/exposure show id " + exposureId))
                                    .method_10949(new class_2568(class_2568.class_5247.field_24343, new class_2568.class_5249(photograph)))
                                    .method_30938(true)));
        };

        ExposureServer.exposureRepository().expect(player, exposureId, (pl, id) -> context.getSource().method_9226(msg, true));
        ExposureServer.frameHistory().add(player, frame);

        Packets.sendToClient(new CaptureStartS2CP(CaptureType.EXPOSE_COMMAND, captureParameters), player);

        return 0;
    }
}
