package io.github.mortuusars.exposure.world.item.crafting.recipe;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2371;
import net.minecraft.class_7710;
import net.minecraft.class_9694;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;

public class PhotographCopyingRecipe extends ComponentTransferringRecipe {
    public PhotographCopyingRecipe(class_7710 category, class_1856 sourceIngredient, class_2371<class_1856> ingredients, class_1799 result) {
        super(category, sourceIngredient, ingredients, result);
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return Exposure.RecipeSerializers.PHOTOGRAPH_COPYING.get();
    }

    @Override
    public @NotNull class_1799 transferComponents(class_1799 stack, class_1799 recipeResultStack) {
        int generation = stack.method_57825(Exposure.DataComponents.PHOTOGRAPH_GENERATION, 0);
        if (generation < 2) {
            class_1799 result = super.transferComponents(stack, recipeResultStack);
            result.method_57379(Exposure.DataComponents.PHOTOGRAPH_GENERATION, generation + 1);
            return result;
        }

        return class_1799.field_8037;
    }

    @Override
    public @NotNull class_2371<class_1799> getRemainingItems(class_9694 input) {
        class_2371<class_1799> remainingItems = super.method_8111(input);;

        for(int i = 0; i < remainingItems.size(); ++i) {
            class_1799 stack = input.method_59984(i);
            if (stack.method_7909() instanceof PhotographItem) {
                class_1799 remainingPhotographStack = stack.method_7972();
                remainingPhotographStack.method_7939(1);
                remainingItems.set(i, remainingPhotographStack);
            }
        }

        return remainingItems;
    }
}
