package io.github.mortuusars.exposure.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.mortuusars.exposure.world.entity.CameraOperator;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 {
    public LivingEntityMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyReturnValue(method = "getMaxHeadRotationRelativeToBody", at = @At("RETURN"))
    private float onGetMaxHeadRotationRelativeToBody(float original) {
        if (this instanceof CameraOperator operator && operator.getActiveExposureCamera() != null) {
            return Math.min(original, 20);
        }
        return original;
    }
}
