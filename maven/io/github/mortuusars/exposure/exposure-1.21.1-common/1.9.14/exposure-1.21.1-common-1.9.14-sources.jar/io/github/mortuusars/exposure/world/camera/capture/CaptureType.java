package io.github.mortuusars.exposure.world.camera.capture;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_2960;

public class CaptureType {
    public static final class_2960 CAMERA = Exposure.resource("camera");
    public static final class_2960 LOAD_COMMAND = Exposure.resource("load_command");
    public static final class_2960 EXPOSE_COMMAND = Exposure.resource("expose_command");
    public static final class_2960 DEBUG_RGB = Exposure.resource("debug_rgb");
}
