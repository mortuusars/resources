package io.github.mortuusars.exposure.client.capture.action;

import net.minecraft.class_310;
import net.minecraft.class_5498;

public class ForceCameraTypeAction implements CaptureAction {
    private final class_5498 forcedCameraType;
    private class_5498 cameraTypeBeforeCapture = class_5498.field_26664;

    public ForceCameraTypeAction(class_5498 forcedCameraType) {
        this.forcedCameraType = forcedCameraType;
    }

    @Override
    public void beforeCapture() {
        cameraTypeBeforeCapture = class_310.method_1551().field_1690.method_31044();
        class_310.method_1551().field_1690.method_31043(forcedCameraType);
    }

    @Override
    public void afterCapture() {
        class_310.method_1551().field_1690.method_31043(cameraTypeBeforeCapture);
    }
}
