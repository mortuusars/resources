package io.github.mortuusars.exposure.commands.exposure;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.data.export.ExportSize;
import io.github.mortuusars.exposure.commands.argument.ExposureLookArgument;
import io.github.mortuusars.exposure.commands.argument.SizeMultiplierArgument;
import io.github.mortuusars.exposure.commands.suggestion.ExposureIdSuggestionProvider;
import io.github.mortuusars.exposure.data.export.ExportLook;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.clientbound.ExportS2CP;
import io.github.mortuusars.exposure.network.packet.clientbound.ExportStopS2CP;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_2168;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class ExportCommand {
    public static LiteralArgumentBuilder<class_2168> get() {
        return method_9247("export")
                .requires((stack) -> stack.method_9259(3))
                .then(id())
                .then(all())
                .then(method_9247("stop")
                        .executes(context -> {
                            Packets.sendToClient(ExportStopS2CP.INSTANCE, context.getSource().method_9207());
                            return 0;
                        }));
    }

    private static ArgumentBuilder<class_2168, ?> id() {
        return method_9247("id")
                .then(method_9244("id", StringArgumentType.string())
                        .suggests(new ExposureIdSuggestionProvider())
                        .executes(context -> exportExposures(context.getSource(),
                                List.of(StringArgumentType.getString(context, "id")),
                                ExportSize.X1,
                                ExportLook.REGULAR))
                        .then(method_9244("size", new SizeMultiplierArgument())
                                .executes(context -> exportExposures(context.getSource(),
                                        List.of(StringArgumentType.getString(context, "id")),
                                        SizeMultiplierArgument.getSize(context, "size"),
                                        ExportLook.REGULAR))
                                .then(method_9244("look", new ExposureLookArgument())
                                        .executes(context -> exportExposures(context.getSource(),
                                                List.of(StringArgumentType.getString(context, "id")),
                                                SizeMultiplierArgument.getSize(context, "size"),
                                                ExposureLookArgument.getLook(context, "look"))))));
    }

    private static ArgumentBuilder<class_2168, ?> all() {
        return method_9247("all")
                .executes(context -> exportAll(context.getSource(), ExportSize.X1, ExportLook.REGULAR))
                .then(method_9244("size", new SizeMultiplierArgument())
                        .executes(context -> exportAll(context.getSource(),
                                SizeMultiplierArgument.getSize(context, "size"),
                                ExportLook.REGULAR))
                        .then(method_9244("look", new ExposureLookArgument())
                                .executes(context -> exportAll(context.getSource(),
                                        SizeMultiplierArgument.getSize(context, "size"),
                                        ExposureLookArgument.getLook(context, "look")))));
    }

    private static int exportAll(class_2168 stack, ExportSize size, ExportLook look) throws CommandSyntaxException {
        List<String> ids = ExposureServer.exposureRepository().getAllIds();
        return confirmExportAll(stack, ids, size, look) ? exportExposures(stack, ids, size, look) : 0;
    }

    private static final Map<Integer, Long> EXPORT_CONFIRMATIONS = new HashMap<>();

    private static boolean confirmExportAll(class_2168 stack, List<String> ids, ExportSize size, ExportLook look) throws CommandSyntaxException {
        class_3222 player = stack.method_9207();
        int count = ids.size();

        if (count < 50) return true;

        @Nullable Long timestamp = EXPORT_CONFIRMATIONS.get(player.method_5628());
        boolean confirmed = timestamp != null && player.method_37908().method_8510() - timestamp < 6000; // 5 minutes

        if (!confirmed) {
            EXPORT_CONFIRMATIONS.put(player.method_5628(), player.method_37908().method_8510());
            stack.method_9226(() -> class_2561.method_43469("command.exposure.export.confirmation", count)
                    .method_27696(class_2583.field_24360.method_36139(0xffe5e3))
                    .method_10852(class_2561.method_43471("command.exposure.export.confirm")
                            .method_27696(class_2583.field_24360.method_36139(0xff7369)
                                    .method_30938(true)
                                    .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43471("command.exposure.export.confirm.tooltip")))
                                    .method_10958(new class_2558(class_2558.class_2559.field_11750,
                                            "/exposure export all " + size.method_15434() + " " + look.method_15434())))), true);
            return false;
        }

        EXPORT_CONFIRMATIONS.remove(player.method_5628());
        return true;
    }

    private static int exportExposures(class_2168 stack, List<String> exposureIds, ExportSize size, ExportLook look) throws CommandSyntaxException {
        class_3222 player = stack.method_9207();
        Packets.sendToClient(new ExportS2CP(exposureIds, size, look), player);
        return 0;
    }
}
