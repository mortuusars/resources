package io.github.mortuusars.exposure.world.item.component.album;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record AlbumPage(class_1799 photograph, String note) {
    public static final Codec<AlbumPage> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_1799.field_49266.optionalFieldOf("photograph", class_1799.field_8037).forGetter(AlbumPage::photograph),
            Codec.string(0, 512).optionalFieldOf("note", "").forGetter(AlbumPage::note)
    ).apply(instance, AlbumPage::new));

    public static final class_9139<class_9129, AlbumPage> STREAM_CODEC = class_9139.method_56435(
            class_1799.field_49268, AlbumPage::photograph,
            class_9135.field_48554, AlbumPage::note,
            AlbumPage::new
    );

    public static final AlbumPage EMPTY = new AlbumPage(class_1799.field_8037, "");

    public boolean isEmpty() {
        return photograph().method_7960() && note().isEmpty();
    }

    public AlbumPage setPhotograph(class_1799 stack) {
        return new AlbumPage(stack, note);
    }

    public AlbumPage setNote(String note) {
        return new AlbumPage(photograph, note);
    }

    public SignedAlbumPage convertToSigned() {
        return new SignedAlbumPage(photograph, class_2561.method_43470(note));
    }
}
