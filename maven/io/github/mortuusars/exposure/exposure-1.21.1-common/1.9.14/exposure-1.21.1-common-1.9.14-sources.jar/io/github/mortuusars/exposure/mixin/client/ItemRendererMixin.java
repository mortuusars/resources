package io.github.mortuusars.exposure.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.PlatformHelperClient;
import io.github.mortuusars.exposure.client.render.model.CameraModel;
import io.github.mortuusars.exposure.client.util.Minecrft;
import net.minecraft.class_1087;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_638;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_918.class)
public abstract class ItemRendererMixin {
    @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true)
    class_1087 renderItem(class_1087 model, class_1799 stack, class_811 displayContext, boolean leftHand,
                          class_4587 poseStack, class_4597 buffer, int combinedLight, int combinedOverlay) {
        if (class_310.method_1551().field_1687 == null) return model;
        if (!stack.method_31574(Exposure.Items.CAMERA.get())) return model;

        if (displayContext == class_811.field_4317) {
            class_1087 guiModel = PlatformHelperClient.getModel(ExposureClient.Models.CAMERA_GUI);
            return guiModel.method_4710().method_3495(guiModel, stack, Minecrft.level(), Minecrft.player(), 0);
        }

        return model;
    }

    @ModifyReturnValue(method = "getModel", at = @At(value = "RETURN"))
    private class_1087 getModel(class_1087 original, @Local(argsOnly = true) class_1799 stack, @Local(argsOnly = true) @Nullable class_1937 level, @Local(argsOnly = true) @Nullable class_1309 entity, @Local(argsOnly = true) int seed) {
        if (stack.method_31574(Exposure.Items.CAMERA.get())) {
            @Nullable class_638 clientLevel = level instanceof class_638 lv ? lv : null;
            return CameraModel.modifyCameraModel(stack, clientLevel, entity, seed, original);
        }

        return original;
    }
}
