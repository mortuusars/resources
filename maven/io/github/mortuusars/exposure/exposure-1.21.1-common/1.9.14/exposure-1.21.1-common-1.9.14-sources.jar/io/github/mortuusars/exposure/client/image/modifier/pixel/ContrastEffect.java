package io.github.mortuusars.exposure.client.image.modifier.pixel;

import com.google.common.base.Preconditions;
import net.minecraft.class_3532;
import net.minecraft.class_5253;

public class ContrastEffect implements PixelEffect {
    protected final float contrast;

    /**
     * @param contrast 0 means no change.
     */
    public ContrastEffect(float contrast) {
        Preconditions.checkArgument(contrast >= -1 && contrast <= 1, "contrast must be in -1 to 1 range.");
        this.contrast = contrast;
    }

    @Override
    public String getIdentifier() {
        return "contrast-" + contrast;
    }

    public int modify(int colorARGB) {
        if (contrast == 0f) return colorARGB;

        int alpha = class_5253.class_5254.method_27762(colorARGB);
        int red = class_5253.class_5254.method_27765(colorARGB);
        int green = class_5253.class_5254.method_27766(colorARGB);
        int blue = class_5253.class_5254.method_27767(colorARGB);

        int contrastValue = Math.round(127 * (1f + contrast));
        red = class_3532.method_15340((red - 127) * contrastValue / 127 + 127, 0, 255);
        green = class_3532.method_15340((green - 127) * contrastValue / 127 + 127, 0, 255);
        blue = class_3532.method_15340((blue - 127) * contrastValue / 127 + 127, 0, 255);

        return class_5253.class_5254.method_27764(alpha, red, green, blue);
    }

    @Override
    public String toString() {
        return "Contrast{contrast=" + contrast + "}";
    }
}
