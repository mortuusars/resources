package io.github.mortuusars.exposure.client.render.texture;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.util.color.Color;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_757;
import org.joml.Matrix4f;

public class TextureRenderer {
    public static void render(class_4587 poseStack, class_4597 bufferSource, class_2960 texture,
                              int packedLight, Color color) {
        render(poseStack, bufferSource, texture, packedLight, color.getR(), color.getG(), color.getB(), color.getA());
    }

    public static void render(class_4587 poseStack, class_4597 bufferSource, class_2960 texture,
                              int packedLight, int r, int g, int b, int a) {
        render(poseStack, bufferSource, texture, 0, 0, 1, 1, packedLight, r, g, b, a);
    }

    public static void render(class_4587 poseStack, class_4597 bufferSource, class_2960 texture,
                              float x, float y, float width, float height, int packedLight, int r, int g, int b, int a) {
        render(poseStack, bufferSource, texture, x, y, x + width, y + height,
                0, 0, 1, 1, packedLight, r, g, b, a);
    }

    public static void render(class_4587 poseStack, class_4597 bufferSource, class_2960 texture,
                              float minX, float minY, float maxX, float maxY,
                              float minU, float minV, float maxU, float maxV, int packedLight, int r, int g, int b, int a) {
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShader(class_757::method_34548);
        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();

        Matrix4f matrix = poseStack.method_23760().method_23761();
        class_4588 bufferBuilder = bufferSource.getBuffer(class_1921.method_23028(texture));
        bufferBuilder.method_22918(matrix, minX, maxY, 0).method_1336(r, g, b, a).method_22913(minU, maxV).method_60803(packedLight);
        bufferBuilder.method_22918(matrix, maxX, maxY, 0).method_1336(r, g, b, a).method_22913(maxU, maxV).method_60803(packedLight);
        bufferBuilder.method_22918(matrix, maxX, minY, 0).method_1336(r, g, b, a).method_22913(maxU, minV).method_60803(packedLight);
        bufferBuilder.method_22918(matrix, minX, minY, 0).method_1336(r, g, b, a).method_22913(minU, minV).method_60803(packedLight);
    }
}
