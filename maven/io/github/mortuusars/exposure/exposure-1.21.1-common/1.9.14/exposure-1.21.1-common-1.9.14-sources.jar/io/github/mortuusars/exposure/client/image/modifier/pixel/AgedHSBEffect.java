package io.github.mortuusars.exposure.client.image.modifier.pixel;

import io.github.mortuusars.exposure.util.color.Color;
import net.minecraft.class_3532;
import net.minecraft.class_5253;

public class AgedHSBEffect implements PixelEffect {
    protected final int tintColor;
    protected final float tintOpacity;
    protected final int blackPoint;
    protected final int whitePoint;

    /**
     * @param tintColor in 0xXXXXXX rgb format. Only rightmost 24 bits would be used, anything extra will be discarded.
     * @param tintOpacity ratio of the original color to tint color. Like a layer opacity.
     * @param blackPoint Like in a Levels adjustment. 0-255.
     * @param whitePoint Like in a Levels adjustment. 0-255.
     */
    public AgedHSBEffect(int tintColor, float tintOpacity, int blackPoint, int whitePoint) {
        this.tintColor = tintColor;
        this.tintOpacity = tintOpacity;
        this.blackPoint = blackPoint & 0xFF; // 0-255
        this.whitePoint = whitePoint & 0xFF; // 0-255
    }

    @Override
    public String getIdentifier() {
        return "aged";
    }

    public int modify(int ARGB) {
        int alpha = class_5253.class_5254.method_27762(ARGB);
        int red = class_5253.class_5254.method_27765(ARGB);
        int green = class_5253.class_5254.method_27766(ARGB);
        int blue = class_5253.class_5254.method_27767(ARGB);

        // Modify black and white points to make the image appear faded:
        red = (int) class_3532.method_37959(red, 0, 255, blackPoint, whitePoint);
        green = (int) class_3532.method_37959(green, 0, 255, blackPoint, whitePoint);
        blue = (int) class_3532.method_37959(blue, 0, 255, blackPoint, whitePoint);

        float[] baseHSB = new float[3];
        Color.HSB.RGBtoHSB(red, green, blue, baseHSB);

        float[] tintHSB = new float[3];
        Color.HSB.RGBtoHSB(class_5253.class_5254.method_27765(tintColor), class_5253.class_5254.method_27766(tintColor), class_5253.class_5254.method_27767(tintColor), tintHSB);

        // Luma is brighter than it would have been originally, but brighter looks better.
        int luma = class_3532.method_15340((int) (0.45 * red + 0.65 * green + 0.2 * blue), 0, 255);
        int tintedRGB = Color.HSB.HSBtoRGB(tintHSB[0], tintHSB[1], luma / 255f);

        // Blend two colors together:
        int newBlue = class_3532.method_15340((int) class_3532.method_16439(tintOpacity, blue, class_5253.class_5254.method_27767(tintedRGB)), 0, 255);
        int newGreen = class_3532.method_15340((int) class_3532.method_16439(tintOpacity, green, class_5253.class_5254.method_27766(tintedRGB)), 0, 255);
        int newRed = class_3532.method_15340((int) class_3532.method_16439(tintOpacity, red, class_5253.class_5254.method_27765(tintedRGB)), 0, 255);

        return class_5253.class_5254.method_27764(alpha, newRed, newGreen, newBlue);
    }

    @Override
    public String toString() {
        return "AgedHSBPixelModifier{" +
                "tintColor=#" + Integer.toHexString(tintColor) +
                ", tintOpacity=" + tintOpacity +
                ", blackPoint=" + blackPoint +
                ", whitePoint=" + whitePoint +
                '}';
    }
}
