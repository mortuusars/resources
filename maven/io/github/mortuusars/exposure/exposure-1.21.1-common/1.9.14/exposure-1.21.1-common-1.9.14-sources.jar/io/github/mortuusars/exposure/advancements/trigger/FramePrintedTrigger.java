package io.github.mortuusars.exposure.advancements.trigger;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.advancements.predicate.FramePredicate;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_1799;
import net.minecraft.class_2048;
import net.minecraft.class_2073;
import net.minecraft.class_2090;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public class FramePrintedTrigger extends class_4558<FramePrintedTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player,
                        class_2338 pos,
                        Frame frame,
                        class_1799 result) {
        this.method_22510(player, triggerInstance ->
                triggerInstance.matches(player, pos, frame, result));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  Optional<class_2090> location,
                                  Optional<FramePredicate> frame,
                                  Optional<class_2073> item) implements SimpleInstance {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                        class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::player),
                        class_2090.field_45760.optionalFieldOf("location").forGetter(TriggerInstance::location),
                        FramePredicate.field_49805.optionalFieldOf("frame").forGetter(TriggerInstance::frame),
                        class_2073.field_45754.optionalFieldOf("item").forGetter(TriggerInstance::item))
                .apply(instance, TriggerInstance::new));

        public boolean matches(class_3222 player,
                               class_2338 pos,
                               Frame frame,
                               class_1799 result) {
            return (location.isEmpty() || location.get().method_9018(player.method_51469(), pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5))
                    && (this.frame.isEmpty() || this.frame.get().matches(frame))
                    && (item.isEmpty() || item.get().method_8970(result));
        }
    }
}