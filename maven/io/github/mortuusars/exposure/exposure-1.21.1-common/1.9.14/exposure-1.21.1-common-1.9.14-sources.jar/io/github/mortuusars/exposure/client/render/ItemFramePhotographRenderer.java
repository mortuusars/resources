package io.github.mortuusars.exposure.client.render;

import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import net.minecraft.class_1299;
import net.minecraft.class_1533;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_7923;

public class ItemFramePhotographRenderer {
    public static void render(class_1533 itemFrame, class_4587 poseStack, class_4597 bufferSource,
                                 int packedLight, PhotographItem item, class_1799 stack) {
        if (itemFrame.method_5864() == class_1299.field_28401)
            packedLight = class_765.field_32767;

        poseStack.method_22903();

        String entityName = class_7923.field_41177.method_10221(itemFrame.method_5864()).toString();
        if (entityName.equals("quark:glass_frame")) {
            poseStack.method_46416(0, 0, 0.475f);
        }

        // Snap to 90 degrees like a map.
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(45 * itemFrame.method_6934()));

        float pixelSize = 0.0625f;
        float scale = 1f - pixelSize * 6; // 3px from each side

        poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
        poseStack.method_22905(scale, scale, scale);
        poseStack.method_22904(-0.5, -0.5, 0.045);

        ExposureClient.photographRenderer().renderPhotograph(poseStack, bufferSource, item, stack,
                false, false, packedLight, 255, 255, 255, 255);

        poseStack.method_22909();
    }
}
