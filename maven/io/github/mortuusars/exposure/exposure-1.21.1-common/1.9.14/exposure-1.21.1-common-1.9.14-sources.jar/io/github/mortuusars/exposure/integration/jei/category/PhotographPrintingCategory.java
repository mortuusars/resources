package io.github.mortuusars.exposure.integration.jei.category;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.integration.jei.ExposureJeiPlugin;
import io.github.mortuusars.exposure.integration.jei.recipe.PhotographPrintingJeiRecipe;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableStatic;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_7923;
import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class PhotographPrintingCategory implements IRecipeCategory<PhotographPrintingJeiRecipe> {
    private static final class_2960 TEXTURE = Exposure.resource("textures/gui/jei/photograph_printing.png");
    private final class_2561 title;
    private final IDrawable background;
    private final IDrawable icon;
    private final IDrawableStatic filmDrawable;

    public PhotographPrintingCategory(IGuiHelper guiHelper) {
        title = class_2561.method_43471("jei.exposure.photograph_printing.title");
        background = guiHelper.createDrawable(TEXTURE, 0, 0, 170, 80);
        icon = guiHelper.createDrawableIngredient(VanillaTypes.ITEM_STACK, new class_1799(Exposure.Items.LIGHTROOM.get()));

        filmDrawable = guiHelper.createDrawable(TEXTURE, 0, 80, 170, 80);
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, @NotNull PhotographPrintingJeiRecipe recipe, @NotNull IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 78, 17)
                .addItemStack(new class_1799(recipe.getExposureType() == ExposureType.COLOR ?
                        Exposure.Items.DEVELOPED_COLOR_FILM.get()
                        : Exposure.Items.DEVELOPED_BLACK_AND_WHITE_FILM.get()))
                .setSlotName("Film");


        List<class_1799> papers = class_7923.field_41178.method_40266(Exposure.Tags.Items.PHOTO_PAPERS)
                .map(holders -> holders.method_40239()
                        .map(itemHolder -> new class_1799(itemHolder.comp_349())).collect(Collectors.toList()))
                .orElse(Collections.emptyList());

        builder.addSlot(RecipeIngredientRole.CATALYST, 6, 55)
                .addItemStacks(papers)
                .setSlotName("Paper");

        if (recipe.getExposureType() == ExposureType.COLOR) {
            List<class_1799> cyanDyes = class_7923.field_41178.method_40266(Exposure.Tags.Items.CYAN_PRINTING_DYES)
                    .map(holders -> holders.method_40239()
                            .map(itemHolder -> new class_1799(itemHolder.comp_349())).collect(Collectors.toList()))
                    .orElse(Collections.emptyList());

            builder.addSlot(RecipeIngredientRole.CATALYST, 40, 55)
                    .addItemStacks(cyanDyes)
                    .setSlotName("Cyan");

            List<class_1799> magentaDyes = class_7923.field_41178.method_40266(Exposure.Tags.Items.MAGENTA_PRINTING_DYES)
                    .map(holders -> holders.method_40239()
                            .map(itemHolder -> new class_1799(itemHolder.comp_349())).collect(Collectors.toList()))
                    .orElse(Collections.emptyList());

            builder.addSlot(RecipeIngredientRole.CATALYST, 58, 55)
                    .addItemStacks(magentaDyes)
                    .setSlotName("Magenta");

            List<class_1799> yellowDyes = class_7923.field_41178.method_40266(Exposure.Tags.Items.YELLOW_PRINTING_DYES)
                    .map(holders -> holders.method_40239()
                            .map(itemHolder -> new class_1799(itemHolder.comp_349())).collect(Collectors.toList()))
                    .orElse(Collections.emptyList());

            builder.addSlot(RecipeIngredientRole.CATALYST, 76, 55)
                    .addItemStacks(yellowDyes)
                    .setSlotName("Yellow");
        }

        List<class_1799> blackDyes = class_7923.field_41178.method_40266(Exposure.Tags.Items.BLACK_PRINTING_DYES)
                .map(holders -> holders.method_40239()
                        .map(itemHolder -> new class_1799(itemHolder.comp_349())).collect(Collectors.toList()))
                .orElse(Collections.emptyList());

        builder.addSlot(RecipeIngredientRole.CATALYST, 94, 55)
                .addItemStacks(blackDyes)
                .setSlotName("Black");

        class_1799 resultItemStack = new class_1799(Exposure.Items.PHOTOGRAPH.get());
        resultItemStack.method_57379(Exposure.DataComponents.PHOTOGRAPH_TYPE, recipe.getExposureType());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 144, 55).addItemStack(resultItemStack);
    }

    @Override
    public void draw(PhotographPrintingJeiRecipe recipe, @NotNull IRecipeSlotsView recipeSlotsView, @NotNull class_332 guiGraphics, double mouseX, double mouseY) {
        if (recipe.getExposureType() == ExposureType.COLOR) {
            RenderSystem.setShaderColor(1.1F, 0.86F, 0.66F, 1F);
        }
        filmDrawable.draw(guiGraphics);
        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
    }

    @Override
    public @NotNull RecipeType<PhotographPrintingJeiRecipe> getRecipeType() {
        return ExposureJeiPlugin.PHOTOGRAPH_PRINTING_RECIPE_TYPE;
    }

    @Override
    public @NotNull class_2561 getTitle() {
        return title;
    }

    @SuppressWarnings("removal")
    @Override
    public @NotNull IDrawable getBackground() {
        return background;
    }

    @Override
    public @NotNull IDrawable getIcon() {
        return icon;
    }
}