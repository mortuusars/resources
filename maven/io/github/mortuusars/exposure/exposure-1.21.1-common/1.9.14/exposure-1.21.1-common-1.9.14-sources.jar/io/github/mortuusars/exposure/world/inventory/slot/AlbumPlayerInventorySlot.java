package io.github.mortuusars.exposure.world.inventory.slot;

import net.minecraft.class_1263;
import net.minecraft.class_1735;

public class AlbumPlayerInventorySlot extends class_1735 {
    protected boolean isActive;

    public AlbumPlayerInventorySlot(class_1263 container, int slot, int x, int y) {
        super(container, slot, x, y);
    }

    @Override
    public boolean method_7682() {
        return isActive;
    }

    public void setActive(boolean value) {
        isActive = value;
    }
}
