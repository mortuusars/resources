package io.github.mortuusars.exposure.world.inventory;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3913;
import net.minecraft.class_3919;
import net.minecraft.class_9129;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.NotNull;

public class LecternAlbumMenu extends class_1703 {
    public static final int BUTTON_PREV_PAGE = 1;
    public static final int BUTTON_NEXT_PAGE = 2;
    public static final int BUTTON_TAKE_BOOK = 3;
    public static final int BUTTON_PAGE_JUMP_RANGE_START = 100;

    private static final int SLOT_COUNT = 1;
    private static final int DATA_COUNT = 1;

    protected final class_1263 container;
    protected final class_3913 data;

    public LecternAlbumMenu(int containerId, class_1661 playerInventory, class_1263 container, class_3913 data) {
        super(Exposure.MenuTypes.LECTERN_ALBUM.get(), containerId);
        this.container = container;
        this.data = data;

        method_17359(container, SLOT_COUNT);
        method_17361(data, DATA_COUNT);

        this.method_7621(new class_1735(container, 0, -999, -999) {
            @Override
            public void method_7668() {
                super.method_7668();
                LecternAlbumMenu.this.method_7609(this.field_7871);
            }
        });
        this.method_17360(data);
    }

    public LecternAlbumMenu(int containerId, class_1661 playerInventory, class_9129 buffer) {
        this(containerId, playerInventory, new class_1277(SLOT_COUNT), new class_3919(DATA_COUNT));
        class_1799 book = class_1799.field_49268.decode(buffer);
        container.method_5447(0, book);
    }


    public class_1799 getBook() {
        return this.container.method_5438(0);
    }

    public int getPage() {
        return this.data.method_17390(0);
    }

    @Override
    public void method_7606(int id, int data) {
        super.method_7606(id, data);
        this.method_7623();
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (id >= BUTTON_PAGE_JUMP_RANGE_START) {
            int pageIndex = id - BUTTON_PAGE_JUMP_RANGE_START;
            this.method_7606(0, pageIndex);
            return true;
        }

        switch (id) {
            case BUTTON_PREV_PAGE: {
                int i = this.data.method_17390(0);
                this.method_7606(0, i - 1);
                return true;
            }
            case BUTTON_NEXT_PAGE: {
                int i = this.data.method_17390(0);
                this.method_7606(0, i + 1);
                return true;
            }
            case BUTTON_TAKE_BOOK: {
                if (!player.method_7294()) {
                    return false;
                }

                class_1799 itemStack = this.container.method_5441(0);
                this.container.method_5431();
                if (!player.method_31548().method_7394(itemStack)) {
                    player.method_7328(itemStack, false);
                }

                return true;
            }
        }

        return false;
    }

    @Override
    public @NotNull class_1799 method_7601(class_1657 player, int index) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return container.method_5443(player);
    }
}
