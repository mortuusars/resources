package io.github.mortuusars.exposure.mixin.client;

import io.github.mortuusars.exposure.client.input.MouseHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1297.class)
public abstract class EntityMixin {
    @Shadow public abstract class_1937 level();

    @Inject(method = "turn", at = @At("HEAD"), cancellable = true)
    private void onTurn(double yRot, double xRot, CallbackInfo ci) {
        if (level().field_9236 && MouseHandler.onTurnPlayer(xRot, yRot)) {
            ci.cancel();
        }
    }
}
