package io.github.mortuusars.exposure.commands.argument;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;
import net.minecraft.class_2172;
import net.minecraft.class_2232;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class TextureLocationArgument extends class_2232 {
    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return class_2172.method_9257(getTextureLocations(), builder);
    }

    private static Stream<class_2960> getTextureLocations() {
        return class_310.method_1551().method_1478()
                .method_14488("textures", rl -> true)
                .keySet()
                .stream();
    }
}
