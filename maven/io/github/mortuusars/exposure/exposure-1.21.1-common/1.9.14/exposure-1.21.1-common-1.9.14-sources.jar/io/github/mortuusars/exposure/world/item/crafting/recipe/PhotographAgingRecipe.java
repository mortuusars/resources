package io.github.mortuusars.exposure.world.item.crafting.recipe;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2371;
import net.minecraft.class_7710;
import net.minecraft.class_8162;
import net.minecraft.class_9694;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.NotNull;

public class PhotographAgingRecipe extends ComponentTransferringRecipe {
    public PhotographAgingRecipe(class_7710 category, class_1856 sourceIngredient,
                                 class_2371<class_1856> ingredients, class_1799 result) {
        super(category, sourceIngredient, ingredients, result);
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return Exposure.RecipeSerializers.PHOTOGRAPH_AGING.get();
    }

    @Override
    public @NotNull class_2371<class_1799> getRemainingItems(class_9694 input) {
        class_2371<class_1799> remainingItems = super.method_8111(input);

        for (int i = 0; i < input.method_59983(); ++i) {
            class_1799 stack = input.method_59984(i);
            if (stack.method_7909() instanceof class_8162) {
                stack = stack.method_7972();
                int damage = stack.method_7919() + 1;
                stack.method_7974(damage);
                if (damage >= stack.method_7936()) {
                    stack.method_7934(1);
                }
                remainingItems.set(i, stack);
            }
        }

        return remainingItems;
    }
}
