package io.github.mortuusars.exposure.world.entity;

import net.minecraft.class_2487;

public class CameraStandRedstoneControl {
    public int delay = 2;

    protected CameraStandEntity stand;

    protected boolean hasSignal;
    protected int releaseDelay;

    public CameraStandRedstoneControl(CameraStandEntity stand) {
        this.stand = stand;
    }

    /**
     * @return 'true' if shutter was released.
     */
    public boolean tick() {
        boolean hasSignal = stand.method_37908().method_49803(stand.method_24515());

        if (hasSignal && !this.hasSignal && releaseDelay <= 0) {
            releaseDelay = delay; // Start delay countdown when receiving a new pulse
            // Delay helps to resolve some visual issues. Redstone will lit up on the client in that time, for example.
        }

        boolean released = false;

        if (releaseDelay > 0) {
            releaseDelay--;
            if (releaseDelay == 0) {
                stand.release(); // Due to release delay, shortest time between releases seems to be 3 ticks instead of default 2-tick cooldown.
                released = true;
            }
        }

        this.hasSignal = hasSignal;
        return released;
    }

    public void load(class_2487 tag) {
        hasSignal = tag.method_10577("HasRedstoneSignal");
        releaseDelay = tag.method_10550("RedstoneReleaseDelay");
    }

    public void save(class_2487 tag) {
        tag.method_10556("HasRedstoneSignal", hasSignal);
        tag.method_10569("RedstoneReleaseDelay", releaseDelay);
    }
}
