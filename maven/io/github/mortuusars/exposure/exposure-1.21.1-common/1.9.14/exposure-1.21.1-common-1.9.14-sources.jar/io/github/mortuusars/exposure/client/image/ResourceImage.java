package io.github.mortuusars.exposure.client.image;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.client.image.renderable.RenderableImage;
import io.github.mortuusars.exposure.client.image.renderable.RenderableImageIdentifier;
import io.github.mortuusars.exposure.util.color.Color;
import net.minecraft.class_1011;
import net.minecraft.class_1044;
import net.minecraft.class_1049;
import net.minecraft.class_1060;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.client.renderer.texture.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.util.concurrent.Executor;

public class ResourceImage extends class_1049 implements RenderableImage {
    @Nullable
    protected class_1011 image;

    public ResourceImage(class_2960 location) {
        super(location);
    }

    public static @NotNull RenderableImage getOrCreate(class_2960 location) {
        class_1060 textureManager = class_310.method_1551().method_1531();

        @Nullable class_1044 existingTexture = textureManager.field_5286.get(location);
        if (existingTexture instanceof ResourceImage resourceImage) {
            return resourceImage;
        }

        try {
            ResourceImage texture = new ResourceImage(location);
            textureManager.method_4616(location, texture);
            return texture;
        }
        catch (Exception e) {
            Exposure.LOGGER.error("Cannot load texture [{}]. {}", location, e);
            return RenderableImage.MISSING;
        }
    }

    @Override
    public int width() {
        @Nullable class_1011 image = getNativeImage();
        return image != null ? image.method_4307() : 1;
    }

    @Override
    public int height() {
        @Nullable class_1011 image = getNativeImage();
        return image != null ? image.method_4323() : 1;
    }

    @Override
    public int getPixelARGB(int x, int y) {
        @Nullable class_1011 image = getNativeImage();
        return image != null ? Color.ABGRtoARGB(image.method_4315(x, y)) : 0x00000000;
    }

    public @Nullable class_1011 getNativeImage() {
        if (this.image != null)
            return image;

        try {
            class_1011 image = super.method_18153(class_310.method_1551().method_1478()).method_18157();
            this.image = image;
            return image;
        } catch (IOException e) {
            Exposure.LOGGER.error("Cannot load texture: {}", e.toString());
            return null;
        }
    }

    @Override
    public void method_18169(@NotNull class_1060 textureManager, @NotNull class_3300 resourceManager,
                      @NotNull class_2960 path, @NotNull Executor executor) {
        super.method_18169(textureManager, resourceManager, path, executor);
        if (image != null) {
            image.close();
            image = null;
        }
    }

    @Override
    public void close() {
        super.close();

        if (this.image != null) {
            image.close();
            image = null;
        }
    }

    @Override
    public Image getImage() {
        return this;
    }

    @Override
    public RenderableImageIdentifier getIdentifier() {
        return new RenderableImageIdentifier(field_5224.toString());
    }
}
