package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.exposure.client.sound.UniqueSoundManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public record UniqueSoundPlayS2CP(String id, int entityId, class_3414 sound, class_3419 source,
                                  float volume, float pitch) implements Packet {
    public static final class_2960 ID = Exposure.resource("unique_sound_play");
    public static final class_8710.class_9154<UniqueSoundPlayS2CP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_9129, UniqueSoundPlayS2CP> STREAM_CODEC = class_9139.method_58025(
            class_9135.field_48554, UniqueSoundPlayS2CP::id,
            class_9135.field_48550, UniqueSoundPlayS2CP::entityId,
            class_3414.field_48278, UniqueSoundPlayS2CP::sound,
            class_9135.method_56375(i -> class_3419.values()[i], class_3419::ordinal), UniqueSoundPlayS2CP::source,
            class_9135.field_48552, UniqueSoundPlayS2CP::volume,
            class_9135.field_48552, UniqueSoundPlayS2CP::pitch,
            UniqueSoundPlayS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        @Nullable class_1297 entity = player.method_37908().method_8469(entityId);
        if (entity != null) {
            UniqueSoundManager.play(id, entity, sound, source, volume, pitch);
        }

        return true;
    }
}
