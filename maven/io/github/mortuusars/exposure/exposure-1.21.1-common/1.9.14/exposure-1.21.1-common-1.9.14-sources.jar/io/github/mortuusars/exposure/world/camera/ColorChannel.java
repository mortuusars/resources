package io.github.mortuusars.exposure.world.camera;

import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.Exposure;
import io.netty.buffer.ByteBuf;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3542;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public enum ColorChannel implements class_3542 {
    RED(0xFFD8523E),
    GREEN(0xFF7BC64B),
    BLUE(0xFF4E73CE);

    public static final Codec<ColorChannel> CODEC = class_3542.method_28140(ColorChannel::values);
    public static final class_9139<ByteBuf, ColorChannel> STREAM_CODEC =
            class_9135.method_56375(id -> ColorChannel.values()[id], ColorChannel::ordinal);

    // Used in UI to color text, etc.
    private final int color;

    ColorChannel(int color) {
        this.color = color;
    }

    public int getRepresentationColor() {
        return color;
    }

    public static Optional<ColorChannel> fromFilterStack(class_1799 stack) {
        if (stack.method_31573(Exposure.Tags.Items.RED_FILTERS))
            return Optional.of(RED);
        else if (stack.method_31573(Exposure.Tags.Items.GREEN_FILTERS))
            return Optional.of(GREEN);
        else if (stack.method_31573(Exposure.Tags.Items.BLUE_FILTERS))
            return Optional.of(BLUE);
        else
            return Optional.empty();
    }

    public static ColorChannel fromStringOrDefault(String serializedName, ColorChannel defaultValue) {
        for (ColorChannel value : values()) {
            if (value.method_15434().equals(serializedName))
                return value;
        }
        return defaultValue;
    }

    public static Optional<ColorChannel> fromStringOptional(String serializedName) {
        for (ColorChannel value : values()) {
            if (value.method_15434().equals(serializedName))
                return Optional.of(value);
        }
        return Optional.empty();
    }

    public static ColorChannel fromStringOrThrow(String serializedName) {
        for (ColorChannel value : values()) {
            if (value.method_15434().equals(serializedName))
                return value;
        }
        throw new IllegalArgumentException(serializedName + " is not a valid ColorChannel.");
    }

    @Override
    public @NotNull String method_15434() {
        return toString().toLowerCase();
    }

    public class_2960 getShader() {
        return Exposure.resource("shaders/" + method_15434() + "_filter.json");
    }
}
