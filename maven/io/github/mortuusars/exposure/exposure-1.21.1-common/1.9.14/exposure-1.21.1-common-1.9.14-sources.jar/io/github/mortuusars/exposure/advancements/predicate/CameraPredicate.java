package io.github.mortuusars.exposure.advancements.predicate;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.world.item.camera.Attachment;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2073;
import net.minecraft.class_2090;
import net.minecraft.class_243;
import net.minecraft.class_3218;

public record CameraPredicate(Optional<class_2073> camera,
                              Optional<class_2073> film,
                              Optional<class_2073> flash,
                              Optional<class_2073> lens,
                              Optional<class_2073> filter,
                              Optional<class_2090> location) {

    public static final Codec<CameraPredicate> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                    class_2073.field_45754.optionalFieldOf("camera").forGetter(CameraPredicate::camera),
                    class_2073.field_45754.optionalFieldOf("film").forGetter(CameraPredicate::film),
                    class_2073.field_45754.optionalFieldOf("flash").forGetter(CameraPredicate::flash),
                    class_2073.field_45754.optionalFieldOf("lens").forGetter(CameraPredicate::lens),
                    class_2073.field_45754.optionalFieldOf("filter").forGetter(CameraPredicate::filter),
                    class_2090.field_45760.optionalFieldOf("location").forGetter(CameraPredicate::location))
            .apply(instance, CameraPredicate::new));

    public boolean matches(class_3218 level, class_1799 cameraStack, class_243 cameraLocation) {
        if (!(cameraStack.method_7909() instanceof CameraItem)) return false;

        return (camera.isEmpty() || camera.get().method_8970(cameraStack))
                && (film.isEmpty() || film.get().method_8970(Attachment.FILM.get(cameraStack).getForReading()))
                && (flash.isEmpty() || flash.get().method_8970(Attachment.FLASH.get(cameraStack).getForReading()))
                && (lens.isEmpty() || lens.get().method_8970(Attachment.LENS.get(cameraStack).getForReading()))
                && (filter.isEmpty() || filter.get().method_8970(Attachment.FILTER.get(cameraStack).getForReading()))
                && (location.isEmpty() || location.get().method_9018(level, cameraLocation.field_1352, cameraLocation.field_1351, cameraLocation.field_1350));
    }
}
