package io.github.mortuusars.exposure.world.camera;

import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.Exposure;
import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_4844;
import net.minecraft.class_9139;

public record CameraId(UUID uuid) {
    public static final Codec<CameraId> CODEC = class_4844.field_25122.xmap(CameraId::new, CameraId::uuid);
    public static final class_9139<ByteBuf, CameraId> STREAM_CODEC = class_4844.field_48453.method_56432(CameraId::new, CameraId::uuid);

    public static CameraId create() {
        return new CameraId(UUID.randomUUID());
    }

    public static CameraId ofStack(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.CAMERA_ID, new CameraId(class_156.field_25140));
    }

    public boolean matches(class_1799 stack) {
        return equals(stack.method_57824(Exposure.DataComponents.CAMERA_ID));
    }

    @Override
    public String toString() {
        return uuid().toString();
    }
}
