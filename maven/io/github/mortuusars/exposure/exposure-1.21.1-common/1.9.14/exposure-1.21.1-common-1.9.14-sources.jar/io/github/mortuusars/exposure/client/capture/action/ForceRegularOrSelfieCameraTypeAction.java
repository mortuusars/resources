package io.github.mortuusars.exposure.client.capture.action;

import io.github.mortuusars.exposure.world.camera.CameraInHand;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import net.minecraft.class_310;
import net.minecraft.class_5498;
import org.jetbrains.annotations.Nullable;

public class ForceRegularOrSelfieCameraTypeAction implements CaptureAction {
    private final CameraHolder holder;
    private class_5498 cameraTypeBeforeCapture = class_5498.field_26664;

    public ForceRegularOrSelfieCameraTypeAction(CameraHolder holder) {
        this.holder = holder;
    }

    @Override
    public void beforeCapture() {
        cameraTypeBeforeCapture = class_310.method_1551().field_1690.method_31044();
        if (cameraTypeBeforeCapture == class_5498.field_26665) {
            class_310.method_1551().field_1690.method_31043(class_5498.field_26664);
        } else if (cameraTypeBeforeCapture == class_5498.field_26666 && !cameraInHandInSelfieMode()) {
            class_310.method_1551().field_1690.method_31043(class_5498.field_26664);
        }
    }

    protected boolean cameraInHandInSelfieMode() {
        @Nullable CameraInHand camera = CameraInHand.find(holder);
        return camera != null && camera.map(CameraItem::isInSelfieMode).orElse(false);
    }

    @Override
    public void afterCapture() {
        class_310.method_1551().field_1690.method_31043(cameraTypeBeforeCapture);
    }
}
