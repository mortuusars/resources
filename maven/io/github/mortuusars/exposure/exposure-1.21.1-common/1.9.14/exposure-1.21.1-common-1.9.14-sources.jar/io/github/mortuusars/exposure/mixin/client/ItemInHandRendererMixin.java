package io.github.mortuusars.exposure.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.client.camera.CameraClient;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import io.github.mortuusars.exposure.world.item.StackedPhotographsItem;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public abstract class ItemInHandRendererMixin {
    @Shadow
    private class_1799 mainHandItem;
    @Shadow
    private class_1799 offHandItem;
    @Shadow
    protected abstract void renderPlayerArm(class_4587 pMatrixStack, class_4597 pBuffer, int pCombinedLight, float pEquippedProgress, float pSwingProgress, class_1306 pSide);
    @Shadow
    protected abstract float calculateMapTilt(float pPitch);
    @Shadow
    protected abstract void renderMapHand(class_4587 pMatrixStack, class_4597 pBuffer, int pCombinedLight, class_1306 pSide);

    @Inject(method = "renderArmWithItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;isEmpty()Z", ordinal = 0),
            cancellable = true)
    private void renderPhotograph(class_742 player, float partialTicks, float pitch, class_1268 hand,
                                  float swingProgress, class_1799 stack, float equipProgress, class_4587 poseStack,
                                  class_4597 buffer, int combinedLight, CallbackInfo ci, @Local boolean isMainHand, @Local class_1306 arm) {
        if (CameraClient.viewfinder() != null && CameraClient.viewfinder().isLookingThrough()) {
            poseStack.method_22909();
            ci.cancel();
            return;
        }

        if (stack.method_7909() instanceof PhotographItem || stack.method_7909() instanceof StackedPhotographsItem) {
            if (isMainHand && this.offHandItem.method_7960()) {
                exposure$renderTwoHandedPhotograph(player, poseStack, buffer, combinedLight, pitch, equipProgress, swingProgress);
            } else {
                exposure$renderOneHandedPhotograph(player, poseStack, buffer, combinedLight, equipProgress, arm, swingProgress, stack);
            }

            poseStack.method_22909();

            ci.cancel();
        }
    }

    @Unique
    private void exposure$renderOneHandedPhotograph(class_742 player, class_4587 poseStack, class_4597 buffer, int packedLight, float pEquippedProgress, class_1306 pHand, float pSwingProgress, class_1799 stack) {
        float f = pHand == class_1306.field_6183 ? 1.0F : -1.0F;
        poseStack.method_22904(f * 0.125F, -0.125D, 0.0D);
        if (!player.method_5767()) {
            poseStack.method_22903();
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(f * 10.0F));
            this.renderPlayerArm(poseStack, buffer, packedLight, pEquippedProgress, pSwingProgress, pHand);
            poseStack.method_22909();
        }

        poseStack.method_22903();
        poseStack.method_22904(f * 0.51F, -0.08F + pEquippedProgress * -1.2F, -0.75D);
        float f1 = class_3532.method_15355(pSwingProgress);
        float f2 = class_3532.method_15374(f1 * (float)Math.PI);
        float f3 = -0.5F * f2;
        float f4 = 0.4F * class_3532.method_15374(f1 * ((float)Math.PI * 2F));
        float f5 = -0.3F * class_3532.method_15374(pSwingProgress * (float)Math.PI);
        poseStack.method_46416(f * f3, f4 - 0.3F * f2, f5);
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(f2 * -45.0F));
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(f * f2 * -30.0F));

        poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
        poseStack.method_22905(0.38f, 0.38f, 0.38f);
        poseStack.method_22904(-0.5, -0.5, 0);
        poseStack.method_22905(1f, 1f, -1f);

        ExposureClient.photographRenderer().render(stack, true, false, poseStack, buffer, packedLight);

        poseStack.method_22909();
    }

    @Unique
    private void exposure$renderTwoHandedPhotograph(class_742 player, class_4587 poseStack, class_4597 buffer, int packedLight, float pitch, float equippedProgress, float swingProgress) {
        float f = class_3532.method_15355(swingProgress);
        float f1 = -0.2F * class_3532.method_15374(swingProgress * (float)Math.PI);
        float f2 = -0.4F * class_3532.method_15374(f * (float)Math.PI);
        poseStack.method_22904(0.0D, -f1 / 2.0F, f2);
        float f3 = this.calculateMapTilt(pitch);
        poseStack.method_22904(0.0D, 0.04F + equippedProgress * -1.2F + f3 * -0.5F, -0.72F);
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(f3 * -85.0F));
        if (!player.method_5767()) {
            poseStack.method_22903();
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
            this.renderMapHand(poseStack, buffer, packedLight, class_1306.field_6183);
            this.renderMapHand(poseStack, buffer, packedLight, class_1306.field_6182);
            poseStack.method_22909();
        }

        float f4 = class_3532.method_15374(f * (float)Math.PI);
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(f4 * 20.0F));
        poseStack.method_22905(2.0F, 2.0F, 2.0F);

        poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
        poseStack.method_22905(0.38f, 0.38f, 0.38f);
        poseStack.method_22904(-0.5, -0.5, 0);
        poseStack.method_22905(1f, 1f, -1f);

        ExposureClient.photographRenderer().render(this.mainHandItem, true, false, poseStack, buffer, packedLight);
    }
}
