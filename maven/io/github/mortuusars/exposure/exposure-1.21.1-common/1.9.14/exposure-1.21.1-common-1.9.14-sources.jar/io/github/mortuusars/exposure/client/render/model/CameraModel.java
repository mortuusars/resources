package io.github.mortuusars.exposure.client.render.model;

import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.PlatformHelperClient;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.item.camera.Attachment;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_638;

public class CameraModel {
    /**
     * Modifies camera model depending on its state.<br>
     * This was implemented through model overrides before, but it gets messy pretty quickly.
     * This way I have more control over the model, and it reduces number of model jsons significantly. And jsons themselves are simpler.<br>
     * Override predicates are still there, so resourcepacks should be able to override most of this anyway if they want.<br>
     * Maybe 1.21.4 override rework will make it easier?
     */
    public static class_1087 modifyCameraModel(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed, class_1087 original) {
        if (!(stack.method_7909() instanceof CameraItem camera)) return original;

        List<class_1087> models = new ArrayList<>();

        if (camera.isInSelfieMode(stack)) {
            if (entity != null && entity.equals(Minecrft.get().method_1560())) {
                return PlatformHelperClient.getModel(ExposureClient.Models.SELFIE_STICK);
            }

            original = getModelWithOverrides(ExposureClient.Models.CAMERA_SELFIE, stack, level, entity, seed);
            models.add(getModelWithOverrides(ExposureClient.Models.CAMERA_SELFIE_STICK, stack, level, entity, seed));
        } else if (camera.isActive(stack)) {
            original = getModelWithOverrides(ExposureClient.Models.CAMERA_ACTIVE, stack, level, entity, seed);
            models.add(getModelWithOverrides(ExposureClient.Models.CAMERA_VIEWFINDER, stack, level, entity, seed));
        }

        if (Attachment.FLASH.isPresent(stack)) {
            models.add(getModelWithOverrides(ExposureClient.Models.CAMERA_FLASH, stack, level, entity, seed));
        }

        if (Attachment.LENS.isPresent(stack)) {
            models.add(getModelWithOverrides(ExposureClient.Models.CAMERA_LENS, stack, level, entity, seed));
        }

        if (!models.isEmpty()) {
            models.addFirst(original);
            return new CompositeModel(models);
        }

        return original;
    }

    private static class_1087 getModelWithOverrides(class_1091 location, class_1799 stack,
                                                    @Nullable class_638 level, @Nullable class_1309 entity, int seed) {
        class_1087 model = PlatformHelperClient.getModel(location);
        return model.method_4710().method_3495(model, stack, level, entity, seed);
    }
}
