package io.github.mortuusars.exposure.mixin.compat.easy_anvils;

import fuzs.easyanvils.world.inventory.ModAnvilMenu;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.world.item.InterplanarProjectorItem;
import net.minecraft.class_1661;
import net.minecraft.class_1706;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(ModAnvilMenu.class)
public abstract class ModAnvilMenuMixin extends class_1706 {
    public ModAnvilMenuMixin(int containerId, class_1661 playerInventory) {
        super(containerId, playerInventory);
    }

    @ModifyConstant(method = "setItemName", constant = @Constant(intValue = 50))
    private int onSetItemName(int constant) {
        if (Config.Server.INTERPLANAR_PROJECTOR_LARGER_RENAMING_LIMIT.get()
              && field_22480.method_5438(0).method_7909() instanceof InterplanarProjectorItem) {
            return 150;
        }
        return 50;
    }
}
