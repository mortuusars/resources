package io.github.mortuusars.exposure.world.photograph;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_2960;

public record PhotographType(class_2960 id) {
    public static final PhotographType REGULAR = new PhotographType(Exposure.resource("regular"));
    public static final PhotographType AGED = new PhotographType(Exposure.resource("aged"));

    public String getFileSuffix() {
        return this == REGULAR ? "" : id.method_12832();
    }
}
