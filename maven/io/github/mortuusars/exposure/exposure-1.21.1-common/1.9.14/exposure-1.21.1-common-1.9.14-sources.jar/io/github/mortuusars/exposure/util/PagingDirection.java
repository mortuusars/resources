package io.github.mortuusars.exposure.util;

import net.minecraft.class_3532;

public enum PagingDirection {
    PREVIOUS(-1),
    NEXT(1);

    private final int value;

    PagingDirection(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public static PagingDirection fromChange(int oldPage, int newPage) {
        int value = class_3532.method_17822(newPage - oldPage);
        for (PagingDirection direction : values()) {
            if (value == direction.getValue()) return direction;
        }
        return NEXT;
    }
}
