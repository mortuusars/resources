package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.world.camera.CameraOnStand;
import io.github.mortuusars.exposure.world.entity.CameraOperator;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record ActiveCameraOnStandSetS2CP(int operatorEntityId, int cameraStandId, CameraId cameraId) implements Packet {
    public static final class_2960 ID = Exposure.resource("active_camera_on_stand_set");
    public static final class_9154<ActiveCameraOnStandSetS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, ActiveCameraOnStandSetS2CP> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48550, ActiveCameraOnStandSetS2CP::operatorEntityId,
            CameraId.STREAM_CODEC, ActiveCameraOnStandSetS2CP::cameraId,
            class_9135.field_48550, ActiveCameraOnStandSetS2CP::cameraStandId,
            (operatorEntityId1, cameraId1, cameraStandId1) -> new ActiveCameraOnStandSetS2CP(operatorEntityId1, cameraStandId1, cameraId1)
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (player.method_37908().method_8469(operatorEntityId) instanceof CameraOperator operator
                && player.method_37908().method_8469(cameraStandId) instanceof CameraStandEntity cameraStand) {
            operator.setActiveExposureCamera(new CameraOnStand(operator, cameraStand, cameraId));
        }
        return true;
    }
}
