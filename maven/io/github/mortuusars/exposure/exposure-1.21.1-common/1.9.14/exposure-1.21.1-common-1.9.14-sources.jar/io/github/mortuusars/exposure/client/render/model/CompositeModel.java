package io.github.mortuusars.exposure.client.render.model;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;

/**
 * Allows combining models into one. Nicely used to add attachments to camera model dynamically, without making an override spaghetti.
 */
public class CompositeModel implements class_1087 {
    private final List<class_1087> models;

    public CompositeModel(List<class_1087> models) {
        this.models = models;
    }

    public CompositeModel(class_1087... models) {
        this.models = List.of(models);
    }

    @Override
    public @NotNull List<class_777> method_4707(@Nullable class_2680 state, @Nullable class_2350 direction, class_5819 random) {
        ArrayList<class_777> list = new ArrayList<>();
        for (class_1087 model : models) {
            list.addAll(model.method_4707(state, direction, random));
        }
        return list;
    }

    @Override
    public boolean method_4708() {
        return models.getFirst().method_4708();
    }

    @Override
    public boolean method_4712() {
        return models.getFirst().method_4712();
    }

    @Override
    public boolean method_24304() {
        return models.getFirst().method_24304();
    }

    @Override
    public boolean method_4713() {
        return models.getFirst().method_4713();
    }

    @Override
    public @NotNull class_1058 method_4711() {
        return models.getFirst().method_4711();
    }

    @Override
    public @NotNull class_809 method_4709() {
        return models.getFirst().method_4709();
    }

    @Override
    public @NotNull class_806 method_4710() {
        return models.getFirst().method_4710();
    }
}
