package io.github.mortuusars.exposure.client.image;

import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.world.level.storage.ExposureData;
import net.minecraft.class_2960;
import io.github.mortuusars.exposure.data.ColorPalettes;

public record PalettedImage(int width, int height, byte[] pixels, ColorPalette palette) implements Image {
    public PalettedImage {
        Image.validate(width, height, pixels.length);
    }

    public PalettedImage(int width, int height, byte[] pixels, class_2960 paletteId) {
        this(width, height, pixels, ColorPalettes.get(Minecrft.registryAccess(), paletteId).comp_349());
    }

    public static PalettedImage fromExposure(ExposureData exposure) {
        return new PalettedImage(exposure.getWidth(), exposure.getHeight(), exposure.getPixels(), exposure.getPaletteId());
    }

    public int getPixelARGB(int x, int y) {
        int id = pixels[y * width + x] & 0xFF;
        return palette.byId(id);
    }
}
