package io.github.mortuusars.exposure.client.render;

import net.minecraft.class_310;
import net.minecraft.class_3532;

public class GammaModifier {
    private static float offset = 0f;

    public static float getOffset() {
        return offset;
    }

    public static void apply(float offsetValue) {
        offsetValue = class_3532.method_15363(offsetValue, -1F, 1F);
        if (offset != offsetValue) {
            offset = offsetValue;
            // Update light texture immediately:
            class_310.method_1551().field_1773.method_22974().method_3314();
        }
    }

    public static void restore() {
        if (offset != 0f) {
            offset = 0f;
            // Update light texture immediately:
            class_310.method_1551().field_1773.method_22974().method_3314();
        }
    }

    public static float getModifiedValue(float original) {
        return original + offset;
    }
}
