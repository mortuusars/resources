package io.github.mortuusars.exposure.network.packet;

import io.github.mortuusars.exposure.network.packet.common.ActiveCameraDeactivateCommonPacket;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class CommonPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
                new class_8710.class_9155<>(ActiveCameraDeactivateCommonPacket.TYPE, ActiveCameraDeactivateCommonPacket.STREAM_CODEC)
        );
    }
}
