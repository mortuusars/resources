package io.github.mortuusars.exposure.world.camera.component;

import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.Exposure;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2561;
import net.minecraft.class_3542;
import net.minecraft.class_5250;
import net.minecraft.class_7995;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public enum FlashMode implements class_3542 {
    OFF("off"),
    ON("on"),
    AUTO("auto");

    public static final Codec<FlashMode> CODEC = class_3542.method_28140(FlashMode::values);
    public static final class_9139<ByteBuf, FlashMode> STREAM_CODEC = class_9135.method_56375(
            class_7995.method_47914(FlashMode::ordinal, values(), class_7995.class_7996.field_41664), FlashMode::ordinal);

    private final String name;

    FlashMode(String name) {
        this.name = name;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }

    public class_5250 translate() {
        return class_2561.method_43471("gui." + Exposure.ID + ".flash_mode." + name);
    }
}
