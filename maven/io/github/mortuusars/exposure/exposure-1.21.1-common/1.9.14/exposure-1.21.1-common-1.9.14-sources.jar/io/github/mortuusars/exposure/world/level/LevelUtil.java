package io.github.mortuusars.exposure.world.level;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3449;
import net.minecraft.class_7924;

public class LevelUtil {
    public static int getLightLevelAt(class_1937 level, class_2338 pos) {
        level.method_8533(); // This updates 'getSkyDarken' on the client. It'll return 0 if we don't update it.
        int skyBrightness = level.method_8314(class_1944.field_9284, pos);
        int blockBrightness = level.method_8314(class_1944.field_9282, pos);
        return skyBrightness < 15 ?
                Math.max(blockBrightness, (int) (skyBrightness * ((15 - level.method_8594()) / 15f))) :
                Math.max(blockBrightness, 15 - level.method_8594());
    }

    public static List<class_2960> getStructuresAt(class_3218 level, class_2338 pos) {
        class_2378<class_3195> registry = level.method_30349().method_30530(class_7924.field_41246);

        return level.method_27056().method_41037(pos).keySet().stream()
                .filter(structure -> {
                    class_3449 structureStart = level.method_27056().method_28388(pos, structure);
                    return structureStart.method_16657();
                })
                .map(registry::method_10221)
                .filter(Objects::nonNull)
                .toList();
    }
}
