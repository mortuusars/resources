package io.github.mortuusars.exposure.world.camera;

import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.util.color.Color;
import io.netty.buffer.ByteBuf;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_3542;
import net.minecraft.class_7995;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public enum ExposureType implements class_3542 {
    COLOR("color", Color.rgb(180, 130, 110), new FilmColor(1.2F, 0.96F, 0.75F, 1.0F)),
    BLACK_AND_WHITE("black_and_white", Color.WHITE, new FilmColor(1.0F, 1.0F, 1.0F, 1.0F));

    public static final Codec<ExposureType> CODEC = class_3542.method_28140(ExposureType::values);
    public static final class_9139<ByteBuf, ExposureType> STREAM_CODEC =
            class_9135.method_56375(class_7995.method_47914(ExposureType::ordinal, values(), class_7995.class_7996.field_41664), ExposureType::ordinal);

    private final String name;
    private final Color imageColor;
    private final FilmColor filmColor;

    ExposureType(String name, Color imageColor, FilmColor filmColor) {
        this.name = name;
        this.imageColor = imageColor;
        this.filmColor = filmColor;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }

    public Color getImageColor() {
        return imageColor;
    }

    public FilmColor getFilmColor() {
        return filmColor;
    }

    public static Optional<ExposureType> byName(@Nullable String name) {
        for (ExposureType type : values()) {
            if (type.name().equals(name))
                return Optional.of(type);
        }

        return Optional.empty();
    }
}
