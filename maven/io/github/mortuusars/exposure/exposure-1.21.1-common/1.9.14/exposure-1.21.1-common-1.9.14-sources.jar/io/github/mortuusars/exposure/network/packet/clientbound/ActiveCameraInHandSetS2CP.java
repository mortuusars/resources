package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.world.camera.CameraInHand;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.entity.CameraOperator;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record ActiveCameraInHandSetS2CP(int operatorEntityId, CameraId cameraId, class_1268 hand) implements Packet {
    public static final class_2960 ID = Exposure.resource("active_camera_in_hand_set");
    public static final class_9154<ActiveCameraInHandSetS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, ActiveCameraInHandSetS2CP> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48550, ActiveCameraInHandSetS2CP::operatorEntityId,
            CameraId.STREAM_CODEC, ActiveCameraInHandSetS2CP::cameraId,
            class_9135.field_48550.method_56432(i -> class_1268.values()[i], class_1268::ordinal), ActiveCameraInHandSetS2CP::hand,
            ActiveCameraInHandSetS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (player.method_37908().method_8469(operatorEntityId) instanceof class_1309 entity
                && entity instanceof CameraOperator operator
                && entity instanceof CameraHolder holder) {
            operator.setActiveExposureCamera(new CameraInHand(holder, cameraId, hand));
        }
        return true;
    }
}
