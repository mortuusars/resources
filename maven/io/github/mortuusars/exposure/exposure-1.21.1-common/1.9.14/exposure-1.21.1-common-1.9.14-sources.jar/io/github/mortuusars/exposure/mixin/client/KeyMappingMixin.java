package io.github.mortuusars.exposure.mixin.client;

import io.github.mortuusars.exposure.client.camera.CameraClient;
import io.github.mortuusars.exposure.client.util.Minecrft;
import net.minecraft.class_304;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_304.class)
public abstract class KeyMappingMixin {
    @Shadow
    public boolean isDown;

    /**
     * Allows moving when ControlsScreen is open.
     * This should also handle {@link net.minecraft.class_4666} on fabric (forge has separate mixin for it).
     */
    @Inject(method = "isDown", at = @At(value = "HEAD"), cancellable = true)
    private void isDown(CallbackInfoReturnable<Boolean> cir) {
        if (CameraClient.viewfinder() != null
                && CameraClient.viewfinder().controlsScreen().map(screen -> screen == Minecrft.get().field_1755).orElse(false)) {
            cir.setReturnValue(this.isDown);
        }
    }
}
