package io.github.mortuusars.exposure.client.capture.action;

import io.github.mortuusars.exposure.client.capture.CaptureShader;
import io.github.mortuusars.exposure.client.util.Shader;
import java.util.Optional;
import net.minecraft.class_2960;

public class SetFilterAction implements CaptureAction {
    protected Optional<class_2960> filter;

    public SetFilterAction(Optional<class_2960> filter) {
        this.filter = filter;
    }

    @Override
    public void beforeCapture() {
        Shader.setSuppressViewfinder(true);
        filter.ifPresent(CaptureShader::apply);
    }

    @Override
    public void afterCapture() {
        Shader.setSuppressViewfinder(false);
        filter.ifPresent(f -> CaptureShader.remove());
    }
}
