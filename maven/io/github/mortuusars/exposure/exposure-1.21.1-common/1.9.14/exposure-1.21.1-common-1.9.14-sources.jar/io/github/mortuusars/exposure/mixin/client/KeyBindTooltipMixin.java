package io.github.mortuusars.exposure.mixin.client;

import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_459;
import net.minecraft.class_7919;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_459.class_462.class)
public abstract class KeyBindTooltipMixin {
    @Shadow
    @Final
    private class_4185 changeButton;
    @Shadow
    @Final
    private class_2561 name;

    @Inject(method = "refreshEntry", at = @At(value = "INVOKE", ordinal = 1, shift = At.Shift.AFTER,
            target = "Lnet/minecraft/client/gui/components/Button;setTooltip(Lnet/minecraft/client/gui/components/Tooltip;)V"))
    private void changeBackpackKeyHover(CallbackInfo ci) {
        if (name.equals(class_2561.method_43471("key.exposure.camera_controls"))) {
            this.changeButton.method_47400(class_7919.method_47407(class_2561.method_43471("key.exposure.camera_controls.tooltip")));
        }
    }
}