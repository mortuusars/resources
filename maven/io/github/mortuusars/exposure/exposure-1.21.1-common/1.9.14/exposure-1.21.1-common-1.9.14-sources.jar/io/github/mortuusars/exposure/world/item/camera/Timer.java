package io.github.mortuusars.exposure.world.item.camera;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.sound.Sound;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_3419;

public class Timer {
    public void set(CameraHolder holder, class_1799 stack, int ticks) {
        long gameTime = holder.asHolderEntity().method_37908().method_8510();
        setStartTick(stack, gameTime);
        setEndTick(stack, gameTime + ticks);
    }

    public void stop(class_1799 stack) {
        setStartTick(stack, -1L);
        setEndTick(stack, -1L);
    }

    public boolean isTicking(CameraHolder holder, class_1799 stack) {
        return getEndTick(stack) > holder.asHolderEntity().method_37908().method_8510();
    }

    // --

    public int getRemainingTicks(CameraHolder holder, class_1799 stack) {
        return (int)Math.max(-1, getEndTick(stack) - holder.asHolderEntity().method_37908().method_8510());
    }

    public long getTicksSinceLastRelease(CameraHolder holder, class_1799 stack) {
        return holder.asHolderEntity().method_37908().method_8510() - getLastReleaseTick(stack);
    }

    // --

    public long getStartTick(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.TIMER_START_TICK, -1L);
    }

    public void setStartTick(class_1799 stack, long tick) {
        stack.method_57379(Exposure.DataComponents.TIMER_START_TICK, tick);
    }

    public long getEndTick(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.TIMER_END_TICK, -1L);
    }

    public void setEndTick(class_1799 stack, long tick) {
        stack.method_57379(Exposure.DataComponents.TIMER_END_TICK, tick);
    }

    public long getLastReleaseTick(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.TIMER_LAST_RELEASE_TICK, -1L);
    }

    public void setLastReleaseTick(class_1799 stack, long tick) {
        stack.method_57379(Exposure.DataComponents.TIMER_LAST_RELEASE_TICK, tick);
    }

    // --

    /**
     * @return true if state has changed.
     */
    public boolean tick(CameraHolder holder, class_3218 level, class_1799 stack) {
        long releaseTick = getEndTick(stack);
        if (releaseTick <= -1L) return false;
        long currentTick = level.method_8510();
        long remainingTicks = releaseTick - currentTick;

        if (remainingTicks < -5) {
            // Ignore if release tick was passed some time ago.
            // To not release when player drops or puts camera in chest and then picks up after some time.
            stop(stack);
            return true;
        }

        if (remainingTicks == 0) {
            setEndTick(stack, currentTick);
            setLastReleaseTick(stack, currentTick);
            if (stack.method_7909() instanceof CameraItem cameraItem) {
                cameraItem.release(holder, stack);
            }
            stop(stack);
            return true;
        }

        if (remainingTicks % getTickingInterval(remainingTicks) == 0) {
            playTickSound(holder);
        }

        return false;
    }

    // --

    protected void playTickSound(CameraHolder holder) {
        Sound.play(holder.asHolderEntity(), Exposure.SoundEvents.CAMERA_TIMER_TICK.get(), class_3419.field_15248, 1, 0.8f);
    }

    protected int getTickingInterval(long remainingTicks) {
        if (remainingTicks > 100) return 10;
        if (remainingTicks > 50) return 6;
        if (remainingTicks > 25) return 4;
        return 2;
    }
}
