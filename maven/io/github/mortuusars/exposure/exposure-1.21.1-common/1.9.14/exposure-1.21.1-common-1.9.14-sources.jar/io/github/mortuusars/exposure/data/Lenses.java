package io.github.mortuusars.exposure.data;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.component.FocalRange;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_5455;

public class Lenses {
    public static Optional<FocalRange> getFocalRange(class_5455 registryAccess, class_1799 stack) {
        if (!stack.method_31573(Exposure.Tags.Items.LENSES)) {
            return Optional.empty();
        }

        return registryAccess.method_30530(Exposure.Registries.LENS)
                .method_10220()
                .filter(lens -> lens.predicate().method_8970(stack))
                .map(Lens::focalRange)
                .findFirst();
    }

    public static FocalRange getFocalRangeOrDefault(class_5455 registryAccess, class_1799 stack) {
        return getFocalRange(registryAccess, stack).orElse(FocalRange.getDefault());
    }
}