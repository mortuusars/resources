package io.github.mortuusars.exposure.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.world.camera.component.FocalRange;
import net.minecraft.class_2073;

public record Lens(class_2073 predicate, FocalRange focalRange) {
    public static final Codec<Lens> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_2073.field_45754.fieldOf("predicate").forGetter(Lens::predicate),
            FocalRange.CODEC.fieldOf("focal_range").forGetter(Lens::focalRange)
    ).apply(instance, Lens::new));
}
