package io.github.mortuusars.exposure.world.sound;

import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;
import net.minecraft.class_3414;

public record SoundEffect(Supplier<class_3414> sound, float volume, float pitch, float pitchVariability) {
    public SoundEffect(Supplier<class_3414> sound, float volume, float pitch) {
        this(sound, volume, pitch, 0F);
    }

    public SoundEffect(Supplier<class_3414> sound, float volume) {
        this(sound, volume, 1F, 0F);
    }

    public SoundEffect(Supplier<class_3414> sound) {
        this(sound, 1F, 1F, 0F);
    }

    public class_3414 get() {
        return sound().get();
    }

    public float getFinalPitch() {
        return pitch - (pitchVariability / 2) + ThreadLocalRandom.current().nextFloat() * pitchVariability;
    }
}
