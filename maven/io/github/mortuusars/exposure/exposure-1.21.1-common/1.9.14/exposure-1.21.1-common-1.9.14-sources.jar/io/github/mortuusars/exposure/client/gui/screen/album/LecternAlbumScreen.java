package io.github.mortuusars.exposure.client.gui.screen.album;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.inventory.LecternAlbumMenu;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1712;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3936;
import net.minecraft.class_4185;
import net.minecraft.class_5244;
import org.jetbrains.annotations.NotNull;

public class LecternAlbumScreen extends AlbumViewScreen implements class_3936<LecternAlbumMenu> {
    private final LecternAlbumMenu menu;

    private final class_1712 listener = new class_1712() {
        public void method_7635(class_1703 containerToSend, int dataSlotIndex, class_1799 stack) {
            LecternAlbumScreen.this.bookChanged();
        }

        public void method_7633(class_1703 containerMenu, int dataSlotIndex, int value) {
            if (dataSlotIndex == 0) {
                LecternAlbumScreen.this.pageChanged();
            }
        }
    };

    public LecternAlbumScreen(LecternAlbumMenu menu, class_1661 playerInventory, class_2561 title) {
        super(AlbumAccess.fromItem(menu.getBook()));
        this.menu = menu;
        this.pager.setChangeSound(null);
    }

    public @NotNull LecternAlbumMenu method_17577() {
        return this.menu;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        if (Minecrft.player().method_7294()) {
            method_37063(class_4185.method_46430(class_5244.field_24334, b -> this.method_25419())
                    .method_46434(this.field_22789 / 2 - 100, topPos + 196, 98, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43471("lectern.take_book"),
                            b -> sendButtonClick(LecternAlbumMenu.BUTTON_TAKE_BOOK))
                    .method_46434(this.field_22789 / 2 + 2, topPos + 196, 98, 20).method_46431());
        }

        this.menu.method_7596(listener);
    }

    public void method_25432() {
        super.method_25432();
        this.menu.method_7603(this.listener);
    }

    @Override
    protected void onSpreadChanged(int oldSpread, int newSpread) {
        super.onSpreadChanged(oldSpread, newSpread);
        sendButtonClick(LecternAlbumMenu.BUTTON_PAGE_JUMP_RANGE_START + newSpread * 2);
    }

    protected void pageChanged() {
        pager.changePage(menu.getPage() / 2);
    }

    protected void bookChanged() {
        class_1799 itemStack = this.menu.getBook();
        this.setAlbumAccess(AlbumAccess.fromItem(itemStack));
    }

    @Override
    protected void forcePage(int pageIndex) {
        sendButtonClick(LecternAlbumMenu.BUTTON_PAGE_JUMP_RANGE_START + pageIndex);
    }

    protected void sendButtonClick(int buttonId) {
        Minecrft.gameMode().method_2900(this.menu.field_7763, buttonId);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int page = method_17577().getPage();
        if (page % 2 == 1 && isHovering(70, 167, 17, 7, mouseX, mouseY)) {
            sendButtonClick(LecternAlbumMenu.BUTTON_PAGE_JUMP_RANGE_START + page - 1);
        } else if (page % 2 == 0 && isHovering(210, 167, 17, 7, mouseX, mouseY)) {
            sendButtonClick(LecternAlbumMenu.BUTTON_PAGE_JUMP_RANGE_START + page + 1);
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    protected void drawPageNumbers(class_332 guiGraphics, int currentSpreadIndex, int mouseX, int mouseY) {
        super.drawPageNumbers(guiGraphics, currentSpreadIndex, mouseX, mouseY);

        int page = method_17577().getPage();
        String leftPageNumber = Integer.toString(currentSpreadIndex * 2 + 1);
        String rightPageNumber = Integer.toString(currentSpreadIndex * 2 + 2);

        if (page % 2 == 1 && isHovering(70, 167, 17, 7, mouseX, mouseY)) {
            guiGraphics.method_51433(field_22793, leftPageNumber, leftPos + 71 + (8 - field_22793.method_1727(leftPageNumber) / 2),
                    topPos + 167, Config.getColor(Config.Client.ALBUM_FONT_MAIN_COLOR), false);
        } else if (page % 2 == 0 && isHovering(210, 167, 17, 7, mouseX, mouseY)) {
            guiGraphics.method_51433(field_22793, rightPageNumber, leftPos + 212 + (8 - field_22793.method_1727(rightPageNumber) / 2),
                    topPos + 167, Config.getColor(Config.Client.ALBUM_FONT_MAIN_COLOR), false);
        }
    }

    @Override
    protected void renderTooltip(class_332 guiGraphics, int x, int y) {
        super.renderTooltip(guiGraphics, x, y);

        int page = method_17577().getPage();

        if (page % 2 == 1 && isHovering(70, 167, 17, 7, x, y)) {
            guiGraphics.method_51438(field_22793, class_2561.method_43471("gui.exposure.album.lectern.set_current_page"), x, y);
        } else if (page % 2 == 0 && isHovering(210, 167, 17, 7, x, y)) {
            guiGraphics.method_51438(field_22793, class_2561.method_43471("gui.exposure.album.lectern.set_current_page"), x, y);
        }
    }

    protected boolean isHovering(int x, int y, int width, int height, double mouseX, double mouseY) {
        mouseX -= this.leftPos;
        mouseY -= this.topPos;
        return mouseX >= (double)(x - 1) && mouseX < (double)(x + width + 1) && mouseY >= (double)(y - 1) && mouseY < (double)(y + height + 1);
    }
}