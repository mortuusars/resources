package io.github.mortuusars.exposure.client;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import org.jetbrains.annotations.Nullable;

public class Censor {
    public static boolean isAllowedToRender(Frame frame) {
        if (frame.identifier().isTexture()) {
            return true;
        }

        @Nullable class_1657 player = class_310.method_1551().field_1724;

        if (Config.Client.HIDE_ALL_PHOTOGRAPHS_MADE_BY_OTHERS.get()
                && (player == null || !frame.isTakenBy(player))) {
            return false;
        }

        if (Config.Client.HIDE_PROJECTED_PHOTOGRAPHS_MADE_BY_OTHERS.get()
                && frame.isProjected()
                && (player == null || !frame.isTakenBy(player))) {
            return false;
        }

        return true;
    }
}
