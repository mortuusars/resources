package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.client.gui.ClientGUI;
import io.github.mortuusars.exposure.world.item.component.album.SignedAlbumContent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3544;

public class SignedAlbumItem extends class_1792 {
    public SignedAlbumItem(class_1793 properties) {
        super(properties);
    }

    public SignedAlbumContent getContent(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.SIGNED_ALBUM_CONTENT, SignedAlbumContent.EMPTY);
    }

    @Override
    public @NotNull class_2561 method_7864(class_1799 stack) {
        @Nullable SignedAlbumContent content = stack.method_57824(Exposure.DataComponents.SIGNED_ALBUM_CONTENT);
        if (content != null) {
            String title = content.title();
            if (!class_3544.method_57181(title)) {
                return class_2561.method_43470(title);
            }
        }

        return super.method_7864(stack);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        if (level.method_8608()) {
            ClientGUI.openAlbumViewScreen(player.method_5998(usedHand));
        }
        return class_1271.method_22427(player.method_5998(usedHand));
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        @Nullable SignedAlbumContent content = stack.method_57824(Exposure.DataComponents.SIGNED_ALBUM_CONTENT);

        if (content != null) {
            String author = content.author();
            if (!class_3544.method_57181(author)) {
                tooltipComponents.add(class_2561.method_43469("gui.exposure.album.by_author", author).method_27692(class_124.field_1080));
            }

            if (Config.Client.ALBUM_PHOTOS_COUNT_TOOLTIP.get()) {
                int photographsCount = (int)content.pages().stream().filter(page -> !page.photograph().method_7960()).count();
                if (photographsCount > 0)
                    tooltipComponents.add(class_2561.method_43469("item.exposure.album.tooltip.photos_count", photographsCount));
            }
        }

    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return Config.Common.SIGNED_ALBUM_GLINT.get();
    }
}
