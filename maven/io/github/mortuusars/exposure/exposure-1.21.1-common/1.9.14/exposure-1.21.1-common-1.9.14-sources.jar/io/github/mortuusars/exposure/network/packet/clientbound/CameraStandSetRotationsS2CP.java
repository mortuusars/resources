package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record CameraStandSetRotationsS2CP(int entityId, float yRot, float xRot) implements Packet {
    public static final class_2960 ID = Exposure.resource("camera_stand_set_rotations");
    public static final class_9154<CameraStandSetRotationsS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, CameraStandSetRotationsS2CP> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48550, CameraStandSetRotationsS2CP::entityId,
            class_9135.field_48552, CameraStandSetRotationsS2CP::yRot,
            class_9135.field_48552, CameraStandSetRotationsS2CP::xRot,
            CameraStandSetRotationsS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (player.method_37908().method_8469(entityId) instanceof CameraStandEntity stand) {
            stand.method_36456(yRot);
            stand.method_36457(xRot);
        }
        return true;
    }
}