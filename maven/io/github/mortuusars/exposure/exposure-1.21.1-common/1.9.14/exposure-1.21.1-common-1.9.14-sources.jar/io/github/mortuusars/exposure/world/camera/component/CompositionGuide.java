package io.github.mortuusars.exposure.world.camera.component;

import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.Exposure;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record CompositionGuide(String name) {
    public static final Codec<CompositionGuide> CODEC = Codec.STRING.xmap(CompositionGuides::byNameOrNone, CompositionGuide::name);

    public static final class_9139<ByteBuf, CompositionGuide> STREAM_CODEC = class_9139.method_56434(
            class_9135.field_48554, CompositionGuide::name,
            CompositionGuides::byNameOrNone
    );

    public class_5250 translate() {
        return class_2561.method_43471("gui." + Exposure.ID + ".composition_guide." + name);
    }

    public class_2960 overlayTextureLocation() {
        return Exposure.resource("textures/gui/viewfinder/composition_guide/" + name + ".png");
    }

    public class_2960 buttonSpriteLocation() {
        return Exposure.resource("camera_controls/composition_guide/" + name);
    }
}
