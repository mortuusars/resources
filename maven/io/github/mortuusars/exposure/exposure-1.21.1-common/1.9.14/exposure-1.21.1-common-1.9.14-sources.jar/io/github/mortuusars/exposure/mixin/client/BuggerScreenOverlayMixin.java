package io.github.mortuusars.exposure.mixin.client;

import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.client.util.bugger.Bugger;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_340;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_340.class)
public class BuggerScreenOverlayMixin {
    @SuppressWarnings("deprecation")
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void onRender(class_332 guiGraphics, CallbackInfo ci) {
        if (!PlatformHelper.isInDevEnv()) return;

        if (Bugger.page == 0) {
            class_310.method_1551().method_16011().method_15396("bugger_main");
            guiGraphics.method_51741(() -> Bugger.renderMainPage(guiGraphics));
            class_310.method_1551().method_16011().method_15407();
            ci.cancel();
        }

        if (Bugger.page == 1) {
            class_310.method_1551().method_16011().method_15396("bugger_tag");
            guiGraphics.method_51741(() -> Bugger.renderTagPage(guiGraphics));
            class_310.method_1551().method_16011().method_15407();
            ci.cancel();
        }

        String str = "[<-] and [->] to switch pages";
        int strWidth = class_310.method_1551().field_1772.method_1727(str);
        int x = guiGraphics.method_51421() / 2 - strWidth / 2;
        guiGraphics.method_25294(x - 1, 1, x + strWidth + 1, 10, -1873784752);
        guiGraphics.method_51433(class_310.method_1551().field_1772, str, x, 2, 0xFFFFFFFF, false);
    }
}
