package io.github.mortuusars.exposure.client.capture.action;

import io.github.mortuusars.exposure.client.util.Minecrft;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public class SetPostEffectAction implements CaptureAction {
    @Nullable
    private class_2960 currentEffect;
    private boolean effectActive;

    private final class_2960 effect;

    public SetPostEffectAction(class_2960 effect) {
        this.effect = effect;
    }

    @Override
    public void beforeCapture() {
        class_279 currentEffect = Minecrft.get().field_1773.method_3183();
        if (currentEffect != null) {
            this.currentEffect = class_2960.method_60654(currentEffect.method_1260());
        }
        this.effectActive = Minecrft.get().field_1773.field_4013;

        Minecrft.get().field_1773.method_3168(effect);
        Minecrft.get().field_1773.field_4013 = true;
    }

    @Override
    public void afterCapture() {
        Minecrft.get().field_1773.field_4013 = effectActive;
        if (currentEffect != null) {
            Minecrft.get().field_1773.method_3168(currentEffect);
        } else {
            Minecrft.get().field_1773.method_3207();
        }
    }
}
