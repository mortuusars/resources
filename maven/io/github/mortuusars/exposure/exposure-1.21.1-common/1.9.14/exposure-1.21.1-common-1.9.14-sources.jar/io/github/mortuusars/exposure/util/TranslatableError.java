package io.github.mortuusars.exposure.util;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record TranslatableError(String key, String code) {
    public static final TranslatableError GENERIC = new TranslatableError("error.exposure.generic", "ERR_GENERIC");
    public static final TranslatableError TIMED_OUT = new TranslatableError("error.exposure.timed_out", "ERR_TIMED_OUT");

    public static final Codec<TranslatableError> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("key").forGetter(TranslatableError::key),
            Codec.STRING.fieldOf("code").forGetter(TranslatableError::code)
    ).apply(instance, TranslatableError::new));

    public static final class_9139<ByteBuf, TranslatableError> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48554, TranslatableError::key,
            class_9135.field_48554, TranslatableError::code,
            TranslatableError::new
    );

    public class_5250 technical() {
        return class_2561.method_43471(key() + ".technical");
    }

    public class_5250 casual() {
        return class_2561.method_43471(key() + ".casual");
    }
}
