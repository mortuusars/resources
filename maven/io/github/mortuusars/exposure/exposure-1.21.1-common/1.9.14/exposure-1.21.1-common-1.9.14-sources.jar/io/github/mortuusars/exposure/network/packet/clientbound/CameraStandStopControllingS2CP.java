package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.world.camera.CameraInHand;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.entity.CameraOperator;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record CameraStandStopControllingS2CP(int standId) implements Packet {
    public static final class_2960 ID = Exposure.resource("camera_stand_stop_controlling");
    public static final class_9154<CameraStandStopControllingS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, CameraStandStopControllingS2CP> STREAM_CODEC = class_9139.method_56434(
            class_9135.field_48550, CameraStandStopControllingS2CP::standId,
            CameraStandStopControllingS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.stopControllingCameraStand(this);
        return true;
    }
}
