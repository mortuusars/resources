package io.github.mortuusars.exposure.client.image.modifier.pixel;

import net.minecraft.class_3532;
import net.minecraft.class_5253;

public class BlackAndWhiteEffect implements PixelEffect {
    protected final float rWeight;
    protected final float gWeight;
    protected final float bWeight;
    protected String identifier;

    public BlackAndWhiteEffect(float rWeight, float gWeight, float bWeight) {
        this.rWeight = rWeight;
        this.gWeight = gWeight;
        this.bWeight = bWeight;
        this.identifier = "bw-" + rWeight + "-" + gWeight + "-" + bWeight;
    }

    @Override
    public String getIdentifier() {
        return identifier;
    }

    public int modify(int colorARGB) {
        int alpha = class_5253.class_5254.method_27762(colorARGB);
        int red = class_5253.class_5254.method_27765(colorARGB);
        int green = class_5253.class_5254.method_27766(colorARGB);
        int blue = class_5253.class_5254.method_27767(colorARGB);

        int value = class_3532.method_15340((int) (rWeight * red + gWeight * green + bWeight * blue), 0, 255);
        return class_5253.class_5254.method_27764(alpha, value, value, value);
    }

    @Override
    public String toString() {
        return "BlackAndWhiteProcessor{weights:%s,%s,%s}".formatted(rWeight, gWeight, bWeight);
    }
}
