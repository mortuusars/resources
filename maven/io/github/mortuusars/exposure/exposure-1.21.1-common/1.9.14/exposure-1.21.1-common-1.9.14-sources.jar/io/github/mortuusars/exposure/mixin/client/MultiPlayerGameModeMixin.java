package io.github.mortuusars.exposure.mixin.client;

import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public abstract class MultiPlayerGameModeMixin {
    @Shadow public abstract class_1269 useItem(class_1657 player, class_1268 hand);

    @Inject(method = "interactAt", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/phys/EntityHitResult;getLocation()Lnet/minecraft/world/phys/Vec3;"),
            cancellable = true)
    void onInteractAt(class_1657 player, class_1297 target, class_3966 ray, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        class_1799 stack = player.method_5998(hand);
        if (stack.method_7909() instanceof CameraItem cameraItem && cameraItem.isActive(stack)
                && (!(ray.method_17782() instanceof CameraStandEntity standEntity) || !standEntity.getCamera().method_7960())) {
            cir.setReturnValue(useItem(player, hand));
        }
    }

    @Inject(method = "useItemOn", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/multiplayer/ClientLevel;getWorldBorder()Lnet/minecraft/world/level/border/WorldBorder;"),
            cancellable = true)
    void onUseItemOn(class_746 player, class_1268 hand, class_3965 result, CallbackInfoReturnable<class_1269> cir) {
        class_1799 stack = player.method_5998(hand);
        if (stack.method_7909() instanceof CameraItem cameraItem && cameraItem.isActive(stack)) {
            cir.setReturnValue(useItem(player, hand));
        }
    }
}
