package io.github.mortuusars.exposure.world.inventory;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_9129;

public class CameraOnStandAttachmentsMenu extends AbstractCameraAttachmentsMenu {
    protected final CameraStandEntity stand;

    public CameraOnStandAttachmentsMenu(int containerId, class_1661 playerInventory, CameraStandEntity stand) {
        super(Exposure.MenuTypes.CAMERA_ON_STAND.get(), containerId, playerInventory, new StandCameraAccess(stand));
        this.stand = stand;
    }

    @Override
    protected void onContainerChanged(class_1263 c) {
        super.onContainerChanged(c);
        if (!stand.isClientSide()) {
            stand.forceUpdate();
        }
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return stand.getCamera().method_7909() instanceof CameraItem && stand.isInInteractionRange(player);
    }

    public static CameraOnStandAttachmentsMenu fromBuffer(int containerId, class_1661 playerInventory, class_9129 buffer) {
        if (!(playerInventory.field_7546.method_37908().method_8469(buffer.readInt()) instanceof CameraStandEntity stand)) {
            throw new IllegalStateException("Cannot open attachments on stand: Camera Stand entity does not exist on client.");
        }
        return new CameraOnStandAttachmentsMenu(containerId, playerInventory, stand);
    }

    public static class StandCameraAccess implements CameraAccess {
        protected final CameraStandEntity stand;

        public StandCameraAccess(CameraStandEntity stand) {
            this.stand = stand;
            Preconditions.checkState(getStack().method_7909() instanceof CameraItem,
                    "Failed to open access the camera. " + getStack() + " is not a CameraItem.");
        }

        @Override
        public class_1799 getStack() {
            return stand.getCamera();
        }
    }
}
