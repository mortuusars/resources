package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.world.level.storage.ExposureData;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

public record ExposureDataC2SP(String id, ExposureData exposure) implements Packet {
    public static final class_2960 ID = Exposure.resource("exposure_data");
    public static final class_9154<ExposureDataC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, ExposureDataC2SP> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48554, ExposureDataC2SP::id,
            ExposureData.STREAM_CODEC, ExposureDataC2SP::exposure,
            ExposureDataC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ExposureServer.exposureRepository().receiveClientUpload(((class_3222) player), id, exposure);
        return true;
    }
}
