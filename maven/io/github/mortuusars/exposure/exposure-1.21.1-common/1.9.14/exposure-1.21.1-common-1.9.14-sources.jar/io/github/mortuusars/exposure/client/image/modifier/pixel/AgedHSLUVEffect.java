package io.github.mortuusars.exposure.client.image.modifier.pixel;

import io.github.mortuusars.exposure.util.color.converter.HUSLColorConverter;
import net.minecraft.class_3532;
import net.minecraft.class_5253;
import org.apache.commons.lang3.StringUtils;

// HSB is faster while giving only slightly worse result. HSLUV is slower and creates noticeable freezes when exposure is loaded.
public class AgedHSLUVEffect implements PixelEffect {
    protected final int tintColor;
    protected final double[] tintColorHsluv;
    protected final float tintOpacity;
    protected final int blackPoint;
    protected final int whitePoint;

    /**
     * @param tintColor in 0xXXXXXX rgb format. Only rightmost 24 bits would be used, anything extra will be discarded.
     * @param tintOpacity ratio of the original color to tint color. Like a layer opacity.
     * @param blackPoint Like in a Levels adjustment. 0-255.
     * @param whitePoint Like in a Levels adjustment. 0-255.
     */
    public AgedHSLUVEffect(int tintColor, float tintOpacity, int blackPoint, int whitePoint) {
        this.tintColor = tintColor;
        String hexStr = StringUtils.leftPad(Integer.toHexString(tintColor & 0xFFFFFF), 6, "0");
        this.tintColorHsluv = HUSLColorConverter.hexToHsluv("#" + hexStr);
        this.tintOpacity = tintOpacity;
        this.blackPoint = blackPoint & 0xFF; // 0-255
        this.whitePoint = whitePoint & 0xFF; // 0-255
    }

    @Override
    public String getIdentifier() {
        return "aged";
    }

    public int modify(int colorARGB) {
        int alpha = class_5253.class_5254.method_27762(colorARGB);
        int red = class_5253.class_5254.method_27765(colorARGB);
        int green = class_5253.class_5254.method_27766(colorARGB);
        int blue = class_5253.class_5254.method_27767(colorARGB);

        // Modify black and white points to make the image appear faded:
        red = (int) class_3532.method_37959(red, 0, 255, blackPoint, whitePoint);
        green = (int) class_3532.method_37959(green, 0, 255, blackPoint, whitePoint);
        blue = (int) class_3532.method_37959(blue, 0, 255, blackPoint, whitePoint);

        // Apply sepia tone with 'color' blending mode:
        double[] hsluv = HUSLColorConverter.rgbToHsluv(new double[] { red / 255f, green / 255f, blue / 255f });
        hsluv[0] = tintColorHsluv[0]; // Hue
        hsluv[1] = tintColorHsluv[1]; // Saturation

        double[] rgb = HUSLColorConverter.hsluvToRgb(hsluv);

        // Blend two colors together:
        int newRed = class_3532.method_15340((int) class_3532.method_16436(tintOpacity, red, rgb[0] * 255), 0, 255);
        int newGreen = class_3532.method_15340((int) class_3532.method_16436(tintOpacity, green, rgb[1] * 255), 0, 255);
        int newBlue = class_3532.method_15340((int) class_3532.method_16436(tintOpacity, blue, rgb[2] * 255), 0, 255);

        return class_5253.class_5254.method_27764(alpha, newRed, newGreen, newBlue);
    }

    @Override
    public String toString() {
        return "AgedHSLUVPixelModifier{" +
                "tintColor=#" + Integer.toHexString(tintColor) +
                ", tintOpacity=" + tintOpacity +
                ", blackPoint=" + blackPoint +
                ", whitePoint=" + whitePoint +
                '}';
    }
}
