package io.github.mortuusars.exposure.client.gui.screen;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.util.PagingDirection;
import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import net.minecraft.class_332;
import net.minecraft.class_3675;

public class LightroomFrameInspectScreen extends FilmFrameInspectScreen {
    private final LightroomScreen lightroomScreen;

    public LightroomFrameInspectScreen(LightroomScreen lightroomScreen) {
        super(lightroomScreen.method_17577().getExposedFrames(), lightroomScreen.method_17577().getSelectedFrame());
        this.lightroomScreen = lightroomScreen;
        this.pager.setChangeSound(null);
    }

    @Override
    protected void pageChanged(int oldPage, int newPage) {
        // Lightroom can only change one at a time.
        // It should always be one anyway, but limiting it just in case would do no harm.
        PagingDirection direction = PagingDirection.fromChange(oldPage, newPage);
        Collections.rotate(frames, -direction.getValue());

        if (newPage != lightroomScreen.method_17577().getSelectedFrame()) {
            lightroomScreen.changeFrame(direction);
        }
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        if (zoom.get() < zoom.getMin() + 0.1f && zoom.getTarget() < zoom.getMin() + 0.1f) {
            Minecrft.get().method_1507(lightroomScreen);
            Minecrft.player().method_5783(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), 1f, 0.7f);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (super.method_25402(mouseX, mouseY, button)) return true;

        if (button == class_3675.field_32002) {
            zoom.setTarget(0f);
            return true;
        }

        return false;
    }

    @Override
    public void method_25419() {
        zoom.setTarget(0f); // LightroomFrameInspectScreen#render will close screen when zooming out ends.
    }
}
