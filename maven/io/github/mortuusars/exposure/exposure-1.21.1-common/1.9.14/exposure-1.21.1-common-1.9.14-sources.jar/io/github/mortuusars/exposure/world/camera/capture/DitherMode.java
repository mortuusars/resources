package io.github.mortuusars.exposure.world.camera.capture;

import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import org.jetbrains.annotations.NotNull;

import java.util.function.IntFunction;
import net.minecraft.class_2561;
import net.minecraft.class_3542;
import net.minecraft.class_7995;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public enum DitherMode implements class_3542 {
    DITHERED("dithered"),
    CLEAN("clean");

    private static final IntFunction<DitherMode> BY_ID =
            class_7995.method_47914(DitherMode::ordinal, values(), class_7995.class_7996.field_41664);
    public static final Codec<DitherMode> CODEC = class_3542.method_28140(DitherMode::values);
    public static final class_9139<ByteBuf, DitherMode> STREAM_CODEC = class_9135.method_56375(BY_ID, DitherMode::ordinal);

    private final String name;

    DitherMode(String name) {
        this.name = name;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }

    public class_2561 translate() {
        return class_2561.method_43471("item.exposure.interplanar_projector.mode." + method_15434());
    }

    public DitherMode cycle() {
        return BY_ID.apply(ordinal() + 1);
    }
}
