package io.github.mortuusars.exposure.world.lightroom;

import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;

public enum PrintingMode implements class_3542 {
    REGULAR("regular"),
    CHROMATIC("chromatic");

    private final String name;

    PrintingMode(String name) {
        this.name = name;
    }

    public static PrintingMode fromStringOrDefault(String serializedName, PrintingMode defaultValue) {
        for (PrintingMode value : values()) {
            if (value.method_15434().equals(serializedName))
                return value;
        }
        return defaultValue;
    }

    public PrintingMode cycle() {
        return this == REGULAR ? CHROMATIC : REGULAR;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }
}
