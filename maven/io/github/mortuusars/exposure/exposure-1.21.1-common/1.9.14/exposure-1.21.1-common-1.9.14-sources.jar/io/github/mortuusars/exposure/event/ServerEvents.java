package io.github.mortuusars.exposure.event;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.stream.Stream;

public class ServerEvents {
    public static void onServerSave() {
        if (Config.Server.CLEANUP_TIMED_OUT_EXPECTED_EXPOSURES.get()) {
            ExposureServer.exposureRepository().clearExpectedExposuresTimedOutLongAgo();
        }
    }

    public static void serverStarted(MinecraftServer server) {
        Exposure.initServer(server);
    }

    public static void serverStopped(MinecraftServer server) {

    }

    public static void syncDatapack(Stream<class_3222> relevantPlayers) {

    }

    public static void playerTick(class_3222 player) {

    }

    public static void itemDrop(class_3222 player) {
        class_1661 inventory = player.method_31548();
        class_1799 droppedItem = inventory.method_7391();

        if (droppedItem.method_7909() instanceof CameraItem cameraItem && cameraItem.isActive(droppedItem)) {
            player.getActiveExposureCameraOptional().ifPresentOrElse(
                    camera -> {
                        player.removeActiveExposureCamera();
                        cameraItem.deactivate(player, droppedItem);
                    },
                    () -> cameraItem.setActive(droppedItem, false));
        }
    }
}
