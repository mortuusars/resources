package io.github.mortuusars.exposure.world.item.component.album;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SignedAlbumPage(class_1799 photograph, class_2561 note) {
    public static final Codec<SignedAlbumPage> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_1799.field_49266.optionalFieldOf("photograph", class_1799.field_8037).forGetter(SignedAlbumPage::photograph),
            class_8824.field_46597.optionalFieldOf("note", class_2561.method_43473()).forGetter(SignedAlbumPage::note)
    ).apply(instance, SignedAlbumPage::new));

    public static final class_9139<class_9129, SignedAlbumPage> STREAM_CODEC = class_9139.method_56435(
            class_1799.field_49268, SignedAlbumPage::photograph,
            class_8824.field_48540, SignedAlbumPage::note,
            SignedAlbumPage::new
    );

    public static final SignedAlbumPage EMPTY = new SignedAlbumPage(class_1799.field_8037, class_2561.method_43473());

    public boolean isEmpty() {
        return this.equals(EMPTY) || (photograph().method_7960() && note().getString().isEmpty());
    }
}
