package io.github.mortuusars.exposure.network.packet.common;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public class ActiveCameraDeactivateCommonPacket implements Packet {
    public static final ActiveCameraDeactivateCommonPacket INSTANCE = new ActiveCameraDeactivateCommonPacket();

    public static final class_2960 ID = Exposure.resource("active_camera_deactivate");
    public static final class_9154<ActiveCameraDeactivateCommonPacket> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, ActiveCameraDeactivateCommonPacket> STREAM_CODEC = class_9139.method_56431(INSTANCE);

    private ActiveCameraDeactivateCommonPacket() {
    }

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        player.getActiveExposureCameraOptional().ifPresent(camera -> {
            camera.map((item, stack) -> item.deactivate(camera.getHolder().asHolderEntity(), stack));
            player.removeActiveExposureCamera();
        });
        return true;
    }
}
