package io.github.mortuusars.exposure.client.camera.viewfinder;

import io.github.mortuusars.exposure.client.animation.Animation;
import io.github.mortuusars.exposure.client.animation.EasingFunction;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.item.camera.CameraSettings;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import io.github.mortuusars.exposure.world.camera.component.FocalRange;
import io.github.mortuusars.exposure.client.util.ZoomDirection;

public class ViewfinderZoom {
    public static final float ZOOM_STEP = 8f;
    public static final float ZOOM_PRECISE_MODIFIER = 0.25f;

    protected final Camera camera;
    protected final Viewfinder viewfinder;

    protected FocalRange focalRange;
    protected Animation animation;
    protected double targetFov;
    protected double currentFov;

    public ViewfinderZoom(Camera camera, Viewfinder viewfinder) {
        this.camera = camera;
        this.viewfinder = viewfinder;

        focalRange = camera.map((cameraItem, cameraStack) -> cameraItem.getFocalRange(Minecrft.registryAccess(), cameraStack))
                .orElse(FocalRange.getDefault());
        animation = new Animation(300, EasingFunction.EASE_OUT_EXPO);

        double defaultFov = Minecrft.options().method_41808().method_41753();
        currentFov = defaultFov;
        targetFov = camera.map(CameraSettings.ZOOM::getOrDefault)
                .map(focalRange::fovFromZoom)
                .orElse(defaultFov);
    }

    public double getCurrentFov() {
        return class_3532.method_16436(animation.getValue(), currentFov, targetFov);
    }

    public void zoom(ZoomDirection direction, boolean precise) {
        currentFov = getCurrentFov();

        double step = ZOOM_STEP * (1f - class_3532.method_15350((focalRange.min() - currentFov) / focalRange.min(), 0.3f, 1f));
        double inertia = Math.abs(targetFov - currentFov) * 0.8f; // Faster zoom if mouse scrolled rapidly.
        double change = step + inertia;
        if (precise) {
            change *= ZOOM_PRECISE_MODIFIER;
        }

        double prevFov = targetFov;

        double fov = focalRange.clampFov(targetFov + (direction == ZoomDirection.IN ? -change : +change));

        if (!class_3532.method_20390(prevFov, fov)) {
            targetFov = fov;
            animation.resetProgress();

            CameraSettings.ZOOM.setAndSync(camera, (float)focalRange.zoomFromFov(fov));
        }
    }

    public boolean keyPressed(int key, int scanCode, int action, int modifiers) {
        if (action == class_3675.field_31997 || action == class_3675.field_31999) {
            if (key == class_3675.field_31933 || key == class_3675.field_31937) {
                zoom(ZoomDirection.IN, class_437.method_25442());
                return true;
            }

            if (key == 333 /*KEY_SUBTRACT*/ || key == class_3675.field_31941) {
                zoom(ZoomDirection.OUT, class_437.method_25442());
                return true;
            }
        }
        return false;
    }

    public boolean mouseScrolled(double amount) {
        zoom(amount > 0 ? ZoomDirection.IN : ZoomDirection.OUT, class_437.method_25442());
        return true;
    }
}
