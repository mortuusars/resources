package io.github.mortuusars.exposure.client.gui.screen.album;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_2960;
import net.minecraft.class_8666;

public class AlbumGUI {
    public static final class_8666 PREVIOUS_PAGE_BUTTON_SPRITES = new class_8666(
            Exposure.resource("album/previous_page"), Exposure.resource("album/previous_page_highlighted"));
    public static final class_8666 NEXT_PAGE_BUTTON_SPRITES = new class_8666(
            Exposure.resource("album/next_page"), Exposure.resource("album/next_page_highlighted"));

    public static final class_2960 TEXTURE = Exposure.resource("textures/gui/album.png");
}
