package io.github.mortuusars.exposure.advancements.predicate;

import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.util.ExtraData;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2522;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.nbt.*;
import org.jetbrains.annotations.Nullable;

/**
 * We cannot use {@link net.minecraft.class_2105} as it checks against CompoundTag.class.
 * This is basically a copy of its functionality to make ExtraData work.
 */
public record ExtraDataPredicate(ExtraData data) {
    public static final Codec<ExtraDataPredicate> CODEC = class_2522.field_51469.xmap(
            tag -> new ExtraDataPredicate(new ExtraData(tag)),
            predicate -> predicate.data);
    public static final class_9139<ByteBuf, ExtraDataPredicate> STREAM_CODEC = class_9135.field_48556.method_56432(
            tag -> new ExtraDataPredicate(new ExtraData(tag)),
            predicate -> predicate.data);

    public boolean matches(@Nullable class_2520 tag) {
        return tag != null && compareNbt(tag);
    }

    private boolean compareNbt(@Nullable class_2520 other) {
        if (data == other) {
            return true;
        } else if (data == null) {
            return true;
        } else if (other == null) {
            return false;
        } else if (data instanceof class_2487 compoundTag) {
            class_2487 compoundTag2 = (class_2487)other;
            if (compoundTag2.method_10546() < compoundTag.method_10546()) {
                return false;
            } else {
                for (String string : compoundTag.method_10541()) {
                    class_2520 tag2 = compoundTag.method_10580(string);
                    if (!class_2512.method_10687(tag2, compoundTag2.method_10580(string), true)) {
                        return false;
                    }
                }

                return true;
            }
        } else {
            return data.equals(other);
        }
    }
}
