package io.github.mortuusars.exposure.event;

import com.mojang.brigadier.CommandDispatcher;
import io.github.mortuusars.exposure.commands.ExposureCommand;
import io.github.mortuusars.exposure.commands.ShaderCommand;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_7157;

public class CommonEvents {
    public static void registerCommands(CommandDispatcher<class_2168> dispatcher,
                                        class_7157 context, class_2170.class_5364 environment) {
        ExposureCommand.register(dispatcher);
        ShaderCommand.register(dispatcher);
    }
}
