package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.data.export.ExportLook;
import io.github.mortuusars.exposure.data.export.ExportSize;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ExportS2CP(List<String> ids, ExportSize size, ExportLook look) implements Packet {
    public static final class_2960 ID = Exposure.resource("export");
    public static final class_9154<ExportS2CP> TYPE = new class_9154<>(ID);
    public static final class_9139<class_2540, ExportS2CP> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48554.method_56433(class_9135.method_56363()), ExportS2CP::ids,
            class_9135.field_48550.method_56432(i -> ExportSize.values()[i], ExportSize::ordinal), ExportS2CP::size,
            class_9135.field_48550.method_56432(i -> ExportLook.values()[i], ExportLook::ordinal), ExportS2CP::look,
            ExportS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        ClientPacketsHandler.exportExposures(this);
        return true;
    }
}
