package io.github.mortuusars.exposure.client.image.modifier.pixel;

import io.github.mortuusars.exposure.world.camera.FilmColor;
import net.minecraft.class_3532;
import net.minecraft.class_5253;

public class TintedNegativeFilmEffect implements PixelEffect {
    private final FilmColor tintColor;

    public TintedNegativeFilmEffect(FilmColor tintColor) {
        this.tintColor = tintColor;
    }

    @Override
    public String getIdentifier() {
        return "tinted-negative-film-" + tintColor;
    }

    public int modify(int ARGB) {
        int alpha = class_5253.class_5254.method_27762(ARGB);
        int red = class_5253.class_5254.method_27765(ARGB);
        int green = class_5253.class_5254.method_27766(ARGB);
        int blue = class_5253.class_5254.method_27767(ARGB);

        // Modify opacity to make lighter colors transparent, like in real film.
        int brightness = (red + green + blue) / 3;
        int opacity = (int) class_3532.method_15363(brightness * 1.5f, 0, 255);
        alpha = (alpha * opacity) / 255;

        // Invert
        red = 255 - red;
        green = 255 - green;
        blue = 255 - blue;

        // Tint
        red = (int) (red * tintColor.r() / 255);
        green = (int) (green * tintColor.g() / 255);
        blue = (int) (blue * tintColor.b() / 255);

        return class_5253.class_5254.method_27764(alpha, red, green, blue);
    }
}
