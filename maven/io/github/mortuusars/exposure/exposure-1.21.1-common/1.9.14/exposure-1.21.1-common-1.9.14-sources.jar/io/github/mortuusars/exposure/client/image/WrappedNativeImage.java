package io.github.mortuusars.exposure.client.image;

import io.github.mortuusars.exposure.util.color.Color;
import net.minecraft.class_1011;

public class WrappedNativeImage implements Image {
    private final class_1011 nativeImage;

    public WrappedNativeImage(class_1011 nativeImage) {
        this.nativeImage = nativeImage;
    }

    @Override
    public int width() {
        return nativeImage.method_4307();
    }

    @Override
    public int height() {
        return nativeImage.method_4323();
    }

    @Override
    public int getPixelARGB(int x, int y) {
        return Color.ABGRtoARGB(nativeImage.method_4315(x, y));
    }

    @Override
    public void close() {
        nativeImage.close();
    }
}
