package io.github.mortuusars.exposure.commands.argument;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.mortuusars.exposure.data.export.ExportLook;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2172;
import net.minecraft.class_2561;

public class ExposureLookArgument implements ArgumentType<ExportLook> {
    @Override
    public ExportLook parse(StringReader reader) throws CommandSyntaxException {
        String string = reader.readString();
        @Nullable ExportLook look = ExportLook.byName(string);
        if (look == null)
            throw new SimpleCommandExceptionType(class_2561.method_43469("argument.enum.invalid", string)).create();

        return look;
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return class_2172.method_9264(Arrays.stream(ExportLook.values())
                .filter(l -> l != ExportLook.REGULAR)
                .map(ExportLook::method_15434), builder);
    }

    public static ExportLook getLook(final CommandContext<?> context, final String name) {
        return context.getArgument(name, ExportLook.class);
    }
}
