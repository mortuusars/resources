package io.github.mortuusars.exposure.mixin.client;

import io.github.mortuusars.exposure.event.ClientEvents;
import net.minecraft.class_2678;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPacketListenerMixin {
    @Inject(method = "handleLogin", at = @At("RETURN"))
    void handleLogin(class_2678 packet, CallbackInfo ci) {
        ClientEvents.login();
    }
}
