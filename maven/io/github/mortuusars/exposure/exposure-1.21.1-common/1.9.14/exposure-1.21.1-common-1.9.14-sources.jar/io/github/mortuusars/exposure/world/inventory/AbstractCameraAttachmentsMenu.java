package io.github.mortuusars.exposure.world.inventory;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.util.supporter.Supporters;
import io.github.mortuusars.exposure.world.inventory.slot.FilteredSlot;
import io.github.mortuusars.exposure.world.item.camera.Attachment;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2i;

import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3917;

public abstract class AbstractCameraAttachmentsMenu extends class_1703 {
    public static final int SKIN_REGULAR_BUTTON_ID = 100;
    public static final int SKIN_GOLD_BUTTON_ID = 101;

    protected final class_1657 player;
    protected final CameraAccess cameraAccess;
    protected final List<Attachment<?>> attachments;

    protected boolean clientContentsInitialized;

    protected AbstractCameraAttachmentsMenu(@Nullable class_3917<?> menuType, int containerId, class_1661 playerInventory, CameraAccess cameraAccess) {
        super(menuType, containerId);
        this.player = playerInventory.field_7546;
        this.cameraAccess = cameraAccess;
        this.attachments = cameraAccess.map((i, s) -> i.getAttachments());

        class_1277 container = createAttachmentsContainer();

        addAttachmentSlots(container);
        addPlayerSlots(playerInventory);
    }

    public CameraAccess getCamera() {
        return cameraAccess;
    }

    protected class_1799 getCameraStack() {
        return getCamera().getStack();
    }

    protected @NotNull class_1277 createAttachmentsContainer() {
        class_1799[] attachmentItems = attachments.stream()
                .map(attachment -> attachment.get(getCamera().getStack()).getCopy())
                .toArray(class_1799[]::new);

        class_1277 container = new class_1277(attachmentItems) {
            @Override
            public int method_5444() {
                return 1;
            }
        };

        container.method_5489(this::onContainerChanged);
        return container;
    }

    protected void onContainerChanged(class_1263 c) {
        for (int slotId = 0; slotId < c.method_5439(); slotId++) {
            Attachment<?> attachment = attachments.get(slotId);
            attachment.set(getCamera().getStack(), c.method_5438(slotId));
        }
    }

    /**
     * Only called client-side.
     */
    @Override
    public void method_7610(int stateId, List<class_1799> items, class_1799 carried) {
        clientContentsInitialized = false;
        super.method_7610(stateId, items, carried);
        clientContentsInitialized = true;
    }

    protected void addAttachmentSlots(class_1263 container) {
        Map<Attachment<?>, Vector2i> slotPositions = Map.of(
                Attachment.FILM, new Vector2i(13, 42),
                Attachment.FLASH, new Vector2i(147, 15),
                Attachment.LENS, new Vector2i(147, 43),
                Attachment.FILTER, new Vector2i(147, 71));

        for (int index = 0; index < attachments.size(); index++) {
            Attachment<?> attachmentType = attachments.get(index);
            Vector2i pos = slotPositions.get(attachmentType);
            method_7621(new FilteredSlot(container, index, pos.x(), pos.y(), 1,
                    this::onItemInSlotChanged, attachmentType.itemPredicate()));
        }
    }

    protected void addPlayerSlots(class_1661 playerInventory) {
        //Player Inventory
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                method_7621(new class_1735(playerInventory, (column + row * 9) + 9, column * 18 + 8, 103 + row * 18));
            }
        }

        //Hotbar
        for (int slot = 0; slot < 9; slot++) {
            method_7621(new class_1735(playerInventory, slot, slot * 18 + 8, 161));
        }
    }

    protected void onItemInSlotChanged(FilteredSlot.SlotChangedArgs args) {
        int slotId = args.slot().getSlotId();
        class_1799 newStack = args.newStack();

        Attachment<?> attachment = attachments.get(slotId);

        if (clientContentsInitialized) {
            if (!newStack.method_7960()) {
                attachment.playInsertSoundSided(player);
            } else {
                attachment.playRemoveSoundSided(player);
            }

            getCamera().apply((item, stack) -> item.actionPerformed(stack, player));
        }
    }

    @Override
    public @NotNull class_1799 method_7601(@NotNull class_1657 player, int slotIndex) {
        class_1799 itemstack = class_1799.field_8037;
        class_1735 clickedSlot = this.field_7761.get(slotIndex);
        if (clickedSlot.method_7681()) {
            class_1799 slotStack = clickedSlot.method_7677();
            itemstack = slotStack.method_7972();
            if (slotIndex < attachments.size()) {
                if (!this.method_7616(slotStack, attachments.size(), this.field_7761.size(), true))
                    return class_1799.field_8037;
            } else {
                if (!this.method_7616(slotStack, 0, attachments.size(), false))
                    return class_1799.field_8037;
            }

            if (slotStack.method_7960())
                clickedSlot.method_7673(class_1799.field_8037);
            else
                clickedSlot.method_7668();
        }

        return itemstack;
    }

    /**
     * Fixed method to respect slot limit.
     */
    @Override
    protected boolean method_7616(class_1799 movedStack, int startIndex, int endIndex, boolean reverseDirection) {
        boolean hasRemainder = false;
        int i = startIndex;
        if (reverseDirection) {
            i = endIndex - 1;
        }
        if (movedStack.method_7946()) {
            while (!movedStack.method_7960() && !(!reverseDirection ? i >= endIndex : i < startIndex)) {
                class_1735 slot = this.field_7761.get(i);
                class_1799 slotStack = slot.method_7677();
                if (!slotStack.method_7960() && class_1799.method_31577(movedStack, slotStack)) {
                    int maxSize;
                    int j = slotStack.method_7947() + movedStack.method_7947();
                    if (j <= (maxSize = Math.min(slot.method_7675(), movedStack.method_7914()))) {
                        movedStack.method_7939(0);
                        slotStack.method_7939(j);
                        slot.method_7668();
                        hasRemainder = true;
                    } else if (slotStack.method_7947() < maxSize) {
                        movedStack.method_7934(maxSize - slotStack.method_7947());
                        slotStack.method_7939(maxSize);
                        slot.method_7668();
                        hasRemainder = true;
                    }
                }
                if (reverseDirection) {
                    --i;
                    continue;
                }
                ++i;
            }
        }
        if (!movedStack.method_7960()) {
            i = reverseDirection ? endIndex - 1 : startIndex;
            while (!(!reverseDirection ? i >= endIndex : i < startIndex)) {
                class_1735 slot1 = this.field_7761.get(i);
                class_1799 movedStack1 = slot1.method_7677();
                if (movedStack1.method_7960() && slot1.method_7680(movedStack)) {
                    if (movedStack.method_7947() > slot1.method_7675()) {
                        slot1.method_53512(movedStack.method_7971(slot1.method_7675()));
                    } else {
                        slot1.method_53512(movedStack.method_7971(movedStack.method_7947()));
                    }
                    slot1.method_7668();
                    hasRemainder = true;
                    break;
                }
                if (reverseDirection) {
                    --i;
                    continue;
                }
                ++i;
            }
        }
        return hasRemainder;
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (Supporters.hasAccessToGoldenSkin(player.method_5667())) {
            if (id == SKIN_REGULAR_BUTTON_ID) {
                getCamera().apply((i, s) -> s.method_57379(Exposure.DataComponents.CAMERA_GOLD, false));
                return true;
            } else if (id == SKIN_GOLD_BUTTON_ID) {
                getCamera().apply((i, s) -> s.method_57379(Exposure.DataComponents.CAMERA_GOLD, true));
                return true;
            }
        }
        return false;
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        getCamera().apply((item, stack) -> item.setDisassembled(stack, false));
    }

    public interface CameraAccess {
        class_1799 getStack();

        default void apply(BiConsumer<CameraItem, class_1799> consumer) {
            class_1799 camera = getStack();
            consumer.accept(((CameraItem) camera.method_7909()), camera);
        }

        default <T> T map(BiFunction<CameraItem, class_1799, T> func) {
            class_1799 camera = getStack();
            return func.apply(((CameraItem) camera.method_7909()), camera);
        }
    }
}
