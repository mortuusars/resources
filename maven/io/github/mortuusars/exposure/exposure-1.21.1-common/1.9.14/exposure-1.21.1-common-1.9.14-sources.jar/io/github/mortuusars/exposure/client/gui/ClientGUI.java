package io.github.mortuusars.exposure.client.gui;

import io.github.mortuusars.exposure.client.gui.screen.PhotographScreen;
import io.github.mortuusars.exposure.client.gui.screen.album.AlbumViewScreen;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import io.github.mortuusars.exposure.world.item.crafting.recipe.FilmDevelopingRecipe;
import io.github.mortuusars.exposure.world.item.crafting.recipe.PhotographCopyingRecipe;
import io.github.mortuusars.exposure.world.item.util.ItemAndStack;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_437;
import net.minecraft.class_8786;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class ClientGUI {
    public static void openPhotographScreen(List<ItemAndStack<PhotographItem>> photographs) {
        Minecrft.get().method_1507(new PhotographScreen(photographs));
    }

    public static void openPhotographsScreenFromItem(int item) {
        Minecrft.get().method_1507(new PhotographScreen(PhotographScreen.PhotographProvider.fromPhotographItem(item)));
    }

    public static void openAlbumViewScreen(class_1799 albumStack) {
        Minecrft.get().method_1507(new AlbumViewScreen(AlbumViewScreen.AlbumAccess.fromItem(albumStack)));
    }

    public static void addFilmRollDevelopingTooltip(class_1799 filmStack, class_1792.class_9635 tooltipContext,
                                                    @NotNull List<class_2561> tooltipComponents, @NotNull class_1836 isAdvanced) {
        addRecipeTooltip(filmStack, tooltipContext, tooltipComponents, isAdvanced,
                r -> r instanceof FilmDevelopingRecipe filmDevelopingRecipe
                        && filmDevelopingRecipe.getSourceIngredient().method_8093(filmStack),
                "item.exposure.film_roll.tooltip.details.develop");
    }

    public static void addPhotographCopyingTooltip(class_1799 photographStack, class_1792.class_9635 tooltipContext,
                                                   @NotNull List<class_2561> tooltipComponents, @NotNull class_1836 isAdvanced) {
        addRecipeTooltip(photographStack, tooltipContext, tooltipComponents, isAdvanced,
                r -> r instanceof PhotographCopyingRecipe photographCopyingRecipe
                        && photographCopyingRecipe.getSourceIngredient().method_8093(photographStack),
                "item.exposure.photograph.tooltip.details.copy");
    }

    private static void addRecipeTooltip(class_1799 stack, class_1792.class_9635 tooltipContext,
                                         @NotNull List<class_2561> tooltipComponents, @NotNull class_1836 isAdvanced,
                                         Predicate<class_3955> recipeFilter, String detailsKey) {
        if (class_310.method_1551().field_1687 == null) {
            return;
        }

        tooltipComponents.add(class_2561.method_43471("tooltip.exposure.hold_for_details"));
        if (!class_437.method_25442()) {
            return;
        }

        Optional<class_2371<class_1856>> recipeIngredients = class_310.method_1551().field_1687
                .method_8433()
                .method_30027(class_3956.field_17545)
                .stream()
                .map(class_8786::comp_1933)
                .filter(recipeFilter)
                .findFirst()
                .map(class_1860::method_8117);

        if (recipeIngredients.isEmpty() || recipeIngredients.get().isEmpty())
            return;

        class_2371<class_1856> ingredients = recipeIngredients.get();

        tooltipComponents.add(class_2561.method_43473());

        class_2583 orange = class_2583.field_24360.method_36139(0xc7954b);
        class_2583 yellow = class_2583.field_24360.method_36139(0xeeda78);

        tooltipComponents.add(class_2561.method_43471(detailsKey).method_27696(orange));

        for (int i = 0; i < ingredients.size(); i++) {
            class_1799[] stacks = ingredients.get(i).method_8105();

            if (stacks.length == 0)
                tooltipComponents.add(class_2561.method_43470("  ").method_10852(class_2561.method_43470("?").method_27696(yellow)));
            else if (stacks.length == 1)
                tooltipComponents.add(class_2561.method_43470("  ").method_10852(stacks[0].method_7964().method_27661().method_27696(yellow)));
            else { // Cycle stacks if it's not one:
                int val = (int) Math.ceil((class_310.method_1551().field_1687.method_8510() + 10 * i) % (20f * stacks.length) / 20f);
                int index = class_3532.method_15340(val - 1, 0, stacks.length - 1);

                tooltipComponents.add(class_2561.method_43470("  ").method_10852(stacks[index].method_7964().method_27661().method_27696(yellow)));
            }
        }
    }
}
