package io.github.mortuusars.exposure.client.gui.toast;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_368;
import net.minecraft.class_374;

public class BetterTutorialToast implements class_368 {
    private static final class_2960 BACKGROUND_SPRITE = class_2960.method_60656("toast/tutorial");
    public static final int DEFAULT_SHOW_DURATION_MS = 7000;

    public class_2960 backgroundSprite = BACKGROUND_SPRITE;
    public Runnable onHide = () -> { };

    protected final ToastIcon icon;
    protected final class_2561 title;
    @Nullable
    protected final class_2561 message;
    protected class_368.class_369 visibility = class_368.class_369.field_2210;

    protected final long shownAt = System.currentTimeMillis();
    protected final int showDurationMs;
    protected final Supplier<Boolean> hideIf;

    public BetterTutorialToast(ToastIcon icon, class_2561 title, @Nullable class_2561 message, int showDurationMs, Supplier<Boolean> hideIf) {
        this.icon = icon;
        this.title = title;
        this.message = message;
        this.showDurationMs = showDurationMs;
        this.hideIf = hideIf;
    }

    public BetterTutorialToast(ToastIcon icon, class_2561 title, @Nullable class_2561 message, int showDurationMs) {
        this.icon = icon;
        this.title = title;
        this.message = message;
        this.showDurationMs = showDurationMs;
        this.hideIf = () -> false;
    }

    public BetterTutorialToast(ToastIcon icon, class_2561 title, @Nullable class_2561 message, Supplier<Boolean> hideIf) {
        this.icon = icon;
        this.title = title;
        this.message = message;
        this.showDurationMs = -1;
        this.hideIf = hideIf;
    }

    public void hide() {
        this.visibility = class_368.class_369.field_2209;
    }

    @Override
    public @NotNull class_369 method_1986(class_332 guiGraphics, class_374 toastComponent, long timeSinceLastVisible) {
        if (visibility == class_369.field_2210 && hideIf.get() || (showDurationMs > 0 && System.currentTimeMillis() > shownAt + showDurationMs)) {
            hide();
            onHide.run();
        }

        guiGraphics.method_52706(backgroundSprite, 0, 0, this.method_29049(), this.method_29050());
        this.icon.render(guiGraphics, 6, 6);
        if (this.message == null) {
            guiGraphics.method_51439(toastComponent.method_1995().field_1772, this.title, 30, 12, 0xFF500050, false);
        } else {
            guiGraphics.method_51439(toastComponent.method_1995().field_1772, this.title, 30, 7, 0xFF500050, false);
            guiGraphics.method_51439(toastComponent.method_1995().field_1772, this.message, 30, 18, 0xFF000000, false);
        }

        return this.visibility;
    }
}
