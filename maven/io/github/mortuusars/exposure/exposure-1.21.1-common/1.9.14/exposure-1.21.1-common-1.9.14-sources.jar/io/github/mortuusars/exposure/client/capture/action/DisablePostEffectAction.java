package io.github.mortuusars.exposure.client.capture.action;

import net.minecraft.class_310;

public class DisablePostEffectAction implements CaptureAction {
    private boolean effectActive;

    @Override
    public void beforeCapture() {
        effectActive = class_310.method_1551().field_1773.field_4013;
        class_310.method_1551().field_1773.field_4013 = false;
    }

    @Override
    public void afterCapture() {
        class_310.method_1551().field_1773.field_4013 = effectActive;
    }
}
