package io.github.mortuusars.exposure.data;

import io.github.mortuusars.exposure.Exposure;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_5455;

public class Filters {
    public static Optional<Filter> of(class_5455 registryAccess, class_1799 stack) {
        return registryAccess.method_30530(Exposure.Registries.FILTER)
                .method_10220()
                .filter(filter -> filter.predicate().method_8970(stack))
                .findFirst();
    }

    public static Optional<class_2960> locationOf(class_5455 registryAccess, Filter filter) {
        return Optional.ofNullable(registryAccess.method_30530(Exposure.Registries.FILTER).method_10221(filter));
    }
}