package io.github.mortuusars.exposure.world.camera.capture;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.util.Codecs;
import io.github.mortuusars.exposure.util.ExtraData;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.world.camera.ColorChannel;
import io.github.mortuusars.exposure.world.camera.component.ShutterSpeed;
import io.github.mortuusars.exposure.world.camera.film.properties.FilmProperties;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_2960;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record CaptureParameters(String exposureId,
                                Optional<CameraId> cameraId,
                                Optional<Integer> cameraHolderId,
                                Optional<Double> fov,
                                float cropFactor,
                                Optional<class_2960> filter,
                                Optional<Projection> projection,
                                Optional<ColorChannel> singleChannel,
                                FilmProperties filmProperties,
                                ExtraData extraData) {

    public static final ExtraData.Type<ShutterSpeed> SHUTTER_SPEED =
            ExtraData.Type.stringRepresentable("shutter_speed", ShutterSpeed::new);
    public static final ExtraData.Type<Boolean> FLASH =
            new ExtraData.Type<>("flash", ExtraData::method_10577, ExtraData::method_10556);
    public static final ExtraData.Type<Integer> LIGHT_LEVEL =
            new ExtraData.Type<>("light_level", ExtraData::method_10550, ExtraData::method_10569);

    // --

    public static final Codec<CaptureParameters> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("id").forGetter(CaptureParameters::exposureId),
            CameraId.CODEC.optionalFieldOf("camera_id").forGetter(CaptureParameters::cameraId),
            Codec.INT.optionalFieldOf("camera_holder_id").forGetter(CaptureParameters::cameraHolderId),
            Codecs.POSITIVE_DOUBLE.optionalFieldOf("fov").forGetter(CaptureParameters::fov),
            Codecs.floatRange(0.001f, 1f).optionalFieldOf("crop_factor", 1f).forGetter(CaptureParameters::cropFactor),
            class_2960.field_25139.optionalFieldOf("filter").forGetter(CaptureParameters::filter),
            Projection.CODEC.optionalFieldOf("projection").forGetter(CaptureParameters::projection),
            ColorChannel.CODEC.optionalFieldOf("single_channel").forGetter(CaptureParameters::singleChannel),
            FilmProperties.CODEC.optionalFieldOf("film", FilmProperties.EMPTY).forGetter(CaptureParameters::filmProperties),
            ExtraData.field_25128.optionalFieldOf("extra_data", ExtraData.EMPTY).forGetter(CaptureParameters::extraData)
    ).apply(instance, CaptureParameters::new));

    public static final class_9139<class_9129, CaptureParameters> STREAM_CODEC = new class_9139<>() {
        public @NotNull CaptureParameters decode(class_9129 buffer) {
            return new CaptureParameters(
                    class_9135.field_48554.decode(buffer),
                    class_9135.method_56382(CameraId.STREAM_CODEC).decode(buffer),
                    class_9135.method_56382(class_9135.field_48550).decode(buffer),
                    class_9135.method_56382(class_9135.field_48553).decode(buffer),
                    class_9135.field_48552.decode(buffer),
                    class_9135.method_56382(class_2960.field_48267).decode(buffer),
                    class_9135.method_56382(Projection.STREAM_CODEC).decode(buffer),
                    class_9135.method_56382(ColorChannel.STREAM_CODEC).decode(buffer),
                    FilmProperties.STREAM_CODEC.decode(buffer),
                    ExtraData.STREAM_CODEC.decode(buffer));
        }

        public void encode(class_9129 buffer, CaptureParameters data) {
            class_9135.field_48554.encode(buffer, data.exposureId());
            class_9135.method_56382(CameraId.STREAM_CODEC).encode(buffer, data.cameraId());
            class_9135.method_56382(class_9135.field_48550).encode(buffer, data.cameraHolderId());
            class_9135.method_56382(class_9135.field_48553).encode(buffer, data.fov());
            class_9135.field_48552.encode(buffer, data.cropFactor());
            class_9135.method_56382(class_2960.field_48267).encode(buffer, data.filter());
            class_9135.method_56382(Projection.STREAM_CODEC).encode(buffer, data.projection());
            class_9135.method_56382(ColorChannel.STREAM_CODEC).encode(buffer, data.singleChannel());
            FilmProperties.STREAM_CODEC.encode(buffer, data.filmProperties());
            ExtraData.STREAM_CODEC.encode(buffer, data.extraData());
        }
    };

    public ShutterSpeed getShutterSpeed() {
        return extraData.get(SHUTTER_SPEED).orElse(ShutterSpeed.DEFAULT);
    }

    public boolean getFlash() {
        return extraData.get(FLASH).orElse(false);
    }

    public Optional<Integer> getLightLevel() {
        return extraData.get(LIGHT_LEVEL);
    }

    public Builder mutable() {
        return new Builder(this);
    }

    public static final class Builder {
        private final String exposureId;
        private @Nullable CameraId cameraId;
        private @Nullable Integer cameraHolderEntityID;
        private @Nullable Double fov;
        private float cropFactor = 1f;
        private @Nullable class_2960 filter = null;
        private @Nullable Projection projection;
        private @Nullable ColorChannel chromaticChannel;
        private FilmProperties filmProperties = FilmProperties.EMPTY;
        private final ExtraData extraData = new ExtraData();

        public Builder(String exposureId) {
            this.exposureId = exposureId;
        }

        public Builder(CaptureParameters params) {
            this.exposureId = params.exposureId();
            this.cameraId = params.cameraId().orElse(null);
            this.cameraHolderEntityID = params.cameraHolderId().orElse(null);
            this.fov = params.fov.orElse(null);
            this.cropFactor = params.cropFactor();
            this.filter = params.filter().orElse(null);
            this.projection = params.projection().orElse(null);
            this.chromaticChannel = params.singleChannel().orElse(null);
            this.filmProperties = params.filmProperties();
            extraData.method_10543(params.extraData());
        }

        public Builder setCameraID(@Nullable CameraId cameraId) {
            this.cameraId = cameraId;
            return this;
        }

        public Builder setCameraHolder(@Nullable CameraHolder holder) {
            if (holder == null) cameraHolderEntityID = null;
            else cameraHolderEntityID = holder.asHolderEntity().method_5628();
            return this;
        }

        public Builder setFilter(@Nullable class_2960 filter) {
            this.filter = filter;
            return this;
        }

        public Builder setFov(@Nullable Double fov) {
            this.fov = fov;
            return this;
        }

        public Builder setCropFactor(float cropFactor) {
            this.cropFactor = cropFactor;
            return this;
        }

        public Builder setProjectionInfo(@Nullable Projection projection) {
            this.projection = projection;
            return this;
        }

        public Builder setProjection(Optional<Projection> projection) {
            this.projection = projection.orElse(null);
            return this;
        }

        public Builder setChromaticChannel(@Nullable ColorChannel chromaticChannel) {
            this.chromaticChannel = chromaticChannel;
            return this;
        }

        public Builder setChromaticChannel(Optional<ColorChannel> chromaticChannel) {
            this.chromaticChannel = chromaticChannel.orElse(null);
            return this;
        }

        public Builder setFilmProperties(FilmProperties filmProperties) {
            this.filmProperties = filmProperties;
            return this;
        }

        public Builder extraData(Consumer<ExtraData> extraDataUpdater) {
            extraDataUpdater.accept(extraData);
            return this;
        }

        public <T> Builder extraData(ExtraData.Type<T> type, T value) {
            extraData.put(type, value);
            return this;
        }

        public CaptureParameters build() {
            return new CaptureParameters(exposureId,
                    Optional.ofNullable(this.cameraId),
                    Optional.ofNullable(this.cameraHolderEntityID),
                    Optional.ofNullable(this.fov),
                    this.cropFactor,
                    Optional.ofNullable(this.filter),
                    Optional.ofNullable(this.projection),
                    Optional.ofNullable(this.chromaticChannel),
                    this.filmProperties,
                    this.extraData);
        }
    }
}
