package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.world.photograph.PhotographType;
import net.minecraft.class_1799;

public class AgedPhotographItem extends PhotographItem {
    public AgedPhotographItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public PhotographType getType(class_1799 stack) {
        return PhotographType.AGED;
    }
}
