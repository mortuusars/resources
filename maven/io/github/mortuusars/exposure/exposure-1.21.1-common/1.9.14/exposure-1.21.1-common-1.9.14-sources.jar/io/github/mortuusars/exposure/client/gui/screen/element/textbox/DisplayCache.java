package io.github.mortuusars.exposure.client.gui.screen.element.textbox;

import io.github.mortuusars.exposure.util.Pos2i;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.commons.lang3.mutable.MutableInt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_327;
import net.minecraft.class_5225;
import net.minecraft.class_768;

public class DisplayCache {
    public String fullText = "";
    public Pos2i cursorPos = new Pos2i(0, 0);
    public boolean cursorAtEnd = true;
    public int[] lineStarts = new int[]{0};
    public LineInfo[] lines = new LineInfo[]{LineInfo.EMPTY};
    public class_768[] selectionAreas = new class_768[0];

    public boolean needsRebuilding = true;
    public int x;
    public int y;
    public int width;
    public int height;
    public HorizontalAlignment alignment = HorizontalAlignment.LEFT;

    public int getIndexAtPosition(class_327 font, Pos2i cursorPosition) {
        int lineIndex = cursorPosition.y / font.field_2000;

        if (lineIndex < 0)
            return 0;
        else if (lineIndex >= this.lines.length)
            return this.fullText.length();

        LineInfo lineInfo = this.lines[lineIndex];

        return this.lineStarts[lineIndex] + font.method_27527()
                .method_27484(lineInfo.contents, cursorPosition.x - lineInfo.x, lineInfo.style);
    }

    public int changeLine(int xChange, int yChange) {
        int m;
        int i = findLineFromPos(this.lineStarts, xChange);
        int j = i + yChange;
        if (0 <= j && j < this.lineStarts.length) {
            int k = xChange - this.lineStarts[i];
            int l = this.lines[j].contents.length();
            m = this.lineStarts[j] + Math.min(k, l);
        } else {
            m = xChange;
        }
        return m;
    }

    public int findLineStart(int line) {
        int i = findLineFromPos(this.lineStarts, line);
        return this.lineStarts[i];
    }

    public int findLineEnd(int line) {
        int i = findLineFromPos(this.lineStarts, line);
        return this.lineStarts[i] + this.lines[i].contents.length();
    }

    protected int findLineFromPos(int[] lineStarts, int find) {
        int i = Arrays.binarySearch(lineStarts, find);
        if (i < 0) {
            return -(i + 2);
        }
        return i;
    }

    public void rebuild(class_327 font, String text, int cursorIndex, int selectionIndex, int x, int y, int width, int height,
                        HorizontalAlignment alignment) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.alignment = alignment;

        this.needsRebuilding = false;

        if (text.isEmpty()) {
            this.fullText = "";
            this.cursorPos = new Pos2i(alignment.align(width, font.method_1727("_")), 0);
            this.cursorAtEnd = true;
            this.lineStarts = new int[]{0};
            this.lines = new LineInfo[]{LineInfo.EMPTY};
            this.selectionAreas = new class_768[0];
            return;
        }

        IntArrayList lineStartIndexes = new IntArrayList();
        List<LineInfo> lines = new ArrayList<>();
        MutableInt linesCount = new MutableInt();
        MutableBoolean endsOnNewLine = new MutableBoolean();

        class_5225 stringSplitter = font.method_27527();
        stringSplitter.method_27485(text, width, class_2583.field_24360, true, (style, lineStartIndex, lineEndIndex) -> {
            int lineIndex = linesCount.getAndIncrement();
            String lineText = text.substring(lineStartIndex, lineEndIndex);
            endsOnNewLine.setValue(lineText.endsWith("\n"));
            lineText = StringUtils.stripEnd(lineText, "\n");

            int contentWidth = (int) stringSplitter.method_27482(lineText);
            int lineXPos = alignment.align(width, contentWidth);
            int lineYPos = lineIndex * font.field_2000;

            lineStartIndexes.add(lineStartIndex);

            lines.add(new DisplayCache.LineInfo(style, lineText, lineXPos, lineYPos, contentWidth, font.field_2000));
        });

        this.fullText = text;
        this.lines = lines.toArray(DisplayCache.LineInfo[]::new);

        int cursorX;
        Pos2i newCursorPos;
        int[] lineStartIndexesArray = lineStartIndexes.toIntArray();
        boolean isCursorAtTextEnd = cursorIndex == text.length();

        if (isCursorAtTextEnd && endsOnNewLine.isTrue()) {
            newCursorPos = new Pos2i(alignment.align(this.width, font.method_1727("_")), lines.size() * font.field_2000);
        } else {
            int lineIndex = findLineFromPos(lineStartIndexesArray, cursorIndex);
            LineInfo line = lines.get(lineIndex);

            String lineTextToCursor = text.substring(lineStartIndexesArray[lineIndex], cursorIndex);

            cursorX = line.x + (int)stringSplitter.method_27482(lineTextToCursor);
            newCursorPos = new Pos2i(cursorX, line.y);
        }

        List<class_768> selections = cursorIndex != selectionIndex ?
                createSelectionAreas(font, text, this.lines, cursorIndex, selectionIndex, stringSplitter, lineStartIndexesArray)
                : Collections.emptyList();

        this.cursorPos = newCursorPos;
        this.cursorAtEnd = isCursorAtTextEnd;
        this.lineStarts = lineStartIndexesArray;
        this.selectionAreas = selections.toArray(class_768[]::new);
    }

    private List<class_768> createSelectionAreas(class_327 font, String fullText, LineInfo[] lines, int cursorPos, int selectionPos, class_5225 stringSplitter, int[] lineStartIndexesArray) {
        int startIndex = Math.min(cursorPos, selectionPos);
        int endIndex = Math.max(cursorPos, selectionPos);
        int lineAtStart = findLineFromPos(lineStartIndexesArray, startIndex);
        int lineAtEnd = findLineFromPos(lineStartIndexesArray, endIndex);

        List<class_768> areas = new ArrayList<>();


        for (int lineIndex = lineAtStart; lineIndex <= lineAtEnd; lineIndex++) {
            LineInfo line = lines[lineIndex];
            int lineStartIndex = lineStartIndexesArray[lineIndex];

            String selectedText = fullText.substring(
                    Math.max(startIndex, lineStartIndex),
                    lineIndex == lineAtEnd ? endIndex : lineStartIndexesArray[lineIndex + 1]);

            int selectionWidth = (int) stringSplitter.method_27482(selectedText);

            String unselectedText = fullText.substring(lineStartIndex, Math.max(startIndex, lineStartIndex));
            int selectionX = startIndex > lineStartIndex ? (int)stringSplitter.method_27482(unselectedText) : 0;

            areas.add(new class_768(line.x + selectionX, line.y, selectionWidth, font.field_2000));
        }

        return areas;
    }

    public static class LineInfo {
        public static final LineInfo EMPTY = new LineInfo(class_2583.field_24360, "", 0, 0, 0, 0);

        public final class_2583 style;
        public final String contents;
        public final class_2561 asComponent;
        public final int x;
        public final int y;
        public final int width;
        public final int height;

        public LineInfo(class_2583 style, String contents, int x, int y, int width, int height) {
            this.style = style;
            this.contents = contents;
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.asComponent = class_2561.method_43470(contents).method_10862(style);
        }
    }
}
