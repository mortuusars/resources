package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.server.CameraInstances;
import io.github.mortuusars.exposure.util.TranslatableError;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record InterplanarProjectionFinishedC2SP(CameraId cameraId,
                                                boolean successful,
                                                Optional<TranslatableError> error) implements Packet {
    public static final class_2960 ID = Exposure.resource("interplanar_projection_finished");
    public static final class_9154<InterplanarProjectionFinishedC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, InterplanarProjectionFinishedC2SP> STREAM_CODEC = class_9139.method_56436(
            CameraId.STREAM_CODEC, InterplanarProjectionFinishedC2SP::cameraId,
            class_9135.field_48547, InterplanarProjectionFinishedC2SP::successful,
            class_9135.method_56382(TranslatableError.STREAM_CODEC), InterplanarProjectionFinishedC2SP::error,
            InterplanarProjectionFinishedC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        CameraInstances.ifPresent(cameraId, cameraInstance -> cameraInstance.setProjectionResult(player.method_37908(), successful, error));
        return true;
    }
}
