package io.github.mortuusars.exposure.client.gui.toast;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_372;

public interface ToastIcon {
    ToastIcon MOVEMENT_KEYS = new TutorialIcon(class_372.class_373.field_2230);
    ToastIcon MOUSE = new TutorialIcon(class_372.class_373.field_2237);
    ToastIcon TREE = new TutorialIcon(class_372.class_373.field_2235);
    ToastIcon RECIPE_BOOK = new TutorialIcon(class_372.class_373.field_2233);
    ToastIcon WOODEN_PLANKS = new TutorialIcon(class_372.class_373.field_2236);
    ToastIcon SOCIAL_INTERACTIONS = new TutorialIcon(class_372.class_373.field_26848);
    ToastIcon RIGHT_CLICK = new TutorialIcon(class_372.class_373.field_28782);
    ToastIcon HOVER = new SpriteIcon(Exposure.resource("toast/hover"));
    ToastIcon F1 = new SpriteIcon(Exposure.resource("toast/f1"));
    ToastIcon HEADS_UP = new SpriteIcon(Exposure.resource("toast/heads_up"));

    void render(class_332 guiGraphics, int x, int y);

    class SpriteIcon implements ToastIcon {
        protected final class_2960 sprite;

        public SpriteIcon(class_2960 sprite) {
            this.sprite = sprite;
        }

        public void render(class_332 guiGraphics, int x, int y) {
            RenderSystem.enableBlend();
            guiGraphics.method_52706(this.sprite, x, y, 20, 20);
        }
    }

    class TutorialIcon implements ToastIcon {
        protected final class_372.class_373 icon;

        public TutorialIcon(class_372.class_373 icon) {
            this.icon = icon;
        }

        @Override
        public void render(class_332 guiGraphics, int x, int y) {
            icon.method_1994(guiGraphics, x, y);
        }
    }
}
