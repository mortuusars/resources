package io.github.mortuusars.exposure.client.image.modifier.pixel;

import net.minecraft.class_3532;
import net.minecraft.class_5253;

public class NegativeFilmEffect implements PixelEffect {
    @Override
    public String getIdentifier() {
        return "negative-film";
    }

    public int modify(int ARGB) {
        int alpha = class_5253.class_5254.method_27762(ARGB);
        int red = class_5253.class_5254.method_27765(ARGB);
        int green = class_5253.class_5254.method_27766(ARGB);
        int blue = class_5253.class_5254.method_27767(ARGB);

        // Modify opacity to make lighter colors transparent, like in real film.
        int lightness = (red + green + blue) / 3;
        int opacity = (int) class_3532.method_15363(lightness * 1.5f, 0, 255);
        alpha = (alpha * opacity) / 255;

        // Invert
        red = 255 - red;
        green = 255 - green;
        blue = 255 - blue;

        return class_5253.class_5254.method_27764(alpha, red, green, blue);
    }
}
