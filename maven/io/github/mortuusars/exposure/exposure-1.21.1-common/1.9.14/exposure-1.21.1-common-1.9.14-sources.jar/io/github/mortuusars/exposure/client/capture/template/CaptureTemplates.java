package io.github.mortuusars.exposure.client.capture.template;

import com.google.common.base.Preconditions;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2960;

public class CaptureTemplates {
    private static final Map<class_2960, CaptureTemplate> TEMPLATES = new HashMap<>();

    public static void register(class_2960 id, CaptureTemplate template) {
        Preconditions.checkState(!TEMPLATES.containsKey(id), "Template with id '%s' is already registered.", id);
        TEMPLATES.put(id, template);
    }

    public static @Nullable CaptureTemplate get(class_2960 id) {
        return TEMPLATES.get(id);
    }

    public static CaptureTemplate getOrThrow(class_2960 id) {
        @Nullable CaptureTemplate template = TEMPLATES.get(id);
        Preconditions.checkNotNull(template, "No template for id '%s' is registered.", id);
        return template;
    }
}
