package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.world.camera.CameraId;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

public record UniqueSoundPlayShutterTickingS2CP(int entityId,
                                                CameraId cameraId,
                                                float volume,
                                                float pitch,
                                                int durationTicks) implements Packet {
    public static final class_2960 ID = Exposure.resource("unique_sound_play_shutter_ticking");
    public static final class_9154<UniqueSoundPlayShutterTickingS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, UniqueSoundPlayShutterTickingS2CP> STREAM_CODEC = class_9139.method_56906(
            class_9135.field_48550, UniqueSoundPlayShutterTickingS2CP::entityId,
            CameraId.STREAM_CODEC, UniqueSoundPlayShutterTickingS2CP::cameraId,
            class_9135.field_48552, UniqueSoundPlayShutterTickingS2CP::volume,
            class_9135.field_48552, UniqueSoundPlayShutterTickingS2CP::pitch,
            class_9135.field_48550, UniqueSoundPlayShutterTickingS2CP::durationTicks,
            UniqueSoundPlayShutterTickingS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.playShutterTickingSound(this);
        return true;
    }
}
