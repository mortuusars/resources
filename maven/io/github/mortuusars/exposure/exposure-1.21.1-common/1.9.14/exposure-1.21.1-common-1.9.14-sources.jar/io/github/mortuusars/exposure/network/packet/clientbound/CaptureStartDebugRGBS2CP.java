package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.capture.CaptureParameters;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record CaptureStartDebugRGBS2CP(class_2960 templateId, List<CaptureParameters> captureProperties) implements Packet {
    public static final class_2960 ID = Exposure.resource("capture_start_debug_rgb");
    public static final class_9154<CaptureStartDebugRGBS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, CaptureStartDebugRGBS2CP> STREAM_CODEC = class_9139.method_56435(
            class_2960.field_48267, CaptureStartDebugRGBS2CP::templateId,
            CaptureParameters.STREAM_CODEC.method_56433(class_9135.method_58000(3)), CaptureStartDebugRGBS2CP::captureProperties,
            CaptureStartDebugRGBS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.startDebugRGBCapture(this);
        return true;
    }
}
