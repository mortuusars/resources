package io.github.mortuusars.exposure.client.gui.screen.element;

import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.util.PagingDirection;
import io.github.mortuusars.exposure.world.sound.SoundEffect;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1109;
import net.minecraft.class_156;
import net.minecraft.class_3532;
import net.minecraft.class_4264;

public class Pager {
    protected int pagesCount;
    protected boolean cycle;
    protected int changeCooldownMs = 50;
    protected @Nullable SoundEffect changeSound = null;
    protected @Nullable class_4264 previousPageButton = null;
    protected @Nullable class_4264 nextPageButton = null;
    protected OnPageChanged onPageChanged = (oldPage, newPage) -> {
    };

    protected int currentPage;
    protected long lastChangeTime;

    // --

    public int getPagesCount() {
        return pagesCount;
    }

    public Pager setPagesCount(int pages) {
        this.pagesCount = pages;
        changePage(getPage()); // Updates current page to new range if needed
        return this;
    }

    public boolean isCycled() {
        return cycle;
    }

    public Pager setCycled(boolean cycled) {
        this.cycle = cycled;
        return this;
    }

    public int getChangeCooldown() {
        return changeCooldownMs;
    }

    public Pager setChangeCooldown(int milliseconds) {
        this.changeCooldownMs = milliseconds;
        return this;
    }

    public Optional<SoundEffect> getChangeSound() {
        return Optional.ofNullable(changeSound);
    }

    public Pager setChangeSound(@Nullable SoundEffect changeSound) {
        this.changeSound = changeSound;
        return this;
    }

    public Optional<class_4264> getPreviousPageButton() {
        return Optional.ofNullable(previousPageButton);
    }

    public Pager setPreviousPageButton(@Nullable class_4264 previousPageButton) {
        this.previousPageButton = previousPageButton;
        updateButtonVisibility();
        return this;
    }

    public Optional<class_4264> getNextPageButton() {
        return Optional.ofNullable(nextPageButton);
    }

    public Pager setNextPageButton(@Nullable class_4264 nextPageButton) {
        this.nextPageButton = nextPageButton;
        updateButtonVisibility();
        return this;
    }

    public OnPageChanged getOnPageChanged() {
        return onPageChanged;
    }

    public Pager onPageChanged(OnPageChanged onPageChanged) {
        this.onPageChanged = onPageChanged;
        return this;
    }

    // --

    public int getPage() {
        return currentPage;
    }

    public boolean changePage(int page) {
        page = class_3532.method_15340(page, 0, this.pagesCount);
        int oldPage = currentPage;
        if (currentPage == page) {
            return false;
        }
        currentPage = page;
        pageChanged(oldPage, page);
        return true;
    }

    /**
     * Sets page without side effects (except button visibility). Useful when setting up starting page.
     */
    public void setPage(int index) {
        currentPage = class_3532.method_15340(index, 0, this.pagesCount);
        updateButtonVisibility();
    }

    public boolean isOnCooldown() {
        return class_156.method_658() - lastChangeTime < changeCooldownMs;
    }

    public void resetCooldown() {
        lastChangeTime = 0;
    }

    public boolean isPagingDirectionAvailable(PagingDirection direction) {
        int newIndex = getPage() + direction.getValue();
        return pagesCount > 1 && (cycle || (0 <= newIndex && newIndex < pagesCount));
    }

    public boolean canChangePage(PagingDirection direction) {
        return isPagingDirectionAvailable(direction) && !isOnCooldown();
    }

    public boolean previousPage() {
        return changePage(PagingDirection.PREVIOUS);
    }

    public boolean nextPage() {
        return changePage(PagingDirection.NEXT);
    }

    public boolean changePage(PagingDirection direction) {
        if (!canChangePage(direction)) {
            return false;
        }

        int oldPage = currentPage;
        int newPage = getPage() + direction.getValue();

        if (cycle && newPage >= pagesCount)
            newPage = 0;
        else if (cycle && newPage < 0)
            newPage = pagesCount - 1;

        if (oldPage == newPage)
            return false;

        return changePage(newPage);
    }

    public void pageChanged(int oldPage, int newPage) {
        lastChangeTime = class_156.method_658();
        playChangeSound();
        updateButtonVisibility();
        onPageChanged.pageChanged(oldPage, newPage);
    }

    // --

    public void updateButtonVisibility() {
        if (previousPageButton != null) {
            previousPageButton.field_22764 = isPagingDirectionAvailable(PagingDirection.PREVIOUS);
        }
        if (nextPageButton != null) {
            nextPageButton.field_22764 = isPagingDirectionAvailable(PagingDirection.NEXT);
        }
    }

    public void playChangeSound() {
        getChangeSound().ifPresent(sound -> Minecrft.get().method_1483().method_4873(
                class_1109.method_4757(sound.get(), sound.getFinalPitch(), sound.volume())));
    }

    @FunctionalInterface
    public interface OnPageChanged {
        void pageChanged(int oldPage, int newPage);
    }
}
