package io.github.mortuusars.exposure.client.gui.screen.camera.button;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.item.camera.Attachment;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_7919;
import net.minecraft.class_8666;
import io.github.mortuusars.exposure.world.item.FilmRollItem;
import org.jetbrains.annotations.NotNull;

public class FrameCounterButton extends class_344 {
    protected final int secondaryFontColor;
    protected final int mainFontColor;

    public FrameCounterButton(int x, int y, int width, int height, class_8666 sprites) {
        super(x, y, width, height, sprites, button -> {});
        mainFontColor = Config.getColor(Config.Client.VIEWFINDER_FONT_MAIN_COLOR);
        secondaryFontColor = Config.getColor(Config.Client.VIEWFINDER_FONT_SECONDARY_COLOR);
    }

    @Override
    public void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float pPartialTick) {
        class_5250 tooltipComponent = class_2561.method_43471("gui.exposure.camera_controls.film_frame_counter.tooltip");
        if (!cameraHasFilmRoll()) {
            tooltipComponent.method_10852(class_5244.field_33849)
                    .method_10852(class_2561.method_43471("gui.exposure.camera_controls.film_frame_counter.tooltip.no_film")
                            .method_27696(class_2583.field_24360.method_36139(0xdd6357)));
        }
        method_47400(class_7919.method_47407(tooltipComponent));

        super.method_48579(guiGraphics, mouseX, mouseY, pPartialTick);

        String text = createText();

        class_327 font = class_310.method_1551().field_1772;
        int textWidth = font.method_1727(text);
        int xPos = 15 + (27 - textWidth) / 2;

        guiGraphics.method_51433(font, text, method_46426() + xPos, method_46427() + 8, secondaryFontColor, false);
        guiGraphics.method_51433(font, text, method_46426() + xPos, method_46427() + 7, mainFontColor, false);
    }

    protected String createText() {
        return Minecrft.player().getActiveExposureCameraOptional().map(camera -> {
            class_1799 filmStack = Attachment.FILM.get(camera.getItemStack()).getForReading();
            if (filmStack.method_7960() || !(filmStack.method_7909() instanceof FilmRollItem filmItem)) {
                return "-";
            }

            int exposedFrames = filmItem.getStoredFrames(filmStack).size();
            int totalFrames = filmItem.getMaxFrameCount(filmStack);
            return exposedFrames + "/" + totalFrames;
        }).orElse("-");
    }

    protected boolean cameraHasFilmRoll() {
        return Minecrft.player().getActiveExposureCameraOptional()
                .map(camera -> Attachment.FILM.isPresent(camera.getItemStack()))
                .orElse(false);
    }
}
