package io.github.mortuusars.exposure.client.sound.instance;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.world.camera.CameraInHand;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import net.minecraft.class_1106;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;

public class ShutterTickingSoundInstance extends class_1106 {
    protected final CameraId cameraId;
    protected final float fullVolume;
    protected final int durationTicks;
    protected final long endsAtTick;

    protected class_1297 entity;

    public ShutterTickingSoundInstance(class_1297 entity, CameraId cameraId, class_3414 soundEvent,
                                       class_3419 soundSource, float volume, float pitch, int durationTicks) {
        super(soundEvent, soundSource, volume, pitch, entity, entity.method_59922().method_43055());
        this.entity = entity;
        this.cameraId = cameraId;
        this.fullVolume = volume;
        this.durationTicks = durationTicks;
        this.endsAtTick = entity.method_37908().method_8510() + durationTicks;
        this.field_5446 = true;
        this.field_5442 = 0;
    }

    public void updateEntity(class_1297 entity) {
        this.entity = entity;
    }

    @Override
    public boolean method_4785() {
        return true;
    }

    @Override
    public boolean method_26273() {
        return !this.entity.method_5701();
    }

    @Override
    public void method_16896() {
        this.field_5439 = this.entity.method_23317();
        this.field_5450 = this.entity.method_23318();
        this.field_5449 = this.entity.method_23321();

        if (endsAtTick - entity.method_37908().method_8510() < 0) {
            method_24876();
            return;
        }

        class_1799 stack = class_1799.field_8037;
        boolean isOnHotbar = false;

        if (entity instanceof CameraHolder holder) {
            @Nullable CameraInHand cameraInHand = CameraInHand.find(holder);
            if (cameraInHand != null && cameraInHand.idMatches(cameraId)) {
                stack = cameraInHand.getItemStack();
            } else if (entity instanceof class_1657 player) {
                class_1799 hotbarStack = getCameraOnHotbar(player);
                if (!hotbarStack.method_7960()) {
                    stack = hotbarStack;
                    isOnHotbar = true;
                }
            }
        } else if (entity instanceof class_1542 itemEntity) {
            if (itemEntity.method_6983().method_7909() instanceof CameraItem)
                stack = itemEntity.method_6983();
        }

        if (stack.method_7909() instanceof CameraItem item && item.getShutter().isOpen(stack)) {
            field_5442 = isOnHotbar ? fullVolume * 0.35f : fullVolume;
        } else {
            field_5442 = 0;
        }
    }

    protected class_1799 getCameraOnHotbar(class_1657 player) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (cameraId.matches(stack)) {
                return stack;
            }
        }
        return class_1799.field_8037;
    }
}
