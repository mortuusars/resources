package io.github.mortuusars.exposure.util;

import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;

public enum Side implements class_3542 {
    LEFT(0, "left"),
    RIGHT(1, "right");

    private final int index;
    private final String name;

    Side(int index, String name) {
        this.index = index;
        this.name = name;
    }

    public int getIndex() {
        return index;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }
}
