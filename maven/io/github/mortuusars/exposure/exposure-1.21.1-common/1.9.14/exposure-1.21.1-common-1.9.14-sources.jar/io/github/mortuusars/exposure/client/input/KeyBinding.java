package io.github.mortuusars.exposure.client.input;

import java.util.function.*;
import net.minecraft.class_3675;

public record KeyBinding(Key matcher, Supplier<Boolean> handler) {
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return matchesPress(keyCode, scanCode, modifiers) && handler().get();
    }

    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        return matchesRelease(keyCode, scanCode, modifiers) && handler().get();
    }

    public boolean matches(int keyCode, int scanCode, int press, int modifiers) {
        return matcher.matches(keyCode, scanCode, press, modifiers);
    }

    public boolean matchesPress(int keyCode, int scanCode, int modifiers) {
        return matcher.matches(keyCode, scanCode, class_3675.field_31997, modifiers);
    }

    public boolean matchesRelease(int keyCode, int scanCode, int modifiers) {
        return matcher.matches(keyCode, scanCode, class_3675.field_31998, modifiers);
    }
}
