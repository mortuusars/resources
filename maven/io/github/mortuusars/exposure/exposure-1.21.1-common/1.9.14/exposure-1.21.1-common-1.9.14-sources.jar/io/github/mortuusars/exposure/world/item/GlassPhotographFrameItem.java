package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.world.entity.GlassPhotographFrameEntity;
import io.github.mortuusars.exposure.world.entity.PhotographFrameEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import org.jetbrains.annotations.NotNull;

public class GlassPhotographFrameItem extends PhotographFrameItem {
    public GlassPhotographFrameItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public @NotNull PhotographFrameEntity createEntity(class_1937 level, class_2338 pos, class_2350 direction) {
        return new GlassPhotographFrameEntity(level, pos, direction);
    }
}