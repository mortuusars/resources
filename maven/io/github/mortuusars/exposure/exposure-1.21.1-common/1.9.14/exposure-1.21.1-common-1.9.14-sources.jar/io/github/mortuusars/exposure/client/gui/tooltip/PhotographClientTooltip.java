package io.github.mortuusars.exposure.client.gui.tooltip;

import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import io.github.mortuusars.exposure.world.inventory.tooltip.PhotographTooltip;
import io.github.mortuusars.exposure.world.item.util.ItemAndStack;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4597;
import net.minecraft.class_5684;
import net.minecraft.class_765;

public class PhotographClientTooltip implements class_5684 {
    public static final int SIZE = 72;

    protected final PhotographTooltip tooltip;
    protected final List<ItemAndStack<PhotographItem>> photographs;

    public PhotographClientTooltip(PhotographTooltip tooltip) {
        this.tooltip = tooltip;
        this.photographs = tooltip.photographs();
    }

    @Override
    public int method_32664(@NotNull class_327 font) {
        return SIZE;
    }

    @Override
    public int method_32661() {
        return SIZE + 2; // 2px bottom margin
    }

    @Override
    public void method_32666(@NotNull class_327 font, int mouseX, int mouseY, class_332 guiGraphics) {
        int photographsCount = photographs.size();
        int additionalPhotographs = Math.min(2, photographsCount - 1);

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(mouseX, mouseY, 5);
        float scale = SIZE;
        float nextPhotographOffset = ExposureClient.photographRenderer().getStackedPhotographOffset();
        scale *= 1f - (additionalPhotographs * nextPhotographOffset);
        guiGraphics.method_51448().method_22905(scale, scale, 1f);

        class_4597.class_4598 bufferSource = class_310.method_1551().method_22940().method_23000();

        ExposureClient.photographRenderer().renderStackedPhotographs(photographs, guiGraphics.method_51448(), bufferSource,
                class_765.field_32767, 255, 255, 255, 255);

        bufferSource.method_22993();

        guiGraphics.method_51448().method_22909();

        // Stack count:
        if (photographsCount > 1) {
            guiGraphics.method_51448().method_22903();
            String count = Integer.toString(photographsCount);
            int fontWidth = class_310.method_1551().field_1772.method_1727(count);
            float fontScale = 1.6f;
            guiGraphics.method_51448().method_46416(
                    mouseX + scale - 2 - fontWidth * fontScale,
                    mouseY + scale - 2 - 8 * fontScale,
                    10);
            guiGraphics.method_51448().method_22905(fontScale, fontScale, fontScale);
            guiGraphics.method_25303(font, count, 0, 0, 0xFFFFFFFF);
            guiGraphics.method_51448().method_22909();
        }
    }
}
