package io.github.mortuusars.exposure.client.camera;

import io.github.mortuusars.exposure.client.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.client.camera.viewfinder.ViewfinderRegistry;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.common.ActiveCameraDeactivateCommonPacket;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1297;

public class CameraClient {
    private static @Nullable Viewfinder activeViewfinder;

    public static void tick() {
        if (activeViewfinder != null) {
            activeViewfinder.tick();
        }
    }

    public static Optional<Camera> getActive() {
        return Minecrft.player().getActiveExposureCameraOptional();
    }

    public static boolean isActive() {
        return getActive().isPresent();
    }

    public static void deactivate() {
        Minecrft.player().getActiveExposureCameraOptional().ifPresent(
              camera -> {
                  camera.map((item, stack) -> item.deactivate(Minecrft.player(), camera.getHolder().asHolderEntity(), stack));
                  Minecrft.player().removeActiveExposureCamera();
                  // Fixes camera getting stuck in some cases, requiring a relog to fix
                  if (Minecrft.get().method_1560() instanceof CameraStandEntity) {
                      resetCameraEntity();
                  }
              });
        Packets.sendToServer(ActiveCameraDeactivateCommonPacket.INSTANCE);
    }

    public static void setCameraEntity(class_1297 entity) {
        // Not using Minecraft#setCameraEntity because it updates postEffect
        Minecrft.get().field_1719 = entity;

        // Set eye height to final value to skip transition animation
        Minecrft.get().field_1773.method_19418().field_18721 = entity.method_5751();
        Minecrft.get().field_1773.method_19418().field_18722 = entity.method_5751();
        Minecrft.get().field_1773.method_19418().method_19337();
    }

    public static void resetCameraEntity() {
        setCameraEntity(Minecrft.player());
    }

    // --

    public static @Nullable Viewfinder viewfinder() {
        return activeViewfinder;
    }

    public static void setupViewfinder(@NotNull Camera camera) {
        removeViewfinder();
        activeViewfinder = ViewfinderRegistry.get(camera);
        activeViewfinder.setup();
    }

    public static void removeViewfinder() {
        if (activeViewfinder != null) {
            activeViewfinder.close();
            activeViewfinder = null;
        }
    }
}