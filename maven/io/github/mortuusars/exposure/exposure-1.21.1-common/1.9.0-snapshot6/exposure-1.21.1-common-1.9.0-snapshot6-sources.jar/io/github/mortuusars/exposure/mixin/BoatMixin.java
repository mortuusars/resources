package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import io.github.mortuusars.exposure.world.item.CameraStandItem;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_8836;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1690.class)
public abstract class BoatMixin extends class_8836 {
    public BoatMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "interact", at = @At("HEAD"), cancellable = true)
    private void onInteract(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        class_1799 itemInHand = player.method_5998(hand);
        if (itemInHand.method_7909() instanceof CameraStandItem cameraStandItem) {
            class_1269 result = cameraStandItem.interactWithBoat(player, hand, ((class_1690)(Object) this));
            if (result != class_1269.field_5811) {
                cir.setReturnValue(result);
                return;
            }
        }
    }

    @Inject(method = "onPassengerTurned", at = @At("HEAD"), cancellable = true)
    private void onPassengerTurned(class_1297 entityToUpdate, CallbackInfo ci) {
        if (entityToUpdate instanceof CameraStandEntity stand) {
            ci.cancel();
        }
    }
}
