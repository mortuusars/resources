package io.github.mortuusars.exposure.client.gui.tooltip;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3966;
import net.minecraft.class_5481;
import net.minecraft.class_8002;
import net.minecraft.class_9779;

public class CameraStandTooltip {
    public static void render(class_332 guiGraphics, class_9779 partialTick) {
        if (!Config.Client.CAMERA_STAND_TOOLTIP.get()) {
            return;
        }

        class_310 minecraft = Minecrft.get();
        if (minecraft.field_1687 == null || minecraft.field_1724 == null) return;
        if (minecraft.field_1755 != null || !(minecraft.field_1765 instanceof class_3966 entityHitResult)) return;
        if (!(entityHitResult.method_17782() instanceof CameraStandEntity stand)) return;
        if (stand.getCamera().method_7960()) return;

        int x = minecraft.method_22683().method_4486() / 2 + 16;
        int y = minecraft.method_22683().method_4502() / 2 - 9;

        if (stand.isMalfunctioned()) {
            List<class_5481> lines = Minecrft.get().field_1772.method_1728(class_2561.method_43471("gui.exposure.camera_stand.tooltip.malfunctioned")
                    .method_27692(class_124.field_1061), 230);
            guiGraphics.method_51447(minecraft.field_1772, lines, x, y + 12);
        } else {
            class_8002.method_47946(guiGraphics, x, y, 18, 18, 400);

            guiGraphics.method_51448().method_22903();
            guiGraphics.method_51448().method_46416(0, 0, 400);
            guiGraphics.method_51427(stand.getCamera(), x + 1, y + 1);
            guiGraphics.method_51448().method_22909();

            guiGraphics.method_51446(minecraft.field_1772, stand.getCamera(), x + 16, y + 12);
        }
    }
}
