package io.github.mortuusars.exposure.client.gui;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_2960;
import net.minecraft.class_8666;

public class Widgets {
    public static final class_8666 PREVIOUS_BUTTON_SPRITES =
            threeStateSprites(Exposure.resource("widgets/previous_button"));
    public static final class_8666 NEXT_BUTTON_SPRITES =
            threeStateSprites(Exposure.resource("widgets/next_button"));
    public static final class_8666 CONFIRM_BUTTON_SPRITES =
            threeStateSprites(Exposure.resource("widgets/confirm_button"));
    public static final class_8666 CANCEL_BUTTON_SPRITES =
            threeStateSprites(Exposure.resource("widgets/cancel_button"));

    public static class_8666 threeStateSprites(class_2960 base) {
        return new class_8666(base,
                class_2960.method_60655(base.method_12836(), base.method_12832() + "_disabled"),
                class_2960.method_60655(base.method_12836(), base.method_12832() + "_highlighted"));
    }

    public static <T> Map<T, class_8666> createMap(List<T> values, Function<T, class_8666> convertFunc) {
        Preconditions.checkArgument(!values.isEmpty(), "values list must not be empty.");
        Map<T, class_8666> map = new HashMap<>();
        for (T value : values) {
            map.put(value, convertFunc.apply(value));
        }
        return map;
    }
}
