package io.github.mortuusars.exposure.world.camera.film.properties;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5699;
import net.minecraft.class_6880;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record FilmProperties(ExposureType type,
                             Optional<Integer> size,
                             class_5321<ColorPalette> colorPalette,
                             FilmStyle style) {
    public FilmProperties(ExposureType type,
                          int size,
                          class_5321<ColorPalette> colorPalette,
                          FilmStyle style) {
        this(type, Optional.of(size), colorPalette, style);
    }

    public FilmProperties {
        size.ifPresent(s -> Preconditions.checkArgument(s > 0 && s <= 2048,
                "size must be 1-2048: " + size));
    }

    public static final Codec<FilmProperties> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            ExposureType.CODEC.optionalFieldOf("type", ExposureType.COLOR).forGetter(FilmProperties::type),
            class_5699.method_48766(0, 2048).optionalFieldOf("frame_size").forGetter(FilmProperties::size),
            class_5321.method_39154(Exposure.Registries.COLOR_PALETTE).optionalFieldOf("color_palette", ColorPalettes.DEFAULT).forGetter(FilmProperties::colorPalette),
            FilmStyle.CODEC.optionalFieldOf("style", FilmStyle.EMPTY).forGetter(FilmProperties::style)
    ).apply(instance, FilmProperties::new));

    public static final class_9139<class_9129, FilmProperties> STREAM_CODEC = new class_9139<>() {
        public @NotNull FilmProperties decode(class_9129 buffer) {
            return new FilmProperties(
                    ExposureType.STREAM_CODEC.decode(buffer),
                    class_9135.method_56382(class_9135.field_48550).decode(buffer),
                    class_5321.method_56038(Exposure.Registries.COLOR_PALETTE).decode(buffer),
                    FilmStyle.STREAM_CODEC.decode(buffer));
        }

        public void encode(class_9129 buffer, FilmProperties data) {
            ExposureType.STREAM_CODEC.encode(buffer, data.type());
            class_9135.method_56382(class_9135.field_48550).encode(buffer, data.size());
            class_5321.method_56038(Exposure.Registries.COLOR_PALETTE).encode(buffer, data.colorPalette());
            FilmStyle.STREAM_CODEC.encode(buffer, data.style());
        }
    };

    public static final FilmProperties EMPTY = new FilmProperties(
            ExposureType.COLOR,
            Optional.empty(),
            ColorPalettes.DEFAULT,
            FilmStyle.EMPTY);

    public FilmProperties withType(ExposureType type) {
        return new FilmProperties(type, size, colorPalette, style);
    }

    public FilmProperties withSize(@Nullable Integer size) {
        return new FilmProperties(type, Optional.ofNullable(size), colorPalette, style);
    }

    public FilmProperties withColorPalette(@NotNull class_5321<ColorPalette> colorPalette) {
        return new FilmProperties(type, size, colorPalette, style);
    }

    public FilmProperties withStyle(@NotNull FilmStyle style) {
        return new FilmProperties(type, size, colorPalette, style);
    }

    // --

    public int getSize() {
        return size.orElse(Config.Server.DEFAULT_FRAME_SIZE.get());
    }

    public class_6880<ColorPalette> getColorPalette(class_5455 access) {
        return ColorPalettes.get(access, colorPalette);
    }
}