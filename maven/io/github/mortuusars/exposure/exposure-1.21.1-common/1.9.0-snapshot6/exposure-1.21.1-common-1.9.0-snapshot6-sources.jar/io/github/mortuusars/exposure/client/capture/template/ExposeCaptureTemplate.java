package io.github.mortuusars.exposure.client.capture.template;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.exposure.client.capture.Capture;
import io.github.mortuusars.exposure.client.capture.action.CaptureAction;
import io.github.mortuusars.exposure.client.capture.palettizer.Palettizer;
import io.github.mortuusars.exposure.client.capture.saving.ExposureUploader;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.util.cycles.task.EmptyTask;
import io.github.mortuusars.exposure.util.cycles.task.Task;
import io.github.mortuusars.exposure.world.camera.capture.CaptureParameters;
import net.minecraft.class_1297;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class ExposeCaptureTemplate implements CaptureTemplate {
    private static final Logger LOGGER = LogUtils.getLogger();

    @Override
    public Task<?> createTask(CaptureParameters params) {
        if (params.exposureId().isEmpty()) {
            LOGGER.error("Failed to create capture task: exposure id cannot be empty. '{}'", params);
            return new EmptyTask<>();
        }

        @Nullable class_1297 entity = Minecrft.level().method_8469(params.cameraHolderId().orElse(Minecrft.player().method_5628()));
        if (entity == null) {
            LOGGER.error("Failed to create capture task: camera holder entity cannot be obtained. '{}'", params);
            return new EmptyTask<>();
        }

        class_6880<ColorPalette> palette = getColorPalette(params);

        return Capture.of(Capture.screenshot(),
                        CaptureAction.setCameraEntity(entity),
                        CaptureAction.optional(params.fov(), CaptureAction::setFov),
                        CaptureAction.setFilter(params.filter()),
                        CaptureAction.hideGui(),
                        CaptureAction.forceRegularOrSelfieCamera(),
                        CaptureAction.disablePostEffect(),
                        CaptureAction.modifyGamma(params.getShutterSpeed()),
                        CaptureAction.optional(params.getFlash(), () -> CaptureAction.flash(entity)))
                .handleErrorAndGetResult(err -> LOGGER.error(err.technical().getString()))
                .thenAsync(applyEffectsToImage(params))
                .thenAsync(Palettizer.DITHERED.palettizeAndClose(palette.comp_349()))
                .thenAsync(convertToExposureData(palette, createExposureTag(params, false)))
                .acceptAsync(image -> ExposureUploader.upload(params.exposureId(), image))
                .onError(err -> LOGGER.error(err.technical().getString()));
    }
}
