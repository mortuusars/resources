package io.github.mortuusars.exposure.client.capture.action;

import net.minecraft.class_310;
import net.minecraft.class_5498;

public class ForceRegularOrSelfieCameraTypeAction implements CaptureAction {
    private class_5498 cameraTypeBeforeCapture = class_5498.field_26664;

    @Override
    public void beforeCapture() {
        cameraTypeBeforeCapture = class_310.method_1551().field_1690.method_31044();
        if (cameraTypeBeforeCapture == class_5498.field_26665) {
            class_310.method_1551().field_1690.method_31043(class_5498.field_26664);
        }
    }

    @Override
    public void afterCapture() {
        class_310.method_1551().field_1690.method_31043(cameraTypeBeforeCapture);
    }
}
