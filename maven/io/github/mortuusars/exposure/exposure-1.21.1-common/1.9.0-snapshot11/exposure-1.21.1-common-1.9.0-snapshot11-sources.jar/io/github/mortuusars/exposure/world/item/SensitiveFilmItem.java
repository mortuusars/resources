package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.world.camera.film.properties.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public interface SensitiveFilmItem extends FilmItem {
    default @NotNull FilmProperties getFilmProperties(class_1799 stack) {
        return new FilmProperties(getType(), getFrameSize(stack), getColorPalette(stack), getFilmStyle(stack));
    }

    default @NotNull FilmStyle getFilmStyle(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.FILM_STYLE, FilmStyle.EMPTY);
    }

    default class_5321<ColorPalette> getColorPalette(class_1799 stack) {
        @Nullable class_2960 location = stack.method_57824(Exposure.DataComponents.FILM_COLOR_PALETTE);
        if (location != null) return ColorPalettes.createKey(location);
        return ColorPalettes.DEFAULT;
    }

    // --

    default void addFrameSizeToTooltip(class_1799 stack, List<class_2561> list) {
        int frameSize = getFrameSize(stack);
        if (frameSize != getDefaultFrameSize(stack)) {
            list.add(class_2561.method_43469("item.exposure.film_roll.tooltip.frame_size",
                            class_2561.method_43470(String.format("%.1f", frameSize / 10f)))
                    .method_27692(class_124.field_1080));
        }
    }

    default void addPaletteToTooltip(class_1799 stack, List<class_2561> list) {
        class_5321<ColorPalette> palette = getColorPalette(stack);
        if (!palette.equals(ColorPalettes.DEFAULT)) {
            list.add(class_2561.method_43469("item.exposure.film_roll.tooltip.palette", palette.method_29177().toString())
                    .method_27692(class_124.field_1063));
        }
    }

    default void addStyleToTooltip(class_1799 stack, List<class_2561> list) {
        FilmStyle style = getFilmStyle(stack);
        if (style.sensitivity() != 0) {
            list.add(class_2561.method_43469("item.exposure.film_roll.tooltip.sensitivity", style.sensitivity())
                    .method_27692(class_124.field_1063));
        }
        if (style.contrast() != 0) {
            list.add(class_2561.method_43469("item.exposure.film_roll.tooltip.contrast", style.contrast())
                    .method_27692(class_124.field_1063));
        }
        if (style.levels() != Levels.EMPTY) {
            list.add(class_2561.method_43469("item.exposure.film_roll.tooltip.levels", style.levels().toString())
                    .method_27692(class_124.field_1063));
        }
        if (style.hsb() != HSB.EMPTY) {
            list.add(class_2561.method_43469("item.exposure.film_roll.tooltip.hsb", style.hsb().toString())
                    .method_27692(class_124.field_1063));
        }
        if (style.colorBalance() != ColorBalance.EMPTY) {
            list.add(class_2561.method_43469("item.exposure.film_roll.tooltip.color_balance", style.colorBalance().toString())
                    .method_27692(class_124.field_1063));
        }
        if (style.noise() != 0f) {
            list.add(class_2561.method_43469("item.exposure.film_roll.tooltip.noise", style.noise())
                    .method_27692(class_124.field_1063));
        }
    }
}
