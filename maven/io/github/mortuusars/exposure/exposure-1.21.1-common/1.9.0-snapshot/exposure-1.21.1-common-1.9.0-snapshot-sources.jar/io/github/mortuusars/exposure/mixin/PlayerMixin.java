package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.camera.CameraOnStand;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.entity.CameraOperator;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

@Mixin(class_1657.class)
@SuppressWarnings("AddedMixinMembersNamePattern")
public abstract class PlayerMixin extends class_1309 implements CameraHolder, CameraOperator {
    @Shadow
    public abstract class_1661 getInventory();

    @Unique
    @Nullable
    protected Camera activeExposureCamera;

    @Unique
    protected float oExposureCameraActionAnim = 0F;
    @Unique
    protected float exposureCameraActionAnim = 0F;

    protected PlayerMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    // --

    @Override
    public @NotNull class_1657 getPlayerExecutingExposure() {
        return (class_1657) (Object) this;
    }

    @Override
    public Optional<class_1657> getPlayerAwardedForExposure() {
        return Optional.of((class_1657) (Object) this);
    }

    @Override
    public @NotNull class_1297 getExposureAuthorEntity() {
        return this;
    }

    @Override
    public Optional<CameraOperator> getExposureCameraOperator() {
        return Optional.of(this);
    }

    // --

    @Override
    public @Nullable Camera getActiveExposureCamera() {
        if (activeExposureCamera != null && !activeExposureCamera.isActive()) {
            return null;
        }
        return activeExposureCamera;
    }

    @Override
    public void setActiveExposureCamera(@Nullable Camera camera) {
        activeExposureCamera = camera;
    }

    @Override
    public void removeActiveExposureCamera() {
        activeExposureCamera = null;
    }

    @Override
    public float getExposureCameraActionAnim(float partialTick) {
        float delta = exposureCameraActionAnim - oExposureCameraActionAnim;
        if (delta < 0.0F) {
            delta++;
        }

        return oExposureCameraActionAnim + delta * partialTick;
    }

    // --

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        if (!method_37908().method_8608() && activeExposureCamera != null && !activeExposureCamera.isActive()) {
            activeExposureCamera.deactivate();
            removeActiveExposureCamera();
        }

        oExposureCameraActionAnim = exposureCameraActionAnim;

        long lastActionTime = -1L;

        if (activeExposureCamera != null) {
            lastActionTime = activeExposureCamera.map(CameraItem::getLastActionTime).orElse(-1L);
        } else if (method_6047().method_7909() instanceof CameraItem item) {
            lastActionTime = item.getLastActionTime(method_6047());
        } else if (method_6079().method_7909() instanceof CameraItem item) {
            lastActionTime = item.getLastActionTime(method_6079());
        }

        int actionTime = (int) (method_37908().method_8510() - lastActionTime);
        exposureCameraActionAnim = Math.clamp(actionTime / 10F, 0F, 1F);
    }

    @Inject(method = "blockActionRestricted", at = @At("HEAD"), cancellable = true)
    private void onBlockActionRestricted(class_1937 level, class_2338 pos, class_1934 gameMode, CallbackInfoReturnable<Boolean> cir) {
        if (getActiveExposureCamera() instanceof CameraOnStand) {
            cir.setReturnValue(true);
        }
    }
}
