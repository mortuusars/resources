package io.github.mortuusars.exposure.client.capture.template;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.client.image.Image;
import io.github.mortuusars.exposure.client.image.PalettedImage;
import io.github.mortuusars.exposure.client.image.modifier.ImageEffect;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.capture.CaptureParameters;
import io.github.mortuusars.exposure.util.cycles.task.Task;
import io.github.mortuusars.exposure.world.camera.film.properties.FilmProperties;
import io.github.mortuusars.exposure.world.level.storage.ExposureData;
import io.github.mortuusars.exposure.util.TranslatableError;
import io.github.mortuusars.exposure.util.UnixTimestamp;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_2960;
import net.minecraft.class_6880;

public interface CaptureTemplate {
    Task<?> createTask(CaptureParameters params);

    default class_6880<ColorPalette> getColorPalette(CaptureParameters params) {
        return params.filmProperties().colorPalette().orElse(ColorPalettes.getDefault(Minecrft.registryAccess()));
    }

    default Function<Image, Image> applyEffectsToImage(CaptureParameters params) {
        FilmProperties filmProperties = params.filmProperties();
        return ImageEffect.chain(
                ImageEffect.Crop.SQUARE_CENTER,
                ImageEffect.Crop.factor(params.cropFactor()),
                ImageEffect.Resize.to(filmProperties.size().orElse(Config.Server.DEFAULT_FRAME_SIZE.get())),
                ImageEffect.exposure(params.getShutterSpeed().getBrightness() * (filmProperties.sensitivity() + 1)),
                ImageEffect.contrast(filmProperties.contrast()),
                ImageEffect.levels(filmProperties.levels()),
                ImageEffect.hsb(filmProperties.hsb()),
                ImageEffect.noise(filmProperties.noise()),
                ImageEffect.optional(params.filmType() == ExposureType.BLACK_AND_WHITE,
                        params.singleChannel()
                                .map(ImageEffect::singleChannelBlackAndWhite)
                                .orElse(ImageEffect.BLACK_AND_WHITE)));
    }

    default Function<PalettedImage, ExposureData> convertToExposureData(class_6880<ColorPalette> palette, ExposureData.Tag tag) {
        class_2960 paletteId = palette.method_40230().orElseThrow().method_29177();
        return image -> new ExposureData(image.width(), image.height(), image.pixels(), paletteId, tag);
    }

    default ExposureData.Tag createExposureTag(CaptureParameters data, boolean isLoaded) {
        return new ExposureData.Tag(data.filmType(), Minecrft.player().method_5820(),
                UnixTimestamp.Seconds.now(), isLoaded, false);
    }

    default @NotNull Consumer<TranslatableError> printCasualErrorInChat() {
        return err -> {
            Minecrft.execute(() -> Minecrft.player().method_7353(
                    err.casual().method_27692(class_124.field_1061), false));
            Exposure.LOGGER.error(err.technical().getString());
        };
    }
}
