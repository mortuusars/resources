package io.github.mortuusars.exposure.world.entity;

import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3222;

/**
 * Injected in Entities such as {@link net.minecraft.class_1657} and others in the future. <br>
 * Injected interfaces must have all methods as 'default'.
 */
public interface CameraHolder {
    /**
     * Player that captures the image (renders it).
     */
    default @NotNull class_1657 getPlayerExecutingExposure() {
        throw new IllegalStateException("This method must be implemented, " +
                "and should return a player that will render the image.");
    }

    /**
     * Used to trigger advancements and award stats.
     */
    default Optional<class_1657> getPlayerAwardedForExposure() {
        throw new IllegalStateException("This method must be implemented, " +
                "and should return a player that will receive advancements or stats for exposure (if applicable).");
    }

    default Optional<class_3222> getServerPlayerAwardedForExposure() {
        return getPlayerAwardedForExposure()
                .filter(pl -> pl instanceof class_3222)
                .map(pl -> (class_3222) pl);
    }

    /**
     * Entity that will be treated as an author of a photo.
     */
    default @NotNull class_1297 getExposureAuthorEntity() {
        throw new IllegalStateException("This method must be implemented, " +
                "and should return an entity that will be treated as an author of a photo.");
    }

    default Optional<CameraOperator> getExposureCameraOperator() {
        throw new IllegalStateException("This method must be implemented, and should return an operator (if present).");
    }

    // --

    default class_1297 asHolderEntity() {
        return ((class_1297) this);
    }
}
