package io.github.mortuusars.exposure.world.camera.film.properties;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.util.Codecs;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_5699;
import net.minecraft.class_6880;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record FilmProperties(Optional<Integer> size,
                             Float sensitivity,
                             Float contrast,
                             Levels levels,
                             HSB hsb,
                             ColorBalance colorBalance,
                             Float saturation,
                             Float noise,
                             Optional<class_6880<ColorPalette>> colorPalette) {

    public FilmProperties {
        size.ifPresent(value -> Preconditions.checkArgument(value > 0,
                "size must be >0. Got: " + value));
        Preconditions.checkArgument(sensitivity >= -10f && sensitivity <= 10f,
                "sensitivity must be >=-10 and <= 10. Got: " + sensitivity);
        Preconditions.checkArgument(contrast >= -1f && contrast <= 1f,
                "contrast must be >=-1 and <= 1. Got: " + contrast);
        Preconditions.checkArgument(saturation >= -1f && saturation <= 1f,
                "saturation must be >=-1 and <= 1. Got: " + saturation);
        Preconditions.checkArgument(noise >= 0f && noise <= 1f,
                "noise must be >=0 and <=1. Got: " + noise);
    }

    public static final Codec<FilmProperties> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_5699.method_48766(1, 2048).optionalFieldOf("frame_size").forGetter(FilmProperties::size),
            Codecs.floatRange(-10f, 10f).optionalFieldOf("sensitivity", 0f).forGetter(FilmProperties::sensitivity),
            Codecs.floatRange(-1f, 1f).optionalFieldOf("contrast", 0f).forGetter(FilmProperties::contrast),
            Levels.CODEC.optionalFieldOf("levels", Levels.EMPTY).forGetter(FilmProperties::levels),
            HSB.CODEC.optionalFieldOf("hsb", HSB.EMPTY).forGetter(FilmProperties::hsb),
            ColorBalance.CODEC.optionalFieldOf("color_balance", ColorBalance.EMPTY).forGetter(FilmProperties::colorBalance),
            Codecs.floatRange(-1f, 1f).optionalFieldOf("saturation", 0f).forGetter(FilmProperties::saturation),
            Codecs.floatRange(0f, 1f).optionalFieldOf("noise", 0f).forGetter(FilmProperties::noise),
            ColorPalette.HOLDER_CODEC.optionalFieldOf("color_palette").forGetter(FilmProperties::colorPalette)
    ).apply(instance, FilmProperties::new));

    public static final class_9139<class_9129, FilmProperties> STREAM_CODEC = new class_9139<>() {
        public @NotNull FilmProperties decode(class_9129 buffer) {
            return new FilmProperties(
                    class_9135.method_56382(class_9135.field_48550).decode(buffer),
                    class_9135.field_48552.decode(buffer),
                    class_9135.field_48552.decode(buffer),
                    Levels.STREAM_CODEC.decode(buffer),
                    HSB.STREAM_CODEC.decode(buffer),
                    ColorBalance.STREAM_CODEC.decode(buffer),
                    class_9135.field_48552.decode(buffer),
                    class_9135.field_48552.decode(buffer),
                    class_9135.method_56382(ColorPalette.STREAM_CODEC).decode(buffer));
        }

        public void encode(class_9129 buffer, FilmProperties data) {
            class_9135.method_56382(class_9135.field_48550).encode(buffer, data.size);
            class_9135.field_48552.encode(buffer, data.sensitivity);
            class_9135.field_48552.encode(buffer, data.contrast);
            Levels.STREAM_CODEC.encode(buffer, data.levels);
            HSB.STREAM_CODEC.encode(buffer, data.hsb);
            ColorBalance.STREAM_CODEC.encode(buffer, data.colorBalance);
            class_9135.field_48552.encode(buffer, data.saturation);
            class_9135.field_48552.encode(buffer, data.noise);
            class_9135.method_56382(ColorPalette.STREAM_CODEC).encode(buffer, data.colorPalette);
        }
    };

    public static final FilmProperties EMPTY = new FilmProperties(
            Optional.empty(),
            0f,
            0f,
            Levels.EMPTY,
            HSB.EMPTY,
            ColorBalance.EMPTY,
            0f,
            0f,
            Optional.empty());

    public static FilmProperties create() {
        return EMPTY;
    }

    public FilmProperties withSize(@Nullable Integer size) {
        return new FilmProperties(Optional.ofNullable(size), sensitivity, contrast,
                levels, hsb, colorBalance, saturation, noise, colorPalette);
    }

    public FilmProperties withSensitivity(@Nullable Float sensitivity) {
        return new FilmProperties(size, sensitivity, contrast, levels, hsb, colorBalance, saturation, noise, colorPalette);
    }

    public FilmProperties withContrast(@Nullable Float contrast) {
        return new FilmProperties(size, sensitivity, contrast, levels, hsb, colorBalance, saturation, noise, colorPalette);
    }

    public FilmProperties withLevels(@Nullable Levels levels) {
        return new FilmProperties(size, sensitivity, contrast, levels, hsb, colorBalance, saturation, noise, colorPalette);
    }

    public FilmProperties withHSB(@Nullable HSB hsb) {
        return new FilmProperties(size, sensitivity, contrast, levels, hsb, colorBalance, saturation, noise, colorPalette);
    }

    public FilmProperties withColorBalance(@Nullable ColorBalance colorBalance) {
        return new FilmProperties(size, sensitivity, contrast, levels, hsb, colorBalance, saturation, noise, colorPalette);
    }

    public FilmProperties withSaturation(@Nullable Float saturation) {
        return new FilmProperties(size, sensitivity, contrast, levels, hsb, colorBalance, saturation, noise, colorPalette);
    }

    public FilmProperties withNoise(@Nullable Float noise) {
        return new FilmProperties(size, sensitivity, contrast, levels, hsb, colorBalance, saturation, noise, colorPalette);
    }

    public FilmProperties withColorPalette(@Nullable class_6880<ColorPalette> colorPalette) {
        return new FilmProperties(size, sensitivity, contrast,
                levels, hsb, colorBalance, saturation, noise, Optional.ofNullable(colorPalette));
    }
}