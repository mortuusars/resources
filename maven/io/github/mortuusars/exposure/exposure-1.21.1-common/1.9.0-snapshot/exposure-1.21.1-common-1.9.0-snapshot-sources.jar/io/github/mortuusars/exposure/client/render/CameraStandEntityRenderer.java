package io.github.mortuusars.exposure.client.render;

import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.PlatformHelperClient;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_897;
import org.jetbrains.annotations.NotNull;

public class CameraStandEntityRenderer <T extends CameraStandEntity> extends class_897<T> {
    public static final class_2960 TEXTURE_LOCATION = class_2960.method_60656("textures/item/camera.png");

    protected final class_776 blockRenderer;

    public CameraStandEntityRenderer(class_5617.class_5618 context) {
        super(context);
        this.blockRenderer = context.method_43337();
    }

    @Override
    public @NotNull class_2960 getTextureLocation(T entity) {
        return TEXTURE_LOCATION;
    }

    @Override
    public void render(T entity, float entityYaw, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight) {
        super.method_3936(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);

        float hurtTime = (float)entity.getHurtTime() - partialTick;
        float damage = Math.max(0, entity.getDamage() - partialTick);
        if (hurtTime > 0.0F) {
            float rotation = class_3532.method_15374(hurtTime) * hurtTime * damage / 10.0F * (float) entity.getHurtDir();
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(rotation));
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(rotation));
        }

        float entityPitch = class_3532.method_16439(partialTick, entity.field_6004, entity.method_36455());

        renderStand(entity, entityYaw, entityPitch, partialTick, poseStack, bufferSource, packedLight);
        renderMount(entity, entityYaw, entityPitch, partialTick, poseStack, bufferSource, packedLight);
        if (!entity.getCamera().method_7960()) {
            renderCamera(entity, entityYaw, entityPitch, partialTick, poseStack, bufferSource, packedLight);
        }
    }

    private void renderStand(T entity, float entityYaw, float entityPitch, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight) {
        poseStack.method_22903();

        if (entity.method_5854() != null) {
            float vehicleRot = class_3532.method_16439(partialTick, entity.method_5854().field_5982, entity.method_5854().method_36454());
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(-vehicleRot + 45));
        }

        poseStack.method_46416(-0.5f, 0f, -0.5f);

        class_1091 modelLocation = ExposureClient.Models.CAMERA_STAND;
        class_1087 model = PlatformHelperClient.getModel(modelLocation);
        blockRenderer.method_3350().method_3367(poseStack.method_23760(), bufferSource.getBuffer(class_1921.method_23577()),
                null, model, 1.0f, 1.0f, 1.0f, packedLight, class_4608.field_21444);
        poseStack.method_22909();
    }

    private void renderMount(T entity, float entityYaw, float entityPitch, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight) {
        poseStack.method_22903();
        poseStack.method_22904(0, 1.125, 0);
        float scale = 0.9f;
        poseStack.method_22905(scale, scale, scale);

        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-entityYaw + 180));
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(-entityPitch));

        if (entity.isMalfunctioned()) {
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(-50));
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(-10));
        }

        poseStack.method_46416(-0.5f, 0f, -0.5f);
        class_1091 mountModelLocation = ExposureClient.Models.CAMERA_STAND_MOUNT;
        class_1087 mountModel = PlatformHelperClient.getModel(mountModelLocation);
        blockRenderer.method_3350().method_3367(poseStack.method_23760(), bufferSource.getBuffer(class_1921.method_23577()),
                null, mountModel, 1.0f, 1.0f, 1.0f, packedLight, class_4608.field_21444);
        poseStack.method_22909();
    }

    private void renderCamera(T entity, float entityYaw, float entityPitch, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight) {
        poseStack.method_22903();
        poseStack.method_22904(0, 1.125, 0);
        float scale = 0.9f;
        poseStack.method_22905(scale, scale, scale);

        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-entityYaw + 180));
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(-entityPitch));

        if (entity.isMalfunctioned()) {
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(-50));
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(-15));
        }

        poseStack.method_22904(0, 0.625, 0);
        Minecrft.get().method_1480().method_23178(entity.getCamera(), class_811.field_4315, packedLight, class_4608.field_21444, poseStack, bufferSource, entity.method_37908(), 0);
        poseStack.method_22909();
    }
}
