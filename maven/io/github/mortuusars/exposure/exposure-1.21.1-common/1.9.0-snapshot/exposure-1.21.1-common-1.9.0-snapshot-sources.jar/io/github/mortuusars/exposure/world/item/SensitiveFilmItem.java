package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.film.properties.FilmProperties;
import net.minecraft.class_1799;

public interface SensitiveFilmItem extends FilmItem {
    default FilmProperties getFilmProperties(class_1799 itemStack) {
        return itemStack.method_57825(Exposure.DataComponents.FILM_PROPERTIES, FilmProperties.EMPTY);
    }
}
