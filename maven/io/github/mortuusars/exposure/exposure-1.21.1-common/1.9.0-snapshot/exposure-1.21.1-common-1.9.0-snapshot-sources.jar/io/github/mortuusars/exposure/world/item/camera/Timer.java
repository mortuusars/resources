package io.github.mortuusars.exposure.world.item.camera;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.sound.Sound;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_3419;

public class Timer {
    public boolean isTicking(CameraHolder holder, class_1799 stack) {
        return getReleaseTick(stack) > holder.asHolderEntity().method_37908().method_8510();
    }

    public int getRemainingTicks(CameraHolder holder, class_1799 stack) {
        return (int)Math.max(-1, getReleaseTick(stack) - holder.asHolderEntity().method_37908().method_8510());
    }

    public long getReleaseTick(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.RELEASE_TICK, -1L);
    }

    public void setReleaseTick(class_1799 stack, long tick) {
        stack.method_57379(Exposure.DataComponents.RELEASE_TICK, tick);
    }

    public void set(CameraHolder holder, class_1799 stack, int seconds) {
        setReleaseTick(stack, holder.asHolderEntity().method_37908().method_8510() + seconds * 20L);
    }

    /**
     * @return true if state has changed.
     */
    public boolean tick(CameraHolder holder, class_3218 level, class_1799 stack) {
        long releaseTick = getReleaseTick(stack);
        if (releaseTick <= -1L) return false;
        long currentTick = level.method_8510();
        long remainingTicks = releaseTick - currentTick;

        if (remainingTicks < -10) {
            // Ignore if release tick was passed some time ago.
            // To not release when player drops or puts camera in chest and then picks up after some time.
            setReleaseTick(stack, -1L);
            return true;
        }

        if (remainingTicks == 0) {
            setReleaseTick(stack, currentTick);
            if (stack.method_7909() instanceof CameraItem cameraItem) {
                cameraItem.release(holder, stack);
            }
            setReleaseTick(stack, -1L);
            return true;
        }

        if (remainingTicks % getTickingInterval(remainingTicks) == 0) {
            playTickSound(holder);
        }

        return false;
    }

    protected void playTickSound(CameraHolder holder) {
        Sound.play(holder.asHolderEntity(), Exposure.SoundEvents.CAMERA_TIMER_TICK.get(), class_3419.field_15248, 1, 0.8f);
    }

    protected int getTickingInterval(long remainingTicks) {
        if (remainingTicks > 100) return 10;
        if (remainingTicks > 50) return 6;
        if (remainingTicks > 25) return 4;
        return 2;
    }
}
