package io.github.mortuusars.exposure.mixin.compat.easy_anvils;

import fuzs.easyanvils.client.gui.screens.inventory.ModAnvilScreen;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.world.item.BrokenInterplanarProjectorItem;
import io.github.mortuusars.exposure.world.item.InterplanarProjectorItem;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_471;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ModAnvilScreen.class)
public abstract class ModAnvilScreenMixin extends class_471 {
    public ModAnvilScreenMixin(class_1706 menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
    }

    /**
     * Same mixin as {@link io.github.mortuusars.exposure.mixin.client.AnvilScreenMixin#onSlotChanged(class_1703, int, class_1799, CallbackInfo)}
     * needs to be applied, as Easy Anvils overwrote whole method.
     */
    @Inject(method = "slotChanged", at = @At("HEAD"))
    private void onSlotChanged(class_1703 containerToSend, int dataSlotIndex, class_1799 stack, CallbackInfo ci) {
        if (dataSlotIndex == 0 &&
              Config.Server.SPEC.isLoaded()
              && Config.Server.INTERPLANAR_PROJECTOR_LARGER_RENAMING_LIMIT.get()) {
            int maxLength = stack.method_7909() instanceof InterplanarProjectorItem
                  || stack.method_7909() instanceof BrokenInterplanarProjectorItem ? 150 : 50;
            this.field_2821.method_1880(maxLength);
        }
    }
}
