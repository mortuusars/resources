package io.github.mortuusars.exposure.client.capture.task.file;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.client.image.WrappedNativeImage;
import io.github.mortuusars.exposure.client.capture.task.FileCaptureTask;
import io.github.mortuusars.exposure.util.cycles.task.Result;
import io.github.mortuusars.exposure.client.image.Image;
import org.slf4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import net.minecraft.class_1011;

public class NativeImagePngFileLoader implements ImageFileLoader {
    private static final Logger LOGGER = LogUtils.getLogger();

    @Override
    public Result<Image> load(File file) {
        try (FileInputStream inputStream = new FileInputStream(file)) {
            class_1011 image = class_1011.method_4310(class_1011.class_1012.field_4997, inputStream);

            if (image.method_4307() > 10_000 || image.method_4323() > 10_000) {
                LOGGER.error("Cannot load image from file '{}': image is too large.", file);
                return Result.error(FileCaptureTask.ERROR_CANNOT_READ);
            }

            return Result.success(new WrappedNativeImage(image));
        } catch (IOException e) {
            Exposure.LOGGER.error("Loading image from file path '{}' failed:", file, e);
            return Result.error(FileCaptureTask.ERROR_CANNOT_READ);
        }
    }
}