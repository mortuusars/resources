package io.github.mortuusars.exposure.world.item;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.client.gui.ClientGUI;
import io.github.mortuusars.exposure.world.inventory.tooltip.PhotographTooltip;
import io.github.mortuusars.exposure.world.item.component.StackedPhotographs;
import io.github.mortuusars.exposure.world.item.util.ItemAndStack;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3419;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import net.minecraft.class_5632;
import net.minecraft.class_5712;

public class StackedPhotographsItem extends class_1792 {
    public StackedPhotographsItem(class_1793 properties) {
        super(properties);
    }

    /**
     * @return How many photographs can be stacked together.
     */
    public int getStackLimit() {
        return Config.Server.STACKED_PHOTOGRAPHS_MAX_SIZE.get();
    }

    public StackedPhotographs getPhotographs(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.STACKED_PHOTOGRAPHS, StackedPhotographs.EMPTY);
    }

    public void setPhotographs(class_1799 stack, StackedPhotographs photographs) {
        stack.method_57379(Exposure.DataComponents.STACKED_PHOTOGRAPHS, photographs);
    }

    public boolean canAddPhotograph(class_1799 stack) {
        return getPhotographs(stack).size() < getStackLimit();
    }

    public void addPhotograph(class_1799 stack, class_1799 photographStack, int index) {
        Preconditions.checkElementIndex(index, getPhotographs(stack).size() + 1);
        Preconditions.checkState(canAddPhotograph(stack),
              "Cannot add more photographs than this stack can store. Size: " + getPhotographs(stack).size() + ", Max count: " + getStackLimit());
        Preconditions.checkArgument(photographStack.method_7909() instanceof PhotographItem, "Only PhotographItem can be stacked.");

        setPhotographs(stack, getPhotographs(stack).add(index, photographStack));
    }

    public void addPhotographOnTop(class_1799 stack, class_1799 photographStack) {
        addPhotograph(stack, photographStack, 0);
    }

    public void addPhotographToBottom(class_1799 stack, class_1799 photographStack) {
        addPhotograph(stack, photographStack, getPhotographs(stack).size());
    }

    public ItemAndStack<PhotographItem> removePhotograph(class_1799 stack, int index) {
        Preconditions.checkElementIndex(index, getPhotographs(stack).size());

        StackedPhotographs stackedPhotographs = getPhotographs(stack);
        class_1799 removedPhotograph = stackedPhotographs.getItemUnsafe(index);
        setPhotographs(stack, stackedPhotographs.remove(index));

        return new ItemAndStack<>(removedPhotograph.method_7972());
    }

    public ItemAndStack<PhotographItem> removeTopPhotograph(class_1799 stack) {
        return removePhotograph(stack, 0);
    }

    public ItemAndStack<PhotographItem> removeBottomPhotograph(class_1799 stack) {
        return removePhotograph(stack, getPhotographs(stack).size() - 1);
    }

    // ---

    @Override
    public @NotNull Optional<class_5632> method_32346(@NotNull class_1799 stack) {
        StackedPhotographs photographs = getPhotographs(stack);
        if (photographs.isEmpty())
            return Optional.empty();

        return Optional.of(new PhotographTooltip(photographs.photographsItemAndStacks()));
    }

    @Override
    public boolean method_31565(@NotNull class_1799 stack, @NotNull class_1735 slot, @NotNull class_5536 action, @NotNull class_1657 player) {
        if (action != class_5536.field_27014 || getPhotographs(stack).isEmpty() || !slot.method_7680(new class_1799(Exposure.Items.PHOTOGRAPH.get())))
            return false;

        class_1799 slotItem = slot.method_7677();
        if (slotItem.method_7960()) {
            ItemAndStack<PhotographItem> photograph = removeBottomPhotograph(stack);
            slot.method_7673(photograph.getItemStack());

            if (getPhotographs(stack).size() == 1)
                player.field_7512.method_34254(removeTopPhotograph(stack).getItemStack());

            playRemoveSoundClientside(player);

            return true;
        }

        if (slotItem.method_7909() instanceof PhotographItem && canAddPhotograph(stack)) {
            addPhotographToBottom(stack, slotItem);
            slot.method_7673(class_1799.field_8037);

            playAddSoundClientside(player);

            return true;
        }

        return false;
    }

    @Override
    public boolean method_31566(@NotNull class_1799 stack, @NotNull class_1799 other, @NotNull class_1735 slot, @NotNull class_5536 action, @NotNull class_1657 player, @NotNull class_5630 access) {
        if (action != class_5536.field_27014 || !slot.method_7680(new class_1799(Exposure.Items.PHOTOGRAPH.get())))
            return false;

        if (!getPhotographs(stack).isEmpty() && other.method_7960()) {
            ItemAndStack<PhotographItem> photograph = removeTopPhotograph(stack);
            access.method_32332(photograph.getItemStack());

            if (getPhotographs(stack).size() == 1) {
                ItemAndStack<PhotographItem> lastPhotograph = removeTopPhotograph(stack);
                slot.method_7673(lastPhotograph.getItemStack());
            }

            playRemoveSoundClientside(player);

            return true;
        }

        if (other.method_7909() instanceof PhotographItem) {
            if (canAddPhotograph(stack)) {
                addPhotographOnTop(stack, other);
                access.method_32332(class_1799.field_8037);

                playAddSoundClientside(player);

                return true;
            } else
                return false;
        }

        if (other.method_7909() instanceof StackedPhotographsItem otherStackedItem) {
            int otherCount = otherStackedItem.getPhotographs(other).size();
            int addedCount = 0;
            for (int i = 0; i < otherCount; i++) {
                if (canAddPhotograph(stack)) {
                    ItemAndStack<PhotographItem> photograph = otherStackedItem.removeBottomPhotograph(other);
                    addPhotographOnTop(stack, photograph.getItemStack());
                    addedCount++;
                }
            }

            if (otherStackedItem.getPhotographs(other).isEmpty())
                access.method_32332(class_1799.field_8037);
            else if (otherStackedItem.getPhotographs(other).size() == 1)
                access.method_32332(otherStackedItem.removeTopPhotograph(other).getItemStack());

            if (addedCount > 0)
                playAddSoundClientside(player);

            return true;
        }

        return false;
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(@NotNull class_1937 level, class_1657 player, @NotNull class_1268 hand) {
        class_1799 itemInHand = player.method_5998(hand);

        if (player.method_21823() && cyclePhotographs(itemInHand)) {
            player.method_37908().method_43129(player, player, Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), class_3419.field_15248, 0.6f,
                    player.method_37908().method_8409().method_43057() * 0.2f + 1.2f);
            player.method_32876(class_5712.field_28146);
            return class_1271.method_22427(itemInHand);
        }

        StackedPhotographs photographs = getPhotographs(itemInHand);
        if (!photographs.isEmpty()) {
            if (level.field_9236) {
                int slot = hand == class_1268.field_5810 ? class_1661.field_30639 : player.method_31548().field_7545;
                ClientGUI.openPhotographsScreenFromItem(slot);
                player.method_5783(Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), 0.6f, 1.1f);
            }
            return class_1271.method_22427(itemInHand);
        }

        return class_1271.method_22431(itemInHand);
    }

    public boolean cyclePhotographs(class_1799 stack) {
        if (getPhotographs(stack).size() < 2)
            return false;

        ItemAndStack<PhotographItem> topPhotograph = removeTopPhotograph(stack);
        addPhotographToBottom(stack, topPhotograph.getItemStack());

        return true;
    }

    public static void playAddSoundClientside(class_1657 player) {
        if (player.method_37908().field_9236)
            player.method_5783(Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), 0.6f,
                    player.method_37908().method_8409().method_43057() * 0.2f + 1.2f);
    }

    public static void playRemoveSoundClientside(class_1657 player) {
        if (player.method_37908().field_9236)
            player.method_5783(Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), 0.75f,
                    player.method_37908().method_8409().method_43057() * 0.2f + 0.75f);
    }
}
