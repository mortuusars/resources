package io.github.mortuusars.exposure.world.item.component;

import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import io.github.mortuusars.exposure.world.item.util.ItemAndStack;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_1799;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

@SuppressWarnings("deprecation")
public record StackedPhotographs(List<class_1799> photographs) {
    public static final StackedPhotographs EMPTY = new StackedPhotographs(List.of());

    public static final Codec<StackedPhotographs> CODEC = class_1799.field_24671.listOf()
          .xmap(StackedPhotographs::new, StackedPhotographs::photographs);
    public static final class_9139<class_9129, StackedPhotographs> STREAM_CODEC = class_1799.field_48349
          .method_56433(class_9135.method_56363())
          .method_56432(StackedPhotographs::new, StackedPhotographs::photographs);

    // --

    public class_1799 getItemUnsafe(int index) {
        return photographs.get(index);
    }

    public List<class_1799> photographsCopy() {
        return Lists.transform(photographs, class_1799::method_7972);
    }

    public Stream<class_1799> photographsCopyStream() {
        return photographs.stream().map(class_1799::method_7972);
    }

    public List<ItemAndStack<PhotographItem>> photographsItemAndStacks() {
        return photographs.stream()
              .filter(stack -> stack.method_7909() instanceof PhotographItem)
              .map(stack -> new ItemAndStack<PhotographItem>(stack))
              .toList();
    }

    public int size() {
        return photographs.size();
    }

    public boolean isEmpty() {
        return photographs.isEmpty();
    }

    // --

    public StackedPhotographs add(int index, class_1799 photograph) {
        ArrayList<class_1799> list = new ArrayList<>(photographs);
        list.add(index, photograph);
        return new StackedPhotographs(list);
    }

    public StackedPhotographs remove(int index) {
        ArrayList<class_1799> list = new ArrayList<>(photographs);
        list.remove(index);
        return new StackedPhotographs(list);
    }

    // --

    @Override
    public boolean equals(Object object) {
        return this == object || object instanceof StackedPhotographs stackedPhotographs
              && class_1799.method_57362(this.photographs, stackedPhotographs.photographs);
    }

    @Override
    public int hashCode() {
        return class_1799.method_57361(photographs);
    }

    @Override
    public @NotNull String toString() {
        return "StackedPhotographs" + photographs;
    }
}
