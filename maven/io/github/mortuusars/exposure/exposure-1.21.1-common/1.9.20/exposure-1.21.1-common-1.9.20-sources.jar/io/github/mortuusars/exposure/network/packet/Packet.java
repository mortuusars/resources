package io.github.mortuusars.exposure.network.packet;

import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_8710;

public interface Packet extends class_8710 {
    boolean handle(class_2598 flow, class_1657 player);
}