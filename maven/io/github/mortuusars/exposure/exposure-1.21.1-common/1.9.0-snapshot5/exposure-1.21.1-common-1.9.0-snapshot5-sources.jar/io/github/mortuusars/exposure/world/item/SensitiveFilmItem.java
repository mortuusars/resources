package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.world.camera.film.properties.FilmProperties;
import io.github.mortuusars.exposure.world.camera.film.properties.FilmStyle;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface SensitiveFilmItem extends FilmItem {
    @NotNull FilmProperties getFilmProperties(class_1799 stack);

    default @NotNull FilmStyle getFilmStyle(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.FILM_STYLE, FilmStyle.EMPTY);
    }

    default class_5321<ColorPalette> getColorPalette(class_1799 stack) {
        @Nullable class_2960 location = stack.method_57824(Exposure.DataComponents.FILM_COLOR_PALETTE);
        if (location != null) return ColorPalettes.createKey(location);
        return ColorPalettes.DEFAULT;
    }
}
