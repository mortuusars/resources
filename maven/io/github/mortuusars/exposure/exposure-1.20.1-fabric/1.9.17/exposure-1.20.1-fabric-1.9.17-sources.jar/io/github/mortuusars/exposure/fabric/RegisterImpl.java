package io.github.mortuusars.exposure.fabric;

import com.mojang.brigadier.arguments.ArgumentType;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.Register;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.command.v2.ArgumentTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1703;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1865;
import net.minecraft.class_2248;
import net.minecraft.class_2314;
import net.minecraft.class_2378;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3414;
import net.minecraft.class_3917;
import net.minecraft.class_7923;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class RegisterImpl {
    public static <T extends class_2248> Supplier<T> block(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41175, Exposure.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_2591<E>, E extends class_2586> Supplier<T> blockEntityType(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41181, Exposure.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_2586> class_2591<T> newBlockEntityType(Register.BlockEntitySupplier<T> blockEntitySupplier, class_2248... validBlocks) {
        return class_2591.class_2592.method_20528(blockEntitySupplier::create, validBlocks).method_11034(null);
    }

    public static <T extends class_1792> Supplier<T> item(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41178, Exposure.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_1761> Supplier<T> creativeTab(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_44687, Exposure.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_1297> Supplier<class_1299<T>> entityType(String id, class_1299.class_4049<T> factory, class_1311 category, boolean receiveVelocityUpdates, Consumer<class_1299.class_1300<T>> typeBuilder) {
        class_1299.class_1300<T> builder = class_1299.class_1300.method_5903(factory, category);
        typeBuilder.accept(builder);
        class_1299<T> type = class_2378.method_10230(class_7923.field_41177, Exposure.resource(id), builder.method_5905(id));
        return () -> type;
    }

    public static <T extends class_3414> Supplier<T> soundEvent(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41172, Exposure.resource(id), supplier.get());
        return () -> obj;
    }

    public static <T extends class_3917<E>, E extends class_1703> Supplier<class_3917<E>> menuType(String id, Register.MenuTypeSupplier<E> supplier) {
        ExtendedScreenHandlerType<E> type = new ExtendedScreenHandlerType<>((syncId, inventory, data) -> {
            class_2540 buffer = PacketByteBufs.copy(data);
            E menu = supplier.create(syncId, inventory, buffer);
            buffer.release();
            return menu;
        });

        class_2378.method_10230(class_7923.field_41187, Exposure.resource(id), type);

        return () -> type;
    }

    public static Supplier<class_1865<?>> recipeSerializer(String id, Supplier<class_1865<?>> supplier) {
        class_1865<?> obj = class_2378.method_10230(class_7923.field_41189, Exposure.resource(id), supplier.get());
        return () -> obj;
    }

    public static <A extends ArgumentType<?>, T extends class_2314.class_7217<A>, I extends class_2314<A, T>>
    Supplier<class_2314<A, T>> commandArgumentType(String id, Class<A> infoClass, I argumentTypeInfo) {
        ArgumentTypeRegistry.registerArgumentType(Exposure.resource(id), infoClass, argumentTypeInfo);
        return () -> argumentTypeInfo;
    }

    public static <T extends class_3037> Supplier<class_3031<?>> worldGenFeature(String name, Supplier<class_3031<T>> featureSupplier) {
        class_3031<T> feature = class_2378.method_10226(class_7923.field_41144, name, featureSupplier.get());
        return () -> feature;
    }

    public static <T extends class_2396<? extends class_2394>> Supplier<T> particleType(String name, Supplier<T> supplier) {
        T particleType = class_2378.method_10226(class_7923.field_41180, name, supplier.get());
        return () -> particleType;
    }
}
