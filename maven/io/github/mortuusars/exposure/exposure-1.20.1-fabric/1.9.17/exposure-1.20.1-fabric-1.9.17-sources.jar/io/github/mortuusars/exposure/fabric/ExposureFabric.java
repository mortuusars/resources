package io.github.mortuusars.exposure.fabric;

import fuzs.forgeconfigapiport.api.config.v2.ForgeConfigRegistry;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.data.Filter;
import io.github.mortuusars.exposure.data.Lens;
import io.github.mortuusars.exposure.event.CommonEvents;
import io.github.mortuusars.exposure.event.ServerEvents;
import io.github.mortuusars.exposure.network.fabric.PacketsImpl;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.registry.DynamicRegistries;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.fabricmc.fabric.api.loot.v2.LootTableSource;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_39;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_60;
import net.minecraft.class_83;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.fml.config.ModConfig;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ExposureFabric implements ModInitializer {
    // Server field to access when no other objects are available to get it from.
    public static @Nullable MinecraftServer server = null;

    @Override
    public void onInitialize() {
        Exposure.init();

        DynamicRegistries.registerSynced(Exposure.Registries.COLOR_PALETTE, ColorPalette.CODEC, ColorPalette.CODEC);
        DynamicRegistries.registerSynced(Exposure.Registries.LENS, Lens.CODEC, Lens.CODEC);
        DynamicRegistries.registerSynced(Exposure.Registries.FILTER, Filter.CODEC, Filter.CODEC);

        ForgeConfigRegistry.INSTANCE.register(Exposure.ID, ModConfig.Type.SERVER, Config.Server.SPEC);
        ForgeConfigRegistry.INSTANCE.register(Exposure.ID, ModConfig.Type.COMMON, Config.Common.SPEC);
        ForgeConfigRegistry.INSTANCE.register(Exposure.ID, ModConfig.Type.CLIENT, Config.Client.SPEC);

        CommandRegistrationCallback.EVENT.register(CommonEvents::registerCommands);

        Exposure.Stats.register();

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            ServerEvents.serverStarted(server);
            ExposureFabric.server = server;
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            ServerEvents.serverStopped(server);
            ExposureFabric.server = null;
        });

        ServerLifecycleEvents.SYNC_DATA_PACK_CONTENTS.register((player, joined) -> ServerEvents.syncDatapack(List.of(player)));

        LootTableEvents.MODIFY.register(ExposureFabric::modifyLoot);

        PacketsImpl.registerC2SPackets();
    }

    private static void modifyLoot(class_3300 resourceManager, class_60 lootDataManager, class_2960 location, class_52.class_53 builder, LootTableSource lootTableSource) {
        if (!Config.Common.GENERATE_LOOT.get() || !lootTableSource.isBuiltin())
            return;

        if (class_39.field_356.equals(location)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.LootTables.SIMPLE_DUNGEON_INJECT))
                    .method_355());
        }
        if (class_39.field_472.equals(location)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.LootTables.ABANDONED_MINESHAFT_INJECT))
                    .method_355());
        }
        if (class_39.field_800.equals(location)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.LootTables.STRONGHOLD_CROSSING_INJECT))
                    .method_355());
        }
        if (class_39.field_16748.equals(location)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.LootTables.VILLAGE_PLAINS_HOUSE_INJECT))
                    .method_355());
        }
        if (class_39.field_841.equals(location)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.LootTables.SHIPWRECK_MAP_INJECT))
                    .method_355());
        }
    }
}
