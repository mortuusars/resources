package io.github.mortuusars.exposure.network.fabric;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.fabric.ExposureFabric;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.network.packet.common.ActiveCameraDeactivateCommonPacket;
import io.github.mortuusars.exposure.network.packet.serverbound.*;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;
import java.util.function.Predicate;

public class PacketsImpl {
    @Nullable
    private static MinecraftServer server;

    public static void registerC2SPackets() {
        ServerPlayNetworking.registerGlobalReceiver(ActiveCameraDeactivateCommonPacket.ID, new ServerHandler(ActiveCameraDeactivateCommonPacket::fromBuffer));

        ServerPlayNetworking.registerGlobalReceiver(AlbumSignC2SP.ID, new ServerHandler(AlbumSignC2SP::fromPacket));
        ServerPlayNetworking.registerGlobalReceiver(AlbumSyncNoteC2SP.ID, new ServerHandler(AlbumSyncNoteC2SP::fromPacket));
        ServerPlayNetworking.registerGlobalReceiver(ActiveCameraSetSettingC2SP.ID, new ServerHandler(ActiveCameraSetSettingC2SP::fromPacket));
        ServerPlayNetworking.registerGlobalReceiver(OpenCameraAttachmentsInCreativePacketC2SP.ID, new ServerHandler(OpenCameraAttachmentsInCreativePacketC2SP::fromPacket));
        ServerPlayNetworking.registerGlobalReceiver(ExposureRequestC2SP.ID, new ServerHandler(ExposureRequestC2SP::fromPacket));
        ServerPlayNetworking.registerGlobalReceiver(ActiveCameraReleaseC2SP.ID, new ServerHandler(ActiveCameraReleaseC2SP::fromPacket));
        ServerPlayNetworking.registerGlobalReceiver(InterplanarProjectionFinishedC2SP.ID, new ServerHandler(InterplanarProjectionFinishedC2SP::fromPacket));
        ServerPlayNetworking.registerGlobalReceiver(ExposureDataC2SP.ID, new ServerHandler(ExposureDataC2SP::fromPacket));
        ServerPlayNetworking.registerGlobalReceiver(ExposureDataChunkHeaderC2SP.ID, new ServerHandler(ExposureDataChunkHeaderC2SP::fromPacket));
        ServerPlayNetworking.registerGlobalReceiver(ExposureDataChunkBytesC2SP.ID, new ServerHandler(ExposureDataChunkBytesC2SP::fromPacket));
        ServerPlayNetworking.registerGlobalReceiver(CameraStandTurnC2SP.ID, new ServerHandler(CameraStandTurnC2SP::fromPacket));
    }

    public static void registerS2CPackets() {
        ClientPackets.registerS2CPackets();
    }

    // --

    public static void sendToServer(Packet packet) {
        class_2540 buffer = PacketByteBufs.create();
        packet.toPacket(buffer);
        ClientPlayNetworking.send(packet.getId(), buffer);
    }

    public static void sendToClient(Packet packet, class_3222 player) {
        class_2540 buffer = PacketByteBufs.create();
        packet.toPacket(buffer);
        ServerPlayNetworking.send(player, packet.getId(), buffer);
    }

    public static void sendToClients(Packet packet, Predicate<class_3222> filter) {
        if (ExposureFabric.server == null) {
            Exposure.LOGGER.error("Cannot send a packet to players. Server is not available.");
            return;
        }

        for (class_3222 player : ExposureFabric.server.method_3760().method_14571()) {
            if (filter.test(player)) {
                sendToClient(packet, player);
            }
        }
    }

    public static void sendToAllClients(Packet packet) {
        if (ExposureFabric.server == null) {
            Exposure.LOGGER.error("Cannot send a packet to all players. Server is not available.");
            return;
        }

        for (class_3222 player : ExposureFabric.server.method_3760().method_14571()) {
            sendToClient(packet, player);
        }
    }

    public static void sendToPlayersNear(Packet packet, @NotNull class_3218 level, @Nullable class_3222 excludedPlayer,
                                         double x, double y, double z, double radius) {
        sendToClients(packet, player -> {
            if (player != excludedPlayer && player.method_37908().method_27983() == level.method_27983()) {
                double d0 = x - player.method_23317();
                double d1 = y - player.method_23318();
                double d2 = z - player.method_23321();
                return d0 * d0 + d1 * d1 + d2 * d2 < radius * radius;
            }

            return false;
        });
    }

    private record ServerHandler(Function<class_2540, Packet> decoder) implements ServerPlayNetworking.PlayChannelHandler {
        @Override
        public void receive(MinecraftServer server, class_3222 player, class_3244 handler, class_2540 buf, PacketSender responseSender) {
            Packet packet = decoder.apply(buf);
            server.execute(() -> packet.handle(class_2598.field_11941, player));
        }
    }
}