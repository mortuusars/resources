package io.github.mortuusars.exposure.network.fabric;

import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.network.packet.clientbound.*;
import io.github.mortuusars.exposure.network.packet.common.ActiveCameraDeactivateCommonPacket;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_310;
import net.minecraft.class_634;
import java.util.function.Function;

public class ClientPackets {
    public static void registerS2CPackets() {
        ClientPlayNetworking.registerGlobalReceiver(ActiveCameraDeactivateCommonPacket.ID, new ClientHandler(ActiveCameraDeactivateCommonPacket::fromBuffer));

        ClientPlayNetworking.registerGlobalReceiver(ActiveCameraRemoveS2CP.ID, new ClientHandler(ActiveCameraRemoveS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(ActiveCameraInHandSetS2CP.ID, new ClientHandler(ActiveCameraInHandSetS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(ActiveCameraOnStandSetS2CP.ID, new ClientHandler(ActiveCameraOnStandSetS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(CameraStandSetRotationsS2CP.ID, new ClientHandler(CameraStandSetRotationsS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(CameraStandStopControllingS2CP.ID, new ClientHandler(CameraStandStopControllingS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(ShaderApplyS2CP.ID, new ClientHandler(ShaderApplyS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(ActionS2CP.ID, new ClientHandler(ActionS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(CreateChromaticExposureS2CP.ID, new ClientHandler(CreateChromaticExposureS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(ExposureDataChangedS2CP.ID, new ClientHandler(ExposureDataChangedS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(UniqueSoundPlayS2CP.ID, new ClientHandler(UniqueSoundPlayS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(UniqueSoundPlayShutterTickingS2CP.ID, new ClientHandler(UniqueSoundPlayShutterTickingS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(UniqueSoundStopS2CP.ID, new ClientHandler(UniqueSoundStopS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(ShowExposureCommandS2CP.ID, new ClientHandler(ShowExposureCommandS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(ExposureDataResponseS2CP.ID, new ClientHandler(ExposureDataResponseS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(CaptureStartS2CP.ID, new ClientHandler(CaptureStartS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(CaptureStartDebugRGBS2CP.ID, new ClientHandler(CaptureStartDebugRGBS2CP::fromPacket));
        ClientPlayNetworking.registerGlobalReceiver(ExportS2CP.ID, new ClientHandler(ExportS2CP::fromPacket));
    }

    private record ClientHandler(Function<class_2540, Packet> decoder) implements ClientPlayNetworking.PlayChannelHandler {
        @Override
        public void receive(class_310 client, class_634 handler, class_2540 buf, PacketSender responseSender) {
            Packet packet = decoder.apply(buf);
            Minecrft.execute(() -> packet.handle(class_2598.field_11942, Minecrft.player()));
        }
    }
}