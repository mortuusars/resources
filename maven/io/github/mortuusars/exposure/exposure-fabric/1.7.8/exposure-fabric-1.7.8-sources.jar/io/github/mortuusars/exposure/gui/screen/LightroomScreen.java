package io.github.mortuusars.exposure.gui.screen;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.block.entity.Lightroom;
import io.github.mortuusars.exposure.block.entity.LightroomBlockEntity;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.gui.screen.element.ChromaticProcessToggleButton;
import io.github.mortuusars.exposure.item.DevelopedFilmItem;
import io.github.mortuusars.exposure.menu.LightroomMenu;
import io.github.mortuusars.exposure.render.image.RenderedImageProvider;
import io.github.mortuusars.exposure.render.modifiers.ExposurePixelModifiers;
import io.github.mortuusars.exposure.util.ColorChannel;
import io.github.mortuusars.exposure.util.PagingDirection;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_289;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_465;
import net.minecraft.class_5250;
import net.minecraft.class_757;
import net.minecraft.class_765;
import net.minecraft.class_768;
import net.minecraft.class_7919;

public class LightroomScreen extends class_465<LightroomMenu> {
    public static final class_2960 MAIN_TEXTURE = Exposure.resource("textures/gui/lightroom.png");
    public static final class_2960 FILM_OVERLAYS_TEXTURE = Exposure.resource("textures/gui/lightroom_film_overlays.png");
    public static final int FRAME_SIZE = 54;

    protected class_1657 player;
    protected class_4185 printButton;
    protected ChromaticProcessToggleButton processToggleButton;

    protected Map<Integer, class_768> slotPlaceholders = Collections.emptyMap();

    public LightroomScreen(LightroomMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
        this.player = playerInventory.field_7546;
    }

    @Override
    protected void method_25426() {
        field_2792 = 176;
        field_2779 = 210;
        super.method_25426();
        field_25270 = 116;

        slotPlaceholders = Map.of(
                Lightroom.FILM_SLOT, new class_768(238, 0, 18, 18),
                Lightroom.PAPER_SLOT, new class_768(238, 18, 18, 18),
                Lightroom.CYAN_SLOT, new class_768(238, 36, 18, 18),
                Lightroom.MAGENTA_SLOT, new class_768(238, 54, 18, 18),
                Lightroom.YELLOW_SLOT, new class_768(238, 72, 18, 18),
                Lightroom.BLACK_SLOT, new class_768(238, 90, 18, 18)
        );

        printButton = new class_344(field_2776 + 117, field_2800 + 89, 22, 22, 176, 17,
                22, MAIN_TEXTURE, 256, 256, this::onPrintButtonPressed,
                class_2561.method_43471("gui.exposure.lightroom.print"));

        class_5250 tooltip = class_2561.method_43471("gui.exposure.lightroom.print");
        if (player.method_7337()) {
            tooltip.method_27693("\n")
                    .method_10852(class_2561.method_43471("gui.exposure.lightroom.print.creative_tooltip"));
        }

        printButton.method_47400(class_7919.method_47407(tooltip));
        method_37063(printButton);

        processToggleButton = new ChromaticProcessToggleButton(field_2776 - 19, field_2800 + 91,
                this::onProcessToggleButtonPressed, () -> method_17577().getBlockEntity().getProcess());
        processToggleButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure.lightroom.current_frame")));
        method_37063(processToggleButton);

        updateButtons();
    }

    protected void onPrintButtonPressed(class_4185 button) {
        if (class_310.method_1551().field_1761 != null) {
            if (class_437.method_25442() && player.method_7337())
                class_310.method_1551().field_1761.method_2900(method_17577().field_7763, LightroomMenu.PRINT_CREATIVE_BUTTON_ID);
            else
                class_310.method_1551().field_1761.method_2900(method_17577().field_7763, LightroomMenu.PRINT_BUTTON_ID);
        }
    }

    protected void onProcessToggleButtonPressed(class_4185 button) {
        if (class_310.method_1551().field_1761 != null)
            class_310.method_1551().field_1761.method_2900(method_17577().field_7763, LightroomMenu.TOGGLE_PROCESS_BUTTON_ID);
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();

        method_25420(guiGraphics);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        method_2380(guiGraphics, mouseX, mouseY);
    }

    protected void updateButtons() {
        printButton.field_22763 = method_17577().getBlockEntity().canPrint() || (player.method_7337() && class_437.method_25442() && method_17577().getBlockEntity().canPrintInCreativeMode());
        printButton.field_22764 = !method_17577().isPrinting();

        processToggleButton.field_22763 = true;
        processToggleButton.field_22764 = method_17577().canChangeProcess();
    }

    @Override
    protected void method_2389(@NotNull class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.method_25302(MAIN_TEXTURE, field_2776, field_2800, 0, 0, field_2792, field_2779);
        guiGraphics.method_25302(MAIN_TEXTURE, field_2776 - 27, field_2800 + 34, 0, 208, 28, 31);

        renderSlotPlaceholders(guiGraphics, mouseX, mouseY, partialTick);

        if (method_17577().isPrinting()) {
            int progress = method_17577().getData().method_17390(LightroomBlockEntity.CONTAINER_DATA_PROGRESS_ID);
            int time = method_17577().getData().method_17390(LightroomBlockEntity.CONTAINER_DATA_PRINT_TIME_ID);
            int width = progress != 0 && time != 0 ? progress * 24 / time : 0;
            guiGraphics.method_25302(MAIN_TEXTURE, field_2776 + 116, field_2800 + 91, 176, 0, width, 17);
        }

        class_2499 frames = method_17577().getExposedFrames();
        if (frames.isEmpty()) {
            guiGraphics.method_25302(FILM_OVERLAYS_TEXTURE, field_2776 + 4, field_2800 + 15, 0, 136, 168, 68);
            return;
        }

        class_1799 filmStack = method_17577().method_7611(Lightroom.FILM_SLOT).method_7677();
        if (!(filmStack.method_7909() instanceof DevelopedFilmItem film))
            return;

        FilmType negative = film.getType();

        int selectedFrame = method_17577().getSelectedFrame();
        @Nullable class_2487 leftFrame = method_17577().getFrameIdByIndex(selectedFrame - 1);
        @Nullable class_2487 centerFrame = method_17577().getFrameIdByIndex(selectedFrame);
        @Nullable class_2487 rightFrame = method_17577().getFrameIdByIndex(selectedFrame + 1);

        RenderSystem.setShaderColor(negative.filmR, negative.filmG, negative.filmB, negative.filmA);

        // Left film part
        guiGraphics.method_25302(FILM_OVERLAYS_TEXTURE, field_2776 + 1, field_2800 + 15, 0, leftFrame != null ? 68 : 0, 54, 68);
        // Center film part
        guiGraphics.method_25302(FILM_OVERLAYS_TEXTURE, field_2776 + 55, field_2800 + 15, 55, rightFrame != null ? 0 : 68, 64, 68);
        // Right film part
        if (rightFrame != null) {
            boolean hasMoreFrames = selectedFrame + 2 < frames.size();
            guiGraphics.method_25302(FILM_OVERLAYS_TEXTURE, field_2776 + 119, field_2800 + 15, 120, hasMoreFrames ? 68 : 0, 56, 68);
        }

        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        class_4587 poseStack = guiGraphics.method_51448();

        if (leftFrame != null)
            renderFrame(leftFrame, poseStack, field_2776 + 6, field_2800 + 22, FRAME_SIZE, isOverLeftFrame(mouseX, mouseY) ? 0.8f : 0.25f, negative);
        if (centerFrame != null)
            renderFrame(centerFrame, poseStack, field_2776 + 61, field_2800 + 22, FRAME_SIZE, 0.9f, negative);
        if (rightFrame != null)
            renderFrame(rightFrame, poseStack, field_2776 + 116, field_2800 + 22, FRAME_SIZE, isOverRightFrame(mouseX, mouseY) ? 0.8f : 0.25f, negative);

        RenderSystem.setShaderColor(negative.filmR, negative.filmG, negative.filmB, negative.filmA);

        if (method_17577().getBlockEntity().isAdvancingFrameOnPrint()) {
            poseStack.method_22903();
            poseStack.method_46416(0, 0, 800);

            if (selectedFrame < method_17577().getTotalFrames() - 1)
                guiGraphics.method_25302(MAIN_TEXTURE, field_2776 + 111, field_2800 + 44, 200, 0, 10, 10);
            else
                guiGraphics.method_25302(MAIN_TEXTURE, field_2776 + 111, field_2800 + 44, 210, 0, 10, 10);

            poseStack.method_22909();
        }

        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    private void renderSlotPlaceholders(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        for (int slotIndex : slotPlaceholders.keySet()) {
            class_1735 slot = method_17577().method_7611(slotIndex);
            if (!slot.method_7681()) {
                class_768 placeholder = slotPlaceholders.get(slotIndex);
                guiGraphics.method_25302(MAIN_TEXTURE, field_2776 + slot.field_7873 - 1, field_2800 + slot.field_7872 - 1,
                        placeholder.method_3321(), placeholder.method_3322(), placeholder.method_3319(), placeholder.method_3320());
            }
        }
    }

    @Override
    protected void method_2380(@NotNull class_332 guiGraphics, int mouseX, int mouseY) {
        super.method_2380(guiGraphics, mouseX, mouseY);

        boolean advancedTooltips = class_310.method_1551().field_1690.field_1827;
        int selectedFrame = method_17577().getSelectedFrame();
        List<class_2561> tooltipLines = new ArrayList<>();

        int hoveredFrameIndex = -1;

        if (isOverLeftFrame(mouseX, mouseY)) {
            hoveredFrameIndex = selectedFrame - 1;
            tooltipLines.add(class_2561.method_43471("gui.exposure.lightroom.previous_frame"));
        } else if (isOverCenterFrame(mouseX, mouseY)) {
            hoveredFrameIndex = selectedFrame;
            tooltipLines.add(class_2561.method_43469("gui.exposure.lightroom.current_frame", Integer.toString(method_17577().getSelectedFrame() + 1)));
        } else if (isOverRightFrame(mouseX, mouseY)) {
            hoveredFrameIndex = selectedFrame + 1;
            tooltipLines.add(class_2561.method_43471("gui.exposure.lightroom.next_frame"));
        }

        if (hoveredFrameIndex != -1) {
            addFrameInfoTooltipLines(tooltipLines, hoveredFrameIndex, advancedTooltips);
        }

        if (isOverCenterFrame(mouseX, mouseY)) {
            tooltipLines.add(class_2561.method_43471("gui.exposure.lightroom.zoom_in.tooltip"));
        }

        guiGraphics.method_51437(class_310.method_1551().field_1772, tooltipLines, Optional.empty(), mouseX, mouseY);
    }

    private void addFrameInfoTooltipLines(List<class_2561> tooltipLines, int frameIndex, boolean isAdvancedTooltips) {
        @Nullable class_2487 frame = method_17577().getFrameIdByIndex(frameIndex);
        if (frame != null) {
            ColorChannel.fromString(frame.method_10558(FrameData.CHROMATIC_CHANNEL)).ifPresent(c ->
                    tooltipLines.add(class_2561.method_43471("gui.exposure.channel." + c.method_15434())
                        .method_27696(class_2583.field_24360.method_36139(c.getRepresentationColor()))));

            if (isAdvancedTooltips) {
                Either<String, class_2960> idOrTexture = FrameData.getIdOrTexture(frame);
                class_5250 component = idOrTexture.map(
                                id -> !id.isEmpty() ? class_2561.method_43469("gui.exposure.frame.id",
                                        class_2561.method_43470(id).method_27692(class_124.field_1080)) : class_2561.method_43473(),
                                texture -> class_2561.method_43469("gui.exposure.frame.texture",
                                        class_2561.method_43470(texture.toString()).method_27692(class_124.field_1080)))
                        .method_27692(class_124.field_1063);
                tooltipLines.add(component);
            }
        }
    }

    private boolean isOverLeftFrame(int mouseX, int mouseY) {
        class_2499 frames = method_17577().getExposedFrames();
        int selectedFrame = method_17577().getSelectedFrame();
        return selectedFrame - 1 >= 0 && selectedFrame - 1 < frames.size() && method_2378(6, 22, FRAME_SIZE, FRAME_SIZE, mouseX, mouseY);
    }

    private boolean isOverCenterFrame(int mouseX, int mouseY) {
        class_2499 frames = method_17577().getExposedFrames();
        int selectedFrame = method_17577().getSelectedFrame();
        return selectedFrame >= 0 && selectedFrame < frames.size() && method_2378(61, 22, FRAME_SIZE, FRAME_SIZE, mouseX, mouseY);
    }

    private boolean isOverRightFrame(int mouseX, int mouseY) {
        class_2499 frames = method_17577().getExposedFrames();
        int selectedFrame = method_17577().getSelectedFrame();
        return selectedFrame + 1 >= 0 && selectedFrame + 1 < frames.size() && method_2378(116, 22, FRAME_SIZE, FRAME_SIZE, mouseX, mouseY);
    }

    public void renderFrame(@Nullable class_2487 frame, class_4587 poseStack, float x, float y, float size, float alpha, FilmType negative) {
        if (frame == null)
            return;

        poseStack.method_22903();
        poseStack.method_46416(x, y, 0);

        class_4597.class_4598 bufferSource = class_4597.method_22991(class_289.method_1348().method_1349());
        ExposureClient.getExposureRenderer().render(RenderedImageProvider.fromFrame(frame),
                ExposurePixelModifiers.NEGATIVE_FILM, poseStack, bufferSource, 0, 0, size, size, class_765.field_32767,
                negative.frameR, negative.frameG, negative.frameB, class_3532.method_15340((int) Math.ceil(alpha * 255), 0, 255));
        bufferSource.method_22993();

        poseStack.method_22909();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        Preconditions.checkState(field_22787 != null);
        Preconditions.checkState(field_22787.field_1761 != null);

        if (field_22787.field_1690.field_1913.method_1417(keyCode, scanCode) || keyCode == class_3675.field_31983) {
            changeFrame(PagingDirection.PREVIOUS);
            return true;
        } else if (field_22787.field_1690.field_1849.method_1417(keyCode, scanCode) || keyCode == class_3675.field_31984) {
            changeFrame(PagingDirection.NEXT);
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta) {
        boolean handled = super.method_25401(mouseX, mouseY, delta);

        if (!handled) {
            if (delta >= 0.0 && isOverCenterFrame((int) mouseX, (int) mouseY)) // Scroll Up
                enterFrameInspectMode();
        }

        return handled;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            Preconditions.checkState(field_22787 != null);
            Preconditions.checkState(field_22787.field_1761 != null);

            if (isOverCenterFrame((int) mouseX, (int) mouseY)) {
                enterFrameInspectMode();
                return true;
            }

            if (isOverLeftFrame((int) mouseX, (int) mouseY)) {
                changeFrame(PagingDirection.PREVIOUS);
                return true;
            }

            if (isOverRightFrame((int) mouseX, (int) mouseY)) {
                changeFrame(PagingDirection.NEXT);
                return true;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    public void changeFrame(PagingDirection navigation) {
        if ((navigation == PagingDirection.PREVIOUS && method_17577().getSelectedFrame() == 0)
                || (navigation == PagingDirection.NEXT && method_17577().getSelectedFrame() == method_17577().getTotalFrames() - 1))
            return;

        Preconditions.checkState(field_22787 != null);
        Preconditions.checkState(field_22787.field_1724 != null);
        Preconditions.checkState(field_22787.field_1761 != null);
        int buttonId = navigation == PagingDirection.NEXT ? LightroomMenu.NEXT_FRAME_BUTTON_ID : LightroomMenu.PREVIOUS_FRAME_BUTTON_ID;
        field_22787.field_1761.method_2900(method_17577().field_7763, buttonId);
        player.method_5783(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), 1f, field_22787.field_1724.method_37908()
                .method_8409().method_43057() * 0.4f + 0.8f);

        // Update block entity clientside to faster update advance frame arrows:
        method_17577().getBlockEntity().setSelectedFrame(method_17577().getBlockEntity().getSelectedFrameIndex() + (navigation == PagingDirection.NEXT ? 1 : -1));
    }

    private void enterFrameInspectMode() {
        class_310.method_1551().method_1507(new FilmFrameInspectScreen(this, method_17577()));
        player.method_5783(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), 1f, 1.3f);
    }

    @Override
    protected boolean method_2381(double mouseX, double mouseY, int guiLeft, int guiTop, int mouseButton) {
        return super.method_2381(mouseX, mouseY, guiLeft, guiTop, mouseButton)
                && field_2787 == null;
    }
}
