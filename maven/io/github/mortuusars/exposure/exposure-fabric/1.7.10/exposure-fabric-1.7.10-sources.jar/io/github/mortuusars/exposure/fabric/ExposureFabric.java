package io.github.mortuusars.exposure.fabric;

import fuzs.forgeconfigapiport.api.config.v2.ForgeConfigRegistry;
import fuzs.forgeconfigapiport.api.config.v2.ModConfigEvents;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.command.ExposureCommand;
import io.github.mortuusars.exposure.command.ShaderCommand;
import io.github.mortuusars.exposure.command.TestCommand;
import io.github.mortuusars.exposure.data.Lenses;
import io.github.mortuusars.exposure.fabric.integration.create.CreateFilmDeveloping;
import io.github.mortuusars.exposure.fabric.resources.FabricLensesDataLoader;
import io.github.mortuusars.exposure.integration.ModCompatibilityClient;
import io.github.mortuusars.exposure.network.fabric.PacketsImpl;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.fabricmc.fabric.api.loot.v2.LootTableSource;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_39;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_60;
import net.minecraft.class_7706;
import net.minecraft.class_83;
import net.minecraftforge.fml.config.ModConfig;

public class ExposureFabric implements ModInitializer {
    @Override
    public void onInitialize() {
        Exposure.init();

        ModConfigEvents.reloading(Exposure.ID).register(config -> {
            if (config.getType() == ModConfig.Type.COMMON && FabricLoader.getInstance().isModLoaded("create")) {
                CreateFilmDeveloping.clearCachedData();
            }

            if (config.getType() == ModConfig.Type.CLIENT) {
                ModCompatibilityClient.handle();
            }
        });

        ForgeConfigRegistry.INSTANCE.register(Exposure.ID, ModConfig.Type.COMMON, Config.Common.SPEC);
        ForgeConfigRegistry.INSTANCE.register(Exposure.ID, ModConfig.Type.CLIENT, Config.Client.SPEC);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            ExposureCommand.register(dispatcher);
            ShaderCommand.register(dispatcher);
            TestCommand.register(dispatcher);
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(content -> {
            content.method_45421(Exposure.Items.CAMERA.get());
            content.method_45421(Exposure.Items.BLACK_AND_WHITE_FILM.get());
            content.method_45421(Exposure.Items.COLOR_FILM.get());
            content.method_45421(Exposure.Items.DEVELOPED_BLACK_AND_WHITE_FILM.get());
            content.method_45421(Exposure.Items.DEVELOPED_COLOR_FILM.get());
            content.method_45421(Exposure.Items.PHOTOGRAPH.get());
            content.method_45421(Exposure.Items.AGED_PHOTOGRAPH.get());
            content.method_45421(Exposure.Items.INTERPLANAR_PROJECTOR.get());
            content.method_45421(Exposure.Items.STACKED_PHOTOGRAPHS.get());
            content.method_45421(Exposure.Items.PHOTOGRAPH_FRAME.get());
            content.method_45421(Exposure.Items.ALBUM.get());
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(content -> {
            content.method_45421(Exposure.Items.LIGHTROOM.get());
        });

        Exposure.Advancements.register();
        Exposure.Stats.register();

        ResourceManagerHelper.get(class_3264.field_14190).registerReloadListener(new FabricLensesDataLoader());

        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            Exposure.initServer(server);
            PacketsImpl.onServerStarting(server);
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(PacketsImpl::onServerStopped);

        ServerLifecycleEvents.SYNC_DATA_PACK_CONTENTS.register((player, joined) -> Lenses.onDatapackSync(player));

        LootTableEvents.MODIFY.register(ExposureFabric::modifyLoot);

        PacketsImpl.registerC2SPackets();
    }

    private static void modifyLoot(class_3300 resourceManager, class_60 manager,
                                   class_2960 table, class_52.class_53 builder, LootTableSource source) {
        if (!Config.Common.LOOT_ADDITION.get() || !source.isBuiltin())
            return;

        if (class_39.field_356.equals(table)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.resource("chests/simple_dungeon")))
                    .method_355());
        }
        if (class_39.field_472.equals(table)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.resource("chests/abandoned_mineshaft")))
                    .method_355());
        }
        if (class_39.field_800.equals(table)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.resource("chests/stronghold")))
                    .method_355());
        }
        if (class_39.field_16748.equals(table)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.resource("chests/village_plains_house")))
                    .method_355());
        }
        if (class_39.field_841.equals(table)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.resource("chests/shipwreck_map")))
                    .method_355());
        }
    }
}
