package io.github.mortuusars.exposure.fabric;

import io.github.mortuusars.exposure.fabric.api.event.FrameAddedCallback;
import io.github.mortuusars.exposure.fabric.api.event.ModifyFrameDataCallback;
import io.github.mortuusars.exposure.fabric.api.event.ShutterOpeningCallback;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1820;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;

public class PlatformHelperImpl {
    public static boolean canShear(class_1799 stack) {
        return stack.method_7909() instanceof class_1820;
    }

    public static boolean canStrip(class_1799 stack) {
        return stack.method_7909() instanceof class_1743;
    }

    public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_2540> extraDataWriter) {
        ExtendedScreenHandlerFactory extendedScreenHandlerFactory = new ExtendedScreenHandlerFactory() {
            @Nullable
            @Override
            public class_1703 createMenu(int i, @NotNull class_1661 inventory, @NotNull class_1657 player) {
                return menuProvider.createMenu(i, inventory, player);
            }

            @Override
            public @NotNull class_2561 method_5476() {
                return menuProvider.method_5476();
            }

            @Override
            public void writeScreenOpeningData(class_3222 player, class_2540 buffer) {
                extraDataWriter.accept(buffer);
            }
        };

        serverPlayer.method_17355(extendedScreenHandlerFactory);
    }

    public static List<String> getDefaultSpoutDevelopmentColorSequence() {
        return List.of(
                "{FluidName:\"create:potion\",Amount:27000,Tag:{Potion:\"minecraft:awkward\"}}",
                "{FluidName:\"create:potion\",Amount:27000,Tag:{Potion:\"minecraft:thick\"}}",
                "{FluidName:\"create:potion\",Amount:27000,Tag:{Potion:\"minecraft:mundane\"}}");
    }

    public static List<String> getDefaultSpoutDevelopmentBWSequence() {
        return List.of(
                "{FluidName:\"minecraft:water\",Amount:27000}");
    }

    public static boolean isModLoaded(String modId) {
        return FabricLoader.getInstance().isModLoaded(modId);
    }

    public static boolean fireShutterOpeningEvent(class_1657 player, class_1799 cameraStack, int lightLevel, boolean shouldFlashFire) {
        return ShutterOpeningCallback.EVENT.invoker().onShutterOpening(player, cameraStack, lightLevel, shouldFlashFire);
    }

    public static void fireModifyFrameDataEvent(class_3222 player, class_1799 cameraStack, class_2487 frame, List<class_1297> entitiesInFrame) {
        ModifyFrameDataCallback.EVENT.invoker().modifyFrameData(player, cameraStack, frame, entitiesInFrame);
    }

    public static void fireFrameAddedEvent(class_3222 player, class_1799 cameraStack, class_2487 frame) {
        FrameAddedCallback.EVENT.invoker().onFrameAdded(player, cameraStack, frame);
    }
}
