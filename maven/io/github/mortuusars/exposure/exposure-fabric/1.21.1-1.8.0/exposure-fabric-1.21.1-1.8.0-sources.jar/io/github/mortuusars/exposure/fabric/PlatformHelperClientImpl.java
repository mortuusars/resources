package io.github.mortuusars.exposure.fabric;

import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_310;

public class PlatformHelperClientImpl {
    public static class_1087 getModel(class_1091 model) {
        // Fabric adds it's "fabric_resource" to id. Forge uses model location as is.
        return class_310.method_1551().method_1554().getModel(model.comp_2875());
    }
}
