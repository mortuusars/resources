package io.github.mortuusars.exposure.fabric;

import fuzs.forgeconfigapiport.fabric.api.neoforge.v4.NeoForgeConfigRegistry;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.data.Filter;
import io.github.mortuusars.exposure.data.Lens;
import io.github.mortuusars.exposure.event.CommonEvents;
import io.github.mortuusars.exposure.event.ServerEvents;
import io.github.mortuusars.exposure.network.fabric.FabricC2SPackets;
import io.github.mortuusars.exposure.network.fabric.FabricS2CPackets;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.registry.DynamicRegistries;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableSource;
import net.minecraft.class_39;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_7225;
import net.minecraft.class_7706;
import net.minecraft.class_83;
import net.minecraft.server.MinecraftServer;
import net.neoforged.fml.config.ModConfig;
import org.jetbrains.annotations.Nullable;

import java.util.stream.Stream;

public class ExposureFabric implements ModInitializer {
    // Server field to access when no other objects are available to get it from.
    public static @Nullable MinecraftServer server = null;

    @Override
    public void onInitialize() {
        Exposure.init();

        DynamicRegistries.registerSynced(Exposure.Registries.COLOR_PALETTE, ColorPalette.CODEC, ColorPalette.CODEC);
        DynamicRegistries.registerSynced(Exposure.Registries.LENS, Lens.CODEC, Lens.CODEC);
        DynamicRegistries.registerSynced(Exposure.Registries.FILTER, Filter.CODEC, Filter.CODEC);

        NeoForgeConfigRegistry.INSTANCE.register(Exposure.ID, ModConfig.Type.SERVER, Config.Server.SPEC);
        NeoForgeConfigRegistry.INSTANCE.register(Exposure.ID, ModConfig.Type.COMMON, Config.Common.SPEC);
        NeoForgeConfigRegistry.INSTANCE.register(Exposure.ID, ModConfig.Type.CLIENT, Config.Client.SPEC);

        CommandRegistrationCallback.EVENT.register(CommonEvents::registerCommands);

        addItemsToCreativeTabs();

        Exposure.Stats.register();

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            ServerEvents.serverStarted(server);
            ExposureFabric.server = server;
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            ServerEvents.serverStopped(server);
            ExposureFabric.server = null;
        });

        ServerLifecycleEvents.SYNC_DATA_PACK_CONTENTS.register((player, joined) -> ServerEvents.syncDatapack(Stream.of(player)));

        LootTableEvents.MODIFY.register(ExposureFabric::modifyLoot);

        FabricC2SPackets.register();
        FabricS2CPackets.register();
    }

    private static void addItemsToCreativeTabs() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(content -> {
            content.method_45421(Exposure.Items.CAMERA.get());
            content.method_45421(Exposure.Items.BLACK_AND_WHITE_FILM.get());
            content.method_45421(Exposure.Items.COLOR_FILM.get());
            content.method_45421(Exposure.Items.DEVELOPED_BLACK_AND_WHITE_FILM.get());
            content.method_45421(Exposure.Items.DEVELOPED_COLOR_FILM.get());
            content.method_45421(Exposure.Items.PHOTOGRAPH.get());
            content.method_45421(Exposure.Items.AGED_PHOTOGRAPH.get());
            content.method_45421(Exposure.Items.INTERPLANAR_PROJECTOR.get());
            content.method_45421(Exposure.Items.STACKED_PHOTOGRAPHS.get());
            content.method_45421(Exposure.Items.PHOTOGRAPH_FRAME.get());
            content.method_45421(Exposure.Items.CLEAR_PHOTOGRAPH_FRAME.get());
            content.method_45421(Exposure.Items.ALBUM.get());
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(content -> {
            content.method_45421(Exposure.Items.LIGHTROOM.get());
        });
    }

    private static void modifyLoot(class_5321<class_52> tableKey, class_52.class_53 builder,
                                   LootTableSource source, class_7225.class_7874 provider) {
        if (!Config.Common.GENERATE_LOOT.get() || !source.isBuiltin())
            return;

        if (class_39.field_356.equals(tableKey)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.LootTables.SIMPLE_DUNGEON_INJECT))
                    .method_355());
        }
        if (class_39.field_472.equals(tableKey)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.LootTables.ABANDONED_MINESHAFT_INJECT))
                    .method_355());
        }
        if (class_39.field_800.equals(tableKey)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.LootTables.STRONGHOLD_CROSSING_INJECT))
                    .method_355());
        }
        if (class_39.field_16748.equals(tableKey)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.LootTables.VILLAGE_PLAINS_HOUSE_INJECT))
                    .method_355());
        }
        if (class_39.field_841.equals(tableKey)) {
            builder.pool(class_55.method_347()
                    .method_351(class_83.method_428(Exposure.LootTables.SHIPWRECK_MAP_INJECT))
                    .method_355());
        }
    }
}
