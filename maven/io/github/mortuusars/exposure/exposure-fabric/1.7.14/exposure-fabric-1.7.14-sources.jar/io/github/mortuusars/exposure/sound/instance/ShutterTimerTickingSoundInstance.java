package io.github.mortuusars.exposure.sound.instance;

import io.github.mortuusars.exposure.item.CameraItem;
import net.minecraft.class_1101;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5819;

public class ShutterTimerTickingSoundInstance extends class_1101 {
    private final class_1657 player;
    private int field_5451 = 2;
    private final float originalVolume;
    public ShutterTimerTickingSoundInstance(class_1657 player, class_3414 soundEvent, class_3419 soundSource, float volume, float pitch, class_5819 random) {
        super(soundEvent, soundSource, random);
        this.player = player;
        this.field_5439 = player.method_23317();
        this.field_5450 = player.method_23318();
        this.field_5449 = player.method_23321();
        this.field_5442 = volume;
        this.originalVolume = volume;
        this.field_5441 = pitch;
        this.field_5446 = true;
    }

    @Override
    public void method_16896() {
        this.field_5439 = player.method_23317();
        this.field_5450 = player.method_23318();
        this.field_5449 = player.method_23321();

        if (hasShutterOpen(player.method_6047()) || hasShutterOpen(player.method_6079())) {
            field_5442 = class_3532.method_16439(0.3f, field_5442, originalVolume);
            return;
        }
        else
            field_5442 = class_3532.method_16439(0.2f, field_5442, originalVolume * 0.3f);

        if (!hasCameraWithOpenShutterInInventory(player)) {
            // In multiplayer other players camera photo is not updated in time (sometimes)
            // This causes the sound to stop instantly
            if (!player.equals(class_310.method_1551().field_1724) && field_5451 > 0) {
                field_5451--;
                return;
            }

            this.method_24876();
        }
    }

    private boolean hasCameraWithOpenShutterInInventory(class_1657 player) {
        for (class_1799 stack : player.method_31548().field_7547) {
            if (hasShutterOpen(stack))
                return true;
        }

        return false;
    }

    private boolean hasShutterOpen(class_1799 stack) {
        return stack.method_7909() instanceof CameraItem cameraItem && cameraItem.isShutterOpen(stack);
    }
}
