package io.github.mortuusars.exposure.fabric.resources;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.data.filter.Filters;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2960;

public class FabricFiltersLoader extends Filters.Loader implements IdentifiableResourceReloadListener {
    public static final class_2960 ID = Exposure.resource("filters_loader");
    @Override
    public class_2960 getFabricId() {
        return ID;
    }
}
