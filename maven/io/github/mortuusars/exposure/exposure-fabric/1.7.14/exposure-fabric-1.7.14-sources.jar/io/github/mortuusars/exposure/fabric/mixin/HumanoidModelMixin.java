package io.github.mortuusars.exposure.fabric.mixin;

import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.item.CameraItemClientExtensions;
import io.github.mortuusars.exposure.util.CameraInHand;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_4592;
import net.minecraft.class_572;
import net.minecraft.class_630;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_572.class)
public abstract class HumanoidModelMixin<T extends class_1309> extends class_4592<T> {
    @Shadow public abstract class_630 getHead();
    @Final
    @Shadow public class_630 hat;

    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At("RETURN"))
    void onSetupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci) {
        if (!(entity instanceof class_1657 player))
            return;

        @Nullable Camera<CameraItem> camera = CameraInHand.ofPlayer(player, CameraItem.class);
        if (!(camera instanceof CameraInHand<CameraItem> cameraInHand))
            return;

        class_1306 arm = class_310.method_1551().field_1690.method_42552().method_41753();
        if (cameraInHand.getHand() == class_1268.field_5810)
            arm = arm.method_5928();

        if (camera.get().getItem().isInSelfieMode(camera.get().getStack()))
            CameraItemClientExtensions.applySelfieHoldingPose((class_572<?>) (Object) this, entity, arm, false);
        else
            CameraItemClientExtensions.applyDefaultHoldingPose((class_572<?>) (Object) this, entity, arm);

        hat.method_17138(getHead());
    }
}
