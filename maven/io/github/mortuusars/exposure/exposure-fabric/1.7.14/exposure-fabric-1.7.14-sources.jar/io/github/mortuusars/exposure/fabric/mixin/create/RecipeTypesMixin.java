package io.github.mortuusars.exposure.fabric.mixin.create;

import com.simibubi.create.AllRecipeTypes;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_1860;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(value = AllRecipeTypes.class, remap = false)
public class RecipeTypesMixin {
    @Inject(method = "shouldIgnoreInAutomation", at = @At("HEAD"), cancellable = true)
    private static void onShouldIgnoreInAutomation(class_1860<?> recipe, CallbackInfoReturnable<Boolean> cir) {
        if (recipe.method_8119().equals(Exposure.RecipeSerializers.FILM_DEVELOPING.get()) ||
                recipe.method_8119().equals(Exposure.RecipeSerializers.PHOTOGRAPH_CLONING.get()) ||
                recipe.method_8119().equals(Exposure.RecipeSerializers.PHOTOGRAPH_AGING.get()))
            cir.setReturnValue(true);
    }
}
