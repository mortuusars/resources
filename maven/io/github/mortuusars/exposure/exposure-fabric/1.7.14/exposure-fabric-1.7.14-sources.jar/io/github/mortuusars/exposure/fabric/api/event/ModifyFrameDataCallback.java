package io.github.mortuusars.exposure.fabric.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_3222;
import java.util.List;

/**
 * Can be used to add additional data to the frame or modify existing data. This data can be used in advancements or quests afterward.
 * Fired only on the server side.
 */
public interface ModifyFrameDataCallback {
    Event<ModifyFrameDataCallback> EVENT = EventFactory.createArrayBacked(ModifyFrameDataCallback.class,
            (listeners) -> (player, cameraStack, frame, entitiesInFrame) -> {
                for (ModifyFrameDataCallback listener : listeners) {
                    listener.modifyFrameData(player, cameraStack, frame, entitiesInFrame);
                }
            });

    void modifyFrameData(class_3222 player, class_1799 cameraStack, class_2487 frame, List<class_1297> entitiesInFrame);
}
