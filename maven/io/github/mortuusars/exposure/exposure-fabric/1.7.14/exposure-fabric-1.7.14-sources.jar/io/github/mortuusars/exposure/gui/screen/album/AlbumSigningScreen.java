package io.github.mortuusars.exposure.gui.screen.album;

import io.github.mortuusars.exposure.gui.screen.element.textbox.HorizontalAlignment;
import io.github.mortuusars.exposure.gui.screen.element.textbox.TextBox;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.server.AlbumSignC2SP;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_7919;

public class AlbumSigningScreen extends class_437 {
    public static final int SELECTION_COLOR = 0xFF8888FF;
    public static final int SELECTION_UNFOCUSED_COLOR = 0xFFBBBBFF;

    @NotNull
    protected final class_310 field_22787;
    @NotNull
    protected final class_1657 player;

    protected final class_437 parentScreen;
    protected final class_2960 texture;

    protected int imageWidth, imageHeight, leftPos, topPos, textureWidth, textureHeight;

    protected TextBox titleTextBox;
    protected class_344 signButton;
    protected class_344 cancelSigningButton;

    protected String titleText = "";

    public AlbumSigningScreen(class_437 screen, class_2960 texture, int textureWidth, int textureHeight) {
        super(class_2561.method_43473());
        this.parentScreen = screen;
        this.texture = texture;
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;

        field_22787 = class_310.method_1551();
        player = Objects.requireNonNull(field_22787.field_1724);
    }

    @Override
    protected void method_25426() {
        this.imageWidth = 149;
        this.imageHeight = 188;
        this.leftPos = (this.field_22789 - this.imageWidth) / 2;
        this.topPos = (this.field_22790 - this.imageHeight) / 2;

        // TITLE
        titleTextBox = new TextBox(field_22793, leftPos + 21, topPos + 73, 108, 9,
                () -> titleText, text -> titleText = text)
                .setFontColor(0xFF856036, 0xFF856036)
                .setSelectionColor(SELECTION_COLOR, SELECTION_UNFOCUSED_COLOR);
        titleTextBox.textValidator = text -> text != null && field_22793.method_1713(text, 108) <= 9 && !text.contains("\n");
        titleTextBox.horizontalAlignment = HorizontalAlignment.CENTER;
        method_37063(titleTextBox);

        // SIGN
        signButton = new class_344(leftPos + 46, topPos + 110, 22, 22, 242, 188,
                22, texture, textureWidth, textureHeight,
                b -> signAlbum(), class_2561.method_43471("gui.exposure.album.sign"));
        class_5250 component = class_2561.method_43471("gui.exposure.album.sign")
                .method_27693("\n").method_10852(class_2561.method_43471("gui.exposure.album.sign.warning").method_27692(class_124.field_1080));
        signButton.method_47400(class_7919.method_47407(component));
        method_37063(signButton);

        // CANCEL
        cancelSigningButton = new class_344(leftPos + 83, topPos + 111, 22, 22, 264, 188,
                22, texture, textureWidth, textureHeight,
                b -> cancelSigning(), class_2561.method_43471("gui.exposure.album.cancel_signing"));
        cancelSigningButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure.album.cancel_signing")));
        method_37063(cancelSigningButton);

        method_48265(titleTextBox);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25393() {
        titleTextBox.tick();
    }

    private void updateButtons() {
        signButton.field_22763 = canSign();
    }

    protected boolean canSign() {
        return !titleText.isEmpty();
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();

        method_25420(guiGraphics);
        guiGraphics.method_25291(texture, leftPos, topPos, 0, 298,
                0, imageWidth, imageHeight, textureWidth, textureHeight);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        renderLabels(guiGraphics);
    }

    private void renderLabels(class_332 guiGraphics) {
        class_5250 component = class_2561.method_43471("gui.exposure.album.enter_title");
        guiGraphics.method_51439(field_22793, component,  leftPos + 149 / 2 - field_22793.method_27525(component) / 2, topPos + 50, 0xf5ebd0, false);

        component = class_2561.method_43469("gui.exposure.album.by_author", player.method_5477());
        guiGraphics.method_51439(field_22793, component, leftPos + 149 / 2 - field_22793.method_27525(component) / 2, topPos + 84, 0xc7b496, false);
    }

    protected void signAlbum() {
        if (canSign()) {
            Packets.sendToServer(new AlbumSignC2SP(titleText));
            this.method_25419();
        }
    }

    protected void cancelSigning() {
        field_22787.method_1507(parentScreen);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == class_3675.field_31948)
            return super.method_25404(keyCode, scanCode, modifiers);

        if (keyCode == class_3675.field_31958) {
            cancelSigning();
            return true;
        }

        if (titleTextBox.method_25370())
            return titleTextBox.method_25404(keyCode, scanCode, modifiers);

        return super.method_25404(keyCode, scanCode, modifiers);
    }
}
