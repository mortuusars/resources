package io.github.mortuusars.exposure.fabric.mixin.create;

import com.simibubi.create.content.fluids.spout.FillingBySpout;
import com.simibubi.create.foundation.fluid.FluidIngredient;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.fabric.integration.create.CreateFilmDeveloping;
import io.github.mortuusars.exposure.item.FilmRollItem;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(value = FillingBySpout.class, remap = false)
public abstract class SpoutDevelopingMixin {
    @Inject(method = "canItemBeFilled", at = @At("HEAD"), cancellable = true)
    private static void onCanItemBeFilled(class_1937 world, class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
        if (Config.Common.CREATE_SPOUT_DEVELOPING_ENABLED.get() && stack.method_7909() instanceof FilmRollItem)
            cir.setReturnValue(true);
    }

    @Inject(method = "getRequiredAmountForItem", at = @At("HEAD"), cancellable = true)
    private static void onGetRequiredAmountForItem(class_1937 world, class_1799 stack, FluidStack availableFluid, CallbackInfoReturnable<Long> cir) {
        if (Config.Common.CREATE_SPOUT_DEVELOPING_ENABLED.get() && stack.method_7909() instanceof FilmRollItem) {
            @Nullable FluidStack nextFluidStep = CreateFilmDeveloping.getNextRequiredFluid(stack);
            if (nextFluidStep == null)
                cir.setReturnValue(0L);
            else if (FluidIngredient.fromFluidStack(nextFluidStep).test(availableFluid))
                cir.setReturnValue(nextFluidStep.getAmount());
        }
    }

    @Inject(method = "fillItem", at = @At("HEAD"), cancellable = true)
    private static void onFillItem(class_1937 world, long requiredAmount, class_1799 stack, FluidStack availableFluid, CallbackInfoReturnable<class_1799> cir) {
        if (Config.Common.CREATE_SPOUT_DEVELOPING_ENABLED.get() && stack.method_7909() instanceof FilmRollItem) {
            class_1799 result = CreateFilmDeveloping.fillFilmStack(stack, requiredAmount, availableFluid);
            cir.setReturnValue(result);
        }
    }
}
