package io.github.mortuusars.exposure.fabric.mixin;

import io.github.mortuusars.exposure.render.ItemFramePhotographRenderer;
import net.minecraft.class_1533;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import net.minecraft.class_915;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_915.class)
public abstract class ItemFrameRendererFabricMixin<T extends class_1533>
        extends class_897<T> {
    protected ItemFrameRendererFabricMixin(class_5617.class_5618 context) {
        super(context);
    }

    @Inject(method = "render(Lnet/minecraft/world/entity/decoration/ItemFrame;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            cancellable = true,
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/ItemRenderer;renderStatic(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;IILcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/level/Level;I)V"))
    void onItemFrameRender(T entity, float entityYaw, float partialTicks, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
        poseStack.method_22905(2F, 2F, 2F);
        boolean rendered = ItemFramePhotographRenderer.render(entity, poseStack, buffer, packedLight);

        if (rendered) {
            poseStack.method_22909();
            ci.cancel();
        }
        else {
            poseStack.method_22905(0.5F, 0.5F, 0.5F);
        }
    }
}
