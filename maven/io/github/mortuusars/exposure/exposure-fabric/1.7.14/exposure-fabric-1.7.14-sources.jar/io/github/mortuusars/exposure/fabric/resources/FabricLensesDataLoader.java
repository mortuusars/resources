package io.github.mortuusars.exposure.fabric.resources;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.data.LensesDataLoader;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2960;

public class FabricLensesDataLoader extends LensesDataLoader implements IdentifiableResourceReloadListener {
    public static final class_2960 ID = Exposure.resource("lenses_data");
    @Override
    public class_2960 getFabricId() {
        return ID;
    }
}
