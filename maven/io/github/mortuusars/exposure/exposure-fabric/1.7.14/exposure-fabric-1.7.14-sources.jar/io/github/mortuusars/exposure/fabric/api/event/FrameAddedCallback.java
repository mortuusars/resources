package io.github.mortuusars.exposure.fabric.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_3222;

/**
 * Fired at the very end of a shot, when frame is added to the film.
 * Fired only on the server side.
 */
public interface FrameAddedCallback {
    Event<FrameAddedCallback> EVENT = EventFactory.createArrayBacked(FrameAddedCallback.class,
            (listeners) -> (player, cameraStack, frame) -> {
                for (FrameAddedCallback listener : listeners) {
                    listener.onFrameAdded(player, cameraStack, frame);
                }
            });

    void onFrameAdded(class_3222 player, class_1799 cameraStack, class_2487 frame);
}
