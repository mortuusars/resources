package io.github.mortuusars.exposure.gui.screen.album;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.gui.screen.element.Pager;
import io.github.mortuusars.exposure.gui.screen.element.TextBlock;
import io.github.mortuusars.exposure.gui.screen.element.textbox.HorizontalAlignment;
import io.github.mortuusars.exposure.gui.screen.element.textbox.TextBox;
import io.github.mortuusars.exposure.item.AlbumPage;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.menu.AlbumMenu;
import io.github.mortuusars.exposure.menu.AlbumPlayerInventorySlot;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.server.AlbumSyncNoteC2SP;
import io.github.mortuusars.exposure.util.ItemAndStack;
import io.github.mortuusars.exposure.util.PagingDirection;
import io.github.mortuusars.exposure.util.Side;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_1109;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3417;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_636;
import net.minecraft.class_757;
import net.minecraft.class_768;
import net.minecraft.class_7919;

public class AlbumScreen extends class_465<AlbumMenu> {
    
    public static final class_2960 TEXTURE = Exposure.resource("textures/gui/album.png");
    public static final int MAIN_FONT_COLOR = 0xFFB59774;
    public static final int SECONDARY_FONT_COLOR = 0xFFEFE4CA;
    public static final int SELECTION_COLOR = 0xFF8888FF;
    public static final int SELECTION_UNFOCUSED_COLOR = 0xFFBBBBFF;

    @NotNull
    protected final class_310 field_22787;
    @NotNull
    protected final class_1657 player;
    @NotNull
    protected final class_636 gameMode;

    protected final Pager pager = new Pager(class_3417.field_17481) {
        @Override
        public void onPageChanged(PagingDirection pagingDirection, int prevPage, int currentPage) {
            super.onPageChanged(pagingDirection, prevPage, currentPage);
            sendButtonClick(pagingDirection == PagingDirection.PREVIOUS ? AlbumMenu.PREVIOUS_PAGE_BUTTON : AlbumMenu.NEXT_PAGE_BUTTON);
        }
    };

    protected final List<Page> pages = new ArrayList<>();

    @Nullable
    protected class_4185 enterSignModeButton;

    public AlbumScreen(AlbumMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
        field_22787 = class_310.method_1551();
        player = Objects.requireNonNull(field_22787.field_1724);
        gameMode = Objects.requireNonNull(field_22787.field_1761);
    }

    @Override
    protected void method_37432() {
        forEachPage(page -> page.noteWidget.ifLeft(TextBox::tick));
    }

    @Override
    protected void method_25426() {
        this.field_2792 = 298;
        this.field_2779 = 188;
        super.method_25426();

        field_25268 = -999;
        field_25269 = 69;
        field_25270 = -999;

        pages.clear();

        // LEFT:
        Page leftPage = createPage(Side.LEFT, 0);
        pages.add(leftPage);

        class_344 previousButton = new class_344(field_2776 + 12, field_2800 + 164, 13, 15,
                216, 188, 15, TEXTURE, 512, 512,
                button -> pager.changePage(PagingDirection.PREVIOUS), class_2561.method_43471("gui.exposure.previous_page"));
        previousButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure.previous_page")));
        method_37063(previousButton);

        // RIGHT:
        Page rightPage = createPage(Side.RIGHT, 140);
        pages.add(rightPage);

        class_344 nextButton = new class_344(field_2776 + 273, field_2800 + 164, 13, 15,
                229, 188, 15, TEXTURE, 512, 512,
                button -> pager.changePage(PagingDirection.NEXT), class_2561.method_43471("gui.exposure.next_page"));
        nextButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure.next_page")));
        method_37063(nextButton);

        // MISC:
        if (method_17577().isAlbumEditable()) {
            enterSignModeButton = new class_344(field_2776 - 23, field_2800 + 17, 22, 22, 242, 188,
                    22, TEXTURE, 512, 512,
                    b -> enterSignMode(), class_2561.method_43471("gui.exposure.album.sign"));
            enterSignModeButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure.album.sign")));
            method_37063(enterSignModeButton);
        }

        int spreadsCount = (int) Math.ceil(method_17577().getPages().size() / 2f);
        pager.init(spreadsCount, false, previousButton, nextButton);
    }

    protected Page createPage(Side side, int xOffset) {
        int x = field_2776 + xOffset;
        int y = field_2800;

        class_768 page = new class_768(x, y, 149, 188);
        class_768 photo = new class_768(x + 25, y + 21, 108, 108);
        class_768 exposure = new class_768(x + 31, y + 27, 96, 96);
        class_768 note = new class_768(x + 22, y + 133, 114, 27);

        PhotographSlotButton photographButton = new PhotographSlotButton(exposure, photo.method_3321(), photo.method_3322(),
                photo.method_3319(), photo.method_3320(), 0, 188, 108, TEXTURE, 512, 512,
                b -> {
                    PhotographSlotButton button = (PhotographSlotButton) b;
                    class_1799 photograph = button.getPhotograph();
                    if (photograph.method_7960()) {
                        if (button.isEditable) {
                            sendButtonClick(side == Side.LEFT ? AlbumMenu.LEFT_PAGE_PHOTO_BUTTON : AlbumMenu.RIGHT_PAGE_PHOTO_BUTTON);
                            button.method_25354(field_22787.method_1483());
                        }
                    } else
                        inspectPhotograph(photograph);
                },
                b -> {
                    PhotographSlotButton button = (PhotographSlotButton) b;
                    if (button.isEditable && !button.getPhotograph().method_7960()) {
                        sendButtonClick(side == Side.LEFT ? AlbumMenu.LEFT_PAGE_PHOTO_BUTTON : AlbumMenu.RIGHT_PAGE_PHOTO_BUTTON);
                        field_22787.method_1483().method_4873(class_1109.method_4757(
                                Exposure.SoundEvents.PHOTOGRAPH_PLACE.get(), 0.7f, 1.1f));
                    }
                }, () -> method_17577().getPhotograph(side), method_17577().isAlbumEditable()) {
            @Override
            public boolean method_25402(double mouseX, double mouseY, int button) {
                return !isInAddingMode() && super.method_25402(mouseX, mouseY, button);
            }

            @Override
            public boolean method_49606() {
                return !isInAddingMode() && super.method_49606();
            }
        };
        method_37063(photographButton);

        Either<TextBox, TextBlock> noteWidget;
        if (method_17577().isAlbumEditable()) {
            TextBox textBox = new TextBox(field_22793, note.method_3321(), note.method_3322(), note.method_3319(), note.method_3320(),
                    () -> method_17577().getPage(side).map(p -> p.getNote().left().orElseThrow()).orElse(""),
                    text -> onNoteChanged(side, text))
                    .setFontColor(MAIN_FONT_COLOR, MAIN_FONT_COLOR)
                    .setSelectionColor(SELECTION_COLOR, SELECTION_UNFOCUSED_COLOR);
            textBox.horizontalAlignment = HorizontalAlignment.CENTER;
            method_37063(textBox);
            noteWidget = Either.left(textBox);
        } else {
            TextBlock textBlock = new TextBlock(field_22793, note.method_3321(), note.method_3322(),
                    note.method_3319(), note.method_3320(), getNoteComponent(side), this::method_25430);
            textBlock.fontColor = MAIN_FONT_COLOR;
            textBlock.alignment = HorizontalAlignment.CENTER;
            textBlock.drawShadow = false;

            //  TextBlock is rendered manually to not be a part of TAB navigation.
            //  addRenderableWidget(textBlock);

            noteWidget = Either.right(textBlock);
        }

        return new Page(side, page, photo, exposure, note, photographButton, noteWidget);
    }

    protected void onNoteChanged(Side side, String noteText) {
        method_17577().getPage(side).ifPresent(page -> {
            page.setNote(Either.left(noteText));
            int pageIndex = method_17577().getCurrentSpreadIndex() * 2 + side.getIndex();
            Packets.sendToServer(new AlbumSyncNoteC2SP(pageIndex, noteText));
        });
    }

    
    // RENDER
    
    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        pager.update();

        if (enterSignModeButton != null)
            enterSignModeButton.field_22764 = method_17577().canSignAlbum();

        boolean isInAddingPhotographMode = isInAddingMode();

        // Note should be hidden when adding photograph because it's drawn over the slots. Blit offset does not help.
        forEachPage(page -> page.getNoteWidget().field_22764 = !isInAddingPhotographMode);

        for (Page page : pages) {
            page.photographButton.field_22764 = !method_17577().getPhotograph(page.side).method_7960()
                    || (!isInAddingPhotographMode && method_17577().isAlbumEditable());
        }

        field_25270 = isInAddingPhotographMode ? method_17577().getPlayerInventorySlots().get(0).field_7872 - 12 : -999;

        this.method_25420(guiGraphics);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        for (Page page : pages) {
            class_339 noteWidget = page.getNoteWidget();
            if (noteWidget instanceof TextBlock textBlock) {
                textBlock.method_25394(guiGraphics, mouseX, mouseY, partialTick);
            }
        }

        if (isInAddingPhotographMode) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            for (class_1735 slot : method_17577().field_7761) {
                if (!slot.method_7677().method_7960() && !(slot.method_7677().method_7909() instanceof PhotographItem)) {
                    guiGraphics.method_25291(TEXTURE, field_2776 + slot.field_7873 - 1, field_2800 + slot.field_7872 - 1, 350, 176, 404,
                            18, 18, 512, 512);
                }
            }
            RenderSystem.disableBlend();
        }

        this.method_2380(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void method_2388(class_332 guiGraphics, int mouseX, int mouseY) {
        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(0, 0, 15);
        super.method_2388(guiGraphics, mouseX, mouseY);

        guiGraphics.method_51448().method_22909();
    }

    @Override
    protected void method_2380(class_332 guiGraphics, int x, int y) {
        if (isInAddingMode() && field_2787 != null && !field_2787.method_7677()
                .method_7960() && !(field_2787.method_7677().method_7909() instanceof PhotographItem))
            return; // Do not onRender tooltips for greyed-out items

        if (!isInAddingMode()) {
            for (Page page : pages) {
                if (page.photographButton.method_25367()) {
                    page.photographButton.renderTooltip(guiGraphics, x, y);
                    return;
                }

                if (method_17577().isAlbumEditable() && page.isMouseOver(page.noteArea, x, y)) {
                    List<class_2561> tooltip = new ArrayList<>();
                    tooltip.add(class_2561.method_43471("gui.exposure.album.note"));

                    if (!page.getNoteWidget().method_25370())
                        tooltip.add(class_2561.method_43471("gui.exposure.album.left_click_to_edit"));

                    boolean hasText = page.noteWidget.left().map(box -> !box.getText().isEmpty()).orElse(false);
                    if (hasText)
                        tooltip.add(class_2561.method_43471("gui.exposure.album.right_click_to_clear"));

                    guiGraphics.method_51437(this.field_22793, tooltip, Optional.empty(), x, y);

                    return;
                }
            }
        }

        super.method_2380(guiGraphics, x, y);
    }

    @Override
    protected @NotNull List<class_2561> method_51454(class_1799 stack) {
        List<class_2561> tooltipLines = super.method_51454(stack);
        if (isInAddingMode() && field_2787 != null && field_2787.method_7677() == stack
                && stack.method_7909() instanceof PhotographItem) {
            tooltipLines.add(class_2561.method_43473());
            tooltipLines.add(class_2561.method_43471("gui.exposure.album.left_click_to_add"));
        }
        return tooltipLines;
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.method_25291(TEXTURE, field_2776, field_2800, 0, 0, 0,
                field_2792, field_2779, 512, 512);

        if (enterSignModeButton != null && enterSignModeButton.field_22764) {
            guiGraphics.method_25290(TEXTURE, field_2776 - 27, field_2800 + 14, 447, 0,
                    27, 28, 512, 512);
        }

        int currentSpreadIndex = method_17577().getCurrentSpreadIndex();
        drawPageNumbers(guiGraphics, currentSpreadIndex);

        if (isInAddingMode()) {
            @Nullable Side pageBeingAddedTo = method_17577().getSideBeingAddedTo();
            for (Page page : pages) {
                if (page.side == pageBeingAddedTo) {
                    guiGraphics.method_25291(TEXTURE, page.photoArea.method_3321(), page.photoArea.method_3322(), 10, 0, 296,
                            page.photoArea.method_3319(), page.photoArea.method_3320(), 512, 512);
                    break;
                }
            }

            AlbumPlayerInventorySlot firstSlot = method_17577().getPlayerInventorySlots().get(0);
            int x = firstSlot.field_7873 - 8;
            int y = firstSlot.field_7872 - 18;
            guiGraphics.method_25291(TEXTURE, field_2776 + x, field_2800 + y, 10, 0, 404, 176, 100, 512, 512);
        }
    }

    protected void drawPageNumbers(class_332 guiGraphics, int currentSpreadIndex) {
        class_327 font = field_22787.field_1772;

        String leftPageNumber = Integer.toString(currentSpreadIndex * 2 + 1);
        String rightPageNumber = Integer.toString(currentSpreadIndex * 2 + 2);

        guiGraphics.method_51433(font, leftPageNumber, field_2776 + 71 + (8 - font.method_1727(leftPageNumber) / 2),
                field_2800 + 167, SECONDARY_FONT_COLOR, false);

        guiGraphics.method_51433(font, rightPageNumber, field_2776 + 212 + (8 - font.method_1727(rightPageNumber) / 2),
                field_2800 + 167, SECONDARY_FONT_COLOR, false);
    }


    // CONTROLS:

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (isInAddingMode()) {
            if (!isHoveringOverInventory(mouseX, mouseY)
                && (!method_2381(mouseX, mouseY, field_2776, field_2800, button) || method_17577().method_34255().method_7960())) {
                sendButtonClick(AlbumMenu.CANCEL_ADDING_PHOTO_BUTTON);
                return true;
            }

            return super.method_25402(mouseX, mouseY, button);
        }

        for (Page page : pages) {
            if (method_17577().isAlbumEditable() && button == class_3675.field_32002 && page.isMouseOver(page.noteArea, mouseX, mouseY)) {
                page.noteWidget.ifLeft(box -> {
                    box.setText(""); // Clear the note
                });
                return true;
            }
        }

        boolean handled = super.method_25402(mouseX, mouseY, button);

        for (Page page : pages) {
            class_339 noteWidget = page.getNoteWidget();
            if (noteWidget instanceof TextBlock textBlock && textBlock.method_25402(mouseX, mouseY, button)) {
                handled = true;
                break;
            }
        }

        for (Page page : pages) {
            if (page.getNoteWidget().method_25370() && !page.isMouseOver(page.noteArea, mouseX, mouseY)) {
                method_25395(null);
                return true;
            }
        }

        if (!(method_25399() instanceof TextBox))
            method_25395(null); // Clear focus on mouse click because it's annoying. But keep on textbox to type.

        return handled;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (field_2794 && !method_17577().method_34255().method_7960() && method_17577().method_34255().method_7947() == 1) {
            field_2794 = false; // Fixes weird issue with carried item not placing when dragging slightly
        }

        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25430(@Nullable class_2583 style) {
        if (style == null)
            return false;

        class_2558 clickEvent = style.method_10970();
        if (clickEvent == null)
            return false;
        else if (clickEvent.method_10845() == class_2558.class_2559.field_11748) {
            String pageIndexStr = clickEvent.method_10844();
            int pageIndex = Integer.parseInt(pageIndexStr) - 1;
            forcePage(pageIndex);
            return true;
        }

        boolean handled = super.method_25430(style);
        if (handled && clickEvent.method_10845() == class_2558.class_2559.field_11750)
            method_25419();
        return handled;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (isInAddingMode())
            return super.method_25403(mouseX, mouseY, button, dragX, dragY);
        else
            return this.method_25399() != null && this.method_25397() && button == 0
                    && this.method_25399().method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    protected void sendButtonClick(int buttonId) {
        method_17577().method_7604(player, buttonId);
        gameMode.method_2900(method_17577().field_7763, buttonId);

        if (buttonId == AlbumMenu.CANCEL_ADDING_PHOTO_BUTTON)
            method_25395(null);

        if (buttonId == AlbumMenu.PREVIOUS_PAGE_BUTTON || buttonId == AlbumMenu.NEXT_PAGE_BUTTON) {
            for (Page page : pages) {
                page.noteWidget
                        .ifLeft(TextBox::setCursorToEnd)
                        .ifRight(textBlock -> textBlock.method_25355(getNoteComponent(page.side)));
            }
        }
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    protected boolean isHoveringOverInventory(double mouseX, double mouseY) {
        if (!isInAddingMode())
            return false;

        AlbumPlayerInventorySlot firstSlot = method_17577().getPlayerInventorySlots().get(0);
        int x = firstSlot.field_7873 - 8;
        int y = firstSlot.field_7872 - 18;
        return method_2378(x, y, 176, 100, mouseX, mouseY);
    }

    protected boolean isHoveringOverSignElement(double mouseX, double mouseY) {
        return enterSignModeButton == null
                || (enterSignModeButton.field_22764 && method_2378(field_2776 - 27, field_2800 + 14, 27, 28, mouseX, mouseY));
    }

    @Override
    protected boolean method_2381(double mouseX, double mouseY, int guiLeft, int guiTop, int mouseButton) {
        return super.method_2381(mouseX, mouseY, guiLeft, guiTop, mouseButton)
                && !isHoveringOverInventory(mouseX, mouseY)
                && !isHoveringOverSignElement(mouseX, mouseY);
    }

    @SuppressWarnings("UnusedReturnValue")
    protected boolean forcePage(int pageIndex) {
        try {
            int newSpreadIndex = pageIndex / 2;

            if (newSpreadIndex == method_17577().getCurrentSpreadIndex() || newSpreadIndex < 0
                    || newSpreadIndex > method_17577().getPages().size() / 2) {
                return false;
            }

            PagingDirection pagingDirection = newSpreadIndex < method_17577().getCurrentSpreadIndex()
                    ? PagingDirection.PREVIOUS : PagingDirection.NEXT;

            int pageChanges = 0; // Safeguard against infinite loop. Probably not needed. But I don't mind it.
            while (newSpreadIndex != method_17577().getCurrentSpreadIndex() || !pager.canChangePage(pagingDirection)) {
                if (pageChanges > 16)
                    break;

                pager.changePage(pagingDirection);
                pageChanges++;
            }
            return true;
        } catch (Exception e) {
            Exposure.LOGGER.error("Cannot force page: {}", e.toString());
        }
        return false;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == class_3675.field_31948)
            return super.method_25404(keyCode, scanCode, modifiers);

        for (Page page : pages) {
            class_339 widget = page.noteWidget.map(box -> box, block -> block);
            if (widget.method_25370()) {
                if (keyCode == class_3675.field_31958) {
                    this.method_25395(null);
                    return true;
                }

                return widget.method_25404(keyCode, scanCode, modifiers);
            }
        }

        if (isInAddingMode() && (field_22787.field_1690.field_1822.method_1417(keyCode, scanCode)
                || keyCode == class_3675.field_31958)) {
            sendButtonClick(AlbumMenu.CANCEL_ADDING_PHOTO_BUTTON);
            return true;
        }

        return pager.handleKeyPressed(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        for (Page page : pages) {
            if (page.noteWidget.map(box -> box, block -> block).method_25370())
                return super.method_16803(keyCode, scanCode, modifiers);
        }

        return pager.handleKeyReleased(keyCode, scanCode, modifiers) || super.method_16803(keyCode, scanCode, modifiers);
    }


    // MISC:
    
    protected void inspectPhotograph(class_1799 photograph) {
        if (!(photograph.method_7909() instanceof PhotographItem))
            return;

        field_22787.method_1507(new AlbumPhotographScreen(this, List.of(new ItemAndStack<>(photograph))));
        field_22787.method_1483()
                .method_4873(class_1109.method_4757(Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(),
                        player.method_37908().method_8409().method_43057() * 0.2f + 1.3f, 0.75f));
    }

    @NotNull
    protected class_2561 getNoteComponent(Side page) {
        return method_17577().getPage(page)
                .map(AlbumPage::getNote)
                .map(n -> n.map(class_2561::method_43470, comp -> comp))
                .orElse(class_2561.method_43473());
    }

    protected void enterSignMode() {
        if (isInAddingMode())
            sendButtonClick(AlbumMenu.CANCEL_ADDING_PHOTO_BUTTON);

        field_22787.method_1507(new AlbumSigningScreen(this, TEXTURE, 512, 512));
    }

    protected boolean isInAddingMode() {
        return method_17577().isInAddingPhotographMode();
    }
    
    protected void forEachPage(Consumer<Page> pageAction) {
        for (Page page : pages) {
            pageAction.accept(page);
        }
    }

    protected class Page {
        public final Side side;
        public final class_768 pageArea;
        public final class_768 photoArea;
        public final class_768 exposureArea;
        public final class_768 noteArea;

        public final PhotographSlotButton photographButton;
        public final Either<TextBox, TextBlock> noteWidget;

        private Page(Side side, class_768 pageArea, class_768 photoArea, class_768 exposureArea, class_768 noteArea,
                     PhotographSlotButton photographButton, Either<TextBox, TextBlock> noteWidget) {
            this.side = side;
            this.pageArea = pageArea;
            this.photoArea = photoArea;
            this.exposureArea = exposureArea;
            this.noteArea = noteArea;
            this.photographButton = photographButton;
            this.noteWidget = noteWidget;
        }

        public boolean isMouseOver(class_768 area, double mouseX, double mouseY) {
            return method_2378(area.method_3321() - field_2776, area.method_3322() - field_2800,
                    area.method_3319(), area.method_3320(), mouseX, mouseY);
        }

        public class_339 getNoteWidget() {
            return noteWidget.map(box -> box, block -> block);
        }
    }
}
