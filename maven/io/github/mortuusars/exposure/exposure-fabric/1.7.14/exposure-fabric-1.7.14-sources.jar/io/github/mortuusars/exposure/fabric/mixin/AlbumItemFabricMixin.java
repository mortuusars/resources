package io.github.mortuusars.exposure.fabric.mixin;

import io.github.mortuusars.exposure.item.AlbumItem;
import net.fabricmc.fabric.api.item.v1.FabricItem;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value = AlbumItem.class, remap = false)
public abstract class AlbumItemFabricMixin implements FabricItem {
    @Shadow
    abstract boolean shouldPlayEquipAnimation(class_1799 oldStack, class_1799 newStack);
    @Override
    public boolean allowNbtUpdateAnimation(class_1657 player, class_1268 hand, class_1799 oldStack, class_1799 newStack) {
        return shouldPlayEquipAnimation(oldStack, newStack);
    }
}
