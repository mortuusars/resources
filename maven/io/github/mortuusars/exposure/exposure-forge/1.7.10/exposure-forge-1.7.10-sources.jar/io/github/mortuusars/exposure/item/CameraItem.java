package io.github.mortuusars.exposure.item;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.block.FlashBlock;
import io.github.mortuusars.exposure.camera.AttachmentSound;
import io.github.mortuusars.exposure.camera.AttachmentType;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.camera.capture.Capture;
import io.github.mortuusars.exposure.camera.capture.CaptureManager;
import io.github.mortuusars.exposure.camera.capture.FileCapture;
import io.github.mortuusars.exposure.camera.capture.ScreenshotCapture;
import io.github.mortuusars.exposure.camera.capture.component.*;
import io.github.mortuusars.exposure.camera.capture.converter.DitheringColorConverter;
import io.github.mortuusars.exposure.camera.capture.converter.SimpleColorConverter;
import io.github.mortuusars.exposure.camera.infrastructure.*;
import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.menu.CameraAttachmentsMenu;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.OnFrameAddedS2CP;
import io.github.mortuusars.exposure.network.packet.client.StartExposureS2CP;
import io.github.mortuusars.exposure.network.packet.server.CameraAddFrameC2SP;
import io.github.mortuusars.exposure.network.packet.server.OpenCameraAttachmentsPacketC2SP;
import io.github.mortuusars.exposure.sound.OnePerPlayerSounds;
import io.github.mortuusars.exposure.sound.OnePerPlayerSoundsClient;
import io.github.mortuusars.exposure.util.CameraInHand;
import io.github.mortuusars.exposure.util.ColorChannel;
import io.github.mortuusars.exposure.util.ItemAndStack;
import io.github.mortuusars.exposure.util.LevelUtil;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundLevelParticlesPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.SlotAccess;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickAction;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.*;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public class CameraItem extends Item {
    public static final AttachmentType FILM_ATTACHMENT = new AttachmentType("Film", 0,
            stack -> stack.m_41720_() instanceof FilmRollItem, AttachmentSound.FILM);
    public static final AttachmentType FLASH_ATTACHMENT = new AttachmentType("Flash", 1,
            stack -> stack.m_204117_(Exposure.Tags.Items.FLASHES), AttachmentSound.FLASH);
    public static final AttachmentType LENS_ATTACHMENT = new AttachmentType("Lens", 2,
            stack -> stack.m_204117_(Exposure.Tags.Items.LENSES), AttachmentSound.LENS);
    public static final AttachmentType FILTER_ATTACHMENT = new AttachmentType("Filter", 3,
            stack -> stack.m_204117_(Exposure.Tags.Items.FILTERS), AttachmentSound.FILTER);

    public static final List<AttachmentType> ATTACHMENTS = List.of(
            FILM_ATTACHMENT,
            FLASH_ATTACHMENT,
            LENS_ATTACHMENT,
            FILTER_ATTACHMENT);

    public static final List<ShutterSpeed> SHUTTER_SPEEDS = List.of(
            new ShutterSpeed("15\""),
            new ShutterSpeed("8\""),
            new ShutterSpeed("4\""),
            new ShutterSpeed("2\""),
            new ShutterSpeed("1\""),
            new ShutterSpeed("2"),
            new ShutterSpeed("4"),
            new ShutterSpeed("8"),
            new ShutterSpeed("15"),
            new ShutterSpeed("30"),
            new ShutterSpeed("60"),
            new ShutterSpeed("125"),
            new ShutterSpeed("250"),
            new ShutterSpeed("500")
    );

    public CameraItem(Properties properties) {
        super(properties);
    }

    @Override
    public int m_8105_(@NotNull ItemStack stack) {
        return 1000;
    }

    public boolean m_142522_(@NotNull ItemStack stack) {
        if (!Config.Client.CAMERA_SHOW_FILM_BAR_ON_ITEM.get())
            return false;
        return getAttachment(stack, FILM_ATTACHMENT)
                .map(f -> f.m_41720_() instanceof FilmRollItem filmRollItem && filmRollItem.m_142522_(f))
                .orElse(false);
    }

    public int m_142158_(@NotNull ItemStack stack) {
        if (!Config.Client.CAMERA_SHOW_FILM_BAR_ON_ITEM.get())
            return 0;
        return getAttachment(stack, FILM_ATTACHMENT)
                .map(f -> f.m_41720_() instanceof FilmRollItem filmRollItem ? filmRollItem.m_142158_(f) : 0)
                .orElse(0);
    }

    public int m_142159_(@NotNull ItemStack stack) {
        if (!Config.Client.CAMERA_SHOW_FILM_BAR_ON_ITEM.get())
            return 0;
        return getAttachment(stack, FILM_ATTACHMENT)
                .map(f -> f.m_41720_() instanceof FilmRollItem filmRollItem ? filmRollItem.m_142159_(f) : 0)
                .orElse(0);
    }

    @Override
    public boolean m_142305_(ItemStack stack, ItemStack otherStack, Slot slot, ClickAction action, Player player, SlotAccess access) {
        if (action != ClickAction.SECONDARY)
            return false;

        if (otherStack.m_41619_() && Config.Common.CAMERA_GUI_RIGHT_CLICK_ATTACHMENTS_SCREEN.get()) {
            if (!(slot.f_40218_ instanceof Inventory)) {
                return false; // Cannot open when not in player's inventory
            }

            if (player.m_7500_() && player.m_9236_().m_5776_()/* && CameraItemClientExtensions.isInCreativeModeInventory()*/) {
                Packets.sendToServer(new OpenCameraAttachmentsPacketC2SP(slot.m_150661_()));
                return true;
            }

            openCameraAttachmentsMenu(player, slot.m_150661_());
            return true;
        }

        if (PlatformHelper.canShear(otherStack) && !isTooltipRemoved(stack)) {
            if (otherStack.m_41763_()) {
                // broadcasting break event is expecting item to be in hand,
                // but making it work for carried items would be too much work for such small feature.
                // No one will ever notice it anyway.
                otherStack.m_41622_(1, player, pl -> pl.m_21190_(InteractionHand.MAIN_HAND));
            }

            if (player.m_9236_().f_46443_)
                player.m_216990_(SoundEvents.f_12344_);

            setTooltipRemoved(stack, true);
            return true;
        }

        if (isTooltipRemoved(stack) && (otherStack.m_41720_() instanceof BookItem || otherStack.m_41720_() instanceof WritableBookItem
                || otherStack.m_41720_() instanceof WrittenBookItem || otherStack.m_41720_() instanceof KnowledgeBookItem)) {
            setTooltipRemoved(stack, false);
            if (player.m_9236_().f_46443_)
                player.m_216990_(SoundEvents.f_12493_);
            return true;
        }

        if (Config.Common.CAMERA_GUI_RIGHT_CLICK_HOTSWAP.get()) {
            for (AttachmentType attachmentType : getAttachmentTypes(stack)) {
                if (attachmentType.matches(otherStack)) {
                    Optional<ItemStack> current = getAttachment(stack, attachmentType);

                    if (otherStack.m_41613_() > 1 && current.isPresent()) {
                        if (player.m_9236_().m_5776_())
                            OnePerPlayerSoundsClient.play(player, Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), SoundSource.PLAYERS, 0.9f, 1f);
                        return true; // Cannot swap when holding more than one item
                    }

                    setAttachment(stack, attachmentType, otherStack.m_41620_(1));
                    access.m_142104_(current.orElse(otherStack));
                    attachmentType.sound().playOnePerPlayer(player, false);
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public void m_7373_(@NotNull ItemStack stack, @Nullable Level level, @NotNull List<Component> components, @NotNull TooltipFlag isAdvanced) {
        if (Config.Client.CAMERA_SHOW_FILM_FRAMES_IN_TOOLTIP.get()) {
            getAttachment(stack, FILM_ATTACHMENT).ifPresent(f -> {
                if (f.m_41720_() instanceof FilmRollItem filmRollItem) {
                    int exposed = filmRollItem.getExposedFramesCount(f);
                    int max = filmRollItem.getMaxFrameCount(f);
                    components.add(Component.m_237110_("item.exposure.camera.tooltip.film_roll_frames", exposed, max));
                }
            });
        }

        if (!isTooltipRemoved(stack) && Config.Client.CAMERA_SHOW_TOOLTIP_DETAILS.get()) {
            boolean rClickAttachments = Config.Common.CAMERA_GUI_RIGHT_CLICK_ATTACHMENTS_SCREEN.get();
            boolean rClickHotswap = Config.Common.CAMERA_GUI_RIGHT_CLICK_HOTSWAP.get();

            if (rClickAttachments || rClickHotswap) {
                if (Screen.m_96638_()) {
                    if (rClickAttachments)
                        components.add(Component.m_237115_("item.exposure.camera.tooltip.details_attachments_screen"));
                    if (rClickHotswap)
                        components.add(Component.m_237115_("item.exposure.camera.tooltip.details_hotswap"));
                    components.add(Component.m_237115_("item.exposure.camera.tooltip.details_remove_tooltip"));
                } else
                    components.add(Component.m_237115_("tooltip.exposure.hold_for_details"));
            }
        }
    }

    public boolean isActive(ItemStack stack) {
        return stack.m_41783_() != null && stack.m_41783_().m_128471_("Active");
    }

    public void setActive(ItemStack stack, boolean active) {
        stack.m_41784_().m_128379_("Active", active);
    }

    public void activate(Player player, ItemStack stack) {
        if (!isActive(stack)) {
            setActive(stack, true);
            player.m_146850_(GameEvent.f_157811_); // Sends skulk vibrations
            playCameraSound(player, Exposure.SoundEvents.VIEWFINDER_OPEN.get(), 0.35f, 0.9f, 0.2f);
        }
    }

    public void deactivate(Player player, ItemStack stack) {
        if (isActive(stack)) {
            setActive(stack, false);
            player.m_146850_(GameEvent.f_157811_); // Sends skulk vibrations
            playCameraSound(player, Exposure.SoundEvents.VIEWFINDER_CLOSE.get(), 0.35f, 0.9f, 0.2f);
        }
    }

    public boolean isInSelfieMode(ItemStack stack) {
        return stack.m_41783_() != null && stack.m_41783_().m_128471_("Selfie");
    }

    public void setSelfieMode(ItemStack stack, boolean selfie) {
        stack.m_41784_().m_128379_("Selfie", selfie);
    }

    public boolean isTooltipRemoved(ItemStack stack) {
        return stack.m_41783_() != null && stack.m_41783_().m_128471_("TooltipRemoved");
    }

    public void setTooltipRemoved(ItemStack stack, boolean removed) {
        stack.m_41784_().m_128379_("TooltipRemoved", removed);
    }

    public void setSelfieModeWithEffects(Player player, ItemStack stack, boolean selfie) {
        if (isInSelfieMode(stack) != selfie) {
            setSelfieMode(stack, selfie);
            player.m_9236_().m_6269_(player, player, Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), SoundSource.PLAYERS, 1f, 1.5f);
        }
    }

    public boolean isShutterOpen(ItemStack stack) {
        return stack.m_41783_() != null && stack.m_41783_().m_128471_("ShutterOpen");
    }

    public void setShutterOpen(Level level, ItemStack stack, ShutterSpeed shutterSpeed, boolean flashHasFired) {
        CompoundTag tag = stack.m_41784_();
        tag.m_128379_("ShutterOpen", true);
        tag.m_128405_("ShutterTicks", Math.max(shutterSpeed.getTicks(), 1));
        tag.m_128356_("ShutterCloseTimestamp", level.m_46467_() + Math.max(shutterSpeed.getTicks(), 1));
        if (flashHasFired)
            tag.m_128379_("FlashHasFired", true);
    }

    public void setShutterClosed(ItemStack stack) {
        @Nullable CompoundTag tag = stack.m_41783_();
        if (tag != null) {
            tag.m_128473_("ShutterOpen");
            tag.m_128473_("ShutterTicks");
            tag.m_128473_("ShutterCloseTimestamp");
            tag.m_128473_("ExposingFrame");
            tag.m_128473_("FlashHasFired");
        }
    }

    public void openShutter(Player player, Level level, ItemStack stack, ShutterSpeed shutterSpeed, boolean flashHasFired) {
        setShutterOpen(player.m_9236_(), stack, shutterSpeed, flashHasFired);

        player.m_146850_(GameEvent.f_223697_);
        playCameraSound(null, player, Exposure.SoundEvents.SHUTTER_OPEN.get(), 0.7f, 1.1f, 0.2f);
        if (shutterSpeed.getMilliseconds() > 500) // More than 1/2
            OnePerPlayerSounds.playForAllClients(player, Exposure.SoundEvents.SHUTTER_TICKING.get(), SoundSource.PLAYERS, 1f, 1f);
    }

    public void closeShutter(Player player, ItemStack stack) {
        long closedAtTimestamp = stack.m_41783_() != null ? stack.m_41783_().m_128454_("ShutterCloseTimestamp") : -1;
        boolean flashHasFired = stack.m_41783_() != null && stack.m_41783_().m_128471_("FlashHasFired");

        setShutterClosed(stack);

        if (player.m_9236_().m_46467_() - closedAtTimestamp < 60) { // Skip effects if shutter "was closed" long ago
            player.m_146850_(GameEvent.f_223697_);
            player.m_36335_().m_41524_(this, flashHasFired ? 10 : 2);
            playCameraSound(player, player, Exposure.SoundEvents.SHUTTER_CLOSE.get(), 0.7f, 1.1f, 0.2f);

            getFilm(stack).ifPresent(f -> {
                float fullness = (float) f.getItem().getExposedFramesCount(f.getStack()) / f.getItem().getMaxFrameCount(f.getStack());
                boolean lastFrame = fullness == 1f;

                if (lastFrame)
                    OnePerPlayerSounds.play(player, Exposure.SoundEvents.FILM_ADVANCE_LAST.get(), SoundSource.PLAYERS, 1f, 1f);
                else {
                    OnePerPlayerSounds.play(player, Exposure.SoundEvents.FILM_ADVANCING.get(), SoundSource.PLAYERS,
                            1f, 0.9f + 0.1f * fullness);
                }
            });
        }
    }

    @SuppressWarnings("unused")
    public void playCameraSound(@NotNull Player player, SoundEvent sound, float volume, float pitch) {
        playCameraSound(player, sound, volume, pitch, 0f);
    }

    public void playCameraSound(@NotNull Player player, SoundEvent sound, float volume, float pitch, float pitchVariety) {
        playCameraSound(player, player, sound, volume, pitch, pitchVariety);
    }

    public void playCameraSound(@Nullable Player player, @NotNull Player originPlayer, SoundEvent sound, float volume, float pitch, float pitchVariety) {
        if (pitchVariety > 0f)
            pitch = pitch - (pitchVariety / 2f) + (originPlayer.m_217043_().m_188501_() * pitchVariety);
        originPlayer.m_9236_().m_6269_(player, originPlayer, sound, SoundSource.PLAYERS, volume, pitch);
    }

    @Override
    public void m_6883_(@NotNull ItemStack stack, @NotNull Level level, @NotNull Entity entity, int slotId, boolean isSelected) {
        if (!(entity instanceof Player player))
            return;

        if (isShutterOpen(stack)) {
            if (stack.m_41783_() != null && stack.m_41783_().m_128441_("ShutterTicks")) {
                int ticks = stack.m_41783_().m_128451_("ShutterTicks");
                if (ticks <= 0)
                    closeShutter(player, stack);
                else {
                    ticks--;
                    stack.m_41783_().m_128405_("ShutterTicks", ticks);
                }
            } else {
                closeShutter(player, stack);
            }
        }

        boolean inOffhand = player.m_21206_().equals(stack);
        boolean inHand = isSelected || inOffhand;

        if (!inHand) {
            deactivate(player, stack);
        }
    }

    @Override
    public @NotNull InteractionResult m_6225_(UseOnContext context) {
        Player player = context.m_43723_();
        if (player != null) {
            InteractionHand hand = context.m_43724_();

            if (hand == InteractionHand.MAIN_HAND && Camera.getCamera(player)
                    .filter(c -> c instanceof CameraInHand<?>)
                    .map(c -> ((CameraInHand<?>) c).getHand() == InteractionHand.OFF_HAND).orElse(false)) {
                return InteractionResult.PASS;
            }

            return useCamera(player, hand);
        }
        return InteractionResult.CONSUME; // To not play attack animation.
    }

    @Override
    public @NotNull InteractionResultHolder<ItemStack> m_7203_(@NotNull Level level, @NotNull Player player, @NotNull InteractionHand hand) {
        if (hand == InteractionHand.MAIN_HAND && Camera.getCamera(player)
                .filter(c -> c instanceof CameraInHand<?>)
                .map(c -> ((CameraInHand<?>) c).getHand() == InteractionHand.OFF_HAND).orElse(false)) {
            return InteractionResultHolder.m_19098_(player.m_21120_(hand));
        }

        useCamera(player, hand);
        return InteractionResultHolder.m_19096_(player.m_21120_(hand));
    }

    public InteractionResult useCamera(Player player, InteractionHand hand) {
        if (player.m_36335_().m_41519_(this))
            return InteractionResult.FAIL;

        ItemStack cameraStack = player.m_21120_(hand);
        if (cameraStack.m_41619_() || cameraStack.m_41720_() != this)
            return InteractionResult.PASS;

        boolean active = isActive(cameraStack);

        if (!active && player.m_36341_()) {
            if (isShutterOpen(cameraStack)) {
                player.m_5661_(Component.m_237115_("item.exposure.camera.camera_attachments.fail.shutter_open")
                        .m_130940_(ChatFormatting.RED), true);
                return InteractionResult.FAIL;
            }

            int cameraSlot = getMatchingSlotInInventory(player.m_150109_(), cameraStack);
            if (cameraSlot < 0)
                return InteractionResult.FAIL;

            openCameraAttachmentsMenu(player, cameraSlot);
            return InteractionResult.SUCCESS;
        }

        if (!active) {
            activate(player, cameraStack);
            player.m_36335_().m_41524_(this, 4);

            if (player.m_9236_().f_46443_) {
                // Release use key after activating. Otherwise, if right click is still held - camera will take a shot
                CameraItemClientExtensions.releaseUseButton();
            }

            return InteractionResult.CONSUME; // Consume to not play animation
        }


        // Taking a shot:

        if (!(player instanceof ServerPlayer))
            return InteractionResult.CONSUME;

        playCameraSound(null, player, Exposure.SoundEvents.CAMERA_RELEASE_BUTTON_CLICK.get(), 0.3f, 1f, 0.1f);

        Optional<ItemAndStack<FilmRollItem>> filmAttachment = getFilm(cameraStack);

        if (filmAttachment.isEmpty())
            return InteractionResult.FAIL;

        ItemAndStack<FilmRollItem> film = filmAttachment.get();
        boolean exposingFilm = film.getItem().canAddFrame(film.getStack());

        if (!exposingFilm)
            return InteractionResult.FAIL;

        if (isShutterOpen(cameraStack))
            return InteractionResult.FAIL;

        int lightLevel = LevelUtil.getLightLevelAt(player.m_9236_(), player.m_20183_());
        boolean shouldFlashFire = shouldFlashFire(player, cameraStack, lightLevel);
        ShutterSpeed shutterSpeed = getShutterSpeed(cameraStack);

        if (PlatformHelper.fireShutterOpeningEvent(player, cameraStack, lightLevel, shouldFlashFire))
            return InteractionResult.FAIL; // Canceled

        boolean flashHasFired = shouldFlashFire && tryUseFlash(player, cameraStack);

        openShutter(player, player.m_9236_(), cameraStack, shutterSpeed, flashHasFired);

        if (player instanceof ServerPlayer serverPlayer) {
            Packets.sendToClient(new StartExposureS2CP(createExposureId(player), hand, flashHasFired, lightLevel), serverPlayer);
        }

        return InteractionResult.CONSUME; // Consume to not play animation
    }

    public void exposeFrameClientside(Player player, InteractionHand hand, String exposureId, boolean flashHasFired, int lightLevel) {
        Preconditions.checkState(player.m_9236_().f_46443_, "Should only be called on client.");

        ItemStack cameraStack = player.m_21120_(hand);

        if (PlatformHelper.fireShutterOpeningEvent(player, cameraStack, lightLevel, flashHasFired))
            return; // Canceled

        boolean projectingFile = hasInterplanarProjectorFilter(cameraStack) && ExposureClient.isShaderActive();

        CompoundTag frame = new CompoundTag();

        if (projectingFile) {
            frame.m_128379_(FrameData.PROJECTED, true);
        }

        // Base properties. It's easier to add them client-side.
        frame.m_128359_(FrameData.ID, exposureId);
        frame.m_128359_(FrameData.TIMESTAMP, Util.m_241986_());

        if (!projectingFile) {
            frame.m_128405_(FrameData.FOCAL_LENGTH, Mth.m_14167_(getFocalLength(cameraStack)));
            frame.m_128405_(FrameData.LIGHT_LEVEL, lightLevel);
            frame.m_128350_(FrameData.SUN_ANGLE, player.m_9236_().m_46490_(0));
            if (flashHasFired)
                frame.m_128379_(FrameData.FLASH, true);
            if (isInSelfieMode(cameraStack))
                frame.m_128379_(FrameData.SELFIE, true);

            if (ExposureClient.isShaderActive()) {
                // Chromatic only for black and white:
                boolean isBW = getAttachment(cameraStack, FILM_ATTACHMENT)
                        .map(f -> f.m_41720_() instanceof IFilmItem filmItem && filmItem.getType() == FilmType.BLACK_AND_WHITE)
                        .orElse(false);
                if (isBW) {
                    getAttachment(cameraStack, FILTER_ATTACHMENT).flatMap(ColorChannel::fromStack).ifPresent(c -> {
                        frame.m_128379_(FrameData.CHROMATIC, true);
                        frame.m_128359_(FrameData.CHROMATIC_CHANNEL, c.m_7912_());
                    });
                }
            }
        }

        List<UUID> entitiesInFrame;

        if (projectingFile) {
            entitiesInFrame = Collections.emptyList();
        } else {
            entitiesInFrame = EntitiesInFrame.get(player, Viewfinder.getCurrentFov(), 12, isInSelfieMode(cameraStack))
                    .stream()
                    .map(Entity::m_20148_)
                    .toList();
        }

        Packets.sendToServer(new CameraAddFrameC2SP(hand, frame, entitiesInFrame));

        startCapture(player, cameraStack, exposureId, flashHasFired);
    }

    protected void startCapture(Player player, ItemStack cameraStack, String exposureId, boolean flashHasFired) {
        Capture capture;

        Optional<ItemAndStack<InterplanarProjectorItem>> projector = getAttachment(cameraStack, FILTER_ATTACHMENT)
                .map(filter -> filter.m_41720_() instanceof InterplanarProjectorItem ? new ItemAndStack<>(filter) : null);

        if (projector.isPresent() && ExposureClient.isShaderActive()) {
            ItemAndStack<InterplanarProjectorItem> filter = projector.get();
            String filepath = filter.getItem().getFilename(filter.getStack()).orElse("");

            capture = createFileCapture(player, cameraStack, exposureId, filepath, filter.getItem().isDithered(filter.getStack()))
                    .onCapturingFailed(() -> {
                        Capture regularCapture = createRegularCapture(player, cameraStack, exposureId, flashHasFired);
                        regularCapture.onImageCaptured(() -> {
                            Minecraft.m_91087_().execute(() -> {
                                player.m_9236_().m_6269_(player, player, Exposure.SoundEvents.INTERPLANAR_PROJECT.get(),
                                        SoundSource.PLAYERS, 0.8f, 0.6f);
                                for (int i = 0; i < 32; ++i) {
                                    player.m_9236_().m_7106_(ParticleTypes.f_123760_, player.m_20185_(), player.m_20186_() + player.m_217043_().m_188500_() * 2.0, player.m_20189_(), player.m_217043_().m_188583_(), 0.0, player.m_217043_().m_188583_());
                                }
                            });
                        });
                        CaptureManager.enqueue(regularCapture);
                    })
                    .onImageCaptured(() -> {
                        Minecraft.m_91087_().execute(() -> {
                            player.m_9236_().m_6269_(player, player, Exposure.SoundEvents.INTERPLANAR_PROJECT.get(),
                                    SoundSource.PLAYERS, 0.8f, 1.1f);
                            for (int i = 0; i < 32; ++i) {
                                player.m_9236_().m_7106_(ParticleTypes.f_123760_, player.m_20185_(), player.m_20186_() + player.m_217043_().m_188500_() * 2.0, player.m_20189_(), player.m_217043_().m_188583_(), 0.0, player.m_217043_().m_188583_());
                            }
                        });
                    });
        } else {
            capture = createRegularCapture(player, cameraStack, exposureId, flashHasFired);
            if (flashHasFired) {
                capture.onImageCaptured(() -> spawnClientsideFlashEffects(player, cameraStack));
            }
        }

        CaptureManager.enqueue(capture);
    }

    protected Capture createRegularCapture(Player player, ItemStack cameraStack, String exposureId, boolean flash) {
        ItemAndStack<FilmRollItem> film = getFilm(cameraStack).orElseThrow();
        int frameSize = film.getItem().getFrameSize(film.getStack());
        float brightnessStops = getShutterSpeed(cameraStack).getStopsDifference(ShutterSpeed.DEFAULT);

        Capture capture = new ScreenshotCapture()
                .setFilmType(film.getItem().getType())
                .setSize(frameSize)
                .setBrightnessStops(brightnessStops)
                .setConverter(new DitheringColorConverter());

        capture.addComponent(new BaseComponent());
        capture.addComponent(new ExposureStorageSaveComponent(exposureId, true));

        if (flash) {
            capture.addComponent(new FlashComponent());
        }
        if (brightnessStops != 0) {
            capture.addComponent(new BrightnessComponent(brightnessStops));
        }
        if (film.getItem().getType() == FilmType.BLACK_AND_WHITE) {
            Optional<ItemStack> filter = getAttachment(cameraStack, FILTER_ATTACHMENT);
            filter.flatMap(ColorChannel::fromStack).ifPresentOrElse(
                    channel -> capture.addComponent(new SelectiveChannelBlackAndWhiteComponent(channel)),
                    () -> capture.addComponent(new BlackAndWhiteComponent()));
        }

        return capture;
    }

    protected Capture createFileCapture(Player player, ItemStack cameraStack, String exposureId,
                                        String filepath, boolean dither) {
        ItemAndStack<FilmRollItem> film = getFilm(cameraStack).orElseThrow();
        FilmType filmType = film.getItem().getType();
        int frameSize = film.getItem().getFrameSize(film.getStack());

        Capture capture = new FileCapture(filepath,
                error -> player.m_5661_(error.getCasualTranslation().m_130940_(ChatFormatting.RED), false))
                .setFilmType(filmType)
                .setSize(frameSize)
                .addComponent(new ExposureStorageSaveComponent(exposureId, true))
                .setConverter(dither ? new DitheringColorConverter() : new SimpleColorConverter())
                .cropFactor(1)
                .setAsyncCapturing(true);

        if (filmType == FilmType.BLACK_AND_WHITE) {
            capture.addComponent(new BlackAndWhiteComponent());
        }

        return capture;
    }

    public void addFrame(ServerPlayer player, ItemStack cameraStack, CompoundTag frameTag, List<Entity> entities) {
        frameTag.m_128359_(FrameData.PHOTOGRAPHER, player.m_6302_());
        frameTag.m_128362_(FrameData.PHOTOGRAPHER_ID, player.m_20148_());

        if (!frameTag.m_128471_(FrameData.PROJECTED)) {
            addFrameData(player, cameraStack, frameTag, entities);
        }

        PlatformHelper.fireModifyFrameDataEvent(player, cameraStack, frameTag, entities);

        player.m_36220_(Exposure.Stats.FILM_FRAMES_EXPOSED);
        Exposure.Advancements.FILM_FRAME_EXPOSED.trigger(player, new ItemAndStack<>(cameraStack), frameTag, entities);

        addFrameToFilm(cameraStack, frameTag);
        onFrameAdded(player, cameraStack, frameTag, entities);
        PlatformHelper.fireFrameAddedEvent(player, cameraStack, frameTag);
        Packets.sendToClient(new OnFrameAddedS2CP(frameTag), player);
    }

    public void onFrameAdded(ServerPlayer player, ItemStack cameraStack, CompoundTag frame, List<Entity> entities) {
        if (frame.m_128471_(FrameData.PROJECTED)) {
            getAttachment(cameraStack, CameraItem.FILTER_ATTACHMENT).ifPresent(filter -> {
                if (!(filter.m_41720_() instanceof InterplanarProjectorItem interplanarProjector)) return;

                player.m_9236_().m_6269_(player, player, Exposure.SoundEvents.INTERPLANAR_PROJECT.get(),
                        SoundSource.PLAYERS, 0.8f, 1f);

                if (interplanarProjector.isConsumable(filter)) {
                    filter.m_41774_(1);
                    setAttachment(cameraStack, CameraItem.FILTER_ATTACHMENT, filter);
                }
            });
        }
    }

    public void addFrameToFilm(ItemStack cameraStack, CompoundTag frame) {
        ItemAndStack<FilmRollItem> film = getFilm(cameraStack)
                .orElseThrow(() -> new IllegalStateException("Camera should have film inserted. " + cameraStack));

        film.getItem().addFrame(film.getStack(), frame);
        setFilm(cameraStack, film.getStack());
    }

    protected boolean shouldFlashFire(Player player, ItemStack cameraStack, int lightLevel) {
        if (getAttachment(cameraStack, FLASH_ATTACHMENT).isEmpty())
            return false;

        return switch (getFlashMode(cameraStack)) {
            case OFF -> false;
            case ON -> true;
            case AUTO -> lightLevel < 8;
        };
    }

    @SuppressWarnings("unused")
    public boolean tryUseFlash(Player player, ItemStack cameraStack) {
        Level level = player.m_9236_();
        BlockPos playerHeadPos = player.m_20183_().m_7494_();
        @Nullable BlockPos flashPos = null;

        if (level.m_8055_(playerHeadPos).m_60795_() || level.m_6425_(playerHeadPos).m_164512_(Fluids.f_76193_))
            flashPos = playerHeadPos;
        else {
            for (Direction direction : Direction.values()) {
                BlockPos pos = playerHeadPos.m_121945_(direction);
                if (level.m_8055_(pos).m_60795_() || level.m_6425_(pos).m_164512_(Fluids.f_76193_)) {
                    flashPos = pos;
                }
            }
        }

        if (flashPos == null)
            return false;

        level.m_7731_(flashPos, Exposure.Blocks.FLASH.get().m_49966_()
                .m_61124_(FlashBlock.WATERLOGGED, level.m_6425_(flashPos)
                        .m_164512_(Fluids.f_76193_)), Block.f_152388_);
        level.m_6269_(null, player, Exposure.SoundEvents.FLASH.get(), SoundSource.PLAYERS, 1f, 1f);

        player.m_146850_(GameEvent.f_157776_);
        player.m_36220_(Exposure.Stats.FLASHES_TRIGGERED);

        // Send particles to other players:
        if (level instanceof ServerLevel serverLevel && player instanceof ServerPlayer serverPlayer) {
            Vec3 pos = player.m_20182_();
            pos = pos.m_82520_(0, 1, 0).m_82549_(player.m_20154_().m_82542_(0.5, 0, 0.5));
            ClientboundLevelParticlesPacket packet = new ClientboundLevelParticlesPacket(ParticleTypes.f_123747_, false,
                    pos.f_82479_, pos.f_82480_, pos.f_82481_, 0, 0, 0, 0, 0);
            for (ServerPlayer pl : serverLevel.m_6907_()) {
                if (!pl.equals(serverPlayer)) {
                    pl.f_8906_.m_9829_(packet);
                    RandomSource r = serverLevel.m_213780_();
                    for (int i = 0; i < 4; i++) {
                        pl.f_8906_.m_9829_(new ClientboundLevelParticlesPacket(ParticleTypes.f_123810_, false,
                                pos.f_82479_ + r.m_188501_() * 0.5f - 0.25f, pos.f_82480_ + r.m_188501_() * 0.5f + 0.2f, pos.f_82481_ + r.m_188501_() * 0.5f - 0.25f,
                                0, 0, 0, 0, 0));
                    }
                }
            }
        }
        return true;
    }

    public void addFrameData(ServerPlayer player, ItemStack cameraStack, CompoundTag frame, List<Entity> entitiesInFrame) {
        Level level = player.m_9236_();

        ListTag pos = new ListTag();
        pos.add(IntTag.m_128679_(player.m_20183_().m_123341_()));
        pos.add(IntTag.m_128679_(player.m_20183_().m_123342_()));
        pos.add(IntTag.m_128679_(player.m_20183_().m_123343_()));
        frame.m_128365_(FrameData.POSITION, pos);

        frame.m_128405_(FrameData.DAYTIME, (int) level.m_46468_());

        frame.m_128359_(FrameData.DIMENSION, player.m_9236_().m_46472_().m_135782_().toString());

        player.m_9236_().m_204166_(player.m_20183_()).m_203543_().map(ResourceKey::m_135782_)
                .ifPresent(biome -> frame.m_128359_(FrameData.BIOME, biome.toString()));

        int surfaceHeight = level.m_6924_(Heightmap.Types.WORLD_SURFACE_WG, player.m_146903_(), player.m_146907_());
        level.m_46465_();
        int skyLight = level.m_45517_(LightLayer.SKY, player.m_20183_());

        if (player.m_5842_())
            frame.m_128379_(FrameData.UNDERWATER, true);

        if (player.m_146904_() < surfaceHeight && skyLight < 2)
            frame.m_128379_(FrameData.IN_CAVE, true);
        else if (!player.m_5842_()) {
            Biome.Precipitation precipitation = level.m_204166_(player.m_20183_()).m_203334_().m_264600_(player.m_20183_());
            if (level.m_46470_() && precipitation != Biome.Precipitation.NONE)
                frame.m_128359_(FrameData.WEATHER, precipitation == Biome.Precipitation.SNOW ? "Snowstorm" : "Thunder");
            else if (level.m_46471_() && precipitation != Biome.Precipitation.NONE)
                frame.m_128359_(FrameData.WEATHER, precipitation == Biome.Precipitation.SNOW ? "Snow" : "Rain");
            else
                frame.m_128359_(FrameData.WEATHER, "Clear");
        }

        addStructuresInfo(player, frame);

        if (!entitiesInFrame.isEmpty()) {
            ListTag entities = new ListTag();

            for (Entity entity : entitiesInFrame) {
                if (entity instanceof EnderMan enderMan && player.equals(enderMan.m_5448_()) && enderMan.m_32534_(player)) {
                    // I wanted to implement this in a predicate,
                    // but it's tricky because EntitySubPredicates do not get the player in their 'match' method.
                    // So it's just easier to hardcode it like this.
                    Exposure.Advancements.PHOTOGRAPH_ENDERMAN_EYES.m_222618_(player);
                }

                CompoundTag entityInfoTag = createEntityInFrameTag(entity, player, cameraStack);
                if (entityInfoTag.m_128456_())
                    continue;

                entities.add(entityInfoTag);

                // Duplicate entity id as a separate field in the tag.
                // Can then be used by FTBQuests nbt matching (it's hard to match from a list), for example.
                frame.m_128379_(entityInfoTag.m_128461_(FrameData.ENTITY_ID), true);
            }

            if (!entities.isEmpty())
                frame.m_128365_(FrameData.ENTITIES_IN_FRAME, entities);
        }
    }

    protected void addStructuresInfo(@NotNull ServerPlayer player, CompoundTag frame) {
        Map<Structure, LongSet> allStructuresAt = player.m_284548_().m_215010_().m_220522_(player.m_20183_());

        List<Structure> inside = new ArrayList<>();

        for (Structure structure : allStructuresAt.keySet()) {
            StructureStart structureAt = player.m_284548_().m_215010_().m_220494_(player.m_20183_(), structure);
            if (structureAt.m_73603_()) {
                inside.add(structure);
            }
        }

        Registry<Structure> structures = player.m_284548_().m_9598_().m_175515_(Registries.f_256944_);
        ListTag structuresTag = new ListTag();

        for (Structure structure : inside) {
            ResourceLocation key = structures.m_7981_(structure);
            if (key != null)
                structuresTag.add(StringTag.m_129297_(key.toString()));
        }

        if (!structuresTag.isEmpty()) {
            frame.m_128365_("Structures", structuresTag);
        }
    }

    protected CompoundTag createEntityInFrameTag(Entity entity, Player photographer, ItemStack cameraStack) {
        CompoundTag tag = new CompoundTag();
        ResourceLocation entityRL = BuiltInRegistries.f_256780_.m_7981_(entity.m_6095_());

        tag.m_128359_(FrameData.ENTITY_ID, entityRL.toString());

        ListTag pos = new ListTag();
        pos.add(IntTag.m_128679_((int) entity.m_20185_()));
        pos.add(IntTag.m_128679_((int) entity.m_20186_()));
        pos.add(IntTag.m_128679_((int) entity.m_20189_()));
        tag.m_128365_(FrameData.ENTITY_POSITION, pos);

        tag.m_128350_(FrameData.ENTITY_DISTANCE, photographer.m_20270_(entity));

        if (entity instanceof Player player)
            tag.m_128359_(FrameData.ENTITY_PLAYER_NAME, player.m_6302_());

        return tag;
    }

    public void openCameraAttachmentsMenu(Player player, int cameraSlotIndex) {
        ItemStack stack = player.m_150109_().m_8020_(cameraSlotIndex);
        Preconditions.checkState(stack.m_41720_() instanceof CameraItem,
                "Cannot open Camera Attachments UI: " + stack + " is not a CameraItem.");

        if (player instanceof ServerPlayer serverPlayer) {
            MenuProvider menuProvider = new MenuProvider() {
                @Override
                public @NotNull Component m_5446_() {
                    return stack.m_41788_() ? stack.m_41786_() : Component.m_237115_("container.exposure.camera");
                }

                @Override
                public @NotNull AbstractContainerMenu m_7208_(int containerId, @NotNull Inventory playerInventory, @NotNull Player player) {
                    return new CameraAttachmentsMenu(containerId, playerInventory, cameraSlotIndex);
                }
            };

            PlatformHelper.openMenu(serverPlayer, menuProvider, buffer -> buffer.writeInt(cameraSlotIndex));
        }
    }

    protected int getMatchingSlotInInventory(Inventory inventory, ItemStack stack) {
        for (int i = 0; i < inventory.m_6643_(); i++) {
            if (inventory.m_8020_(i).equals(stack)) {
                return i;
            }
        }
        return -1;
    }

    protected String createExposureId(Player player) {
        // This method is called only server-side and then gets sent to client in a packet
        // because gameTime is different between client/server, and IDs won't match.
        String playerName = player.m_7755_().getString().replaceAll("[^A-Za-z0-9-_]", "-"); // Filter out problematic chars
        return playerName + "_" + player.m_9236_().m_46467_();
    }

    public FocalRange getFocalRange(ItemStack cameraStack) {
        return getAttachment(cameraStack, LENS_ATTACHMENT).map(FocalRange::ofStack).orElse(getDefaultFocalRange());
    }

    public FocalRange getDefaultFocalRange() {
        return FocalRange.getDefault();
    }

    /**
     * This method is called after we take a screenshot. Otherwise, due to the delays (flash, etc) - particles would be captured as well.
     */
    @SuppressWarnings("unused")
    public void spawnClientsideFlashEffects(@NotNull Player player, ItemStack cameraStack) {
        Preconditions.checkState(player.m_9236_().f_46443_, "This methods should only be called client-side.");
        Level level = player.m_9236_();
        Vec3 pos = player.m_20182_();
        Vec3 lookAngle = player.m_20154_();
        pos = pos.m_82520_(0, 1, 0).m_82549_(lookAngle.m_82542_(0.8f, 0.8f, 0.8f));

        RandomSource r = level.m_213780_();
        for (int i = 0; i < 3; i++) {
            level.m_7106_(ParticleTypes.f_123810_,
                    pos.f_82479_ + r.m_188501_() - 0.5f,
                    pos.f_82480_ + r.m_188501_() + 0.15f,
                    pos.f_82481_ + r.m_188501_() - 0.5f,
                    lookAngle.f_82479_ * 0.025f + r.m_188501_() * 0.025f,
                    lookAngle.f_82480_ * 0.025f + r.m_188501_() * 0.025f,
                    lookAngle.f_82481_ * 0.025f + r.m_188501_() * 0.025f);
        }
    }

    // ---

    @SuppressWarnings("unused")
    public List<AttachmentType> getAttachmentTypes(ItemStack cameraStack) {
        return ATTACHMENTS;
    }

    public Optional<AttachmentType> getAttachmentTypeForSlot(ItemStack cameraStack, int slot) {
        List<AttachmentType> attachmentTypes = getAttachmentTypes(cameraStack);
        for (AttachmentType attachmentType : attachmentTypes) {
            if (attachmentType.slot() == slot)
                return Optional.of(attachmentType);
        }
        return Optional.empty();
    }

    public Optional<ItemAndStack<FilmRollItem>> getFilm(ItemStack cameraStack) {
        return getAttachment(cameraStack, FILM_ATTACHMENT).map(ItemAndStack::new);
    }

    public void setFilm(ItemStack cameraStack, ItemStack filmStack) {
        setAttachment(cameraStack, FILM_ATTACHMENT, filmStack);
    }

    public Optional<ItemStack> getAttachment(ItemStack cameraStack, AttachmentType attachmentType) {
        if (cameraStack.m_41783_() != null && cameraStack.m_41783_().m_128425_(attachmentType.id(), Tag.f_178203_)) {
            ItemStack itemStack = ItemStack.m_41712_(cameraStack.m_41783_().m_128469_(attachmentType.id()));
            if (!itemStack.m_41619_())
                return Optional.of(itemStack);
        }
        return Optional.empty();
    }

    public void setAttachment(ItemStack cameraStack, AttachmentType attachmentType, ItemStack attachmentStack) {
        Preconditions.checkState(attachmentStack.m_41619_() || attachmentType.matches(attachmentStack),
                attachmentStack + " is not valid for the '" + attachmentType + "' attachment type.");

        CompoundTag cameraTag = cameraStack.m_41784_();

        boolean hasChanged = getAttachment(cameraStack, attachmentType)
                .map(stack -> !stack.equals(attachmentStack))
                .orElse(!attachmentStack.m_41619_());

        if (attachmentStack.m_41619_()) {
            cameraTag.m_128473_(attachmentType.id());
        } else {
            cameraTag.m_128365_(attachmentType.id(), attachmentStack.m_41739_(new CompoundTag()));
        }

        if (hasChanged) {
            onAttachmentChanged(cameraStack, attachmentType);
        }
    }

    public void onAttachmentChanged(ItemStack cameraStack, AttachmentType attachmentType) {
        if (attachmentType == LENS_ATTACHMENT) {
            setZoom(cameraStack, getFocalRange(cameraStack).min());
        }
    }

    // ---

    /**
     * Returns all possible Shutter Speeds for this camera.
     */
    @SuppressWarnings("unused")
    public List<ShutterSpeed> getAllShutterSpeeds(ItemStack cameraStack) {
        return SHUTTER_SPEEDS;
    }

    public ShutterSpeed getShutterSpeed(ItemStack cameraStack) {
        return ShutterSpeed.loadOrDefault(cameraStack.m_41784_());
    }

    public void setShutterSpeed(ItemStack cameraStack, ShutterSpeed shutterSpeed) {
        shutterSpeed.save(cameraStack.m_41784_());
    }

    public float getFocalLength(ItemStack cameraStack) {
        return cameraStack.m_41782_() ? cameraStack.m_41784_().m_128457_("Zoom") : getFocalRange(cameraStack).min();
    }

    public void setZoom(ItemStack cameraStack, double focalLength) {
        cameraStack.m_41784_().m_128347_("Zoom", focalLength);
    }

    public CompositionGuide getCompositionGuide(ItemStack cameraStack) {
        if (!cameraStack.m_41782_() || !cameraStack.m_41784_().m_128425_("CompositionGuide", Tag.f_178201_))
            return CompositionGuides.NONE;

        return CompositionGuides.byIdOrNone(cameraStack.m_41784_().m_128461_("CompositionGuide"));
    }

    public void setCompositionGuide(ItemStack cameraStack, CompositionGuide guide) {
        cameraStack.m_41784_().m_128359_("CompositionGuide", guide.getId());
    }

    public FlashMode getFlashMode(ItemStack cameraStack) {
        if (!cameraStack.m_41782_() || !cameraStack.m_41784_().m_128425_("FlashMode", Tag.f_178201_))
            return FlashMode.OFF;

        return FlashMode.byIdOrOff(cameraStack.m_41784_().m_128461_("FlashMode"));
    }

    public void setFlashMode(ItemStack cameraStack, FlashMode flashMode) {
        cameraStack.m_41784_().m_128359_("FlashMode", flashMode.getId());
    }

    public boolean hasInterplanarProjectorFilter(ItemStack cameraStack) {
        return getAttachment(cameraStack, FILTER_ATTACHMENT)
                .map(stack -> stack.m_41720_() instanceof InterplanarProjectorItem)
                .orElse(false);
    }
}
