package io.github.mortuusars.exposure.gui.screen;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.block.entity.Lightroom;
import io.github.mortuusars.exposure.block.entity.LightroomBlockEntity;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.gui.screen.element.ChromaticProcessToggleButton;
import io.github.mortuusars.exposure.item.DevelopedFilmItem;
import io.github.mortuusars.exposure.menu.LightroomMenu;
import io.github.mortuusars.exposure.render.image.RenderedImageProvider;
import io.github.mortuusars.exposure.render.modifiers.ExposurePixelModifiers;
import io.github.mortuusars.exposure.util.ColorChannel;
import io.github.mortuusars.exposure.util.PagingDirection;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public class LightroomScreen extends AbstractContainerScreen<LightroomMenu> {
    public static final ResourceLocation MAIN_TEXTURE = Exposure.resource("textures/gui/lightroom.png");
    public static final ResourceLocation FILM_OVERLAYS_TEXTURE = Exposure.resource("textures/gui/lightroom_film_overlays.png");
    public static final int FRAME_SIZE = 54;

    protected Player player;
    protected Button printButton;
    protected ChromaticProcessToggleButton processToggleButton;

    protected Map<Integer, Rect2i> slotPlaceholders = Collections.emptyMap();

    public LightroomScreen(LightroomMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
        this.player = playerInventory.f_35978_;
    }

    @Override
    protected void m_7856_() {
        f_97726_ = 176;
        f_97727_ = 210;
        super.m_7856_();
        f_97731_ = 116;

        slotPlaceholders = Map.of(
                Lightroom.FILM_SLOT, new Rect2i(238, 0, 18, 18),
                Lightroom.PAPER_SLOT, new Rect2i(238, 18, 18, 18),
                Lightroom.CYAN_SLOT, new Rect2i(238, 36, 18, 18),
                Lightroom.MAGENTA_SLOT, new Rect2i(238, 54, 18, 18),
                Lightroom.YELLOW_SLOT, new Rect2i(238, 72, 18, 18),
                Lightroom.BLACK_SLOT, new Rect2i(238, 90, 18, 18)
        );

        printButton = new ImageButton(f_97735_ + 117, f_97736_ + 89, 22, 22, 176, 17,
                22, MAIN_TEXTURE, 256, 256, this::onPrintButtonPressed,
                Component.m_237115_("gui.exposure.lightroom.print"));

        MutableComponent tooltip = Component.m_237115_("gui.exposure.lightroom.print");
        if (player.m_7500_()) {
            tooltip.m_130946_("\n")
                    .m_7220_(Component.m_237115_("gui.exposure.lightroom.print.creative_tooltip"));
        }

        printButton.m_257544_(Tooltip.m_257550_(tooltip));
        m_142416_(printButton);

        processToggleButton = new ChromaticProcessToggleButton(f_97735_ - 17, f_97736_ + 91,
                this::onProcessToggleButtonPressed, () -> m_6262_().getBlockEntity().getProcess());
        processToggleButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.exposure.lightroom.current_frame")));
        m_142416_(processToggleButton);

        updateButtons();
    }

    protected void onPrintButtonPressed(Button button) {
        if (Minecraft.m_91087_().f_91072_ != null) {
            if (Screen.m_96638_() && player.m_7500_())
                Minecraft.m_91087_().f_91072_.m_105208_(m_6262_().f_38840_, LightroomMenu.PRINT_CREATIVE_BUTTON_ID);
            else
                Minecraft.m_91087_().f_91072_.m_105208_(m_6262_().f_38840_, LightroomMenu.PRINT_BUTTON_ID);
        }
    }

    protected void onProcessToggleButtonPressed(Button button) {
        if (Minecraft.m_91087_().f_91072_ != null)
            Minecraft.m_91087_().f_91072_.m_105208_(m_6262_().f_38840_, LightroomMenu.TOGGLE_PROCESS_BUTTON_ID);
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();

        m_280273_(guiGraphics);
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
        m_280072_(guiGraphics, mouseX, mouseY);
    }

    protected void updateButtons() {
        printButton.f_93623_ = m_6262_().getBlockEntity().canPrint() || (player.m_7500_() && Screen.m_96638_() && m_6262_().getBlockEntity().canPrintInCreativeMode());
        printButton.f_93624_ = !m_6262_().isPrinting();

        processToggleButton.f_93623_ = true;
        processToggleButton.f_93624_ = m_6262_().canChangeProcess();
    }

    @Override
    protected void m_7286_(@NotNull GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShader(GameRenderer::m_172817_);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.m_280218_(MAIN_TEXTURE, f_97735_, f_97736_, 0, 0, f_97726_, f_97727_);
        guiGraphics.m_280218_(MAIN_TEXTURE, f_97735_ - 27, f_97736_ + 35, 0, 209, 28, 31);

        renderSlotPlaceholders(guiGraphics, mouseX, mouseY, partialTick);

        if (m_6262_().isPrinting()) {
            int progress = m_6262_().getData().m_6413_(LightroomBlockEntity.CONTAINER_DATA_PROGRESS_ID);
            int time = m_6262_().getData().m_6413_(LightroomBlockEntity.CONTAINER_DATA_PRINT_TIME_ID);
            int width = progress != 0 && time != 0 ? progress * 24 / time : 0;
            guiGraphics.m_280218_(MAIN_TEXTURE, f_97735_ + 116, f_97736_ + 91, 176, 0, width, 17);
        }

        ListTag frames = m_6262_().getExposedFrames();
        if (frames.isEmpty()) {
            guiGraphics.m_280218_(FILM_OVERLAYS_TEXTURE, f_97735_ + 4, f_97736_ + 15, 0, 136, 168, 68);
            return;
        }

        ItemStack filmStack = m_6262_().m_38853_(Lightroom.FILM_SLOT).m_7993_();
        if (!(filmStack.m_41720_() instanceof DevelopedFilmItem film))
            return;

        FilmType negative = film.getType();

        int selectedFrame = m_6262_().getSelectedFrame();
        @Nullable CompoundTag leftFrame = m_6262_().getFrameIdByIndex(selectedFrame - 1);
        @Nullable CompoundTag centerFrame = m_6262_().getFrameIdByIndex(selectedFrame);
        @Nullable CompoundTag rightFrame = m_6262_().getFrameIdByIndex(selectedFrame + 1);

        RenderSystem.setShaderColor(negative.filmR, negative.filmG, negative.filmB, negative.filmA);

        // Left film part
        guiGraphics.m_280218_(FILM_OVERLAYS_TEXTURE, f_97735_ + 1, f_97736_ + 15, 0, leftFrame != null ? 68 : 0, 54, 68);
        // Center film part
        guiGraphics.m_280218_(FILM_OVERLAYS_TEXTURE, f_97735_ + 55, f_97736_ + 15, 55, rightFrame != null ? 0 : 68, 64, 68);
        // Right film part
        if (rightFrame != null) {
            boolean hasMoreFrames = selectedFrame + 2 < frames.size();
            guiGraphics.m_280218_(FILM_OVERLAYS_TEXTURE, f_97735_ + 119, f_97736_ + 15, 120, hasMoreFrames ? 68 : 0, 56, 68);
        }

        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        PoseStack poseStack = guiGraphics.m_280168_();

        if (leftFrame != null)
            renderFrame(leftFrame, poseStack, f_97735_ + 6, f_97736_ + 22, FRAME_SIZE, isOverLeftFrame(mouseX, mouseY) ? 0.8f : 0.25f, negative);
        if (centerFrame != null)
            renderFrame(centerFrame, poseStack, f_97735_ + 61, f_97736_ + 22, FRAME_SIZE, 0.9f, negative);
        if (rightFrame != null)
            renderFrame(rightFrame, poseStack, f_97735_ + 116, f_97736_ + 22, FRAME_SIZE, isOverRightFrame(mouseX, mouseY) ? 0.8f : 0.25f, negative);

        RenderSystem.setShaderColor(negative.filmR, negative.filmG, negative.filmB, negative.filmA);

        if (m_6262_().getBlockEntity().isAdvancingFrameOnPrint()) {
            poseStack.m_85836_();
            poseStack.m_252880_(0, 0, 800);

            if (selectedFrame < m_6262_().getTotalFrames() - 1)
                guiGraphics.m_280218_(MAIN_TEXTURE, f_97735_ + 111, f_97736_ + 44, 200, 0, 10, 10);
            else
                guiGraphics.m_280218_(MAIN_TEXTURE, f_97735_ + 111, f_97736_ + 44, 210, 0, 10, 10);

            poseStack.m_85849_();
        }

        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    private void renderSlotPlaceholders(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        for (int slotIndex : slotPlaceholders.keySet()) {
            Slot slot = m_6262_().m_38853_(slotIndex);
            if (!slot.m_6657_()) {
                Rect2i placeholder = slotPlaceholders.get(slotIndex);
                guiGraphics.m_280218_(MAIN_TEXTURE, f_97735_ + slot.f_40220_ - 1, f_97736_ + slot.f_40221_ - 1,
                        placeholder.m_110085_(), placeholder.m_110086_(), placeholder.m_110090_(), placeholder.m_110091_());
            }
        }
    }

    @Override
    protected void m_280072_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY) {
        super.m_280072_(guiGraphics, mouseX, mouseY);

        boolean advancedTooltips = Minecraft.m_91087_().f_91066_.f_92125_;
        int selectedFrame = m_6262_().getSelectedFrame();
        List<Component> tooltipLines = new ArrayList<>();

        int hoveredFrameIndex = -1;

        if (isOverLeftFrame(mouseX, mouseY)) {
            hoveredFrameIndex = selectedFrame - 1;
            tooltipLines.add(Component.m_237115_("gui.exposure.lightroom.previous_frame"));
        } else if (isOverCenterFrame(mouseX, mouseY)) {
            hoveredFrameIndex = selectedFrame;
            tooltipLines.add(Component.m_237110_("gui.exposure.lightroom.current_frame", Integer.toString(m_6262_().getSelectedFrame() + 1)));
        } else if (isOverRightFrame(mouseX, mouseY)) {
            hoveredFrameIndex = selectedFrame + 1;
            tooltipLines.add(Component.m_237115_("gui.exposure.lightroom.next_frame"));
        }

        if (hoveredFrameIndex != -1) {
            addFrameInfoTooltipLines(tooltipLines, hoveredFrameIndex, advancedTooltips);
        }

        if (isOverCenterFrame(mouseX, mouseY)) {
            tooltipLines.add(Component.m_237115_("gui.exposure.lightroom.zoom_in.tooltip"));
        }

        guiGraphics.m_280677_(Minecraft.m_91087_().f_91062_, tooltipLines, Optional.empty(), mouseX, mouseY);
    }

    private void addFrameInfoTooltipLines(List<Component> tooltipLines, int frameIndex, boolean isAdvancedTooltips) {
        @Nullable CompoundTag frame = m_6262_().getFrameIdByIndex(frameIndex);
        if (frame != null) {
            ColorChannel.fromString(frame.m_128461_(FrameData.CHROMATIC_CHANNEL)).ifPresent(c ->
                    tooltipLines.add(Component.m_237115_("gui.exposure.channel." + c.m_7912_())
                        .m_130948_(Style.f_131099_.m_178520_(c.getRepresentationColor()))));

            if (isAdvancedTooltips) {
                Either<String, ResourceLocation> idOrTexture = FrameData.getIdOrTexture(frame);
                MutableComponent component = idOrTexture.map(
                                id -> !id.isEmpty() ? Component.m_237110_("gui.exposure.frame.id",
                                        Component.m_237113_(id).m_130940_(ChatFormatting.GRAY)) : Component.m_237119_(),
                                texture -> Component.m_237110_("gui.exposure.frame.texture",
                                        Component.m_237113_(texture.toString()).m_130940_(ChatFormatting.GRAY)))
                        .m_130940_(ChatFormatting.DARK_GRAY);
                tooltipLines.add(component);
            }
        }
    }

    private boolean isOverLeftFrame(int mouseX, int mouseY) {
        ListTag frames = m_6262_().getExposedFrames();
        int selectedFrame = m_6262_().getSelectedFrame();
        return selectedFrame - 1 >= 0 && selectedFrame - 1 < frames.size() && m_6774_(6, 22, FRAME_SIZE, FRAME_SIZE, mouseX, mouseY);
    }

    private boolean isOverCenterFrame(int mouseX, int mouseY) {
        ListTag frames = m_6262_().getExposedFrames();
        int selectedFrame = m_6262_().getSelectedFrame();
        return selectedFrame >= 0 && selectedFrame < frames.size() && m_6774_(61, 22, FRAME_SIZE, FRAME_SIZE, mouseX, mouseY);
    }

    private boolean isOverRightFrame(int mouseX, int mouseY) {
        ListTag frames = m_6262_().getExposedFrames();
        int selectedFrame = m_6262_().getSelectedFrame();
        return selectedFrame + 1 >= 0 && selectedFrame + 1 < frames.size() && m_6774_(116, 22, FRAME_SIZE, FRAME_SIZE, mouseX, mouseY);
    }

    public void renderFrame(@Nullable CompoundTag frame, PoseStack poseStack, float x, float y, float size, float alpha, FilmType negative) {
        if (frame == null)
            return;

        poseStack.m_85836_();
        poseStack.m_252880_(x, y, 0);

        MultiBufferSource.BufferSource bufferSource = MultiBufferSource.m_109898_(Tesselator.m_85913_().m_85915_());
        ExposureClient.getExposureRenderer().render(RenderedImageProvider.fromFrame(frame),
                ExposurePixelModifiers.NEGATIVE_FILM, poseStack, bufferSource, 0, 0, size, size, LightTexture.f_173040_,
                negative.frameR, negative.frameG, negative.frameB, Mth.m_14045_((int) Math.ceil(alpha * 255), 0, 255));
        bufferSource.m_109911_();

        poseStack.m_85849_();
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        Preconditions.checkState(f_96541_ != null);
        Preconditions.checkState(f_96541_.f_91072_ != null);

        if (f_96541_.f_91066_.f_92086_.m_90832_(keyCode, scanCode) || keyCode == InputConstants.f_166330_) {
            changeFrame(PagingDirection.PREVIOUS);
            return true;
        } else if (f_96541_.f_91066_.f_92088_.m_90832_(keyCode, scanCode) || keyCode == InputConstants.f_166331_) {
            changeFrame(PagingDirection.NEXT);
            return true;
        }

        return super.m_7933_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_6050_(double mouseX, double mouseY, double delta) {
        boolean handled = super.m_6050_(mouseX, mouseY, delta);

        if (!handled) {
            if (delta >= 0.0 && isOverCenterFrame((int) mouseX, (int) mouseY)) // Scroll Up
                enterFrameInspectMode();
        }

        return handled;
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        if (button == 0) {
            Preconditions.checkState(f_96541_ != null);
            Preconditions.checkState(f_96541_.f_91072_ != null);

            if (isOverCenterFrame((int) mouseX, (int) mouseY)) {
                enterFrameInspectMode();
                return true;
            }

            if (isOverLeftFrame((int) mouseX, (int) mouseY)) {
                changeFrame(PagingDirection.PREVIOUS);
                return true;
            }

            if (isOverRightFrame((int) mouseX, (int) mouseY)) {
                changeFrame(PagingDirection.NEXT);
                return true;
            }
        }

        return super.m_6375_(mouseX, mouseY, button);
    }

    public void changeFrame(PagingDirection navigation) {
        if ((navigation == PagingDirection.PREVIOUS && m_6262_().getSelectedFrame() == 0)
                || (navigation == PagingDirection.NEXT && m_6262_().getSelectedFrame() == m_6262_().getTotalFrames() - 1))
            return;

        Preconditions.checkState(f_96541_ != null);
        Preconditions.checkState(f_96541_.f_91074_ != null);
        Preconditions.checkState(f_96541_.f_91072_ != null);
        int buttonId = navigation == PagingDirection.NEXT ? LightroomMenu.NEXT_FRAME_BUTTON_ID : LightroomMenu.PREVIOUS_FRAME_BUTTON_ID;
        f_96541_.f_91072_.m_105208_(m_6262_().f_38840_, buttonId);
        player.m_5496_(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), 1f, f_96541_.f_91074_.m_9236_()
                .m_213780_().m_188501_() * 0.4f + 0.8f);

        // Update block entity clientside to faster update advance frame arrows:
        m_6262_().getBlockEntity().setSelectedFrame(m_6262_().getBlockEntity().getSelectedFrameIndex() + (navigation == PagingDirection.NEXT ? 1 : -1));
    }

    private void enterFrameInspectMode() {
        Minecraft.m_91087_().m_91152_(new FilmFrameInspectScreen(this, m_6262_()));
        player.m_5496_(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), 1f, 1.3f);
    }

    @Override
    protected boolean m_7467_(double mouseX, double mouseY, int guiLeft, int guiTop, int mouseButton) {
        return super.m_7467_(mouseX, mouseY, guiLeft, guiTop, mouseButton)
                && f_97734_ == null;
    }
}
