package io.github.mortuusars.exposure.item;

import io.github.mortuusars.exposure.PlatformHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.AnimationUtils;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public class CameraItemClientExtensions {
    public static void applyDefaultHoldingPose(HumanoidModel<?> model, LivingEntity entity, HumanoidArm arm) {
        if (PlatformHelper.isModLoaded("realcamera")) {
            return;
        }

        model.f_102808_.f_104203_ += 0.4f; // If we turn head down completely - arms will be too low.
        if (arm == HumanoidArm.RIGHT) {
            AnimationUtils.m_102097_(model.f_102811_, model.f_102812_, model.f_102808_, true);
        } else if (arm == HumanoidArm.LEFT) {
            AnimationUtils.m_102097_(model.f_102811_, model.f_102812_, model.f_102808_, false);
        }
        model.f_102808_.f_104203_ += 0.3f;
    }

    public static void applySelfieHoldingPose(HumanoidModel<?> model, LivingEntity entity, HumanoidArm arm, boolean undoArmBobbing) {
        ModelPart cameraArm = arm == HumanoidArm.RIGHT ? model.f_102811_ : model.f_102812_;

        // Arm follows camera:
        cameraArm.f_104203_ = (model.f_102808_.f_104203_ + Math.abs(model.f_102808_.f_104203_ * 0.13f)) + (-(float) Math.PI / 2F);
        cameraArm.f_104204_ = model.f_102808_.f_104204_ + (arm == HumanoidArm.RIGHT ? -0.25f : 0.25f);
        if (model.f_102808_.f_104203_ <= 0) {
            cameraArm.f_104205_ = -(model.f_102808_.f_104203_ * 0.15f);
        } else {
            cameraArm.f_104205_ = -(model.f_102808_.f_104203_ * 0.22f);
        }

        if (undoArmBobbing) {
            AnimationUtils.m_170341_(cameraArm, entity.f_19797_ + Minecraft.m_91087_().m_91296_(),
                    arm == HumanoidArm.LEFT ? 1.0F : -1.0F);
        }
    }

    public static float itemPropertyFunction(ItemStack stack, ClientLevel clientLevel, LivingEntity livingEntity, int seed) {
        if (stack.m_41720_() instanceof CameraItem cameraItem) {
            if (cameraItem.isActive(stack)) {
                if (cameraItem.isInSelfieMode(stack))
                    return livingEntity == Minecraft.m_91087_().f_91074_ ? 0.2f : 0.3f;

                return 0.1f;
            }
        }

        return 0f;
    }

    public static void releaseUseButton() {
        Minecraft.m_91087_().f_91066_.f_92095_.m_7249_(false);
    }
}
