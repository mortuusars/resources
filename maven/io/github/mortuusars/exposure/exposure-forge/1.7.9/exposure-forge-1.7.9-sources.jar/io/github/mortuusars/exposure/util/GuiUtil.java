package io.github.mortuusars.exposure.util;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;

public class GuiUtil {
    public static void blit(PoseStack poseStack, float minX, float maxX, float minY, float maxY, float blitOffset, float minU, float maxU, float minV, float maxV) {
        Matrix4f matrix = poseStack.m_85850_().m_252922_();
        RenderSystem.setShader(GameRenderer::m_172817_);
        BufferBuilder bufferbuilder = Tesselator.m_85913_().m_85915_();
        bufferbuilder.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85817_);
        bufferbuilder.m_252986_(matrix, minX, maxY, blitOffset).m_7421_(minU, maxV).m_5752_();
        bufferbuilder.m_252986_(matrix, maxX, maxY, blitOffset).m_7421_(maxU, maxV).m_5752_();
        bufferbuilder.m_252986_(matrix, maxX, minY, blitOffset).m_7421_(maxU, minV).m_5752_();
        bufferbuilder.m_252986_(matrix, minX, minY, blitOffset).m_7421_(minU, minV).m_5752_();
        BufferUploader.m_231202_(bufferbuilder.m_231175_());
    }

    public static void blit(PoseStack poseStack, float x, float y, float width, float height, int u, int v, int textureWidth, int textureHeight, float blitOffset) {
        blit(poseStack, x, x + width, y, y + height, blitOffset,
                (u + 0.0F) / (float)textureWidth, (u + width) / (float)textureWidth, (v + 0.0F) / (float)textureHeight, (v + height) / (float)textureHeight);
    }
}
