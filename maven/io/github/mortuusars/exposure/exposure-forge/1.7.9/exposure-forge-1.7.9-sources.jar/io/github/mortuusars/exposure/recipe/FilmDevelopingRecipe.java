package io.github.mortuusars.exposure.recipe;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.core.NonNullList;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PotionItem;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.ShapedRecipe;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public class FilmDevelopingRecipe extends AbstractNbtTransferringRecipe {
    public FilmDevelopingRecipe(ResourceLocation id, Ingredient filmIngredient, NonNullList<Ingredient> ingredients, ItemStack result) {
        super(id, filmIngredient, ingredients, result);
    }

    @Override
    public @NotNull RecipeSerializer<?> m_7707_() {
        return Exposure.RecipeSerializers.FILM_DEVELOPING.get();
    }

    @Override
    public @NotNull NonNullList<ItemStack> getRemainingItems(@NotNull CraftingContainer container) {
        NonNullList<ItemStack> remainingItems = super.m_7457_(container);

        for (int i = 0; i < container.m_6643_(); ++i) {
            ItemStack item = container.m_8020_(i);
            if (item.m_41720_() instanceof PotionItem) {
                remainingItems.set(i, new ItemStack(Items.f_42590_));
            }
            else if (item.m_41720_().m_41470_()) {
                remainingItems.set(i, new ItemStack(Objects.requireNonNull(item.m_41720_().m_41469_())));
            }
        }

        return remainingItems;
    }

    public static class Serializer implements RecipeSerializer<FilmDevelopingRecipe> {
        @Override
        public @NotNull FilmDevelopingRecipe m_6729_(ResourceLocation recipeId, JsonObject serializedRecipe) {
            Ingredient filmIngredient = Ingredient.m_43917_(GsonHelper.m_289747_(serializedRecipe, "film"));
            NonNullList<Ingredient> ingredients = getIngredients(GsonHelper.m_13933_(serializedRecipe, "ingredients"));
            ItemStack result = ShapedRecipe.m_151274_(GsonHelper.m_13930_(serializedRecipe, "result"));

            if (filmIngredient.m_43947_())
                throw new JsonParseException("Recipe should have 'film' ingredient.");

            return new FilmDevelopingRecipe(recipeId, filmIngredient, ingredients, result);
        }

        @Override
        public @NotNull FilmDevelopingRecipe m_8005_(ResourceLocation recipeId, FriendlyByteBuf buffer) {
            Ingredient transferredIngredient = Ingredient.m_43940_(buffer);
            int ingredientsCount = buffer.m_130242_();
            NonNullList<Ingredient> ingredients = NonNullList.m_122780_(ingredientsCount, Ingredient.f_43901_);
            ingredients.replaceAll(ignored -> Ingredient.m_43940_(buffer));
            ItemStack result = buffer.m_130267_();

            return new FilmDevelopingRecipe(recipeId, transferredIngredient, ingredients, result);
        }

        @Override
        public void toNetwork(FriendlyByteBuf buffer, FilmDevelopingRecipe recipe) {
            recipe.getTransferIngredient().m_43923_(buffer);
            buffer.m_130130_(recipe.m_7527_().size());
            for (Ingredient ingredient : recipe.m_7527_()) {
                ingredient.m_43923_(buffer);
            }
            buffer.m_130055_(recipe.getResult());
        }

        private NonNullList<Ingredient> getIngredients(JsonArray jsonArray) {
            NonNullList<Ingredient> ingredients = NonNullList.m_122779_();

            for (int i = 0; i < jsonArray.size(); ++i) {
                Ingredient ingredient = Ingredient.m_43917_(jsonArray.get(i));
                if (!ingredient.m_43947_())
                    ingredients.add(ingredient);
            }

            if (ingredients.isEmpty())
                throw new JsonParseException("No ingredients for a recipe.");
            else if (ingredients.size() > 3 * 3)
                throw new JsonParseException("Too many ingredients for a recipe. The maximum is 9.");
            return ingredients;
        }
    }
}
