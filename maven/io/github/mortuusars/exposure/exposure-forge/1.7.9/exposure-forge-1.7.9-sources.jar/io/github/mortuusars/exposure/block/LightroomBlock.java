package io.github.mortuusars.exposure.block;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.block.entity.Lightroom;
import io.github.mortuusars.exposure.block.entity.LightroomBlockEntity;
import io.github.mortuusars.exposure.item.StackedPhotographsItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class LightroomBlock extends Block implements EntityBlock {
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.f_54117_;
    public static final BooleanProperty LIT = RedstoneTorchBlock.f_55674_;

    public LightroomBlock(Properties properties) {
        super(properties);
        this.m_49959_(this.f_49792_.m_61090_().m_61124_(FACING, Direction.NORTH).m_61124_(LIT, false));
    }

    @Override
    protected void m_7926_(StateDefinition.Builder<Block, BlockState> pBuilder) {
        pBuilder.m_61104_(FACING, LIT);
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext pContext) {
        return this.m_49966_().m_61124_(FACING, pContext.m_8125_().m_122424_());
    }

    @Override
    public void m_6402_(@NotNull Level pLevel, @NotNull BlockPos pPos, @NotNull BlockState pState, LivingEntity pPlacer, ItemStack pStack) {
        if (pStack.m_41788_()) {
            BlockEntity blockentity = pLevel.m_7702_(pPos);
            if (blockentity instanceof LightroomBlockEntity lightroomBlockEntity)
                lightroomBlockEntity.m_58638_(pStack.m_41786_());
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void m_6810_(BlockState state, @NotNull Level level, @NotNull BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.m_60713_(newState.m_60734_())) {
            if (level.m_7702_(pos) instanceof LightroomBlockEntity lightroomBlockEntity) {
                if (level instanceof ServerLevel serverLevel) {
                    Containers.m_19002_(serverLevel, pos, lightroomBlockEntity);
                    lightroomBlockEntity.dropStoredExperience(null);
                }

                level.m_46717_(pos, this);
            }

            super.m_6810_(state, level, pos, newState, isMoving);
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public boolean m_7278_(@NotNull BlockState state) {
        return true;
    }

    @SuppressWarnings("deprecation")
    @Override
    public int m_6782_(@NotNull BlockState blockState, Level level, @NotNull BlockPos pos) {
        if (!(level.m_7702_(pos) instanceof LightroomBlockEntity lightroomBlockEntity)) {
            return 0;
        }

        ItemStack resultStack = lightroomBlockEntity.m_8020_(Lightroom.RESULT_SLOT);

        if (resultStack.m_41619_()) {
            return 0;
        }

        if (resultStack.m_41720_() instanceof StackedPhotographsItem stackedPhotographsItem) {
            int photographsCount = stackedPhotographsItem.getPhotographsCount(resultStack);
            return (int) ((photographsCount / (float) stackedPhotographsItem.getStackLimit() * 14) + 1);
        }
        else {
            return 1;
        }
    }


    @SuppressWarnings("deprecation")
    @Override
    public @NotNull BlockState m_6843_(BlockState pState, Rotation pRotation) {
        return pState.m_61124_(FACING, pRotation.m_55954_(pState.m_61143_(FACING)));
    }

    @SuppressWarnings("deprecation")
    @Override
    public @NotNull BlockState m_6943_(BlockState pState, Mirror pMirror) {
        return pState.m_60717_(pMirror.m_54846_(pState.m_61143_(FACING)));
    }

    @SuppressWarnings("deprecation")
    @Override
    public @NotNull InteractionResult m_6227_(@NotNull BlockState blockState, Level level, @NotNull BlockPos pos, @NotNull Player player, @NotNull InteractionHand hand, @NotNull BlockHitResult hitResult) {
        if (!(level.m_7702_(pos) instanceof LightroomBlockEntity lightroomBlockEntity))
            return InteractionResult.FAIL;

        player.m_36220_(Exposure.Stats.INTERACT_WITH_LIGHTROOM);

        if (player instanceof ServerPlayer serverPlayer) {
            lightroomBlockEntity.setLastPlayer(serverPlayer);
            lightroomBlockEntity.m_6596_(); // Updates state for client. Without this GUI buttons have some problems. (PrintButton active state)
            PlatformHelper.openMenu(serverPlayer, lightroomBlockEntity, buffer -> buffer.m_130064_(pos));
        }

        return InteractionResult.m_19078_(level.f_46443_);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void m_6861_(@NotNull BlockState state, Level level, @NotNull BlockPos pos, @NotNull Block block, @NotNull BlockPos fromPos, boolean pIsMoving) {
        if (!level.f_46443_) {
            if (!state.m_61143_(LIT)) {
                for (Direction direction : Direction.values()) {
                    BlockPos relative = pos.m_121945_(direction);
                    if (relative.equals(fromPos) && level.m_277185_(relative, direction) > 0
                            && level.m_7702_(pos) instanceof LightroomBlockEntity lightroomBlockEntity) {
                        lightroomBlockEntity.startPrintingProcess(true);
                        return;
                    }
                }
            }
        }
    }

    @Nullable
    @Override
    public BlockEntity m_142194_(BlockPos pos, BlockState state) {
        return createBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> m_142354_(Level level, BlockState state, BlockEntityType<T> blockEntityType) {
        return getBlockTicker(level, state, blockEntityType);
    }

    public static BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new LightroomBlockEntity(pos, state);
    }

    @SuppressWarnings("unused")
    public static <T extends BlockEntity> BlockEntityTicker<T> getBlockTicker(Level level, BlockState state, BlockEntityType<T> blockEntityType) {
        if (!level.f_46443_ && blockEntityType.equals(Exposure.BlockEntityTypes.LIGHTROOM.get()))
            return LightroomBlockEntity::serverTick;

        return null;
    }
}
