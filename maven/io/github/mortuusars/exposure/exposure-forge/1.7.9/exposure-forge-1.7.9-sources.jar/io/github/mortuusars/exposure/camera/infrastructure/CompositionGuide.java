package io.github.mortuusars.exposure.camera.infrastructure;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;

@SuppressWarnings("ClassCanBeRecord")
public class CompositionGuide {
    private final String id;

    public CompositionGuide(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public Component translate() {
        return Component.m_237115_("gui." + Exposure.ID + ".composition_guide." + id);
    }

    public void toBuffer(FriendlyByteBuf buffer) {
        buffer.m_130070_(id);
    }

    public static CompositionGuide fromBuffer(FriendlyByteBuf buffer) {
        return CompositionGuides.byIdOrNone(buffer.m_130277_());
    }
}
