package io.github.mortuusars.exposure.gui.screen.album;

import io.github.mortuusars.exposure.gui.screen.element.textbox.TextBox;
import io.github.mortuusars.exposure.menu.AlbumMenu;
import io.github.mortuusars.exposure.menu.LecternAlbumMenu;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerListener;
import net.minecraft.world.item.ItemStack;

public class LecternAlbumScreen extends AlbumScreen {
    private final LecternAlbumMenu menu;

    private final ContainerListener listener = new ContainerListener() {
        public void m_7934_(AbstractContainerMenu containerToSend, int dataSlotIndex, ItemStack stack) { }

        public void m_142153_(AbstractContainerMenu containerMenu, int dataSlotIndex, int value) {
            if (dataSlotIndex == 1) {
                m_6262_().setCurrentSpreadIndex(value);
                pager.setPage(value);
                for (Page page : pages) {
                    page.noteWidget
                            .ifLeft(TextBox::setCursorToEnd)
                            .ifRight(textBlock -> textBlock.m_93666_(getNoteComponent(page.side)));
                }
            }
        }
    };

    public LecternAlbumScreen(AlbumMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
        this.menu = (LecternAlbumMenu) menu;
        menu.m_38893_(listener);
    }

    @Override
    protected void m_7856_() {
        super.m_7856_();

        if (player.m_36326_()) {
            m_142416_(Button.m_253074_(CommonComponents.f_130655_, b -> this.m_7379_())
                    .m_252987_(this.f_96543_ / 2 - 100, f_97736_ + 196, 98, 20).m_253136_());
            m_142416_(Button.m_253074_(Component.m_237115_("lectern.take_book"), b -> sendButtonClick(LecternAlbumMenu.TAKE_BOOK_BUTTON))
                    .m_252987_(this.f_96543_ / 2 + 2, f_97736_ + 196, 98, 20).m_253136_());
        }
    }

    public void m_7861_() {
        super.m_7861_();
        this.menu.m_38943_(this.listener);
    }
}
