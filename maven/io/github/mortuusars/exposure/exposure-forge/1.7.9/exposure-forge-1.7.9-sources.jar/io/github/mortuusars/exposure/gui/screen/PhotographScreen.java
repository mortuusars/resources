package io.github.mortuusars.exposure.gui.screen;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.data.storage.ClientsideExposureExporter;
import io.github.mortuusars.exposure.gui.screen.element.Pager;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.render.PhotographRenderProperties;
import io.github.mortuusars.exposure.render.PhotographRenderer;
import io.github.mortuusars.exposure.util.ClientsideWorldNameGetter;
import io.github.mortuusars.exposure.util.ItemAndStack;
import io.github.mortuusars.exposure.util.PagingDirection;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class PhotographScreen extends ZoomableScreen {
    public static final ResourceLocation WIDGETS_TEXTURE = Exposure.resource("textures/gui/widgets.png");

    private final List<ItemAndStack<PhotographItem>> photographs;
    private final List<String> savedExposures = new ArrayList<>();

    private final Pager pager = new Pager(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get());

    public PhotographScreen(List<ItemAndStack<PhotographItem>> photographs) {
        super(Component.m_237119_());
        Preconditions.checkState(!photographs.isEmpty(), "No photographs to display.");
        this.photographs = photographs;

        if (shouldQueryAllPhotographsImmediately()) {
            queryAllPhotographs(photographs);
        }
    }

    protected boolean shouldQueryAllPhotographsImmediately() {
        return true;
    }

    protected void queryAllPhotographs(List<ItemAndStack<PhotographItem>> photographs) {
        for (ItemAndStack<PhotographItem> photograph : photographs) {
            FrameData.getIdOrTexture(photograph.getStack())
                    .left()
                    .ifPresent(id -> {
                        if (!id.isBlank()) {
                            ExposureClient.getExposureStorage().getOrQuery(id);
                        }
                    });
        }
    }

    @Override
    public boolean m_7043_() {
        return false;
    }

    @Override
    protected void m_7856_() {
        super.m_7856_();
        zoomFactor = (float) f_96544_ / ExposureClient.getExposureRenderer().getSize();

        ImageButton previousButton = new ImageButton(0, (int) (f_96544_ / 2f - 16 / 2f), 16, 16,
                0, 0, 16, WIDGETS_TEXTURE, 256, 256,
                button -> pager.changePage(PagingDirection.PREVIOUS), Component.m_237115_("gui.exposure.previous_page"));
        m_142416_(previousButton);

        ImageButton nextButton = new ImageButton(f_96543_ - 16, (int) (f_96544_ / 2f - 16 / 2f), 16, 16,
                16, 0, 16, WIDGETS_TEXTURE, 256, 256,
                button -> pager.changePage(PagingDirection.NEXT), Component.m_237115_("gui.exposure.next_page"));
        m_142416_(nextButton);

        pager.init(photographs.size(), true, previousButton, nextButton);
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        pager.update();

        m_280273_(guiGraphics);

        guiGraphics.m_280168_().m_85836_();
        guiGraphics.m_280168_().m_252880_(0, 0, 500); // Otherwise exposure will overlap buttons
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
        guiGraphics.m_280168_().m_85849_();

        guiGraphics.m_280168_().m_85836_();

        guiGraphics.m_280168_().m_252880_(x, y, 0);
        guiGraphics.m_280168_().m_252880_(f_96543_ / 2f, f_96544_ / 2f, 0);
        guiGraphics.m_280168_().m_85841_(scale, scale, scale);
        guiGraphics.m_280168_().m_252880_(ExposureClient.getExposureRenderer().getSize() / -2f, ExposureClient.getExposureRenderer().getSize() / -2f, 0);

        MultiBufferSource.BufferSource bufferSource = MultiBufferSource.m_109898_(Tesselator.m_85913_().m_85915_());

        ArrayList<ItemAndStack<PhotographItem>> photos = new ArrayList<>(photographs);
        Collections.rotate(photos, -pager.getCurrentPage());
        PhotographRenderer.renderStackedPhotographs(photos, guiGraphics.m_280168_(), bufferSource, LightTexture.f_173040_, 255, 255, 255, 255);

        bufferSource.m_109911_();

        guiGraphics.m_280168_().m_85849_();

        ItemAndStack<PhotographItem> photograph = photographs.get(pager.getCurrentPage());

        if (f_96541_.f_91074_ != null && f_96541_.f_91074_.m_7500_() && FrameData.hasIdOrTexture(photograph.getStack())) {
            guiGraphics.m_280488_(f_96547_, "?", f_96543_ - f_96547_.m_92895_("?") - 10, 10, 0xFFFFFFFF);

            if (mouseX > f_96543_ - 20 && mouseX < f_96543_ && mouseY < 20) {
                Either<String, ResourceLocation> idOrTexture = FrameData.getIdOrTexture(photograph.getStack());

                List<Component> lines = new ArrayList<>();

                String exposureName = idOrTexture.map(id -> id, ResourceLocation::toString);
                lines.add(Component.m_237113_(exposureName));

                lines.add(Component.m_237110_("gui.exposure.photograph_screen.drop_as_item_tooltip", Component.m_237113_("CTRL + I")));

                lines.add(idOrTexture.map(
                        id -> Component.m_237110_("gui.exposure.photograph_screen.copy_id_tooltip", "CTRL + C"),
                        texture -> Component.m_237110_("gui.exposure.photograph_screen.copy_texture_path_tooltip", "CTRL + C")));

                guiGraphics.m_280677_(f_96547_, lines, Optional.empty(), mouseX, mouseY + 20);
            }
        }

        if (Config.Client.SAVE_EXPOSURE_TO_FILE_WHEN_VIEWED.get())
            trySaveToFile(photograph);
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        LocalPlayer player = Minecraft.m_91087_().f_91074_;
        ItemAndStack<PhotographItem> photograph = photographs.get(pager.getCurrentPage());
        if (Screen.m_96637_() && player != null && player.m_7500_() && FrameData.hasIdOrTexture(photograph.getStack())) {
            if (keyCode == InputConstants.f_166365_) {
                Either<String, ResourceLocation> idOrTexture = FrameData.getIdOrTexture(photograph.getStack());
                String text = idOrTexture.map(id -> id, ResourceLocation::toString);
                Minecraft.m_91087_().f_91068_.m_90911_(text);
                player.m_5661_(Component.m_237110_("gui.exposure.photograph_screen.copied_message", text), false);
                return true;
            }

            if (keyCode == InputConstants.f_166371_) {
                if (Minecraft.m_91087_().f_91072_ != null) {
                    Minecraft.m_91087_().f_91072_.m_105239_(photograph.getStack().m_41777_());
                    player.m_5661_(Component.m_237110_("gui.exposure.photograph_screen.item_dropped_message",
                            photograph.getStack().toString()), false);
                }
                return true;
            }
        }

        return pager.handleKeyPressed(keyCode, scanCode, modifiers) || super.m_7933_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_7920_(int keyCode, int scanCode, int modifiers) {
        return pager.handleKeyReleased(keyCode, scanCode, modifiers) || super.m_7920_(keyCode, scanCode, modifiers);
    }

    private void trySaveToFile(ItemAndStack<PhotographItem> photograph) {
        if (Minecraft.m_91087_().f_91074_ == null || photograph.getStack().m_41783_() == null)
            return;

        CompoundTag tag = photograph.getStack().m_41783_();
        if (tag == null
                || Minecraft.m_91087_().f_91074_ == null
                || !tag.m_128425_(FrameData.PHOTOGRAPHER_ID, Tag.f_178204_)
                || !tag.m_128342_(FrameData.PHOTOGRAPHER_ID).equals(Minecraft.m_91087_().f_91074_.m_20148_())) {
            return;
        }

        FrameData.getIdOrTexture(photograph.getStack()).left().ifPresent(id -> {
            if (id.isBlank()) {
                return;
            }

            PhotographRenderProperties properties = PhotographRenderProperties.get(photograph.getStack());
            String filename = properties != PhotographRenderProperties.DEFAULT ? id + "_" + properties.getId() : id;

            if (savedExposures.contains(filename))
                return;

            ExposureClient.getExposureStorage().getOrQuery(id).ifPresent(exposure -> {
                savedExposures.add(filename);

                new Thread(() -> new ClientsideExposureExporter(filename)
                        .withDefaultFolder()
                        .organizeByWorld(Config.Client.EXPOSURE_SAVING_LEVEL_SUBFOLDER.get(), ClientsideWorldNameGetter::getWorldName)
                        .withModifier(properties.getModifier())
                        .withSize(Config.Client.EXPOSURE_SAVING_SIZE.get())
                        .save(exposure), "ExposureSaving").start();
            });
        });
    }
}
