package io.github.mortuusars.exposure.camera.capture.component;

import io.github.mortuusars.exposure.camera.capture.Capture;
import net.minecraft.util.FastColor;
import net.minecraft.util.Mth;

public class BlackAndWhiteComponent implements ICaptureComponent {
    @Override
    public int modifyPixel(Capture capture, int colorABGR) {
        int alpha = FastColor.ABGR32.m_266503_(colorABGR);
        int blue = FastColor.ABGR32.m_266247_(colorABGR);
        int green = FastColor.ABGR32.m_266446_(colorABGR);
        int red = FastColor.ABGR32.m_266313_(colorABGR);

        // Weights adding up to more than 1 - to make the image slightly brighter
        int luma = Mth.m_14045_((int) (0.299 * red + 0.587 * green + 0.114 * blue), 0, 255);

        // Slightly increase the contrast
        int contrast = 145;
        luma = Mth.m_14045_((luma - 128) * contrast / 128 + 128, 0, 255);

        return FastColor.ABGR32.m_266248_(alpha, luma, luma, luma);
    }
}
