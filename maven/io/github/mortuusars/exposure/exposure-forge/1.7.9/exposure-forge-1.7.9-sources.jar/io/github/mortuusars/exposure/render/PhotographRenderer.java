package io.github.mortuusars.exposure.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.item.StackedPhotographsItem;
import io.github.mortuusars.exposure.render.image.RenderedImageProvider;
import io.github.mortuusars.exposure.util.ItemAndStack;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.List;

public class PhotographRenderer {
    public static void render(ItemStack stack, boolean renderPaper, boolean renderBackside, PoseStack poseStack,
                              MultiBufferSource bufferSource, int packedLight, int r, int g, int b, int a) {
        if (stack.m_41720_() instanceof PhotographItem photographItem)
            renderPhotograph(photographItem, stack, renderPaper, renderBackside, poseStack, bufferSource, packedLight, r, g, b, a);
        else if (stack.m_41720_() instanceof StackedPhotographsItem stackedPhotographsItem)
            renderStackedPhotographs(stackedPhotographsItem, stack, poseStack, bufferSource, packedLight, r, g, b, a);
    }

    public static void renderPhotograph(PhotographItem photographItem, ItemStack stack, boolean renderPaper,
                                        boolean renderBackside, PoseStack poseStack, MultiBufferSource bufferSource,
                                        int packedLight, int r, int g, int b, int a) {
        PhotographRenderProperties properties = PhotographRenderProperties.get(stack);
        int size = ExposureClient.getExposureRenderer().getSize();
        float rotateOffset = size / 2f;

        @Nullable CompoundTag frame = stack.m_41783_();
        RenderedImageProvider imageProvider = frame != null ? RenderedImageProvider.fromFrame(frame) : RenderedImageProvider.EMPTY;

        int rotation = imageProvider.getInstanceId().hashCode() % 4;

        if (renderPaper) {
            poseStack.m_85836_();
            poseStack.m_252880_(rotateOffset, rotateOffset, 0);
            poseStack.m_252781_(Axis.f_252403_.m_252977_(rotation * 90));
            poseStack.m_252880_(-rotateOffset, -rotateOffset, 0);

            renderTexture(properties.getPaperTexture(), poseStack, bufferSource, 0, 0,
                    size, size, packedLight, r, g, b, a);

            poseStack.m_85849_();

            if (renderBackside) {
                poseStack.m_85836_();
                poseStack.m_252781_(Axis.f_252436_.m_252977_(180));
                poseStack.m_85837_(-size, 0, -0.5);

                poseStack.m_252880_(rotateOffset, rotateOffset, 0);
                poseStack.m_252781_(Axis.f_252403_.m_252977_(rotation * 90));
                poseStack.m_252880_(-rotateOffset, -rotateOffset, 0);

                renderTexture(properties.getPaperTexture(), poseStack, bufferSource,
                        packedLight, (int) (r * 0.85f), (int) (g * 0.85f), (int) (b * 0.85f), a);

                poseStack.m_85849_();
            }
        }

        if (renderPaper) {
            poseStack.m_85836_();
            float offset = size * 0.0625f;
            poseStack.m_252880_(offset, offset, 1);
            poseStack.m_85841_(0.875f, 0.875f, 0.875f);
            ExposureClient.getExposureRenderer().render(imageProvider, properties.getModifier(), poseStack, bufferSource,
                    packedLight, r, g, b, a);
            poseStack.m_85849_();
        } else {
            ExposureClient.getExposureRenderer().render(imageProvider, properties.getModifier(), poseStack, bufferSource,
                    packedLight, r, g, b, a);
        }

        if (renderPaper && properties.hasPaperOverlayTexture()) {
            poseStack.m_85836_();

            poseStack.m_252880_(rotateOffset, rotateOffset, 0);
            poseStack.m_252781_(Axis.f_252403_.m_252977_(rotation * 90));
            poseStack.m_252880_(-rotateOffset, -rotateOffset, 0);

            poseStack.m_252880_(0, 0, 2);
            renderTexture(properties.getPaperOverlayTexture(), poseStack, bufferSource, packedLight, r, g, b, a);
            poseStack.m_85849_();
        }
    }

    public static void renderStackedPhotographs(StackedPhotographsItem stackedPhotographsItem, ItemStack stack,
                                                PoseStack poseStack, MultiBufferSource bufferSource,
                                                int packedLight, int r, int g, int b, int a) {
        List<ItemAndStack<PhotographItem>> photographs = stackedPhotographsItem.getPhotographs(stack, 3);
        renderStackedPhotographs(photographs, poseStack, bufferSource, packedLight, r, g, b, a);
    }

    public static void renderStackedPhotographs(List<ItemAndStack<PhotographItem>> photographs,
                                                PoseStack poseStack, MultiBufferSource bufferSource,
                                                int packedLight, int r, int g, int b, int a) {
        if (photographs.isEmpty())
            return;

        for (int i = 2; i >= 0; i--) {
            if (photographs.size() - 1 < i)
                continue;

            ItemAndStack<PhotographItem> photograph = photographs.get(i);
            PhotographRenderProperties properties = PhotographRenderProperties.get(photograph.getStack());

            // Top photograph:
            if (i == 0) {
                poseStack.m_85836_();
                poseStack.m_252880_(0, 0, 2);
                renderPhotograph(photograph.getItem(), photograph.getStack(), true, false, poseStack,
                        bufferSource, packedLight, r, g, b, a);
                poseStack.m_85849_();
                break;
            }

            @Nullable CompoundTag frame = photograph.getStack().m_41783_();
            RenderedImageProvider imageProvider = frame != null ? RenderedImageProvider.fromFrame(frame) : RenderedImageProvider.EMPTY;

            int rotation = imageProvider.getInstanceId().hashCode() % 4;

            // Photographs below (only paper)
            float posOffset = getStackedPhotographOffset() * i;
            float rotateOffset = ExposureClient.getExposureRenderer().getSize() / 2f;

            poseStack.m_85836_();
            poseStack.m_252880_(posOffset, posOffset, 2 - i);

            poseStack.m_252880_(rotateOffset, rotateOffset, 0);
            poseStack.m_252781_(Axis.f_252403_.m_252977_(rotation * 90));
            poseStack.m_252880_(-rotateOffset, -rotateOffset, 0);

            float brightnessMul = 1f - (getStackedBrightnessStep() * i);

            renderTexture(properties.getPaperTexture(), poseStack, bufferSource,
                    packedLight, (int)(r * brightnessMul), (int)(g * brightnessMul), (int)(b * brightnessMul), a);

            poseStack.m_85849_();
        }
    }

    public static float getStackedBrightnessStep() {
        return 0.15f;
    }

    public static float getStackedPhotographOffset() {
        // 2 px / Texture size (64px) = 0.03125
        return ExposureClient.getExposureRenderer().getSize() * 0.03125f;
    }

    private static void renderTexture(ResourceLocation resource, PoseStack poseStack, MultiBufferSource bufferSource,
                                      int packedLight, int r, int g, int b, int a) {
        renderTexture(resource, poseStack, bufferSource, 0, 0, ExposureClient.getExposureRenderer().getSize(),
                ExposureClient.getExposureRenderer().getSize(), packedLight, r, g, b, a);
    }

    private static void renderTexture(ResourceLocation resource, PoseStack poseStack, MultiBufferSource bufferSource,
                                      float x, float y, float width, float height, int packedLight, int r, int g, int b, int a) {
        renderTexture(resource, poseStack, bufferSource, x, y, x + width, y + height,
                0, 0, 1, 1, packedLight, r, g, b, a);
    }

    private static void renderTexture(ResourceLocation resource, PoseStack poseStack, MultiBufferSource bufferSource,
                                      float minX, float minY, float maxX, float maxY,
                                      float minU, float minV, float maxU, float maxV, int packedLight, int r, int g, int b, int a) {
        RenderSystem.setShaderTexture(0, resource);
        RenderSystem.setShader(GameRenderer::m_172835_);
        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();

        Matrix4f matrix = poseStack.m_85850_().m_252922_();
        VertexConsumer bufferBuilder = bufferSource.m_6299_(RenderType.m_110497_(resource));
        bufferBuilder.m_252986_(matrix, minX, maxY, 0).m_6122_(r, g, b, a).m_7421_(minU, maxV).m_85969_(packedLight).m_5752_();
        bufferBuilder.m_252986_(matrix, maxX, maxY, 0).m_6122_(r, g, b, a).m_7421_(maxU, maxV).m_85969_(packedLight).m_5752_();
        bufferBuilder.m_252986_(matrix, maxX, minY, 0).m_6122_(r, g, b, a).m_7421_(maxU, minV).m_85969_(packedLight).m_5752_();
        bufferBuilder.m_252986_(matrix, minX, minY, 0).m_6122_(r, g, b, a).m_7421_(minU, minV).m_85969_(packedLight).m_5752_();
    }
}