package io.github.mortuusars.exposure.block.entity;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.block.FlashBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Objects;

public class FlashBlockEntity extends BlockEntity {
    private int ticks;
    public FlashBlockEntity(BlockPos pos, BlockState blockState) {
        super(Exposure.BlockEntityTypes.FLASH.get(), pos, blockState);
        ticks = 7;
    }

    @SuppressWarnings("unused")
    public static <T extends BlockEntity> void serverTick(Level level, BlockPos blockPos, BlockState blockState, T blockEntity) {
        if (blockEntity instanceof FlashBlockEntity flashBlockEntity)
            flashBlockEntity.tick();
    }

    protected void tick() {
        ticks--;
        if (ticks <= 0) {
            BlockState blockState = Objects.requireNonNull(f_58857_).m_8055_(m_58899_());
            f_58857_.m_7731_(m_58899_(), blockState.m_61143_(FlashBlock.WATERLOGGED) ? Blocks.f_49990_.m_49966_() : Blocks.f_50016_.m_49966_(), Block.f_152402_);
        }
    }
}
