package io.github.mortuusars.exposure.gui;

import io.github.mortuusars.exposure.gui.screen.PhotographScreen;
import io.github.mortuusars.exposure.gui.screen.camera.ViewfinderControlsScreen;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.recipe.FilmDevelopingRecipe;
import io.github.mortuusars.exposure.recipe.PhotographCopyingRecipe;
import io.github.mortuusars.exposure.util.ItemAndStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class ClientGUI {
    public static void openPhotographScreen(List<ItemAndStack<PhotographItem>> photographs) {
        Minecraft.m_91087_().m_91152_(new PhotographScreen(photographs));
    }

    public static void openViewfinderControlsScreen() {
        Minecraft.m_91087_().m_91152_(new ViewfinderControlsScreen());
    }

    public static void addFilmRollDevelopingTooltip(ItemStack filmStack, @Nullable Level level, @NotNull List<Component> tooltipComponents, @NotNull TooltipFlag isAdvanced) {
        addRecipeTooltip(filmStack, level, tooltipComponents, isAdvanced,
                r -> r instanceof FilmDevelopingRecipe filmDevelopingRecipe
                    && filmDevelopingRecipe.getTransferIngredient().test(filmStack), "item.exposure.film_roll.tooltip.details.develop");
    }

    public static void addPhotographCopyingTooltip(ItemStack photographStack, @Nullable Level level, @NotNull List<Component> tooltipComponents, @NotNull TooltipFlag isAdvanced) {
        addRecipeTooltip(photographStack, level, tooltipComponents, isAdvanced,
                r -> r instanceof PhotographCopyingRecipe photographCopyingRecipe
                        && photographCopyingRecipe.getTransferIngredient().test(photographStack), "item.exposure.photograph.tooltip.details.copy");
    }

    private static void addRecipeTooltip(ItemStack stack, @Nullable Level level,
                                         @NotNull List<Component> tooltipComponents, @NotNull TooltipFlag isAdvanced,
                                         Predicate<CraftingRecipe> recipeFilter, String detailsKey) {
        if (level == null)
            return;

        tooltipComponents.add(Component.m_237115_("tooltip.exposure.hold_for_details"));
        if (!Screen.m_96638_()) {
            return;
        }

        Optional<NonNullList<Ingredient>> recipeIngredients = level.m_7465_().m_44013_(RecipeType.f_44107_)
                .stream()
                .filter(recipeFilter)
                .findFirst()
                .map(Recipe::m_7527_);

        if (recipeIngredients.isEmpty() || recipeIngredients.get().isEmpty())
            return;

        NonNullList<Ingredient> ingredients = recipeIngredients.get();

        tooltipComponents.add(Component.m_237119_());

        Style orange = Style.f_131099_.m_178520_(0xc7954b);
        Style yellow = Style.f_131099_.m_178520_(0xeeda78);

        tooltipComponents.add(Component.m_237115_(detailsKey).m_130948_(orange));

        for (int i = 0; i < ingredients.size(); i++) {
            ItemStack[] stacks = ingredients.get(i).m_43908_();

            if (stacks.length == 0)
                tooltipComponents.add(Component.m_237113_("  ").m_7220_(Component.m_237113_("?").m_130948_(yellow)));
            else if (stacks.length == 1)
                tooltipComponents.add(Component.m_237113_("  ").m_7220_(stacks[0].m_41786_().m_6881_().m_130948_(yellow)));
            else { // Cycle stacks if it's not one:
                int val = (int)Math.ceil((level.m_46467_() + 10 * i) % (20f * stacks.length) / 20f);
                int index = Mth.m_14045_(val - 1, 0, stacks.length - 1);

                tooltipComponents.add(Component.m_237113_("  ").m_7220_(stacks[index].m_41786_().m_6881_().m_130948_(yellow)));
            }
        }
    }
}
