package io.github.mortuusars.exposure.forge.loot;

import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Config;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class LootTableAdditionModifier extends LootModifier {
    public static final Supplier<Codec<LootTableAdditionModifier>> CODEC = Suppliers.memoize(
            () -> RecordCodecBuilder.create(instance -> codecStart(instance)
                    .and(ResourceLocation.f_135803_.fieldOf("lootTable").forGetter(m -> m.lootTable))
                    .apply(instance, LootTableAdditionModifier::new)
            )
    );

    public final ResourceLocation lootTable;

    public LootTableAdditionModifier(LootItemCondition[] conditions, ResourceLocation lootTable) {
        super(conditions);
        this.lootTable = lootTable;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC.get();
    }
    @Override
    protected @NotNull ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
        if (!Config.Common.LOOT_ADDITION.get())
            return generatedLoot;

        List<ItemStack> additionalItems = new ArrayList<>();

        context.m_78952_().m_7654_().m_278653_().m_278676_(lootTable).m_79131_(context, additionalItems::add);

        generatedLoot.addAll(additionalItems);

        return generatedLoot;
    }
}