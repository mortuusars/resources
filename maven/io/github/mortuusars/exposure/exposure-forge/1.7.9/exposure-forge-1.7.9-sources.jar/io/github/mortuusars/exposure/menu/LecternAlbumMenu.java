package io.github.mortuusars.exposure.menu;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.item.AlbumItem;
import io.github.mortuusars.exposure.util.ItemAndStack;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.LecternBlockEntity;

public class LecternAlbumMenu extends AlbumMenu {
    public static final int TAKE_BOOK_BUTTON = 99;

    private final Container lectern;
    private final BlockPos lecternPos;
    private final Level level;

    public LecternAlbumMenu(int containerId, BlockPos lecternPos, Inventory playerInventory,
                            ItemAndStack<AlbumItem> album, Container lectern, ContainerData lecternData) {
        this(Exposure.MenuTypes.LECTERN_ALBUM.get(), containerId, lecternPos, playerInventory, album, lectern, lecternData);
    }

    protected LecternAlbumMenu(MenuType<? extends AbstractContainerMenu> type, int containerId, BlockPos lecternPos,
                               Inventory playerInventory, ItemAndStack<AlbumItem> album, Container lectern, ContainerData lecternData) {
        super(type, containerId, playerInventory, new ItemAndStack<>(album.getStack()), false);
        m_38869_(lectern, 1);
        m_38886_(lecternData, 1);
        this.lecternPos = lecternPos;
        this.lectern = lectern;
        this.level = playerInventory.f_35978_.m_9236_();
        this.m_38897_(new Slot(lectern, 0, -999, -999) {
            @Override
            public void m_6654_() {
                super.m_6654_();
                LecternAlbumMenu.this.m_6199_(this.f_40218_);
            }
        });
        this.m_38884_(lecternData);
        setCurrentSpreadIndex(lecternData.m_6413_(0));
    }

    @Override
    public boolean m_6366_(Player player, int id) {
        if (id == TAKE_BOOK_BUTTON) {
            if (!player.m_36326_())
                return false;

            ItemStack albumStack = this.lectern.m_8016_(0);
            this.lectern.m_6596_();
            if (!player.m_150109_().m_36054_(albumStack))
                player.m_36176_(albumStack, false);

            return true;
        }

        return super.m_6366_(player, id);
    }

    @Override
    public void setCurrentSpreadIndex(int spreadIndex) {
        spreadIndex = Math.max(0, spreadIndex);
        super.setCurrentSpreadIndex(spreadIndex);
        m_7511_(1, spreadIndex);
    }

    @Override
    public void m_7511_(int id, int data) {
        super.m_7511_(id, data);
        this.m_38946_();
    }

    @Override
    public boolean m_6875_(Player player) {
        return level.m_7702_(lecternPos) instanceof LecternBlockEntity lecternBlockEntity
                && lecternBlockEntity.m_59566_().m_41720_() instanceof AlbumItem
                && Container.m_272074_(lecternBlockEntity, player);
    }

    public static LecternAlbumMenu fromBuffer(int containerId, Inventory inventory, FriendlyByteBuf buffer) {
        return new LecternAlbumMenu(containerId, buffer.m_130135_(), inventory,
                new ItemAndStack<>(buffer.m_130267_()), new SimpleContainer(1), new SimpleContainerData(1));
    }
}
