package io.github.mortuusars.exposure.block.entity;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.block.LightroomBlock;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.data.storage.ExposureSavedData;
import io.github.mortuusars.exposure.item.*;
import io.github.mortuusars.exposure.menu.LightroomMenu;
import io.github.mortuusars.exposure.util.ItemAndStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;

@SuppressWarnings("unused")
public class LightroomBlockEntity extends BaseContainerBlockEntity implements WorldlyContainer {
    
    public static final int CONTAINER_DATA_SIZE = 3;
    public static final int CONTAINER_DATA_PROGRESS_ID = 0;
    public static final int CONTAINER_DATA_PRINT_TIME_ID = 1;
    public static final int CONTAINER_DATA_SELECTED_FRAME_ID = 2;

    protected final ContainerData containerData = new ContainerData() {
        public int m_6413_(int id) {
            return switch (id) {
                case CONTAINER_DATA_PROGRESS_ID -> LightroomBlockEntity.this.progress;
                case CONTAINER_DATA_PRINT_TIME_ID -> LightroomBlockEntity.this.printTime;
                case CONTAINER_DATA_SELECTED_FRAME_ID -> LightroomBlockEntity.this.getSelectedFrameIndex();
                default -> 0;
            };
        }

        public void m_8050_(int id, int value) {
            if (id == CONTAINER_DATA_PROGRESS_ID)
                LightroomBlockEntity.this.progress = value;
            else if (id == CONTAINER_DATA_PRINT_TIME_ID)
                LightroomBlockEntity.this.printTime = value;
            else if (id == CONTAINER_DATA_SELECTED_FRAME_ID)
                LightroomBlockEntity.this.setSelectedFrame(value);
            m_6596_();
        }

        public int m_6499_() {
            return CONTAINER_DATA_SIZE;
        }
    };

    protected NonNullList<ItemStack> items = NonNullList.m_122780_(Lightroom.SLOTS, ItemStack.f_41583_);

    protected @Nullable String lastPlayerName = null;
    protected int selectedFrame;
    protected int progress;
    protected int printTime;
    protected int storedExperience;
    protected boolean advanceFrame;
    protected Lightroom.Process process = Lightroom.Process.REGULAR;

    public LightroomBlockEntity(BlockPos pos, BlockState blockState) {
        super(Exposure.BlockEntityTypes.LIGHTROOM.get(), pos, blockState);
    }

    public static <T extends BlockEntity> void serverTick(Level level, BlockPos blockPos, BlockState blockState, T blockEntity) {
        if (blockEntity instanceof LightroomBlockEntity lightroomBlockEntity)
            lightroomBlockEntity.tick();
    }

    public void setLastPlayer(Player player) {
        lastPlayerName = player.m_6302_();
    }

    protected void tick() {
        if (printTime <= 0 || !canPrint()) {
            stopPrintingProcess();
            return;
        }

        if (progress < printTime) {
            progress++;
            if (progress % 55 == 0 && printTime - progress > 12 && f_58857_ != null)
                f_58857_.m_5594_(null, m_58899_(), Exposure.SoundEvents.LIGHTROOM_PRINT.get(), SoundSource.BLOCKS,
                        1f, f_58857_.m_213780_().m_188501_() * 0.3f + 1f);
            return;
        }

        if (tryPrint()) {
            onFramePrinted();
        }

        stopPrintingProcess();
    }

    public float getProgressPercentage() {
        if (progress < 1 || printTime < 1)
            return 0f;

        return progress / (float)printTime;
    }

    protected void onFramePrinted() {
        if (advanceFrame)
            advanceFrame();
    }

    protected void advanceFrame() {
        ItemAndStack<DevelopedFilmItem> film = new ItemAndStack<>(m_8020_(Lightroom.FILM_SLOT));
        int frames = film.getItem().getExposedFramesCount(film.getStack());

        if (getSelectedFrameIndex() >= frames - 1) { // On last frame
            if (canEjectFilm())
                ejectFilm();
        } else {
            setSelectedFrame(getSelectedFrameIndex() + 1);
            m_6596_();
        }
    }

    public boolean isAdvancingFrameOnPrint() {
        return advanceFrame;
    }

    protected boolean canEjectFilm() {
        if (f_58857_ == null || f_58857_.f_46443_ || m_8020_(Lightroom.FILM_SLOT).m_41619_())
            return false;

        BlockPos pos = m_58899_();
        Direction facing = f_58857_.m_8055_(pos).m_61143_(LightroomBlock.FACING);

        return !f_58857_.m_8055_(pos.m_121945_(facing)).m_60815_();
    }

    protected void ejectFilm() {
        if (f_58857_ == null || f_58857_.f_46443_ || m_8020_(Lightroom.FILM_SLOT).m_41619_())
            return;

        BlockPos pos = m_58899_();
        Direction facing = f_58857_.m_8055_(pos).m_61143_(LightroomBlock.FACING);
        ItemStack filmStack = m_7407_(Lightroom.FILM_SLOT, 1);

        Vec3i normal = facing.m_122436_();
        Vec3 point = Vec3.m_82512_(pos).m_82520_(normal.m_123341_() * 0.75f, normal.m_123342_() * 0.75f, normal.m_123343_() * 0.75f);
        ItemEntity itemEntity = new ItemEntity(f_58857_, point.f_82479_, point.f_82480_, point.f_82481_, filmStack);
        itemEntity.m_20334_(normal.m_123341_() * 0.05f, normal.m_123342_() * 0.05f + 0.15f, normal.m_123343_() * 0.05f);
        itemEntity.m_32060_();
        f_58857_.m_7967_(itemEntity);

        inventoryContentsChanged(Lightroom.FILM_SLOT);
    }

    public int getSelectedFrameIndex() {
        return selectedFrame;
    }

    public void setSelectedFrame(int index) {
        if (selectedFrame != index) {
            selectedFrame = index;
            stopPrintingProcess();
        }
    }

    /*
        Process setting stays where it was set by the player, But if the frame does not support it -
        image would be printed with supported process (probably regular), WITHOUT changing the process setting -
        this means that this process will be used again if some other image is supporting it.

        This was done to not reset Process in automated setups, if there were some image on a film that doesn't support selected process.
     */

    /**
     * @return Process SETTING. Can be different from actual process that would be used to print an image
     * (if frame does not support this process, for example).
     */
    public Lightroom.Process getProcess() {
        return process;
    }

    /**
     * @return Process, that will be used to print an image.
     */
    public Lightroom.Process getActualProcess(ItemStack filmStack) {
        if (!canPrintChromatic(filmStack, getSelectedFrameIndex())) {
            return Lightroom.Process.REGULAR;
        }

        return process;
    }

    public void setProcess(Lightroom.Process process) {
        this.process = process;
        stopPrintingProcess();
        m_6596_();
    }

    public Optional<CompoundTag> getSelectedFrame(ItemStack film) {
        if (!film.m_41619_() && film.m_41720_() instanceof DevelopedFilmItem developedFilm) {
            ListTag frames = developedFilm.getExposedFrames(film);
            if (frames.size() > getSelectedFrameIndex())
                return Optional.of(frames.m_128728_(selectedFrame));
        }

        return Optional.empty();
    }

    public boolean isSelectedFrameChromatic(ItemStack film, int selectedFrame) {
        return getSelectedFrame(film)
                .map(frame -> frame.m_128471_(FrameData.CHROMATIC))
                .orElse(false);
    }

    public boolean canPrintChromatic(ItemStack filmStack, int selectedFrameIndex) {
        boolean chromaticSelected = getSelectedFrame(filmStack)
                .map(frame -> frame.m_128471_(FrameData.CHROMATIC))
                .orElse(false);

        if (chromaticSelected) {
            return true;
        }

        if (filmStack.m_41720_() instanceof IFilmItem filmItem && filmItem.getType() == FilmType.BLACK_AND_WHITE && m_58904_() != null) {
            return m_58904_().m_8055_(m_58899_().m_7494_()).m_204336_(Exposure.Tags.Blocks.CHROMATIC_REFRACTORS);
        }

        return false;
    }

    public void startPrintingProcess(boolean advanceFrameOnFinish) {
        if (!canPrint())
            return;

        ItemStack filmStack = m_8020_(Lightroom.FILM_SLOT);
        if (!(filmStack.m_41720_() instanceof DevelopedFilmItem film))
            return;

        if (getActualProcess(filmStack) == Lightroom.Process.CHROMATIC)
            printTime = Config.Common.LIGHTROOM_CHROMATIC_PRINT_TIME.get();
        else if (film.getType() == FilmType.BLACK_AND_WHITE)
            printTime = Config.Common.LIGHTROOM_BW_PRINT_TIME.get();
        else
            printTime = Config.Common.LIGHTROOM_COLOR_PRINT_TIME.get();

        advanceFrame = advanceFrameOnFinish;

        if (f_58857_ != null) {
            f_58857_.m_7731_(m_58899_(), f_58857_.m_8055_(m_58899_())
                    .m_61124_(LightroomBlock.LIT, true), Block.f_152394_);
            f_58857_.m_5594_(null, m_58899_(), Exposure.SoundEvents.LIGHTROOM_PRINT.get(), SoundSource.BLOCKS,
                    1f, f_58857_.m_213780_().m_188501_() * 0.3f + 1f);
        }
    }

    public void stopPrintingProcess() {
        progress = 0;
        printTime = 0;
        advanceFrame = false;
        if (f_58857_ != null && f_58857_.m_8055_(m_58899_()).m_60734_() instanceof LightroomBlock)
            f_58857_.m_7731_(m_58899_(), f_58857_.m_8055_(m_58899_())
                    .m_61124_(LightroomBlock.LIT, false), Block.f_152394_);
    }

    public boolean isPrinting() {
        return printTime > 0;
    }

    public boolean canPrint() {
        if (getSelectedFrameIndex() < 0) // Upper bound is checked further down
            return false;

        ItemStack filmStack = m_8020_(Lightroom.FILM_SLOT);
        if (!(filmStack.m_41720_() instanceof DevelopedFilmItem developedFilm) || !developedFilm.hasExposedFrame(filmStack, getSelectedFrameIndex()))
            return false;

        Lightroom.Process process = getActualProcess(filmStack);

        ItemStack paperStack = m_8020_(Lightroom.PAPER_SLOT);

        return isPaperValidForPrint(paperStack, filmStack, process)
                && hasDyesForPrint(filmStack, paperStack, process)
                && canOutputToResultSlot(m_8020_(Lightroom.RESULT_SLOT), filmStack, process);
    }

    public boolean canPrintInCreativeMode() {
        if (getSelectedFrameIndex() < 0) // Upper bound is checked further down
            return false;

        ItemStack filmStack = m_8020_(Lightroom.FILM_SLOT);
        if (!(filmStack.m_41720_() instanceof DevelopedFilmItem developedFilm) || !developedFilm.hasExposedFrame(filmStack, getSelectedFrameIndex()))
            return false;

        return canOutputToResultSlot(m_8020_(Lightroom.RESULT_SLOT), filmStack, getActualProcess(filmStack));
    }

    protected boolean isPaperValidForPrint(ItemStack paperStack, ItemStack filmStack, Lightroom.Process process) {
        if (paperStack.m_41619_())
            return false;

        return process != Lightroom.Process.REGULAR || paperStack.m_204117_(Exposure.Tags.Items.PHOTO_PAPERS);
    }

    protected boolean hasDyesForPrint(ItemStack film, ItemStack paper, Lightroom.Process process) {
        int[] dyeSlots = getRequiredDyeSlotsForPrint(film, paper, process);

        for (int slot : dyeSlots) {
            if (m_8020_(slot).m_41619_())
                return false;
        }

        return true;
    }

    public boolean canOutputToResultSlot(ItemStack resultStack, ItemStack filmStack, Lightroom.Process process) {
        if (canPrintChromatic(filmStack, getSelectedFrameIndex()) && process == Lightroom.Process.CHROMATIC)
            return resultStack.m_41619_();

        return resultStack.m_41619_() || resultStack.m_41720_() instanceof PhotographItem
                || (resultStack.m_41720_() instanceof StackedPhotographsItem stackedPhotographsItem
                && stackedPhotographsItem.canAddPhotograph(resultStack));
    }

    protected int[] getRequiredDyeSlotsForPrint(ItemStack film, ItemStack paper, Lightroom.Process process) {
        if (!(film.m_41720_() instanceof IFilmItem filmItem))
            return ArrayUtils.EMPTY_INT_ARRAY;

        if (process == Lightroom.Process.REGULAR) {
            return filmItem.getType() == FilmType.COLOR ? Lightroom.DYES_FOR_COLOR : Lightroom.DYES_FOR_BW;
        }

        if (process == Lightroom.Process.CHROMATIC) {
            int chromaticStep = getChromaticStep(paper);
            if (chromaticStep == 0) return Lightroom.DYES_FOR_CHROMATIC_RED;
            if (chromaticStep == 1) return Lightroom.DYES_FOR_CHROMATIC_GREEN;
            if (chromaticStep == 2) return Lightroom.DYES_FOR_CHROMATIC_BLUE;
        }

        return ArrayUtils.EMPTY_INT_ARRAY;
    }

    protected int getChromaticStep(ItemStack paper) {
        if (!(paper.m_41720_() instanceof ChromaticSheetItem chromaticFragment))
            return 0;

        return chromaticFragment.getExposures(paper).size();
    }

    public boolean tryPrint() {
        Preconditions.checkState(f_58857_ != null && !f_58857_.f_46443_, "Cannot be called clientside.");
        if (!canPrint())
            return false;

        ItemStack filmStack = m_8020_(Lightroom.FILM_SLOT);
        if (!(filmStack.m_41720_() instanceof DevelopedFilmItem developedFilm))
            return false;

        Optional<CompoundTag> selectedFrame = getSelectedFrame(filmStack);
        if (selectedFrame.isEmpty()) {
            Exposure.LOGGER.error("Unable to get selected frame '{}' : {}", getSelectedFrameIndex(), filmStack);
            return false;
        }

        CompoundTag frame = selectedFrame.get().m_6426_();
        Lightroom.Process process = getActualProcess(filmStack);
        ItemStack paperStack = m_8020_(Lightroom.PAPER_SLOT);

        ItemStack printResult = createPrintResult(frame, filmStack, paperStack, process);
        putPrintResultInOutputSlot(printResult);

        // Consume items required for printing:
        int[] dyesSlots = getRequiredDyeSlotsForPrint(filmStack, paperStack, process);
        for (int slot : dyesSlots) {
            m_8020_(slot).m_41774_(1);
        }
        m_8020_(Lightroom.PAPER_SLOT).m_41774_(1);

        f_58857_.m_5594_(null, m_58899_(), Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), SoundSource.PLAYERS, 0.8f, 1f);

        storeExperienceForPrint(filmStack, frame, process, printResult);

        if (process != Lightroom.Process.CHROMATIC) { // Chromatics create new exposure. Marking is not needed.
            // Mark exposure as printed
            String id = frame.m_128461_(FrameData.ID);
            if (!id.isEmpty()) {
                ExposureServer.getExposureStorage().getOrQuery(id).ifPresent(exposure -> {
                    CompoundTag properties = exposure.getProperties();
                    if (!properties.m_128471_(ExposureSavedData.WAS_PRINTED_PROPERTY)) {
                        properties.m_128379_(ExposureSavedData.WAS_PRINTED_PROPERTY, true);
                        exposure.m_77762_();
                    }
                });
            }
        }

        return true;
    }

    protected void storeExperienceForPrint(ItemStack film, CompoundTag frame, Lightroom.Process process, ItemStack result) {
        if (f_58857_ == null)
            return;

        int xp = 0;
        if (process == Lightroom.Process.CHROMATIC) {
            // Printing intermediate channels does not grant xp. Only finished photograph does.
            xp = result.m_41720_() instanceof ChromaticSheetItem ? 0 : Config.Common.LIGHTROOM_EXPERIENCE_PER_PRINT_CHROMATIC.get();
        }
        else if (film.m_41720_() instanceof IFilmItem filmItem)
            xp = filmItem.getType() == FilmType.COLOR
                    ? Config.Common.LIGHTROOM_EXPERIENCE_PER_PRINT_COLOR.get()
                    : Config.Common.LIGHTROOM_EXPERIENCE_PER_PRINT_BW.get();

        if (xp > 0) {
            float variability = f_58857_.m_213780_().m_188501_() * 0.3f + 1f;
            int variableXp = (int)Math.max(1, Math.ceil(xp * variability));
            storedExperience += variableXp;
        }
    }

    public void printInCreativeMode() {
        Preconditions.checkState(f_58857_ != null && !f_58857_.f_46443_, "Cannot be called clientside.");
        if (!canPrintInCreativeMode())
            return;

        ItemStack filmStack = m_8020_(Lightroom.FILM_SLOT);
        if (!(filmStack.m_41720_() instanceof DevelopedFilmItem developedFilm))
            return;

        Optional<CompoundTag> selectedFrame = getSelectedFrame(filmStack);
        if (selectedFrame.isEmpty()) {
            Exposure.LOGGER.error("Unable to get selected frame '{}' : {}", getSelectedFrameIndex(), filmStack);
            return;
        }

        CompoundTag frame = selectedFrame.get().m_6426_();
        Lightroom.Process process = getActualProcess(filmStack);
        ItemStack paperStack = m_8020_(Lightroom.PAPER_SLOT);

        ItemStack printResult = createPrintResult(frame, filmStack, paperStack, process);
        putPrintResultInOutputSlot(printResult);

        if (process == Lightroom.Process.CHROMATIC)
            m_8020_(Lightroom.PAPER_SLOT).m_41774_(1);

        f_58857_.m_5594_(null, m_58899_(), Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), SoundSource.PLAYERS, 0.8f, 1f);

        if (process != Lightroom.Process.CHROMATIC) { // Chromatics create new exposure. Marking is not needed.
            // Mark exposure as printed
            String id = frame.m_128461_(FrameData.ID);
            if (!id.isEmpty()) {
                ExposureServer.getExposureStorage().getOrQuery(id).ifPresent(exposure -> {
                    CompoundTag properties = exposure.getProperties();
                    if (!properties.m_128471_(ExposureSavedData.WAS_PRINTED_PROPERTY)) {
                        properties.m_128379_(ExposureSavedData.WAS_PRINTED_PROPERTY, true);
                        exposure.m_77762_();
                    }
                });
            }
        }
    }

    protected void putPrintResultInOutputSlot(ItemStack printResult) {
        ItemStack resultStack = m_8020_(Lightroom.RESULT_SLOT);
        if (resultStack.m_41619_())
            resultStack = printResult;
        else if (resultStack.m_41720_() instanceof PhotographItem) {
            StackedPhotographsItem stackedPhotographsItem = Exposure.Items.STACKED_PHOTOGRAPHS.get();
            ItemStack newStackedPhotographs = new ItemStack(stackedPhotographsItem);
            stackedPhotographsItem.addPhotographOnTop(newStackedPhotographs, resultStack);
            stackedPhotographsItem.addPhotographOnTop(newStackedPhotographs, printResult);
            resultStack = newStackedPhotographs;
        } else if (resultStack.m_41720_() instanceof StackedPhotographsItem stackedPhotographsItem) {
            stackedPhotographsItem.addPhotographOnTop(resultStack, printResult);
        } else {
            Exposure.LOGGER.error("Unexpected item in result slot: " + resultStack);
            return;
        }
        m_6836_(Lightroom.RESULT_SLOT, resultStack);
    }

    protected ItemStack createPrintResult(CompoundTag frame, ItemStack film, ItemStack paper, Lightroom.Process process) {
        if (!(film.m_41720_() instanceof IFilmItem filmItem))
            throw new IllegalStateException("Film stack is invalid: " + film);

        paper = paper.m_41777_();

        // Type is currently used to decide what dyes are used when copying photograph.
        // Or for quests. Or other purposes. It's important.
        frame.m_128359_(FrameData.TYPE, process == Lightroom.Process.REGULAR
                ? filmItem.getType().m_7912_() : FilmType.COLOR.m_7912_());

        if (process == Lightroom.Process.CHROMATIC) {
            ItemAndStack<ChromaticSheetItem> chromaticFragment = new ItemAndStack<>(
                    paper.m_41720_() instanceof ChromaticSheetItem ? paper
                            : new ItemStack(Exposure.Items.CHROMATIC_SHEET.get()));

            chromaticFragment.getItem().addExposure(chromaticFragment.getStack(), frame);

            if (chromaticFragment.getItem().getExposures(chromaticFragment.getStack()).size() >= 3) {
                assert f_58857_ != null;
                if (lastPlayerName == null) {
                    return chromaticFragment.getItem().finalize(f_58857_, chromaticFragment.getStack(), "Exposure", null);
                }
                else if (f_58857_.m_7654_() == null) {
                    return chromaticFragment.getItem().finalize(f_58857_, chromaticFragment.getStack(), lastPlayerName, null);
                }
                else {
                    @Nullable ServerPlayer player = f_58857_.m_7654_().m_6846_().m_11255_(lastPlayerName);
                    return chromaticFragment.getItem().finalize(f_58857_, chromaticFragment.getStack(), lastPlayerName, player);
                }
            }

            return chromaticFragment.getStack();
        }
        else {
            ItemStack photographStack = new ItemStack(Exposure.Items.PHOTOGRAPH.get());
            photographStack.m_41751_(frame);
            return photographStack;
        }
    }

    public void dropStoredExperience(@Nullable Player player) {
        if (f_58857_ instanceof ServerLevel serverLevel && storedExperience > 0) {
            ExperienceOrb.m_147082_(serverLevel, Vec3.m_82512_(m_58899_()), storedExperience);
            storedExperience = 0;
            m_6596_();
        }
    }


    // Container

    @Override
    protected @NotNull Component m_6820_() {
        return Component.m_237115_("container.exposure.lightroom");
    }

    @Override
    protected @NotNull AbstractContainerMenu m_6555_(int containerId, Inventory inventory) {
        return new LightroomMenu(containerId, inventory, this, containerData);
    }

    public boolean isItemValidForSlot(int slot, ItemStack stack) {
        if (slot == Lightroom.FILM_SLOT) return stack.m_41720_() instanceof DevelopedFilmItem;
        else if (slot == Lightroom.CYAN_SLOT) return stack.m_204117_(Exposure.Tags.Items.CYAN_PRINTING_DYES);
        else if (slot == Lightroom.MAGENTA_SLOT) return stack.m_204117_(Exposure.Tags.Items.MAGENTA_PRINTING_DYES);
        else if (slot == Lightroom.YELLOW_SLOT) return stack.m_204117_(Exposure.Tags.Items.YELLOW_PRINTING_DYES);
        else if (slot == Lightroom.BLACK_SLOT) return stack.m_204117_(Exposure.Tags.Items.BLACK_PRINTING_DYES);
        else if (slot == Lightroom.PAPER_SLOT)
            return stack.m_204117_(Exposure.Tags.Items.PHOTO_PAPERS) ||
                    (stack.m_41720_() instanceof ChromaticSheetItem chromatic && chromatic.getExposures(stack).size() < 3);
        else if (slot == Lightroom.RESULT_SLOT)
            return stack.m_41720_() instanceof PhotographItem || stack.m_41720_() instanceof ChromaticSheetItem;
        return false;
    }

    protected void inventoryContentsChanged(int slot) {
        if (slot == Lightroom.FILM_SLOT)
            setSelectedFrame(0);

        m_6596_();
    }

    @Override
    public boolean m_6542_(@NotNull Player player) {
        return this.f_58857_ != null && this.f_58857_.m_7702_(this.f_58858_) == this
                && player.m_20275_(this.f_58858_.m_123341_() + 0.5D,
                this.f_58858_.m_123342_() + 0.5D,
                this.f_58858_.m_123343_() + 0.5D) <= 64.0D;
    }

    @Override
    public int @NotNull [] m_7071_(@NotNull Direction face) {
        return Lightroom.ALL_SLOTS;
    }

    @Override
    public boolean m_7155_(int index, @NotNull ItemStack itemStack, @Nullable Direction direction) {
        if (direction == Direction.DOWN)
            return false;
        return m_7013_(index, itemStack);
    }

    @Override
    public boolean m_7013_(int index, ItemStack stack) {
        return index != Lightroom.RESULT_SLOT && isItemValidForSlot(index, stack) && super.m_7013_(index, stack);
    }

    @Override
    public boolean m_7157_(int index, @NotNull ItemStack pStack, @NotNull Direction direction) {
        for (int outputSlot : Lightroom.OUTPUT_SLOTS) {
            if (index == outputSlot)
                return true;
        }
        return false;
    }


    // Load/Save
    @Override
    public void m_142466_(@NotNull CompoundTag tag) {
        super.m_142466_(tag);

        this.items = NonNullList.m_122780_(this.m_6643_(), ItemStack.f_41583_);
        ContainerHelper.m_18980_(tag, this.items);

        // Backwards compatibility:
        if (tag.m_128425_("Inventory", Tag.f_178203_)) {
            CompoundTag inventory = tag.m_128469_("Inventory");
            ListTag itemsList = inventory.m_128437_("Items", Tag.f_178203_);

            for (int i = 0; i < itemsList.size(); i++) {
                CompoundTag itemTags = itemsList.m_128728_(i);
                int slot = itemTags.m_128451_("Slot");

                if (slot >= 0 && slot < items.size())
                    items.set(slot, ItemStack.m_41712_(itemTags));
            }
        }

        this.setSelectedFrame(tag.m_128451_("SelectedFrame"));
        this.progress = tag.m_128451_("Progress");
        this.printTime = tag.m_128451_("PrintTime");
        this.storedExperience = tag.m_128451_("PrintedPhotographsCount");
        this.advanceFrame = tag.m_128471_("AdvanceFrame");
        this.process = Lightroom.Process.fromStringOrDefault(tag.m_128461_("Process"), Lightroom.Process.REGULAR);
        if (tag.m_128425_("LastPlayerName", Tag.f_178201_)) {
            this.lastPlayerName = tag.m_128461_("LastPlayerName");
        }
    }

    @Override
    protected void m_183515_(@NotNull CompoundTag tag) {
        super.m_183515_(tag);
        ContainerHelper.m_18973_(tag, items);
        if (getSelectedFrameIndex() > 0)
            tag.m_128405_("SelectedFrame", getSelectedFrameIndex());
        if (progress > 0)
            tag.m_128405_("Progress", progress);
        if (printTime > 0)
            tag.m_128405_("PrintTime", printTime);
        if (storedExperience > 0)
            tag.m_128405_("PrintedPhotographsCount", storedExperience);
        if (advanceFrame)
            tag.m_128379_("AdvanceFrame", true);
        if (process != Lightroom.Process.REGULAR)
            tag.m_128359_("Process", process.m_7912_());
        if (lastPlayerName != null)
            tag.m_128359_("LastPlayerName", lastPlayerName);
    }

    protected NonNullList<ItemStack> getItems() {
        return this.items;
    }

    @Override
    public int m_6643_() {
        return Lightroom.SLOTS;
    }

    @Override
    public boolean m_7983_() {
        return getItems().stream().allMatch(ItemStack::m_41619_);
    }

    @Override
    public @NotNull ItemStack m_8020_(int slot) {
        return getItems().get(slot);
    }

    @Override
    public @NotNull ItemStack m_7407_(int slot, int amount) {
        ItemStack itemStack = ContainerHelper.m_18969_(getItems(), slot, amount);
        if (!itemStack.m_41619_())
            inventoryContentsChanged(slot);
        return itemStack;
    }

    @Override
    public @NotNull ItemStack m_8016_(int slot) {
        return ContainerHelper.m_18966_(getItems(), slot);
    }

    @Override
    public void m_6836_(int slot, ItemStack stack) {
        this.getItems().set(slot, stack);
        if (stack.m_41613_() > this.m_6893_()) {
            stack.m_41764_(this.m_6893_());
        }
        inventoryContentsChanged(slot);
    }

    @Override
    public void m_6211_() {
        getItems().clear();
        inventoryContentsChanged(-1);
    }

    @Override
    public void m_6596_() {
        super.m_6596_();
        if (f_58857_ != null && !f_58857_.f_46443_) {
            f_58857_.m_7260_(m_58899_(), m_58900_(), m_58900_(), Block.f_152394_);
        }
    }


    // Sync:

    @Override
    @Nullable
    public ClientboundBlockEntityDataPacket m_58483_() {
        return ClientboundBlockEntityDataPacket.m_195640_(this);
    }

    @Override
    public @NotNull CompoundTag m_5995_() {
        return m_187482_();
    }
}
