package io.github.mortuusars.exposure.gui.screen.camera;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.camera.CameraClient;
import io.github.mortuusars.exposure.camera.infrastructure.ZoomDirection;
import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.camera.viewfinder.ViewfinderOverlay;
import io.github.mortuusars.exposure.client.MouseHandler;
import io.github.mortuusars.exposure.gui.screen.element.IElementWithTooltip;
import io.github.mortuusars.exposure.gui.screen.camera.button.*;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.util.CameraInHand;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;

public class ViewfinderControlsScreen extends Screen {
    public static final ResourceLocation TEXTURE = Exposure.resource("textures/gui/viewfinder/viewfinder_camera_controls.png");

    private final Player player;
    private final ClientLevel level;
    private final long openedAtTimestamp;

    public ViewfinderControlsScreen() {
        super(Component.m_237119_());

        player = Minecraft.m_91087_().f_91074_;
        level = Minecraft.m_91087_().f_91073_;
        assert level != null;
        openedAtTimestamp = level.m_46467_();
    }

    @Override
    public boolean m_7043_() {
        return false;
    }

    @Override
    public void m_86600_() {
        refreshMovementKeys();
        Minecraft.m_91087_().m_91279_();
    }

    @Override
    protected void m_7856_() {
        super.m_7856_();
        refreshMovementKeys();

        int leftPos = (f_96543_ - 256) / 2;
        int topPos = Math.round(ViewfinderOverlay.opening.y + ViewfinderOverlay.opening.height - 256);

        Camera<?> camera = CameraClient.getCamera().orElseThrow();

        boolean hasFlashAttached = camera.get().getItem().getAttachment(camera.get().getStack(), CameraItem.FLASH_ATTACHMENT).isPresent();

        int sideButtonsWidth = 48;
        int buttonWidth = 15;

        int elementX = leftPos + 128 - (sideButtonsWidth + 1 + buttonWidth + 1 + (hasFlashAttached ? buttonWidth + 1 : 0) + sideButtonsWidth) / 2;
        int elementY = topPos + 238;

        // Order of adding influences TAB key behavior

        ShutterSpeedButton shutterSpeedButton = new ShutterSpeedButton(this, leftPos + 94, topPos + 226, 69, 12, 112, 0, TEXTURE);
        m_142416_(shutterSpeedButton);

        FocalLengthButton focalLengthButton = new FocalLengthButton(this, elementX, elementY, 48, 18, 0, 0, TEXTURE);
        m_169394_(focalLengthButton);
        elementX += focalLengthButton.m_5711_();

        ImageButton separator1 = new ImageButton(elementX, elementY, 1, 18, 111, 0, TEXTURE, pButton -> {});
        m_169394_(separator1);
        elementX += separator1.m_5711_();

        CompositionGuideButton compositionGuideButton = new CompositionGuideButton(this, elementX, elementY, 15, 18, 48, 0, TEXTURE);
        m_142416_(compositionGuideButton);
        elementX += compositionGuideButton.m_5711_();

        ImageButton separator2 = new ImageButton(elementX, elementY, 1, 18, 111, 0, TEXTURE, pButton -> {});
        m_169394_(separator2);
        elementX += separator2.m_5711_();

        if (hasFlashAttached) {
            FlashModeButton flashModeButton = new FlashModeButton(this, elementX, elementY, 15, 18, 48, 0, TEXTURE);
            m_142416_(flashModeButton);
            elementX += flashModeButton.m_5711_();

            ImageButton separator3 = new ImageButton(elementX, elementY, 1, 18, 111, 0, TEXTURE, pButton -> {});
            m_169394_(separator3);
            elementX += separator3.m_5711_();
        }

        FrameCounterButton frameCounterButton = new FrameCounterButton(this, elementX, elementY, 48, 18, 63, 0, TEXTURE);
        m_169394_(frameCounterButton);
    }

    /**
     * When screen is opened - all keys are released. If we do not refresh them - player would stop moving (if they had).
     */
    private void refreshMovementKeys() {
        Consumer<KeyMapping> update = keyMapping -> {
            if (keyMapping.f_90816_.m_84868_() == InputConstants.Type.MOUSE) {
                keyMapping.m_7249_(MouseHandler.isMouseButtonHeld(keyMapping.f_90816_.m_84873_()));
            }
            else {
                long windowId = Minecraft.m_91087_().m_91268_().m_85439_();
                keyMapping.m_7249_(InputConstants.m_84830_(windowId, keyMapping.f_90816_.m_84873_()));
            }
        };

        update.accept(ExposureClient.getCameraControlsKey());
        Options opt = Minecraft.m_91087_().f_91066_;
        update.accept(opt.f_92085_);
        update.accept(opt.f_92087_);
        update.accept(opt.f_92086_);
        update.accept(opt.f_92088_);
        update.accept(opt.f_92089_);
        update.accept(opt.f_92091_);
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (!Viewfinder.isLookingThrough()) {
            this.m_7379_();
            return;
        }

        if (Minecraft.m_91087_().f_91066_.f_92062_)
            return;

        guiGraphics.m_280168_().m_85836_();

        float viewfinderScale = ViewfinderOverlay.getScale();
        if (viewfinderScale != 1.0f) {
            guiGraphics.m_280168_().m_252880_(f_96543_ / 2f, f_96544_ / 2f, 0);
            guiGraphics.m_280168_().m_85841_(viewfinderScale, viewfinderScale, viewfinderScale);
            guiGraphics.m_280168_().m_252880_(-f_96543_ / 2f, -f_96544_ / 2f, 0);
        }

        RenderSystem.setShader(GameRenderer::m_172817_);
        RenderSystem.setShaderTexture(0, TEXTURE);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);

        for(Renderable renderable : this.f_169369_) {
            if (renderable instanceof IElementWithTooltip tooltipElement && renderable instanceof AbstractWidget widget
                && widget.f_93624_ && widget.m_198029_()) {
                tooltipElement.renderToolTip(guiGraphics, mouseX, mouseY);
                break;
            }
        }

        guiGraphics.m_280168_().m_85849_();
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        if (super.m_6375_(mouseX, mouseY, button))
            return true;

        if (button == InputConstants.f_166349_ && Minecraft.m_91087_().f_91072_ != null) {
            Camera<?> camera = CameraClient.getCamera().orElseThrow();

            if (camera instanceof CameraInHand<?> cameraInHand) {
                InteractionHand hand = cameraInHand.getHand();
                Minecraft.m_91087_().f_91072_.m_233721_(player, hand);
            }

            return true;
        }

        return false;
    }

    @Override
    public boolean m_6348_(double mouseX, double mouseY, int button) {
        if (ExposureClient.getCameraControlsKey().m_90830_(button)
                || (Config.Client.VIEWFINDER_MIDDLE_CLICK_CONTROLS.get() && button == InputConstants.f_166348_)) {
            if (level.m_46467_() - openedAtTimestamp >= 5)
                this.m_7379_();

            return false;
        }

        return super.m_6348_(mouseX, mouseY, button);
    }

    @Override
    public boolean m_7920_(int keyCode, int scanCode, int modifiers) {
        if (ExposureClient.getCameraControlsKey().m_90832_(keyCode, scanCode)) {
            if (level.m_46467_() - openedAtTimestamp >= 5)
                this.m_7379_();

            return false;
        }

        return super.m_7920_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        Preconditions.checkState(f_96541_ != null);

        boolean handled = super.m_7933_(keyCode, scanCode, modifiers);
        if (handled)
            return true;

        if (keyCode == InputConstants.f_166281_ || keyCode == InputConstants.f_166285_) {
            Viewfinder.zoom(ZoomDirection.IN, true);
            return true;
        }
        else if (keyCode == 333 /*KEY_SUBTRACT*/ || keyCode == InputConstants.f_166288_) {
            Viewfinder.zoom(ZoomDirection.OUT, true);
            return true;
        }

        return false;
    }

    @Override
    public boolean m_6050_(double mouseX, double mouseY, double delta) {
        if (!super.m_6050_(mouseX, mouseY, delta)) {
            Viewfinder.zoom(delta > 0d ? ZoomDirection.IN : ZoomDirection.OUT, true);
            return true;
        }

        return false;
    }
}
