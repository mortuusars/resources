package io.github.mortuusars.exposure.gui.screen;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.gui.screen.element.Pager;
import io.github.mortuusars.exposure.render.image.RenderedImageProvider;
import io.github.mortuusars.exposure.render.image.ExposureDataImage;
import io.github.mortuusars.exposure.render.image.IImage;
import io.github.mortuusars.exposure.render.image.TextureImage;
import io.github.mortuusars.exposure.data.storage.ExposureSavedData;
import io.github.mortuusars.exposure.render.modifiers.ExposurePixelModifiers;
import io.github.mortuusars.exposure.util.GuiUtil;
import io.github.mortuusars.exposure.util.PagingDirection;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class NegativeExposureScreen extends ZoomableScreen {
    public static final ResourceLocation TEXTURE = Exposure.resource("textures/gui/film_frame_inspect.png");
    public static final int BG_SIZE = 78;
    public static final int FRAME_SIZE = 54;

    private final Pager pager = new Pager(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get());
    private final List<Either<String, ResourceLocation>> exposures;

    public NegativeExposureScreen(List<Either<String, ResourceLocation>> exposures) {
        super(Component.m_237119_());
        this.exposures = exposures;
        Preconditions.checkArgument(exposures != null && !exposures.isEmpty());

        zoom.step = 2f;
        zoom.defaultZoom = 1f;
        zoom.targetZoom = 1f;
        zoom.minZoom = zoom.defaultZoom / (float)Math.pow(zoom.step, 1f);
        zoom.maxZoom = zoom.defaultZoom * (float)Math.pow(zoom.step, 5f);
    }

    @Override
    public boolean m_7043_() {
        return false;
    }

    @Override
    protected void m_7856_() {
        super.m_7856_();
        zoomFactor = 1f / (f_96541_.f_91066_.m_231928_().m_231551_() + 1);
        ImageButton previousButton = new ImageButton(0, (int) (f_96544_ / 2f - 16 / 2f), 16, 16,
                0, 0, 16, PhotographScreen.WIDGETS_TEXTURE, 256, 256,
                button -> pager.changePage(PagingDirection.PREVIOUS), Component.m_237115_("gui.exposure.previous_page"));
        m_142416_(previousButton);

        ImageButton nextButton = new ImageButton(f_96543_ - 16, (int) (f_96544_ / 2f - 16 / 2f), 16, 16,
                16, 0, 16, PhotographScreen.WIDGETS_TEXTURE, 256, 256,
                button -> pager.changePage(PagingDirection.NEXT), Component.m_237115_("gui.exposure.next_page"));
        m_142416_(nextButton);

        pager.init(exposures.size(), true, previousButton, nextButton);
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        pager.update();

        m_280273_(guiGraphics);

        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);

        Either<String, ResourceLocation> idOrTexture = exposures.get(pager.getCurrentPage());

        @Nullable FilmType type = idOrTexture.map(
                id -> ExposureClient.getExposureStorage().getOrQuery(id).map(ExposureSavedData::getType)
                        .orElse(FilmType.BLACK_AND_WHITE),
                texture -> (texture.m_135815_().endsWith("_black_and_white") || texture.m_135815_()
                        .endsWith("_bw")) ? FilmType.COLOR : FilmType.BLACK_AND_WHITE);
        if (type == null)
            type = FilmType.BLACK_AND_WHITE;

        @Nullable IImage image = idOrTexture.map(
                id -> ExposureClient.getExposureStorage().getOrQuery(id)
                        .map(data -> new ExposureDataImage(id, data)).orElse(null),
                TextureImage::getTexture
        );

        if (image == null)
            return;

        int width = image.getWidth();
        int height = image.getHeight();

        guiGraphics.m_280168_().m_85836_();
        guiGraphics.m_280168_().m_252880_(x + this.f_96543_ / 2f, y + this.f_96544_ / 2f, 0);
        guiGraphics.m_280168_().m_85841_(scale, scale, scale);
        guiGraphics.m_280168_().m_252880_(-width / 2f, -height / 2f, 0);

        {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShaderTexture(0, TEXTURE);

            guiGraphics.m_280168_().m_85836_();
            float scale = Math.max((float) width / (FRAME_SIZE), (float) height / (FRAME_SIZE));
            guiGraphics.m_280168_().m_85841_(scale, scale, scale);
            guiGraphics.m_280168_().m_252880_(-12, -12, 0);

            GuiUtil.blit(guiGraphics.m_280168_(), 0, 0, BG_SIZE, BG_SIZE, 0, 0, 256, 256, 0);

            RenderSystem.setShaderColor(type.filmR, type.filmG, type.filmB, type.filmA);
            GuiUtil.blit(guiGraphics.m_280168_(), 0, 0, BG_SIZE, BG_SIZE, 0, BG_SIZE, 256, 256, 0);

            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

            guiGraphics.m_280168_().m_85849_();
        }

        MultiBufferSource.BufferSource bufferSource = MultiBufferSource.m_109898_(Tesselator.m_85913_().m_85915_());
        ExposureClient.getExposureRenderer().render(new RenderedImageProvider(image), ExposurePixelModifiers.NEGATIVE_FILM,
                guiGraphics.m_280168_(), bufferSource, 0, 0, width, height, 0, 0, 1, 1,
                LightTexture.f_173040_, type.frameR, type.frameG, type.frameB, 255);
        bufferSource.m_109911_();

        guiGraphics.m_280168_().m_85849_();
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        return pager.handleKeyPressed(keyCode, scanCode, modifiers) || super.m_7933_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_7920_(int keyCode, int scanCode, int modifiers) {
        return pager.handleKeyReleased(keyCode, scanCode, modifiers) || super.m_7920_(keyCode, scanCode, modifiers);
    }
}
