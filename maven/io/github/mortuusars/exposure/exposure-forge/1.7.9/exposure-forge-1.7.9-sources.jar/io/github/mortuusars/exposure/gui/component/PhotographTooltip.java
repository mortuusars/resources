package io.github.mortuusars.exposure.gui.component;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.vertex.Tesselator;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.item.StackedPhotographsItem;
import io.github.mortuusars.exposure.render.PhotographRenderer;
import io.github.mortuusars.exposure.util.ItemAndStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class PhotographTooltip implements ClientTooltipComponent, TooltipComponent {
    public static final int SIZE = 72;
    private final List<ItemAndStack<PhotographItem>> photographs;

    public PhotographTooltip(ItemStack photographStack) {
        Preconditions.checkArgument(photographStack.m_41720_() instanceof PhotographItem,
                photographStack + " is not a PhotographItem.");

        this.photographs = List.of(new ItemAndStack<>(photographStack));
    }

    public PhotographTooltip(ItemAndStack<StackedPhotographsItem> stackedPhotographs) {
        this.photographs = stackedPhotographs.getItem().getPhotographs(stackedPhotographs.getStack());
    }

    @Override
    public int m_142069_(@NotNull Font font) {
        return SIZE;
    }

    @Override
    public int m_142103_() {
        return SIZE + 2; // 2px bottom margin
    }

    @Override
    public void m_183452_(@NotNull Font font, int mouseX, int mouseY, GuiGraphics guiGraphics) {
        int photographsCount = photographs.size();
        int additionalPhotographs = Math.min(2, photographsCount - 1);

        guiGraphics.m_280168_().m_85836_();
        guiGraphics.m_280168_().m_252880_(mouseX, mouseY, 5);
        float scale = SIZE / (float) ExposureClient.getExposureRenderer().getSize();
        float nextPhotographOffset = PhotographRenderer.getStackedPhotographOffset() / ExposureClient.getExposureRenderer().getSize();
        scale *= 1f - (additionalPhotographs * nextPhotographOffset);
        guiGraphics.m_280168_().m_85841_(scale, scale, 1f);

        MultiBufferSource.BufferSource bufferSource = MultiBufferSource.m_109898_(Tesselator.m_85913_().m_85915_());

        PhotographRenderer.renderStackedPhotographs(photographs, guiGraphics.m_280168_(), bufferSource,
                LightTexture.f_173040_, 255, 255, 255, 255);

        bufferSource.m_109911_();

        guiGraphics.m_280168_().m_85849_();

        // Stack count:
        if (photographsCount > 1) {
            guiGraphics.m_280168_().m_85836_();
            String count = Integer.toString(photographsCount);
            int fontWidth = Minecraft.m_91087_().f_91062_.m_92895_(count);
            float fontScale = 1.6f;
            guiGraphics.m_280168_().m_252880_(
                    mouseX + ExposureClient.getExposureRenderer().getSize() * scale - 2 - fontWidth * fontScale,
                    mouseY + ExposureClient.getExposureRenderer().getSize() * scale - 2 - 8 * fontScale,
                    10);
            guiGraphics.m_280168_().m_85841_(fontScale, fontScale, fontScale);
            guiGraphics.m_280488_(font, count, 0, 0, 0xFFFFFFFF);
            guiGraphics.m_280168_().m_85849_();
        }
    }
}
