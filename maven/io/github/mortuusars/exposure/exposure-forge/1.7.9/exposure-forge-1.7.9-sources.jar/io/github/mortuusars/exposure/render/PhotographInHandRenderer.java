package io.github.mortuusars.exposure.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import io.github.mortuusars.exposure.ExposureClient;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.item.ItemStack;

public class PhotographInHandRenderer {
    public static void renderPhotograph(PoseStack poseStack, MultiBufferSource bufferSource, int combinedLight, ItemStack stack) {
        poseStack.m_252781_(Axis.f_252436_.m_252977_(180.0F));
        poseStack.m_252781_(Axis.f_252403_.m_252977_(180.0F));
        poseStack.m_85841_(0.38f, 0.38f, 0.38f);
        poseStack.m_85837_(-0.5, -0.5, 0);
        float scale = 1f / ExposureClient.getExposureRenderer().getSize();
        poseStack.m_85841_(scale, scale, -scale);

        PhotographRenderer.render(stack, true, false, poseStack, bufferSource,
                combinedLight, 255, 255, 255, 255);
    }
}
