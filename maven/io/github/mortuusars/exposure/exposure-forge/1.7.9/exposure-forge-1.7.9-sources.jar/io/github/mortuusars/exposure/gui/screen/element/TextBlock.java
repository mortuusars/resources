package io.github.mortuusars.exposure.gui.screen.element;

import io.github.mortuusars.exposure.gui.screen.element.textbox.HorizontalAlignment;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.inventory.tooltip.DefaultTooltipPositioner;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;

public class TextBlock extends AbstractWidget {
    public int fontColor = 0xFF000000;
    public boolean drawShadow = false;
    public HorizontalAlignment alignment = HorizontalAlignment.LEFT;

    private final Font font;
    private final Function<Style, Boolean> componentClickedHandler;

    private List<FormattedCharSequence> renderedLines;
    private List<FormattedCharSequence> tooltipLines;

    public TextBlock(Font font, int x, int y, int width, int height, Component message, Function<Style, Boolean> componentClickedHandler) {
        super(x, y, width, height, message);
        this.font = font;
        this.componentClickedHandler = componentClickedHandler;

        makeLines();
    }

    @Override
    public void m_93666_(Component message) {
        super.m_93666_(message);
        makeLines();
    }

    protected void makeLines() {
        Component text = m_6035_();
        List<FormattedCharSequence> lines = font.m_92923_(text, m_5711_());

        int availableLines = Math.min(lines.size(), f_93619_ / font.f_92710_);

        List<FormattedCharSequence> visibleLines = new ArrayList<>();
        for (int i = 0; i < availableLines; i++) {
            FormattedCharSequence line = lines.get(i);

            if (i == availableLines - 1 && availableLines < lines.size()) {
                line = FormattedCharSequence.m_13696_(line,
                        Component.m_237113_("...").m_130948_(text.m_7383_()).m_7532_());
            }

            visibleLines.add(line);
        }

        List<FormattedCharSequence> hiddenLines = Collections.emptyList();
        if (availableLines < lines.size()) {
            hiddenLines = new ArrayList<>(lines.stream()
                    .skip(availableLines)
                    .toList());

            hiddenLines.set(0, FormattedCharSequence.m_13696_(
                    FormattedCharSequence.m_13714_("...", text.m_7383_()), hiddenLines.get(0)));
        }

        this.renderedLines = visibleLines;
        this.tooltipLines = hiddenLines;
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        Style style = getClickedComponentStyleAt(mouseX, mouseY);
        return button == 0 && style != null && componentClickedHandler.apply(style);
    }

    @Override
    protected void m_168797_(NarrationElementOutput narrationElementOutput) {
        narrationElementOutput.m_169146_(NarratedElementType.TITLE, m_5646_());
    }

    @Override
    protected @NotNull MutableComponent m_5646_() {
        return m_6035_().m_6881_();
    }

    @Override
    protected void m_87963_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        for (int i = 0; i < renderedLines.size(); i++) {
            FormattedCharSequence line = renderedLines.get(i);

            int x = m_252754_() + alignment.align(m_5711_(), font.m_92724_(line));
            guiGraphics.m_280649_(font, line, x, m_252907_() + font.f_92710_ * i, fontColor, drawShadow);
        }

        if (m_274382_()) {
            Style style = getClickedComponentStyleAt(mouseX, mouseY);
            if (style != null)
                guiGraphics.m_280304_(this.font, style, mouseX, mouseY);
        }

        if (!tooltipLines.isEmpty() && m_5953_(mouseX, mouseY))
            guiGraphics.m_280547_(font, tooltipLines, DefaultTooltipPositioner.f_262752_, mouseX, mouseY);
    }

    public @Nullable Style getClickedComponentStyleAt(double mouseX, double mouseY) {
        if (renderedLines.isEmpty())
            return null;

        int x = Mth.m_14107_(mouseX - m_252754_());
        int y = Mth.m_14107_(mouseY - m_252907_());

        if (x < 0 || y < 0 || x > m_5711_() || y > m_93694_())
            return null;

        int hoveredLine = y / font.f_92710_;

        if (hoveredLine >= renderedLines.size())
            return null;

        FormattedCharSequence line = renderedLines.get(hoveredLine);
        int lineStart = alignment.align(m_5711_(), font.m_92724_(line));

        if (x < lineStart)
            return null;


        return font.m_92865_().m_92338_(line, x - lineStart);
    }
}
