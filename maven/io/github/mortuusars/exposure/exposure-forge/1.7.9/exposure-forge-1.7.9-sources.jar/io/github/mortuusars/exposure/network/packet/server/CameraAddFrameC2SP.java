package io.github.mortuusars.exposure.network.packet.server;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.item.InterplanarProjectorItem;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public record CameraAddFrameC2SP(InteractionHand hand, CompoundTag frame, List<UUID> entitiesInFrameIds) implements IPacket {
    public static final ResourceLocation ID = Exposure.resource("camera_add_frame");

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    public FriendlyByteBuf toBuffer(FriendlyByteBuf buffer) {
        buffer.m_130068_(hand);
        buffer.m_130079_(frame);
        buffer.writeInt(entitiesInFrameIds.size());
        for (UUID uuid : entitiesInFrameIds) {
            buffer.m_130077_(uuid);
        }
        return buffer;
    }

    public static CameraAddFrameC2SP fromBuffer(FriendlyByteBuf buffer) {
        InteractionHand hand = buffer.m_130066_(InteractionHand.class);
        @Nullable CompoundTag frame = buffer.m_130261_();
        if (frame == null)
            frame = new CompoundTag();

        int entitiesCount = buffer.readInt();
        List<UUID> entities = new ArrayList<>();
        for (int i = 0; i < entitiesCount; i++) {
            entities.add(buffer.m_130259_());
        }

        return new CameraAddFrameC2SP(hand, frame, entities);
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable Player player) {
        Preconditions.checkState(player != null, "Cannot handle packet: Player was null");
        ServerPlayer serverPlayer = ((ServerPlayer) player);

        Camera.getCamera(player).ifPresentOrElse(camera -> {
            CameraItem cameraItem = camera.get().getItem();
            cameraItem.addFrame(serverPlayer, camera.get().getStack(), frame, getEntities(serverPlayer.m_284548_()));
        }, () -> Exposure.LOGGER.error("Cannot add frame. Player is not using a Camera."));

        ItemStack cameraStack = player.m_21120_(hand);
        if (!(cameraStack.m_41720_() instanceof CameraItem cameraItem))
            throw new IllegalStateException("Item in hand in not a Camera.");

        if (frame.m_128471_(FrameData.PROJECTED)) {
            cameraItem.getAttachment(cameraStack, CameraItem.FILTER_ATTACHMENT).ifPresent(filter -> {
                if (filter.m_41720_() instanceof InterplanarProjectorItem interplanarProjector) {
                    player.m_9236_().m_6269_(player, player, Exposure.SoundEvents.INTERPLANAR_PROJECT.get(),
                            SoundSource.PLAYERS, 0.8f, 1f);

                    if (interplanarProjector.isConsumable(filter)) {
                        filter.m_41774_(1);
                        cameraItem.setAttachment(cameraStack, CameraItem.FILTER_ATTACHMENT, filter);
                    }
                }
            });
        }
        return true;
    }

    private List<Entity> getEntities(ServerLevel level) {
        List<Entity> entitiesInFrame = new ArrayList<>();
        for (UUID uuid : entitiesInFrameIds) {
            @Nullable Entity entity = level.m_8791_(uuid);
            if (entity != null)
                entitiesInFrame.add(entity);
        }
        return entitiesInFrame;
    }
}
