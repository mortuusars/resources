package io.github.mortuusars.exposure.item;

import io.github.mortuusars.exposure.entity.PhotographFrameEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;
import org.jetbrains.annotations.NotNull;

public class PhotographFrameItem extends Item {
    public PhotographFrameItem(Properties properties) {
        super(properties);
    }

    @Override
    public @NotNull InteractionResult m_6225_(UseOnContext context) {
        BlockPos clickedPos = context.m_8083_();
        Direction direction = context.m_43719_();
        BlockPos resultPos = clickedPos.m_121945_(direction);
        Player player = context.m_43723_();
        ItemStack itemInHand = context.m_43722_();
        if (player == null || player.m_9236_().m_151570_(resultPos) || !player.m_36204_(resultPos, direction, itemInHand))
            return InteractionResult.FAIL;

        Level level = context.m_43725_();
        PhotographFrameEntity photographEntity = new PhotographFrameEntity(level, resultPos, direction);

        CompoundTag compoundTag = itemInHand.m_41783_();
        if (compoundTag != null) {
            EntityType.m_20620_(level, player, photographEntity, compoundTag);
        }

        for (int i = 2; i >= 0; i--) {
            photographEntity.setSize(i);
            if (photographEntity.m_7088_()) {
                if (!level.f_46443_) {
                    photographEntity.m_7084_();
                    level.m_220400_(player, GameEvent.f_157810_, photographEntity.m_20182_());
                    level.m_7967_(photographEntity);
                }

                photographEntity.setFrameItem((player.m_7500_() ? itemInHand.m_41777_() : itemInHand).m_41620_(1));

                return InteractionResult.m_19078_(level.f_46443_);
            }
        }

        return InteractionResult.FAIL;
    }
}
