package io.github.mortuusars.exposure.gui.screen;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.mortuusars.exposure.camera.infrastructure.ZoomDirection;
import io.github.mortuusars.exposure.gui.screen.element.ZoomHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.NotNull;

public abstract class ZoomableScreen extends Screen {
    protected final ZoomHandler zoom = new ZoomHandler();
    protected float zoomFactor = 1f;
    protected float scale = 1f;
    protected float x;
    protected float y;

    @NotNull
    protected final Minecraft f_96541_ = Minecraft.m_91087_();

    protected ZoomableScreen(Component title) {
        super(title);
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        zoom.update(partialTick);
        scale = zoom.get() * zoomFactor;
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        boolean handled = super.m_7933_(keyCode, scanCode, modifiers);
        if (handled)
            return true;

        if (f_96541_.f_91066_.f_92092_.m_90832_(keyCode, scanCode))
            this.m_7379_();
        else if (keyCode == InputConstants.f_166281_ || keyCode == InputConstants.f_166285_)
            zoom.change(ZoomDirection.IN);
        else if (keyCode == 333 /*KEY_SUBTRACT*/ || keyCode == InputConstants.f_166288_)
            zoom.change(ZoomDirection.OUT);
        else
            return false;

        return true;
    }

    @Override
    public boolean m_6050_(double mouseX, double mouseY, double delta) {
        boolean handled = super.m_6050_(mouseX, mouseY, delta);

        if (!handled) {
            zoom.change(delta >= 0.0 ? ZoomDirection.IN : ZoomDirection.OUT);
            return true;
        }

        return true;
    }

    @Override
    public boolean m_7979_(double mouseX, double mouseY, int button, double dragX, double dragY) {
        boolean handled = super.m_7979_(mouseX, mouseY, button, dragX, dragY);

        if (!handled && button == 0) { // Left Click
            float centerX = f_96543_ / 2f;
            float centerY = f_96544_ / 2f;

            x = (float) Mth.m_14008_(x + dragX, -centerX, centerX);
            y = (float) Mth.m_14008_(y + dragY, -centerY, centerY);
            handled = true;
        }

        return handled;
    }
}
