package io.github.mortuusars.exposure.gui.screen.album;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.gui.screen.element.Pager;
import io.github.mortuusars.exposure.gui.screen.element.TextBlock;
import io.github.mortuusars.exposure.gui.screen.element.textbox.HorizontalAlignment;
import io.github.mortuusars.exposure.gui.screen.element.textbox.TextBox;
import io.github.mortuusars.exposure.item.AlbumPage;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.menu.AlbumMenu;
import io.github.mortuusars.exposure.menu.AlbumPlayerInventorySlot;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.server.AlbumSyncNoteC2SP;
import io.github.mortuusars.exposure.util.ItemAndStack;
import io.github.mortuusars.exposure.util.PagingDirection;
import io.github.mortuusars.exposure.util.Side;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;

public class AlbumScreen extends AbstractContainerScreen<AlbumMenu> {
    
    public static final ResourceLocation TEXTURE = Exposure.resource("textures/gui/album.png");
    public static final int MAIN_FONT_COLOR = 0xFFB59774;
    public static final int SECONDARY_FONT_COLOR = 0xFFEFE4CA;
    public static final int SELECTION_COLOR = 0xFF8888FF;
    public static final int SELECTION_UNFOCUSED_COLOR = 0xFFBBBBFF;

    @NotNull
    protected final Minecraft minecraft;
    @NotNull
    protected final Player player;
    @NotNull
    protected final MultiPlayerGameMode gameMode;

    protected final Pager pager = new Pager(SoundEvents.f_11713_) {
        @Override
        public void onPageChanged(PagingDirection pagingDirection, int prevPage, int currentPage) {
            super.onPageChanged(pagingDirection, prevPage, currentPage);
            sendButtonClick(pagingDirection == PagingDirection.PREVIOUS ? AlbumMenu.PREVIOUS_PAGE_BUTTON : AlbumMenu.NEXT_PAGE_BUTTON);
        }
    };

    protected final List<Page> pages = new ArrayList<>();

    @Nullable
    protected Button enterSignModeButton;

    public AlbumScreen(AlbumMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
        f_96541_ = Minecraft.m_91087_();
        player = Objects.requireNonNull(f_96541_.f_91074_);
        gameMode = Objects.requireNonNull(f_96541_.f_91072_);
    }

    @Override
    protected void m_181908_() {
        forEachPage(page -> page.noteWidget.ifLeft(TextBox::tick));
    }

    @Override
    protected void m_7856_() {
        this.f_97726_ = 298;
        this.f_97727_ = 188;
        super.m_7856_();

        f_97729_ = -999;
        f_97730_ = 69;
        f_97731_ = -999;

        pages.clear();

        // LEFT:
        Page leftPage = createPage(Side.LEFT, 0);
        pages.add(leftPage);

        ImageButton previousButton = new ImageButton(f_97735_ + 12, f_97736_ + 164, 13, 15,
                216, 188, 15, TEXTURE, 512, 512,
                button -> pager.changePage(PagingDirection.PREVIOUS), Component.m_237115_("gui.exposure.previous_page"));
        previousButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.exposure.previous_page")));
        m_142416_(previousButton);

        // RIGHT:
        Page rightPage = createPage(Side.RIGHT, 140);
        pages.add(rightPage);

        ImageButton nextButton = new ImageButton(f_97735_ + 273, f_97736_ + 164, 13, 15,
                229, 188, 15, TEXTURE, 512, 512,
                button -> pager.changePage(PagingDirection.NEXT), Component.m_237115_("gui.exposure.next_page"));
        nextButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.exposure.next_page")));
        m_142416_(nextButton);

        // MISC:
        if (m_6262_().isAlbumEditable()) {
            enterSignModeButton = new ImageButton(f_97735_ - 23, f_97736_ + 17, 22, 22, 242, 188,
                    22, TEXTURE, 512, 512,
                    b -> enterSignMode(), Component.m_237115_("gui.exposure.album.sign"));
            enterSignModeButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.exposure.album.sign")));
            m_142416_(enterSignModeButton);
        }

        int spreadsCount = (int) Math.ceil(m_6262_().getPages().size() / 2f);
        pager.init(spreadsCount, false, previousButton, nextButton);
    }

    protected Page createPage(Side side, int xOffset) {
        int x = f_97735_ + xOffset;
        int y = f_97736_;

        Rect2i page = new Rect2i(x, y, 149, 188);
        Rect2i photo = new Rect2i(x + 25, y + 21, 108, 108);
        Rect2i exposure = new Rect2i(x + 31, y + 27, 96, 96);
        Rect2i note = new Rect2i(x + 22, y + 133, 114, 27);

        PhotographSlotButton photographButton = new PhotographSlotButton(exposure, photo.m_110085_(), photo.m_110086_(),
                photo.m_110090_(), photo.m_110091_(), 0, 188, 108, TEXTURE, 512, 512,
                b -> {
                    PhotographSlotButton button = (PhotographSlotButton) b;
                    ItemStack photograph = button.getPhotograph();
                    if (photograph.m_41619_()) {
                        if (button.isEditable) {
                            sendButtonClick(side == Side.LEFT ? AlbumMenu.LEFT_PAGE_PHOTO_BUTTON : AlbumMenu.RIGHT_PAGE_PHOTO_BUTTON);
                            button.m_7435_(f_96541_.m_91106_());
                        }
                    } else
                        inspectPhotograph(photograph);
                },
                b -> {
                    PhotographSlotButton button = (PhotographSlotButton) b;
                    if (button.isEditable && !button.getPhotograph().m_41619_()) {
                        sendButtonClick(side == Side.LEFT ? AlbumMenu.LEFT_PAGE_PHOTO_BUTTON : AlbumMenu.RIGHT_PAGE_PHOTO_BUTTON);
                        f_96541_.m_91106_().m_120367_(SimpleSoundInstance.m_119755_(
                                Exposure.SoundEvents.PHOTOGRAPH_PLACE.get(), 0.7f, 1.1f));
                    }
                }, () -> m_6262_().getPhotograph(side), m_6262_().isAlbumEditable()) {
            @Override
            public boolean m_6375_(double mouseX, double mouseY, int button) {
                return !isInAddingMode() && super.m_6375_(mouseX, mouseY, button);
            }

            @Override
            public boolean m_274382_() {
                return !isInAddingMode() && super.m_274382_();
            }
        };
        m_142416_(photographButton);

        Either<TextBox, TextBlock> noteWidget;
        if (m_6262_().isAlbumEditable()) {
            TextBox textBox = new TextBox(f_96547_, note.m_110085_(), note.m_110086_(), note.m_110090_(), note.m_110091_(),
                    () -> m_6262_().getPage(side).map(p -> p.getNote().left().orElseThrow()).orElse(""),
                    text -> onNoteChanged(side, text))
                    .setFontColor(MAIN_FONT_COLOR, MAIN_FONT_COLOR)
                    .setSelectionColor(SELECTION_COLOR, SELECTION_UNFOCUSED_COLOR);
            textBox.horizontalAlignment = HorizontalAlignment.CENTER;
            m_142416_(textBox);
            noteWidget = Either.left(textBox);
        } else {
            TextBlock textBlock = new TextBlock(f_96547_, note.m_110085_(), note.m_110086_(),
                    note.m_110090_(), note.m_110091_(), getNoteComponent(side), this::m_5561_);
            textBlock.fontColor = MAIN_FONT_COLOR;
            textBlock.alignment = HorizontalAlignment.CENTER;
            textBlock.drawShadow = false;

            //  TextBlock is rendered manually to not be a part of TAB navigation.
            //  addRenderableWidget(textBlock);

            noteWidget = Either.right(textBlock);
        }

        return new Page(side, page, photo, exposure, note, photographButton, noteWidget);
    }

    protected void onNoteChanged(Side side, String noteText) {
        m_6262_().getPage(side).ifPresent(page -> {
            page.setNote(Either.left(noteText));
            int pageIndex = m_6262_().getCurrentSpreadIndex() * 2 + side.getIndex();
            Packets.sendToServer(new AlbumSyncNoteC2SP(pageIndex, noteText));
        });
    }

    
    // RENDER
    
    @Override
    public void m_88315_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        pager.update();

        if (enterSignModeButton != null)
            enterSignModeButton.f_93624_ = m_6262_().canSignAlbum();

        boolean isInAddingPhotographMode = isInAddingMode();

        // Note should be hidden when adding photograph because it's drawn over the slots. Blit offset does not help.
        forEachPage(page -> page.getNoteWidget().f_93624_ = !isInAddingPhotographMode);

        for (Page page : pages) {
            page.photographButton.f_93624_ = !m_6262_().getPhotograph(page.side).m_41619_()
                    || (!isInAddingPhotographMode && m_6262_().isAlbumEditable());
        }

        f_97731_ = isInAddingPhotographMode ? m_6262_().getPlayerInventorySlots().get(0).f_40221_ - 12 : -999;

        this.m_280273_(guiGraphics);
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);

        for (Page page : pages) {
            AbstractWidget noteWidget = page.getNoteWidget();
            if (noteWidget instanceof TextBlock textBlock) {
                textBlock.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
            }
        }

        if (isInAddingPhotographMode) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            for (Slot slot : m_6262_().f_38839_) {
                if (!slot.m_7993_().m_41619_() && !(slot.m_7993_().m_41720_() instanceof PhotographItem)) {
                    guiGraphics.m_280398_(TEXTURE, f_97735_ + slot.f_40220_ - 1, f_97736_ + slot.f_40221_ - 1, 350, 176, 404,
                            18, 18, 512, 512);
                }
            }
            RenderSystem.disableBlend();
        }

        this.m_280072_(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void m_280003_(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        guiGraphics.m_280168_().m_85836_();
        guiGraphics.m_280168_().m_252880_(0, 0, 15);
        super.m_280003_(guiGraphics, mouseX, mouseY);

        guiGraphics.m_280168_().m_85849_();
    }

    @Override
    protected void m_280072_(GuiGraphics guiGraphics, int x, int y) {
        if (isInAddingMode() && f_97734_ != null && !f_97734_.m_7993_()
                .m_41619_() && !(f_97734_.m_7993_().m_41720_() instanceof PhotographItem))
            return; // Do not onRender tooltips for greyed-out items

        if (!isInAddingMode()) {
            for (Page page : pages) {
                if (page.photographButton.m_198029_()) {
                    page.photographButton.renderTooltip(guiGraphics, x, y);
                    return;
                }

                if (m_6262_().isAlbumEditable() && page.isMouseOver(page.noteArea, x, y)) {
                    List<Component> tooltip = new ArrayList<>();
                    tooltip.add(Component.m_237115_("gui.exposure.album.note"));

                    if (!page.getNoteWidget().m_93696_())
                        tooltip.add(Component.m_237115_("gui.exposure.album.left_click_to_edit"));

                    boolean hasText = page.noteWidget.left().map(box -> !box.getText().isEmpty()).orElse(false);
                    if (hasText)
                        tooltip.add(Component.m_237115_("gui.exposure.album.right_click_to_clear"));

                    guiGraphics.m_280677_(this.f_96547_, tooltip, Optional.empty(), x, y);

                    return;
                }
            }
        }

        super.m_280072_(guiGraphics, x, y);
    }

    @Override
    protected @NotNull List<Component> m_280553_(ItemStack stack) {
        List<Component> tooltipLines = super.m_280553_(stack);
        if (isInAddingMode() && f_97734_ != null && f_97734_.m_7993_() == stack
                && stack.m_41720_() instanceof PhotographItem) {
            tooltipLines.add(Component.m_237119_());
            tooltipLines.add(Component.m_237115_("gui.exposure.album.left_click_to_add"));
        }
        return tooltipLines;
    }

    @Override
    protected void m_7286_(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShader(GameRenderer::m_172817_);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.m_280398_(TEXTURE, f_97735_, f_97736_, 0, 0, 0,
                f_97726_, f_97727_, 512, 512);

        if (enterSignModeButton != null && enterSignModeButton.f_93624_) {
            guiGraphics.m_280163_(TEXTURE, f_97735_ - 27, f_97736_ + 14, 447, 0,
                    27, 28, 512, 512);
        }

        int currentSpreadIndex = m_6262_().getCurrentSpreadIndex();
        drawPageNumbers(guiGraphics, currentSpreadIndex);

        if (isInAddingMode()) {
            @Nullable Side pageBeingAddedTo = m_6262_().getSideBeingAddedTo();
            for (Page page : pages) {
                if (page.side == pageBeingAddedTo) {
                    guiGraphics.m_280398_(TEXTURE, page.photoArea.m_110085_(), page.photoArea.m_110086_(), 10, 0, 296,
                            page.photoArea.m_110090_(), page.photoArea.m_110091_(), 512, 512);
                    break;
                }
            }

            AlbumPlayerInventorySlot firstSlot = m_6262_().getPlayerInventorySlots().get(0);
            int x = firstSlot.f_40220_ - 8;
            int y = firstSlot.f_40221_ - 18;
            guiGraphics.m_280398_(TEXTURE, f_97735_ + x, f_97736_ + y, 10, 0, 404, 176, 100, 512, 512);
        }
    }

    protected void drawPageNumbers(GuiGraphics guiGraphics, int currentSpreadIndex) {
        Font font = f_96541_.f_91062_;

        String leftPageNumber = Integer.toString(currentSpreadIndex * 2 + 1);
        String rightPageNumber = Integer.toString(currentSpreadIndex * 2 + 2);

        guiGraphics.m_280056_(font, leftPageNumber, f_97735_ + 71 + (8 - font.m_92895_(leftPageNumber) / 2),
                f_97736_ + 167, SECONDARY_FONT_COLOR, false);

        guiGraphics.m_280056_(font, rightPageNumber, f_97735_ + 212 + (8 - font.m_92895_(rightPageNumber) / 2),
                f_97736_ + 167, SECONDARY_FONT_COLOR, false);
    }


    // CONTROLS:

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        if (isInAddingMode()) {
            if (!isHoveringOverInventory(mouseX, mouseY)
                && (!m_7467_(mouseX, mouseY, f_97735_, f_97736_, button) || m_6262_().m_142621_().m_41619_())) {
                sendButtonClick(AlbumMenu.CANCEL_ADDING_PHOTO_BUTTON);
                return true;
            }

            return super.m_6375_(mouseX, mouseY, button);
        }

        for (Page page : pages) {
            if (m_6262_().isAlbumEditable() && button == InputConstants.f_166349_ && page.isMouseOver(page.noteArea, mouseX, mouseY)) {
                page.noteWidget.ifLeft(box -> {
                    box.setText(""); // Clear the note
                });
                return true;
            }
        }

        boolean handled = super.m_6375_(mouseX, mouseY, button);

        for (Page page : pages) {
            AbstractWidget noteWidget = page.getNoteWidget();
            if (noteWidget instanceof TextBlock textBlock && textBlock.m_6375_(mouseX, mouseY, button)) {
                handled = true;
                break;
            }
        }

        for (Page page : pages) {
            if (page.getNoteWidget().m_93696_() && !page.isMouseOver(page.noteArea, mouseX, mouseY)) {
                m_7522_(null);
                return true;
            }
        }

        if (!(m_7222_() instanceof TextBox))
            m_7522_(null); // Clear focus on mouse click because it's annoying. But keep on textbox to type.

        return handled;
    }

    @Override
    public boolean m_6348_(double mouseX, double mouseY, int button) {
        if (f_97738_ && !m_6262_().m_142621_().m_41619_() && m_6262_().m_142621_().m_41613_() == 1) {
            f_97738_ = false; // Fixes weird issue with carried item not placing when dragging slightly
        }

        return super.m_6348_(mouseX, mouseY, button);
    }

    @Override
    public boolean m_5561_(@Nullable Style style) {
        if (style == null)
            return false;

        ClickEvent clickEvent = style.m_131182_();
        if (clickEvent == null)
            return false;
        else if (clickEvent.m_130622_() == ClickEvent.Action.CHANGE_PAGE) {
            String pageIndexStr = clickEvent.m_130623_();
            int pageIndex = Integer.parseInt(pageIndexStr) - 1;
            forcePage(pageIndex);
            return true;
        }

        boolean handled = super.m_5561_(style);
        if (handled && clickEvent.m_130622_() == ClickEvent.Action.RUN_COMMAND)
            m_7379_();
        return handled;
    }

    @Override
    public boolean m_7979_(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (isInAddingMode())
            return super.m_7979_(mouseX, mouseY, button, dragX, dragY);
        else
            return this.m_7222_() != null && this.m_7282_() && button == 0
                    && this.m_7222_().m_7979_(mouseX, mouseY, button, dragX, dragY);
    }

    protected void sendButtonClick(int buttonId) {
        m_6262_().m_6366_(player, buttonId);
        gameMode.m_105208_(m_6262_().f_38840_, buttonId);

        if (buttonId == AlbumMenu.CANCEL_ADDING_PHOTO_BUTTON)
            m_7522_(null);

        if (buttonId == AlbumMenu.PREVIOUS_PAGE_BUTTON || buttonId == AlbumMenu.NEXT_PAGE_BUTTON) {
            for (Page page : pages) {
                page.noteWidget
                        .ifLeft(TextBox::setCursorToEnd)
                        .ifRight(textBlock -> textBlock.m_93666_(getNoteComponent(page.side)));
            }
        }
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    protected boolean isHoveringOverInventory(double mouseX, double mouseY) {
        if (!isInAddingMode())
            return false;

        AlbumPlayerInventorySlot firstSlot = m_6262_().getPlayerInventorySlots().get(0);
        int x = firstSlot.f_40220_ - 8;
        int y = firstSlot.f_40221_ - 18;
        return m_6774_(x, y, 176, 100, mouseX, mouseY);
    }

    protected boolean isHoveringOverSignElement(double mouseX, double mouseY) {
        return enterSignModeButton == null
                || (enterSignModeButton.f_93624_ && m_6774_(f_97735_ - 27, f_97736_ + 14, 27, 28, mouseX, mouseY));
    }

    @Override
    protected boolean m_7467_(double mouseX, double mouseY, int guiLeft, int guiTop, int mouseButton) {
        return super.m_7467_(mouseX, mouseY, guiLeft, guiTop, mouseButton)
                && !isHoveringOverInventory(mouseX, mouseY)
                && !isHoveringOverSignElement(mouseX, mouseY);
    }

    @SuppressWarnings("UnusedReturnValue")
    protected boolean forcePage(int pageIndex) {
        try {
            int newSpreadIndex = pageIndex / 2;

            if (newSpreadIndex == m_6262_().getCurrentSpreadIndex() || newSpreadIndex < 0
                    || newSpreadIndex > m_6262_().getPages().size() / 2) {
                return false;
            }

            PagingDirection pagingDirection = newSpreadIndex < m_6262_().getCurrentSpreadIndex()
                    ? PagingDirection.PREVIOUS : PagingDirection.NEXT;

            int pageChanges = 0; // Safeguard against infinite loop. Probably not needed. But I don't mind it.
            while (newSpreadIndex != m_6262_().getCurrentSpreadIndex() || !pager.canChangePage(pagingDirection)) {
                if (pageChanges > 16)
                    break;

                pager.changePage(pagingDirection);
                pageChanges++;
            }
            return true;
        } catch (Exception e) {
            Exposure.LOGGER.error("Cannot force page: {}", e.toString());
        }
        return false;
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (keyCode == InputConstants.f_166295_)
            return super.m_7933_(keyCode, scanCode, modifiers);

        for (Page page : pages) {
            AbstractWidget widget = page.noteWidget.map(box -> box, block -> block);
            if (widget.m_93696_()) {
                if (keyCode == InputConstants.f_166305_) {
                    this.m_7522_(null);
                    return true;
                }

                return widget.m_7933_(keyCode, scanCode, modifiers);
            }
        }

        if (isInAddingMode() && (f_96541_.f_91066_.f_92092_.m_90832_(keyCode, scanCode)
                || keyCode == InputConstants.f_166305_)) {
            sendButtonClick(AlbumMenu.CANCEL_ADDING_PHOTO_BUTTON);
            return true;
        }

        return pager.handleKeyPressed(keyCode, scanCode, modifiers) || super.m_7933_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_7920_(int keyCode, int scanCode, int modifiers) {
        for (Page page : pages) {
            if (page.noteWidget.map(box -> box, block -> block).m_93696_())
                return super.m_7920_(keyCode, scanCode, modifiers);
        }

        return pager.handleKeyReleased(keyCode, scanCode, modifiers) || super.m_7920_(keyCode, scanCode, modifiers);
    }


    // MISC:
    
    protected void inspectPhotograph(ItemStack photograph) {
        if (!(photograph.m_41720_() instanceof PhotographItem))
            return;

        f_96541_.m_91152_(new AlbumPhotographScreen(this, List.of(new ItemAndStack<>(photograph))));
        f_96541_.m_91106_()
                .m_120367_(SimpleSoundInstance.m_119755_(Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(),
                        player.m_9236_().m_213780_().m_188501_() * 0.2f + 1.3f, 0.75f));
    }

    @NotNull
    protected Component getNoteComponent(Side page) {
        return m_6262_().getPage(page)
                .map(AlbumPage::getNote)
                .map(n -> n.map(Component::m_237113_, comp -> comp))
                .orElse(Component.m_237119_());
    }

    protected void enterSignMode() {
        if (isInAddingMode())
            sendButtonClick(AlbumMenu.CANCEL_ADDING_PHOTO_BUTTON);

        f_96541_.m_91152_(new AlbumSigningScreen(this, TEXTURE, 512, 512));
    }

    protected boolean isInAddingMode() {
        return m_6262_().isInAddingPhotographMode();
    }
    
    protected void forEachPage(Consumer<Page> pageAction) {
        for (Page page : pages) {
            pageAction.accept(page);
        }
    }

    protected class Page {
        public final Side side;
        public final Rect2i pageArea;
        public final Rect2i photoArea;
        public final Rect2i exposureArea;
        public final Rect2i noteArea;

        public final PhotographSlotButton photographButton;
        public final Either<TextBox, TextBlock> noteWidget;

        private Page(Side side, Rect2i pageArea, Rect2i photoArea, Rect2i exposureArea, Rect2i noteArea,
                     PhotographSlotButton photographButton, Either<TextBox, TextBlock> noteWidget) {
            this.side = side;
            this.pageArea = pageArea;
            this.photoArea = photoArea;
            this.exposureArea = exposureArea;
            this.noteArea = noteArea;
            this.photographButton = photographButton;
            this.noteWidget = noteWidget;
        }

        public boolean isMouseOver(Rect2i area, double mouseX, double mouseY) {
            return m_6774_(area.m_110085_() - f_97735_, area.m_110086_() - f_97736_,
                    area.m_110090_(), area.m_110091_(), mouseX, mouseY);
        }

        public AbstractWidget getNoteWidget() {
            return noteWidget.map(box -> box, block -> block);
        }
    }
}
