package io.github.mortuusars.exposure.entity;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.item.PhotographItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.decoration.HangingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DiodeBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.apache.commons.lang3.Validate;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class PhotographFrameEntity extends HangingEntity {
    public static final Logger LOGGER = Exposure.LOGGER;

    protected static final EntityDataAccessor<Integer> DATA_SIZE = SynchedEntityData.m_135353_(PhotographFrameEntity.class, EntityDataSerializers.f_135028_);
    protected static final EntityDataAccessor<ItemStack> DATA_FRAME_ITEM = SynchedEntityData.m_135353_(PhotographFrameEntity.class, EntityDataSerializers.f_135033_);
    protected static final EntityDataAccessor<ItemStack> DATA_ITEM = SynchedEntityData.m_135353_(PhotographFrameEntity.class, EntityDataSerializers.f_135033_);
    protected static final EntityDataAccessor<Integer> DATA_ITEM_ROTATION = SynchedEntityData.m_135353_(PhotographFrameEntity.class, EntityDataSerializers.f_135028_);
    protected static final EntityDataAccessor<Boolean> DATA_GLOWING = SynchedEntityData.m_135353_(PhotographFrameEntity.class, EntityDataSerializers.f_135035_);
    protected static final EntityDataAccessor<Boolean> DATA_STRIPPED = SynchedEntityData.m_135353_(PhotographFrameEntity.class, EntityDataSerializers.f_135035_);

    protected int size = 0;

    public PhotographFrameEntity(EntityType<? extends PhotographFrameEntity> entityType, Level level) {
        super(entityType, level);
    }

    public PhotographFrameEntity(Level level, BlockPos pos, Direction facingDirection) {
        super(Exposure.EntityTypes.PHOTOGRAPH_FRAME.get(), level, pos);
        m_6022_(facingDirection);
        setItem(ItemStack.f_41583_);
    }

    @Override
    public boolean m_6783_(double distance) {
        double d = Config.Client.PHOTOGRAPH_FRAME_CULLING_DISTANCE.get() * m_20150_();
        return distance < d * d;
    }

    protected void m_8097_() {
        m_20088_().m_135372_(DATA_SIZE, 0);
        m_20088_().m_135372_(DATA_FRAME_ITEM, ItemStack.f_41583_);
        m_20088_().m_135372_(DATA_ITEM, ItemStack.f_41583_);
        m_20088_().m_135372_(DATA_ITEM_ROTATION, 0);
        m_20088_().m_135372_(DATA_STRIPPED, false);
        m_20088_().m_135372_(DATA_GLOWING, false);
    }

    public void m_7350_(EntityDataAccessor<?> key) {
        if (key.equals(DATA_ITEM)) {
            onItemChanged(getItem());
        }
        if (key.equals(DATA_SIZE)) {
            size = m_20088_().m_135370_(DATA_SIZE);
            m_7087_();
        }
    }

    @Override
    public void m_141965_(@NotNull ClientboundAddEntityPacket packet) {
        super.m_141965_(packet);
        int packedData = packet.m_131509_();
        int size = (packedData >> 8) & 0xFF;
        int direction = packedData & 0xFF;
        setSize(size);
        m_6022_(Direction.m_122376_(direction));
    }

    @Override
    public @NotNull Packet<ClientGamePacketListener> m_5654_() {
        int packedData = (size << 8) | f_31699_.m_122411_();
        return new ClientboundAddEntityPacket(this, packedData, this.m_31748_());
    }

    public void m_7380_(@NotNull CompoundTag tag) {
        super.m_7380_(tag);
        ItemStack item = getItem();
        if (!item.m_41619_()) {
            tag.m_128365_("Item", item.m_41739_(new CompoundTag()));
            tag.m_128379_("IsGlowing", this.isGlowing()); // "Glowing" is used in vanilla
            tag.m_128344_("ItemRotation", (byte) this.getItemRotation());
        }
        ItemStack frameItem = getFrameItem();
        if (!frameItem.m_41619_())
            tag.m_128365_("FrameItem", frameItem.m_41739_(new CompoundTag()));

        tag.m_128344_("Size", (byte) getSize());
        tag.m_128344_("Facing", (byte) f_31699_.m_122411_());
        tag.m_128379_("Stripped", isStripped());
        tag.m_128379_("Invisible", m_20145_());
    }

    public void m_7378_(@NotNull CompoundTag tag) {
        super.m_7378_(tag);
        CompoundTag frameItemTag = tag.m_128469_("FrameItem");
        if (!frameItemTag.m_128456_()) {
            ItemStack itemstack = ItemStack.m_41712_(frameItemTag);
            if (itemstack.m_41619_()) {
                Exposure.LOGGER.warn("Unable to load frame item from: {}", frameItemTag);
                itemstack = new ItemStack(Exposure.Items.PHOTOGRAPH_FRAME.get());
            }

            setFrameItem(itemstack);
        }

        CompoundTag itemTag = tag.m_128469_("Item");
        if (!itemTag.m_128456_()) {
            ItemStack itemstack = ItemStack.m_41712_(itemTag);
            if (itemstack.m_41619_())
                Exposure.LOGGER.warn("Unable to load item from: {}", itemTag);

            setItem(itemstack);
            setGlowing(tag.m_128471_("IsGlowing")); // "Glowing" is used in vanilla
            setItemRotation(tag.m_128445_("ItemRotation"));
        }

        setSize(tag.m_128445_("Size"));
        m_6022_(Direction.m_122376_(tag.m_128445_("Facing")));
        setStripped(tag.m_128471_("Stripped"));
        m_6842_(tag.m_128471_("Invisible"));
    }

    @Override
    public @NotNull Vec3 m_213870_() {
        return Vec3.m_82528_(this.f_31698_);
    }

    @Override
    protected float m_6380_(@NotNull Pose pose, @NotNull EntityDimensions dimensions) {
        return 0f;
    }

    @Override
    public int m_7076_() {
        return getSize() * 16 + 16;
    }

    @Override
    public int m_7068_() {
        return getSize() * 16 + 16;
    }

    @Nullable
    @Override
    public ItemStack m_142340_() {
        ItemStack item = getItem();
        if (!item.m_41619_())
            return item.m_41777_();

        return getFrameItem().m_41777_();
    }

    @Override
    protected void m_7087_() {
        //noinspection ConstantValue
        if (this.f_31699_ == null)
            return;

        double x = (double)this.f_31698_.m_123341_() + 0.5;
        double y = (double)this.f_31698_.m_123342_() + 0.5;
        double z = (double)this.f_31698_.m_123343_() + 0.5;

        double widthOffset = m_7076_() % 32 == 0 ? 0.5 : 0.0;
        double heightOffset = m_7068_() % 32 == 0 ? 0.5 : 0.0;
        if (getSize() == 2) {
            widthOffset += 1;
            heightOffset += 1;
        }

        double hangOffset = 0.46875;

        if (m_6350_().m_122434_().m_122479_()) {
            x -= m_6350_().m_122429_() * hangOffset;
            z -= m_6350_().m_122431_() * hangOffset;
            Direction direction = m_6350_().m_122428_();
            m_20343_(x += widthOffset * (double)direction.m_122429_(), y += heightOffset, z += widthOffset * (double)direction.m_122431_());
            double xSize = this.m_7076_();
            double ySize = this.m_7068_();
            double zSize = this.m_7076_();
            if (m_6350_().m_122434_() == Direction.Axis.Z)
                zSize = 1.0;
            else
                xSize = 1.0;
            m_20011_(new AABB(x - (xSize /= 32.0), y - (ySize /= 32.0), z - (zSize /= 32.0), x + xSize, y + ySize, z + zSize));
        }
        else {
            y -= m_6350_().m_122430_() * hangOffset;
            m_20343_(x += widthOffset, y, z -= heightOffset);
            double xSize = m_7076_();
            double zSize = m_7068_();
            m_20011_(new AABB(x - (xSize /= 32.0), y - (1.0 / 32.0), z - (zSize /= 32.0), x + xSize, y + 1.0 / 32.0, z + zSize));
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public boolean m_7088_() {
        if (!m_9236_().m_45786_(this))
            return false;

        int sizeX = Math.max(1, m_7076_() / 16);
        int sizeY = Math.max(1, m_7068_() / 16);
        BlockPos baseBlockPos = f_31698_.m_121945_(f_31699_.m_122424_());

        if (m_6350_().m_122434_().m_122479_()) {
            Direction direction = m_6350_().m_122428_();
            BlockPos.MutableBlockPos mPos = new BlockPos.MutableBlockPos();
            for (int pX = 0; pX < sizeX; ++pX) {
                for (int pY = 0; pY < sizeY; ++pY) {
                    mPos.m_122190_(baseBlockPos).m_122175_(direction, pX).m_122175_(Direction.UP, pY);
                    BlockState blockState = m_9236_().m_8055_(mPos);
                    if (blockState.m_280296_() || DiodeBlock.m_52586_(blockState)) continue;
                    return false;
                }
            }
        } else {
            BlockPos.MutableBlockPos mPos = new BlockPos.MutableBlockPos();
            for (int pX = 0; pX < sizeX; ++pX) {
                for (int pY = 0; pY < sizeY; ++pY) {
                    mPos.m_122190_(baseBlockPos).m_122175_(Direction.NORTH, pX).m_122175_(Direction.EAST, pY);
                    BlockState blockState = m_9236_().m_8055_(mPos);
                    if (blockState.m_280296_() || DiodeBlock.m_52586_(blockState)) continue;
                    return false;
                }
            }
        }

        return m_9236_().m_6249_(this, m_20191_(), f_31697_).isEmpty();
    }

    @Override
    protected void m_6022_(@NotNull Direction facingDirection) {
        Validate.notNull(facingDirection);

        f_31699_ = facingDirection;
        if (facingDirection.m_122434_().m_122479_()) {
            m_146926_(0.0f);
            m_146922_(f_31699_.m_122416_() * 90);
        } else {
            m_146926_(-90 * facingDirection.m_122421_().m_122540_());
            m_146922_(0.0f);
        }
        f_19860_ = m_146909_();
        f_19859_ = m_146908_();
        m_7087_();
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        m_20088_().m_135381_(DATA_SIZE, Mth.m_14045_(size, 0, 2));
        this.size = size;
        m_7087_();
    }

    public ItemStack getFrameItem() {
        return m_20088_().m_135370_(DATA_FRAME_ITEM);
    }

    public void setFrameItem(ItemStack stack) {
        m_20088_().m_135381_(DATA_FRAME_ITEM, stack);
    }

    public ItemStack getItem() {
        return m_20088_().m_135370_(DATA_ITEM);
    }

    public void setItem(ItemStack stack) {
        m_20088_().m_135381_(DATA_ITEM, stack);
    }

    protected void onItemChanged(ItemStack itemStack) {
        if (!itemStack.m_41619_()) {
            itemStack.m_41636_(this);
        }
    }

    public int getItemRotation() {
        return m_20088_().m_135370_(DATA_ITEM_ROTATION);
    }

    public void setItemRotation(int rotation) {
        m_20088_().m_135381_(DATA_ITEM_ROTATION, rotation % 4);
    }

    public boolean isGlowing() {
        return m_20088_().m_135370_(DATA_GLOWING);
    }

    public void setGlowing(boolean glowing) {
        m_20088_().m_135381_(DATA_GLOWING, glowing);
    }

    public boolean isStripped() {
        return m_20088_().m_135370_(DATA_STRIPPED);
    }

    public void setStripped(boolean stripped) {
        m_20088_().m_135381_(DATA_STRIPPED, stripped);
    }

    @Override
    public @NotNull InteractionResult m_6096_(@NotNull Player player, @NotNull InteractionHand hand) {
        ItemStack itemInHand = player.m_21120_(hand);

        if (!isStripped()) {
            if (canStrip(itemInHand)) {
                if (!m_9236_().f_46443_) {
                    setStripped(true);
                    itemInHand.m_41622_(1, player, (pl) -> pl.m_21190_(hand));
                    m_146852_(GameEvent.f_157792_, player);
                    m_5496_(SoundEvents.f_11688_, 1f, 1f);
                }
                return InteractionResult.SUCCESS;
            }
        }
        else if (itemInHand.m_150930_(Items.f_42398_)) {
            if (!m_9236_().f_46443_) {
                setStripped(false);
                itemInHand.m_41774_(1);
                m_146852_(GameEvent.f_157792_, player);
                m_7084_();
            }
            return InteractionResult.SUCCESS;
        }

        if (itemInHand.m_41720_() instanceof PhotographItem && getItem().m_41619_()) {
            setItem(itemInHand.m_41777_());
            itemInHand.m_41774_(1);
            m_146852_(GameEvent.f_157792_, player);
            m_5496_(getAddItemSound(), 1.0f, 1.0f);
            return InteractionResult.SUCCESS;
        }

        if (itemInHand.m_150930_(Items.f_151056_) && !isGlowing()) {
            setGlowing(true);
            itemInHand.m_41774_(1);
            if (!m_9236_().f_46443_) {
                m_216990_(SoundEvents.f_144153_);
                m_146852_(GameEvent.f_157792_, player);
            }
            return InteractionResult.SUCCESS;
        }

        if (m_20145_()) {
            if (itemInHand.m_204117_(ItemTags.f_13168_)) {
                m_6842_(false);
                itemInHand.m_41774_(1);
                if (!m_9236_().f_46443_) {
                    m_7084_();
                    m_146852_(GameEvent.f_157792_, player);
                }
                return InteractionResult.SUCCESS;
            }
        }
        else if (itemInHand.m_150930_(Items.f_42027_)) {
            m_6842_(true);
            itemInHand.m_41774_(1);
            if (!m_9236_().f_46443_) {
                m_5496_(Exposure.SoundEvents.FILTER_INSERT.get(), 0.8f, 1.0f);
                m_146852_(GameEvent.f_157792_, player);
            }
            return InteractionResult.SUCCESS;
        }

        if (!getItem().m_41619_()) {
            if (!m_9236_().f_46443_) {
                m_5496_(getRotateSound(), 1.0F, m_9236_().m_213780_().m_188501_() * 0.2f + 0.9f);
                setItemRotation(getItemRotation() + 1);
                m_146852_(GameEvent.f_157792_, player);
            }
            return InteractionResult.SUCCESS;
        }

        return InteractionResult.PASS;
    }

    public boolean canStrip(ItemStack stack) {
        return PlatformHelper.canStrip(stack);
    }

    @Override
    public boolean m_6469_(@NotNull DamageSource damageSource, float amount) {
        if (m_6673_(damageSource))
            return false;

        if (!damageSource.m_269533_(DamageTypeTags.f_268415_) && !getItem().m_41619_()) {
            if (!m_9236_().f_46443_) {
                dropItem(damageSource.m_7639_(), false);
                m_146852_(GameEvent.f_157792_, damageSource.m_7639_());
                m_5496_(getRemoveItemSound(), 1.0f, 1.0f);
            }
            return true;
        }

        return super.m_6469_(damageSource, amount);
    }

    @Override
    public void m_5553_(@Nullable Entity brokenEntity) {
        m_5496_(getBreakSound(), 1.0f, 1.0f);
        dropItem(brokenEntity, true);
        m_146852_(GameEvent.f_157792_, brokenEntity);
    }

    protected void dropItem(@Nullable Entity entity, boolean dropSelf) {
        ItemStack itemStack = getItem();
        setItem(ItemStack.f_41583_);
        if (!m_9236_().m_46469_().m_46207_(GameRules.f_46137_))
            return;

        if (entity instanceof Player player && player.m_7500_())
            return;

        // Prevent item phasing through the block when placed on the ceiling (pointing DOWN)
        float yOffset = m_6350_() == Direction.DOWN ? -0.3f : 0f;

        if (dropSelf)
            m_5552_(getFrameItem(), yOffset);

        if (!itemStack.m_41619_())
            m_5552_(itemStack.m_41777_(), yOffset);
    }

    @Override
    public void m_8119_() {
        super.m_8119_();
        if (m_9236_().f_46443_ && isGlowing() && m_9236_().m_213780_().m_188501_() < 0.003f) {
            AABB bb = m_20191_();
            Vec3i normal = m_6350_().m_122436_();
            m_9236_().m_7106_(ParticleTypes.f_123810_,
                    m_20182_().f_82479_ + (m_9236_().m_213780_().m_188501_() * (bb.m_82362_() * 0.75f) - bb.m_82362_() * 0.75f / 2),
                    m_20182_().f_82480_ + (m_9236_().m_213780_().m_188501_() * (bb.m_82376_() * 0.75f) - bb.m_82376_() * 0.75f / 2),
                    m_20182_().f_82481_ + (m_9236_().m_213780_().m_188501_() * (bb.m_82385_() * 0.75f) - bb.m_82385_() * 0.75f / 2),
                    m_9236_().m_213780_().m_188501_() * 0.02f * normal.m_123341_(),
                    m_9236_().m_213780_().m_188501_() * 0.02f * normal.m_123342_(),
                    m_9236_().m_213780_().m_188501_() * 0.02f * normal.m_123343_());
        }
    }

    @Override
    public @NotNull SlotAccess m_141942_(int slot) {
        if (slot == 0) {
            return new SlotAccess(){

                @Override
                public @NotNull ItemStack m_142196_() {
                    return PhotographFrameEntity.this.getItem();
                }

                @Override
                public boolean m_142104_(ItemStack carried) {
                    PhotographFrameEntity.this.setItem(carried);
                    return true;
                }
            };
        }
        return super.m_141942_(slot);
    }

    @Override
    protected @NotNull Component m_5677_() {
        if (isGlowing())
            return Component.m_237115_("entity.exposure.glow_photograph_frame");
        return super.m_5677_();
    }

    @Override
    public float m_278726_() {
        return (getSize() + 1) / 2f + 0.35f;
    }

    @Override
    public void m_7084_() {
        m_5496_(getPlaceSound(), 1.0F, m_9236_().m_213780_().m_188501_() * 0.2f + 0.7f);
    }

    public SoundEvent getPlaceSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_FRAME_PLACE.get();
    }

    public SoundEvent getBreakSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_FRAME_BREAK.get();
    }

    public SoundEvent getAddItemSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_FRAME_ADD_ITEM.get();
    }

    public SoundEvent getRemoveItemSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_FRAME_REMOVE_ITEM.get();
    }

    public SoundEvent getRotateSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_FRAME_ROTATE_ITEM.get();
    }
}
