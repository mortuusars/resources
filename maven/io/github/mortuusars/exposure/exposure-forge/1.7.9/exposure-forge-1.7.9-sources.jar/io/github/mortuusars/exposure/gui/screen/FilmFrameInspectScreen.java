package io.github.mortuusars.exposure.gui.screen;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.block.entity.Lightroom;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.item.DevelopedFilmItem;
import io.github.mortuusars.exposure.menu.LightroomMenu;
import io.github.mortuusars.exposure.util.GuiUtil;
import io.github.mortuusars.exposure.util.PagingDirection;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class FilmFrameInspectScreen extends ZoomableScreen {
    public static final ResourceLocation TEXTURE = Exposure.resource("textures/gui/film_frame_inspect.png");
    public static final ResourceLocation WIDGETS_TEXTURE = Exposure.resource("textures/gui/widgets.png");
    public static final int BG_SIZE = 78;
    public static final int FRAME_SIZE = 54;
    public static final int BUTTON_SIZE = 16;

    private final LightroomScreen lightroomScreen;
    private final LightroomMenu lightroomMenu;

    private ImageButton previousButton;
    private ImageButton nextButton;

    public FilmFrameInspectScreen(LightroomScreen lightroomScreen, LightroomMenu lightroomMenu) {
        super(Component.m_237119_());
        this.lightroomScreen = lightroomScreen;
        this.lightroomMenu = lightroomMenu;
        zoom.minZoom = zoom.defaultZoom / (float) Math.pow(zoom.step, 2f);
    }

    @Override
    public boolean m_7043_() {
        return false;
    }

    private LightroomMenu getLightroomMenu() {
        return lightroomMenu;
    }

    @Override
    protected void m_7856_() {
        super.m_7856_();

        zoomFactor = (float) f_96544_ / BG_SIZE;

        previousButton = new ImageButton(0, (int) (f_96544_ / 2f - BUTTON_SIZE / 2f), BUTTON_SIZE, BUTTON_SIZE,
                0, 0, BUTTON_SIZE, WIDGETS_TEXTURE, this::buttonPressed);
        nextButton = new ImageButton(f_96543_ - BUTTON_SIZE, (int) (f_96544_ / 2f - BUTTON_SIZE / 2f), BUTTON_SIZE, BUTTON_SIZE,
                16, 0, BUTTON_SIZE, WIDGETS_TEXTURE, this::buttonPressed);

        m_142416_(previousButton);
        m_142416_(nextButton);
    }

    private void buttonPressed(Button button) {
        if (button == previousButton)
            lightroomScreen.changeFrame(PagingDirection.PREVIOUS);
        else if (button == nextButton)
            lightroomScreen.changeFrame(PagingDirection.NEXT);
    }

    public void close() {
        Minecraft.m_91087_().m_91152_(lightroomScreen);
        if (f_96541_.f_91074_ != null)
            f_96541_.f_91074_.m_5496_(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), 1f, 0.7f);
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        m_280273_(guiGraphics);

        guiGraphics.m_280168_().m_85836_();
        guiGraphics.m_280168_().m_252880_(0, 0, 500); // Otherwise exposure will overlap buttons
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
        guiGraphics.m_280168_().m_85849_();

        if (zoom.targetZoom == zoom.minZoom) {
            close();
            return;
        }

        guiGraphics.m_280168_().m_85836_();

        guiGraphics.m_280168_().m_252880_(x, y, 0);
        guiGraphics.m_280168_().m_252880_(f_96543_ / 2f, f_96544_ / 2f, 0);
        guiGraphics.m_280168_().m_85841_(scale, scale, scale);

        RenderSystem.setShaderTexture(0, TEXTURE);

        guiGraphics.m_280168_().m_252880_(BG_SIZE / -2f, BG_SIZE / -2f, 0);

        GuiUtil.blit(guiGraphics.m_280168_(), 0, 0, BG_SIZE, BG_SIZE, 0, 0, 256, 256, 0);

        ItemStack filmStack = lightroomMenu.m_38853_(Lightroom.FILM_SLOT).m_7993_();
        if (!(filmStack.m_41720_() instanceof DevelopedFilmItem film))
            return;

        FilmType negative = film.getType();

        RenderSystem.setShaderColor(negative.filmR, negative.filmG, negative.filmB, negative.filmA);

        GuiUtil.blit(guiGraphics.m_280168_(), 0, 0, BG_SIZE, BG_SIZE, 0, BG_SIZE, 256, 256, 0);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        guiGraphics.m_280168_().m_252880_(12, 12, 0);

        int currentFrame = getLightroomMenu().getSelectedFrame();
        @Nullable CompoundTag frame = getLightroomMenu().getFrameIdByIndex(currentFrame);
        if (frame != null)
            lightroomScreen.renderFrame(frame, guiGraphics.m_280168_(), 0, 0, FRAME_SIZE, 1f, negative);

        guiGraphics.m_280168_().m_85849_();

        previousButton.f_93624_ = currentFrame != 0;
        previousButton.f_93623_ = currentFrame != 0;
        nextButton.f_93624_ = currentFrame != getLightroomMenu().getTotalFrames() - 1;
        nextButton.f_93623_ = currentFrame != getLightroomMenu().getTotalFrames() - 1;
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (keyCode == InputConstants.f_166305_ || f_96541_.f_91066_.f_92092_.m_90832_(keyCode, scanCode))
            zoom.set(0f);
        else if (f_96541_.f_91066_.f_92086_.m_90832_(keyCode, scanCode) || keyCode == InputConstants.f_166330_)
            lightroomScreen.changeFrame(PagingDirection.PREVIOUS);
        else if (f_96541_.f_91066_.f_92088_.m_90832_(keyCode, scanCode) || keyCode == InputConstants.f_166331_)
            lightroomScreen.changeFrame(PagingDirection.NEXT);
        else
            return super.m_7933_(keyCode, scanCode, modifiers);

        return true;
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        boolean handled = super.m_6375_(mouseX, mouseY, button);
        if (handled)
            return true;

        if (button == 1) { // Right Click
            zoom.set(0f);
            return true;
        }

        return false;
    }
}
