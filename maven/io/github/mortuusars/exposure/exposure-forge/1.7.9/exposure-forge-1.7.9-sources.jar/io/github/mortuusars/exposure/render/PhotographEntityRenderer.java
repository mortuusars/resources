package io.github.mortuusars.exposure.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.entity.PhotographEntity;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LightLayer;
import org.jetbrains.annotations.NotNull;

public class PhotographEntityRenderer<T extends PhotographEntity> extends EntityRenderer<T> {

    public PhotographEntityRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public @NotNull ResourceLocation getTextureLocation(@NotNull T pEntity) {
        return InventoryMenu.f_39692_;
    }

    @Override
    public boolean shouldRender(T livingEntity, Frustum camera, double camX, double camY, double camZ) {
        return super.m_5523_(livingEntity, camera, camX, camY, camZ);
    }

    @Override
    public void render(@NotNull T entity, float entityYaw, float partialTick, @NotNull PoseStack poseStack, @NotNull MultiBufferSource bufferSource, int packedLight) {
        super.m_7392_(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);

        poseStack.m_85836_();

        poseStack.m_252781_(Axis.f_252529_.m_252977_(entity.m_146909_()));
        poseStack.m_252781_(Axis.f_252436_.m_252977_(180.0F - entity.m_146908_()));
        poseStack.m_252781_(Axis.f_252403_.m_252977_((entity.getRotation() * 360.0F / 4.0F)));
        poseStack.m_252781_(Axis.f_252403_.m_252977_(180.0F));

        poseStack.m_85837_(-0.5, -0.5, 1f / 32f - 0.005);
        float scale = 1f / ExposureClient.getExposureRenderer().getSize();
        poseStack.m_85841_(scale, scale, -scale);

        boolean isGlowing = entity.isGlowing();
        if (isGlowing)
            packedLight = LightTexture.f_173040_;

        int brightness = isGlowing ? 255 : getPhotographBrightness(entity);

        ItemStack item = entity.getItem();

        PhotographRenderer.render(item, !entity.m_20145_(), true, poseStack, bufferSource, packedLight,
                brightness, brightness, brightness, 255);

        poseStack.m_85849_();
    }

    public int getPhotographBrightness(T entity) {
        if (entity.m_6350_() == Direction.UP)
            return 255;

        // Darken the photo same way as the block sides darken,
        // but not quite as much and allow light sources to brighten it:
        int lightLevel = entity.m_9236_().m_45517_(LightLayer.BLOCK, entity.m_20183_());
        float shadeFactor = entity.m_9236_().m_7717_(entity.m_6350_(), true);
        shadeFactor += (1f - shadeFactor) * 0.05f;

        int shadedBrightness = (int)(255 * shadeFactor);
        int missingLight = 255 - shadedBrightness;
        int lightUp = (int)(missingLight * (lightLevel / 15f * 0.7f));
        return Math.min(255, shadedBrightness + lightUp);
    }
}
