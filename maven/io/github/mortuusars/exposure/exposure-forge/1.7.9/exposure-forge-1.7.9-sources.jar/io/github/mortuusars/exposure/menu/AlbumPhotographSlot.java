package io.github.mortuusars.exposure.menu;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class AlbumPhotographSlot extends Slot {
    private boolean isActive;

    public AlbumPhotographSlot(Container container, int slot, int x, int y) {
        super(container, slot, x, y);
    }

    @Override
    public boolean m_5857_(ItemStack stack) {
        return false;
    }

    @Override
    public boolean m_8010_(Player player) {
        return false;
    }

    @Override
    public boolean m_6659_() {
        return isActive;
    }

    public void setActive(boolean value) {
        isActive = value;
    }
}
