package io.github.mortuusars.exposure.network.packet;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.PacketDirection;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Nullable;

public record ExposureDataPartPacket(String id, int width, int height, CompoundTag properties, int offset, byte[] partBytes) implements IPacket {
    public static final ResourceLocation ID = Exposure.resource("exposure_data_part");

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    public FriendlyByteBuf toBuffer(FriendlyByteBuf buffer) {
        buffer.m_130070_(id);
        buffer.writeInt(width);
        buffer.writeInt(height);
        buffer.m_130079_(properties);
        buffer.writeInt(offset);
        buffer.m_130087_(partBytes);
        return buffer;
    }

    public static ExposureDataPartPacket fromBuffer(FriendlyByteBuf buffer) {
        return new ExposureDataPartPacket(buffer.m_130277_(), buffer.readInt(), buffer.readInt(),
                buffer.m_130261_(), buffer.readInt(), buffer.m_130052_());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable Player player) {
        direction.getExposureReceiver().receivePart(id, width, height, properties, offset, partBytes);
        return true;
    }
}
