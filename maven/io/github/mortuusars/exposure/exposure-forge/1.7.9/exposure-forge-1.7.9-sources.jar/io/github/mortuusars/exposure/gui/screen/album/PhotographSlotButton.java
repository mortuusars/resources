package io.github.mortuusars.exposure.gui.screen.album;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.vertex.Tesselator;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.render.PhotographRenderProperties;
import io.github.mortuusars.exposure.render.PhotographRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.navigation.CommonInputs;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

public class PhotographSlotButton extends ImageButton {

    protected final Rect2i exposureArea;
    protected final OnPress onRightButtonPress;
    protected final Supplier<ItemStack> photograph;
    protected final boolean isEditable;
    protected boolean hasPhotograph;

    public PhotographSlotButton(Rect2i exposureArea, int x, int y, int width, int height, int xTexStart, int yTexStart,
                                int yDiffTex, ResourceLocation resourceLocation, int textureWidth, int textureHeight,
                                OnPress onLeftButtonPress, OnPress onRightButtonPress, Supplier<ItemStack> photographGetter, boolean isEditable) {
        super(x, y, width, height, xTexStart, yTexStart, yDiffTex, resourceLocation, textureWidth, textureHeight, onLeftButtonPress,
                Component.m_237115_("item.exposure.photograph"));
        this.exposureArea = exposureArea;
        this.onRightButtonPress = onRightButtonPress;
        this.photograph = photographGetter;
        this.isEditable = isEditable;
    }

    public ItemStack getPhotograph() {
        return photograph.get();
    }

    @Override
    public void m_87963_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        ItemStack photograph = getPhotograph();

        if (photograph.m_41720_() instanceof PhotographItem) {
            hasPhotograph = true;

            PhotographRenderProperties renderProperties = PhotographRenderProperties.get(photograph);

            // Paper
            m_280322_(guiGraphics, renderProperties.getAlbumPaperTexture(),
                    m_252754_(), m_252907_(), 0, 0, 0, f_93618_, f_93619_, f_93618_, f_93619_);

            // Exposure
            guiGraphics.m_280168_().m_85836_();
            float scale = exposureArea.m_110090_() / (float) ExposureClient.getExposureRenderer().getSize();
            guiGraphics.m_280168_().m_252880_(exposureArea.m_110085_(), exposureArea.m_110086_(), 1);
            guiGraphics.m_280168_().m_85841_(scale, scale, scale);
            MultiBufferSource.BufferSource bufferSource = MultiBufferSource.m_109898_(Tesselator.m_85913_().m_85915_());
            PhotographRenderer.render(photograph, false, false, guiGraphics.m_280168_(),
                    bufferSource, LightTexture.f_173040_, 255, 255, 255, 255);
            bufferSource.m_109911_();
            guiGraphics.m_280168_().m_85849_();

            // Paper overlay
            if (renderProperties.hasAlbumPaperOverlayTexture()) {
                guiGraphics.m_280168_().m_85836_();
                guiGraphics.m_280168_().m_252880_(0, 0, 2);
                m_280322_(guiGraphics, renderProperties.getAlbumPaperOverlayTexture(),
                        m_252754_(), m_252907_(), 0, 0, 0, f_93618_, f_93619_, f_93618_, f_93619_);
                guiGraphics.m_280168_().m_85849_();
            }
        }
        else {
            hasPhotograph = false;
        }

        // Album pins
        int xTex = f_94224_ + (hasPhotograph ? m_5711_() : 0);
        m_280322_(guiGraphics, f_94223_, m_252754_(), m_252907_(), xTex, f_94225_, f_94226_, f_93618_, f_93619_, f_94227_, f_94228_);
    }

    public void renderTooltip(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        if (isEditable && !hasPhotograph) {
            guiGraphics.m_280557_(Minecraft.m_91087_().f_91062_,
                    Component.m_237115_("gui.exposure.album.add_photograph"), mouseX, mouseY);
            return;
        }

        ItemStack photograph = getPhotograph();
        if (photograph.m_41619_())
            return;

        List<Component> itemTooltip = Screen.m_280152_(Minecraft.m_91087_(), photograph);
        itemTooltip.add(Component.m_237115_("gui.exposure.album.left_click_or_scroll_up_to_view"));
        if (isEditable)
            itemTooltip.add(Component.m_237115_("gui.exposure.album.right_click_to_remove"));

        // Photograph image in tooltip is not rendered here

        if (m_93696_()) {
            guiGraphics.m_280547_(Minecraft.m_91087_().f_91062_, Lists.transform(itemTooltip,
                    Component::m_7532_), m_262860_(), mouseX, mouseY);
        }
        else
            guiGraphics.m_280677_(Minecraft.m_91087_().f_91062_, itemTooltip, Optional.empty(), mouseX, mouseY);
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        if (!this.f_93623_ || !this.f_93624_ || !m_93680_(mouseX, mouseY))
            return false;

        if (button == InputConstants.f_166347_) {
            this.f_93717_.m_93750_(this);
        } else if (button == InputConstants.f_166349_) {
            this.onRightButtonPress.m_93750_(this);
        } else
            return false;

        return true;
    }

    @Override
    public boolean m_6050_(double mouseX, double mouseY, double delta) {
        if (delta > 0 && m_93680_(mouseX, mouseY) && hasPhotograph) {
            this.f_93717_.m_93750_(this);
            return true;
        }

        return super.m_6050_(mouseX, mouseY, delta);
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (this.f_93623_ && this.f_93624_ && Screen.m_96638_() && CommonInputs.m_278691_(keyCode)) {
            onRightButtonPress.m_93750_(this);
            return true;
        }

        return super.m_7933_(keyCode, scanCode, modifiers);
    }
}
