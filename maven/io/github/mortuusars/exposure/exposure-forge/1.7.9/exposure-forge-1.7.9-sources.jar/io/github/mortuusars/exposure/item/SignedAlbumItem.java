package io.github.mortuusars.exposure.item;

import io.github.mortuusars.exposure.Config;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.util.StringUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class SignedAlbumItem extends AlbumItem {
    public SignedAlbumItem(Properties properties) {
        super(properties);
    }

    @Override
    public boolean isEditable() {
        return false;
    }

    @Override
    public @NotNull Component m_7626_(ItemStack stack) {
        if (stack.m_41783_() != null && !StringUtil.m_14408_(stack.m_41783_().m_128461_(TAG_TITLE))) {
            return Component.m_237113_(stack.m_41783_().m_128461_(TAG_TITLE));
        }
        return super.m_7626_(stack);
    }
    @Override
    public void m_7373_(ItemStack stack, @Nullable Level level, List<Component> tooltipComponents, TooltipFlag isAdvanced) {
        if (stack.m_41783_() != null) {
            CompoundTag compoundTag = stack.m_41783_();
            String author = compoundTag.m_128461_(TAG_AUTHOR);
            if (!StringUtil.m_14408_(author)) {
                tooltipComponents.add(Component.m_237110_("gui.exposure.album.by_author", author).m_130940_(ChatFormatting.GRAY));
            }
        }
        super.m_7373_(stack, level, tooltipComponents, isAdvanced);
    }

    @Override
    public boolean m_5812_(ItemStack stack) {
        return Config.Client.SIGNED_ALBUM_GLINT.get();
    }
}
