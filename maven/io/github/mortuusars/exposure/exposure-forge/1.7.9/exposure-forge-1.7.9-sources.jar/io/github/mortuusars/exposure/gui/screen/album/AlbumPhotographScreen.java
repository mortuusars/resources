package io.github.mortuusars.exposure.gui.screen.album;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.gui.screen.PhotographScreen;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.util.ItemAndStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class AlbumPhotographScreen extends PhotographScreen {
    private final Screen parentScreen;

    public AlbumPhotographScreen(Screen parentScreen, List<ItemAndStack<PhotographItem>> photographs) {
        super(photographs);
        this.parentScreen = parentScreen;
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (zoom.targetZoom == zoom.minZoom) {
            close();
            return;
        }

        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (keyCode == InputConstants.f_166305_ || f_96541_.f_91066_.f_92092_.m_90832_(keyCode, scanCode)) {
            zoom.set(0f);
            return true;
        }

        return super.m_7933_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        boolean handled = super.m_6375_(mouseX, mouseY, button);
        if (handled)
            return true;

        if (button == 1) { // Right Click
            zoom.set(0f);
            return true;
        }

        return false;
    }

    public void close() {
        Minecraft.m_91087_().m_91152_(parentScreen);
        if (f_96541_.f_91074_ != null)
            f_96541_.f_91074_.m_5496_(Exposure.SoundEvents.PHOTOGRAPH_PLACE.get(), 0.7f, 1.1f);
    }
}
