package io.github.mortuusars.exposure.command.exposure;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.command.argument.ExposureLookArgument;
import io.github.mortuusars.exposure.command.argument.ExposureSizeArgument;
import io.github.mortuusars.exposure.command.suggestion.ExposureIdSuggestionProvider;
import io.github.mortuusars.exposure.data.ExposureLook;
import io.github.mortuusars.exposure.data.ExposureSize;
import io.github.mortuusars.exposure.data.storage.ExposureSavedData;
import io.github.mortuusars.exposure.data.storage.ServersideExposureExporter;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.storage.LevelResource;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import static net.minecraft.commands.Commands.m_82129_;
import static net.minecraft.commands.Commands.m_82127_;

public class ExportCommand {
    public static LiteralArgumentBuilder<CommandSourceStack> get() {
        return m_82127_("export")
                .requires((stack) -> stack.m_6761_(3))
                .then(id())
                .then(all());
    }

    private static ArgumentBuilder<CommandSourceStack, ?> id() {
        return m_82127_("id")
                .then(m_82129_("id", StringArgumentType.string())
                        .suggests(new ExposureIdSuggestionProvider())
                        .executes(context -> exportExposures(context.getSource(),
                                List.of(StringArgumentType.getString(context, "id")),
                                ExposureSize.X1,
                                ExposureLook.REGULAR))
                        .then(m_82129_("size", new ExposureSizeArgument())
                                .executes(context -> exportExposures(context.getSource(),
                                        List.of(StringArgumentType.getString(context, "id")),
                                        ExposureSizeArgument.getSize(context, "size"),
                                        ExposureLook.REGULAR))
                                .then(m_82129_("look", new ExposureLookArgument())
                                        .executes(context -> exportExposures(context.getSource(),
                                                List.of(StringArgumentType.getString(context, "id")),
                                                ExposureSizeArgument.getSize(context, "size"),
                                                ExposureLookArgument.getLook(context, "look"))))));
    }

    private static ArgumentBuilder<CommandSourceStack, ?> all() {
        return m_82127_("all")
                .executes(context -> exportAll(context.getSource(), ExposureSize.X1, ExposureLook.REGULAR))
                .then(m_82129_("size", new ExposureSizeArgument())
                        .executes(context -> exportAll(context.getSource(),
                                ExposureSizeArgument.getSize(context, "size"),
                                ExposureLook.REGULAR))
                        .then(m_82129_("look", new ExposureLookArgument())
                                .executes(context -> exportAll(context.getSource(),
                                        ExposureSizeArgument.getSize(context, "size"),
                                        ExposureLookArgument.getLook(context, "look")))));
    }

    private static int exportAll(CommandSourceStack source, ExposureSize size, ExposureLook look) {
        List<String> ids = ExposureServer.getExposureStorage().getAllIds();
        return exportExposures(source, ids, size, look);
    }

    private static int exportExposures(CommandSourceStack stack, List<String> exposureIds, ExposureSize size, ExposureLook look) {
        int savedCount = 0;

        File folder = stack.m_81377_().m_129843_(LevelResource.f_78182_).resolve("exposures").toFile();
        boolean ignored = folder.mkdirs();

        for (String id : exposureIds) {
            Optional<ExposureSavedData> data = ExposureServer.getExposureStorage().getOrQuery(id);
            if (data.isEmpty()) {
                stack.m_81352_(Component.m_237110_("command.exposure.export.failure.not_found", id));
                continue;
            }

            ExposureSavedData exposureSavedData = data.get();
            String name = id + look.getIdSuffix();

            boolean saved = new ServersideExposureExporter(name)
                    .withFolder(folder.getAbsolutePath().replace("\\.\\", "\\").replace("/./", "/"))
                    .withModifier(look.getModifier())
                    .withSize(size)
                    .save(exposureSavedData);

            if (saved)
                stack.m_288197_(() ->
                        Component.m_237110_("command.exposure.export.success.saved_exposure_id", id), true);

            savedCount++;
        }

        if (savedCount > 0) {
            String folderPath = getFolderPath(folder);
            Component folderComponent = Component.m_237113_(folderPath)
                    .m_130940_(ChatFormatting.UNDERLINE)
                    .m_130938_(arg -> arg.m_131142_(new ClickEvent(ClickEvent.Action.OPEN_FILE, folderPath)));
            Component component = Component.m_237110_("command.exposure.export.success.result", savedCount, folderComponent);
            stack.m_288197_(() -> component, true);
        } else
            stack.m_81352_(Component.m_237115_("command.exposure.export.failure.none_saved"));

        return 0;
    }

    @NotNull
    private static String getFolderPath(File folder) {
        String folderPath;
        try {
            folderPath = folder.getCanonicalPath();
        } catch (IOException e) {
            Exposure.LOGGER.error(e.toString());
            folderPath = folder.getAbsolutePath();
        }
        return folderPath;
    }
}
