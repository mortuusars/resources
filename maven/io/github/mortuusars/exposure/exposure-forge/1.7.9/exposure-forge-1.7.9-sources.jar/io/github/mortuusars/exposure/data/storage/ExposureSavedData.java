package io.github.mortuusars.exposure.data.storage;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ExposureSavedData extends SavedData {
    public static final String TYPE_PROPERTY = "Type";
    public static final String WAS_PRINTED_PROPERTY = "WasPrinted";
    public static final String TIMESTAMP_PROPERTY = "Timestamp";
    public static final String FROM_FILE_PROPERTY = "FromFile";

    private final int width;
    private final int height;
    private final byte[] pixels;
    private final CompoundTag properties;

    public ExposureSavedData(int width, int height, byte[] pixels, CompoundTag properties) {
        Preconditions.checkArgument(width >= 0, "Width cannot be negative.");
        Preconditions.checkArgument(height >= 0, "Height cannot be negative.");

        if (pixels.length > width * height)
            Exposure.LOGGER.warn("Pixel count was larger that it supposed to be. This shouldn't happen.");

        this.width = width;
        this.height = height;
        this.pixels = pixels;
        this.properties = properties;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public byte[] getPixels() {
        return pixels;
    }

    public byte getPixel(int x, int y) {
        return pixels[y * width + x];
    }

    @SuppressWarnings("unused")
    public void setPixel(int x, int y, byte value) {
        Preconditions.checkArgument(x >= 0 && x < width,  "X=" + x + " is out of bounds for Width=" + width);
        Preconditions.checkArgument(y >= 0 && y < height,  "Y=" + x + " is out of bounds for Height=" + height);
        pixels[y * width + x] = value;
    }

    public CompoundTag getProperties() {
        return properties;
    }

    public @Nullable FilmType getType() {
        String typeString = properties.m_128461_(TYPE_PROPERTY);
        return FilmType.byName(typeString);
    }

    @Override
    public @NotNull CompoundTag m_7176_(CompoundTag compoundTag) {
        compoundTag.m_128405_("width", width);
        compoundTag.m_128405_("height", height);
        compoundTag.m_128382_("pixels", pixels);
        compoundTag.m_128365_("properties", properties);
        return compoundTag;
    }

    public static ExposureSavedData load(CompoundTag compoundTag) {
        CompoundTag properties = compoundTag.m_128469_("properties");

        // Backwards compatibility:
        if (!properties.m_128441_(TYPE_PROPERTY)) {
            properties.m_128359_(TYPE_PROPERTY, compoundTag.m_128471_("black_and_white") ? "black_and_white" : "color");
        }
        if (!properties.m_128441_(WAS_PRINTED_PROPERTY)) {
            properties.m_128379_(WAS_PRINTED_PROPERTY, compoundTag.m_128471_("printed"));
        }

        return new ExposureSavedData(
                compoundTag.m_128451_("width"),
                compoundTag.m_128451_("height"),
                compoundTag.m_128463_("pixels"),
                properties);
    }
}
