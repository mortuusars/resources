package io.github.mortuusars.exposure.item;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.SlotAccess;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickAction;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

public class InterplanarProjectorItem extends Item {
    public InterplanarProjectorItem(Properties properties) {
        super(properties);
    }

    public boolean isDithered(ItemStack stack) {
        return stack.m_41783_() == null || !stack.m_41783_().m_128471_("Clean");
    }

    public void setDithered(ItemStack stack, boolean dithered) {
        stack.m_41784_().m_128379_("Clean", !dithered);
    }

    public boolean isConsumable(ItemStack stack) {
        return true;
    }

    @Override
    public void m_7373_(ItemStack stack, @Nullable Level level, List<Component> components, TooltipFlag isAdvanced) {
        super.m_7373_(stack, level, components, isAdvanced);

        if (isDithered(stack)){
            components.add(Component.m_237115_("item.exposure.interplanar_projector.mode.dithered"));
        }
        else {
            components.add(Component.m_237115_("item.exposure.interplanar_projector.mode.clear"));
        }

        if (Screen.m_96638_()) {
            if (isConsumable(stack)) {
                components.add(Component.m_237115_("item.exposure.interplanar_projector.tooltip.consumed_info"));
            }
            components.add(Component.m_237115_("item.exposure.interplanar_projector.tooltip.info"));
            components.add(Component.m_237115_("item.exposure.interplanar_projector.tooltip.switch_info"));
        }
        else {
            components.add(Component.m_237115_("tooltip.exposure.hold_for_details"));
        }
    }

    @Override
    public boolean m_142305_(ItemStack stack, ItemStack other, Slot slot, ClickAction action, Player player, SlotAccess access) {
        if (other.m_41619_() && action == ClickAction.SECONDARY) {
            setDithered(stack, !isDithered(stack));
            slot.m_6654_();
            if (player.m_9236_().f_46443_) {
                player.m_5496_(Exposure.SoundEvents.CAMERA_GENERIC_CLICK.get(), 0.6f, 1f);
            }
            return true;
        }

        return super.m_142305_(stack, other, slot, action, player, access);
    }

    public Optional<String> getFilename(ItemStack stack) {
        return stack.m_41788_() ? Optional.of(stack.m_41786_().getString()) : Optional.empty();
    }
}
