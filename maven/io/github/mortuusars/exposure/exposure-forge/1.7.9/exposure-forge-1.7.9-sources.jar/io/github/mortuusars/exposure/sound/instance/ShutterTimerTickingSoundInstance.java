package io.github.mortuusars.exposure.sound.instance;

import io.github.mortuusars.exposure.item.CameraItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public class ShutterTimerTickingSoundInstance extends AbstractTickableSoundInstance {
    private final Player player;
    private int delay = 2;
    private final float originalVolume;
    public ShutterTimerTickingSoundInstance(Player player, SoundEvent soundEvent, SoundSource soundSource, float volume, float pitch, RandomSource random) {
        super(soundEvent, soundSource, random);
        this.player = player;
        this.f_119575_ = player.m_20185_();
        this.f_119576_ = player.m_20186_();
        this.f_119577_ = player.m_20189_();
        this.f_119573_ = volume;
        this.originalVolume = volume;
        this.f_119574_ = pitch;
        this.f_119578_ = true;
    }

    @Override
    public void m_7788_() {
        this.f_119575_ = player.m_20185_();
        this.f_119576_ = player.m_20186_();
        this.f_119577_ = player.m_20189_();

        if (hasShutterOpen(player.m_21205_()) || hasShutterOpen(player.m_21206_())) {
            f_119573_ = Mth.m_14179_(0.3f, f_119573_, originalVolume);
            return;
        }
        else
            f_119573_ = Mth.m_14179_(0.2f, f_119573_, originalVolume * 0.3f);

        if (!hasCameraWithOpenShutterInInventory(player)) {
            // In multiplayer other players camera photo is not updated in time (sometimes)
            // This causes the sound to stop instantly
            if (!player.equals(Minecraft.m_91087_().f_91074_) && f_119579_ > 0) {
                f_119579_--;
                return;
            }

            this.m_119609_();
        }
    }

    private boolean hasCameraWithOpenShutterInInventory(Player player) {
        for (ItemStack stack : player.m_150109_().f_35974_) {
            if (hasShutterOpen(stack))
                return true;
        }

        return false;
    }

    private boolean hasShutterOpen(ItemStack stack) {
        return stack.m_41720_() instanceof CameraItem cameraItem && cameraItem.isShutterOpen(stack);
    }
}
