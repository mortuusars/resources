package io.github.mortuusars.exposure.item;

import io.github.mortuusars.exposure.ExposureConstants;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;

public interface IFilmItem {
    String FRAME_COUNT_TAG = "FrameCount";
    String FRAME_SIZE_TAG = "FrameSize";
    String FRAMES_TAG = "Frames";

    FilmType getType();

    default int getDefaultMaxFrameCount(ItemStack filmStack) {
        return 16;
    }

    default int getMaxFrameCount(ItemStack filmStack) {
        if (filmStack.m_41783_() != null && filmStack.m_41783_().m_128425_(FRAME_COUNT_TAG, Tag.f_178196_))
            return filmStack.m_41783_().m_128451_(FRAME_COUNT_TAG);
        else
            return getDefaultMaxFrameCount(filmStack);
    }

    default int getDefaultFrameSize() {
        return ExposureConstants.DEFAULT_FRAME_SIZE;
    }

    default int getFrameSize(ItemStack filmStack) {
        if (filmStack.m_41783_() != null && filmStack.m_41783_().m_128425_(FRAME_SIZE_TAG, Tag.f_178196_))
            return Mth.m_14045_(filmStack.m_41784_().m_128451_(FRAME_SIZE_TAG), 1, 2048);
        else
            return getDefaultFrameSize();
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    default boolean hasExposedFrame(ItemStack filmStack, int index) {
        if (index < 0 || filmStack.m_41783_() == null || !filmStack.m_41783_().m_128425_(FRAMES_TAG, Tag.f_178202_))
            return false;

        ListTag list = filmStack.m_41783_().m_128437_(FRAMES_TAG, Tag.f_178203_);
        return index < list.size();
    }

    default int getExposedFramesCount(ItemStack stack) {
        return stack.m_41783_() != null && stack.m_41783_().m_128425_(FRAMES_TAG, Tag.f_178202_) ?
                stack.m_41783_().m_128437_(FRAMES_TAG, Tag.f_178203_).size() : 0;
    }

    default ListTag getExposedFrames(ItemStack filmStack) {
        return filmStack.m_41783_() != null ? filmStack.m_41783_().m_128437_(FRAMES_TAG, Tag.f_178203_) : new ListTag();
    }
}
