package io.github.mortuusars.exposure.entity;

import com.google.common.base.Preconditions;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.item.PhotographItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.decoration.HangingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DiodeBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import org.apache.commons.lang3.Validate;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PhotographEntity extends HangingEntity {
    
    protected static final EntityDataAccessor<ItemStack> DATA_ITEM = SynchedEntityData.m_135353_(PhotographEntity.class, EntityDataSerializers.f_135033_);
    protected static final EntityDataAccessor<Boolean> DATA_GLOWING = SynchedEntityData.m_135353_(PhotographEntity.class, EntityDataSerializers.f_135035_);
    protected static final EntityDataAccessor<Integer> DATA_ROTATION = SynchedEntityData.m_135353_(PhotographEntity.class, EntityDataSerializers.f_135028_);

    public PhotographEntity(EntityType<? extends PhotographEntity> entityType, Level level) {
        super(entityType, level);
    }

    public PhotographEntity(Level level, BlockPos pos, Direction facingDirection, ItemStack photographStack) {
        super(Exposure.EntityTypes.PHOTOGRAPH.get(), level, pos);
        m_6022_(facingDirection);
        setItem(photographStack);
    }


    // Entity:


    @Override
    public boolean m_6783_(double distance) {
        double d = 16.0;
        d *= 64.0 * m_20150_();
        return distance < d * d;
    }

    protected void m_8097_() {
        this.m_20088_().m_135372_(DATA_ITEM, ItemStack.f_41583_);
        this.m_20088_().m_135372_(DATA_GLOWING, false);
        this.m_20088_().m_135372_(DATA_ROTATION, 0);
    }

    public void m_7350_(EntityDataAccessor<?> key) {
        if (key.equals(DATA_ITEM)) {
            this.onItemChanged(this.getItem());
        }
    }

    @Override
    public void m_141965_(@NotNull ClientboundAddEntityPacket packet) {
        super.m_141965_(packet);
        this.m_6022_(Direction.m_122376_(packet.m_131509_()));
    }

    @Override
    public @NotNull Packet<ClientGamePacketListener> m_5654_() {
        return new ClientboundAddEntityPacket(this, this.f_31699_.m_122411_(), this.m_31748_());
    }

    public void m_7380_(@NotNull CompoundTag tag) {
        super.m_7380_(tag);
        if (!this.getItem().m_41619_()) {
            tag.m_128365_("Item", this.getItem().m_41739_(new CompoundTag()));
            tag.m_128379_("Glowing", this.isGlowing());
            tag.m_128344_("ItemRotation", (byte)this.getRotation());
        }

        tag.m_128344_("Facing", (byte)this.f_31699_.m_122411_());
        tag.m_128379_("Invisible", this.m_20145_());
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void m_7378_(@NotNull CompoundTag tag) {
        super.m_7378_(tag);
        CompoundTag compoundtag = tag.m_128469_("Item");
        if (!compoundtag.m_128456_()) {
            ItemStack itemstack = ItemStack.m_41712_(compoundtag);
            if (itemstack.m_41619_())
                Exposure.LOGGER.warn("Unable to load item from: {}", compoundtag);

            setItem(itemstack);
            setGlowing(tag.m_128471_("Glowing"));
            setRotation(tag.m_128445_("ItemRotation"));
        }

        this.m_6022_(Direction.m_122376_(tag.m_128445_("Facing")));
        this.m_6842_(tag.m_128471_("Invisible"));
    }


    // Properties:

    @Override
    protected float m_6380_(@NotNull Pose pose, @NotNull EntityDimensions dimensions) {
        return 0f;
    }

    @Override
    public int m_7076_() {
        return 16;
    }

    @Override
    public int m_7068_() {
        return 16;
    }

    @Nullable
    @Override
    public ItemStack m_142340_() {
        return getItem().m_41777_();
    }

    @SuppressWarnings("deprecation")
    @Override
    public boolean m_7088_() {
        if (!this.m_9236_().m_45786_(this)) {
            return false;
        } else {
            BlockState blockstate = this.m_9236_().m_8055_(this.f_31698_.m_121945_(this.f_31699_.m_122424_()));
            return (blockstate.m_280296_() || this.f_31699_.m_122434_().m_122479_()
                    && DiodeBlock.m_52586_(blockstate))
                    && this.m_9236_().m_6249_(this, this.m_20191_(), f_31697_).isEmpty();
        }
    }

    @Override
    protected void m_7087_() {
        //noinspection ConstantValue
        if (this.f_31699_ == null) {
            // When called from HangingEntity constructor direction is null
            return;
        }

        double value = 0.46875D;
        double d1 = (double)this.f_31698_.m_123341_() + 0.5D - (double)this.f_31699_.m_122429_() * value;
        double d2 = (double)this.f_31698_.m_123342_() + 0.5D - (double)this.f_31699_.m_122430_() * value;
        double d3 = (double)this.f_31698_.m_123343_() + 0.5D - (double)this.f_31699_.m_122431_() * value;
        this.m_20343_(d1, d2, d3);
        double d4 = this.m_7076_();
        double d5 = this.m_7068_();
        double d6 = this.m_7076_();
        Direction.Axis directionAxis = this.f_31699_.m_122434_();
        switch (directionAxis) {
            case X -> d4 = 1.0D;
            case Y -> d5 = 1.0D;
            case Z -> d6 = 1.0D;
        }

        d4 /= 32.0D;
        d5 /= 32.0D;
        d6 /= 32.0D;
        this.m_20011_(new AABB(d1 - d4, d2 - d5, d3 - d6, d1 + d4, d2 + d5, d3 + d6));
    }


    // Interaction:

    @Override
    protected void m_6022_(@NotNull Direction facingDirection) {
        Validate.notNull(facingDirection);
        this.f_31699_ = facingDirection;
        if (facingDirection.m_122434_().m_122479_()) {
            this.m_146926_(0.0F);
            this.m_146922_((float)(this.f_31699_.m_122416_() * 90));
        } else {
            this.m_146926_((float)(-90 * facingDirection.m_122421_().m_122540_()));
            this.m_146922_(0.0F);
        }

        this.f_19860_ = this.m_146909_();
        this.f_19859_ = this.m_146908_();
        this.m_7087_();
    }

    public ItemStack getItem() {
        return this.m_20088_().m_135370_(DATA_ITEM);
    }

    public void setItem(ItemStack photographStack) {
        Preconditions.checkState(photographStack.m_41720_() instanceof PhotographItem,  photographStack + " is not a PhotographItem");
        this.m_20088_().m_135381_(DATA_ITEM, photographStack);
    }

    protected void onItemChanged(ItemStack itemStack) {
        if (!itemStack.m_41619_()) {
            itemStack.m_41636_(this);
        }

        this.m_7087_();
    }

    public boolean isGlowing() {
        return this.m_20088_().m_135370_(DATA_GLOWING);
    }

    public void setGlowing(boolean glowing) {
        this.m_20088_().m_135381_(DATA_GLOWING, glowing);
    }

    public int getRotation() {
        return this.m_20088_().m_135370_(DATA_ROTATION);
    }

    public void setRotation(int rotation) {
        this.m_20088_().m_135381_(DATA_ROTATION, rotation % 4);
    }

    @Override
    public @NotNull InteractionResult m_6096_(@NotNull Player player, @NotNull InteractionHand hand) {
        ItemStack itemInHand = player.m_21120_(hand);
        if (!m_20145_() && canShear(itemInHand)) {
            if (!m_9236_().f_46443_) {
                m_6842_(true);
                itemInHand.m_41622_(1, player, (pl) -> pl.m_21190_(hand));
                m_5496_(SoundEvents.f_12344_, 1f, m_9236_().m_213780_().m_188501_() * 0.2f + 0.9f);
            }

            return InteractionResult.SUCCESS;
        }

        if (itemInHand.m_150930_(Items.f_151056_)) {
            setGlowing(true);
            itemInHand.m_41774_(1);
            if (!m_9236_().f_46443_)
                m_216990_(SoundEvents.f_144153_);
            return InteractionResult.SUCCESS;
        }

        if (!m_9236_().f_46443_) {
            this.m_5496_(getRotateSound(), 1.0F, m_9236_().m_213780_().m_188501_() * 0.2f + 0.9f);
            this.setRotation(getRotation() + 1);
        }

        return InteractionResult.SUCCESS;
    }

    public boolean canShear(ItemStack stack) {
        return PlatformHelper.canShear(stack);
    }

    @Override
    public boolean m_6469_(@NotNull DamageSource damageSource, float amount) {
        if (this.m_6673_(damageSource))
            return false;

        if (!this.m_213877_() && !this.m_9236_().f_46443_) {
            if (!getItem().m_41619_() && !damageSource.m_276093_(DamageTypes.f_268565_))
                this.m_5553_(damageSource.m_7639_());

            this.m_6074_();
            this.m_5834_();
        }

        return true;
    }

    @Override
    public void m_5553_(@Nullable Entity breaker) {
        this.m_5496_(this.getBreakSound(), 1.0F, m_9236_().m_213780_().m_188501_() * 0.3f + 0.6f);

        if ((breaker instanceof Player player && player.m_7500_()))
            return;

        ItemStack itemStack = getItem();
        m_19983_(itemStack);
    }

    @Override
    public void m_8119_() {
        super.m_8119_();
        if (m_9236_().f_46443_ && isGlowing() && m_9236_().m_213780_().m_188501_() < 0.01f) {
            AABB bb = m_20191_();
            Vec3i normal = m_6350_().m_122436_();
            m_9236_().m_7106_(ParticleTypes.f_123810_,
                    m_20182_().f_82479_ + (m_9236_().m_213780_().m_188501_() * (bb.m_82362_() * 0.75f) - bb.m_82362_() * 0.75f / 2),
                    m_20182_().f_82480_ + (m_9236_().m_213780_().m_188501_() * (bb.m_82376_() * 0.75f) - bb.m_82376_() * 0.75f / 2),
                    m_20182_().f_82481_ + (m_9236_().m_213780_().m_188501_() * (bb.m_82385_() * 0.75f) - bb.m_82385_() * 0.75f / 2),
                    m_9236_().m_213780_().m_188501_() * 0.02f * normal.m_123341_(),
                    m_9236_().m_213780_().m_188501_() * 0.02f * normal.m_123342_(),
                    m_9236_().m_213780_().m_188501_() * 0.02f * normal.m_123343_());
        }
    }

    @Override
    public void m_7084_() {
        this.m_5496_(this.getPlaceSound(), 1.0F, m_9236_().m_213780_().m_188501_() * 0.3f + 0.9f);
    }

    public SoundEvent getPlaceSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_PLACE.get();
    }

    public SoundEvent getBreakSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_BREAK.get();
    }

    public SoundEvent getRotateSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get();
    }
}
