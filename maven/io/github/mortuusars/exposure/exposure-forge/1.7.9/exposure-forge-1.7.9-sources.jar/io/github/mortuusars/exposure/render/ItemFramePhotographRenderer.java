package io.github.mortuusars.exposure.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.datafixers.util.Either;
import com.mojang.math.Axis;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.item.PhotographItem;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public class ItemFramePhotographRenderer {
    public static boolean render(ItemFrame itemFrameEntity, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
        ItemStack itemStack = itemFrameEntity.m_31822_();
        if (!(itemStack.m_41720_() instanceof PhotographItem photographItem) || !FrameData.hasIdOrTexture(itemStack))
            return false;

        if (itemFrameEntity.m_6095_() == EntityType.f_147033_)
            packedLight = LightTexture.f_173040_;

        poseStack.m_85836_();

        String entityName = BuiltInRegistries.f_256780_.m_7981_(itemFrameEntity.m_6095_()).toString();
        if (entityName.equals("quark:glass_frame")) {
            poseStack.m_252880_(0, 0, 0.475f);
        }

        // Snap to 90 degrees like a map.
        poseStack.m_252781_(Axis.f_252403_.m_252977_(45 * itemFrameEntity.m_31823_()));

        float size = ExposureClient.getExposureRenderer().getSize();

        float scale = 1f / size;
        float pixelScale = scale / 16f;
        scale -= pixelScale * 6;

        poseStack.m_252781_(Axis.f_252403_.m_252977_(180.0F));
        poseStack.m_85841_(scale, scale, scale);
        poseStack.m_252880_(-size / 2f, -size / 2f, 10);

        PhotographRenderer.renderPhotograph(photographItem, itemStack, false, false,
                poseStack, bufferSource, packedLight, 255, 255, 255, 255);

        poseStack.m_85849_();

        return true;
    }
}
