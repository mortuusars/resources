package io.github.mortuusars.exposure.gui.screen.camera.button;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.gui.screen.element.IElementWithTooltip;
import io.github.mortuusars.exposure.util.Fov;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

public class FocalLengthButton extends ImageButton implements IElementWithTooltip {
    private final int secondaryFontColor;
    private final int mainFontColor;

    public FocalLengthButton(Screen screen, int x, int y, int width, int height, int u, int v, ResourceLocation texture) {
        super(x, y, width, height, u, v, height, texture, 256, 256, button -> {}, Component.m_237119_());
        secondaryFontColor = Config.Client.getSecondaryFontColor();
        mainFontColor = Config.Client.getMainFontColor();
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float pPartialTick) {
        super.m_88315_(guiGraphics, mouseX, mouseY, pPartialTick);
    }

    public void renderToolTip(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY) {
        guiGraphics.m_280557_(Minecraft.m_91087_().f_91062_, Component.m_237115_("gui.exposure.viewfinder.focal_length.tooltip"), mouseX, mouseY);
    }

    @Override
    public void m_87963_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.m_87963_(guiGraphics, mouseX, mouseY, partialTick);

        int focalLength = (int)Math.round(Fov.fovToFocalLength(Viewfinder.getCurrentFov()));

        Font font = Minecraft.m_91087_().f_91062_;
        MutableComponent text = Component.m_237110_("gui.exposure.viewfinder.focal_length", focalLength);
        int textWidth = font.m_92852_(text);
        int xPos = 17 + (29 - textWidth) / 2;

        guiGraphics.m_280614_(font, text, m_252754_() + xPos, m_252907_() + 8, secondaryFontColor, false);
        guiGraphics.m_280614_(font, text, m_252754_() + xPos, m_252907_() + 7, mainFontColor, false);
    }
}
