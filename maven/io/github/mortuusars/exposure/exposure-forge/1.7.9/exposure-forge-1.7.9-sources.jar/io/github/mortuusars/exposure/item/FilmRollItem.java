package io.github.mortuusars.exposure.item;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.gui.ClientGUI;
import io.github.mortuusars.exposure.menu.ItemRenameMenu;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class FilmRollItem extends Item implements IFilmItem {
    private final FilmType filmType;
    private final int barColor;

    public FilmRollItem(FilmType filmType, int barColor, Properties properties) {
        super(properties);
        this.filmType = filmType;
        this.barColor = barColor;
    }

    @Override
    public FilmType getType() {
        return filmType;
    }

    public boolean m_142522_(@NotNull ItemStack stack) {
        return getExposedFramesCount(stack) > 0;
    }

    public int m_142158_(@NotNull ItemStack stack) {
        return Math.min(1 + 12 * getExposedFramesCount(stack) / getMaxFrameCount(stack), 13);
    }

    public int m_142159_(@NotNull ItemStack stack) {
        return barColor;
    }

    public void addFrame(ItemStack filmStack, CompoundTag frame) {
        CompoundTag tag = filmStack.m_41784_();

        if (!tag.m_128425_(FRAMES_TAG, Tag.f_178202_)) {
            tag.m_128365_(FRAMES_TAG, new ListTag());
        }

        ListTag listTag = tag.m_128437_(FRAMES_TAG, Tag.f_178203_);

        if (listTag.size() >= getMaxFrameCount(filmStack))
            throw new IllegalStateException("Cannot add more frames than film could fit. Size: " + listTag.size());

        listTag.add(frame);
        tag.m_128365_(FRAMES_TAG, listTag);
    }

    public boolean canAddFrame(ItemStack filmStack) {
        if (!filmStack.m_41782_() || !filmStack.m_41784_().m_128425_(FRAMES_TAG, Tag.f_178202_))
            return true;

        return filmStack.m_41784_().m_128437_(FRAMES_TAG, Tag.f_178203_).size() < getMaxFrameCount(filmStack);
    }

    @Override
    public void m_7373_(@NotNull ItemStack stack, @Nullable Level level, @NotNull List<Component> tooltipComponents, @NotNull TooltipFlag isAdvanced) {
        int exposedFrames = getExposedFramesCount(stack);
        if (exposedFrames > 0) {
            int totalFrames = getMaxFrameCount(stack);
            tooltipComponents.add(Component.m_237110_("item.exposure.film_roll.tooltip.frame_count", exposedFrames, totalFrames)
                    .m_130940_(ChatFormatting.GRAY));
        }

        int frameSize = getFrameSize(stack);
        if (frameSize != getDefaultFrameSize()) {
            tooltipComponents.add(Component.m_237110_("item.exposure.film_roll.tooltip.frame_size",
                    Component.m_237113_(String.format("%.1f", frameSize / 10f)))
                            .m_130940_(ChatFormatting.GRAY));
        }

        if (Config.Common.FILM_ROLL_RENAMING.get()) {
            tooltipComponents.add(Component.m_237115_("item.exposure.film_roll.tooltip.renaming"));
        }

        // Create compat:
        int developingStep = stack.m_41783_() != null ? stack.m_41783_().m_128451_("CurrentDevelopingStep") : 0;
        if (Config.Common.CREATE_SPOUT_DEVELOPING_ENABLED.get() && developingStep > 0) {
            List<? extends String> totalSteps = Config.Common.spoutDevelopingSequence(getType()).get();

            MutableComponent stepsComponent = Component.m_237113_("");

            for (int i = 0; i < developingStep; i++) {
                stepsComponent.m_7220_(Component.m_237113_("I").m_130940_(ChatFormatting.GOLD));
            }

            for (int i = developingStep; i < totalSteps.size(); i++) {
                stepsComponent.m_7220_(Component.m_237113_("I").m_130940_(ChatFormatting.DARK_GRAY));
            }

            tooltipComponents.add(Component.m_237110_("item.exposure.film_roll.tooltip.developing_step", stepsComponent)
                    .m_130940_(ChatFormatting.GOLD));
        }

        //noinspection ConstantValue
        if (exposedFrames > 0 && !PlatformHelper.isModLoaded("jei") && Config.Client.RECIPE_TOOLTIPS_WITHOUT_JEI.get()) {
            ClientGUI.addFilmRollDevelopingTooltip(stack, level, tooltipComponents, isAdvanced);
        }
    }

    @Override
    public @NotNull InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand usedHand) {
        if (!Config.Common.FILM_ROLL_RENAMING.get() || !(player instanceof ServerPlayer serverPlayer)) {
            return super.m_7203_(level, player, usedHand);
        }

        int slot = getMatchingSlotInInventory(player.m_150109_(), player.m_21120_(usedHand));
        MenuProvider menuProvider = new MenuProvider() {
            @Override
            public @NotNull Component m_5446_() {
                return Component.m_237115_("gui.exposure.item_rename.title");
            }

            @Override
            public @NotNull AbstractContainerMenu m_7208_(int containerId, @NotNull Inventory playerInventory, @NotNull Player player) {
                return new ItemRenameMenu(containerId, playerInventory, slot);
            }
        };
        PlatformHelper.openMenu(serverPlayer, menuProvider, buffer -> buffer.writeInt(slot));
        return InteractionResultHolder.m_19090_(player.m_21120_(usedHand));
    }

    protected int getMatchingSlotInInventory(Inventory inventory, ItemStack stack) {
        for (int i = 0; i < inventory.m_6643_(); i++) {
            if (inventory.m_8020_(i).equals(stack)) {
                return i;
            }
        }
        return -1;
    }
}
