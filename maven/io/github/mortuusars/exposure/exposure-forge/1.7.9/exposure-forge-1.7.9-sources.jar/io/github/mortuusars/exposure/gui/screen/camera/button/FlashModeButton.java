package io.github.mortuusars.exposure.gui.screen.camera.button;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.camera.CameraClient;
import io.github.mortuusars.exposure.camera.infrastructure.FlashMode;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class FlashModeButton extends CycleButton {

    private final List<FlashMode> flashModes;

    public FlashModeButton(Screen screen, int x, int y, int width, int height, int u, int v, ResourceLocation texture) {
        super(screen, x, y, width, height, u, v, height, texture);
        flashModes = Arrays.stream(FlashMode.values()).toList();

        Camera<?> camera = CameraClient.getCamera().orElseThrow();
        FlashMode guide = camera.get().getItem().getFlashMode(camera.get().getStack());

        int currentGuideIndex = 0;

        for (int i = 0; i < flashModes.size(); i++) {
            if (flashModes.get(i).getId().equals(guide.getId())) {
                currentGuideIndex = i;
                break;
            }
        }

        setupButtonElements(flashModes.size(), currentGuideIndex);
    }

    @Override
    public void m_7435_(SoundManager handler) {
        handler.m_120367_(SimpleSoundInstance.m_119755_(Exposure.SoundEvents.CAMERA_BUTTON_CLICK.get(),
                Objects.requireNonNull(Minecraft.m_91087_().f_91073_).f_46441_.m_188501_() * 0.15f + 0.93f, 0.7f));
    }

    @Override
    public void m_87963_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.m_87963_(guiGraphics, mouseX, mouseY, partialTick);

        // Icon
        guiGraphics.m_280398_(Exposure.resource("textures/gui/viewfinder/icon/flash_mode/" + flashModes.get(currentIndex).getId() + ".png"),
                m_252754_(), m_252907_() + 4, 0, 0, 0, 15, 14, 15, 14);
    }

    @Override
    public void renderToolTip(@NotNull GuiGraphics pGuiGraphics, int mouseX, int mouseY) {
        pGuiGraphics.m_280677_(Minecraft.m_91087_().f_91062_, List.of(Component.m_237115_("gui.exposure.viewfinder.flash_mode.tooltip"),
                ((MutableComponent) m_6035_()).m_130940_(ChatFormatting.GRAY)), Optional.empty(), mouseX, mouseY);
    }

    @Override
    public @NotNull Component m_6035_() {
        return flashModes.get(currentIndex).translate();
    }

    @Override
    protected void onCycle() {
        CameraClient.setFlashMode(flashModes.get(currentIndex));
    }
}
