package io.github.mortuusars.exposure.menu;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.block.entity.Lightroom;
import io.github.mortuusars.exposure.block.entity.LightroomBlockEntity;
import io.github.mortuusars.exposure.item.DevelopedFilmItem;
import io.github.mortuusars.exposure.item.IFilmItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public class LightroomMenu extends AbstractContainerMenu {
    public static final int PRINT_BUTTON_ID = 0;
    public static final int PRINT_CREATIVE_BUTTON_ID = 1;
    public static final int PREVIOUS_FRAME_BUTTON_ID = 2;
    public static final int NEXT_FRAME_BUTTON_ID = 3;
    public static final int TOGGLE_PROCESS_BUTTON_ID = 4;

    private final LightroomBlockEntity lightroomBlockEntity;
    private final ContainerData data;

    private ListTag frames = new ListTag();

    public LightroomMenu(int containerId, final Inventory playerInventory, final LightroomBlockEntity blockEntity, ContainerData containerData) {
        super(Exposure.MenuTypes.LIGHTROOM.get(), containerId);
        this.lightroomBlockEntity = blockEntity;
        this.data = containerData;

        {
            this.m_38897_(new Slot(blockEntity, Lightroom.FILM_SLOT, -20, 42) {
                @Override
                public boolean m_5857_(ItemStack stack) {
                    return blockEntity.isItemValidForSlot(Lightroom.FILM_SLOT, stack);
                }

                @Override
                public void m_6654_() {
                    frames = m_7993_().m_41720_() instanceof DevelopedFilmItem developedFilm ?
                            developedFilm.getExposedFrames(m_7993_()) : new ListTag();
                    if (lightroomBlockEntity.m_58904_() != null && !lightroomBlockEntity.m_58904_().f_46443_)
                        data.m_8050_(LightroomBlockEntity.CONTAINER_DATA_SELECTED_FRAME_ID, 0);
                    super.m_6654_();
                }
            });

            this.m_38897_(new Slot(blockEntity, Lightroom.PAPER_SLOT, 8, 92){
                @Override
                public boolean m_5857_(ItemStack stack) {
                    return blockEntity.isItemValidForSlot(Lightroom.PAPER_SLOT, stack);
                }
            });
            this.m_38897_(new Slot(blockEntity, Lightroom.CYAN_SLOT, 42, 92){
                @Override
                public boolean m_5857_(ItemStack stack) {
                    return blockEntity.isItemValidForSlot(Lightroom.CYAN_SLOT, stack);
                }
            });
            this.m_38897_(new Slot(blockEntity, Lightroom.MAGENTA_SLOT, 60, 92){
                @Override
                public boolean m_5857_(ItemStack stack) {
                    return blockEntity.isItemValidForSlot(Lightroom.MAGENTA_SLOT, stack);
                }
            });
            this.m_38897_(new Slot(blockEntity, Lightroom.YELLOW_SLOT, 78, 92){
                @Override
                public boolean m_5857_(ItemStack stack) {
                    return blockEntity.isItemValidForSlot(Lightroom.YELLOW_SLOT, stack);
                }
            });
            this.m_38897_(new Slot(blockEntity, Lightroom.BLACK_SLOT, 96, 92){
                @Override
                public boolean m_5857_(ItemStack stack) {
                    return blockEntity.isItemValidForSlot(Lightroom.BLACK_SLOT, stack);
                }
            });

            // OUTPUT
            this.m_38897_(new Slot(blockEntity, Lightroom.RESULT_SLOT, 148, 92) {
                @Override
                public boolean m_5857_(@NotNull ItemStack stack) {
                    return false;
                }

                @Override
                public void m_142406_(@NotNull Player player, @NotNull ItemStack pStack) {
                    super.m_142406_(player, pStack);
                    blockEntity.dropStoredExperience(player);
                }

                @Override
                public void m_40234_(@NotNull ItemStack oldStackIn, @NotNull ItemStack newStackIn) {
                    super.m_40234_(oldStackIn, newStackIn);
                    blockEntity.dropStoredExperience(playerInventory.f_35978_);
                }
            });
        }

        // Player inventory slots
        for(int row = 0; row < 3; ++row) {
            for(int column = 0; column < 9; ++column) {
                this.m_38897_(new Slot(playerInventory, column + row * 9 + 9, 8 + column * 18, 127 + row * 18));
            }
        }

        // Player hotbar slots
        // Hotbar should go after main inventory for Shift+Click to work properly.
        for(int index = 0; index < 9; ++index) {
            this.m_38897_(new Slot(playerInventory, index, 8 + index * 18, 185));
        }

        this.m_38884_(data);
    }

    public static LightroomMenu fromBuffer(int containerID, Inventory playerInventory, FriendlyByteBuf buffer) {
        return new LightroomMenu(containerID, playerInventory, getBlockEntity(playerInventory, buffer),
                new SimpleContainerData(LightroomBlockEntity.CONTAINER_DATA_SIZE));
    }

    public LightroomBlockEntity getBlockEntity() {
        return lightroomBlockEntity;
    }

    public ContainerData getData() {
        return data;
    }

    public ListTag getExposedFrames() {
        return frames;
    }

    public @Nullable CompoundTag getFrameIdByIndex(int index) {
        return index >= 0 && index < getExposedFrames().size() ? getExposedFrames().m_128728_(index) : null;
    }

    public int getSelectedFrame() {
        return data.m_6413_(LightroomBlockEntity.CONTAINER_DATA_SELECTED_FRAME_ID);
    }

    public boolean isPrinting() {
        return data.m_6413_(LightroomBlockEntity.CONTAINER_DATA_PRINT_TIME_ID) > 0;
    }

    public int getTotalFrames() {
        ItemStack filmStack = getBlockEntity().m_8020_(Lightroom.FILM_SLOT);
        return (!filmStack.m_41619_() && filmStack.m_41720_() instanceof IFilmItem filmItem) ? filmItem.getExposedFramesCount(filmStack) : 0;
    }

    public boolean canChangeProcess() {
        return getBlockEntity().canPrintChromatic(getBlockEntity().m_8020_(Lightroom.FILM_SLOT), getSelectedFrame());
    }

    @Override
    public boolean m_6366_(Player player, int buttonId) {
        Preconditions.checkState(!player.m_9236_().f_46443_, "This should be server-side only.");

        if (buttonId == PREVIOUS_FRAME_BUTTON_ID || buttonId == NEXT_FRAME_BUTTON_ID) {
            ItemStack filmStack = getBlockEntity().m_8020_(Lightroom.FILM_SLOT);
            if (!filmStack.m_41619_() && filmStack.m_41720_() instanceof DevelopedFilmItem) {
                int frames = getTotalFrames();
                if (frames == 0)
                    return true;

                int selectedFrame = data.m_6413_(LightroomBlockEntity.CONTAINER_DATA_SELECTED_FRAME_ID);
                selectedFrame = selectedFrame + (buttonId == NEXT_FRAME_BUTTON_ID ? 1 : -1);
                selectedFrame = Mth.m_14045_(selectedFrame, 0, frames - 1);
                data.m_8050_(LightroomBlockEntity.CONTAINER_DATA_SELECTED_FRAME_ID, selectedFrame);
                return true;
            }
        }

        if (buttonId == TOGGLE_PROCESS_BUTTON_ID) {
            Lightroom.Process currentProcess = getBlockEntity().getProcess();
            getBlockEntity().setProcess(currentProcess == Lightroom.Process.CHROMATIC ? Lightroom.Process.REGULAR : Lightroom.Process.CHROMATIC);
        }

        if (buttonId == PRINT_BUTTON_ID) {
            getBlockEntity().startPrintingProcess(false);
            return true;
        }

        if (buttonId == PRINT_CREATIVE_BUTTON_ID) {
            if (player.m_7500_())
                getBlockEntity().printInCreativeMode();
        }

        return false;
    }

    @Override
    public @NotNull ItemStack m_7648_(@NotNull Player player, int index) {
        Slot slot = f_38839_.get(index);
        ItemStack clickedStack = slot.m_7993_();
        ItemStack returnedStack = clickedStack.m_41777_();

         if (index < Lightroom.SLOTS) {
            if (!m_38903_(clickedStack, Lightroom.SLOTS, f_38839_.size(), true)) {
                return ItemStack.f_41583_;
            }

            if (index == Lightroom.RESULT_SLOT)
                slot.m_40234_(clickedStack, returnedStack);
        }
        else if (index < f_38839_.size()) {
            if (!m_38903_(clickedStack, 0, Lightroom.SLOTS, false))
                return ItemStack.f_41583_;
        }

        if (clickedStack.m_41619_()) {
            slot.m_5852_(ItemStack.f_41583_);
        } else {
            slot.m_6654_();
        }

        return returnedStack;
    }

    /**
     * Fixed method to respect slot photo limit.
     */
    @Override
    protected boolean m_38903_(ItemStack movedStack, int startIndex, int endIndex, boolean reverseDirection) {
        boolean hasRemainder = false;
        int i = startIndex;
        if (reverseDirection) {
            i = endIndex - 1;
        }
        if (movedStack.m_41753_()) {
            while (!movedStack.m_41619_() && !(!reverseDirection ? i >= endIndex : i < startIndex)) {
                Slot slot = this.f_38839_.get(i);
                ItemStack slotStack = slot.m_7993_();
                if (!slotStack.m_41619_() && ItemStack.m_150942_(movedStack, slotStack)) {
                    int maxSize;
                    int j = slotStack.m_41613_() + movedStack.m_41613_();
                    if (j <= (maxSize = Math.min(slot.m_6641_(), movedStack.m_41741_()))) {
                        movedStack.m_41764_(0);
                        slotStack.m_41764_(j);
                        slot.m_6654_();
                        hasRemainder = true;
                    } else if (slotStack.m_41613_() < maxSize) {
                        movedStack.m_41774_(maxSize - slotStack.m_41613_());
                        slotStack.m_41764_(maxSize);
                        slot.m_6654_();
                        hasRemainder = true;
                    }
                }
                if (reverseDirection) {
                    --i;
                    continue;
                }
                ++i;
            }
        }
        if (!movedStack.m_41619_()) {
            i = reverseDirection ? endIndex - 1 : startIndex;
            while (!(!reverseDirection ? i >= endIndex : i < startIndex)) {
                Slot slot1 = this.f_38839_.get(i);
                ItemStack itemmovedStack1 = slot1.m_7993_();
                if (itemmovedStack1.m_41619_() && slot1.m_5857_(movedStack)) {
                    if (movedStack.m_41613_() > slot1.m_6641_()) {
                        slot1.m_269060_(movedStack.m_41620_(slot1.m_6641_()));
                    } else {
                        slot1.m_269060_(movedStack.m_41620_(movedStack.m_41613_()));
                    }
                    slot1.m_6654_();
                    hasRemainder = true;
                    break;
                }
                if (reverseDirection) {
                    --i;
                    continue;
                }
                ++i;
            }
        }
        return hasRemainder;
    }

    @Override
    public boolean m_6875_(@NotNull Player player) {
        return lightroomBlockEntity.m_6542_(player);
    }

    private static LightroomBlockEntity getBlockEntity(final Inventory playerInventory, final FriendlyByteBuf data) {
        Objects.requireNonNull(playerInventory, "playerInventory cannot be null");
        Objects.requireNonNull(data, "data cannot be null");
        final BlockEntity blockEntityAtPos = playerInventory.f_35978_.m_9236_().m_7702_(data.m_130135_());
        if (blockEntityAtPos instanceof LightroomBlockEntity blockEntity)
            return blockEntity;
        throw new IllegalStateException("Block entity is not correct! " + blockEntityAtPos);
    }
}
