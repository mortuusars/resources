package io.github.mortuusars.exposure.render.modifiers;

import net.minecraft.util.FastColor;

@SuppressWarnings({"ClassCanBeRecord", "unused"})
public class MultiplyPixelModifier implements IPixelModifier {
    public final int multiplyColor;

    public MultiplyPixelModifier(int multiplyColor) {
        this.multiplyColor = multiplyColor;
    }

    @Override
    public int modifyPixel(int ABGR) {
        if (multiplyColor == 0)
            return ABGR;

        int alpha = FastColor.ABGR32.m_266503_(ABGR);
        int blue = FastColor.ABGR32.m_266247_(ABGR);
        int green = FastColor.ABGR32.m_266446_(ABGR);
        int red = FastColor.ABGR32.m_266313_(ABGR);

        int tintAlpha = FastColor.ARGB32.m_13655_(ABGR);
        int tintBlue = FastColor.ARGB32.m_13669_(ABGR);
        int tintGreen = FastColor.ARGB32.m_13667_(ABGR);
        int tintRed = FastColor.ARGB32.m_13665_(ABGR);

        alpha = Math.min(255, (alpha * tintAlpha) / 255);
        blue = Math.min(255, (blue * tintBlue) / 255);
        green = Math.min(255, (green * tintGreen) / 255);
        red = Math.min(255, (red * tintRed) / 255);

        return FastColor.ABGR32.m_266248_(alpha, blue, green, red);
    }

    @Override
    public String getIdSuffix() {
        return multiplyColor != 0 ? "_tint" + Integer.toHexString(multiplyColor) : "";
    }
}
