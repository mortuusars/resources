package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.item.StackedPhotographsItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Gui.class)
public abstract class GuiMixin {
    @Inject(method = "render", at = @At(value = "HEAD"), cancellable = true)
    private void renderGui(GuiGraphics guiGraphics, float partialTick, CallbackInfo ci) {
        if (Viewfinder.isLookingThrough())
            ci.cancel();
    }

    @Inject(method = "renderCrosshair", at = @At(value = "HEAD"), cancellable = true)
    private void renderCrosshair(GuiGraphics guiGraphics, CallbackInfo ci) {
        Minecraft mc = Minecraft.m_91087_();
        if (Config.Client.PHOTOGRAPH_IN_HAND_HIDE_CROSSHAIR.get() && mc.f_91074_ != null && mc.f_91074_.m_146909_() > 25f
                && (mc.f_91074_.m_21205_().m_41720_() instanceof PhotographItem || mc.f_91074_.m_21205_().m_41720_() instanceof StackedPhotographsItem)
                && mc.f_91074_.m_21206_().m_41619_())
            ci.cancel();
    }
}
