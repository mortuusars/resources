package io.github.mortuusars.exposure.data.storage;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.capture.CapturedFramesHistory;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.ExposureChangedS2CP;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.DimensionDataStorage;
import net.minecraft.world.level.storage.LevelResource;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

public class ServersideExposureStorage implements IServersideExposureStorage {
    
    private static final String EXPOSURE_DIR = "exposures";

    private final MinecraftServer server;

    private final Supplier<DimensionDataStorage> levelStorageSupplier;
    private final Supplier<Path> worldPathSupplier;

    public ServersideExposureStorage(MinecraftServer server) {
        this.server = server;
        this.levelStorageSupplier = () -> server.m_129783_().m_8895_();
        this.worldPathSupplier = () -> server.m_129843_(LevelResource.f_78182_);
    }

    @Override
    public Optional<ExposureSavedData> getOrQuery(String id) {
        DimensionDataStorage dataStorage = levelStorageSupplier.get();
        @Nullable ExposureSavedData loadedExposureData = dataStorage.m_164858_(ExposureSavedData::load, getSaveId(id));

        if (loadedExposureData == null)
            Exposure.LOGGER.error("Exposure '{}' was not loaded. File does not exist or some error occurred.", id);

        return Optional.ofNullable(loadedExposureData);
    }

    @Override
    public void put(String id, ExposureSavedData data) {
        if (createStorageDirectory()) {
            DimensionDataStorage dataStorage = levelStorageSupplier.get();
            dataStorage.m_164855_(getSaveId(id), data);
            data.m_77762_();

            if (server.m_6982_()) {
                CompoundTag frameTag = new CompoundTag();
                frameTag.m_128359_(FrameData.ID, id);
                CapturedFramesHistory.add(frameTag);
            }
        }
    }

    public List<String> getAllIds() {
        // Save exposures that are in cache and waiting to be saved:
        levelStorageSupplier.get().m_78151_();

        Path path = worldPathSupplier.get().resolve("data/" + EXPOSURE_DIR);
        File folder = path.toFile();

        @Nullable File[] listOfFiles = folder.listFiles();
        if (listOfFiles == null)
            return Collections.emptyList();

        List<String> ids = new ArrayList<>();

        for (File file : listOfFiles) {
            if (file != null && file.isFile())
                ids.add(com.google.common.io.Files.getNameWithoutExtension(file.getName()));
        }

        return ids;
    }

    @Override
    public void clear() {
        Exposure.LOGGER.warn("Clearing Server Exposure Storage is not implemented.");
    }

    /**
     * When exposure on the server changes we need to notify client to re-query it.
     * Otherwise, due to caching, client wouldn't know about the change.
     */
    public void sendExposureChanged(String exposureId) {
        Packets.sendToAllClients(new ExposureChangedS2CP(exposureId));
    }

    private String getSaveId(String id) {
        return EXPOSURE_DIR + "/" + id;
    }

    private boolean createStorageDirectory() {
        try {
            Path path = worldPathSupplier.get().resolve("data/" + EXPOSURE_DIR);
            return Files.exists(path) || path.toFile().mkdirs();
        }
        catch (Exception e) {
            Exposure.LOGGER.error("Failed to create exposure storage directory: {}", e.toString());
            return false;
        }
    }
}
