package io.github.mortuusars.exposure.gui.screen.album;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.mortuusars.exposure.gui.screen.element.textbox.HorizontalAlignment;
import io.github.mortuusars.exposure.gui.screen.element.textbox.TextBox;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.server.AlbumSignC2SP;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public class AlbumSigningScreen extends Screen {
    public static final int SELECTION_COLOR = 0xFF8888FF;
    public static final int SELECTION_UNFOCUSED_COLOR = 0xFFBBBBFF;

    @NotNull
    protected final Minecraft minecraft;
    @NotNull
    protected final Player player;

    protected final Screen parentScreen;
    protected final ResourceLocation texture;

    protected int imageWidth, imageHeight, leftPos, topPos, textureWidth, textureHeight;

    protected TextBox titleTextBox;
    protected ImageButton signButton;
    protected ImageButton cancelSigningButton;

    protected String titleText = "";

    public AlbumSigningScreen(Screen screen, ResourceLocation texture, int textureWidth, int textureHeight) {
        super(Component.m_237119_());
        this.parentScreen = screen;
        this.texture = texture;
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;

        f_96541_ = Minecraft.m_91087_();
        player = Objects.requireNonNull(f_96541_.f_91074_);
    }

    @Override
    protected void m_7856_() {
        this.imageWidth = 149;
        this.imageHeight = 188;
        this.leftPos = (this.f_96543_ - this.imageWidth) / 2;
        this.topPos = (this.f_96544_ - this.imageHeight) / 2;

        // TITLE
        titleTextBox = new TextBox(f_96547_, leftPos + 21, topPos + 73, 108, 9,
                () -> titleText, text -> titleText = text)
                .setFontColor(0xFF856036, 0xFF856036)
                .setSelectionColor(SELECTION_COLOR, SELECTION_UNFOCUSED_COLOR);
        titleTextBox.textValidator = text -> text != null && f_96547_.m_92920_(text, 108) <= 9 && !text.contains("\n");
        titleTextBox.horizontalAlignment = HorizontalAlignment.CENTER;
        m_142416_(titleTextBox);

        // SIGN
        signButton = new ImageButton(leftPos + 46, topPos + 110, 22, 22, 242, 188,
                22, texture, textureWidth, textureHeight,
                b -> signAlbum(), Component.m_237115_("gui.exposure.album.sign"));
        MutableComponent component = Component.m_237115_("gui.exposure.album.sign")
                .m_130946_("\n").m_7220_(Component.m_237115_("gui.exposure.album.sign.warning").m_130940_(ChatFormatting.GRAY));
        signButton.m_257544_(Tooltip.m_257550_(component));
        m_142416_(signButton);

        // CANCEL
        cancelSigningButton = new ImageButton(leftPos + 83, topPos + 111, 22, 22, 264, 188,
                22, texture, textureWidth, textureHeight,
                b -> cancelSigning(), Component.m_237115_("gui.exposure.album.cancel_signing"));
        cancelSigningButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.exposure.album.cancel_signing")));
        m_142416_(cancelSigningButton);

        m_264313_(titleTextBox);
    }

    @Override
    public boolean m_7043_() {
        return false;
    }

    @Override
    public void m_86600_() {
        titleTextBox.tick();
    }

    private void updateButtons() {
        signButton.f_93623_ = canSign();
    }

    protected boolean canSign() {
        return !titleText.isEmpty();
    }

    @Override
    public void m_88315_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();

        m_280273_(guiGraphics);
        guiGraphics.m_280398_(texture, leftPos, topPos, 0, 298,
                0, imageWidth, imageHeight, textureWidth, textureHeight);
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);

        renderLabels(guiGraphics);
    }

    private void renderLabels(GuiGraphics guiGraphics) {
        MutableComponent component = Component.m_237115_("gui.exposure.album.enter_title");
        guiGraphics.m_280614_(f_96547_, component,  leftPos + 149 / 2 - f_96547_.m_92852_(component) / 2, topPos + 50, 0xf5ebd0, false);

        component = Component.m_237110_("gui.exposure.album.by_author", player.m_7755_());
        guiGraphics.m_280614_(f_96547_, component, leftPos + 149 / 2 - f_96547_.m_92852_(component) / 2, topPos + 84, 0xc7b496, false);
    }

    protected void signAlbum() {
        if (canSign()) {
            Packets.sendToServer(new AlbumSignC2SP(titleText));
            this.m_7379_();
        }
    }

    protected void cancelSigning() {
        f_96541_.m_91152_(parentScreen);
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (keyCode == InputConstants.f_166295_)
            return super.m_7933_(keyCode, scanCode, modifiers);

        if (keyCode == InputConstants.f_166305_) {
            cancelSigning();
            return true;
        }

        if (titleTextBox.m_93696_())
            return titleTextBox.m_7933_(keyCode, scanCode, modifiers);

        return super.m_7933_(keyCode, scanCode, modifiers);
    }
}
