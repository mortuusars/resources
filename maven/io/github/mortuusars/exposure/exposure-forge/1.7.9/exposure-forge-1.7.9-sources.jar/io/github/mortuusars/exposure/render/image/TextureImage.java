package io.github.mortuusars.exposure.render.image;

import com.mojang.blaze3d.platform.NativeImage;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.util.concurrent.Executor;

public class TextureImage extends SimpleTexture implements IImage {
    private final String name;
    @Nullable
    private NativeImage image;

    public TextureImage(ResourceLocation location) {
        super(location);
        name = location.toString();
    }

    @Override
    public String getImageId() {
        return name;
    }

    @Override
    public int getWidth() {
        @Nullable NativeImage image = getImage();
        return image != null ? image.m_84982_() : 1;
    }

    @Override
    public int getHeight() {
        @Nullable NativeImage image = getImage();
        return image != null ? image.m_85084_() : 1;
    }

    @Override
    public int getPixelABGR(int x, int y) {
        @Nullable NativeImage image = getImage();
        return image != null ? image.m_84985_(x, y) : 0x00000000;
    }

    public static @Nullable io.github.mortuusars.exposure.render.image.TextureImage getTexture(ResourceLocation location) {
        TextureManager textureManager = Minecraft.m_91087_().m_91097_();

        @Nullable AbstractTexture existingTexture = textureManager.f_118468_.get(location);
        if (existingTexture != null) {
            return existingTexture instanceof io.github.mortuusars.exposure.render.image.TextureImage exposureTexture ? exposureTexture : null;
        }

        try {
            io.github.mortuusars.exposure.render.image.TextureImage texture = new io.github.mortuusars.exposure.render.image.TextureImage(location);
            textureManager.m_118495_(location, texture);
            return texture;
        }
        catch (Exception e) {
            Exposure.LOGGER.error("Cannot load texture [{}]. {}", location, e);
            return null;
        }
    }

    public @Nullable NativeImage getImage() {
        if (this.image != null)
            return image;

        try {
            NativeImage image = super.m_6335_(Minecraft.m_91087_().m_91098_()).m_118158_();
            this.image = image;
            return image;
        } catch (IOException e) {
            Exposure.LOGGER.error("Cannot load texture: {}", e.toString());
            return null;
        }
    }

    @Override
    public void m_6479_(@NotNull TextureManager pTextureManager, @NotNull ResourceManager pResourceManager, @NotNull ResourceLocation pPath, @NotNull Executor pExecutor) {
        super.m_6479_(pTextureManager, pResourceManager, pPath, pExecutor);
        if (image != null) {
            image.close();
            image = null;
        }
    }

    @Override
    public void close() {
        super.close();

        if (this.image != null) {
            image.close();
            image = null;
        }
    }
}
