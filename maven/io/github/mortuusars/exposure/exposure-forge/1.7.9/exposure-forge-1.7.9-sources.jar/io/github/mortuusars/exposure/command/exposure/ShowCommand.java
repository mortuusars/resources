package io.github.mortuusars.exposure.command.exposure;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.command.argument.TextureLocationArgument;
import io.github.mortuusars.exposure.command.suggestion.ExposureIdSuggestionProvider;
import io.github.mortuusars.exposure.data.storage.ExposureSavedData;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.ShowExposureS2CP;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import java.util.Optional;

public class ShowCommand {
    public static LiteralArgumentBuilder<CommandSourceStack> get() {
        return Commands.m_82127_("show")
                .then(Commands.m_82127_("latest")
                        .executes(context -> latest(context.getSource(), false))
                        .then(Commands.m_82127_("negative")
                                .executes(context -> latest(context.getSource(), true))))
                .then(Commands.m_82127_("id")
                        .then(Commands.m_82129_("id", StringArgumentType.string())
                                .suggests(new ExposureIdSuggestionProvider())
                                .executes(context -> exposureId(context.getSource(),
                                        StringArgumentType.getString(context, "id"), false))
                                .then(Commands.m_82127_("negative")
                                        .executes(context -> exposureId(context.getSource(),
                                                StringArgumentType.getString(context, "id"), true)))))
                .then(Commands.m_82127_("texture")
                        .then(Commands.m_82129_("path", new TextureLocationArgument())
                                .executes(context -> texture(context.getSource(),
                                        ResourceLocationArgument.m_107011_(context, "path"), false))
                                .then(Commands.m_82127_("negative")
                                        .executes(context -> texture(context.getSource(),
                                                ResourceLocationArgument.m_107011_(context, "path"), true)))));
    }

    private static int latest(CommandSourceStack stack, boolean negative) {
        ServerPlayer player = stack.m_230896_();
        if (player == null) {
            stack.m_81352_(Component.m_237115_("command.exposure.show.error.not_a_player"));
            return 1;
        }

        Packets.sendToClient(ShowExposureS2CP.latest(negative), player);
        return 0;
    }

    private static int exposureId(CommandSourceStack stack, String id, boolean negative) {
        ServerPlayer player = stack.m_230896_();
        if (player == null) {
            stack.m_81352_(Component.m_237115_("command.exposure.show.error.not_a_player"));
            return 1;
        }

        Optional<ExposureSavedData> exposureData = ExposureServer.getExposureStorage().getOrQuery(id);
        if (exposureData.isEmpty()) {
            stack.m_81352_(Component.m_237110_("command.exposure.show.error.not_found", id));
            return 0;
        }

        ExposureServer.getExposureSender().sendTo(player, id, exposureData.get());

        Packets.sendToClient(ShowExposureS2CP.id(id, negative), player);

        return 0;
    }

    private static int texture(CommandSourceStack stack, ResourceLocation path, boolean negative) {
        ServerPlayer player = stack.m_230896_();
        if (player == null) {
            stack.m_81352_(Component.m_237115_("command.exposure.show.error.not_a_player"));
            return 1;
        }

        Packets.sendToClient(ShowExposureS2CP.texture(path.toString(), negative), player);

        return 0;
    }
}
