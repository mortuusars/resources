package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.packet.IPacket;
import io.github.mortuusars.exposure.sound.OnePerPlayerSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public record StopOnePerPlayerSoundS2CP(UUID sourcePlayerId, SoundEvent soundEvent) implements IPacket {
    
    public static final ResourceLocation ID = Exposure.resource("stop_one_per_player_sound");

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    public FriendlyByteBuf toBuffer(FriendlyByteBuf buffer) {
        buffer.m_130077_(sourcePlayerId);
        buffer.m_130085_(soundEvent.m_11660_());
        return buffer;
    }

    public static StopOnePerPlayerSoundS2CP fromBuffer(FriendlyByteBuf buffer) {
        UUID uuid = buffer.m_130259_();
        ResourceLocation soundEventLocation = buffer.m_130281_();
        @Nullable SoundEvent soundEvent = BuiltInRegistries.f_256894_.m_7745_(soundEventLocation);
        if (soundEvent == null)
            soundEvent = SoundEvents.f_12209_.m_203334_();

        return new StopOnePerPlayerSoundS2CP(uuid, soundEvent);
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable Player player) {
        if (Minecraft.m_91087_().f_91073_ != null) {
            @Nullable Player sourcePlayer = Minecraft.m_91087_().f_91073_.m_46003_(sourcePlayerId);
            if (sourcePlayer != null)
                Minecraft.m_91087_().execute(() -> OnePerPlayerSounds.stop(sourcePlayer, soundEvent));
            else
                Exposure.LOGGER.debug("Cannot stop OnePerPlayer sound. SourcePlayer was not found by it's UUID.");
        }

        return true;
    }
}
