package io.github.mortuusars.exposure.gui.screen;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.menu.ItemRenameMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundRenameItemPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public class ItemRenameScreen extends AbstractContainerScreen<ItemRenameMenu> {
    public static final ResourceLocation TEXTURE = Exposure.resource("textures/gui/item_rename.png");

    private EditBox name;

    public ItemRenameScreen(ItemRenameMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected void m_7856_() {
        f_97726_ = 206;
        f_97727_ = 66;
        f_97730_ = -999;
        f_97731_ = -999;
        f_97728_ = 28;
        super.m_7856_();

        name = new EditBox(this.f_96547_, f_97735_ + 32, f_97736_ + 21, 142, 12, Component.m_237115_("gui.exposure.item_rename.title"));
        name.m_94202_(-1);
        name.m_94205_(-1);
        name.m_94182_(false);
        name.m_94199_(ItemRenameMenu.MAX_NAME_LENGTH);
        name.m_94151_(this::onNameChanged);
        name.m_94144_(m_6262_().getItemName());
        m_7787_(name);
        m_264313_(name);

        ImageButton applyButton = new ImageButton(f_97735_ + 133, f_97736_ + 42, 19, 19,
                f_97726_, 0, 19, TEXTURE, 256, 256,
                button -> confirm(), Component.m_237115_("gui.exposure.item_rename.apply"));
        applyButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.exposure.item_rename.apply")));
        m_142416_(applyButton);

        ImageButton cancelButton = new ImageButton(f_97735_ + 154, f_97736_ + 42, 19, 19,
                f_97726_ + 19, 0, 19, TEXTURE, 256, 256,
                button -> cancel(), Component.m_237115_("gui.exposure.item_rename.cancel"));
        cancelButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.exposure.item_rename.cancel")));
        m_142416_(cancelButton);
    }

    private void confirm() {
        m_6262_().m_6366_(Minecraft.m_91087_().f_91074_, ItemRenameMenu.APPLY_BUTTON_ID);
        Objects.requireNonNull(Minecraft.m_91087_().f_91072_).m_105208_(m_6262_().f_38840_, ItemRenameMenu.APPLY_BUTTON_ID);
        m_7379_();
    }

    private void cancel() {
        m_7379_();
    }

    @Override
    public void m_6574_(Minecraft minecraft, int width, int height) {
        String string = this.name.m_94155_();
        this.m_6575_(minecraft, width, height);
        this.name.m_94144_(string);
    }

    @Override
    public void m_181908_() {
        super.m_181908_();
        name.m_94120_();
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        m_280273_(guiGraphics);
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
        this.name.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
        m_280072_(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void m_280072_(GuiGraphics guiGraphics, int x, int y) {
        super.m_280072_(guiGraphics, x, y);
    }

    @Override
    protected void m_7286_(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        guiGraphics.m_280218_(TEXTURE, f_97735_, f_97736_, 0, 0, f_97726_, f_97727_);
    }


    private void onNameChanged(String name) {
        ItemStack itemStack = m_6262_().m_38853_(0).m_7993_();
        if (!itemStack.m_41788_() && name.equals(itemStack.m_41786_().getString())) {
            name = "";
        }

        if (m_6262_().setItemName(name) && Minecraft.m_91087_().f_91074_ != null) {
            Minecraft.m_91087_().f_91074_.f_108617_.m_104955_(new ServerboundRenameItemPacket(name));
        }
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            m_7379_();
        }

        if (keyCode != InputConstants.f_166295_ && (name.m_7933_(keyCode, scanCode, modifiers) || name.m_94204_())) {
            return true;
        }

        return super.m_7933_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        if (button == InputConstants.f_166349_ && name.m_5953_(mouseX, mouseY)) {
            name.m_94144_("");
            return true;
        }

        return super.m_6375_(mouseX, mouseY, button);
    }
}
