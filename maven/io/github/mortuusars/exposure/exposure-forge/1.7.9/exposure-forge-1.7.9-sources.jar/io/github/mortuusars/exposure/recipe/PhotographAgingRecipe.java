package io.github.mortuusars.exposure.recipe;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.core.NonNullList;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.ShapedRecipe;
import org.jetbrains.annotations.NotNull;

public class PhotographAgingRecipe extends AbstractNbtTransferringRecipe{
    public PhotographAgingRecipe(ResourceLocation id, Ingredient transferIngredient,
                                 NonNullList<Ingredient> ingredients, ItemStack result) {
        super(id, transferIngredient, ingredients, result);
    }

    @Override
    public @NotNull RecipeSerializer<?> m_7707_() {
        return Exposure.RecipeSerializers.PHOTOGRAPH_AGING.get();
    }

    public static class Serializer implements RecipeSerializer<PhotographAgingRecipe> {
        @Override
        public @NotNull PhotographAgingRecipe m_6729_(ResourceLocation recipeId, JsonObject serializedRecipe) {
            Ingredient photographIngredient = Ingredient.m_43917_(GsonHelper.m_289747_(serializedRecipe, "photograph"));
            NonNullList<Ingredient> ingredients = getIngredients(GsonHelper.m_13933_(serializedRecipe, "ingredients"));
            ItemStack result = ShapedRecipe.m_151274_(GsonHelper.m_13930_(serializedRecipe, "result"));

            if (photographIngredient.m_43947_())
                throw new JsonParseException("Recipe should have 'photograph' ingredient.");

            return new PhotographAgingRecipe(recipeId, photographIngredient, ingredients, result);
        }

        @Override
        public @NotNull PhotographAgingRecipe m_8005_(ResourceLocation recipeId, FriendlyByteBuf buffer) {
            Ingredient transferredIngredient = Ingredient.m_43940_(buffer);
            int ingredientsCount = buffer.m_130242_();
            NonNullList<Ingredient> ingredients = NonNullList.m_122780_(ingredientsCount, Ingredient.f_43901_);
            ingredients.replaceAll(ignored -> Ingredient.m_43940_(buffer));
            ItemStack result = buffer.m_130267_();

            return new PhotographAgingRecipe(recipeId, transferredIngredient, ingredients, result);
        }

        @Override
        public void toNetwork(FriendlyByteBuf buffer, PhotographAgingRecipe recipe) {
            recipe.getTransferIngredient().m_43923_(buffer);
            buffer.m_130130_(recipe.m_7527_().size());
            for (Ingredient ingredient : recipe.m_7527_()) {
                ingredient.m_43923_(buffer);
            }
            buffer.m_130055_(recipe.getResult());
        }

        private NonNullList<Ingredient> getIngredients(JsonArray jsonArray) {
            NonNullList<Ingredient> ingredients = NonNullList.m_122779_();

            for (int i = 0; i < jsonArray.size(); ++i) {
                Ingredient ingredient = Ingredient.m_43917_(jsonArray.get(i));
                if (!ingredient.m_43947_())
                    ingredients.add(ingredient);
            }

            if (ingredients.isEmpty())
                throw new JsonParseException("No ingredients for a recipe.");
            else if (ingredients.size() > 3 * 3)
                throw new JsonParseException("Too many ingredients for a recipe. The maximum is 9.");
            return ingredients;
        }
    }
}
