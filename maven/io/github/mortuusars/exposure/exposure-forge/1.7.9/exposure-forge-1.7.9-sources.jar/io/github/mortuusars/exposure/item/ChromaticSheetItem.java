package io.github.mortuusars.exposure.item;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.camera.capture.converter.DitheringColorConverter;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.data.storage.ExposureSavedData;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.CreateChromaticExposureS2CP;
import io.github.mortuusars.exposure.network.packet.client.WaitForExposureChangeS2CP;
import io.github.mortuusars.exposure.render.image.ExposureDataImage;
import io.github.mortuusars.exposure.render.image.IImage;
import io.github.mortuusars.exposure.util.ColorChannel;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.FastColor;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ChromaticSheetItem extends Item {
    public static final String EXPOSURES_TAG = "Exposures";

    public ChromaticSheetItem(Properties properties) {
        super(properties);
    }

    public List<CompoundTag> getExposures(ItemStack stack) {
        if (stack.m_41783_() == null || !stack.m_41783_().m_128425_(EXPOSURES_TAG, Tag.f_178202_))
            return Collections.emptyList();

        ListTag channelsList = stack.m_41783_().m_128437_(EXPOSURES_TAG, Tag.f_178203_);
        return channelsList.stream().map(t -> (CompoundTag)t).collect(Collectors.toList());
    }

    public void addExposure(ItemStack stack, CompoundTag frame) {
        ListTag channelsList = getOrCreateExposuresTag(stack);
        channelsList.add(frame);
        stack.m_41784_().m_128365_(EXPOSURES_TAG, channelsList);
    }

    private ListTag getOrCreateExposuresTag(ItemStack stack) {
        CompoundTag tag = stack.m_41784_();
        ListTag list = tag.m_128437_(EXPOSURES_TAG, Tag.f_178203_);
        tag.m_128365_(EXPOSURES_TAG, list);
        return list;
    }

    @Override
    public void m_7373_(ItemStack stack, @Nullable Level level, List<Component> tooltipComponents, TooltipFlag isAdvanced) {
        List<CompoundTag> exposures = getExposures(stack);

        if (!exposures.isEmpty()) {
            MutableComponent component = Component.m_237115_("gui.exposure.channel.red")
                    .m_130948_(Style.f_131099_.m_178520_(ColorChannel.RED.getRepresentationColor()));

            if (exposures.size() >= 2){
                component.m_7220_(Component.m_237115_("gui.exposure.channel.separator").m_130940_(ChatFormatting.GRAY));
                component.m_7220_(Component.m_237115_("gui.exposure.channel.green")
                        .m_130948_(Style.f_131099_.m_178520_(ColorChannel.GREEN.getRepresentationColor())));
            }

            if (exposures.size() >= 3) {
                component.m_7220_(Component.m_237115_("gui.exposure.channel.separator").m_130940_(ChatFormatting.GRAY));
                component.m_7220_(Component.m_237115_("gui.exposure.channel.blue")
                        .m_130948_(Style.f_131099_.m_178520_(ColorChannel.BLUE.getRepresentationColor())));
            }

            tooltipComponents.add(component);

            if (exposures.size() >= 3) {
                tooltipComponents.add(Component.m_237115_("item.exposure.chromatic_sheet.use_tooltip").m_130940_(ChatFormatting.GRAY));
            }
            else {
                tooltipComponents.add(Component.m_237115_("item.exposure.chromatic_sheet.info").m_130940_(ChatFormatting.GRAY));
            }
        }
    }

    @Override
    public void m_6883_(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
        if (entity instanceof ServerPlayer player
                && stack.m_41783_() != null && stack.m_41783_().m_128471_("RequiresDeferredFinalization")) {
            ItemStack finalizedItem = finalize(level, stack, player.m_6302_(), player);
            player.m_150109_().m_6836_(slotId, finalizedItem);
        }
    }

    @Override
    public @NotNull InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand usedHand) {
        ItemStack stack = player.m_21120_(usedHand);

        if (!level.f_46443_ && getExposures(stack).size() >= 3) {
            ItemStack result = finalize(level, stack, player.m_6302_(),
                    player instanceof ServerPlayer serverPlayer ? serverPlayer : null);
            player.m_21008_(usedHand, result);
            return InteractionResultHolder.m_19090_(result);
        }

        return super.m_7203_(level, player, usedHand);
    }

    public ItemStack finalize(@NotNull Level level, ItemStack stack, String idPrefix, @Nullable ServerPlayer player) {
        Preconditions.checkState(!level.f_46443_, "Can only finalize server-side.");

        List<CompoundTag> exposures = getExposures(stack);

        Preconditions.checkState(exposures.size() >= 3, 
                "Finalizing Chromatic Fragment requires 3 exposures. " + stack);

        CompoundTag redFrame = exposures.get(0);
        CompoundTag greenFrame = exposures.get(1);
        CompoundTag blueFrame = exposures.get(2);

        String exposureId = getChromaticExposureId(level, idPrefix);

        ItemStack photograph = new ItemStack(Exposure.Items.PHOTOGRAPH.get());

        // It would probably be better to make a tag that contains properties common to all 3 tags,
        // but it's tricky to implement, and it wouldn't be noticed most of the time.
        CompoundTag tag = redFrame.m_6426_();
        tag = tag.m_128391_(greenFrame);
        tag = tag.m_128391_(blueFrame);

        tag.m_128473_(FrameData.CHROMATIC_CHANNEL);

        tag.m_128359_(FrameData.ID, exposureId);
        tag.m_128379_(FrameData.CHROMATIC, true);
        tag.m_128359_(FrameData.RED_CHANNEL, getFrameName(redFrame));
        tag.m_128359_(FrameData.GREEN_CHANNEL, getFrameName(greenFrame));
        tag.m_128359_(FrameData.BLUE_CHANNEL, getFrameName(blueFrame));
        tag.m_128359_(FrameData.TYPE, FilmType.COLOR.m_7912_());

        photograph.m_41751_(tag);

        boolean hasTexture = hasTextureFrame(redFrame, greenFrame, blueFrame);

        if (!hasTexture) {
            return finalizeServerside(stack, photograph, level, exposureId, redFrame, greenFrame, blueFrame);
        }
        else {
            if (player != null) {
                Packets.sendToClient(new CreateChromaticExposureS2CP(redFrame, greenFrame, blueFrame, exposureId), player);
                return photograph;
            }
            else {
                stack.m_41784_().m_128379_("RequiresDeferredFinalization", true);
                return stack;
            }
        }
    }

    private static @NotNull String getChromaticExposureId(@NotNull Level level, String idPrefix) {
        return String.format("%s_chromatic_%s", idPrefix, level.m_46467_());
    }

    protected String getFrameName(CompoundTag frame) {
        if (frame.m_128441_(FrameData.ID))
            return frame.m_128461_(FrameData.ID);

        if (frame.m_128441_(FrameData.TEXTURE))
            return frame.m_128461_(FrameData.TEXTURE);

        return "unknown";
    }

    protected boolean hasTextureFrame(CompoundTag red, CompoundTag green, CompoundTag blue) {
        if (!red.m_128441_(FrameData.ID) && red.m_128441_(FrameData.TEXTURE))
            return true;

        if (!green.m_128441_(FrameData.ID) && green.m_128441_(FrameData.TEXTURE))
            return true;

        if (!blue.m_128441_(FrameData.ID) && blue.m_128441_(FrameData.TEXTURE))
            return true;

        return false;
    }

    protected ItemStack finalizeServerside(ItemStack chromaticSheetStack, ItemStack photographStack, @NotNull Level level, String exposureId, CompoundTag redFrame, CompoundTag greenFrame, CompoundTag blueFrame) {
        @Nullable IImage redImage = getExposureImage(redFrame);
        if (redImage == null) {
            Exposure.LOGGER.error("Cannot create Chromatic Photograph: Red channel image is not found in frame {}.", redFrame);
            return chromaticSheetStack;
        }

        @Nullable IImage greenImage = getExposureImage(greenFrame);
        if (greenImage == null) {
            Exposure.LOGGER.error("Cannot create Chromatic Photograph: Green channel image is not found in frame {}.", greenFrame);
            return chromaticSheetStack;
        }

        @Nullable IImage blueImage = getExposureImage(blueFrame);
        if (blueImage == null) {
            Exposure.LOGGER.error("Cannot create Chromatic Photograph: Blue channel image is not found in frame {}.", blueFrame);
            return chromaticSheetStack;
        }

        Packets.sendToAllClients(new WaitForExposureChangeS2CP(exposureId));

        new Thread(() -> {
            try {
                processAndSaveTrichrome(redImage, greenImage, blueImage, exposureId);
            } catch (Exception e) {
                Exposure.LOGGER.error("Cannot process and save Chromatic Photograph: {}", e.toString());
            }
        }).start();

        return photographStack;
    }

    protected @Nullable IImage getExposureImage(CompoundTag frame) {
        if (frame.m_128425_(FrameData.ID, Tag.f_178201_)) {
            String exposureId = frame.m_128461_(FrameData.ID);
            return ExposureServer.getExposureStorage().getOrQuery(exposureId)
                    .map(data -> new ExposureDataImage(exposureId, data))
                    .orElse(null);
        }
        return null;
    }

    @SuppressWarnings("UnusedReturnValue")
    protected boolean processAndSaveTrichrome(IImage red, IImage green, IImage blue, String id) {
        int width = Math.min(red.getWidth(), Math.min(green.getWidth(), blue.getWidth()));
        int height = Math.min(red.getHeight(), Math.min(green.getHeight(), blue.getHeight()));
        if (width <= 0 ||height <= 0) {
            Exposure.LOGGER.error("Cannot create Chromatic Photograph: Width and Height should be larger than 0. " +
                    "Width '{}', Height: '{}'.", width, height);
            return false;
        }

        int[][] pixels = new int[height][width];

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int a = FastColor.ABGR32.m_266503_(red.getPixelABGR(x, y));
                int b = FastColor.ABGR32.m_266247_(blue.getPixelABGR(x, y));
                int g = FastColor.ABGR32.m_266446_(green.getPixelABGR(x, y));
                int r = FastColor.ABGR32.m_266313_(red.getPixelABGR(x, y));

                int abgr = FastColor.ARGB32.m_13660_(a, r, g, b);

                pixels[y][x] = abgr;
            }
        }

        byte[] mapColorPixels = new DitheringColorConverter().convert(pixels);

//        try (NativeImage image = new NativeImage(width, height, false)) {
//            for (int x = 0; x < image.getWidth(); x++) {
//                for (int y = 0; y < image.getHeight(); y++) {
//                    int a = FastColor.ABGR32.alpha(red.getPixelABGR(x, y));
//                    int b = FastColor.ABGR32.blue(blue.getPixelABGR(x, y));
//                    int g = FastColor.ABGR32.green(green.getPixelABGR(x, y));
//                    int r = FastColor.ABGR32.red(red.getPixelABGR(x, y));
//
//                    int abgr = FastColor.ABGR32.color(a, b, g, r);
//
//                    image.setPixelRGBA(x, y, abgr);
//                }
//            }
//
//            mapColorPixels = new DitheringColorConverter().convert(image);
//        }

        CompoundTag properties = new CompoundTag();
        properties.m_128359_(ExposureSavedData.TYPE_PROPERTY, FilmType.COLOR.m_7912_());
        long unixTime = System.currentTimeMillis() / 1000L;
        properties.m_128356_(ExposureSavedData.TIMESTAMP_PROPERTY, unixTime);

        ExposureSavedData resultData = new ExposureSavedData(width, height, mapColorPixels, properties);
        ExposureServer.getExposureStorage().put(id, resultData);

        // Because we save exposure off-thread, and item was already created before chromatic processing has even begun -
        // we need to update clients, otherwise, client wouldn't know that and will think that the exposure is missing.
        ExposureServer.getExposureStorage().sendExposureChanged(id);
        return true;
    }
}
