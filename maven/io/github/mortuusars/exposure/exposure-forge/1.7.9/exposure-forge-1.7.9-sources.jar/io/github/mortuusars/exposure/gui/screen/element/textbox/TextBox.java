package io.github.mortuusars.exposure.gui.screen.element.textbox;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.util.Pos2i;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.StringSplitter;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.font.TextFieldHelper;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class TextBox extends AbstractWidget {
    public final Font font;
    public Supplier<String> textGetter;
    public Consumer<String> textSetter;
    public Predicate<String> textValidator = text -> text != null
            && getFont().m_92920_(text, f_93618_) + (text.endsWith("\n") ? getFont().f_92710_ : 0) <= f_93619_;

    public HorizontalAlignment horizontalAlignment = HorizontalAlignment.LEFT;
    public int fontColor = 0xFF000000;
    public int fontUnfocusedColor = 0xFF000000;
    public int selectionColor = 0xFF0000FF;
    public int selectionUnfocusedColor = 0x880000FF;

    public final TextFieldHelper textFieldHelper;
    protected DisplayCache displayCache = new DisplayCache();
    protected int frameTick;
    protected long lastClickTime;
    protected int lastIndex = -1;

    public TextBox(@NotNull Font font, int x, int y, int width, int height,
                   Supplier<String> textGetter, Consumer<String> textSetter) {
        super(x, y, width, height, Component.m_237119_());
        this.font = font;
        this.textGetter = textGetter;
        this.textSetter = textSetter;
        textFieldHelper = new TextFieldHelper(this::getText, this::setText,
                TextFieldHelper.m_95153_(Minecraft.m_91087_()),
                TextFieldHelper.m_95182_(Minecraft.m_91087_()),
                this::validateText);
    }

    public void tick() {
        ++frameTick;
    }

    public Font getFont() {
        return font;
    }

    public @NotNull String getText() {
        return textGetter.get();
    }

    public TextBox setText(@NotNull String text) {
        textSetter.accept(text);
        clearDisplayCache();
        return this;
    }

    protected boolean validateText(String text) {
        return textValidator.test(text);
    }

    public void setHeight(int height) {
        this.f_93619_ = height;
        clearDisplayCache();
    }

    public int getCurrentFontColor() {
        return m_93696_() ? fontColor : fontUnfocusedColor;
    }

    public TextBox setFontColor(int fontColor, int fontUnfocusedColor) {
        this.fontColor = fontColor;
        this.fontUnfocusedColor = fontUnfocusedColor;
        clearDisplayCache();
        return this;
    }

    public TextBox setSelectionColor(int selectionColor, int selectionUnfocusedColor) {
        this.selectionColor = selectionColor;
        this.selectionUnfocusedColor = selectionUnfocusedColor;
        clearDisplayCache();
        return this;
    }

    public void setCursorToEnd() {
        textFieldHelper.m_95193_();
        clearDisplayCache();
    }

    public void refresh() {
        clearDisplayCache();
    }

    protected DisplayCache getDisplayCache() {
        if (displayCache.needsRebuilding)
            displayCache.rebuild(font, getText(), textFieldHelper.m_95194_(), textFieldHelper.m_95197_(),
                    m_252754_(), m_252907_(), m_5711_(), m_93694_(), horizontalAlignment);
        return displayCache;
    }

    protected void clearDisplayCache() {
        displayCache.needsRebuilding = true;
    }

    protected Pos2i convertLocalToScreen(Pos2i pos) {
        return new Pos2i(m_252754_() + pos.x, m_252907_() + pos.y);
    }

    protected Pos2i convertScreenToLocal(Pos2i screenPos) {
        return new Pos2i(screenPos.x - m_252754_(), screenPos.y - m_252907_());
    }

    @Override
    protected void m_87963_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        DisplayCache displayCache = this.getDisplayCache();
        for (DisplayCache.LineInfo lineInfo : displayCache.lines) {
            guiGraphics.m_280614_(this.font, lineInfo.asComponent, m_252754_() + lineInfo.x, m_252907_() + lineInfo.y, getCurrentFontColor(), false);
        }
        this.renderHighlight(guiGraphics, displayCache.selectionAreas);
        if (m_93696_())
            this.renderCursor(guiGraphics, displayCache.cursorPos, displayCache.cursorAtEnd);
    }

    protected void renderHighlight(GuiGraphics guiGraphics, Rect2i[] highlightAreas) {
        for (Rect2i selection : highlightAreas) {
            int x = m_252754_() + selection.m_110085_();
            int y = m_252907_() + selection.m_110086_();
            int x1 = x + selection.m_110090_();
            int y1 = y + selection.m_110091_();
            guiGraphics.m_285944_(RenderType.m_285783_(), x, y - 1, x1, y1, m_93696_() ? selectionColor : selectionUnfocusedColor);
        }
    }

    protected void renderCursor(GuiGraphics guiGraphics, Pos2i cursorPos, boolean isEndOfText) {
        if (this.frameTick / 6 % 2 == 0) {
            cursorPos = convertLocalToScreen(cursorPos);
            if (isEndOfText)
                guiGraphics.m_280056_(this.font, "_", cursorPos.x, cursorPos.y, getCurrentFontColor(), false);
            else {
                guiGraphics.m_280168_().m_85836_();
                guiGraphics.m_280168_().m_252880_(0, 0, 50);
                RenderSystem.disableBlend();
                guiGraphics.m_280509_(cursorPos.x, cursorPos.y - 1, cursorPos.x + 1, cursorPos.y + this.font.f_92710_, getCurrentFontColor());
                guiGraphics.m_280168_().m_85849_();
            }
        }
    }

    @Override
    protected void m_168797_(NarrationElementOutput narrationElementOutput) {
        narrationElementOutput.m_169146_(NarratedElementType.TITLE, m_5646_());
    }

    @Override
    public @NotNull Component m_6035_() {
        return Component.m_237113_(getText());
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (!m_93696_())
            return false;
        boolean handled = handleKeyPressed(keyCode, scanCode, modifiers);
        if (handled)
            clearDisplayCache();
        return handled;
    }

    protected boolean handleKeyPressed(int keyCode, int scanCode, int modifiers) {
        TextFieldHelper.CursorStep cursorStep = Screen.m_96637_() ? TextFieldHelper.CursorStep.WORD : TextFieldHelper.CursorStep.CHARACTER;
        if (keyCode == InputConstants.f_166280_) {
            changeLine(-1);
            return true;
        } else if (keyCode == InputConstants.f_166329_) {
            changeLine(1);
            return true;
        } else if (keyCode == InputConstants.f_166336_) {
            keyHome();
            return true;
        } else if (keyCode == InputConstants.f_166335_) {
            keyEnd();
            return true;
        } else if (keyCode == InputConstants.f_166333_) {
            textFieldHelper.m_232572_(-1, cursorStep);
            return true;
        } else if (keyCode == InputConstants.f_166334_) {
            textFieldHelper.m_232572_(1, cursorStep);
            return true;
        } else if (keyCode == InputConstants.f_166304_ || keyCode == InputConstants.f_166327_) {
            textFieldHelper.m_95158_(CommonComponents.f_178388_.getString());
            return true;
        }

        return textFieldHelper.m_95145_(keyCode);
    }

    public boolean m_5534_(char codePoint, int modifiers) {
        if (!m_93696_())
            return false;

        boolean typed = textFieldHelper.m_95143_(codePoint);
        if (typed)
            clearDisplayCache();
        return typed;
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        if (f_93622_ && f_93624_ && m_142518_() && button == 0) {
            long currentTime = Util.m_137550_();
            DisplayCache displayCache = getDisplayCache();
            int index = displayCache.getIndexAtPosition(font, convertScreenToLocal(new Pos2i((int) mouseX, (int) mouseY)));

            if (index >= 0) {
                if (index == lastIndex && currentTime - lastClickTime < 250L) {
                    if (!textFieldHelper.m_95198_()) {
                        selectWord(index);
                    } else {
                        textFieldHelper.m_95188_();
                    }
                } else {
                    textFieldHelper.m_95179_(index, Screen.m_96638_());
                }
                clearDisplayCache();
            }

            lastIndex = index;
            lastClickTime = currentTime;
            return true;
        }

        return false;
    }

    @Override
    public boolean m_7979_(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (button == 0) {
            DisplayCache displayCache = this.getDisplayCache();
            int index = displayCache.getIndexAtPosition(this.font, this.convertScreenToLocal(new Pos2i((int) mouseX, (int) mouseY)));
            this.textFieldHelper.m_95179_(index, true);
            this.clearDisplayCache();
        }
        return true;
    }

    protected void selectWord(int index) {
        String string = this.getText();
        this.textFieldHelper.m_95147_(StringSplitter.m_92355_(string, -1, index, false),
                StringSplitter.m_92355_(string, 1, index, false));
    }

    protected void changeLine(int yChange) {
        int cursorPos = this.textFieldHelper.m_95194_();
        int line = this.getDisplayCache().changeLine(cursorPos, yChange);
        this.textFieldHelper.m_95179_(line, Screen.m_96638_());
    }

    protected void keyHome() {
        if (Screen.m_96637_()) {
            this.textFieldHelper.m_95176_(Screen.m_96638_());
        } else {
            int cursorIndex = this.textFieldHelper.m_95194_();
            int lineStartIndex = this.getDisplayCache().findLineStart(cursorIndex);
            this.textFieldHelper.m_95179_(lineStartIndex, Screen.m_96638_());
        }
    }

    protected void keyEnd() {
        if (Screen.m_96637_()) {
            this.textFieldHelper.m_95186_(Screen.m_96638_());
        } else {
            DisplayCache displayCache = this.getDisplayCache();
            int cursorIndex = this.textFieldHelper.m_95194_();
            int lineEndIndex = displayCache.findLineEnd(cursorIndex);
            this.textFieldHelper.m_95179_(lineEndIndex, Screen.m_96638_());
        }
    }
}
