package io.github.mortuusars.exposure.util;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.client.Minecraft;

import java.io.File;
import java.nio.file.Path;

public class ClientsideWorldNameGetter {
    
    public static String getWorldName() {
        try {
            if (Minecraft.m_91087_().m_257720_()) {
                if (Minecraft.m_91087_().m_91092_() != null)
                    return Minecraft.m_91087_().m_91092_().m_129910_().m_5462_()
                            .replace('.', '_'); // Folder name has underscores instead of dots.
                else {
                    String gameDirectory = Minecraft.m_91087_().f_91069_.getAbsolutePath();
                    Path savesDir = Path.of(gameDirectory, "/saves");

                    File[] dirs = savesDir.toFile().listFiles((dir, name) -> new File(dir, name).isDirectory());

                    if (dirs == null || dirs.length == 0)
                        return "";

                    File lastModified = dirs[0];

                    for (File dir : dirs) {
                        if (dir.lastModified() > lastModified.lastModified())
                            lastModified = dir;
                    }

                    return lastModified.getName();
                }
            }
            else if (Minecraft.m_91087_().m_91089_() != null) {
                return Minecraft.m_91087_().m_91089_().f_105362_;
            }
            else {
                return "Unknown";
            }
        } catch (Exception e) {
            Exposure.LOGGER.error("Failed to get level name: " + e);
            return "Unknown";
        }
    }
}
