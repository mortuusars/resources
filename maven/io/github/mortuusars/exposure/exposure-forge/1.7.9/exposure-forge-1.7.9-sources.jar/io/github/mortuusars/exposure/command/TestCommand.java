package io.github.mortuusars.exposure.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.exposure.test.Tests;
import io.github.mortuusars.exposure.test.framework.TestResult;
import io.github.mortuusars.exposure.test.framework.TestingResult;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;

public class TestCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
                Commands.m_82127_("test")
                        .requires((commandSourceStack -> commandSourceStack.m_6761_(3)))
                        .then(Commands.m_82127_("exposure")
                                .executes(TestCommand::run)));
    }

    private static int run(CommandContext<CommandSourceStack> context) {
        try {
            ServerPlayer player = context.getSource().m_81375_();
            TestingResult testingResult = new Tests(player).run();

            MutableComponent message = Component.m_237113_("Testing: ").m_130940_(ChatFormatting.GOLD)
                    .m_7220_(Component.m_237113_("Total: " + testingResult.getTotalTestCount() + ".").m_130940_(ChatFormatting.WHITE));

            for (TestResult failedTest : testingResult.failed()) {
                if (failedTest.error() != null)
                    context.getSource().m_81352_(Component.m_237113_(failedTest.name() + " failed: " + failedTest.error())
                            .m_130940_(ChatFormatting.DARK_RED));
            }

            if (testingResult.passed().size() > 0) {
                message.m_130946_(" ");
                message.m_7220_(Component.m_237113_("Passed: " + testingResult.passed()
                        .size() + ".").m_130940_(ChatFormatting.GREEN));
            }

            if (testingResult.failed().size() > 0) {
                message.m_130946_(" ");
                message.m_7220_(Component.m_237113_("Failed: " + testingResult.failed()
                        .size() + ".").m_130940_(ChatFormatting.RED));
            }

            if (testingResult.skipped().size() > 0) {
                message.m_130946_(" ");
                message.m_7220_(Component.m_237113_("Skipped: " + testingResult.skipped()
                        .size() + ".").m_130940_(ChatFormatting.GRAY));
            }

            if (testingResult.failed().size() == 0)
                context.getSource().m_288197_(() -> message, false);
            else
                context.getSource().m_81352_(message);

        } catch (CommandSyntaxException e) {
            throw new RuntimeException(e);
        }

        return 0;
    }
}
