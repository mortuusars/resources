package io.github.mortuusars.exposure.gui.screen.element;

import io.github.mortuusars.exposure.block.entity.Lightroom;
import io.github.mortuusars.exposure.gui.screen.LightroomScreen;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.function.Supplier;

public class ChromaticProcessToggleButton extends ImageButton {
    private final Supplier<Lightroom.Process> processGetter;

    public ChromaticProcessToggleButton(int x, int y, OnPress onPress, Supplier<Lightroom.Process> processGetter) {
        super(x, y, 18, 18, 198, 17, 18,
                LightroomScreen.MAIN_TEXTURE, 256, 256, onPress);
        this.processGetter = processGetter;
    }

    @Override
    public void m_87963_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        Lightroom.Process currentProcess = processGetter.get();
        int xTex = currentProcess == Lightroom.Process.CHROMATIC ? 18 : 0;

        this.m_280322_(guiGraphics, this.f_94223_, this.m_252754_(), this.m_252907_(), this.f_94224_ + xTex, this.f_94225_,
                this.f_94226_, this.f_93618_, this.f_93619_, this.f_94227_, this.f_94228_);

        MutableComponent tooltip = Component.m_237115_("gui.exposure.lightroom.process." + currentProcess.m_7912_());
        if (currentProcess == Lightroom.Process.CHROMATIC) {
            tooltip.m_7220_(CommonComponents.f_178388_);
            tooltip.m_7220_(Component.m_237115_("gui.exposure.lightroom.process.chromatic.info")
                    .m_130940_(ChatFormatting.GRAY));
        }

        m_257544_(Tooltip.m_257550_(tooltip));
    }
}
