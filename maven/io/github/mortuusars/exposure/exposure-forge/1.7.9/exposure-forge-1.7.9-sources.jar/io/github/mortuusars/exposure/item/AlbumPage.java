package io.github.mortuusars.exposure.item;

import com.mojang.datafixers.util.Either;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public class AlbumPage {
    public static final String PHOTOGRAPH_TAG = "Photo";
    public static final String NOTE_TAG = "Note";
    public static final String NOTE_COMPONENT_TAG = "NoteComponent";
    private ItemStack photographStack;
    private Either<String, Component> note;

    public AlbumPage(ItemStack photographStack, Either<String, Component> note) {
        this.photographStack = photographStack;
        this.note = note;
    }

    public static AlbumPage editable(ItemStack photographStack, String note) {
        return new AlbumPage(photographStack, Either.left(note));
    }

    public static AlbumPage signed(ItemStack photographStack, Component note) {
        return new AlbumPage(photographStack, Either.right(note));
    }

    public boolean isEditable() {
        return note.left().isPresent();
    }

    public boolean isEmpty() {
        return photographStack.m_41619_() && note.map(String::isEmpty, c -> c.getString().isEmpty());
    }

    public static AlbumPage fromTag(CompoundTag tag, boolean editable) {
        ItemStack photographStack = tag.m_128425_(PHOTOGRAPH_TAG, Tag.f_178203_)
                ? ItemStack.m_41712_(tag.m_128469_(PHOTOGRAPH_TAG)) : ItemStack.f_41583_;

        if (editable) {
            String note;
            if (tag.m_128425_(NOTE_TAG, Tag.f_178201_))
                note = tag.m_128461_(NOTE_TAG);
            else if (tag.m_128441_(NOTE_COMPONENT_TAG)) {
                @Nullable MutableComponent component = Component.Serializer.m_130701_(tag.m_128461_(NOTE_COMPONENT_TAG));
                note = component != null ? component.m_130668_(512) : "";
            } else
                note = "";

            return editable(photographStack, note);
        } else {
            Component note;
            if (tag.m_128425_(NOTE_COMPONENT_TAG, Tag.f_178201_))
                note = Component.Serializer.m_130701_(tag.m_128461_(NOTE_COMPONENT_TAG));
            else if (tag.m_128441_(NOTE_TAG))
                note = Component.m_237113_(tag.m_128461_(NOTE_TAG));
            else
                note = Component.m_237119_();

            return signed(photographStack, note);
        }
    }

    public CompoundTag toTag(CompoundTag tag) {
        if (!photographStack.m_41619_())
            tag.m_128365_(PHOTOGRAPH_TAG, photographStack.m_41739_(new CompoundTag()));

        note.ifLeft(string -> { if (!string.isEmpty()) tag.m_128359_(NOTE_TAG, string);})
            .ifRight(component -> tag.m_128359_(NOTE_COMPONENT_TAG, Component.Serializer.m_130703_(component)));

        return tag;
    }

    public ItemStack getPhotographStack() {
        return photographStack;
    }

    public ItemStack setPhotographStack(ItemStack photographStack) {
        ItemStack existingStack = this.photographStack;
        this.photographStack = photographStack;
        return existingStack;
    }

    public Either<String, Component> getNote() {
        return note;
    }

    public void setNote(Either<String, Component> note) {
        this.note = note;
    }

    public AlbumPage toSigned() {
        if (!isEditable())
            return this;

        MutableComponent noteComponent = Component.m_237113_(getNote().left().orElseThrow());
        return signed(getPhotographStack(), noteComponent);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (AlbumPage) obj;
        return Objects.equals(this.photographStack, that.photographStack) &&
                Objects.equals(this.note, that.note);
    }

    @Override
    public int hashCode() {
        return Objects.hash(photographStack, note);
    }

    @Override
    public String toString() {
        return "Page[" +
                "photo=" + photographStack + ", " +
                "note=" + note + ']';
    }
}
