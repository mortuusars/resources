package io.github.mortuusars.exposure.advancement.predicate;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.util.ItemAndStack;
import net.minecraft.advancements.critereon.ItemPredicate;
import net.minecraft.advancements.critereon.MinMaxBounds;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public class CameraPredicate {
    public static final CameraPredicate ANY = new CameraPredicate(ItemPredicate.f_45028_, MinMaxBounds.Doubles.f_154779_,
            MinMaxBounds.Ints.f_55364_, ItemPredicate.f_45028_, ItemPredicate.f_45028_, ItemPredicate.f_45028_, ItemPredicate.f_45028_);

    private final ItemPredicate camera;
    private final MinMaxBounds.Doubles shutterSpeedMS;
    private final MinMaxBounds.Ints focalLength;
    private final ItemPredicate film;
    private final ItemPredicate flash;
    private final ItemPredicate lens;
    private final ItemPredicate filter;

    public CameraPredicate(ItemPredicate camera, MinMaxBounds.Doubles shutterSpeedMS,
                           MinMaxBounds.Ints focalLength, ItemPredicate film,
                           ItemPredicate flash, ItemPredicate lens, ItemPredicate filter) {
        this.camera = camera;
        this.shutterSpeedMS = shutterSpeedMS;
        this.focalLength = focalLength;
        this.film = film;
        this.flash = flash;
        this.lens = lens;
        this.filter = filter;
    }

    public boolean matches(ItemAndStack<CameraItem> camera) {
        if (this.equals(ANY)) {
            return true;
        }

        ItemStack stack = camera.getStack();
        CameraItem item = camera.getItem();

        return this.camera.m_45049_(stack)
                && this.shutterSpeedMS.m_154810_(item.getShutterSpeed(stack).getMilliseconds())
                && this.focalLength.m_55390_(Mth.m_14167_(item.getFocalLength(stack)))
                && this.film.m_45049_(item.getAttachment(stack, CameraItem.FILM_ATTACHMENT).orElse(ItemStack.f_41583_))
                && this.flash.m_45049_(item.getAttachment(stack, CameraItem.FLASH_ATTACHMENT).orElse(ItemStack.f_41583_))
                && this.lens.m_45049_(item.getAttachment(stack, CameraItem.LENS_ATTACHMENT).orElse(ItemStack.f_41583_))
                && this.filter.m_45049_(item.getAttachment(stack, CameraItem.FILTER_ATTACHMENT).orElse(ItemStack.f_41583_));
    }

    public JsonElement serializeToJson() {
        if (this == ANY)
            return JsonNull.INSTANCE;

        JsonObject json = new JsonObject();
        json.add("camera", camera.m_45048_());
        json.add("shutter_speed_ms", shutterSpeedMS.m_55328_());
        json.add("focal_length", focalLength.m_55328_());
        json.add("film", film.m_45048_());
        json.add("flash", flash.m_45048_());
        json.add("lens", lens.m_45048_());
        json.add("filter", filter.m_45048_());
        return json;
    }

    public static CameraPredicate fromJson(@Nullable JsonElement json) {
        if (json == null || json.isJsonNull())
            return ANY;

        JsonObject jsonObj = GsonHelper.m_13918_(json, "camera");

        return new CameraPredicate(
                ItemPredicate.m_45051_(jsonObj.getAsJsonObject("camera")),
                MinMaxBounds.Doubles.m_154791_(jsonObj.getAsJsonObject("shutter_speed_ms")),
                MinMaxBounds.Ints.m_55373_(jsonObj.getAsJsonObject("focal_length")),
                ItemPredicate.m_45051_(jsonObj.getAsJsonObject("film")),
                ItemPredicate.m_45051_(jsonObj.getAsJsonObject("flash")),
                ItemPredicate.m_45051_(jsonObj.getAsJsonObject("lens")),
                ItemPredicate.m_45051_(jsonObj.getAsJsonObject("filter")));
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CameraPredicate that = (CameraPredicate) o;
        return Objects.equals(camera, that.camera) && Objects.equals(shutterSpeedMS, that.shutterSpeedMS)
                && Objects.equals(focalLength, that.focalLength) && Objects.equals(film, that.film)
                && Objects.equals(flash, that.flash) && Objects.equals(lens, that.lens) && Objects.equals(filter, that.filter);
    }

    @Override
    public int hashCode() {
        return Objects.hash(camera, shutterSpeedMS, focalLength, film, flash, lens, filter);
    }
}
