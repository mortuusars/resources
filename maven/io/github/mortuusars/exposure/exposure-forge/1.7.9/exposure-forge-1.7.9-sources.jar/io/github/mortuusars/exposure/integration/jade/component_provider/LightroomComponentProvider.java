package io.github.mortuusars.exposure.integration.jade.component_provider;

import io.github.mortuusars.exposure.block.entity.Lightroom;
import io.github.mortuusars.exposure.block.entity.LightroomBlockEntity;
import io.github.mortuusars.exposure.integration.jade.ExposureJadePlugin;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec2;
import org.jetbrains.annotations.Nullable;
import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IBlockComponentProvider;
import snownee.jade.api.IServerDataProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.config.IPluginConfig;
import snownee.jade.api.ui.IElementHelper;
import snownee.jade.api.view.IServerExtensionProvider;
import snownee.jade.api.view.ViewGroup;
import snownee.jade.impl.ui.ProgressArrowElement;

import java.util.List;

public enum LightroomComponentProvider implements IBlockComponentProvider, IServerDataProvider<BlockAccessor>,
        IServerExtensionProvider<LightroomBlockEntity, ItemStack> {
    INSTANCE;

    @Override
    public void appendTooltip(ITooltip tooltip, BlockAccessor blockAccessor, IPluginConfig iPluginConfig) {
        CompoundTag tag = blockAccessor.getServerData();

        if (tag.m_128471_("Empty"))
            return;

        IElementHelper helper = IElementHelper.get();

        tooltip.add(helper.spacer(0, 0));

        ItemStack film = ItemStack.m_41712_(tag.m_128469_("Film"));
        if (!film.m_41619_()) {
            tooltip.append(helper.item(film));
            tooltip.append(helper.text(Component.m_237113_("|").m_130940_(ChatFormatting.GRAY))
                    .size(new Vec2(11, 12))
                    .translate(new Vec2(5, 6))
                    .message(null));
        }

        ItemStack paper = ItemStack.m_41712_(tag.m_128469_("Paper"));
        if (!paper.m_41619_()) {
            tooltip.append(helper.item(paper));
            tooltip.append(helper.text(Component.m_237113_("+").m_130940_(ChatFormatting.GRAY))
                    .size(new Vec2(12, 12))
                    .translate(new Vec2(5, 6))
                    .message(null));
        }

        for (String dye : new String[] {"Cyan", "Yellow", "Magenta", "Black"}) {
            ItemStack stack = ItemStack.m_41712_(tag.m_128469_(dye));
            if (!stack.m_41619_())
                tooltip.append(helper.item(stack));
        }

        tooltip.append(new ProgressArrowElement(tag.m_128457_("Progress")));

        tooltip.append(helper.item(ItemStack.m_41712_(tag.m_128469_("Result"))));


        Lightroom.Process process = Lightroom.Process.fromStringOrDefault(tag.m_128461_("Process"), Lightroom.Process.REGULAR);
        if (process != Lightroom.Process.REGULAR)
            tooltip.add(helper.text(Component.m_237115_("gui.exposure.lightroom.process." + process.m_7912_())));

        tooltip.add(helper.spacer(0, 2));
    }

    @Override
    public void appendServerData(CompoundTag tag, BlockAccessor blockAccessor) {
        if (blockAccessor.getBlockEntity() instanceof LightroomBlockEntity lightroomBlockEntity) {
            if (lightroomBlockEntity.m_7983_()) {
                tag.m_128379_("Empty", true);
                return;
            }

            tag.m_128365_("Film", lightroomBlockEntity.m_8020_(Lightroom.FILM_SLOT).m_41739_(new CompoundTag()));
            tag.m_128365_("Paper", lightroomBlockEntity.m_8020_(Lightroom.PAPER_SLOT).m_41739_(new CompoundTag()));
            tag.m_128365_("Cyan", lightroomBlockEntity.m_8020_(Lightroom.CYAN_SLOT).m_41739_(new CompoundTag()));
            tag.m_128365_("Yellow", lightroomBlockEntity.m_8020_(Lightroom.YELLOW_SLOT).m_41739_(new CompoundTag()));
            tag.m_128365_("Magenta", lightroomBlockEntity.m_8020_(Lightroom.MAGENTA_SLOT).m_41739_(new CompoundTag()));
            tag.m_128365_("Black", lightroomBlockEntity.m_8020_(Lightroom.BLACK_SLOT).m_41739_(new CompoundTag()));
            tag.m_128365_("Result", lightroomBlockEntity.m_8020_(Lightroom.RESULT_SLOT).m_41739_(new CompoundTag()));

            tag.m_128359_("Process", lightroomBlockEntity.getProcess().m_7912_());

            tag.m_128350_("Progress", lightroomBlockEntity.getProgressPercentage());
        }
    }

    @Override
    public @Nullable List<ViewGroup<ItemStack>> getGroups(ServerPlayer serverPlayer, ServerLevel serverLevel, LightroomBlockEntity lightroomBlockEntity, boolean b) {
        return null;
    }

    @Override
    public ResourceLocation getUid() {
        return ExposureJadePlugin.LIGHTROOM;
    }
}
