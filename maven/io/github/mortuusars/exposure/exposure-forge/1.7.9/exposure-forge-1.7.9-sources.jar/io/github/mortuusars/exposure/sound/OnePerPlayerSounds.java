package io.github.mortuusars.exposure.sound;

import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.PlayOnePerPlayerSoundS2CP;
import io.github.mortuusars.exposure.network.packet.client.StopOnePerPlayerSoundS2CP;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;

public class OnePerPlayerSounds {
    public static void play(Player sourcePlayer, SoundEvent soundEvent, SoundSource source, float volume, float pitch) {
        if (sourcePlayer.m_9236_().f_46443_) {
            OnePerPlayerSoundsClient.play(sourcePlayer, soundEvent, source, volume, pitch);
        }
        else if (sourcePlayer instanceof ServerPlayer serverSourcePlayer) {
            Packets.sendToOtherClients(new PlayOnePerPlayerSoundS2CP(serverSourcePlayer.m_20148_(),
                            soundEvent, source, volume, pitch),
                    serverSourcePlayer,
                    serverPlayer -> serverSourcePlayer.m_20270_(serverPlayer) < soundEvent.m_215668_(1f));
        }
    }

    public static void stop(Player sourcePlayer, SoundEvent soundEvent) {
        if (sourcePlayer.m_9236_().f_46443_) {
            OnePerPlayerSoundsClient.stop(sourcePlayer, soundEvent);
        }
        else if (sourcePlayer instanceof ServerPlayer serverSourcePlayer) {
            Packets.sendToOtherClients(new StopOnePerPlayerSoundS2CP(serverSourcePlayer.m_20148_(), soundEvent),
                    serverSourcePlayer, serverPlayer -> serverSourcePlayer.m_20270_(serverPlayer) < soundEvent.m_215668_(1f));
        }
    }

    public static void playForAllClients(Player player, SoundEvent soundEvent, SoundSource source, float volume, float pitch) {
        if (!player.m_9236_().f_46443_)
            Packets.sendToAllClients(new PlayOnePerPlayerSoundS2CP(player.m_20148_(), soundEvent, source, volume, pitch));
    }
}
