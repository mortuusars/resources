package io.github.mortuusars.exposure.client;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.camera.CameraClient;
import io.github.mortuusars.exposure.camera.infrastructure.ZoomDirection;
import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.gui.ClientGUI;
import io.github.mortuusars.exposure.gui.screen.camera.ViewfinderControlsScreen;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class KeyboardHandler {
    public static boolean handleViewfinderKeyPress(long windowId, int key, int scanCode, int action, int modifiers) {
        Minecraft minecraft = Minecraft.m_91087_();
        @Nullable LocalPlayer player = minecraft.f_91074_;
        if (player == null) {
            return false;
        }

        Optional<Camera<?>> cameraOptional = CameraClient.getCamera();
        if (cameraOptional.isEmpty()) {
            return false;
        }

        if (!Config.Common.CAMERA_VIEWFINDER_ATTACK.get()
                && Minecraft.m_91087_().f_91066_.f_92096_.m_90832_(key, scanCode)
                && !(Minecraft.m_91087_().f_91080_ instanceof ViewfinderControlsScreen)) {
            return true; // Block attacks
        }

        if (minecraft.f_91066_.f_92103_.m_90832_(key, scanCode)) {
            if (action == InputConstants.f_166344_)
                return true;

            CameraType currentCameraType = minecraft.f_91066_.m_92176_();
            CameraType newCameraType = currentCameraType == CameraType.FIRST_PERSON ? CameraType.THIRD_PERSON_FRONT
                    : CameraType.FIRST_PERSON;

            minecraft.f_91066_.m_92157_(newCameraType);
            return true;
        }


        if (key == InputConstants.f_166305_ || minecraft.f_91066_.f_92092_.m_90832_(key, scanCode)) {
            if (action == InputConstants.f_166344_) { // TODO: Check if activating on release is not causing problems
                if (minecraft.f_91080_ instanceof ViewfinderControlsScreen viewfinderControlsScreen) {
                    viewfinderControlsScreen.m_7379_();
                } else {
                    CameraClient.deactivate(player);
                }
            }
            return true;
        }

        if (!Viewfinder.isLookingThrough())
            return false;

        if (!(minecraft.f_91080_ instanceof ViewfinderControlsScreen)) {
            if (ExposureClient.getCameraControlsKey().m_90832_(key, scanCode)) {
                ClientGUI.openViewfinderControlsScreen();
                return false; // Do not handle to keep sneaking
            }

            if (action == 1 || action == 2) { // Press or Hold
                if (key == InputConstants.f_166281_ || key == InputConstants.f_166285_) {
                    Viewfinder.zoom(ZoomDirection.IN, false);
                    return true;
                }

                if (key == 333 /*KEY_SUBTRACT*/ || key == InputConstants.f_166288_) {
                    Viewfinder.zoom(ZoomDirection.OUT, false);
                    return true;
                }
            }
        }

        return false;
    }
}
