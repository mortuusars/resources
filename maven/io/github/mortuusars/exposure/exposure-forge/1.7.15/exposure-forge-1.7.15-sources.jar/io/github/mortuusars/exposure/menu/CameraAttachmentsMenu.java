package io.github.mortuusars.exposure.menu;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.AttachmentType;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.util.ItemAndStack;
import io.github.mortuusars.exposure.util.supporter.Supporters;
import net.minecraft.core.NonNullList;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerListener;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;

public class CameraAttachmentsMenu extends AbstractContainerMenu {
    public static final int SKIN_REGULAR_BUTTON_ID = 100;
    public static final int SKIN_GOLD_BUTTON_ID = 101;

    private final int attachmentSlotsCount;
    private final int cameraSlotIndex;
    private final Player player;
    private final ItemAndStack<CameraItem> camera;

    private boolean clientContentsInitialized;

    public CameraAttachmentsMenu(int containerId, Inventory playerInventory, int cameraSlotIndex) {
        super(Exposure.MenuTypes.CAMERA.get(), containerId);

        ItemStack cameraStack = playerInventory.f_35974_.get(cameraSlotIndex);
        Preconditions.checkState(cameraStack.m_41720_() instanceof CameraItem,
                "Failed to open Camera Attachments. " + cameraStack + " is not a CameraItem.");

        this.player = playerInventory.f_35978_;
        this.cameraSlotIndex = cameraSlotIndex;
        this.camera = new ItemAndStack<>(cameraStack);

        SimpleContainer container = new SimpleContainer(getCameraAttachments(camera).toArray(ItemStack[]::new)) {
            @Override
            public int m_6893_() {
                return 1;
            }
        };

        container.m_19164_(new ContainerListener() {
            @Override
            public void m_5757_(Container container) {
                for (int slotId = 0; slotId < container.m_6643_(); slotId++) {
                    AttachmentType attachmentType = camera.getItem().getAttachmentTypeForSlot(camera.getStack(), slotId).orElseThrow();

                    camera.getItem().setAttachment(camera.getStack(), attachmentType, container.m_8020_(slotId));

                    if (!player.m_9236_().m_5776_() && player.m_7500_()) {
                        // Fixes item not updating properly when not in "Inventory" tab of creative inventory
                        player.m_150109_().m_6836_(cameraSlotIndex, camera.getStack());
                    }
                }
            }
        });

        this.attachmentSlotsCount = addAttachmentSlots(container);
        addPlayerSlots(playerInventory);
    }

    public ItemAndStack<CameraItem> getCamera() {
        return camera;
    }

    /**
     * Only called client-side.
     */
    @Override
    public void m_182410_(int stateId, List<ItemStack> items, ItemStack carried) {
        clientContentsInitialized = false;
        super.m_182410_(stateId, items, carried);
        clientContentsInitialized = true;
    }

    protected int addAttachmentSlots(Container container) {
        int attachmentSlots = 0;

        int[][] slots = new int[][]{
                // SlotId, x, y, maxStackSize
                {CameraItem.FILM_ATTACHMENT.slot(), 13, 42, 1},
                {CameraItem.FLASH_ATTACHMENT.slot(), 147, 15, 1},
                {CameraItem.LENS_ATTACHMENT.slot(), 147, 43, 1},
                {CameraItem.FILTER_ATTACHMENT.slot(), 147, 71, 1}
        };

        for (int[] slot : slots) {
            Optional<AttachmentType> attachment = camera.getItem()
                    .getAttachmentTypeForSlot(camera.getStack(), slot[0]);

            if (attachment.isPresent()) {
                m_38897_(new FilteredSlot(container, slot[0], slot[1], slot[2], slot[3],
                        this::onItemInSlotChanged, attachment.get().itemPredicate()));
                attachmentSlots++;
            }
        }

        return attachmentSlots;
    }

    protected void addPlayerSlots(Inventory playerInventory) {
        //Player Inventory
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                m_38897_(new Slot(playerInventory, (column + row * 9) + 9, column * 18 + 8, 103 + row * 18){
                    @Override
                    public boolean m_8010_(@NotNull Player player) {
                        return super.m_8010_(player) && m_150661_() != cameraSlotIndex;
                    }

                    @Override
                    public boolean m_6659_() {
                        return m_150661_() != cameraSlotIndex;
                    }

                    @Override
                    public boolean m_280329_() {
                        return m_150661_() != cameraSlotIndex;
                    }
                });
            }
        }

        //Hotbar
        for (int slot = 0; slot < 9; slot++) {
            int finalSlot = slot;
            m_38897_(new Slot(playerInventory, finalSlot, slot * 18 + 8, 161) {
                @Override
                public boolean m_8010_(@NotNull Player player) {
                    return super.m_8010_(player) && m_150661_() != cameraSlotIndex;
                }

                @Override
                public boolean m_6659_() {
                    return m_150661_() != cameraSlotIndex;
                }

                @Override
                public boolean m_280329_() {
                    return m_150661_() != cameraSlotIndex;
                }
            });
        }
    }

    protected void onItemInSlotChanged(FilteredSlot.SlotChangedArgs args) {
        int slotId = args.slot().getSlotId();
        ItemStack newStack = args.newStack();

        camera.getItem().getAttachmentTypeForSlot(camera.getStack(), slotId).ifPresent(type -> {
            camera.getItem().setAttachment(camera.getStack(), type, newStack);

            if (player.m_9236_().m_5776_() && clientContentsInitialized)
                type.sound().playOnePerPlayer(player, newStack.m_41619_());

            if (!player.m_9236_().m_5776_() && player.m_7500_()) {
                // Fixes item not updating properly when not in "Inventory" tab of creative inventory
                player.m_150109_().m_6836_(cameraSlotIndex, camera.getStack());
            }
        });
    }

    private static NonNullList<ItemStack> getCameraAttachments(ItemAndStack<CameraItem> camera) {
        NonNullList<ItemStack> items = NonNullList.m_122779_();

        List<AttachmentType> attachmentTypes = camera.getItem().getAttachmentTypes(camera.getStack());
        for (AttachmentType attachmentType : attachmentTypes) {
            items.add(camera.getItem().getAttachment(camera.getStack(), attachmentType).orElse(ItemStack.f_41583_));
        }

        return items;
    }

    @Override
    public @NotNull ItemStack m_7648_(@NotNull Player player, int slotIndex) {
        ItemStack itemstack = ItemStack.f_41583_;
        Slot clickedSlot = this.f_38839_.get(slotIndex);
        if (clickedSlot.m_6657_()) {
            ItemStack slotStack = clickedSlot.m_7993_();
            itemstack = slotStack.m_41777_();
            if (slotIndex < attachmentSlotsCount) {
                if (!this.m_38903_(slotStack, attachmentSlotsCount, this.f_38839_.size(), true))
                    return ItemStack.f_41583_;
            } else {
                if (!this.m_38903_(slotStack, 0, attachmentSlotsCount, false))
                    return ItemStack.f_41583_;
            }

            if (slotStack.m_41619_())
                clickedSlot.m_5852_(ItemStack.f_41583_);
            else
                clickedSlot.m_6654_();
        }

        return itemstack;
    }

    /**
     * Fixed method to respect slot photo limit.
     */
    @Override
    protected boolean m_38903_(ItemStack movedStack, int startIndex, int endIndex, boolean reverseDirection) {
        boolean hasRemainder = false;
        int i = startIndex;
        if (reverseDirection) {
            i = endIndex - 1;
        }
        if (movedStack.m_41753_()) {
            while (!movedStack.m_41619_() && !(!reverseDirection ? i >= endIndex : i < startIndex)) {
                Slot slot = this.f_38839_.get(i);
                ItemStack slotStack = slot.m_7993_();
                if (!slotStack.m_41619_() && ItemStack.m_150942_(movedStack, slotStack)) {
                    int maxSize;
                    int j = slotStack.m_41613_() + movedStack.m_41613_();
                    if (j <= (maxSize = Math.min(slot.m_6641_(), movedStack.m_41741_()))) {
                        movedStack.m_41764_(0);
                        slotStack.m_41764_(j);
                        slot.m_6654_();
                        hasRemainder = true;
                    } else if (slotStack.m_41613_() < maxSize) {
                        movedStack.m_41774_(maxSize - slotStack.m_41613_());
                        slotStack.m_41764_(maxSize);
                        slot.m_6654_();
                        hasRemainder = true;
                    }
                }
                if (reverseDirection) {
                    --i;
                    continue;
                }
                ++i;
            }
        }
        if (!movedStack.m_41619_()) {
            i = reverseDirection ? endIndex - 1 : startIndex;
            while (!(!reverseDirection ? i >= endIndex : i < startIndex)) {
                Slot slot1 = this.f_38839_.get(i);
                ItemStack movedStack1 = slot1.m_7993_();
                if (movedStack1.m_41619_() && slot1.m_5857_(movedStack)) {
                    if (movedStack.m_41613_() > slot1.m_6641_()) {
                        slot1.m_269060_(movedStack.m_41620_(slot1.m_6641_()));
                    } else {
                        slot1.m_269060_(movedStack.m_41620_(movedStack.m_41613_()));
                    }
                    slot1.m_6654_();
                    hasRemainder = true;
                    break;
                }
                if (reverseDirection) {
                    --i;
                    continue;
                }
                ++i;
            }
        }
        return hasRemainder;
    }

    @Override
    public boolean m_6366_(Player player, int id) {
        if (Supporters.hasAccessToGoldenSkin(player.m_20148_())) {
            if (id == SKIN_REGULAR_BUTTON_ID) {
                getCamera().apply((i, s) -> s.m_41784_().m_128473_("GoldenCamera"));
                m_38946_();
                return true;
            } else if (id == SKIN_GOLD_BUTTON_ID) {
                getCamera().apply((i, s) -> s.m_41784_().m_128379_("GoldenCamera", true));
                m_38946_();
                return true;
            }
        }
        return false;
    }

    @Override
    public void m_6877_(Player player) {
        super.m_6877_(player);

        // Without this, client inventory is syncing properly when menu is closed. (only when opened by r-click in GUI)
        player.f_36095_.m_150444_();
    }

    @Override
    public boolean m_6875_(@NotNull Player player) {
        return ItemStack.m_150942_(player.m_150109_().m_8020_(cameraSlotIndex), camera.getStack());
    }

    public static CameraAttachmentsMenu fromBuffer(int containerId, Inventory playerInventory, FriendlyByteBuf buffer) {
        return new CameraAttachmentsMenu(containerId, playerInventory, buffer.readInt());
    }
}
