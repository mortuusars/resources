package io.github.mortuusars.exposure.util.supporter;

import net.minecraft.Util;

import java.util.UUID;

public record Supporter(String name, UUID uuid) {
    public boolean matches(UUID uuid) {
        if (uuid.equals(Util.f_137441_)) return false;
        return uuid().equals(uuid);
    }
}