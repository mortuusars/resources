package io.github.mortuusars.exposure.gui.screen.camera;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.infrastructure.FocalRange;
import io.github.mortuusars.exposure.data.Lenses;
import io.github.mortuusars.exposure.data.filter.Filters;
import io.github.mortuusars.exposure.gui.screen.ItemListScreen;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.menu.CameraAttachmentsMenu;
import io.github.mortuusars.exposure.sound.OnePerPlayerSounds;
import io.github.mortuusars.exposure.util.supporter.Supporters;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Supplier;

public class CameraAttachmentsScreen extends AbstractContainerScreen<CameraAttachmentsMenu> {
    public static final ResourceLocation TEXTURE = Exposure.resource("textures/gui/camera_attachments.png");

    protected final Player player;

    protected Map<Integer, Rect2i> slotPlaceholders = Collections.emptyMap();

    protected final HoveredElement flash = new HoveredElement(List.of(new Rect2i(96, 11, 28, 27)),
            () -> m_6262_().m_38853_(CameraItem.FLASH_ATTACHMENT.slot()).m_6657_());
    protected final HoveredElement filterOnLens = new HoveredElement(List.of(new Rect2i(114, 57, 13, 6),
            new Rect2i(110, 63, 17, 24)), () -> m_6262_().m_38853_(CameraItem.LENS_ATTACHMENT.slot()).m_6657_());
    protected final HoveredElement lens = new HoveredElement(List.of(new Rect2i(93, 48, 33, 34)),
            () -> m_6262_().m_38853_(CameraItem.LENS_ATTACHMENT.slot()).m_6657_());
    protected final HoveredElement filter = new HoveredElement(List.of(new Rect2i(110, 55, 13, 6),
            new Rect2i(106, 61, 17, 24)), () -> !m_6262_().m_38853_(CameraItem.LENS_ATTACHMENT.slot()).m_6657_());
    protected final HoveredElement lensBuiltIn = new HoveredElement(List.of(new Rect2i(93, 48, 29, 32)),
            () -> !m_6262_().m_38853_(CameraItem.LENS_ATTACHMENT.slot()).m_6657_());
    protected final HoveredElement viewfinder = new HoveredElement(List.of(new Rect2i(65, 25, 30, 12),
            new Rect2i(72, 31, 39, 11), new Rect2i(80, 42, 24, 5)), () -> true);

    protected @Nullable ImageButton regularSkinButton;
    protected @Nullable ImageButton goldSkinButton;

    public CameraAttachmentsScreen(CameraAttachmentsMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
        this.player = playerInventory.f_35978_;
    }

    @Override
    public void m_274333_() {
        OnePerPlayerSounds.play(player, Exposure.SoundEvents.CAMERA_GENERIC_CLICK.get(), SoundSource.PLAYERS, 0.9f, 0.9f);
    }

    @Override
    protected void m_7856_() {
        this.f_97727_ = 185;
        f_97731_ = this.f_97727_ - 94;
        super.m_7856_();

        slotPlaceholders = Map.of(
                CameraItem.FILM_ATTACHMENT.slot(), new Rect2i(238, 0, 18, 18),
                CameraItem.FLASH_ATTACHMENT.slot(), new Rect2i(238, 18, 18, 18),
                CameraItem.LENS_ATTACHMENT.slot(), new Rect2i(238, 36, 18, 18),
                CameraItem.FILTER_ATTACHMENT.slot(), new Rect2i(238, 54, 18, 18)
        );

        if (Supporters.hasAccessToGoldenSkin(Objects.requireNonNull(Minecraft.m_91087_().f_91074_).m_20148_())) {
            regularSkinButton = new ImageButton(f_97735_ + 8, f_97736_ + 18, 7, 7, 224, 0, 7, TEXTURE, b -> changeCameraSkin(false));
            goldSkinButton = new ImageButton(f_97735_ + 8, f_97736_ + 18, 7, 7, 231, 0, 7, TEXTURE, b -> changeCameraSkin(true));
            regularSkinButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.exposure.camera_attachments.change_skin")));
            goldSkinButton.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.exposure.camera_attachments.change_skin")));
            m_142416_(regularSkinButton);
            m_142416_(goldSkinButton);
        }
    }

    protected void changeCameraSkin(boolean isGold) {
        int buttonId = isGold ? CameraAttachmentsMenu.SKIN_GOLD_BUTTON_ID : CameraAttachmentsMenu.SKIN_REGULAR_BUTTON_ID;
        m_6262_().m_6366_(Objects.requireNonNull(Minecraft.m_91087_().f_91074_), buttonId);
        Objects.requireNonNull(Minecraft.m_91087_().f_91072_).m_105208_(m_6262_().f_38840_, buttonId);
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (regularSkinButton != null && goldSkinButton != null) {
            boolean isGold = m_6262_().getCamera().getStack().m_41783_() != null
                    && m_6262_().getCamera().getStack().m_41783_().m_128471_("GoldenCamera");
            regularSkinButton.f_93624_ = isGold;
            goldSkinButton.f_93624_ = !isGold;
        }

        this.m_280273_(guiGraphics);
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);

        for (Slot slot : m_6262_().f_38839_) {
            if (!slot.m_8010_(player)) {
                guiGraphics.m_280480_(slot.m_7993_(), f_97735_ + slot.f_40220_, f_97736_ + slot.f_40221_);
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                guiGraphics.m_280398_(TEXTURE, f_97735_ + slot.f_40220_ - 2, f_97736_ + slot.f_40221_ - 2, 350, 236, 92, 20, 20, 256, 256);
                RenderSystem.disableBlend();
            }
        }

        this.m_280072_(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void m_7286_(@NotNull GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShader(GameRenderer::m_172817_);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.m_280218_(TEXTURE, this.f_97735_, this.f_97736_, 0, 0, this.f_97726_, this.f_97727_);

        renderSlotPlaceholders(guiGraphics, mouseX, mouseY, partialTick);

        renderAttachments(guiGraphics, mouseX, mouseY, partialTick);

        for (Slot slot : m_6262_().f_38839_) {
            if (!slot.m_8010_(player)) {
                guiGraphics.m_280218_(TEXTURE, f_97735_ + slot.f_40220_ - 2, f_97736_ + slot.f_40221_ - 2, 236, 72, 20, 20);
            }
        }

        RenderSystem.disableBlend();
    }

    private void renderAttachments(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (m_6262_().m_38853_(CameraItem.FLASH_ATTACHMENT.slot()).m_6657_()) {
            int vOffset = isMouseOver(flash, mouseX, mouseY) ? 28 : 0;
            guiGraphics.m_280218_(TEXTURE, f_97735_ + 96, f_97736_ + 11, 176, vOffset, 28, 28);
        }

        boolean hasLens = m_6262_().m_38853_(CameraItem.LENS_ATTACHMENT.slot()).m_6657_();
        if (hasLens) {
            int vOffset = isMouseOver(lens, mouseX, mouseY) && !isMouseOver(filterOnLens, mouseX, mouseY) ? 37 : 0;
            guiGraphics.m_280218_(TEXTURE, f_97735_ + 93, f_97736_ + 47, 176, 56 + vOffset, 35, 37);
        } else if (isMouseOver(lensBuiltIn, mouseX, mouseY) && !isMouseOver(filter, mouseX, mouseY)) {
            guiGraphics.m_280218_(TEXTURE, f_97735_ + 93, f_97736_ + 47, 176, 130, 31, 35);
        }

        Slot filterSlot = m_6262_().m_38853_(CameraItem.FILTER_ATTACHMENT.slot());
        int filterX = hasLens ? 102 : 98;
        int filterY = hasLens ? 54 : 52;
        if (filterSlot.m_6657_()) {
            Filters.of(filterSlot.m_7993_()).ifPresent(filter -> {
                int tintRGB = filter.getTintColor();
                float r = ((tintRGB >> 16) & 0xFF) / 255f;
                float g = ((tintRGB >> 8) & 0xFF) / 255f;
                float b = (tintRGB & 0xFF) / 255f;

                if (isMouseOver(filterOnLens, mouseX, mouseY) || isMouseOver(this.filter, mouseX, mouseY)) {
                    r *= 1.35f;
                    g *= 1.35f;
                    b *= 1.35f;
                }

                RenderSystem.setShaderColor(r, g, b, 1.0F);
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();

                ResourceLocation filterTexture = filter.getAttachmentTexture();
                guiGraphics.m_280163_(filterTexture, f_97735_ + filterX, f_97736_ + filterY, 0, 0, 32, 32, 32, 32);
                RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            });
        } else if (isMouseOver(filterOnLens, mouseX, mouseY)) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            guiGraphics.m_280218_(TEXTURE, f_97735_ + 110, f_97736_ + 58, 176, 165, 15, 23);
        } else if (isMouseOver(filter, mouseX, mouseY)) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            guiGraphics.m_280218_(TEXTURE, f_97735_ + 106, f_97736_ + 56, 176, 165, 15, 23);
        }

        if (isMouseOver(viewfinder, mouseX, mouseY) && !isMouseOver(flash, mouseX, mouseY)) {
            guiGraphics.m_280218_(TEXTURE, f_97735_ + 65, f_97736_ + 24, 42, 185, 49, 26);
        }
    }

    protected boolean isMouseOver(HoveredElement element, int mouseX, int mouseY) {
        if (!element.isEnabled.get()) {
            return false;
        }

        mouseX -= f_97735_;
        mouseY -= f_97736_;

        for (Rect2i area : element.hoverArea) {
            if (mouseX >= area.m_110085_() && mouseX < area.m_110085_() + area.m_110090_() &&
                    mouseY >= area.m_110086_() && mouseY < area.m_110086_() + area.m_110091_()) {
                return true;
            }
        }

        return false;
    }

    protected void renderSlotPlaceholders(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        for (int slotIndex : slotPlaceholders.keySet()) {
            Slot slot = m_6262_().m_38853_(slotIndex);
            if (!slot.m_6657_()) {
                Rect2i placeholder = slotPlaceholders.get(slotIndex);
                guiGraphics.m_280218_(TEXTURE, f_97735_ + slot.f_40220_ - 1, f_97736_ + slot.f_40221_ - 1,
                        placeholder.m_110085_(), placeholder.m_110086_(), placeholder.m_110090_(), placeholder.m_110091_());
            }
        }
    }

    @Override
    protected void m_280072_(GuiGraphics guiGraphics, int x, int y) {
        if (isMouseOver(flash, x, y)) {
            guiGraphics.m_280245_(f_96547_, f_96547_.m_92923_(
                    Component.m_237115_("gui.exposure.camera_attachments.flash.tooltip"), 230), x, y);
        } else if (isMouseOver(viewfinder, x, y)) {
            Component key = Component.m_237113_(ExposureClient.getCameraControlsKey().m_90863_().getString())
                    .m_130940_(ChatFormatting.GRAY);
            Component middleClick = Config.Client.VIEWFINDER_MIDDLE_CLICK_CONTROLS.get()
                    ? Component.m_237115_("gui.exposure.camera_attachments.viewfinder.tooltip.or_middle_click")
                    : Component.m_237119_();
            guiGraphics.m_280245_(f_96547_, f_96547_.m_92923_(
                    Component.m_237110_("gui.exposure.camera_attachments.viewfinder.tooltip", key, middleClick), 230), x, y);
        } else if (isMouseOver(filter, x, y) || isMouseOver(filterOnLens, x, y)) {
            guiGraphics.m_280245_(f_96547_, f_96547_.m_92923_(
                    Component.m_237115_("gui.exposure.camera_attachments.filter.tooltip"), 230), x, y);
        } else if (isMouseOver(lens, x, y) || isMouseOver(lensBuiltIn, x, y)) {
            guiGraphics.m_280245_(f_96547_, f_96547_.m_92923_(
                    Component.m_237115_("gui.exposure.camera_attachments.lens.tooltip"), 230), x, y);
        } else {
            super.m_280072_(guiGraphics, x, y);
        }
    }

    @Override
    protected @NotNull List<Component> m_280553_(ItemStack stack) {
        List<Component> tooltip = super.m_280553_(stack);
        if (stack.m_204117_(Exposure.Tags.Items.LENSES) && f_97734_ != null && f_97734_.m_7993_().equals(stack)) {
            tooltip.add(Component.m_237110_("gui.exposure.viewfinder.focal_length", FocalRange.ofStack(stack).m_7912_())
                    .m_130940_(ChatFormatting.GOLD));
        }
        return tooltip;
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        int x = (int) mouseX;
        int y = (int) mouseY;

        if (isMouseOver(filter, x, y) || isMouseOver(filterOnLens, x, y)) {
            List<ItemStack> itemStacks = new ArrayList<>();
            for (Holder<Item> holder : BuiltInRegistries.f_257033_.m_206058_(Exposure.Tags.Items.FILTERS)) {
                itemStacks.add(new ItemStack(holder));
            }

            ItemListScreen screen = new ItemListScreen(this, Component.m_237115_("gui.exposure.filters"), itemStacks) {
                @Override
                protected List<Component> getTooltipFromContainerItem(ItemStack stack) {
                    List<Component> tooltip = super.getTooltipFromContainerItem(stack);
                    if (Minecraft.m_91087_().f_91066_.f_92125_) {
                        Filters.of(stack).ifPresent(filter ->
                                tooltip.add(Component.m_237113_(filter.getShader().toString())
                                        .m_130940_(ChatFormatting.GRAY)));
                    }
                    return tooltip;
                }
            };
            Minecraft.m_91087_().m_91152_(screen);

            return true;
        } else if (isMouseOver(lens, x, y) || isMouseOver(lensBuiltIn, x, y)) {
            List<ItemStack> itemStacks = new ArrayList<>();
            for (Holder<Item> holder : BuiltInRegistries.f_257033_.m_206058_(Exposure.Tags.Items.LENSES)) {
                itemStacks.add(new ItemStack(holder));
            }

            ItemListScreen screen = new ItemListScreen(this, Component.m_237115_("gui.exposure.lenses"), itemStacks) {
                @Override
                protected List<Component> getTooltipFromContainerItem(ItemStack stack) {
                    List<Component> tooltip = super.getTooltipFromContainerItem(stack);
                    Lenses.getFocalRangeOf(stack).ifPresent(fr ->
                            tooltip.add(Component.m_237110_("gui.exposure.viewfinder.focal_length", fr.m_7912_())
                                    .m_130940_(ChatFormatting.GOLD)));
                    return tooltip;
                }
            };
            Minecraft.m_91087_().m_91152_(screen);
            return true;
        }

        return super.m_6375_(mouseX, mouseY, button);
    }

    public record HoveredElement(List<Rect2i> hoverArea, Supplier<Boolean> isEnabled) {
    }
}
