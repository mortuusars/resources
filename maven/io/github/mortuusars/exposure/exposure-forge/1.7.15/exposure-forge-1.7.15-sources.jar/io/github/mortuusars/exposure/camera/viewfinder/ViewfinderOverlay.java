package io.github.mortuusars.exposure.camera.viewfinder;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.camera.CameraClient;
import io.github.mortuusars.exposure.gui.screen.camera.ViewfinderControlsScreen;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.item.FilmRollItem;
import io.github.mortuusars.exposure.util.GuiUtil;
import io.github.mortuusars.exposure.util.ItemAndStack;
import io.github.mortuusars.exposure.util.Rect2f;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix4f;

import java.util.Optional;

public class ViewfinderOverlay {
    public static final ResourceLocation VIEWFINDER_TEXTURE = Exposure.resource("textures/gui/viewfinder/viewfinder.png");
    public static final ResourceLocation NO_FILM_ICON_TEXTURE = Exposure.resource("textures/gui/viewfinder/icon/no_film.png");
    public static final ResourceLocation REMAINING_FRAMES_ICON_TEXTURE = Exposure.resource("textures/gui/viewfinder/icon/remaining_frames.png");

    public static Rect2f opening = new Rect2f(0, 0, 0, 0);

    private static final PoseStack POSE_STACK = new PoseStack();
    private static Minecraft minecraft = Minecraft.m_91087_();
    private static Player player = minecraft.f_91074_;

    private static int backgroundColor;

    private static float scale = 1f;

    private static Float xRot = null;
    private static Float yRot = null;
    private static Float xRot0 = null;
    private static Float yRot0 = null;

    public static void setup() {
        minecraft = Minecraft.m_91087_();
        player = minecraft.f_91074_;

        backgroundColor = Config.Client.getBackgroundColor();
        scale = 0.5f;
    }

    public static float getScale() {
        return scale;
    }

    public static void render() {
        final int width = minecraft.m_91268_().m_85445_();
        final int height = minecraft.m_91268_().m_85446_();

        scale = Mth.m_14179_(Math.min(0.8f * minecraft.m_91297_(), 0.8f), scale, 1f);
        float openingSize = Math.min(width, height);

        opening = new Rect2f((width - openingSize) / 2f, (height - openingSize) / 2f, openingSize, openingSize);

        if (minecraft.f_91066_.f_92062_)
            return;

        Optional<Camera<?>> cameraOpt = CameraClient.getCamera();
        if (cameraOpt.isEmpty()) {
            return;
        }

        Camera<?> camera = cameraOpt.get();
        CameraItem cameraItem = camera.get().getItem();
        ItemStack cameraStack = camera.get().getStack();

        if (xRot == null || yRot == null || xRot0 == null || yRot0 == null) {
            xRot = player.m_146909_();
            yRot = player.m_146908_();
            xRot0 = xRot;
            yRot0 = yRot;
        }
        float delta = Math.min(0.7f * minecraft.m_91297_(), 0.8f);
        xRot0 = Mth.m_14179_(delta, xRot0, xRot);
        yRot0 = Mth.m_14179_(delta, yRot0, yRot);
        xRot = player.m_146909_();
        yRot = player.m_146908_();
        float xDelay = (xRot - xRot0);
        float yDelay = (yRot - yRot0);
        // Adjust for gui scale:
        xDelay *= width / (float)Minecraft.m_91087_().m_91268_().m_85441_();
        yDelay *= height / (float)Minecraft.m_91087_().m_91268_().m_85442_();
        xDelay *= 3.5f;
        yDelay *= 3.5f;

        PoseStack poseStack = POSE_STACK;
        poseStack.m_85836_();
        poseStack.m_252880_(width / 2f, height / 2f, 0);
        poseStack.m_85841_(scale, scale, scale);

        float attackAnim = player.m_21324_(minecraft.m_91296_());
        if (attackAnim > 0.5f)
            attackAnim = 1f - attackAnim;
        poseStack.m_85841_(1f - attackAnim * 0.4f, 1f - attackAnim * 0.6f, 1f - attackAnim * 0.4f);
        poseStack.m_252880_(width / 16f * attackAnim, width / 5f * attackAnim, 0);
        poseStack.m_252781_(Axis.f_252403_.m_252977_(Mth.m_14179_(attackAnim, 0, 10)));
        poseStack.m_252781_(Axis.f_252529_.m_252977_(Mth.m_14179_(attackAnim, 0, 100)));

        poseStack.m_252880_(-width / 2f - yDelay, -height / 2f - xDelay, 0);

        if (minecraft.f_91066_.m_231830_().m_231551_())
            bobView(poseStack, minecraft.m_91296_());

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        // -9999 to cover all screen when poseStack is scaled down.
        // Left
        drawRect(poseStack, -9999, opening.y, opening.x, opening.y + opening.height, backgroundColor);
        // Right
        drawRect(poseStack, opening.x + opening.width, opening.y, width + 9999, opening.y + opening.height, backgroundColor);
        // Top
        drawRect(poseStack, -9999, -9999, width + 9999, opening.y, backgroundColor);
        // Bottom
        drawRect(poseStack, -9999, opening.y + opening.height, width + 9999, height + 9999, backgroundColor);

        // Shutter
        if (cameraItem.isShutterOpen(cameraStack)) {
            drawRect(poseStack, opening.x, opening.y, opening.x + opening.width, opening.y + opening.height, 0xfa1f1d1b);
        }

        // Opening Texture
        RenderSystem.enableBlend();
        RenderSystem.setShaderTexture(0, VIEWFINDER_TEXTURE);
        GuiUtil.blit(poseStack, opening.x, opening.x + opening.width, opening.y, opening.y + opening.height, 0f, 0f, 1f, 0f, 1f);

        // Guide
        RenderSystem.setShaderTexture(0, Exposure.resource("textures/gui/viewfinder/composition_guide/" +
                cameraItem.getCompositionGuide(cameraStack).getId() + ".png"));
        GuiUtil.blit(poseStack, opening.x, opening.x + opening.width, opening.y, opening.y + opening.height, -1f, 0f, 1f, 0f, 1f);

        if (!(minecraft.f_91080_ instanceof ViewfinderControlsScreen)) {
            renderIcons(poseStack, cameraItem, cameraStack);
        }

        poseStack.m_85849_();
    }

    private static void renderIcons(PoseStack poseStack, CameraItem cameraItem, ItemStack cameraStack) {
        Optional<ItemAndStack<FilmRollItem>> film = cameraItem.getFilm(cameraStack);
        if (film.isEmpty() || !film.get().getItem().canAddFrame(film.get().getStack())) {
            RenderSystem.setShaderTexture(0, NO_FILM_ICON_TEXTURE);
            GuiUtil.blit(poseStack, (opening.x + (opening.width / 2) - 12), opening.y + opening.height - 19,
                    24, 19, 0, 0, 24, 19, 0);
        }
        else {
            ItemAndStack<FilmRollItem> f = film.get();
            int maxFrames = f.getItem().getMaxFrameCount(f.getStack());
            int exposedFrames = f.getItem().getExposedFramesCount(f.getStack());
            int remainingFrames = Math.max(0, maxFrames - exposedFrames);
            if (maxFrames > 5 && remainingFrames <= 3) {
                RenderSystem.setShaderTexture(0, REMAINING_FRAMES_ICON_TEXTURE);
                GuiUtil.blit(poseStack, (opening.x + (opening.width / 2) - 17), opening.y + opening.height - 15,
                        33, 15, 0, (remainingFrames - 1) * 15, 33, 45, 0);
            }
        }
    }

    public static void drawRect(PoseStack poseStack, float minX, float minY, float maxX, float maxY, int color) {
        if (minX < maxX) {
            float temp = minX;
            minX = maxX;
            maxX = temp;
        }

        if (minY < maxY) {
            float temp = minY;
            minY = maxY;
            maxY = temp;
        }

        float alpha = (color >> 24 & 255) / 255.0F;
        float r = (color >> 16 & 255) / 255.0F;
        float g = (color >> 8 & 255) / 255.0F;
        float b = (color & 255) / 255.0F;

        Matrix4f matrix = poseStack.m_85850_().m_252922_();

        BufferBuilder bufferbuilder = Tesselator.m_85913_().m_85915_();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::m_172811_);
        bufferbuilder.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85815_);
        bufferbuilder.m_252986_(matrix, minX, maxY, 0.0F).m_85950_(r, g, b, alpha).m_5752_();
        bufferbuilder.m_252986_(matrix, maxX, maxY, 0.0F).m_85950_(r, g, b, alpha).m_5752_();
        bufferbuilder.m_252986_(matrix, maxX, minY, 0.0F).m_85950_(r, g, b, alpha).m_5752_();
        bufferbuilder.m_252986_(matrix, minX, minY, 0.0F).m_85950_(r, g, b, alpha).m_5752_();
        BufferUploader.m_231202_(bufferbuilder.m_231175_());
        RenderSystem.disableBlend();
    }

    public static void bobView(PoseStack poseStack, float partialTicks) {
        if (minecraft.m_91288_() instanceof Player pl) {
            float f = pl.f_19787_ - pl.f_19867_;
            float f1 = -(pl.f_19787_ + f * partialTicks);
            float f2 = Mth.m_14179_(partialTicks, pl.f_36099_, pl.f_36100_);
            poseStack.m_85837_((Mth.m_14031_(f1 * (float) Math.PI) * f2 * 16F), (-Math.abs(Mth.m_14089_(f1 * (float) Math.PI) * f2 * 32F)), 0.0D);
            poseStack.m_252781_(Axis.f_252403_.m_252977_(Mth.m_14031_(f1 * (float) Math.PI) * f2 * 3.0F));
        }
    }
}

