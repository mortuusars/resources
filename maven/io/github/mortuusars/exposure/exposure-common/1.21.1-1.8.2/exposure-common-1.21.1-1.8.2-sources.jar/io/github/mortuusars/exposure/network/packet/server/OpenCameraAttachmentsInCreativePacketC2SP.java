package io.github.mortuusars.exposure.network.packet.server;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

public record OpenCameraAttachmentsInCreativePacketC2SP(int cameraSlotIndex) implements Packet {
    public static final class_2960 ID = Exposure.resource("open_camera_attachments");
    public static final class_8710.class_9154<OpenCameraAttachmentsInCreativePacketC2SP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, OpenCameraAttachmentsInCreativePacketC2SP> STREAM_CODEC = class_9139.method_56434(
            class_9135.field_48550, OpenCameraAttachmentsInCreativePacketC2SP::cameraSlotIndex,
            OpenCameraAttachmentsInCreativePacketC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (player instanceof class_3222 serverPlayer) {
            serverPlayer.field_13995.execute(() -> {
                class_1799 stack = player.method_31548().method_5438(cameraSlotIndex);
                if (stack.method_7909() instanceof CameraItem cameraItem)
                    cameraItem.openCameraAttachments(player, cameraSlotIndex, true);
            });
        }

        return true;
    }
}
