package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record CreateChromaticExposureS2CP(String id, List<ExposureIdentifier> layers) implements Packet {
    public static final class_2960 ID = Exposure.resource("create_chromatic_exposure");
    public static final class_8710.class_9154<CreateChromaticExposureS2CP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, CreateChromaticExposureS2CP> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48554, CreateChromaticExposureS2CP::id,
            ExposureIdentifier.STREAM_CODEC.method_56433(class_9135.method_56363()), CreateChromaticExposureS2CP::layers,
            CreateChromaticExposureS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.createChromaticExposure(this);
        return true;
    }
}
