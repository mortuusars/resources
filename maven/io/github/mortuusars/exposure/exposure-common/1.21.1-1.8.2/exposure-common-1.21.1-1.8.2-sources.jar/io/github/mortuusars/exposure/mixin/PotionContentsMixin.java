package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.Config;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import net.minecraft.class_6880;

@Mixin(class_1844.class)
public abstract class PotionContentsMixin {
    @Shadow public abstract Optional<class_6880<class_1842>> potion();

    @Inject(method = "getColor()I", at = @At("RETURN"), cancellable = true)
    private void onGetColor(CallbackInfoReturnable<Integer> cir) {
        if (!Config.Client.DIFFERENT_DEVELOPING_POTION_COLORS.get() || cir.getReturnValue() != 0xFF385DC6) { // Default color
            return;
        }

        potion().ifPresent(potionHolder -> {
            if (potionHolder.comp_349().equals(class_1847.field_8967.comp_349())) {
                cir.setReturnValue(0xFF424D8F);
                return;
            }

            if (potionHolder.comp_349().equals(class_1847.field_8999.comp_349())) {
                cir.setReturnValue(0xFF653594);
                return;
            }

            if (potionHolder.comp_349().equals(class_1847.field_8985.comp_349())) {
                cir.setReturnValue(0xFF3E7782);
                return;
            }
        });
    }
}
