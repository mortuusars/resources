package io.github.mortuusars.exposure.network;

import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record PacketDefinition(class_8710.class_9154<?> type,
                               class_9139<? super class_9129, ? extends Packet> streamCodec) {
}
