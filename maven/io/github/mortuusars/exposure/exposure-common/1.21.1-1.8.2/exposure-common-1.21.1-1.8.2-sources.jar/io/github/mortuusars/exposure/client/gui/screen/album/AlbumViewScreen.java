package io.github.mortuusars.exposure.client.gui.screen.album;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.client.gui.screen.element.Pager;
import io.github.mortuusars.exposure.client.gui.screen.element.TextBlock;
import io.github.mortuusars.exposure.client.gui.screen.element.textbox.HorizontalAlignment;
import io.github.mortuusars.exposure.client.input.Key;
import io.github.mortuusars.exposure.client.input.KeyBindings;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.util.PagingDirection;
import io.github.mortuusars.exposure.util.Side;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import io.github.mortuusars.exposure.world.item.component.album.AlbumContent;
import io.github.mortuusars.exposure.world.item.component.album.AlbumPage;
import io.github.mortuusars.exposure.world.item.component.album.SignedAlbumContent;
import io.github.mortuusars.exposure.world.item.component.album.SignedAlbumPage;
import io.github.mortuusars.exposure.world.item.util.ItemAndStack;
import io.github.mortuusars.exposure.world.sound.SoundEffect;
import net.minecraft.class_1109;
import net.minecraft.class_1799;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3417;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_757;
import net.minecraft.class_7919;
import net.minecraft.client.gui.components.*;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public class AlbumViewScreen extends class_437 {
    protected final Pager pager = new Pager()
            .setChangeSound(new SoundEffect(() -> class_3417.field_17481))
            .onPageChanged(this::onSpreadChanged);

    protected final KeyBindings keyBindings = KeyBindings.of(
            Key.press(Minecrft.options().field_1822).executes(this::method_25419),
            Key.press(class_3675.field_31983).or(Key.press(class_3675.field_32015)).executes(pager::previousPage),
            Key.press(class_3675.field_31984).or(Key.press(class_3675.field_32018)).executes(pager::nextPage),
            Key.release(class_3675.field_31983).or(Key.press(class_3675.field_32015)).executes(pager::resetCooldown),
            Key.release(class_3675.field_31984).or(Key.press(class_3675.field_32018)).executes(pager::resetCooldown)
    );

    protected final List<Page> pages = new ArrayList<>();

    protected AlbumAccess albumAccess;
    protected int imageWidth;
    protected int imageHeight;
    protected int leftPos;
    protected int topPos;

    public AlbumViewScreen(AlbumAccess albumAccess) {
        super(class_2561.method_43473());
        this.albumAccess = albumAccess;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    protected void method_25426() {
        this.imageWidth = 298;
        this.imageHeight = 188;
        this.leftPos = (this.field_22789 - this.imageWidth) / 2;
        this.topPos = (this.field_22790 - this.imageHeight) / 2;

        pages.clear();

        // LEFT:
        Page leftPage = createPage(Side.LEFT, 0);
        pages.add(leftPage);

        class_344 previousPageButton = new class_344(leftPos + 12, topPos + 164, 13, 15,
                AlbumGUI.PREVIOUS_PAGE_BUTTON_SPRITES, button -> pager.changePage(PagingDirection.PREVIOUS), class_2561.method_43471("gui.exposure.previous_page"));
        previousPageButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure.previous_page")));
        method_37063(previousPageButton);

        // RIGHT:
        Page rightPage = createPage(Side.RIGHT, 140);
        pages.add(rightPage);

        class_344 nextPageButton = new class_344(leftPos + 273, topPos + 164, 13, 15,
                AlbumGUI.NEXT_PAGE_BUTTON_SPRITES, button -> pager.changePage(PagingDirection.NEXT), class_2561.method_43471("gui.exposure.next_page"));
        nextPageButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure.next_page")));
        method_37063(nextPageButton);

        int spreadsCount = (int) Math.ceil(albumAccess.pages().size() / 2f);
        pager.setPagesCount(spreadsCount)
                .setPreviousPageButton(previousPageButton)
                .setNextPageButton(nextPageButton);
    }

    protected Page createPage(Side side, int xOffset) {
        int x = leftPos + xOffset;
        int y = topPos;

        PhotographSlotWidget photographWidget = new PhotographSlotWidget(this, x + 25, y + 21, 108, 108,
                () -> getPage(side).orElse(PageContent.EMPTY).photograph())
                .editable(false)
                .primaryAction(widget -> inspectPhotograph(widget.getPhotograph()));

        method_37063(photographWidget);

        TextBlock noteWidget = new TextBlock(field_22793, x + 22, y + 133, 114, 27,
                getPage(side).orElse(PageContent.EMPTY).note(), this::method_25430);
        noteWidget.fontColor = Config.getColor(Config.Client.ALBUM_FONT_MAIN_COLOR);
        noteWidget.alignment = HorizontalAlignment.CENTER;
        noteWidget.drawShadow = false;
        //  TextBlock is rendered manually to not be a part of TAB navigation.
        //  addRenderableWidget(noteWidget);

        return new Page(side, photographWidget, noteWidget);
    }

    public List<PageContent> getPages() {
        return albumAccess.pages();
    }

    public Optional<PageContent> getPage(int pageIndex) {
        if (pageIndex <= getPages().size() - 1)
            return Optional.ofNullable(getPages().get(pageIndex));

        return Optional.empty();
    }

    public Optional<PageContent> getPage(Side side) {
        return getPage(getCurrentSpreadIndex() * 2 + side.getIndex());
    }

    public int getCurrentSpreadIndex() {
        return pager.getPage();
    }

    protected void onSpreadChanged(int oldSpread, int newSpread) {
        forEachPage(page -> {
            class_2561 note = getPage(page.side).orElse(PageContent.EMPTY).note();
            page.noteWidget().method_25355(note);
        });
    }

    public void setAlbumAccess(AlbumAccess albumAccess) {
        this.albumAccess = albumAccess;
        pager.setPagesCount(albumAccess.getPageCount() / 2);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        renderTooltip(guiGraphics, mouseX, mouseY);

        for (Page page : pages) {
            class_339 noteWidget = page.noteWidget();
            if (noteWidget instanceof TextBlock textBlock) {
                textBlock.method_25394(guiGraphics, mouseX, mouseY, partialTick);
            }
        }

        this.renderTooltip(guiGraphics, mouseX, mouseY);
    }

    protected void renderTooltip(class_332 guiGraphics, int x, int y) {
        for (Page page : pages) {
            if (page.photographWidget().method_25367()) {
                page.photographWidget().renderTooltip(guiGraphics, x, y);
                return;
            }
        }
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        method_52752(guiGraphics);

        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.method_25291(AlbumGUI.TEXTURE, leftPos, topPos, 0, 0, 0,
                imageWidth, imageHeight, 512, 512);

        int currentSpreadIndex = getCurrentSpreadIndex();
        drawPageNumbers(guiGraphics, currentSpreadIndex, mouseX, mouseY);
    }

    protected void drawPageNumbers(class_332 guiGraphics, int currentSpreadIndex, int mouseX, int mouseY) {
        class_327 font = Minecrft.get().field_1772;

        String leftPageNumber = Integer.toString(currentSpreadIndex * 2 + 1);
        String rightPageNumber = Integer.toString(currentSpreadIndex * 2 + 2);

        guiGraphics.method_51433(font, leftPageNumber, leftPos + 71 + (8 - font.method_1727(leftPageNumber) / 2),
                topPos + 167, Config.getColor(Config.Client.ALBUM_FONT_SECONDARY_COLOR), false);

        guiGraphics.method_51433(font, rightPageNumber, leftPos + 212 + (8 - font.method_1727(rightPageNumber) / 2),
                topPos + 167, Config.getColor(Config.Client.ALBUM_FONT_SECONDARY_COLOR), false);
    }

    // --

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (super.method_25402(mouseX, mouseY, button)) return true;

        for (Page page : pages) {
            if (page.noteWidget().method_25402(mouseX, mouseY, button)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean method_25430(@Nullable class_2583 style) {
        if (style == null)
            return false;

        class_2558 clickEvent = style.method_10970();
        if (clickEvent == null)
            return false;
        else if (clickEvent.method_10845() == class_2558.class_2559.field_11748) {
            String pageIndexStr = clickEvent.method_10844();
            int pageIndex = Integer.parseInt(pageIndexStr) - 1;
            forcePage(pageIndex);
            return true;
        }

        boolean handled = super.method_25430(style);
        if (handled && clickEvent.method_10845() == class_2558.class_2559.field_11750)
            method_25419();
        return handled;
    }

    protected void forcePage(int pageIndex) {
        pager.changePage(pageIndex / 2);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        return keyBindings.keyPressed(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        return keyBindings.keyReleased(keyCode, scanCode, modifiers) || super.method_16803(keyCode, scanCode, modifiers);
    }

    // --

    protected void inspectPhotograph(class_1799 photograph) {
        if (!(photograph.method_7909() instanceof PhotographItem)) {
            return;
        }

        Minecrft.get().method_1507(new AlbumPhotographScreen(this, List.of(new ItemAndStack<>(photograph))));
        Minecrft.get().method_1483()
                .method_4873(class_1109.method_4757(Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(),
                        Minecrft.level().method_8409().method_43057() * 0.2f + 1.3f, 0.75f));
    }

    protected void forEachPage(Consumer<Page> pageAction) {
        for (Page page : pages) {
            pageAction.accept(page);
        }
    }

    protected record Page(Side side, PhotographSlotWidget photographWidget, TextBlock noteWidget) { }

    public record AlbumAccess(List<PageContent> pages) {
        public static final AlbumAccess EMPTY = new AlbumAccess(Collections.emptyList());

        public int getPageCount() {
            return this.pages.size();
        }

        public static AlbumAccess fromItem(class_1799 stack) {
            if (stack.method_57824(Exposure.DataComponents.ALBUM_CONTENT) instanceof AlbumContent content) {
                return new AlbumAccess(content.pages().stream().map(PageContent::new).toList());
            }

            if (stack.method_57824(Exposure.DataComponents.SIGNED_ALBUM_CONTENT) instanceof SignedAlbumContent content) {
                return new AlbumAccess(content.pages().stream().map(PageContent::new).toList());
            }

            return EMPTY;
        }
    }

    public record PageContent(class_1799 photograph, class_2561 note) {
        public static final PageContent EMPTY = new PageContent(class_1799.field_8037, class_2561.method_43473());

        public PageContent(AlbumPage page) {
            this(page.photograph(), class_2561.method_43470(page.note()));
        }

        public PageContent(SignedAlbumPage page) {
            this(page.photograph(), page.note());
        }
    }
}
