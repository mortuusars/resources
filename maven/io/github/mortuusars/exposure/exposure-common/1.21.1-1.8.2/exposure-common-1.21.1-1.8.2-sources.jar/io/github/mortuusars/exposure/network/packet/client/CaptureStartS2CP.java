package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.capture.CaptureProperties;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

public record CaptureStartS2CP(class_2960 templateId, CaptureProperties captureProperties) implements Packet {
    public static final class_2960 ID = Exposure.resource("capture_start");
    public static final class_9154<CaptureStartS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, CaptureStartS2CP> STREAM_CODEC = class_9139.method_56435(
            class_2960.field_48267, CaptureStartS2CP::templateId,
            CaptureProperties.STREAM_CODEC, CaptureStartS2CP::captureProperties,
            CaptureStartS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.startCapture(this);
        return true;
    }
}
