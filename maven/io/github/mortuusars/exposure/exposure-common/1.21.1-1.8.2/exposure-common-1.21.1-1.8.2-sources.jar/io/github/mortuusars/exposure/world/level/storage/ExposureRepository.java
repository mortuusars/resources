package io.github.mortuusars.exposure.world.level.storage;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.ExposureDataChangedS2CP;
import io.github.mortuusars.exposure.network.packet.client.ExposureDataResponseS2CP;
import io.github.mortuusars.exposure.util.UnixTimestamp;
import net.minecraft.class_26;
import net.minecraft.class_3222;
import net.minecraft.class_3544;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;
import java.util.function.Function;

public class ExposureRepository {
    public static final int EXPECTED_TIMEOUT_SECONDS = 60;
    public static final String EXPOSURES_DIRECTORY_NAME = "exposures";

    private static final Logger LOGGER = LogUtils.getLogger();

    protected final MinecraftServer server;
    protected final class_26 dataStorage;
    protected final Path worldFolderPath;
    protected final Path exposuresFolderPath;

    protected final Map<class_3222, Set<ExpectedExposure>> expectedExposures = new HashMap<>();

    public ExposureRepository(MinecraftServer server) {
        this.server = server;
        this.dataStorage = server.method_30002().method_17983();
        this.worldFolderPath = server.method_27050(class_5218.field_24188);
        this.exposuresFolderPath = worldFolderPath.resolve("data/" + EXPOSURES_DIRECTORY_NAME);
    }

    public List<String> getAllIds() {
        // Save exposures that are in cache and waiting to be saved:
        dataStorage.method_125();

        File folder = exposuresFolderPath.toFile();

        @Nullable File[] filesList = folder.listFiles();
        if (filesList == null) {
            return Collections.emptyList();
        }

        return Arrays.stream(filesList)
                .filter(file -> file != null && file.isFile())
                .map(file -> com.google.common.io.Files.getNameWithoutExtension(file.getName()))
                .toList();
    }

    public RequestedPalettedExposure loadExposure(@NotNull String id) {
        Preconditions.checkNotNull(id, "id");
        Preconditions.checkArgument(!class_3544.method_57181(id), "Cannot load exposure: id is empty.");

        String name = EXPOSURES_DIRECTORY_NAME + "/" + id;
        @Nullable ExposureData exposureData = dataStorage.method_20786(ExposureData.factory(), name);

        if (exposureData == null) {
            File filepath = exposuresFolderPath.resolve(id + ".dat").toFile();
            if (!filepath.exists()) {
                LOGGER.error("Exposure '{}' was not loaded. File '{}' does not exist.", id, filepath);
                return RequestedPalettedExposure.NOT_FOUND;
            }

            LOGGER.error("Exposure '{}' was not loaded. Check above messages for errors.", id);
            return RequestedPalettedExposure.CANNOT_LOAD;
        }

        return RequestedPalettedExposure.success(exposureData);
    }

    public void saveExposure(@NotNull String id, ExposureData data) {
        Preconditions.checkArgument(!class_3544.method_57181(id), "Cannot save exposure: id is null or empty.");

        if (ensureExposuresDirectoryExists()) {
            String saveDataName = EXPOSURES_DIRECTORY_NAME + "/" + id;
            dataStorage.method_123(saveDataName, data);
            data.method_80();
            Packets.sendToAllClients(new ExposureDataChangedS2CP(id));
        }
    }

    public void updateExposure(@NotNull String id, Function<ExposureData, ExposureData> updateFunction) {
        Preconditions.checkArgument(!class_3544.method_57181(id), "Cannot update exposure: id is null or empty.");

        loadExposure(id).getData().ifPresent(exposure -> {
            ExposureData updatedExposure = updateFunction.apply(exposure);
            if (!updatedExposure.equals(exposure)) {
                saveExposure(id, updatedExposure);
            }
        });
    }

    public void expect(class_3222 player, String id, BiConsumer<class_3222, String> onReceived) {
        Preconditions.checkArgument(!class_3544.method_57181(id), "id cannot be null or empty.");
        Set<ExpectedExposure> exposures = expectedExposures.computeIfAbsent(player, pl -> new HashSet<>());
        exposures.add(new ExpectedExposure(id, UnixTimestamp.Seconds.fromNow(EXPECTED_TIMEOUT_SECONDS), onReceived));
    }

    public void expect(class_3222 player, String id) {
        expect(player, id, (pl, i) -> {});
    }

    public void handleClientRequest(class_3222 player, String id) {
        RequestedPalettedExposure result;

        if (class_3544.method_57181(id)) {
            LOGGER.error("Null or empty id cannot be used to get an exposure data. Player: '{}'", player.method_5820());
            result = RequestedPalettedExposure.INVALID_ID;
        } else {
            result = loadExposure(id);
        }

        Packets.sendToClient(new ExposureDataResponseS2CP(id, result), player);
    }

    public void receiveClientUpload(class_3222 player, String id, ExposureData exposure) {
        if (!validateUpload(player, id)) {
            return;
        }

        saveExposure(id, exposure);
        onExposureReceived(player, id);

        LOGGER.debug("Saved exposure '{}' uploaded by '{}'.", id, player.method_5820());
    }

    public void clearExpectedExposuresTimedOutLongAgo() {
        for (Map.Entry<class_3222, Set<ExpectedExposure>> exposures : expectedExposures.entrySet()) {
            AtomicInteger cleared = new AtomicInteger();
            exposures.getValue().removeIf(expected -> {
                if (expected.isTimedOut(UnixTimestamp.Seconds.now() - EXPECTED_TIMEOUT_SECONDS)) {
                    cleared.getAndIncrement();
                    return true;
                }
                return false;
            });
            LOGGER.error("Cleared {} timed out expected exposures of player: '{}'", cleared.get(), exposures.getKey().method_5820());
        }
    }

    protected boolean validateUpload(class_3222 player, String id) {
        if (class_3544.method_57181(id)) {
            LOGGER.error("Null or empty id cannot be used to save captured exposure. Player: '{}'", player.method_5820());
            return false;
        }

        @Nullable ExpectedExposure expectedExposure = expectedExposures.getOrDefault(player, Collections.emptySet())
                .stream()
                .filter(ee -> ee.id().equals(id))
                .findFirst()
                .orElse(null);

        if (expectedExposure == null) {
            LOGGER.error("Received unexpected upload from player '{}' with ID '{}'. Discarding.", player.method_5820(), id);
            return false;
        } else if (expectedExposure.isTimedOut(UnixTimestamp.Seconds.now())) {
            LOGGER.error("Received expected upload from player '{}' with ID '{}' - {}seconds later than expected. Discarding.",
                    player.method_5820(), id, UnixTimestamp.Seconds.now() - expectedExposure.timeoutAt());
            return false;
        }

        return true;
    }

    protected void onExposureReceived(class_3222 player, String id) {
        expectedExposures.getOrDefault(player, Collections.emptySet())
                .removeIf(expectedExposure -> {
                    if (expectedExposure.id().equals(id)) {
                        expectedExposure.onReceived().accept(player, id);
                        return true;
                    }
                    return false;
                });
    }

    protected boolean ensureExposuresDirectoryExists() {
        try {
            return Files.exists(exposuresFolderPath) || exposuresFolderPath.toFile().mkdirs();
        } catch (Exception e) {
            LOGGER.error("Failed to create exposure storage directory: {}", e.toString());
            return false;
        }
    }
}
