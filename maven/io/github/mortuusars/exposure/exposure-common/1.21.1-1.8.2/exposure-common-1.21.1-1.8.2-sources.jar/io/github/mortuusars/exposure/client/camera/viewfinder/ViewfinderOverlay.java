package io.github.mortuusars.exposure.client.camera.viewfinder;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.client.animation.Animation;
import io.github.mortuusars.exposure.client.animation.EasingFunction;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.util.UnixTimestamp;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.item.camera.CameraSettings;
import io.github.mortuusars.exposure.world.item.BrokenInterplanarProjectorItem;
import io.github.mortuusars.exposure.world.item.FilmRollItem;
import io.github.mortuusars.exposure.world.item.component.StoredItemStack;
import io.github.mortuusars.exposure.world.item.camera.Attachment;
import io.github.mortuusars.exposure.client.util.GuiUtil;
import io.github.mortuusars.exposure.util.Rect2f;
import java.util.List;
import net.minecraft.class_155;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_746;
import net.minecraft.class_7833;
import net.minecraft.class_9779;

public class ViewfinderOverlay {
    public static final class_2960 VIEWFINDER_TEXTURE = Exposure.resource("textures/gui/viewfinder/viewfinder.png");
    public static final class_2960 NO_FILM_ICON_TEXTURE = Exposure.resource("textures/gui/viewfinder/no_film.png");
    public static final class_2960 REMAINING_FRAMES_ICON_TEXTURE = Exposure.resource("textures/gui/viewfinder/remaining_frames.png");
    public static final class_2960 BSOD_SAD_FACE_TEXTURE = Exposure.resource("textures/gui/viewfinder/bsod_sad_face.png");
    public static final class_2960 BSOD_QR_CODE_TEXTURE = Exposure.resource("textures/gui/viewfinder/bsod_qr_code.png");

    protected final class_746 player;
    protected final Camera camera;
    protected final Viewfinder viewfinder;
    protected final int backgroundColor;
    protected final Rect2f opening;

    protected final Animation scaleAnimation;
    protected final float initialScale;

    protected float scale;
    protected float bobX = 0f;
    protected float bobY = 0f;
    protected float attackAnim = 0f;
    protected float xRot;
    protected float yRot;
    protected float xRot0;
    protected float yRot0;

    protected boolean forceDrawShutterOnNextFrame;
    protected long forceDrawShutterUntil = -1;

    public ViewfinderOverlay(Camera camera, Viewfinder viewfinder) {
        this.player = Minecrft.player();
        this.camera = camera;
        this.viewfinder = viewfinder;
        this.backgroundColor = Config.getColor(Config.Client.VIEWFINDER_BACKGROUND_COLOR);
        this.opening = new Rect2f(0, 0, 0, 0);
        recalculateOpening();

        this.scaleAnimation = new Animation(300, EasingFunction.EASE_OUT_EXPO);
        this.initialScale = 0.5f;
        this.scale = 0.5f; // Start small to animate expanding

        this.xRot = Minecrft.get().field_1773.method_19418().method_19329();
        this.yRot = Minecrft.get().field_1773.method_19418().method_19330();
        this.xRot0 = xRot;
        this.yRot0 = yRot;
    }

    public Rect2f getOpening() {
        return opening;
    }

    public float getScale() {
        return scale;
    }

    public void render(class_332 guiGraphics, class_9779 deltaTracker) {
        recalculateOpening();
        scale = class_3532.method_16439((float) scaleAnimation.getValue(), initialScale, 1f);

        // opening and scale is updated even if overlay is not rendered - other classes may depend on them.

        if (!viewfinder.isLookingThrough() || Minecrft.options().field_1842 || camera.isEmpty()) return;

        final int width = Minecrft.get().method_22683().method_4486();
        final int height = Minecrft.get().method_22683().method_4502();

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(width / 2f, height / 2f, 0);
        guiGraphics.method_51448().method_22905(scale, scale, scale);

        if (Minecrft.options().method_42448().method_41753()) {
            bobView(guiGraphics.method_51448(), deltaTracker);
        }
        applyAttackAnimation(guiGraphics.method_51448(), deltaTracker);
        applyMovementDelay(guiGraphics.method_51448(), deltaTracker);

        guiGraphics.method_51448().method_46416(-width / 2f, -height / 2f, 0);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        // -9999 to cover all screen when overlay is scaled down
        // Left
        GuiUtil.drawRect(guiGraphics, opening.x, opening.y, -9999, opening.height, backgroundColor);
        // Right
        GuiUtil.drawRect(guiGraphics, opening.x + opening.width, opening.y, 9999, opening.height, backgroundColor);
        // Top
        GuiUtil.drawRect(guiGraphics, -4999, opening.y, 9999, -9999, backgroundColor);
        // Bottom
        GuiUtil.drawRect(guiGraphics, -4999, opening.y + opening.height, 9999, 9999, backgroundColor);

        boolean drawGuide = true;

        StoredItemStack filter = Attachment.FILTER.get(camera.getItemStack());
        if (filter.getForReading().method_7909() instanceof BrokenInterplanarProjectorItem brokenInterplanarProjector) {
            drawGuide = false;
            renderBSOD(guiGraphics, brokenInterplanarProjector, filter.getForReading());
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.enableDepthTest();
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        }

        drawShutter(guiGraphics);

        // Opening Texture
        GuiUtil.blit(VIEWFINDER_TEXTURE, guiGraphics.method_51448(), opening, 0, 0, (int) opening.width, (int) opening.height, 0);

        // Guide
        if (drawGuide) {
            class_2960 guideTexture = CameraSettings.COMPOSITION_GUIDE.getOrDefault(camera.getItemStack()).overlayTextureLocation();
            GuiUtil.blit(guideTexture, guiGraphics.method_51448(), opening, 0, 0, (int) opening.width, (int) opening.height, 0);
        }

        if (!(Minecrft.get().field_1755 instanceof ViewfinderCameraControlsScreen)) {
            renderStatusIcons(guiGraphics.method_51448(), camera.getItemStack());
        }

        guiGraphics.method_51448().method_22909();
        RenderSystem.disableDepthTest();
    }

    /**
     * Usually shutter drawing is controlled by camera#isShutterOpen,
     * but due to fast shutter speeds and occasional lag, shutter may not be drawn at all.
     * So we force shutter to render for at least some time when shutter is open. <br><br>
     * Combination of timestamp and next frame check is for cases where lag takes so long that 'forceDrawShutterUntil' is passed without rendering.
     */
    protected void drawShutter(class_332 guiGraphics) {
        if (camera.isShutterOpen() || forceDrawShutterOnNextFrame || forceDrawShutterUntil - System.currentTimeMillis() > 0) {
            GuiUtil.drawRect(guiGraphics, opening, 0xfa1f1d1b);
            forceDrawShutterOnNextFrame = false;
        }
    }

    public void startDrawingShutter() {
        forceDrawShutterOnNextFrame = true;
        forceDrawShutterUntil = UnixTimestamp.Milliseconds.now() + class_155.field_44973 * 2;
    }

    protected void renderBSOD(class_332 guiGraphics, BrokenInterplanarProjectorItem item, class_1799 stack) {
        class_327 font = Minecrft.get().field_1772;

        int yCenter = (int) (opening.y + opening.height / 2);
        int margin = font.field_2000;

        int x = (int) (opening.x + opening.width * 0.125f);
        int y = yCenter;

        int sadFaceSize = font.field_2000 * 5;
        guiGraphics.method_25290(BSOD_SAD_FACE_TEXTURE, x, y - sadFaceSize - margin, 0, 0, sadFaceSize, sadFaceSize, sadFaceSize, sadFaceSize);

        class_5250 message = class_2561.method_43471("item.exposure.broken_interplanar_projector.viewfinder.message");
        List<class_5481> messageLines = font.method_1728(message, (int) (opening.width * 0.75f));

        for (class_5481 line : messageLines) {
            guiGraphics.method_51430(font, line, x, y, 0xFFFFFFFF, false);
            y += font.field_2000;
        }

        y += margin;

        int qrCodeTextureSize = 41;
        int qrCodeSize = switch ((int) Minecrft.get().method_22683().method_4495()) {
            case 1 -> qrCodeTextureSize * 3;
            case 2 -> qrCodeTextureSize * 2;
            default -> qrCodeTextureSize;
        };
        guiGraphics.method_25290(BSOD_QR_CODE_TEXTURE, x, y, 0, 0, qrCodeSize, qrCodeSize, qrCodeSize, qrCodeSize);

        class_5250 errorCode = class_2561.method_43471("item.exposure.broken_interplanar_projector.viewfinder.error_code");
        guiGraphics.method_51439(font, errorCode, x + qrCodeSize + margin, y, 0xFFFFFFFF, false);
        y += font.field_2000;
        String code = item.getErrorCode(stack);
        guiGraphics.method_51433(font, code, x + qrCodeSize + margin, y, 0xFFFFFFFF, false);
    }

    public void bobView(class_4587 poseStack, class_9779 deltaTracker) {
        if (Minecrft.get().method_1560() instanceof class_1657 pl) {
            float walkDist = class_3532.method_16439(deltaTracker.method_60636(), pl.field_6039, pl.field_5973);
            float strength = class_3532.method_16439(deltaTracker.method_60636(), pl.field_7505, pl.field_7483);
            float x = class_3532.method_15374(walkDist * (float) Math.PI) * strength;
            float y = Math.abs(class_3532.method_15362(walkDist * (float) Math.PI) * strength);

            float delta = Math.min(deltaTracker.method_60636(), 1f);
            bobX = class_3532.method_16439(delta, bobX, x);
            bobY = class_3532.method_16439(delta, bobY, y);
            double guiScale = Minecrft.get().method_22683().method_4495();
            poseStack.method_22904(bobX * 100 / guiScale, bobY * 200 / guiScale, 0.0F);
            float scale = this.scale - (bobY * 0.25f);
            poseStack.method_22905(scale, scale, scale);
        }
    }

    public void applyAttackAnimation(class_4587 poseStack, class_9779 deltaTracker) {
        float attack = player.field_6251;
        if (attack > 0.1f)
            attack = 1f - attack;

        float delta = Math.min(deltaTracker.method_60636(), 1f);
        attackAnim = class_3532.method_16439(delta, attackAnim, attack);

        poseStack.method_22905(1f - attackAnim * 0.1f, 1f - attackAnim * 0.2f, 1f - attackAnim * 0.1f);
        poseStack.method_22907(class_7833.field_40717.rotationDegrees(class_3532.method_16439(attackAnim, 0, 5)));
        double guiScale = Minecrft.get().method_22683().method_4495();
        poseStack.method_22904(0, 60f / guiScale * attackAnim, 0);
    }

    public void applyMovementDelay(class_4587 poseStack, class_9779 deltaTracker) {
        float delta = Math.min(deltaTracker.method_60636() * 0.6f, 1.0f);
        xRot0 = class_3532.method_16439(delta, xRot0, xRot);
        yRot0 = class_3532.method_16439(delta, yRot0, yRot);
        xRot = Minecrft.get().field_1773.method_19418().method_19329();
        yRot = Minecrft.get().field_1773.method_19418().method_19330();
        double guiScale = Minecrft.get().method_22683().method_4495();
        double horizontalDelay = (yRot - yRot0) / guiScale * 3;
        double verticalDelay = (xRot - xRot0) / guiScale * 3;
        poseStack.method_22904(-horizontalDelay, -verticalDelay, 0);
    }

    protected void recalculateOpening() {
        final int width = Minecrft.get().method_22683().method_4486();
        final int height = Minecrft.get().method_22683().method_4502();
        final float openingSize = Math.min(width, height);

        opening.x = (width - openingSize) / 2f;
        opening.y = (height - openingSize) / 2f;
        opening.width = openingSize;
        opening.height = openingSize;
    }

    protected void renderStatusIcons(class_4587 poseStack, class_1799 cameraStack) {
        class_1799 filmStack = Attachment.FILM.get(cameraStack).getForReading();

        if (filmStack.method_7960()
                || !(filmStack.method_7909() instanceof FilmRollItem filmRollItem)
                || !filmRollItem.canAddFrame(filmStack)) {
            renderNoFilmIcon(poseStack);
            return;
        }

        renderRemainingFramesIcon(poseStack, filmRollItem, filmStack);
    }

    protected void renderNoFilmIcon(class_4587 poseStack) {
        RenderSystem.setShaderTexture(0, NO_FILM_ICON_TEXTURE);
        int x = (int) ((opening.x + (opening.width / 2) - 12));
        int y = (int) (opening.y + opening.height - 18);
        GuiUtil.blit(poseStack, x, y, 23, 18, 0, 0, 23, 18, 0);
    }

    protected void renderRemainingFramesIcon(class_4587 poseStack, FilmRollItem filmRollItem, class_1799 filmStack) {
        int maxFrames = filmRollItem.getMaxFrameCount(filmStack);
        int exposedFrames = filmRollItem.getStoredFramesCount(filmStack);
        int remainingFrames = Math.max(0, maxFrames - exposedFrames);
        if (maxFrames > 5 && remainingFrames <= 3) {
            RenderSystem.setShaderTexture(0, REMAINING_FRAMES_ICON_TEXTURE);
            float x = (int) (opening.x + (opening.width / 2) - 17);
            float y = (int) (opening.y + opening.height - 15);
            int vOffset = (remainingFrames - 1) * 15;
            GuiUtil.blit(poseStack, x, y, 33, 15, 0, vOffset, 33, 45, 0);
        }
    }
}
