package io.github.mortuusars.exposure.network.packet.server;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

public record QueryExposureDataC2SP(ExposureIdentifier identifier) implements Packet {
    public static final class_2960 ID = Exposure.resource("query_exposure_data");
    public static final class_8710.class_9154<QueryExposureDataC2SP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, QueryExposureDataC2SP> STREAM_CODEC = class_9139.method_56434(
            ExposureIdentifier.STREAM_CODEC, QueryExposureDataC2SP::identifier,
            QueryExposureDataC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        Preconditions.checkArgument(player instanceof class_3222, "Cannot handle packet: Player was is not available.");
//        PalettedExposure palettedExposure = ExposureServer.getExposure(identifier);
//        ExposureServer.exposureSender().sendTo(identifier, palettedExposure, ((ServerPlayer) player));
        return true;
    }
}
