package io.github.mortuusars.exposure.commands.exposure;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.commands.argument.TextureLocationArgument;
import io.github.mortuusars.exposure.commands.suggestion.ExposureIdSuggestionProvider;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import io.github.mortuusars.exposure.world.level.storage.RequestedPalettedExposure;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.ExposureDataResponseS2CP;
import io.github.mortuusars.exposure.network.packet.client.ShowExposureCommandS2CP;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2232;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class ShowCommand {
    public static LiteralArgumentBuilder<class_2168> get() {
        return class_2170.method_9247("show")
                .then(class_2170.method_9247("latest")
                        .executes(context -> latest(context.getSource(), context.getSource().method_9207(), false))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(context -> latest(context.getSource(), class_2186.method_9315(context, "player"), false))
                                .then(class_2170.method_9247("negative")
                                        .executes(context -> latest(context.getSource(), class_2186.method_9315(context, "player"), true))))
                        .then(class_2170.method_9247("negative")
                                .executes(context -> latest(context.getSource(), context.getSource().method_9207(), true))))
                .then(class_2170.method_9247("id")
                        .then(class_2170.method_9244("id", StringArgumentType.string())
                                .suggests(new ExposureIdSuggestionProvider())
                                .executes(context -> exposureId(context.getSource(),
                                        StringArgumentType.getString(context, "id"), false))
                                .then(class_2170.method_9247("negative")
                                        .executes(context -> exposureId(context.getSource(),
                                                StringArgumentType.getString(context, "id"), true)))))
                .then(class_2170.method_9247("texture")
                        .then(class_2170.method_9244("path", new TextureLocationArgument())
                                .executes(context -> texture(context.getSource(),
                                        class_2232.method_9443(context, "path"), false))
                                .then(class_2170.method_9247("negative")
                                        .executes(context -> texture(context.getSource(),
                                                class_2232.method_9443(context, "path"), true)))));
    }

    private static int latest(class_2168 stack, @NotNull class_3222 player, boolean negative) {
        List<Frame> frames = ExposureServer.frameHistory().getFramesOf(player);

        if (frames.isEmpty()) {
            stack.method_9213(class_2561.method_43470(player.method_5820() + " has not taken any photos yet."));
            return 0;
        }

        Packets.sendToClient(new ShowExposureCommandS2CP(frames, negative), player);
        return 0;
    }

    private static int exposureId(class_2168 stack, String id, boolean negative) {
        class_3222 player = stack.method_44023();
        if (player == null) {
            stack.method_9213(class_2561.method_43471("command.exposure.show.error.not_a_player"));
            return 1;
        }

        RequestedPalettedExposure palettedExposure = ExposureServer.exposureRepository().loadExposure(id);
        if (palettedExposure.getData().isEmpty()) {
            stack.method_9213(class_2561.method_43469("command.exposure.show.error.not_found", id));
            return 0;
        }

        Packets.sendToClient(new ExposureDataResponseS2CP(id, palettedExposure), player);
        Packets.sendToClient(ShowExposureCommandS2CP.identifier(ExposureIdentifier.id(id), negative), player);

        return 0;
    }

    private static int texture(class_2168 stack, class_2960 path, boolean negative) {
        class_3222 player = stack.method_44023();
        if (player == null) {
            stack.method_9213(class_2561.method_43471("command.exposure.show.error.not_a_player"));
            return 1;
        }

        ExposureIdentifier identifier = ExposureIdentifier.texture(path);
        Packets.sendToClient(ShowExposureCommandS2CP.identifier(identifier, negative), player);

        return 0;
    }
}
