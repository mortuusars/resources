package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record ExposureDataChangedS2CP(String id) implements Packet {
    public static final class_2960 ID = Exposure.resource("exposure_data_changed");
    public static final class_8710.class_9154<ExposureDataChangedS2CP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, ExposureDataChangedS2CP> STREAM_CODEC = class_9139.method_56434(
            class_9135.field_48554, ExposureDataChangedS2CP::id,
            ExposureDataChangedS2CP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.exposureDataChanged(this);
        return true;
    }
}
