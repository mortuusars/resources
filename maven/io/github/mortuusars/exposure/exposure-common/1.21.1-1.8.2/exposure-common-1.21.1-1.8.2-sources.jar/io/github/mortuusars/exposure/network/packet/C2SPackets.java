package io.github.mortuusars.exposure.network.packet;

import io.github.mortuusars.exposure.network.packet.server.*;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class C2SPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
                new class_8710.class_9155<>(AlbumSignC2SP.TYPE, AlbumSignC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(AlbumSyncNoteC2SP.TYPE, AlbumSyncNoteC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(ActiveCameraSetSettingC2SP.TYPE, ActiveCameraSetSettingC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(OpenCameraAttachmentsInCreativePacketC2SP.TYPE, OpenCameraAttachmentsInCreativePacketC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(ExposureRequestC2SP.TYPE, ExposureRequestC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(ActiveCameraReleaseC2SP.TYPE, ActiveCameraReleaseC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(InterplanarProjectionFinishedC2SP.TYPE, InterplanarProjectionFinishedC2SP.STREAM_CODEC),
                new class_8710.class_9155<>(ExposureDataC2SP.TYPE, ExposureDataC2SP.STREAM_CODEC)
        );
    }
}
