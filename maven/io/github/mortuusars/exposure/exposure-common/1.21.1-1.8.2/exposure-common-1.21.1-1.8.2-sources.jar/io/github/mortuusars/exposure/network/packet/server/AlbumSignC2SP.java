package io.github.mortuusars.exposure.network.packet.server;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.item.AlbumItem;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3419;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

public record AlbumSignC2SP(int slot, String title, String author) implements Packet {
    public static final class_2960 ID = Exposure.resource("album_sign");
    public static final class_8710.class_9154<AlbumSignC2SP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, AlbumSignC2SP> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48550, AlbumSignC2SP::slot,
            class_9135.field_48554, AlbumSignC2SP::title,
            class_9135.field_48554, AlbumSignC2SP::author,
            AlbumSignC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        Preconditions.checkState(player != null, "Cannot handle packet: Player was null");

        class_1799 albumStack = player.method_31548().method_5438(slot());
        if (albumStack.method_7909() instanceof AlbumItem albumItem) {
            class_1799 signedAlbumStack = albumItem.sign(albumStack, title(), author());
            player.method_31548().method_5447(slot(), signedAlbumStack);
            player.method_37908().method_43129(null, player, Exposure.SoundEvents.WRITE.get(), class_3419.field_15248, 0.8f ,1f);
        }

        return true;
    }
}
