package io.github.mortuusars.exposure.network.packet.server;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.Camera;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

public class ActiveCameraReleaseC2SP implements Packet {
    public static final ActiveCameraReleaseC2SP INSTANCE = new ActiveCameraReleaseC2SP();
    public static final class_9154<ActiveCameraReleaseC2SP> TYPE = new class_9154<>(Exposure.resource("active_camera_release"));
    public static final class_9139<class_2540, ActiveCameraReleaseC2SP> STREAM_CODEC = class_9139.method_56431(INSTANCE);
    private ActiveCameraReleaseC2SP() {
    }

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        player.getActiveExposureCameraOptional().ifPresentOrElse(
                Camera::release,
                () -> Exposure.LOGGER.error("Cannot release shutter: '{}' does not have an active camera.", player));

        return true;
    }
}
