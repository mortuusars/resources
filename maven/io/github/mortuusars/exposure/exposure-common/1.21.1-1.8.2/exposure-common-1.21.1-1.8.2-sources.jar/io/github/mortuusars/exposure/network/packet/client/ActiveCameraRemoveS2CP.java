package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.entity.CameraOperator;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record ActiveCameraRemoveS2CP(int operatorEntityId) implements Packet {
    public static final class_2960 ID = Exposure.resource("active_camera_remove");
    public static final class_8710.class_9154<ActiveCameraRemoveS2CP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, ActiveCameraRemoveS2CP> STREAM_CODEC = class_9139.method_56434(
            class_9135.field_48550, ActiveCameraRemoveS2CP::operatorEntityId,
            ActiveCameraRemoveS2CP::new
    );


    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (player.method_37908().method_8469(operatorEntityId) instanceof CameraOperator operator) {
            operator.removeActiveExposureCamera();
        }
        return true;
    }
}
