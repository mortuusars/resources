package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ShaderApplyS2CP(Optional<class_2960> shaderLocation) implements Packet {
    public static final class_2960 ID = Exposure.resource("shader_apply");
    public static final class_8710.class_9154<ShaderApplyS2CP> TYPE = new class_8710.class_9154<>(ID);
    public static final class_9139<class_2540, ShaderApplyS2CP> STREAM_CODEC = class_9139.method_56434(
            class_9135.method_56382(class_2960.field_48267), ShaderApplyS2CP::shaderLocation,
            ShaderApplyS2CP::new
    );

    public ShaderApplyS2CP(class_2960 location) {
        this(Optional.of(location));
    }

    public static final ShaderApplyS2CP REMOVE = new ShaderApplyS2CP(Optional.empty());

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        ClientPacketsHandler.applyShader(this);
        return true;
    }
}
