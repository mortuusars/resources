package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.world.level.storage.RequestedPalettedExposure;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

public record ExposureDataResponseS2CP(String id, RequestedPalettedExposure result) implements Packet {
    public static final class_2960 ID = Exposure.resource("exposure_data_response");
    public static final class_9154<ExposureDataResponseS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, ExposureDataResponseS2CP> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48554, ExposureDataResponseS2CP::id,
            RequestedPalettedExposure.STREAM_CODEC, ExposureDataResponseS2CP::result,
            ExposureDataResponseS2CP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ExposureClient.exposureStore().receive(id, result);
        return true;
    }
}
