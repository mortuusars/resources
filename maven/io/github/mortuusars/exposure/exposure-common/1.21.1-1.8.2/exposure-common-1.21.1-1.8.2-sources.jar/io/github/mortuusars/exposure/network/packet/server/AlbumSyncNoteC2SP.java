package io.github.mortuusars.exposure.network.packet.server;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.item.component.album.AlbumPage;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.exposure.world.inventory.AlbumMenu;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

public record AlbumSyncNoteC2SP(int pageIndex, String text) implements Packet {
    public static final class_2960 ID = Exposure.resource("album_update_note");
    public static final class_8710.class_9154<AlbumSyncNoteC2SP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, AlbumSyncNoteC2SP> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48550, AlbumSyncNoteC2SP::pageIndex,
            class_9135.field_48554, AlbumSyncNoteC2SP::text,
            AlbumSyncNoteC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        Preconditions.checkState(player != null, "Cannot handle packet: Player was null");

        if (!(player.field_7512 instanceof AlbumMenu albumMenu)) {
            throw new IllegalStateException("Player receiving this packet should have AlbumMenu open. " +
                    "Current menu: " + player.field_7512);
        }

        albumMenu.updatePage(pageIndex, page -> page.setNote(text));
        return true;
    }
}
