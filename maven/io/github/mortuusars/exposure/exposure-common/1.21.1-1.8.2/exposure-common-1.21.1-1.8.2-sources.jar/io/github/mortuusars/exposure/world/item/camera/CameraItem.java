package io.github.mortuusars.exposure.world.item.camera;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.*;
import io.github.mortuusars.exposure.network.packet.client.ShutterOpenedS2CP;
import io.github.mortuusars.exposure.world.block.FlashBlock;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.camera.*;
import io.github.mortuusars.exposure.world.camera.capture.CaptureType;
import io.github.mortuusars.exposure.world.camera.component.FocalRange;
import io.github.mortuusars.exposure.world.camera.component.ShutterSpeed;
import io.github.mortuusars.exposure.world.camera.capture.CaptureProperties;
import io.github.mortuusars.exposure.world.camera.capture.ProjectionInfo;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.world.camera.frame.*;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.data.Lenses;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.item.FilmItem;
import io.github.mortuusars.exposure.world.item.FilmRollItem;
import io.github.mortuusars.exposure.world.item.InterplanarProjectorItem;
import io.github.mortuusars.exposure.world.item.component.StoredItemStack;
import io.github.mortuusars.exposure.world.inventory.CameraAttachmentsMenu;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.CaptureStartS2CP;
import io.github.mortuusars.exposure.network.packet.server.OpenCameraAttachmentsInCreativePacketC2SP;
import io.github.mortuusars.exposure.server.CameraInstance;
import io.github.mortuusars.exposure.server.CameraInstances;
import io.github.mortuusars.exposure.world.item.util.ItemAndStack;
import io.github.mortuusars.exposure.world.level.LevelUtil;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import io.github.mortuusars.exposure.util.*;
import io.github.mortuusars.exposure.world.sound.Sound;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1560;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2675;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3612;
import net.minecraft.class_3908;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_437;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import net.minecraft.class_9334;
import net.minecraft.core.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CameraItem extends class_1792 {
    public static final int BASE_COOLDOWN = 2;
    public static final int FLASH_COOLDOWN = 10;
    public static final int PROJECT_COOLDOWN = 20;

    protected final Shutter shutter;
    protected final List<Attachment<?>> attachments;
    protected final List<ShutterSpeed> availableShutterSpeeds;

    public CameraItem(Shutter shutter, class_1793 properties) {
        super(properties);
        this.shutter = shutter;
        this.attachments = defineAttachments();
        this.availableShutterSpeeds = defineShutterSpeeds();

        shutter.onOpen(this::onShutterOpen);
        shutter.onClosed(this::onShutterClosed);
    }

    protected @NotNull List<Attachment<?>> defineAttachments() {
        return List.of(Attachment.FILM, Attachment.FLASH, Attachment.LENS, Attachment.FILTER);
    }

    protected List<ShutterSpeed> defineShutterSpeeds() {
        return List.of(
                new ShutterSpeed("1/500"),
                new ShutterSpeed("1/250"),
                new ShutterSpeed("1/125"),
                new ShutterSpeed("1/60"),
                new ShutterSpeed("1/30"),
                new ShutterSpeed("1/15"),
                new ShutterSpeed("1/8"),
                new ShutterSpeed("1/4"),
                new ShutterSpeed("1/2"),
                new ShutterSpeed("1\""),
                new ShutterSpeed("2\""),
                new ShutterSpeed("4\""),
                new ShutterSpeed("8\""),
                new ShutterSpeed("15\"")
        );
    }

    // --

    public Shutter getShutter() {
        return shutter;
    }

    public List<ShutterSpeed> getAvailableShutterSpeeds() {
        return availableShutterSpeeds;
    }

    public List<Attachment<?>> getAttachments() {
        return attachments;
    }

    public class_3414 getViewfinderOpenSound() {
        return Exposure.SoundEvents.VIEWFINDER_OPEN.get();
    }

    public class_3414 getViewfinderCloseSound() {
        return Exposure.SoundEvents.VIEWFINDER_CLOSE.get();
    }

    public class_3414 getReleaseButtonSound() {
        return Exposure.SoundEvents.CAMERA_RELEASE_BUTTON_CLICK.get();
    }

    public class_3414 getFlashSound() {
        return Exposure.SoundEvents.FLASH.get();
    }

    public class_2960 getCaptureType(class_1799 stack) {
        return CaptureType.CAMERA;
    }

    public float getCropFactor() {
        return Exposure.CROP_FACTOR;
    }

    public FocalRange getFocalRange(class_5455 registryAccess, class_1799 stack) {
        return Attachment.LENS.map(stack, lensStack -> Lenses.getFocalRangeOrDefault(registryAccess, lensStack))
                .orElse(FocalRange.getDefault());
    }

    public float getFov(class_1937 level, class_1799 stack) {
        double zoom = CameraSettings.ZOOM.getOrDefault(stack);
        FocalRange focalRange = getFocalRange(level.method_30349(), stack);
        return (float) focalRange.fovFromZoom(zoom);
    }

    public class_6880<ColorPalette> getColorPalette(class_5455 registryAccess, class_1799 stack) {
        class_5321<ColorPalette> key = Attachment.FILM.map(stack, FilmItem::getColorPaletteId).orElse(ColorPalettes.DEFAULT);
        return ColorPalettes.get(registryAccess, key);
    }

    protected Optional<ColorChannel> getChromaticChannel(class_1799 stack) {
        return Attachment.FILTER.map(stack, ColorChannel::fromFilterStack).orElse(Optional.empty());
    }

    protected Optional<ProjectionInfo> getProjectionInfo(class_1799 stack) {
        return Attachment.FILTER.map(stack, (filterItem, filterStack) ->
                        filterItem instanceof InterplanarProjectorItem projectorItem
                                ? projectorItem.getProjectingInfo(filterStack)
                                : Optional.<ProjectionInfo>empty())
                .orElse(Optional.empty());
    }

    // --

    public CameraId getOrCreateID(class_1799 stack) {
        if (!stack.method_57826(Exposure.DataComponents.CAMERA_ID)) {
            stack.method_57379(Exposure.DataComponents.CAMERA_ID, CameraId.create());
        }
        return stack.method_57824(Exposure.DataComponents.CAMERA_ID);
    }

    public boolean isInSelfieMode(class_1799 stack) {
        return CameraSettings.SELFIE_MODE.getOrDefault(stack);
    }

    public boolean isActive(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.CAMERA_ACTIVE, false);
    }

    public void setActive(class_1799 stack, boolean active) {
        stack.method_57379(Exposure.DataComponents.CAMERA_ACTIVE, active);
    }

    public boolean isDisassembled(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.CAMERA_DISASSEMBLED, false);
    }

    public void setDisassembled(class_1799 stack, boolean disassembled) {
        stack.method_57379(Exposure.DataComponents.CAMERA_DISASSEMBLED, disassembled);
    }

    public long getLastActionTime(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.CAMERA_LAST_ACTION_TIME, -1L);
    }

    public void setLastActionTime(class_1799 stack, long lastActionTime) {
        stack.method_57379(Exposure.DataComponents.CAMERA_LAST_ACTION_TIME, lastActionTime);
    }

    public void actionPerformed(class_1799 stack, CameraHolder holder) {
        setLastActionTime(stack, holder.asEntity().method_37908().method_8510());
        holder.asEntity().method_32876(class_5712.field_28146);
    }

    public @NotNull class_1271<class_1799> activateInHand(class_1657 player, class_1799 stack, @NotNull class_1268 hand) {
        player.setActiveExposureCamera(new CameraInHand(player, getOrCreateID(stack), hand));
        if (player.method_37908().field_9236) {
            Minecrft.releaseUseButton(); // Releasing use key to not take a shot immediately, if right click is still held.
        }
        return activate(player, stack);
    }

    public @NotNull class_1271<class_1799> activate(class_1297 entity, class_1799 stack) {
        setActive(stack, true);
        setDisassembled(stack, false);
        Sound.play(entity, getViewfinderOpenSound(), entity.method_5634(), 0.35f, 0.9f, 0.2f);
        entity.method_32876(class_5712.field_28739);
        return class_1271.method_22428(stack);
    }

    public @NotNull class_1271<class_1799> deactivate(class_1297 entity, class_1799 stack) {
        setActive(stack, false);
        CameraSettings.SELFIE_MODE.set(stack, false);
        Sound.play(entity, getViewfinderCloseSound(), entity.method_5634(), 0.35f, 0.9f, 0.2f);
        entity.method_32876(class_5712.field_28739);
        return class_1271.method_22428(stack);
    }

    public int calculateCooldownAfterShot(class_1799 stack, CaptureProperties captureProperties) {
        if (captureProperties.projection().isPresent()) return PROJECT_COOLDOWN;
        if (captureProperties.flash()) return FLASH_COOLDOWN;
        return BASE_COOLDOWN;
    }

    // --

    public boolean method_31567(@NotNull class_1799 stack) {
        return Config.Client.CAMERA_SHOW_FILM_BAR_ON_ITEM.get()
                && Attachment.FILM.map(stack, FilmRollItem::method_31567).orElse(false);
    }

    public int method_31569(@NotNull class_1799 stack) {
        return Attachment.FILM.map(stack, FilmRollItem::method_31569).orElse(0);
    }

    public int method_31571(@NotNull class_1799 stack) {
        return Attachment.FILM.map(stack, FilmRollItem::method_31571).orElse(0);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> components, class_1836 tooltipFlag) {
        if (Config.Client.CAMERA_SHOW_FILM_FRAMES_IN_TOOLTIP.get()) {
            Attachment.FILM.ifPresent(stack, (filmItem, filmStack) -> {
                int exposed = filmItem.getStoredFramesCount(filmStack);
                int max = filmItem.getMaxFrameCount(filmStack);
                components.add(class_2561.method_43469("item.exposure.camera.tooltip.film_roll_frames", exposed, max));
            });
        }

        if (Config.Client.CAMERA_SHOW_TOOLTIP_DETAILS.get()) {
            boolean rClickAttachments = Config.Server.CAMERA_GUI_RIGHT_CLICK_OPEN_ATTACHMENTS.get();
            boolean rClickHotswap = Config.Server.CAMERA_GUI_RIGHT_CLICK_HOTSWAP.get();

            if (rClickAttachments || rClickHotswap) {
                if (class_437.method_25442()) {
                    if (rClickAttachments)
                        components.add(class_2561.method_43471("item.exposure.camera.tooltip.details_attachments_screen"));
                    if (rClickHotswap)
                        components.add(class_2561.method_43471("item.exposure.camera.tooltip.details_hotswap"));
                } else
                    components.add(class_2561.method_43471("tooltip.exposure.hold_for_details"));
            }
        }
    }

    @Override
    public boolean method_31566(class_1799 stack, class_1799 otherStack, class_1735 slot, class_5536 action, class_1657 player, class_5630 access) {
        if (action != class_5536.field_27014) return false;

        if (getShutter().isOpen(stack)) {
            player.method_5783(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), 0.9f, 1f);
            player.method_7353(class_2561.method_43471("item.exposure.camera.camera_attachments.fail.shutter_open")
                    .method_27692(class_124.field_1061), true);
            return true;
        }

        if (otherStack.method_7960() && Config.Server.CAMERA_GUI_RIGHT_CLICK_OPEN_ATTACHMENTS.get()) {
            if (!(slot.field_7871 instanceof class_1661)) {
                return false; // Cannot open when not in player's inventory
            }

            if (player.method_7337() && player.method_37908().method_8608()) {
                Packets.sendToServer(new OpenCameraAttachmentsInCreativePacketC2SP(slot.method_34266()));
                return true;
            }

            openCameraAttachments(player, slot.method_34266(), true);
            return true;
        }

        if (Config.Server.CAMERA_GUI_RIGHT_CLICK_HOTSWAP.get()) {
            for (Attachment<?> attachment : getAttachments()) {
                if (attachment.matches(otherStack)) {
                    StoredItemStack currentAttachment = attachment.get(stack);

                    if (otherStack.method_7947() > 1 && !currentAttachment.isEmpty()) {
                        player.method_5783(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), 0.9f, 1f);
                        return true; // Cannot swap when holding more than one item
                    }

                    attachment.set(stack, otherStack.method_7971(1));

                    class_1799 returnedStack = !currentAttachment.isEmpty() ? currentAttachment.getCopy() : otherStack;
                    access.method_32332(returnedStack);

                    attachment.playInsertSoundSided(player);
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 level, class_1297 entity, int slotId, boolean isSelected) {
        if (!(entity instanceof class_1657 player) || !(level instanceof class_3218 serverLevel)) return;

        getShutter().tick(player, serverLevel, stack);

        boolean matchesActive = player.getActiveExposureCameraOptional()
                .map(camera -> camera.idMatches(getOrCreateID(stack)))
                .orElse(false);
        if (isActive(stack) && !matchesActive) {
            setActive(stack, false);
        }

        CameraInstances.ifPresent(stack, instance -> {
            CameraInstance.ProjectionState state = instance.getProjectionState(level);
            switch (state) {
                case SUCCESSFUL, FAILED, TIMED_OUT -> {
                    handleProjectionResult(serverLevel, player, stack, state, instance.getProjectionError(level));
                    instance.stopWaitingForProjection();
                }
            }
        });
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(@NotNull class_1937 level, @NotNull class_1657 player, @NotNull class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (hand == class_1268.field_5808
                && player.method_6079().method_7909() instanceof CameraItem offhandCameraItem
                && offhandCameraItem.isActive(player.method_6079())) {
            return class_1271.method_22430(stack);
        }

        if (!isActive(stack)) {
            return player.method_21823()
                    ? openCameraAttachments(player, stack, false)
                    : activateInHand(player, stack, hand);
        }

        return release(player, stack);
    }

    public @NotNull class_1271<class_1799> release(CameraHolder holder, class_1799 stack) {
        class_1297 entity = holder.asEntity();
        class_1937 level = entity.method_37908();

        Sound.playSided(entity, getReleaseButtonSound(), entity.method_5634(), 0.3f, 1f, 0.1f);

        if (level.field_9236
                || getShutter().isOpen(stack)
                || Attachment.FILM.isEmpty(stack)
                || !CameraInstances.canReleaseShutter(CameraId.ofStack(stack))) {
            return class_1271.method_22428(stack);
        }

        ItemAndStack<FilmRollItem> film = Attachment.FILM.get(stack).getItemAndStackCopy();

        if (!film.getItem().canAddFrame(film.getItemStack())) {
            return class_1271.method_22428(stack);
        }

        if (level instanceof class_3218 serverLevel) {
            if (!(holder.getPlayerExecutingExposure() instanceof class_3222 serverPlayer)) {
                Exposure.LOGGER.error("Cannot start capture: photographer '{}' does not have valid executing player.", holder);
                return class_1271.method_22428(stack);
            }

            int lightLevel = LevelUtil.getLightLevelAt(level, entity.method_24515());
            boolean shouldFlashFire = shouldFlashFire(stack, lightLevel);
            ShutterSpeed shutterSpeed = CameraSettings.SHUTTER_SPEED.getOrDefault(stack);

            getShutter().open(holder, serverLevel, stack, shutterSpeed);

            boolean flashHasFired = shouldFlashFire && tryUseFlash(entity, serverLevel, stack);

            CameraId cameraId = getOrCreateID(stack);
            String exposureId = ExposureIdentifier.createId(serverPlayer);

            CaptureProperties captureProperties = new CaptureProperties.Builder(exposureId)
                    .setCameraHolder(holder)
                    .setCameraID(cameraId)
                    .setShutterSpeed(CameraSettings.SHUTTER_SPEED.getOrDefault(stack))
                    .setFilmType(film.getItem().getType())
                    .setFrameSize(film.getItem().getFrameSize(film.getItemStack()))
                    .setCropFactor(getCropFactor())
                    .setColorPalette(getColorPalette(level.method_30349(), stack))
                    .setFlash(flashHasFired)
                    .setProjectingInfo(getProjectionInfo(stack))
                    .setChromaticChannel(getChromaticChannel(stack))
                    .extraData(tag -> tag.method_10569("light_level", lightLevel))
                    .build();

            if (shutterSpeed.shouldCauseTickingSound() || captureProperties.projection().isPresent()) {
                int duration = Math.max(shutterSpeed.getDurationTicks(), captureProperties.projection()
                        .map(l -> Config.Server.PROJECT_TIMEOUT_TICKS.get()).orElse(0));
                Sound.playShutterTicking(entity, cameraId, duration);
            }

            CameraInstances.createOrUpdate(cameraId, instance -> {
                int cooldown = calculateCooldownAfterShot(stack, captureProperties);
                instance.setDeferredCooldown(cooldown);

                captureProperties.projection().ifPresent(fileLoading -> {
                    instance.waitForProjection(level.method_8510() + Config.Server.PROJECT_TIMEOUT_TICKS.get());
                });
            });

            addNewFrame(serverLevel, captureProperties, holder, stack);

            ExposureServer.exposureRepository().expect(serverPlayer, exposureId);
            Packets.sendToClient(new CaptureStartS2CP(getCaptureType(stack), captureProperties), serverPlayer);
        }

        return class_1271.method_22428(stack);
    }

    protected void onShutterOpen(CameraHolder holder, class_3218 serverLevel, class_1799 stack) {
        holder.getExposureCameraOperator().ifPresent(operator -> {
            if (operator instanceof class_3222 player) {
                Packets.sendToClient(ShutterOpenedS2CP.INSTANCE, player);
            }
        });
    }

    protected void onShutterClosed(CameraHolder holder, class_3218 serverLevel, class_1799 stack) {
        if (holder instanceof class_1657 player) {
            int cooldown = CameraInstances.getOptional(stack).map(CameraInstance::getDeferredCooldown).orElse(BASE_COOLDOWN);
            player.method_7357().method_7906(this, cooldown);
        }

        Attachment.FILM.ifPresent(stack, (filmItem, filmStack) -> {
            class_3414 sound = filmItem.isFull(filmStack)
                    ? Exposure.SoundEvents.FILM_ADVANCE_LAST.get()
                    : Exposure.SoundEvents.FILM_ADVANCE.get();

            float fullness = filmItem.getFullness(filmStack);
            String id = holder.asEntity().method_5628() + getOrCreateID(stack).uuid().toString();
            Sound.playUnique(id, holder.asEntity(), sound, class_3419.field_15248, 1f, 0.85f + 0.2f * fullness);
        });
    }

    public class_1271<class_1799> openCameraAttachments(@NotNull class_1657 player, class_1799 stack, boolean openedFromGUI) {
        Preconditions.checkArgument(stack.method_7909() instanceof CameraItem, "%s is not a CameraItem.", stack);

        int cameraSlot = getMatchingSlotInInventory(player.method_31548(), stack);
        if (cameraSlot < 0) {
            Exposure.LOGGER.error("Cannot open camera attachments: slot index is not found for item '{}'.", stack);
            return class_1271.method_22431(stack);
        }

        return openCameraAttachments(player, cameraSlot, openedFromGUI);
    }

    public class_1271<class_1799> openCameraAttachments(@NotNull class_1657 player, int slotIndex, boolean openedFromGUI) {
        Preconditions.checkArgument(slotIndex >= 0,
                "slotIndex '%s' is invalid. Should be larger than 0", slotIndex);
        class_1799 stack = player.method_31548().method_5438(slotIndex);
        Preconditions.checkArgument(stack.method_7909() instanceof CameraItem,
                "Item in slotIndex '%s' is not a CameraItem but '%s'.", slotIndex, stack);

        if (getShutter().isOpen(stack)) {
            player.method_7353(class_2561.method_43471("item.exposure.camera.camera_attachments.fail.shutter_open")
                    .method_27692(class_124.field_1061), true);
            return class_1271.method_22431(stack);
        }

        getOrCreateID(stack);

        if (player instanceof class_3222 serverPlayer) {
            class_3908 menuProvider = new class_3908() {
                @Override
                public @NotNull class_2561 method_5476() {
                    return stack.method_57824(class_9334.field_49631) != null
                            ? stack.method_7964() : class_2561.method_43471("container.exposure.camera");
                }

                @Override
                public @NotNull class_1703 createMenu(int containerId, @NotNull class_1661 playerInventory, @NotNull class_1657 player) {
                    return new CameraAttachmentsMenu(containerId, playerInventory, slotIndex, openedFromGUI);
                }
            };

            PlatformHelper.openMenu(serverPlayer, menuProvider, buffer -> {
                buffer.method_53002(slotIndex);
                buffer.method_52964(openedFromGUI);
            });
        }

        setDisassembled(stack, true);
        Sound.play(player, Exposure.SoundEvents.CAMERA_GENERIC_CLICK.get(), class_3419.field_15248, 0.9f, 0.9f, 0.2f);

        return class_1271.method_22427(stack);
    }

    protected boolean shouldFlashFire(class_1799 stack, int lightLevel) {
        if (Attachment.FLASH.isEmpty(stack))
            return false;

        return switch (CameraSettings.FLASH_MODE.getOrDefault(stack)) {
            case OFF -> false;
            case ON -> true;
            case AUTO -> lightLevel < 8;
        };
    }

    protected boolean tryUseFlash(class_1297 entity, class_3218 serverLevel, class_1799 stack) {
        class_1937 level = entity.method_37908();
        class_2338 playerHeadPos = entity.method_24515().method_10084();
        @Nullable class_2338 flashPos = null;

        if (level.method_8320(playerHeadPos).method_26215() || level.method_8316(playerHeadPos).method_33659(class_3612.field_15910))
            flashPos = playerHeadPos;
        else {
            for (class_2350 direction : class_2350.values()) {
                class_2338 pos = playerHeadPos.method_10093(direction);
                if (level.method_8320(pos).method_26215() || level.method_8316(pos).method_33659(class_3612.field_15910)) {
                    flashPos = pos;
                }
            }
        }

        if (flashPos == null) {
            return false;
        }

        level.method_8652(flashPos, Exposure.Blocks.FLASH.get().method_9564()
                .method_11657(FlashBlock.WATERLOGGED, level.method_8316(flashPos)
                        .method_33659(class_3612.field_15910)), class_2248.field_31022);

        Sound.play(entity, getFlashSound(), entity.method_5634());

        entity.method_32876(class_5712.field_28727);

        // Send particles to other players:
        if (entity instanceof class_3222 serverPlayer) {
            serverPlayer.method_7281(Exposure.Stats.FLASHES_TRIGGERED);

            class_243 pos = entity.method_19538();
            pos = pos.method_1031(0, 1, 0).method_1019(entity.method_5720().method_18805(0.5, 0, 0.5));
            class_2675 packet = new class_2675(class_2398.field_17909, false,
                    pos.field_1352, pos.field_1351, pos.field_1350, 0, 0, 0, 0, 0);
            for (class_3222 pl : serverPlayer.method_51469().method_18456()) {
                if (!pl.equals(serverPlayer)) {
                    pl.field_13987.method_14364(packet);
                    class_5819 r = serverPlayer.method_51469().method_8409();
                    for (int i = 0; i < 4; i++) {
                        pl.field_13987.method_14364(new class_2675(class_2398.field_11207, false,
                                pos.field_1352 + r.method_43057() * 0.5f - 0.25f, pos.field_1351 + r.method_43057() * 0.5f + 0.2f, pos.field_1350 + r.method_43057() * 0.5f - 0.25f,
                                0, 0, 0, 0, 0));
                    }
                }
            }
        }
        return true;
    }

    // --

    public void addNewFrame(class_3218 level, CaptureProperties captureProperties, CameraHolder holder, class_1799 stack) {
        boolean projecting = captureProperties.projection().isPresent();

        float fov = getFov(level, stack);

        List<class_2338> positionsInFrame = projecting ? Collections.emptyList() : getPositionsInFrame(holder.asEntity(), fov);
        List<class_1309> entitiesInFrame = projecting ? Collections.emptyList() : getEntitiesInFrame(holder, level, stack);

        Frame frame = createFrame(holder, level, stack, captureProperties, positionsInFrame, entitiesInFrame);
        addFrameToFilm(stack, frame);
        onFrameAdded(holder, level, stack, frame, positionsInFrame, entitiesInFrame);
    }

    public Frame createFrame(CameraHolder holder, class_3218 level, class_1799 stack, CaptureProperties captureProperties,
                             List<class_2338> positionsInFrame, List<class_1309> entitiesInFrame) {
        return Frame.create()
                .setIdentifier(ExposureIdentifier.id(captureProperties.exposureId()))
                .setType(captureProperties.filmType())
                .setPhotographer(new Photographer(holder))
                .setEntitiesInFrame(entitiesInFrame.stream()
                        .limit(Exposure.MAX_ENTITIES_IN_FRAME)
                        .map(entity -> EntityInFrame.of(holder.asEntity(), entity, data -> {
                            PlatformHelper.postModifyEntityInFrameExtraDataEvent(holder, stack, entity, data);
                        }))
                        .toList())
                .addExtraData(Frame.SHUTTER_SPEED, CameraSettings.SHUTTER_SPEED.getOrDefault(stack))
                .addExtraData(Frame.TIMESTAMP, UnixTimestamp.Seconds.now())
                .updateExtraData(data -> addFrameExtraData(holder, level, stack, captureProperties, positionsInFrame, entitiesInFrame, data))
                .toImmutable();
    }

    protected void addFrameExtraData(CameraHolder holder, class_3218 level, class_1799 camera, CaptureProperties captureProperties,
                                     List<class_2338> positionsInFrame, List<class_1309> entitiesInFrame, ExtraData data) {
        class_1297 cameraHolder = holder.asEntity();
        boolean projecting = captureProperties.projection().isPresent();

        if (projecting) {
            data.put(Frame.PROJECTED, true);
            return;
        }

        if (isInSelfieMode(camera)) {
            data.put(Frame.SELFIE, true);
        }
        if (captureProperties.flash()) {
            data.put(Frame.FLASH, true);
        }

        double zoom = CameraSettings.ZOOM.getOrDefault(camera);
        FocalRange focalRange = getFocalRange(level.method_30349(), camera);
        int focalLength = (int) focalRange.focalLengthFromZoom(zoom);
        data.put(Frame.FOCAL_LENGTH, focalLength);

        captureProperties.extraData().get(CaptureProperties.LIGHT_LEVEL)
                .ifPresent(lightLevel -> data.put(Frame.LIGHT_LEVEL, lightLevel));

        if (captureProperties.filmType() == ExposureType.BLACK_AND_WHITE) {
            captureProperties.singleChannel().ifPresent(channel ->
                    data.put(Frame.COLOR_CHANNEL, channel));
        }

        data.put(Frame.POSITION, cameraHolder.method_19538());
        data.put(Frame.PITCH, cameraHolder.method_36455());
        data.put(Frame.YAW, cameraHolder.method_36454());

        data.put(Frame.DAY_TIME, (int) level.method_8532());
        data.put(Frame.DIMENSION, level.method_27983().method_29177());

        class_2338 blockPos = cameraHolder.method_24515();

        int surfaceHeight = level.method_8624(class_2902.class_2903.field_13202, cameraHolder.method_31477(), cameraHolder.method_31479());
        level.method_8533();
        int skyLight = level.method_8314(class_1944.field_9284, blockPos);

        if (cameraHolder.method_5869()) {
            data.put(Frame.UNDERWATER, true);
        }
        if (cameraHolder.method_31478() < Math.min(level.method_8615(), surfaceHeight) && skyLight == 0) {
            data.put(Frame.IN_CAVE, true);
        } else if (!cameraHolder.method_5869()) {
            class_1959.class_1963 precipitation = level.method_23753(blockPos).comp_349().method_48162(blockPos);
            if (level.method_8546() && precipitation != class_1959.class_1963.field_9384)
                data.put(Frame.WEATHER, precipitation == class_1959.class_1963.field_9383 ? "Snowstorm" : "Thunder");
            else if (level.method_8419() && precipitation != class_1959.class_1963.field_9384)
                data.put(Frame.WEATHER, precipitation == class_1959.class_1963.field_9383 ? "Snow" : "Rain");
            else
                data.put(Frame.WEATHER, "Clear");
        }

        // Most common biome:
        positionsInFrame.stream()
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet()
                .stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .flatMap(pos -> level.method_23753(pos).method_40230().map(class_5321::method_29177))
                .ifPresent(biome -> data.put(Frame.BIOME, biome));

        List<class_2960> structures = positionsInFrame.stream()
                .map(pos -> LevelUtil.getStructuresAt(level, pos))
                .flatMap(List::stream)
                .collect(Collectors.toSet()) // Remove duplicates
                .stream()
                .toList();
        if (!structures.isEmpty()) {
            data.put(Frame.STRUCTURES, structures);
        }

        PlatformHelper.postModifyFrameExtraDataEvent(holder, camera, captureProperties, positionsInFrame, entitiesInFrame, data);
    }

    /**
     * Fires 5 rays from camera and obtains positions where they landed. <br>
     * First ray is in the center (equals to look direction).<br>
     * Next are: top left, top right, bottom left, bottom right.
     * These 4 are roughly in positions where rule of thirds cross points are.
     */
    public List<class_2338> getPositionsInFrame(class_1297 cameraHolder, float fov) {
        class_243 eyePos = cameraHolder.method_33571();
        class_243 lookDirection = class_243.method_1030(cameraHolder.method_36455(), cameraHolder.method_36454());
        // offset roughly corresponds to rule of thirds distance
        float offsetDegrees = (float) ((fov * getCropFactor()) / 4.3);

        return Vec3Util.getCrossVectors(lookDirection, offsetDegrees).stream()
                .map(direction -> {
                    class_243 endPos = eyePos.method_1019(direction.method_1021(100));
                    return cameraHolder.method_37908().method_17742(
                            new class_3959(eyePos, endPos, class_3959.class_3960.field_17559, class_3959.class_242.field_1347, cameraHolder));
                })
                .filter(hit -> hit.method_17783() != class_239.class_240.field_1333)
                .map(class_3965::method_17777)
                .toList();
    }

    public void addFrameToFilm(class_1799 stack, Frame frame) {
        Attachment.FILM.ifPresentOrElse(stack, (filmItem, filmStack) -> {
            class_1799 updatedFilmStack = filmStack.method_7972();
            filmItem.addFrame(updatedFilmStack, frame);
            Attachment.FILM.set(stack, updatedFilmStack);
        }, () -> Exposure.LOGGER.error("Cannot add frame: no film attachment is present."));
    }

    public void onFrameAdded(CameraHolder holder, class_3218 level, class_1799 stack, Frame frame,
                             List<class_2338> positionsInFrame, List<class_1309> entitiesInFrame) {
        ExposureServer.frameHistory().add(holder.asEntity(), frame);

        entitiesInFrame.forEach(entity -> entityCaptured(holder, stack, entity));

        holder.getPlayerAwardedForExposure()
                .filter(player -> player instanceof class_3222)
                .ifPresent(player -> {
                    class_3222 serverPlayer = (class_3222) player;
                    serverPlayer.method_7281(Exposure.Stats.FILM_FRAMES_EXPOSED);
                    Exposure.CriteriaTriggers.FRAME_EXPOSED.get().trigger(
                            serverPlayer, holder, stack, frame, positionsInFrame, entitiesInFrame);
                });

        PlatformHelper.postFrameAddedEvent(holder, stack, frame, positionsInFrame, entitiesInFrame);
    }

    public List<class_1309> getEntitiesInFrame(CameraHolder cameraHolder, class_3218 level, class_1799 stack) {
        float zoom = CameraSettings.ZOOM.getOrDefault(stack);
        double fov = getFocalRange(level.method_30349(), stack).fovFromZoom(zoom) * getCropFactor();

        return EntitiesInFrame.get(cameraHolder.asEntity(), fov, isInSelfieMode(stack));
    }

    protected void entityCaptured(CameraHolder cameraHolder, class_1799 stack, class_1309 entity) {
        if (cameraHolder.asEntity() instanceof class_3222 player && entity instanceof class_1560 enderMan) {
            boolean lookingAtAngryEnderMan = player.equals(enderMan.method_5968()) && enderMan.method_7026(player);

            if (lookingAtAngryEnderMan) {
                // I wanted to implement this in a predicate,
                // but it's tricky because EntitySubPredicates do not get the player in their 'match' method.
                // So it's just easier to hardcode it like this.
                Exposure.CriteriaTriggers.PHOTOGRAPH_ENDERMAN_EYES.get().method_9141(player);
            }
        }
    }

    public void handleProjectionResult(class_3218 level, CameraHolder holder, class_1799 stack,
                                       CameraInstance.ProjectionState projectionState, Optional<TranslatableError> error) {
        StoredItemStack filter = Attachment.FILTER.get(stack);
        if (filter.isEmpty()) return;
        if (!(filter.getItem() instanceof InterplanarProjectorItem interplanarProjector)) return;
        if (!interplanarProjector.isConsumable(filter.getForReading())) return;

        class_1297 entity = holder.asEntity();

        if (projectionState == CameraInstance.ProjectionState.FAILED || projectionState == CameraInstance.ProjectionState.TIMED_OUT) {
            class_1799 filterStack = filter.getCopy().method_60503(Exposure.Items.BROKEN_INTERPLANAR_PROJECTOR.get());
            error.ifPresent(err -> filterStack.method_57379(Exposure.DataComponents.INTERPLANAR_PROJECTOR_ERROR_CODE, err.code()));
            Attachment.FILTER.set(stack, filterStack);
            Sound.play(entity, Exposure.SoundEvents.BSOD.get());
            if (getShutter().isOpen(stack)) {
                getShutter().close(holder, level, stack);
            }
            return;
        }

        class_1799 filterStack = filter.getCopy();
        filterStack.method_7934(1);
        Attachment.FILTER.set(stack, filterStack);

        if (projectionState == CameraInstance.ProjectionState.SUCCESSFUL) {
            holder.getServerPlayerAwardedForExposure()
                    .ifPresent(player -> Exposure.CriteriaTriggers.SUCCESSFULLY_PROJECT_IMAGE.get().method_9141(player));
            Sound.play(entity, Exposure.SoundEvents.INTERPLANAR_PROJECT.get(), entity.method_5634(), 0.8f, 1.1f);
            for (int i = 0; i < 16; i++) {
                level.method_14199(class_2398.field_11214, entity.method_23317(), entity.method_23318() + 1.2, entity.method_23321(), 2,
                        entity.method_59922().method_43059() * 0.3, entity.method_59922().method_43059() * 0.3, entity.method_59922().method_43059() * 0.3, 0.01);
            }
        }
    }

    // --

    protected int getMatchingSlotInInventory(class_1661 inventory, class_1799 stack) {
        for (int i = 0; i < inventory.method_5439(); i++) {
            if (inventory.method_5438(i).equals(stack)) {
                return i;
            }
        }
        return -1;
    }
}

