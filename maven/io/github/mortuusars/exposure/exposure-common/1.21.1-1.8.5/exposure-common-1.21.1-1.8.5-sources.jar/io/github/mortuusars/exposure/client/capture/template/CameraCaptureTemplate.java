package io.github.mortuusars.exposure.client.capture.template;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.client.capture.Capture;
import io.github.mortuusars.exposure.client.capture.action.CaptureAction;
import io.github.mortuusars.exposure.client.capture.palettizer.Palettizer;
import io.github.mortuusars.exposure.client.image.modifier.ImageModifier;
import io.github.mortuusars.exposure.client.capture.saving.ExposureUploader;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.capture.CaptureProperties;
import io.github.mortuusars.exposure.world.camera.capture.ProjectionInfo;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.util.cycles.task.EmptyTask;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.level.storage.ExposureData;
import net.minecraft.class_1297;
import net.minecraft.class_6880;
import io.github.mortuusars.exposure.util.cycles.task.Task;
import org.slf4j.Logger;

public class CameraCaptureTemplate implements CaptureTemplate {
    private static final Logger LOGGER = LogUtils.getLogger();

    @Override
    public Task<?> createTask(CaptureProperties data) {
        if (data.exposureId().isEmpty()) {
            LOGGER.error("Failed to create capture task: exposure id cannot be empty. '{}'", data);
            return new EmptyTask<>();
        }

        int entityId = data.cameraHolderEntityId().orElse(Minecrft.player().method_5628());
        if (!(Minecrft.level().method_8469(entityId) instanceof CameraHolder cameraHolder)) {
            LOGGER.error("Failed to create capture task: camera holder cannot be obtained. '{}'", data);
            return new EmptyTask<>();
        }

        class_1297 entity = cameraHolder.asEntity();
        ExposureType filmType = data.filmType();
        int frameSize = data.frameSize().orElse(Config.Server.DEFAULT_FRAME_SIZE.getAsInt());
        class_6880<ColorPalette> palette = data.getColorPalette(Minecrft.registryAccess());

        Task<ExposureData> captureTask = Capture.of(Capture.screenshot(),
                        CaptureAction.setCameraEntity(entity),
                        CaptureAction.hideGui(),
                        CaptureAction.forceRegularOrSelfieCamera(),
                        CaptureAction.optional(data.fovOverride(), fov -> CaptureAction.setFov(fov)),
                        CaptureAction.optional(Config.Client.KEEP_POST_EFFECT.isFalse(), CaptureAction::disablePostEffect),
                        CaptureAction.modifyGamma(data.getShutterSpeed()),
                        CaptureAction.optional(data.flash(), () -> CaptureAction.flash(entity)))
                .handleErrorAndGetResult(printCasualErrorInChat())
                .thenAsync(ImageModifier.chain(
                        ImageModifier.Crop.SQUARE_CENTER,
                        ImageModifier.Crop.factor(data.cropFactor()),
                        ImageModifier.Resize.to(frameSize),
                        ImageModifier.brightness(data.getShutterSpeed()),
                        ImageModifier.optional(filmType == ExposureType.BLACK_AND_WHITE,
                                data.singleChannel()
                                        .map(ImageModifier::singleChannelBlackAndWhite)
                                        .orElse(ImageModifier.BLACK_AND_WHITE))))
                .thenAsync(Palettizer.DITHERED.palettizeAndClose(palette.comp_349()))
                .thenAsync(convertToExposureData(palette, createExposureTag(cameraHolder.getPlayerExecutingExposure(), data, false)));

        if (data.projection().isPresent()) {
            ProjectionInfo projectionInfo = data.projection().get();
            String path = projectionInfo.path();

            captureTask = captureTask.overridenBy(Capture.of(Capture.path(path),
                            CaptureAction.optional(data.cameraId(), CaptureAction::interplanarProjection))
                    .logErrorAndGetResult(LOGGER)
                    .thenAsync(ImageModifier.chain(
                            ImageModifier.Crop.SQUARE_CENTER,
                            ImageModifier.Resize.to(frameSize),
                            ImageModifier.brightness(data.getShutterSpeed()),
                            ImageModifier.optional(filmType == ExposureType.BLACK_AND_WHITE,
                                    data.singleChannel()
                                            .map(ImageModifier::singleChannelBlackAndWhite)
                                            .orElse(ImageModifier.BLACK_AND_WHITE))))
                    .thenAsync(Palettizer.fromProjectionMode(projectionInfo.mode()).palettizeAndClose(palette.comp_349()))
                    .thenAsync(convertToExposureData(palette, createExposureTag(cameraHolder.getPlayerExecutingExposure(), data, true))));
        }

        return captureTask
                .acceptAsync(image -> ExposureUploader.upload(data.exposureId(), image))
                .onError(printCasualErrorInChat());
    }
}
