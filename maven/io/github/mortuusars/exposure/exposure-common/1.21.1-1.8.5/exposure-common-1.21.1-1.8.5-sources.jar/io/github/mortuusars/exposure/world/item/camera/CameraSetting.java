package io.github.mortuusars.exposure.world.item.camera;

import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.serverbound.ActiveCameraSetSettingC2SP;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.sound.Sound;
import io.github.mortuusars.exposure.world.sound.SoundEffect;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3419;
import net.minecraft.class_5455;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9331;

public record CameraSetting<T>(class_9331<T> component, T defaultValue, Optional<SoundEffect> sound) {
    public static final Codec<CameraSetting<?>> CODEC = class_2960.field_25139.xmap(CameraSettings::byId, CameraSettings::idOf);
    public static final class_9139<ByteBuf, CameraSetting<?>> STREAM_CODEC = class_9139.method_56434(
            class_2960.field_48267, CameraSettings::idOf,
            CameraSettings::byId
    );

    public CameraSetting(class_9331<T> component, T defaultValue, SoundEffect sound) {
        this(component, defaultValue, Optional.ofNullable(sound));
    }

    public CameraSetting(class_9331<T> component, T defaultValue) {
        this(component, defaultValue, Optional.empty());
    }

    // --

    public @Nullable T get(class_1799 stack) {
        return stack.method_57824(component);
    }

    public Optional<T> getOptional(class_1799 stack) {
        return Optional.ofNullable(get(stack));
    }

    public T getOrDefault(class_1799 stack) {
        return stack.method_57825(component, defaultValue);
    }

    public T getOrElse(class_1799 stack, T defaultValue) {
        return stack.method_57825(component, defaultValue);
    }

    public @Nullable T get(Camera camera) {
        return camera.getItemStack().method_57824(component);
    }

    public Optional<T> getOptional(Camera camera) {
        return Optional.ofNullable(get(camera));
    }

    public T getOrDefault(Camera camera) {
        return camera.getItemStack().method_57825(component, defaultValue);
    }

    public T getOrElse(Camera camera, T defaultValue) {
        return camera.getItemStack().method_57825(component, defaultValue);
    }

    // --

    public boolean set(class_1799 stack, T value) {
        if (stack.method_7960() || getOrDefault(stack).equals(value)) return false;

        if (value instanceof Boolean bool && !bool) {
            stack.method_57381(component);
        } else {
            stack.method_57379(component, value);
        }
        return true;
    }

    public boolean set(CameraHolder holder, class_1799 stack, T value) {
        if (stack.method_7909() instanceof CameraItem cameraItem && set(stack, value)) {
            cameraItem.actionPerformed(stack, holder);
            sound.ifPresent(sound ->
                    Sound.playSided(holder.asEntity(), sound.sound().get(), class_3419.field_15248,
                            sound.volume(), sound.pitch(), sound.pitchVariability()));
            return true;
        }
        return false;
    }

    public boolean set(Camera camera, T value) {
        return camera.map((item, stack) -> set(camera.getHolder(), stack, value)).orElse(false);
    }

    public boolean setAndSync(Camera camera, T value) {
        return camera.map((item, stack) -> {
            if (set(camera.getHolder(), stack, value)) {
                byte[] bytes = encodeValue(camera.getHolder().asEntity().method_56673(), value);
                Packets.sendToServer(new ActiveCameraSetSettingC2SP(this, bytes));
                return true;
            }
            return false;
        }).orElse(false);
    }

    public boolean decodeAndSet(class_1799 stack, class_5455 registryAccess, byte[] bytes) {
        T value = decodeValue(registryAccess, bytes);
        return set(stack, value);
    }

    public boolean decodeAndSet(CameraHolder holder, class_1799 stack, class_5455 registryAccess, byte[] bytes) {
        T value = decodeValue(registryAccess, bytes);
        return set(holder, stack, value);
    }

    // --

    public byte[] encodeValue(class_5455 registryAccess, T value) {
        class_9129 buffer = new class_9129(Unpooled.buffer(), registryAccess);
        try {
            component.method_57878().encode(buffer, value);
            return buffer.array().clone();
        } finally {
            buffer.release();
        }
    }

    public T decodeValue(class_5455 registryAccess, byte[] bytes) {
        class_9129 buffer = new class_9129(Unpooled.buffer(), registryAccess);
        try {
            buffer.method_52983(bytes);
            return component.method_57878().decode(buffer);
        } finally {
            buffer.release();
        }
    }
}
