package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.world.entity.CameraOperator;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 {
    public LivingEntityMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "getMaxHeadRotationRelativeToBody", at = @At("RETURN"), cancellable = true)
    private void getMaxHeadRotation(CallbackInfoReturnable<Float> cir) {
        if (this instanceof CameraOperator operator && operator.getActiveExposureCamera() != null) {
            cir.setReturnValue(Math.min(cir.getReturnValue(), 20));
        }
    }
}
