package io.github.mortuusars.exposure.client.capture.template;

import io.github.mortuusars.exposure.client.image.PalettedImage;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.world.camera.capture.CaptureProperties;
import io.github.mortuusars.exposure.util.cycles.task.Task;
import io.github.mortuusars.exposure.world.level.storage.ExposureData;
import io.github.mortuusars.exposure.util.TranslatableError;
import io.github.mortuusars.exposure.util.UnixTimestamp;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_6880;

public interface CaptureTemplate {
    Task<?> createTask(CaptureProperties captureProperties);

    default Function<PalettedImage, ExposureData> convertToExposureData(class_6880<ColorPalette> palette, ExposureData.Tag tag) {
        class_2960 paletteId = palette.method_40230().orElseThrow().method_29177();
        return image -> new ExposureData(image.width(), image.height(), image.pixels(), paletteId, tag);
    }

    default ExposureData.Tag createExposureTag(class_1657 executingPlayer, CaptureProperties data, boolean isLoaded) {
        return new ExposureData.Tag(data.filmType(), executingPlayer.method_5820(),
                UnixTimestamp.Seconds.now(), isLoaded, false);
    }

    default @NotNull Consumer<TranslatableError> printCasualErrorInChat() {
        return err -> Minecrft.execute(() ->
                Minecrft.player().method_7353(err.casual().method_27692(class_124.field_1061), false));
    }
}
