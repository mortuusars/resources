package io.github.mortuusars.exposure.client.util;

import com.google.gson.JsonSyntaxException;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Exposure;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_2960;

public class Shader {
    /**
     * Processes specified shader (if it is present and active) to a specified render target.
     * Shader is not modified in the process. Copy of the shader is created and resized to the render target dimensions.
     * Since this method creates a temp PostChain on every call, this probably should not be used when performance matters.
     * Main use for this is to apply a shader when capturing a photograph.
     */
    // This is probably wrong class for it, but it'll do for now.
    public static void apply(@NotNull class_279 shader, @NotNull class_276 renderTarget) {
        try {
            class_2960 shaderLocation = class_2960.method_60654(shader.method_1260());

            class_279 tempShader = new class_279(Minecrft.get().method_1531(), Minecrft.get().method_1478(),
                    renderTarget, shaderLocation);
            tempShader.method_1259(renderTarget.field_1482, renderTarget.field_1481);

            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.resetTextureMatrix();
            tempShader.method_1258(Minecrft.get().method_60646().method_60636());
        } catch (IOException e) {
            Exposure.LOGGER.warn("Failed to load shader: {}", shader.method_1260(), e);
        } catch (JsonSyntaxException e) {
            Exposure.LOGGER.warn("Failed to parse shader: {}", shader.method_1260(), e);
        }
    }
}
