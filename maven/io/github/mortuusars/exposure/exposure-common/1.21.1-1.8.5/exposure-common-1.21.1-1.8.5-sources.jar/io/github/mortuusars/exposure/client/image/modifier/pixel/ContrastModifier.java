package io.github.mortuusars.exposure.client.image.modifier.pixel;

import com.google.common.base.Preconditions;
import net.minecraft.class_3532;
import net.minecraft.class_5253;

public class ContrastModifier implements PixelModifier {
    protected final float contrast;

    /**
     * @param contrast 1 means no change.
     */
    public ContrastModifier(float contrast) {
        Preconditions.checkArgument(contrast > 0f, "Contrast should be larger than 0.");
        this.contrast = contrast;
    }

    public ContrastModifier() {
        this(1f);
    }

    @Override
    public String getIdentifier() {
        return "contrast-" + contrast;
    }

    public int modify(int colorARGB) {
        if (contrast == 1f) return colorARGB;

        int alpha = class_5253.class_5254.method_27762(colorARGB);
        int red = class_5253.class_5254.method_27765(colorARGB);
        int green = class_5253.class_5254.method_27766(colorARGB);
        int blue = class_5253.class_5254.method_27767(colorARGB);

        int contrastValue = Math.round(127 * contrast);
        red = class_3532.method_15340((red - 127) * contrastValue / 127 + 127, 0, 255);
        green = class_3532.method_15340((green - 127) * contrastValue / 127 + 127, 0, 255);
        blue = class_3532.method_15340((blue - 127) * contrastValue / 127 + 127, 0, 255);

        return class_5253.class_5254.method_27764(alpha, red, green, blue);
    }

    @Override
    public String toString() {
        return "Contrast{contrast=" + contrast + "}";
    }
}
