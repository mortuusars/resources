package io.github.mortuusars.exposure.world.camera.frame;

import io.github.mortuusars.exposure.util.Fov;
import io.github.mortuusars.exposure.util.PointOfView;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;

public class EntitiesInFrame {
    public static List<class_1309> get(CameraHolder cameraHolder, PointOfView pov, double fov) {
        return get(cameraHolder.asEntity(), pov, fov);
    }

    public static List<class_1309> get(class_1297 cameraHolder, PointOfView pov, double fov) {
        fov *= 0.95; // 5% margin from edge
        double focalLength = Fov.fovToFocalLength(fov);

        class_238 area = new class_238(cameraHolder.method_24515()).method_1014(128);
        List<class_1297> entities = cameraHolder.method_37908().method_8335(null, area);

        FrustumCheck frustum = FrustumCheck.createFromCamera(pov.pos(), pov.dir(), ((float) Math.toRadians(fov)));

        entities.sort((entity, entity2) -> {
            double dist1 = pov.pos().method_1022(entity.method_19538());
            double dist2 = pov.pos().method_1022(entity2.method_19538());
            if (dist1 == dist2) return 0;
            return dist1 > dist2 ? 1 : -1;
        });

        List<class_1309> entitiesInFrame = new ArrayList<>();

        for (class_1297 entity : entities) {
            if (!(entity instanceof class_1309 livingEntity)) continue;
            if (!livingEntity.method_5805()) continue;
            if (!frustum.contains(entity.method_33571())) continue; // Not in frame
            if (calculateVisibleDistance(pov.pos(), entity) > focalLength) continue; // Too far to be in frame
            if (!hasLineOfSight(pov.pos(), entity)) continue; // Not visible

            entitiesInFrame.add(livingEntity);
        }

        return entitiesInFrame;
    }

    /**
     * Gets the distance in blocks to the target entity.
     */
    public static double calculateVisibleDistance(class_243 cameraPos, class_1297 entity) {
        double distanceInBlocks = Math.sqrt(entity.method_5707(cameraPos));

        class_238 boundingBox = entity.method_5830();
        double size = boundingBox.method_995();
        if (Double.isNaN(size) || size == 0.0)
            size = 0.1;

        double sizeInfluence = (size - 1.0) * 0.6 + 1.0;
        // Makes distance longer, so entity would need to be closer to be "in frame". Very sophisticated math right here.
        double feelsRightInfluence = 1.15;
        return (distanceInBlocks / sizeInfluence) * feelsRightInfluence;
    }

    /**
     * Adaptation of {@link class_1309#method_6057(class_1297)} but using custom camera position instead of an entity.
     */
    public static boolean hasLineOfSight(class_243 cameraPos, class_1297 entity) {
        return entity.method_37908().method_17742(new class_3959(cameraPos, entity.method_33571(),
                class_3959.class_3960.field_17558, class_3959.class_242.field_1348, entity)).method_17783() == class_239.class_240.field_1333;
    }

    /**
     * ChatGPT did a good job with this one.
     */
    public static class FrustumCheck {
        private final class_243 cameraPos;
        private final class_243 forward;
        private final class_243 right;
        private final class_243 up;
        private final float fovRadians;

        public FrustumCheck(class_243 cameraPos, class_243 forward, class_243 right, class_243 up, float fovRadians) {
            this.cameraPos = cameraPos;
            this.forward = forward.method_1029();
            this.right = right.method_1029();
            this.up = up.method_1029();
            this.fovRadians = fovRadians;
        }

        public boolean contains(class_243 pos) {
            // Calculate relative position
            class_243 toEntity = pos.method_1020(cameraPos);

            // Dot product with forward vector for depth
            double depth = toEntity.method_1026(forward);
            if (depth <= 0) {
                // Entity is behind the camera
                return false;
            }

            // Dot product with right and up vectors
            double horizontalOffset = toEntity.method_1026(right);
            double verticalOffset = toEntity.method_1026(up);

            double halfSize = depth * Math.tan(fovRadians / 2);

            // Check if the entity is within the frustum bounds
            return Math.abs(horizontalOffset) <= halfSize && Math.abs(verticalOffset) <= halfSize;
        }

        public static FrustumCheck createFromCamera(class_243 cameraPos, class_243 lookVec, float fov) {
            // Create forward vector (normalized)
            class_243 forward = lookVec.method_1029();

            // Create up vector (assume Y-up world). You may replace this with actual camera up vector if available.
            class_243 worldUp = new class_243(0, 1, 0);

            // Calculate right and adjusted up vectors
            class_243 right = forward.method_1036(worldUp).method_1029();
            class_243 up = right.method_1036(forward).method_1029();

            return new FrustumCheck(cameraPos, forward, right, up, fov);
        }
    }
}