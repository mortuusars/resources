package io.github.mortuusars.exposure.world.camera.capture;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.util.ExtraData;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.world.camera.ColorChannel;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.component.ShutterSpeed;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.core.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Consumer;

public record CaptureProperties(String exposureId,
                                ExposureType filmType,
                                Optional<class_6880<ColorPalette>> colorPalette,
                                Optional<Integer> frameSize,
                                float cropFactor,
                                Optional<ShutterSpeed> shutterSpeed,
                                Optional<Float> fovOverride,
                                boolean flash,
                                Optional<ProjectionInfo> projection,
                                Optional<ColorChannel> singleChannel,
                                Optional<Integer> cameraHolderEntityId,
                                Optional<CameraId> cameraId,
                                ExtraData extraData) {

    public static final ExtraData.Entry<Integer> LIGHT_LEVEL = new ExtraData.Entry<>("light_level", ExtraData::method_10550, ExtraData::method_10569);

    // --

    public static final Codec<CaptureProperties> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("id").forGetter(CaptureProperties::exposureId),
            ExposureType.CODEC.optionalFieldOf("film_type", ExposureType.COLOR).forGetter(CaptureProperties::filmType),
            ColorPalette.HOLDER_CODEC.optionalFieldOf("color_palette").forGetter(CaptureProperties::colorPalette),
            Codec.INT.optionalFieldOf("frame_size").forGetter(CaptureProperties::frameSize),
            Codec.FLOAT.optionalFieldOf("crop_factor", 1f).forGetter(CaptureProperties::cropFactor),
            ShutterSpeed.CODEC.optionalFieldOf("shutter_speed").forGetter(CaptureProperties::shutterSpeed),
            Codec.FLOAT.optionalFieldOf("fov_override").forGetter(CaptureProperties::fovOverride),
            Codec.BOOL.optionalFieldOf("flash", false).forGetter(CaptureProperties::flash),
            ProjectionInfo.CODEC.optionalFieldOf("projection").forGetter(CaptureProperties::projection),
            ColorChannel.CODEC.optionalFieldOf("single_channel").forGetter(CaptureProperties::singleChannel),
            Codec.INT.optionalFieldOf("camera_holder_id").forGetter(CaptureProperties::cameraHolderEntityId),
            CameraId.CODEC.optionalFieldOf("camera_id").forGetter(CaptureProperties::cameraId),
            ExtraData.field_25128.optionalFieldOf("extra_data", new ExtraData()).forGetter(CaptureProperties::extraData)
    ).apply(instance, CaptureProperties::new));

    public static final class_9139<class_9129, CaptureProperties> STREAM_CODEC = new class_9139<>() {
        public @NotNull CaptureProperties decode(class_9129 buffer) {
            return new CaptureProperties(
                    class_9135.field_48554.decode(buffer),
                    ExposureType.STREAM_CODEC.decode(buffer),
                    class_9135.method_56382(ColorPalette.STREAM_CODEC).decode(buffer),
                    class_9135.method_56382(class_9135.field_48550).decode(buffer),
                    class_9135.field_48552.decode(buffer),
                    class_9135.method_56382(ShutterSpeed.STREAM_CODEC).decode(buffer),
                    class_9135.method_56382(class_9135.field_48552).decode(buffer),
                    class_9135.field_48547.decode(buffer),
                    class_9135.method_56382(ProjectionInfo.STREAM_CODEC).decode(buffer),
                    class_9135.method_56382(ColorChannel.STREAM_CODEC).decode(buffer),
                    class_9135.method_56382(class_9135.field_48550).decode(buffer),
                    class_9135.method_56382(CameraId.STREAM_CODEC).decode(buffer),
                    ExtraData.STREAM_CODEC.decode(buffer));
        }

        public void encode(class_9129 buffer, CaptureProperties data) {
            class_9135.field_48554.encode(buffer, data.exposureId());
            ExposureType.STREAM_CODEC.encode(buffer, data.filmType());
            class_9135.method_56382(ColorPalette.STREAM_CODEC).encode(buffer, data.colorPalette());
            class_9135.method_56382(class_9135.field_48550).encode(buffer, data.frameSize());
            class_9135.field_48552.encode(buffer, data.cropFactor());
            class_9135.method_56382(ShutterSpeed.STREAM_CODEC).encode(buffer, data.shutterSpeed());
            class_9135.method_56382(class_9135.field_48552).encode(buffer, data.fovOverride());
            class_9135.field_48547.encode(buffer, data.flash());
            class_9135.method_56382(ProjectionInfo.STREAM_CODEC).encode(buffer, data.projection());
            class_9135.method_56382(ColorChannel.STREAM_CODEC).encode(buffer, data.singleChannel());
            class_9135.method_56382(class_9135.field_48550).encode(buffer, data.cameraHolderEntityId());
            class_9135.method_56382(CameraId.STREAM_CODEC).encode(buffer, data.cameraId());
            ExtraData.STREAM_CODEC.encode(buffer, data.extraData());
        }
    };

    public ShutterSpeed getShutterSpeed() {
        return shutterSpeed.orElse(ShutterSpeed.DEFAULT);
    }

    public class_6880<ColorPalette> getColorPalette(class_5455 access) {
        return colorPalette.orElse(ColorPalettes.getDefault(access));
    }

    public static final class Builder {
        private final String exposureId;

        private ExposureType filmType = ExposureType.COLOR;
        private @Nullable class_6880<ColorPalette> colorPalette = null;
        private @Nullable Integer frameSize = null;
        private float cropFactor = 1f;
        private @Nullable ShutterSpeed shutterSpeed = null;
        private @Nullable Float fovOverride = null;
        private boolean flash = false;
        private @Nullable ProjectionInfo projectionInfo;
        private @Nullable ColorChannel chromaticChannel;
        private @Nullable Integer cameraHolderEntityID = null;
        private @Nullable CameraId cameraId = null;
        private final ExtraData extraData = new ExtraData();

        public Builder(String exposureId) {
            this.exposureId = exposureId;
        }

        public Builder setFilmType(@Nullable ExposureType filmType) {
            this.filmType = filmType;
            return this;
        }

        public Builder setColorPalette(@Nullable class_6880<ColorPalette> colorPalette) {
            this.colorPalette = colorPalette;
            return this;
        }

        public Builder setFrameSize(@Nullable Integer frameSize) {
            this.frameSize = frameSize;
            return this;
        }

        public Builder setCropFactor(float cropFactor) {
            this.cropFactor = cropFactor;
            return this;
        }

        public Builder setShutterSpeed(@Nullable ShutterSpeed shutterSpeed) {
            this.shutterSpeed = shutterSpeed;
            return this;
        }

        public Builder setFovOverride(@Nullable Float fovOverride) {
            this.fovOverride = fovOverride;
            return this;
        }

        public Builder setFlash(boolean flash) {
            this.flash = flash;
            return this;
        }

        public Builder setCameraHolder(@Nullable CameraHolder holder) {
            if (holder == null) cameraHolderEntityID = null;
            else cameraHolderEntityID = holder.asEntity().method_5628();
            return this;
        }

        public Builder setCameraID(@Nullable CameraId cameraId) {
            this.cameraId = cameraId;
            return this;
        }

        public Builder setCameraID(Optional<CameraId> cameraId) {
            this.cameraId = cameraId.orElse(null);
            return this;
        }

        public Builder setProjectionInfo(@Nullable ProjectionInfo projectionInfo) {
            this.projectionInfo = projectionInfo;
            return this;
        }

        public Builder setProjectingInfo(Optional<ProjectionInfo> projectingInfo) {
            this.projectionInfo = projectingInfo.orElse(null);
            return this;
        }

        public Builder setChromaticChannel(@Nullable ColorChannel chromaticChannel) {
            this.chromaticChannel = chromaticChannel;
            return this;
        }

        public Builder setChromaticChannel(Optional<ColorChannel> chromaticChannel) {
            this.chromaticChannel = chromaticChannel.orElse(null);
            return this;
        }

        public Builder extraData(Consumer<ExtraData> extraDataUpdater) {
            extraDataUpdater.accept(extraData);
            return this;
        }

        public CaptureProperties build() {
            return new CaptureProperties(exposureId,
                    this.filmType,
                    Optional.ofNullable(this.colorPalette),
                    Optional.ofNullable(this.frameSize),
                    this.cropFactor,
                    Optional.ofNullable(this.shutterSpeed),
                    Optional.ofNullable(this.fovOverride),
                    this.flash,
                    Optional.ofNullable(this.projectionInfo),
                    Optional.ofNullable(this.chromaticChannel),
                    Optional.ofNullable(this.cameraHolderEntityID),
                    Optional.ofNullable(this.cameraId),
                    this.extraData);
        }
    }
}
