package io.github.mortuusars.exposure.client.capture.action;

import io.github.mortuusars.exposure.client.util.Minecrft;
import net.minecraft.class_1297;

public class SetCameraEntityAction implements CaptureAction {
    private final class_1297 cameraEntity;
    private class_1297 cameraEntityBeforeCapture;

    public SetCameraEntityAction(class_1297 cameraEntity) {
        this.cameraEntity = cameraEntity;
        this.cameraEntityBeforeCapture = Minecrft.player();
    }

    @Override
    public void beforeCapture() {
        cameraEntityBeforeCapture = Minecrft.get().method_1560();
        // Not using Minecraft#setCameraEntity because it updates postEffect.
        Minecrft.get().field_1719 = cameraEntity;
    }

    @Override
    public void afterCapture() {
        Minecrft.get().field_1719 = cameraEntityBeforeCapture;
    }
}
