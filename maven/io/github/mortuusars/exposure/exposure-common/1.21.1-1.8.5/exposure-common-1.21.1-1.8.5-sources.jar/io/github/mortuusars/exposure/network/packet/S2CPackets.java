package io.github.mortuusars.exposure.network.packet;

import io.github.mortuusars.exposure.network.packet.clientbound.*;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class S2CPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
                new class_8710.class_9155<>(ActiveCameraRemoveS2CP.TYPE, ActiveCameraRemoveS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(ActiveCameraInHandSetS2CP.TYPE, ActiveCameraInHandSetS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(ShaderApplyS2CP.TYPE, ShaderApplyS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(ClearRenderingCacheS2CP.TYPE, ClearRenderingCacheS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(CreateChromaticExposureS2CP.TYPE, CreateChromaticExposureS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(ExposureDataChangedS2CP.TYPE, ExposureDataChangedS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(UniqueSoundPlayS2CP.TYPE, UniqueSoundPlayS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(UniqueSoundPlayShutterTickingS2CP.TYPE, UniqueSoundPlayShutterTickingS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(UniqueSoundStopS2CP.TYPE, UniqueSoundStopS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(ShowExposureCommandS2CP.TYPE, ShowExposureCommandS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(ExposureDataResponseS2CP.TYPE, ExposureDataResponseS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(ShutterOpenedS2CP.TYPE, ShutterOpenedS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(CaptureStartS2CP.TYPE, CaptureStartS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(CaptureStartDebugRGBS2CP.TYPE, CaptureStartDebugRGBS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(ExportS2CP.TYPE, ExportS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(ExportStopS2CP.TYPE, ExportStopS2CP.STREAM_CODEC)
        );
    }
}
