package io.github.mortuusars.exposure.mixin.client;

import com.mojang.authlib.GameProfile;
import io.github.mortuusars.exposure.client.camera.CameraClient;
import io.github.mortuusars.exposure.world.camera.Camera;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings("AddedMixinMembersNamePattern")
@Mixin(class_746.class)
public abstract class LocalPlayerMixin extends class_1657 {
    public LocalPlayerMixin(class_1937 level, class_2338 pos, float yRot, GameProfile gameProfile) {
        super(level, pos, yRot, gameProfile);
    }

    @Override
    public void setActiveExposureCamera(Camera camera) {
        super.setActiveExposureCamera(camera);
        CameraClient.setupViewfinder(camera);
    }

    @Override
    public void removeActiveExposureCamera() {
        super.removeActiveExposureCamera();
        CameraClient.removeViewfinder();
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void onTick(CallbackInfo ci) {
        CameraClient.tick();

        getActiveExposureCameraOptional().ifPresent(camera -> {
            if (!camera.isActive()) {
                removeActiveExposureCamera();
            }
        });
    }
}
