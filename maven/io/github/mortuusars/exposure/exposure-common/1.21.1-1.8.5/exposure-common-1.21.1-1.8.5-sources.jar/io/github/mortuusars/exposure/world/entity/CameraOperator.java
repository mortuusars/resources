package io.github.mortuusars.exposure.world.entity;

import io.github.mortuusars.exposure.world.camera.Camera;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1309;

/**
 * Injected in Entities such as {@link net.minecraft.class_1657}. <br>
 * Injected interfaces must have all methods as 'default'.
 */
public interface CameraOperator {
    default @Nullable Camera getActiveExposureCamera() {
        throw new IllegalStateException("This method must be implemented.");
    }

    default void setActiveExposureCamera(Camera camera) {
        throw new IllegalStateException("This method must be implemented.");
    }

    default void removeActiveExposureCamera() {
        throw new IllegalStateException("This method must be implemented.");
    }

    // --

    default Optional<Camera> getActiveExposureCameraOptional() {
        return Optional.ofNullable(getActiveExposureCamera());
    }

    default float getExposureCameraActionAnim(float partialTick) {
        return 0F;
    }

    default class_1309 toEntity() {
        return (class_1309) this;
    }
}
