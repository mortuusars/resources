package io.github.mortuusars.exposure.advancements.trigger;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.advancements.predicate.CameraPredicate;
import io.github.mortuusars.exposure.advancements.predicate.FramePredicate;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2048;
import net.minecraft.class_2090;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;

public class FrameExposedTrigger extends class_4558<FrameExposedTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player,
                        CameraHolder cameraHolder,
                        class_1799 cameraStack,
                        Frame frame,
                        List<class_2338> locationsInFrame,
                        List<class_1309> entitiesInFrame) {
        this.method_22510(player, triggerInstance ->
                triggerInstance.matches(player, cameraHolder, cameraStack, frame, locationsInFrame, entitiesInFrame));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  Optional<CameraPredicate> camera,
                                  Optional<FramePredicate> frame,
                                  Optional<class_2090> locationInFrame,
                                  Optional<class_2048> entityInFrame) implements class_4558.class_8788 {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                        class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::comp_2029),
                        CameraPredicate.CODEC.optionalFieldOf("camera").forGetter(TriggerInstance::camera),
                        FramePredicate.field_49805.optionalFieldOf("frame").forGetter(TriggerInstance::frame),
                        class_2090.field_45760.optionalFieldOf("location_in_frame").forGetter(TriggerInstance::locationInFrame),
                        class_2048.field_45746.optionalFieldOf("entity_in_frame").forGetter(TriggerInstance::entityInFrame))
                .apply(instance, TriggerInstance::new));

        public boolean matches(class_3222 player,
                               CameraHolder cameraHolder,
                               class_1799 cameraStack,
                               Frame frame,
                               List<class_2338> locationsInFrame,
                               List<class_1309> entitiesInFrame) {
            class_1297 holder = cameraHolder.asEntity();

            return (camera.isEmpty() || camera.get().matches(player.method_51469(), cameraStack, holder.method_19538()))
                    && (this.frame.isEmpty() || this.frame.get().matches(frame))
                    && (locationInFrame.isEmpty() || locationsInFrame.stream().anyMatch(pos ->
                        locationInFrame.get().method_9018(player.method_51469(), pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5)))
                    && (entityInFrame.isEmpty() || entitiesInFrame.stream().anyMatch(entity ->
                        entityInFrame.get().method_8909(player.method_51469(), holder.method_19538(), entity)));
        }
    }
}