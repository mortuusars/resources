package io.github.mortuusars.exposure;

import dev.architectury.injectables.annotations.ExpectPlatform;
import io.github.mortuusars.exposure.util.ExtraData;
import io.github.mortuusars.exposure.world.camera.capture.CaptureProperties;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_9129;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;

public class PlatformHelper {
    @ExpectPlatform
    public static @Nullable MinecraftServer getServer() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean canShear(class_1799 stack) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean canStrip(class_1799 stack) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_9129> extraDataWriter) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static List<String> getDefaultSpoutDevelopmentColorSequence() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static List<String> getDefaultSpoutDevelopmentBWSequence() {
        throw new AssertionError();
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    @ExpectPlatform
    public static boolean isModLoaded(String modId) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isInDevEnv() {
        throw new AssertionError();
    }

    // --

    @ExpectPlatform
    public static void postModifyEntityInFrameExtraDataEvent(CameraHolder cameraHolder, class_1799 camera, class_1309 entityInFrame, ExtraData data) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void postModifyFrameExtraDataEvent(CameraHolder cameraHolder, class_1799 camera, CaptureProperties captureProperties,
                                                     List<class_2338> positionsInFrame, List<class_1309> entitiesInFrame, ExtraData data) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void postFrameAddedEvent(CameraHolder holder, class_1799 camera, Frame frame,
                                           List<class_2338> positionsInFrame, List<class_1309> entitiesInFrame) {
        throw new AssertionError();
    }
}
