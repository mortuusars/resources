package io.github.mortuusars.exposure.world.sound;

import io.github.mortuusars.exposure.client.sound.UniqueSoundManager;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.clientbound.UniqueSoundPlayShutterTickingS2CP;
import io.github.mortuusars.exposure.network.packet.clientbound.UniqueSoundPlayS2CP;
import io.github.mortuusars.exposure.world.camera.CameraId;
import org.jetbrains.annotations.Nullable;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;

public class Sound {
    public static void play(class_1937 level, double x, double y, double z, class_3414 sound, class_3419 source) {
        play(level, x, y, z, sound ,source, 1F, 1F, 0F);
    }

    public static void play(class_1937 level, double x, double y, double z, class_3414 sound, class_3419 source, float volume, float pitch) {
        play(level, x, y, z, sound ,source, volume, pitch, 0F);
    }

    public static void play(class_1937 level, double x, double y, double z, class_3414 sound, class_3419 source, float volume, float pitch, float pitchVariability) {
        pitch = vary(pitch, pitchVariability);
        level.method_43128(null, x, y, z, sound, source, volume, pitch);
    }

    public static void play(class_1297 entity, class_3414 sound) {
        play(entity, sound, entity.method_5634(), 1F, 1F, 0F);
    }

    public static void play(class_1297 entity, class_3414 sound, class_3419 source) {
        play(entity, sound, source, 1F, 1F, 0F);
    }

    public static void play(class_1297 entity, class_3414 sound, class_3419 source, float volume, float pitch) {
        play(entity, sound, source, volume, pitch, 0F);
    }

    public static void play(class_1297 entity, class_3414 sound, class_3419 source, float volume, float pitch, float pitchVariability) {
        pitch = vary(pitch, pitchVariability);
        entity.method_37908().method_43129(null, entity, sound, source, volume, pitch);
    }

    // --

    public static void playSided(class_1657 player, double x, double y, double z, class_3414 sound, class_3419 source) {
        playSided(player, x, y, z, sound, source, 1F, 1F, 0F);
    }

    public static void playSided(class_1657 player, double x, double y, double z, class_3414 sound, class_3419 source, float volume, float pitch) {
        playSided(player, x, y, z, sound, source, volume, pitch, 0F);
    }

    public static void playSided(class_1657 player, double x, double y, double z, class_3414 sound, class_3419 source, float volume, float pitch, float pitchVariability) {
        pitch = vary(pitch, pitchVariability);
        player.method_37908().method_43128(player, x, y, z, sound, source, volume, pitch);
    }

//    public static void playSided(Player player, Entity entity, SoundEvent sound) {
//        playSided(player, entity, sound, entity.getSoundSource(), 1F, 1F, 0F);
//    }
//
//    public static void playSided(Player player, Entity entity, SoundEvent sound, SoundSource source) {
//        playSided(player, entity, sound, source, 1F, 1F, 0F);
//    }
//
//    public static void playSided(Player player, Entity entity, SoundEvent sound, SoundSource source, float volume, float pitch) {
//        playSided(player, entity, sound, source, volume, pitch, 0F);
//    }
//
//    public static void playSided(Player player, Entity entity, SoundEvent sound, SoundSource source, float volume, float pitch, float pitchVariability) {
//        pitch = vary(pitch, pitchVariability);
//        player.level().playSound(player, entity, sound, source, volume, pitch);
//    }

    public static void playSided(class_1297 entity, SoundEffect sound) {
        playSided(entity, sound.get(), entity.method_5634(), sound.volume(), sound.pitch(), sound.pitchVariability());
    }

    public static void playSided(class_1297 entity, class_3414 sound) {
        playSided(entity, sound, entity.method_5634());
    }

    public static void playSided(class_1297 entity, class_3414 sound, class_3419 source) {
        playSided(entity, sound, source, 1F, 1F);
    }

    public static void playSided(class_1297 entity, class_3414 sound, class_3419 source, float volume, float pitch) {
        playSided(entity, sound, source, volume, pitch, 0F);
    }

    public static void playSided(class_1297 entity, class_3414 sound, class_3419 source, float volume, float pitch, float pitchVariability) {
        pitch = vary(pitch, pitchVariability);
        @Nullable class_1657 player = entity instanceof class_1657 ? ((class_1657) entity) : null;
        entity.method_37908().method_43129(player, entity, sound, source, volume, pitch);
    }

    // --

    public static void playUnique(String id, class_1297 entity, SoundEffect sound, class_3419 source) {
        playUnique(id, entity, sound.get(), source, sound.volume(), sound.pitch(), sound.pitchVariability());
    }

    public static void playUnique(String id, class_1297 entity, class_3414 sound, class_3419 source) {
        playUnique(id, entity, sound, source, 1F, 1F, 0F);
    }

    public static void playUnique(String id, class_1297 entity, class_3414 sound, class_3419 source, float volume, float pitch) {
        playUnique(id, entity, sound, source, volume, pitch, 0F);
    }

    public static void playUnique(String id, class_1297 entity, class_3414 sound, class_3419 source,
                                  float volume, float pitch, float pitchVariability) {
        pitch = vary(pitch, pitchVariability);
        if (entity.method_37908() instanceof class_3218 serverLevel) {
            UniqueSoundPlayS2CP packet = new UniqueSoundPlayS2CP(id, entity.method_5628(), sound, source, volume, pitch);
            Packets.sendToPlayersNear(packet, serverLevel, null, entity, sound.method_43044(1f) * 4);
        }
    }

    public static void playUniqueSided(String id, class_1657 player, class_1297 entity, SoundEffect sound, class_3419 source) {
        playUniqueSided(id, player, entity, sound.get(), source, sound.volume(), sound.pitch(), sound.pitchVariability());
    }

    public static void playUniqueSided(String id, class_1657 player, class_1297 entity, class_3414 sound, class_3419 source,
                                       float volume, float pitch, float pitchVariability) {
        pitch = vary(pitch, pitchVariability);
        if (player.method_37908() instanceof class_3218 serverLevel) {
            UniqueSoundPlayS2CP packet = new UniqueSoundPlayS2CP(id, entity.method_5628(), sound, source, volume, pitch);
            Packets.sendToPlayersNear(packet, serverLevel, ((class_3222) player), entity, sound.method_43044(1f) * 4);
        } else if (player.method_37908().method_8608()) {
            UniqueSoundManager.play(id, entity, sound, source, volume, pitch);
        }
    }

    private static float vary(float value, float variability) {
        return value - (variability / 2) + ThreadLocalRandom.current().nextFloat() * variability;
    }

    public static void playShutterTicking(class_1297 entity, CameraId cameraId, int duration) {
        if (!entity.method_37908().method_8608()) {
            Packets.sendToAllClients(new UniqueSoundPlayShutterTickingS2CP(entity.method_5628(), cameraId, 1F, 1F, duration));
        }
    }
}
