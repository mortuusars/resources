package io.github.mortuusars.exposure.advancements.predicate;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2096;
import net.minecraft.class_9331;
import net.minecraft.class_9365;

public record FramePredicate(Optional<ExposureIdentifier> identifier,
                             Optional<String> type,
                             Optional<String> photographer,
                             Optional<ShutterSpeedPredicate> shutterSpeed,
                             Optional<class_2096.class_2100> focalLength,
                             Optional<class_2096.class_2100> lightLevel,
                             Optional<class_2096.class_2100> dayTime,
                             Optional<class_2096.class_2100> entitiesInFrameCount,
                             Optional<EntityInFramePredicate> entityInFrame,
                             Optional<ExtraDataPredicate> extraData) implements class_9365<Frame> {
    public static final Codec<FramePredicate> field_49805 = RecordCodecBuilder.create(instance -> instance.group(
            ExposureIdentifier.CODEC.optionalFieldOf("identifier").forGetter(FramePredicate::identifier),
            Codec.STRING.optionalFieldOf("type").forGetter(FramePredicate::type),
            Codec.STRING.optionalFieldOf("photographer").forGetter(FramePredicate::photographer),
            ShutterSpeedPredicate.CODEC.optionalFieldOf("shutter_speed").forGetter(FramePredicate::shutterSpeed),
            class_2096.class_2100.field_45763.optionalFieldOf("focal_length").forGetter(FramePredicate::focalLength),
            class_2096.class_2100.field_45763.optionalFieldOf("light_level").forGetter(FramePredicate::lightLevel),
            class_2096.class_2100.field_45763.optionalFieldOf("day_time").forGetter(FramePredicate::dayTime),
            class_2096.class_2100.field_45763.optionalFieldOf("entities_in_frame_count").forGetter(FramePredicate::entitiesInFrameCount),
            EntityInFramePredicate.CODEC.optionalFieldOf("entity_in_frame").forGetter(FramePredicate::entityInFrame),
            ExtraDataPredicate.CODEC.optionalFieldOf("extra_data").forGetter(FramePredicate::extraData)
    ).apply(instance, FramePredicate::new));

    @Override
    public @NotNull class_9331<Frame> method_58163() {
        return Exposure.DataComponents.PHOTOGRAPH_FRAME;
    }

    @Override
    public boolean matches(class_1799 stack, Frame frame) {
        return matches(frame);
    }

    public boolean matches(Frame frame) {
        return (identifier.isEmpty() || identifier.get().equals(frame.identifier()))
                && (type.isEmpty() || type.get().equals(frame.type().method_15434()))
                && (photographer.isEmpty() || photographer.get().equals(frame.photographer().name()))
                && (shutterSpeed.isEmpty() || shutterSpeed.get().matches(frame.extraData().get(Frame.SHUTTER_SPEED)))
                && (focalLength.isEmpty() || frame.extraData().get(Frame.FOCAL_LENGTH).map(focalLength.get()::method_9054).orElse(false))
                && (lightLevel.isEmpty() || frame.extraData().get(Frame.LIGHT_LEVEL).map(lightLevel.get()::method_9054).orElse(false))
                && (dayTime.isEmpty() || frame.extraData().get(Frame.DAY_TIME).map(dayTime.get()::method_9054).orElse(false))
                && (entitiesInFrameCount.isEmpty() || entitiesInFrameCount.get().method_9054(frame.entitiesInFrame().size()))
                && (entityInFrame.isEmpty() || entityInFrame.get().matches(frame.entitiesInFrame()))
                && (extraData.isEmpty() || extraData.get().matches(frame.extraData()));
    }
}
