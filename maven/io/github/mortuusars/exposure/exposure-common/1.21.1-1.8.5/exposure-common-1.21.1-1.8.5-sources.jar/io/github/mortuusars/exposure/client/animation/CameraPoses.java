package io.github.mortuusars.exposure.client.animation;

import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.entity.CameraOperator;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_5498;
import net.minecraft.class_572;
import net.minecraft.class_630;

public class CameraPoses {
    public void applyHolding(class_572<?> model, class_1309 entity, class_1306 arm) {
        float actionProgress = getCameraActionAnim(entity);
        actionProgress = (float)EasingFunction.EASE_OUT_CUBIC.ease(actionProgress);
        float actionAnim =  actionProgress > 0.3F ? (1F - actionProgress) : actionProgress;

        boolean rightHanded = arm == class_1306.field_6183;

        class_630 mainHand = rightHanded ? model.field_3401 : model.field_27433;
        class_630 offHand = rightHanded ? model.field_27433 : model.field_3401;

        model.field_3398.field_3654 += 0.4f; // Applying part of head rotation. If we turn head down completely - arms will be too low.
        model.field_3398.field_3654 = Math.clamp(model.field_3398.field_3654, -1F, 1.15F); // Look up/down limit

        mainHand.field_3675 = (rightHanded ? -0.3F : 0.3F) + model.field_3398.field_3675;
        offHand.field_3675 = (rightHanded ? 0.5F : -0.5F) + model.field_3398.field_3675;
        mainHand.field_3654 = model.field_3398.field_3654 - 1.5F;
        offHand.field_3654 = model.field_3398.field_3654 - 1.5F;
        offHand.field_3654 += (actionAnim * 0.1F) * (rightHanded ? 1 : -1);
        offHand.field_3675 += (actionAnim * 0.1F) * (rightHanded ? 1 : -1);
        model.field_3398.field_3654 += 0.3f; // Applying rest of head rotation after arms

        model.field_3394.method_17138(model.field_3398);
    }

    public void applySelfie(class_572<?> model, class_1309 entity, class_1306 arm, boolean undoArmBobbing) {
        class_630 cameraArm = arm == class_1306.field_6183 ? model.field_3401 : model.field_27433;

        // Arm follows camera:
        cameraArm.field_3654 = (model.field_3398.field_3654 + Math.abs(model.field_3398.field_3654 * 0.13f)) + (-(float) Math.PI / 2F);
        cameraArm.field_3675 = model.field_3398.field_3675 + (arm == class_1306.field_6183 ? -0.25f : 0.25f);
        if (model.field_3398.field_3654 <= 0) {
            cameraArm.field_3674 = (model.field_3398.field_3654 * 0.15f) * (arm == class_1306.field_6183 ? -1 : 1);
        } else {
            cameraArm.field_3674 = (model.field_3398.field_3654 * 0.22f) * (arm == class_1306.field_6183 ? -1 : 1);
        }
    }

    public void applyDisassembled(class_572<?> model, class_1309 entity, class_1306 arm) {
        if (Minecrft.player().equals(entity) && Minecrft.options().method_31044() == class_5498.field_26664) {
            return;
        }

        float actionProgress = getCameraActionAnim(entity);
        actionProgress = (float)EasingFunction.EASE_OUT_CUBIC.ease(actionProgress);
        float actionAnim =  actionProgress > 0.3F ? (1F - actionProgress) : actionProgress;

        model.field_3398.field_3654 += 0.4f; // Applying part of head rotation. If we turn head down completely - arms will be too low.
        model.field_3398.field_3654 = Math.clamp(model.field_3398.field_3654, -0.75F, 0.75F); // Look up/down limit

        boolean rightHanded = arm == class_1306.field_6183;

        class_630 mainHand = rightHanded ? model.field_3401 : model.field_27433;
        class_630 offHand = rightHanded ? model.field_27433 : model.field_3401;
        mainHand.field_3675 = (rightHanded ? -0.6F : 0.6F) + model.field_3398.field_3675;
        offHand.field_3675 = (rightHanded ? 0.6F : -0.6F) + model.field_3398.field_3675;
        mainHand.field_3654 = model.field_3398.field_3654 - 1.5F;
        offHand.field_3654 = model.field_3398.field_3654 - 1.5F;
        offHand.field_3654 += (actionAnim * 0.1F) * (rightHanded ? 1 : -1);
        offHand.field_3675 += (actionAnim * 0.1F) * (rightHanded ? 1 : -1);
        model.field_3398.field_3654 += 0.3f; // Applying rest of head rotation after arms

        model.field_3394.method_17138(model.field_3398);
    }

    public float getCameraActionAnim(class_1309 entity) {
        if (entity instanceof CameraOperator operator) {
            float partialTick = Minecrft.get().method_60646().method_60637(true);
            return operator.getExposureCameraActionAnim(partialTick);
        }
        return 0F;
    }
}