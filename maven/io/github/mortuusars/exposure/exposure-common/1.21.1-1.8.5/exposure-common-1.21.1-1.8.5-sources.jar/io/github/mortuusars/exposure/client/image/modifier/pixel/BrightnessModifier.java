package io.github.mortuusars.exposure.client.image.modifier.pixel;

import io.github.mortuusars.exposure.world.camera.component.ShutterSpeed;
import net.minecraft.class_3532;
import net.minecraft.class_5253;

public class BrightnessModifier implements PixelModifier {
    protected final float brightness;

    /**
     * @param brightness 1 means no change.
     */
    public BrightnessModifier(float brightness) {
        this.brightness = brightness;
    }

    public BrightnessModifier(float brightnessStops, float brightnessPerStop) {
        this(1f + brightnessStops * brightnessPerStop);
    }

    public BrightnessModifier(ShutterSpeed shutterSpeed) {
        this(shutterSpeed.getStops(), 0.2f);
    }

    @Override
    public String getIdentifier() {
        return "brightness-" + brightness;
    }

    public int modify(int colorARGB) {
        if (brightness == 1f) return colorARGB;

        int alpha = class_5253.class_5254.method_27762(colorARGB);
        int red = class_5253.class_5254.method_27765(colorARGB);
        int green = class_5253.class_5254.method_27766(colorARGB);
        int blue = class_5253.class_5254.method_27767(colorARGB);

        // We simulate bright light by not modifying all pixels equally
        float lightness = (blue + green + red) / 765f; // from 0.0 to 1.0
        float bias;
        if (brightness < 1)
            bias = (1f - lightness) * 0.8f + 0.2f;
        else {
            float curve = (float) Math.pow(Math.sin(lightness * Math.PI), 2);
            bias = lightness > 0.5f ? curve * 0.8f + 0.2f : curve * 0.5f + 0.5f;
        }

        float b = class_3532.method_16439(bias, blue, blue * brightness);
        float g = class_3532.method_16439(bias, green, green * brightness);
        float r = class_3532.method_16439(bias, red, red * brightness);

        // Above values are not clamped at 255 purposely.
        // Excess is redistributed to other channels. As a result - color gets less saturated, which gives more natural color.
        int[] rdst = redistribute(r, g, b);

        // BUT it does not look perfect (IDK, maybe because of dithering), so we blend them together.
        // This makes transitions smoother, subtler. Which looks good imo.
        return class_5253.class_5254.method_27764(alpha,
                class_3532.method_15340(class_3532.method_48781(0.5f, (int)r, rdst[0]), 0, 255),
                class_3532.method_15340(class_3532.method_48781(0.5f, (int)g, rdst[1]), 0, 255),
                class_3532.method_15340(class_3532.method_48781(0.5f, (int)b, rdst[2]), 0, 255));
    }

    /**
     * Redistributes excess (> 255) values to other channels.
     * Adapted from Mark Ransom's answer:
     * <a href="https://stackoverflow.com/a/141943">StackOverflow</a>
     */
    private int[] redistribute(float red, float green, float blue) {
        float threshold = 255.999f;
        float max = Math.max(red, Math.max(green, blue));
        if (max <= threshold) {
            return new int[]{
                    class_3532.method_15340(Math.round(red), 0, 255),
                    class_3532.method_15340(Math.round(green), 0, 255),
                    class_3532.method_15340(Math.round(blue), 0, 255)};
        }

        float total = red + green + blue;

        if (total >= 3 * threshold)
            return new int[]{(int) threshold, (int) threshold, (int) threshold};

        float x = (3f * threshold - total) / (3f * max - total);
        float gray = threshold - x * max;
        return new int[]{
                class_3532.method_15340(Math.round(gray + x * red), 0, 255),
                class_3532.method_15340(Math.round(gray + x * green), 0, 255),
                class_3532.method_15340(Math.round(gray + x * blue), 0, 255)};
    }

    @Override
    public String toString() {
        return "BrightnessProcessor[" +
                "brightness=" + brightness + ']';
    }
}
