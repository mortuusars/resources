package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.item.camera.CameraSetting;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.NotNull;

public record ActiveCameraSetSettingC2SP(CameraSetting<?> setting, byte[] encodedValue) implements Packet {
    public static final class_2960 ID = Exposure.resource("active_camera_set_setting");
    public static final class_9154<ActiveCameraSetSettingC2SP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, ActiveCameraSetSettingC2SP> STREAM_CODEC = class_9139.method_56435(
            CameraSetting.STREAM_CODEC, ActiveCameraSetSettingC2SP::setting,
            class_9135.method_56895(4096), ActiveCameraSetSettingC2SP::encodedValue,
            ActiveCameraSetSettingC2SP::new
    );

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (player.getActiveExposureCamera() == null) return false;
        player.getActiveExposureCamera().ifPresent((item, stack) ->
                setting.decodeAndSet(player, stack, player.method_37908().method_30349(), encodedValue));
        return true;
    }
}