package io.github.mortuusars.exposure.client.task;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.client.export.ImageExporter;
import io.github.mortuusars.exposure.client.image.modifier.ImageModifier;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.data.export.ExportLook;
import io.github.mortuusars.exposure.data.export.ExportSize;
import io.github.mortuusars.exposure.util.cycles.task.Result;
import io.github.mortuusars.exposure.util.cycles.task.Task;
import io.github.mortuusars.exposure.world.level.storage.ExposureData;
import io.github.mortuusars.exposure.world.level.storage.RequestedPalettedExposure;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.network.chat.*;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;

public class ExportExposuresTask extends Task<Result<Boolean>> {
    private static final Logger LOGGER = LogUtils.getLogger();

    @Nullable
    private static ExportExposuresTask currentTask;

    protected final List<String> ids;
    protected final ExportSize size;
    protected final ExportLook look;

    @Nullable
    protected CompletableFuture<Result<Boolean>> future;
    protected boolean stop;

    public ExportExposuresTask(List<String> ids, ExportSize size, ExportLook look) {
        this.ids = ids;
        this.size = size;
        this.look = look;
    }

    public static boolean isRunning() {
        return currentTask != null;
    }

    public static boolean start(List<String> ids, ExportSize size, ExportLook look) {
        if (ExportExposuresTask.isRunning()) {
            Minecrft.player().method_7353(class_2561.method_43471("task.exposure.export.already_running"), false);
            return false;
        }
        ExposureClient.cycles().addParallelTask(new ExportExposuresTask(ids, size, look));
        return true;
    }

    public static boolean stopCurrentTask() {
        if (currentTask != null) {
            currentTask.stop = true;
            return true;
        }
        return false;
    }

    @Override
    public CompletableFuture<Result<Boolean>> execute() {
        currentTask = this;
        if (future == null) {
            this.future = CompletableFuture.supplyAsync(() -> {
                try {
                    return export();
                } finally {
                    currentTask = null;
                }
            });
            setStarted();
        }
        return future;
    }

    protected Result<Boolean> export() {
        int total = ids.size();
        AtomicInteger exported = new AtomicInteger();

        print(class_2561.method_43469("task.exposure.export.started", total));

        for (String id : ids) {
            if (stop) {
                print(class_2561.method_43471("task.exposure.export.stopped"));
                return Result.success(false);
            }

            @Nullable ExposureData exposure = null;

            for (int attempt = 0; attempt < 50; attempt++) {
                updateStatus(class_2561.method_43469("task.exposure.export.status.requesting", id, exported, total));

                RequestedPalettedExposure request = ExposureClient.exposureStore().getOrRequest(id);
                if (request.getData().isPresent()) {
                    exposure = request.getData().get();
                    break;
                }

                try {
                    Thread.sleep(100);
                } catch (InterruptedException ignored) {
                }
            }

            if (exposure == null) {
                print(class_2561.method_43469("task.exposure.export.error.not_received", id));
                continue;
            }

            updateStatus(class_2561.method_43469("task.exposure.export.status.exporting", id, exported, total));

            try {
                String fileName = id + look.getIdSuffix();
                new ImageExporter(exposure, fileName)
                        .modify(ImageModifier.chain(
                                look.getModifier(),
                                ImageModifier.Resize.multiplier(size.getMultiplier())
                        ))
                        .toExposuresFolder()
                        .organizeByWorld(Config.Client.EXPORT_ORGANIZE_BY_WORLD.get())
                        .setCreationDate(exposure.getTag().unixTimestamp())
                        .onExport(file -> {
                            exported.getAndIncrement();
                            print(class_2561.method_43471("task.exposure.export.exported")
                                    .method_27693("'" + fileName + "'").method_27696(class_2583.field_24360
                                            .method_30938(true)
                                            .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Open")))
                                            .method_10958(new class_2558(class_2558.class_2559.field_11746, file.getAbsolutePath()))));
                        })
                        .export();
            } catch (Exception e) {
                print(class_2561.method_43469("task.exposure.export.error", id, e.getMessage()));
                LOGGER.error("Failed to export exposure '{}': ", id, e);
            }
        }

        if (exported.get() > 0) {
            print(class_2561.method_43469("task.exposure.export.result", total));
        } else {
            print(class_2561.method_43471("task.exposure.export.none_exported"));
        }

        updateStatus(class_2561.method_43473());

        return Result.success(true);
    }

    protected void print(class_5250 message) {
        Minecrft.execute(() -> Minecrft.player().method_7353(message, false));
    }

    protected void updateStatus(class_5250 status) {
        Minecrft.execute(() -> Minecrft.player().method_7353(status, true));
    }
}