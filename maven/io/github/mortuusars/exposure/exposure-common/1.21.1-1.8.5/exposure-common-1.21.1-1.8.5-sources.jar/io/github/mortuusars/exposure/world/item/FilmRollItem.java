package io.github.mortuusars.exposure.world.item;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.client.gui.ClientGUI;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.inventory.ItemRenameMenu;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_5321;

public class FilmRollItem extends class_1792 implements FilmItem {
    private final ExposureType exposureType;
    private final int barColor;

    public FilmRollItem(ExposureType exposureType, int barColor, class_1793 properties) {
        super(properties);
        this.exposureType = exposureType;
        this.barColor = barColor;
    }

    @Override
    public ExposureType getType() {
        return exposureType;
    }

    public boolean method_31567(@NotNull class_1799 stack) {
        return hasFrames(stack);
    }

    public int method_31569(@NotNull class_1799 stack) {
        return Math.min(1 + 12 * getStoredFramesCount(stack) / getMaxFrameCount(stack), 13);
    }

    public int method_31571(@NotNull class_1799 stack) {
        return barColor;
    }

    public void addFrame(class_1799 stack, Frame frame) {
        Preconditions.checkState(getStoredFramesCount(stack) < getMaxFrameCount(stack),
                "Cannot add more frames than film could fit. Size: " + getMaxFrameCount(stack));

        List<Frame> frames = new ArrayList<>(stack.method_57825(Exposure.DataComponents.FILM_FRAMES, Collections.emptyList()));
        frames.add(frame);

        stack.method_57379(Exposure.DataComponents.FILM_FRAMES, frames);
    }

    public boolean canAddFrame(class_1799 stack) {
        return getStoredFramesCount(stack) < getMaxFrameCount(stack);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        int exposedFrames = getStoredFramesCount(stack);
        if (exposedFrames > 0) {
            int totalFrames = getMaxFrameCount(stack);
            tooltipComponents.add(class_2561.method_43469("item.exposure.film_roll.tooltip.frame_count", exposedFrames, totalFrames)
                    .method_27692(class_124.field_1080));
        }

        int frameSize = getFrameSize(stack);
        if (frameSize != getDefaultFrameSize(stack)) {
            tooltipComponents.add(class_2561.method_43469("item.exposure.film_roll.tooltip.frame_size",
                            class_2561.method_43470(String.format("%.1f", frameSize / 10f)))
                    .method_27692(class_124.field_1080));
        }

        class_5321<ColorPalette> colorPaletteId = getColorPaletteId(stack);
        if (tooltipFlag.method_8035() && !colorPaletteId.equals(ColorPalettes.DEFAULT)) {
            tooltipComponents.add(class_2561.method_43469("item.exposure.film_roll.tooltip.palette", colorPaletteId.method_29177().toString())
                    .method_27692(class_124.field_1080));
        }

        if (Config.Server.FILM_ROLL_EASY_RENAMING.get()) {
            tooltipComponents.add(class_2561.method_43471("item.exposure.film_roll.tooltip.renaming"));
        }

//        // Create compat:
//        int developingStep = stack.getTag() != null ? stack.getTag().getInt("CurrentDevelopingStep") : 0;
//        if (Config.Common.CREATE_SPOUT_DEVELOPING_ENABLED.get() && developingStep > 0) {
//            List<? extends String> totalSteps = Config.Common.spoutDevelopingSequence(getType()).get();
//
//            MutableComponent stepsComponent = Component.literal("");
//
//            for (int i = 0; i < developingStep; i++) {
//                stepsComponent.append(Component.literal("I").withStyle(ChatFormatting.GOLD));
//            }
//
//            for (int i = developingStep; i < totalSteps.size(); i++) {
//                stepsComponent.append(Component.literal("I").withStyle(ChatFormatting.DARK_GRAY));
//            }
//
//            tooltipComponents.add(Component.translatable("item.exposure.film_roll.tooltip.developing_step", stepsComponent)
//                    .withStyle(ChatFormatting.GOLD));
//        }

        //noinspection ConstantValue
        if (exposedFrames > 0 && !PlatformHelper.isModLoaded("jei") && Config.Client.RECIPE_TOOLTIPS_WITHOUT_JEI.get()) {
            ClientGUI.addFilmRollDevelopingTooltip(stack, context, tooltipComponents, tooltipFlag);
        }
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        if (!Config.Server.FILM_ROLL_EASY_RENAMING.get() || !(player instanceof class_3222 serverPlayer)) {
            return super.method_7836(level, player, usedHand);
        }

        int slot = getMatchingSlotInInventory(player.method_31548(), player.method_5998(usedHand));
        class_3908 menuProvider = new class_3908() {
            @Override
            public @NotNull class_2561 method_5476() {
                return class_2561.method_43471("gui.exposure.item_rename.title");
            }

            @Override
            public @NotNull class_1703 createMenu(int containerId, @NotNull class_1661 playerInventory, @NotNull class_1657 player) {
                return new ItemRenameMenu(containerId, playerInventory, slot);
            }
        };
        PlatformHelper.openMenu(serverPlayer, menuProvider, buffer -> buffer.method_53002(slot));
        return class_1271.method_22427(player.method_5998(usedHand));
    }

    protected int getMatchingSlotInInventory(class_1661 inventory, class_1799 stack) {
        for (int i = 0; i < inventory.method_5439(); i++) {
            if (inventory.method_5438(i).equals(stack)) {
                return i;
            }
        }
        return -1;
    }
}
