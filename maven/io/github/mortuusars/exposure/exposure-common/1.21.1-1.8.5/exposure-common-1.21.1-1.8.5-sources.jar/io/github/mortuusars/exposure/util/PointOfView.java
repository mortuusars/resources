package io.github.mortuusars.exposure.util;

import io.github.mortuusars.exposure.world.entity.CameraHolder;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3726;
import net.minecraft.class_3959;

/**
 * Some functionality related to camera (player's view) implemented for server side, as client classes are not available.
 *
 * @param pos position of the camera.
 * @param dir look direction of the camera.
 */
public record PointOfView(class_243 pos, class_243 dir) {
    public static PointOfView of(CameraHolder holder) {
        return of(holder.asEntity());
    }

    public static PointOfView of(class_1297 entity) {
        return new PointOfView(
                entity.method_19538().method_1031(0, entity.method_5751(), 0),
                // Not allowing xRot to reach 90deg because it'll cause problems with rotations down the line.
                // Precision is not that important here.
                class_243.method_1030(class_3532.method_15363(entity.method_36455(), -89, 89), entity.method_36454()));
    }

    // --

    public PointOfView rotateX(double degrees) {
        class_243 upVector = new class_243(0, 1, 0);
        class_243 rightVector = dir.method_1036(upVector).method_1029();
        if (class_3532.method_20390(rightVector.method_1033(), 0)) {
            rightVector = new class_243(1, 0, 0).method_1036(dir).method_1029();
        }
        class_243 rotated = Vec3Util.rotateVector(dir(), rightVector, Math.toRadians(degrees));
        return new PointOfView(pos, rotated);
    }

    public PointOfView rotateY(double degrees) {
        return new PointOfView(pos, dir.method_1024((float) Math.toRadians(degrees)));
    }

    public PointOfView move(double x, double y, double z) {
        return new PointOfView(pos.method_1031(x, y, z), dir);
    }

    public PointOfView reverseDirection() {
        return new PointOfView(pos, dir.method_22882());
    }

    public PointOfView limitMaxDistance(CameraHolder holder, double distance) {
        return limitMaxDistance(holder.asEntity(), distance);
    }

    public PointOfView limitMaxDistance(class_1297 entity, double distance) {
        float maxDistance = getMaxCameraDistance(entity, pos, dir, (float) distance);
        return new PointOfView(pos.method_1019(dir.method_1029().method_1021(-maxDistance)), dir);
    }

    /**
     * This method is the same as {@link net.minecraft.class_4184#method_19318(float)}
     * We need it to calculate proper camera position if camera is in third-person mode, so it does not clip into blocks.
     */
    private float getMaxCameraDistance(class_1297 entity, class_243 position, class_243 direction, float maxDistance) {
        for (int i = 0; i < 8; i++) {
            float xOff = (float) ((i & 1) * 2 - 1);
            float yOff = (float) ((i >> 1 & 1) * 2 - 1);
            float zOff = (float) ((i >> 2 & 1) * 2 - 1);
            class_243 pos = position.method_1031(xOff * 0.1F, yOff * 0.1F, zOff * 0.1F);
            class_243 endPos = pos.method_1019(direction.method_1021(-maxDistance));
            class_239 hitResult = entity.method_37908().method_17742(
                    new class_3959(pos, endPos, class_3959.class_3960.field_23142, class_3959.class_242.field_1348, class_3726.method_16195(entity)));
            if (hitResult.method_17783() != class_239.class_240.field_1333) {
                float distanceSqr = (float) hitResult.method_17784().method_1025(position);
                if (distanceSqr < class_3532.method_27285(maxDistance)) {
                    maxDistance = class_3532.method_15355(distanceSqr);
                }
            }
        }

        return maxDistance;
    }
}