package io.github.mortuusars.exposure.client.image.modifier.pixel;

import net.minecraft.class_5253;

public class NegativeModifier implements PixelModifier {
    @Override
    public String getIdentifier() {
        return "negative";
    }

    public int modify(int ARGB) {
        int alpha = class_5253.class_5254.method_27762(ARGB);
        int red = class_5253.class_5254.method_27765(ARGB);
        int green = class_5253.class_5254.method_27766(ARGB);
        int blue = class_5253.class_5254.method_27767(ARGB);

        // Invert
        red = 255 - red;
        green = 255 - green;
        blue = 255 - blue;

        return class_5253.class_5254.method_27764(alpha, red, green, blue);
    }
}
