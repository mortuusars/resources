package io.github.mortuusars.exposure.world.inventory;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.util.PagingDirection;
import io.github.mortuusars.exposure.world.item.AlbumItem;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import io.github.mortuusars.exposure.world.item.component.album.AlbumPage;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.serverbound.AlbumSignC2SP;
import io.github.mortuusars.exposure.util.Side;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3675;
import net.minecraft.class_3915;
import net.minecraft.class_3917;
import net.minecraft.class_9129;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;

public class AlbumMenu extends class_1703 {
    public static final int CANCEL_ADDING_PHOTO_BUTTON = -1;
    public static final int PREVIOUS_PAGE_BUTTON = PagingDirection.PREVIOUS.ordinal();
    public static final int NEXT_PAGE_BUTTON = PagingDirection.NEXT.ordinal();
    public static final int LEFT_PAGE_PHOTO_BUTTON = 2;
    public static final int RIGHT_PAGE_PHOTO_BUTTON = 3;
    public static final int ENTER_SIGN_MODE_BUTTON = 4;
    public static final int SIGN_BUTTON = 5;
    public static final int CANCEL_SIGNING_BUTTON = 6;

    protected final int albumSlot;
    protected final class_1799 albumStack;
    protected final AlbumItem albumItem;

    protected final List<AlbumPhotographSlot> photographSlots = new ArrayList<>();
    protected final List<AlbumPlayerInventorySlot> playerInventorySlots = new ArrayList<>();

    protected class_3915 currentSpreadIndex = class_3915.method_17403();

    @Nullable
    protected Side sideBeingAddedTo = null;
    protected boolean signing;
    protected String title = "";

    protected final Map<Integer, Consumer<class_1657>> buttonActions = new HashMap<>() {{
        put(CANCEL_ADDING_PHOTO_BUTTON, p -> {
            sideBeingAddedTo = null;
            if (!method_34255().method_7960()) {
                p.method_31548().method_7398(method_34255());
                method_34254(class_1799.field_8037);
            }
            updatePlayerInventorySlots();
        });
        put(PREVIOUS_PAGE_BUTTON, p -> {
            method_7604(p, CANCEL_ADDING_PHOTO_BUTTON);
            setCurrentSpreadIndex(Math.max(0, getCurrentSpreadIndex() - 1));
        });
        put(NEXT_PAGE_BUTTON, p -> {
            method_7604(p, CANCEL_ADDING_PHOTO_BUTTON);
            setCurrentSpreadIndex(Math.min((getPages().size() - 1) / 2, getCurrentSpreadIndex() + 1));
        });
        put(LEFT_PAGE_PHOTO_BUTTON, p -> onPhotoButtonPress(p, Side.LEFT));
        put(RIGHT_PAGE_PHOTO_BUTTON, p -> onPhotoButtonPress(p, Side.RIGHT));
        put(ENTER_SIGN_MODE_BUTTON, p -> {
            signing = true;
            sideBeingAddedTo = null;
        });
        put(SIGN_BUTTON, p -> signAlbum(p));
        put(CANCEL_SIGNING_BUTTON, p -> signing = false);
    }};

    public AlbumMenu(int containerId, class_1661 playerInventory, int albumSlot) {
        this(Exposure.MenuTypes.ALBUM.get(), containerId, playerInventory, albumSlot);
    }

    protected AlbumMenu(class_3917<? extends class_1703> type, int containerId, class_1661 playerInventory, int albumSlot) {
        super(type, containerId);
        this.albumSlot = albumSlot;

        albumStack = playerInventory.method_5438(albumSlot);
        if (!(albumStack.method_7909() instanceof AlbumItem item)) {
            throw new IllegalStateException("Expected AlbumItem in slot '" + albumSlot + "'. Got: " + albumStack);
        }

        this.albumItem = item;

        if (isAlbumEditable()) {
            // Sets all pages to empty.
            item.setContent(albumStack, item.getContent(albumStack).toMutable().setPage(15, AlbumPage.EMPTY).toImmutable());
        }

        addPhotographSlots();
        addPlayerInventorySlots(playerInventory, 70, 115);
        method_17362(currentSpreadIndex);
    }

    protected void addPhotographSlots() {
        class_1799[] photographs = albumItem.getContent(albumStack).pages().stream().map(AlbumPage::photograph).toArray(class_1799[]::new);
        class_1277 container = new class_1277(photographs);

        for (int i = 0; i < container.method_5439(); i++) {
            int x = i % 2 == 0 ? 71 : 212;
            int y = 67;
            AlbumPhotographSlot slot = new AlbumPhotographSlot(container, i, x, y) {
                @Override
                public void method_7673(class_1799 stack) {
                    super.method_7673(stack);
                    onPhotographSlotChanged(method_34266(), stack);
                }
            };
            method_7621(slot);
            photographSlots.add(slot);
        }
    }

    private void onPhotographSlotChanged(int slotIndex, class_1799 stack) {
        albumItem.updatePage(albumStack, slotIndex, page -> page.orElse(AlbumPage.EMPTY).setPhotograph(stack));
//        List<AlbumPage> pages = getPages();
//        AlbumPage page = pages.get(slotIndex);
//        page = page.setPhotograph(stack);
//        pages.set(slotIndex, page);
    }

    private void addPlayerInventorySlots(class_1661 playerInventory, int x, int y) {
        // Player inventory slots
        for (int row = 0; row < 3; ++row) {
            for (int column = 0; column < 9; ++column) {
                AlbumPlayerInventorySlot slot = new AlbumPlayerInventorySlot(playerInventory, column + row * 9 + 9,
                        x + column * 18, y + row * 18);
                method_7621(slot);
                playerInventorySlots.add(slot);
            }
        }

        // Player hotbar slots
        // Hotbar should go after main inventory for Shift+Click to work properly.
        for (int index = 0; index < 9; ++index) {
            boolean disabled = index == playerInventory.field_7545 && playerInventory.method_7391().method_7909() instanceof AlbumItem;
            AlbumPlayerInventorySlot slot = new AlbumPlayerInventorySlot(playerInventory, index,
                    x + index * 18, y + 58) {
                @Override
                public boolean method_7674(class_1657 player) {
                    return !disabled;
                }

                @Override
                public boolean method_7680(class_1799 stack) {
                    return !disabled;
                }
            };
            method_7621(slot);
            playerInventorySlots.add(slot);
        }
    }

    protected void updatePlayerInventorySlots() {
        boolean isInAddingPhotographMode = isInAddingPhotographMode();
        for (AlbumPlayerInventorySlot slot : playerInventorySlots) {
            slot.setActive(isInAddingPhotographMode);
        }
    }

    public int getAlbumSlot() {
        return albumSlot;
    }

    public boolean isAlbumEditable() {
        return true;
    }

    public boolean isInAddingPhotographMode() {
        return getSideBeingAddedTo() != null;
    }

    public boolean isInSigningMode() {
        return signing;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean canSignAlbum() {
        for (AlbumPage page : getPages()) {
            if (!page.photograph().method_7960() || !page.note().isEmpty()) {
                return true;
            }
        }
        return false;
    }

    public void signAlbum(class_1657 player) {
        if (!player.method_37908().field_9236) {
            return;
        }

        if (!canSignAlbum()) {
            throw new IllegalStateException("Cannot sign the album.\n" + Arrays.toString(getPages().toArray()));
        }

        Packets.sendToServer(new AlbumSignC2SP(albumSlot, title, player.method_5820()));
    }

    public List<AlbumPlayerInventorySlot> getPlayerInventorySlots() {
        return playerInventorySlots;
    }

    public List<AlbumPage> getPages() {
        return albumItem.getContent(albumStack).pages();
    }

    public Optional<AlbumPage> getPage(int pageIndex) {
        if (pageIndex <= getPages().size() - 1)
            return Optional.ofNullable(getPages().get(pageIndex));

        return Optional.empty();
    }

    public Optional<AlbumPage> getPage(Side side) {
        return getPage(getCurrentSpreadIndex() * 2 + side.getIndex());
    }

    public void updatePage(int pageIndex, Function<AlbumPage, AlbumPage> pageTransform) {
        albumItem.updatePage(albumStack, pageIndex, page -> pageTransform.apply(page.orElse(AlbumPage.EMPTY)));
    }

    public Optional<AlbumPhotographSlot> getPhotographSlot(Side side) {
        return getPhotographSlot(getCurrentSpreadIndex() * 2 + (side == Side.LEFT ? 0 : 1));
    }

    public Optional<AlbumPhotographSlot> getPhotographSlot(int index) {
        if (index >= 0 && index < photographSlots.size())
            return Optional.ofNullable(photographSlots.get(index));

        return Optional.empty();
    }

    public class_1799 getPhotograph(Side side) {
        return getPhotographSlot(side).map(class_1735::method_7677).orElse(class_1799.field_8037);
    }

    public int getCurrentSpreadIndex() {
        return this.currentSpreadIndex.method_17407();
    }

    public void setCurrentSpreadIndex(int spreadIndex) {
        this.currentSpreadIndex.method_17404(spreadIndex);
    }

    public @Nullable Side getSideBeingAddedTo() {
        return sideBeingAddedTo;
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        @Nullable Consumer<class_1657> buttonAction = buttonActions.get(id);
        if (buttonAction != null) {
            buttonAction.accept(player);
            return true;
        }

        return false;
    }

    private void onPhotoButtonPress(class_1657 player, Side side) {
        Preconditions.checkArgument(isAlbumEditable(),
                "Photo Button should be disabled and hidden when Album is not editable. " + albumStack);

        Optional<AlbumPhotographSlot> photographSlot = getPhotographSlot(side);
        if (photographSlot.isEmpty())
            return;

        AlbumPhotographSlot slot = photographSlot.get();
        if (!slot.method_7681()) {
            sideBeingAddedTo = side;
        }
        else {
            class_1799 stack = slot.method_7677();
            if (!player.method_31548().method_7394(stack))
                player.method_7328(stack, false);

            slot.method_7673(class_1799.field_8037);
        }

        updatePlayerInventorySlots();
    }

    @Override
    public void method_7593(int slotId, int button, class_1713 clickType, class_1657 player) {
        // Both sides

        if (sideBeingAddedTo == null || slotId < 0 || slotId >= field_7761.size()) {
            super.method_7593(slotId, button, clickType, player);
            return;
        }

        class_1735 slot = field_7761.get(slotId);
        class_1799 stack = slot.method_7677();

        if (button == class_3675.field_32000
                && slot instanceof AlbumPlayerInventorySlot
                && stack.method_7909() instanceof PhotographItem
                && method_34255().method_7960()) {
            int pageIndex = getCurrentSpreadIndex() * 2 + sideBeingAddedTo.getIndex();
            Optional<AlbumPhotographSlot> photographSlot = getPhotographSlot(pageIndex);
            if (photographSlot.isEmpty() || !photographSlot.get().method_7677().method_7960())
                return;

            photographSlot.get().method_7673(stack);
            slot.method_7673(class_1799.field_8037);

            if (player.method_37908().field_9236) {
                player.method_5783(Exposure.SoundEvents.PHOTOGRAPH_PLACE.get(), 0.8f, 1.1f);
            }

            sideBeingAddedTo = null;
            updatePlayerInventorySlots();
        }
        else
            super.method_7593(slotId, button, clickType, player);
    }

    @Override
    public @NotNull class_1799 method_7601(class_1657 player, int index) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return player.method_31548().method_5438(albumSlot).method_7909() instanceof AlbumItem;
    }

    public static AlbumMenu fromBuffer(int containerId, class_1661 playerInventory, class_9129 buffer) {
        return new AlbumMenu(containerId, playerInventory, buffer.method_10816());
    }
}
