package io.github.mortuusars.exposure.client.camera.viewfinder;

import com.google.gson.JsonSyntaxException;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.client.util.Shader;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.data.Filter;
import io.github.mortuusars.exposure.data.Filters;
import io.github.mortuusars.exposure.world.item.camera.Attachment;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import net.minecraft.class_1799;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class ViewfinderShader implements AutoCloseable {
    private final class_310 minecraft;
    private final Camera camera;
    private final Viewfinder viewfinder;

    @Nullable
    private class_279 shader;
    private boolean active;

    public ViewfinderShader(Camera camera, Viewfinder viewfinder) {
        this.minecraft = Minecrft.get();
        this.camera = camera;
        this.viewfinder = viewfinder;
        this.update();
    }

    public void apply(class_2960 shaderLocation) {
        if (shader != null) {
            if (shader.method_1260().equals(shaderLocation.toString())) {
                return;
            }

            shader.close();
        }

        try {
            shader = new class_279(minecraft.method_1531(), minecraft.method_1478(),
                    minecraft.method_1522(), shaderLocation);
            shader.method_1259(minecraft.method_22683().method_4489(), minecraft.method_22683().method_4506());
            active = true;
        } catch (IOException e) {
            Exposure.LOGGER.warn("Failed to load shader: {}", shaderLocation, e);
            active = false;
        } catch (JsonSyntaxException e) {
            Exposure.LOGGER.warn("Failed to parse shader: {}", shaderLocation, e);
            active = false;
        }
    }

    public void resize(int width, int height) {
        if (shader != null) {
            shader.method_1259(width, height);
        }
    }

    /**
     * Processes current viewfinder shader (if it is present and active).
     */
    public void process() {
        if (shader != null && active) {
            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.resetTextureMatrix();
            shader.method_1258(minecraft.method_60646().method_60636());
        }
    }

    /**
     * Processes current viewfinder shader (if it is present and active) to a specified render target.
     * Current shader is not modified in the process. Copy of the shader is created and resized to the render target dimensions.
     * Since this method creates a temp PostChain on every call, this probably should not be used when performance matters.
     * Main use for this is to apply a shader when capturing a photograph.
     */
    public void process(class_276 renderTarget) {
        if (shader != null) {
            Shader.apply(shader, renderTarget);
        }
    }

    public void update() {
        class_1799 filterStack = Attachment.FILTER.get(camera.getItemStack()).getForReading();
        Filters.of(Minecrft.registryAccess(), filterStack).map(Filter::shader).ifPresentOrElse(this::apply, this::remove);
        setActive(viewfinder.isLookingThrough());
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public void remove() {
        if (shader != null) {
            shader.close();
        }

        shader = null;
    }

    @Override
    public void close() {
        remove();
    }
}
