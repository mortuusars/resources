package io.github.mortuusars.exposure.world.camera.capture;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2540;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ProjectionInfo(String path, ProjectionMode mode) {
    public static final Codec<ProjectionInfo> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("path").forGetter(ProjectionInfo::path),
            ProjectionMode.CODEC.optionalFieldOf("mode", ProjectionMode.DITHERED).forGetter(ProjectionInfo::mode)
    ).apply(instance, ProjectionInfo::new));

    public static final class_9139<class_2540, ProjectionInfo> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48554, ProjectionInfo::path,
            ProjectionMode.STREAM_CODEC, ProjectionInfo::mode,
            ProjectionInfo::new
    );
}
