package io.github.mortuusars.exposure.client.render.photograph;

import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.client.image.modifier.ImageModifier;
import io.github.mortuusars.exposure.client.image.renderable.RenderableImage;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

public record PhotographStyle(class_2960 paperTexture,
                              class_2960 overlayTexture,
                              class_2960 albumPaperTexture,
                              class_2960 albumOverlayTexture,
                              ImageModifier modifier) {

    public static final PhotographStyle REGULAR = new PhotographStyle(
            ExposureClient.Textures.Photograph.REGULAR_PAPER,
            ExposureClient.Textures.EMPTY,
            ExposureClient.Textures.Photograph.REGULAR_ALBUM_PAPER,
            ExposureClient.Textures.EMPTY,
            ImageModifier.EMPTY);

    public static PhotographStyle of(class_1799 photographStack) {
        return photographStack.method_7909() instanceof PhotographItem photographItem
                ? PhotographStyles.get(photographItem.getType(photographStack))
                : PhotographStyle.REGULAR;
    }

    public boolean hasOverlayTexture() {
        return !overlayTexture().equals(ExposureClient.Textures.EMPTY);
    }

    public boolean hasAlbumOverlayTexture() {
        return !albumOverlayTexture().equals(ExposureClient.Textures.EMPTY);
    }

    public RenderableImage process(RenderableImage image) {
        return !modifier.equals(ImageModifier.EMPTY) ? image.modifyWith(modifier) : image;
    }
}
