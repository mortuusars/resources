package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.data.ColorPalettes;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public interface FilmItem {
    ExposureType getType();

    default int getDefaultMaxFrameCount(class_1799 stack) {
        return 16;
    }

    default int getDefaultFrameSize(class_1799 stack) {
        return Config.Server.DEFAULT_FRAME_SIZE.get();
    }

    default class_5321<ColorPalette> getColorPaletteId(class_1799 stack) {
        @Nullable class_2960 location = stack.method_57824(Exposure.DataComponents.FILM_COLOR_PALETTE);
        if (location != null) return class_5321.method_29179(Exposure.Registries.COLOR_PALETTE, location);
        return ColorPalettes.DEFAULT;
    }

    default int getMaxFrameCount(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.FILM_FRAME_COUNT, getDefaultMaxFrameCount(stack));
    }

    default int getFrameSize(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.FILM_FRAME_SIZE, getDefaultFrameSize(stack));
    }

    default List<Frame> getStoredFrames(class_1799 stack) {
        return stack.method_57825(Exposure.DataComponents.FILM_FRAMES, Collections.emptyList());
    }

    default int getStoredFramesCount(class_1799 stack) {
        return getStoredFrames(stack).size();
    }

    default boolean hasFrames(class_1799 stack) {
        return !getStoredFrames(stack).isEmpty();
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    default boolean hasFrameAt(class_1799 stack, int index) {
        return getStoredFrames(stack).size() > index;
    }

    default float getFullness(class_1799 stack) {
        return (float) getStoredFramesCount(stack) / getMaxFrameCount(stack);
    }

    default boolean isFull(class_1799 stack) {
        return getStoredFramesCount(stack) == getMaxFrameCount(stack);
    }
}
