package io.github.mortuusars.exposure.client.image.modifier.pixel;

import com.google.common.base.Preconditions;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_3532;
import net.minecraft.class_5253;

public class NoiseModifier implements PixelModifier {
    protected final float intensity;

    public NoiseModifier(float intensity) {
        Preconditions.checkArgument(intensity >= 0 && intensity <= 1, "intensity should be in 0-1 range.");
        this.intensity = intensity;
    }

    @Override
    public String getIdentifier() {
        return "noise-" + intensity;
    }

    public int modify(int colorARGB) {
        int alpha = class_5253.class_5254.method_27762(colorARGB);
        int red = class_5253.class_5254.method_27765(colorARGB);
        int green = class_5253.class_5254.method_27766(colorARGB);
        int blue = class_5253.class_5254.method_27767(colorARGB);

        red = addNoise(red);
        green = addNoise(green);
        blue = addNoise(blue);

        return class_5253.class_5254.method_27764(alpha, red, green, blue);
    }

    protected int addNoise(int colorValue) {
        // Apply noise based on intensity
        float effect = intensity * (1f - (colorValue / 255f));
        effect = class_3532.method_16439(0.4f, effect, intensity);
        int noise = (int) ((ThreadLocalRandom.current().nextDouble() * 2 - 1) * 255 * effect);
        return class_3532.method_15340(colorValue + noise, 0, 255);
    }
}
