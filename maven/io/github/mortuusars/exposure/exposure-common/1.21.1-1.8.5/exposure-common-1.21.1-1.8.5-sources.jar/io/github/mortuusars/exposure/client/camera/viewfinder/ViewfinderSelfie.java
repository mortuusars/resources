package io.github.mortuusars.exposure.client.camera.viewfinder;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.client.animation.Animation;
import io.github.mortuusars.exposure.client.animation.EasingFunction;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.item.camera.CameraSettings;
import net.minecraft.class_3532;
import net.minecraft.class_5498;

public class ViewfinderSelfie {
    protected final Camera camera;
    protected final Viewfinder viewfinder;

    protected double rawXRot, rawYRot, xRot, yRot, prevXRot, prevYRot;
    protected Animation xRotAnimation = new Animation(200, EasingFunction.EASE_OUT_EXPO);
    protected Animation yRotAnimation = new Animation(200, EasingFunction.EASE_OUT_EXPO);

    public ViewfinderSelfie(Camera camera, Viewfinder viewfinder) {
        this.camera = camera;
        this.viewfinder = viewfinder;
    }

    public void tick() {
        updateSelfieMode();
    }

    public float getMaxCameraDistance() {
        return Config.Server.SELFIE_CAMERA_DISTANCE.get().floatValue();
    }

    public double getCameraXRot() {
        return class_3532.method_16436(xRotAnimation.getValue(), prevXRot, xRot);
    }

    public double getCameraYRot() {
        return class_3532.method_16436(yRotAnimation.getValue(), prevYRot, yRot);
    }

    public double getMaxRotationXDegrees() {
        return 40.0;
    }

    public double getMaxRotationYDegrees() {
        return 30.0;
    }

    public double getRotationXStepDegrees() {
        return 5.0;
    }

    public double getRotationYStepDegrees() {
        return 5.0;
    }

    public void toggle() {
        class_5498 newCameraType = Minecrft.options().method_31044() == class_5498.field_26664
                ? class_5498.field_26666
                : class_5498.field_26664;

        Minecrft.options().method_31043(newCameraType);
    }

    public void updateSelfieMode() {
        boolean inSelfieMode = Minecrft.options().method_31044() == class_5498.field_26666;
        if (camera.inSelfieMode() != inSelfieMode) {
            CameraSettings.SELFIE_MODE.setAndSync(camera, inSelfieMode);
            CameraSettings.SELFIE_ROTATION_X.setAndSync(camera, 0.0);
            CameraSettings.SELFIE_ROTATION_Y.setAndSync(camera, 0.0);
            xRot = 0;
            yRot = 0;
            rawXRot = 0;
            rawYRot = 0;
        }
    }

    public boolean mouseMove(double xRotDelta, double yRotDelta) {
        if (!viewfinder.controlsActive() && camera.inSelfieMode() && Minecrft.options().field_1867.field_1653) {
            rotateCamera(xRotDelta, yRotDelta, false);
            return true;
        }

        return false;
    }

    public void rotateCamera(double xRotDelta, double yRotDelta, boolean precise) {
        double maxX = getMaxRotationXDegrees();
        double maxY = getMaxRotationYDegrees();
        this.rawXRot = class_3532.method_15350(this.rawXRot + xRotDelta * 0.15, -maxX, maxX);
        this.rawYRot = class_3532.method_15350(this.rawYRot + yRotDelta * 0.15, -maxY, maxY);

        double stepX = getRotationXStepDegrees() * (precise ? 0.25 : 1);
        double stepY = getRotationYStepDegrees() * (precise ? 0.25 : 1);
        double xr = ((int)this.rawXRot) - ((int)this.rawXRot) % stepX;
        double yr = ((int)this.rawYRot) - ((int)this.rawYRot) % stepY;

        if (xr != prevXRot) {
            this.prevXRot = getCameraXRot();
            this.xRot = xr;
            xRotAnimation.resetProgress();
            CameraSettings.SELFIE_ROTATION_X.setAndSync(camera, this.xRot);
        }

        if (yr != prevYRot) {
            this.prevYRot = getCameraYRot();
            this.yRot = yr;
            yRotAnimation.resetProgress();
            CameraSettings.SELFIE_ROTATION_Y.setAndSync(camera, this.yRot);
        }
    }
}