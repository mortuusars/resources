package io.github.mortuusars.exposure.camera.infrastructure;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import java.util.Objects;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2540;

public class ShutterSpeed {
    
    public static final ShutterSpeed DEFAULT = new ShutterSpeed("60");

    private final String text;
    private final float valueMilliseconds;

    public ShutterSpeed(String shutterSpeed) {
        this.text = shutterSpeed;
        this.valueMilliseconds = parseMilliseconds(shutterSpeed);
        Preconditions.checkState(valueMilliseconds != -1,  shutterSpeed + " is not valid. (format should be: '1/60', '60', '2\"')");
        Preconditions.checkState(valueMilliseconds > 0, "Shutter Speed cannot be 0 or smaller.");
    }

    private float parseMilliseconds(String shutterSpeed) {
        shutterSpeed = shutterSpeed.trim();

        if (shutterSpeed.contains("\""))
            return Integer.parseInt(shutterSpeed.replace("\"", "")) * 1000;
        else if (shutterSpeed.contains("1/"))
            return 1f / Integer.parseInt(shutterSpeed.replace("1/", "")) * 1000;
        else
            return 1f / Integer.parseInt(shutterSpeed) * 1000;
    }

    public String getFormattedText() {
        if (getMilliseconds() < 999 && !text.startsWith("1/"))
            return "1/" + text;

        return text;
    }

    public float getMilliseconds() {
        return valueMilliseconds;
    }

    public int getTicks() {
        return Math.max(1, (int)(valueMilliseconds * 20 / 1000f));
    }

    public float getStopsDifference(ShutterSpeed relative) {
        return (float) (Math.log(valueMilliseconds / relative.getMilliseconds()) / Math.log(2));
    }

    public class_2487 save(class_2487 tag) {
        tag.method_10582("ShutterSpeed", text);
        return tag;
    }

    public static ShutterSpeed loadOrDefault(class_2487 tag) {
        try {
            if (tag.method_10573("ShutterSpeed", class_2520.field_33258)) {
                String shutterSpeed = tag.method_10558("ShutterSpeed");
                return new ShutterSpeed(shutterSpeed);
            }
        }
        catch (IllegalStateException e) {
            Exposure.LOGGER.error("Cannot load a shutter speed from tag: " + e);
        }

        return DEFAULT;
    }
    
    public void toBuffer(class_2540 buffer) {
        buffer.method_10814(text);
    }

    public static ShutterSpeed fromBuffer(class_2540 buffer) {
        return new ShutterSpeed(buffer.method_19772());
    }

    @Override
    public String toString() {
        return text;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ShutterSpeed that = (ShutterSpeed) o;
        return Float.compare(that.valueMilliseconds, valueMilliseconds) == 0 && Objects.equals(text, that.text);
    }

    @Override
    public int hashCode() {
        return Objects.hash(text, valueMilliseconds);
    }
}
