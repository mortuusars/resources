package io.github.mortuusars.exposure.gui.screen.element;

import io.github.mortuusars.exposure.block.entity.Lightroom;
import io.github.mortuusars.exposure.gui.screen.LightroomScreen;
import java.util.function.Supplier;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_7919;

public class ChromaticProcessToggleButton extends class_344 {
    private final Supplier<Lightroom.Process> processGetter;

    public ChromaticProcessToggleButton(int x, int y, class_4241 onPress, Supplier<Lightroom.Process> processGetter) {
        super(x, y, 18, 18, 198, 17, 18,
                LightroomScreen.MAIN_TEXTURE, 256, 256, onPress);
        this.processGetter = processGetter;
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        Lightroom.Process currentProcess = processGetter.get();
        int xTex = currentProcess == Lightroom.Process.CHROMATIC ? 18 : 0;

        this.method_48588(guiGraphics, this.field_2127, this.method_46426(), this.method_46427(), this.field_2126 + xTex, this.field_2125,
                this.field_19079, this.field_22758, this.field_22759, this.field_2124, this.field_19080);

        class_5250 tooltip = class_2561.method_43471("gui.exposure.lightroom.process." + currentProcess.method_15434());
        if (currentProcess == Lightroom.Process.CHROMATIC) {
            tooltip.method_10852(class_5244.field_33849);
            tooltip.method_10852(class_2561.method_43471("gui.exposure.lightroom.process.chromatic.info")
                    .method_27692(class_124.field_1080));
        }

        method_47400(class_7919.method_47407(tooltip));
    }
}
