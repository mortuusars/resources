package io.github.mortuusars.exposure.entity;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.item.PhotographItem;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1530;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2312;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_5630;
import net.minecraft.class_5712;
import net.minecraft.class_8103;
import net.minecraft.world.entity.*;
import org.apache.commons.lang3.Validate;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class PhotographFrameEntity extends class_1530 {
    public static final Logger LOGGER = Exposure.LOGGER;

    protected static final class_2940<Integer> DATA_SIZE = class_2945.method_12791(PhotographFrameEntity.class, class_2943.field_13327);
    protected static final class_2940<class_1799> DATA_FRAME_ITEM = class_2945.method_12791(PhotographFrameEntity.class, class_2943.field_13322);
    protected static final class_2940<class_1799> DATA_ITEM = class_2945.method_12791(PhotographFrameEntity.class, class_2943.field_13322);
    protected static final class_2940<Integer> DATA_ITEM_ROTATION = class_2945.method_12791(PhotographFrameEntity.class, class_2943.field_13327);
    protected static final class_2940<Boolean> DATA_GLOWING = class_2945.method_12791(PhotographFrameEntity.class, class_2943.field_13323);
    protected static final class_2940<Boolean> DATA_STRIPPED = class_2945.method_12791(PhotographFrameEntity.class, class_2943.field_13323);

    protected int size = 0;

    public PhotographFrameEntity(class_1299<? extends PhotographFrameEntity> entityType, class_1937 level) {
        super(entityType, level);
    }

    public PhotographFrameEntity(class_1937 level, class_2338 pos, class_2350 facingDirection) {
        super(Exposure.EntityTypes.PHOTOGRAPH_FRAME.get(), level, pos);
        method_6892(facingDirection);
        setItem(class_1799.field_8037);
    }

    @Override
    public boolean method_5640(double distance) {
        double d = Config.Client.PHOTOGRAPH_FRAME_CULLING_DISTANCE.get() * method_5824();
        return distance < d * d;
    }

    protected void method_5693() {
        method_5841().method_12784(DATA_SIZE, 0);
        method_5841().method_12784(DATA_FRAME_ITEM, class_1799.field_8037);
        method_5841().method_12784(DATA_ITEM, class_1799.field_8037);
        method_5841().method_12784(DATA_ITEM_ROTATION, 0);
        method_5841().method_12784(DATA_STRIPPED, false);
        method_5841().method_12784(DATA_GLOWING, false);
    }

    public void method_5674(class_2940<?> key) {
        if (key.equals(DATA_ITEM)) {
            onItemChanged(getItem());
        }
        if (key.equals(DATA_SIZE)) {
            size = method_5841().method_12789(DATA_SIZE);
            method_6895();
        }
    }

    @Override
    public void method_31471(@NotNull class_2604 packet) {
        super.method_31471(packet);
        int packedData = packet.method_11166();
        int size = (packedData >> 8) & 0xFF;
        int direction = packedData & 0xFF;
        setSize(size);
        method_6892(class_2350.method_10143(direction));
    }

    @Override
    public @NotNull class_2596<class_2602> method_18002() {
        int packedData = (size << 8) | field_7099.method_10146();
        return new class_2604(this, packedData, this.method_6896());
    }

    public void method_5652(@NotNull class_2487 tag) {
        super.method_5652(tag);
        class_1799 item = getItem();
        if (!item.method_7960()) {
            tag.method_10566("Item", item.method_7953(new class_2487()));
            tag.method_10556("IsGlowing", this.isGlowing()); // "Glowing" is used in vanilla
            tag.method_10567("ItemRotation", (byte) this.getItemRotation());
        }
        class_1799 frameItem = getFrameItem();
        if (!frameItem.method_7960())
            tag.method_10566("FrameItem", frameItem.method_7953(new class_2487()));

        tag.method_10567("Size", (byte) getSize());
        tag.method_10567("Facing", (byte) field_7099.method_10146());
        tag.method_10556("Stripped", isStripped());
        tag.method_10556("Invisible", method_5767());
    }

    public void method_5749(@NotNull class_2487 tag) {
        super.method_5749(tag);
        class_2487 frameItemTag = tag.method_10562("FrameItem");
        if (!frameItemTag.method_33133()) {
            class_1799 itemstack = class_1799.method_7915(frameItemTag);
            if (itemstack.method_7960()) {
                Exposure.LOGGER.warn("Unable to load frame item from: {}", frameItemTag);
                itemstack = new class_1799(Exposure.Items.PHOTOGRAPH_FRAME.get());
            }

            setFrameItem(itemstack);
        }

        class_2487 itemTag = tag.method_10562("Item");
        if (!itemTag.method_33133()) {
            class_1799 itemstack = class_1799.method_7915(itemTag);
            if (itemstack.method_7960())
                Exposure.LOGGER.warn("Unable to load item from: {}", itemTag);

            setItem(itemstack);
            setGlowing(tag.method_10577("IsGlowing")); // "Glowing" is used in vanilla
            setItemRotation(tag.method_10571("ItemRotation"));
        }

        setSize(tag.method_10571("Size"));
        method_6892(class_2350.method_10143(tag.method_10571("Facing")));
        setStripped(tag.method_10577("Stripped"));
        method_5648(tag.method_10577("Invisible"));
    }

    @Override
    public @NotNull class_243 method_43390() {
        return class_243.method_24954(this.field_7100);
    }

    @Override
    protected float method_18378(@NotNull class_4050 pose, @NotNull class_4048 dimensions) {
        return 0f;
    }

    @Override
    public int method_6897() {
        return getSize() * 16 + 16;
    }

    @Override
    public int method_6891() {
        return getSize() * 16 + 16;
    }

    @Nullable
    @Override
    public class_1799 method_31480() {
        class_1799 item = getItem();
        if (!item.method_7960())
            return item.method_7972();

        return getFrameItem().method_7972();
    }

    @Override
    protected void method_6895() {
        //noinspection ConstantValue
        if (this.field_7099 == null)
            return;

        double x = (double)this.field_7100.method_10263() + 0.5;
        double y = (double)this.field_7100.method_10264() + 0.5;
        double z = (double)this.field_7100.method_10260() + 0.5;

        double widthOffset = method_6897() % 32 == 0 ? 0.5 : 0.0;
        double heightOffset = method_6891() % 32 == 0 ? 0.5 : 0.0;
        if (getSize() == 2) {
            widthOffset += 1;
            heightOffset += 1;
        }

        double hangOffset = 0.46875;

        if (method_5735().method_10166().method_10179()) {
            x -= method_5735().method_10148() * hangOffset;
            z -= method_5735().method_10165() * hangOffset;
            class_2350 direction = method_5735().method_10160();
            method_23327(x += widthOffset * (double)direction.method_10148(), y += heightOffset, z += widthOffset * (double)direction.method_10165());
            double xSize = this.method_6897();
            double ySize = this.method_6891();
            double zSize = this.method_6897();
            if (method_5735().method_10166() == class_2350.class_2351.field_11051)
                zSize = 1.0;
            else
                xSize = 1.0;
            method_5857(new class_238(x - (xSize /= 32.0), y - (ySize /= 32.0), z - (zSize /= 32.0), x + xSize, y + ySize, z + zSize));
        }
        else {
            y -= method_5735().method_10164() * hangOffset;
            method_23327(x += widthOffset, y, z -= heightOffset);
            double xSize = method_6897();
            double zSize = method_6891();
            method_5857(new class_238(x - (xSize /= 32.0), y - (1.0 / 32.0), z - (zSize /= 32.0), x + xSize, y + 1.0 / 32.0, z + zSize));
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public boolean method_6888() {
        if (!method_37908().method_17892(this))
            return false;

        int sizeX = Math.max(1, method_6897() / 16);
        int sizeY = Math.max(1, method_6891() / 16);
        class_2338 baseBlockPos = field_7100.method_10093(field_7099.method_10153());

        if (method_5735().method_10166().method_10179()) {
            class_2350 direction = method_5735().method_10160();
            class_2338.class_2339 mPos = new class_2338.class_2339();
            for (int pX = 0; pX < sizeX; ++pX) {
                for (int pY = 0; pY < sizeY; ++pY) {
                    mPos.method_10101(baseBlockPos).method_10104(direction, pX).method_10104(class_2350.field_11036, pY);
                    class_2680 blockState = method_37908().method_8320(mPos);
                    if (blockState.method_51367() || class_2312.method_9999(blockState)) continue;
                    return false;
                }
            }
        } else {
            class_2338.class_2339 mPos = new class_2338.class_2339();
            for (int pX = 0; pX < sizeX; ++pX) {
                for (int pY = 0; pY < sizeY; ++pY) {
                    mPos.method_10101(baseBlockPos).method_10104(class_2350.field_11043, pX).method_10104(class_2350.field_11034, pY);
                    class_2680 blockState = method_37908().method_8320(mPos);
                    if (blockState.method_51367() || class_2312.method_9999(blockState)) continue;
                    return false;
                }
            }
        }

        return method_37908().method_8333(this, method_5829(), field_7098).isEmpty();
    }

    @Override
    protected void method_6892(@NotNull class_2350 facingDirection) {
        Validate.notNull(facingDirection);

        field_7099 = facingDirection;
        if (facingDirection.method_10166().method_10179()) {
            method_36457(0.0f);
            method_36456(field_7099.method_10161() * 90);
        } else {
            method_36457(-90 * facingDirection.method_10171().method_10181());
            method_36456(0.0f);
        }
        field_6004 = method_36455();
        field_5982 = method_36454();
        method_6895();
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        method_5841().method_12778(DATA_SIZE, class_3532.method_15340(size, 0, 2));
        this.size = size;
        method_6895();
    }

    public class_1799 getFrameItem() {
        return method_5841().method_12789(DATA_FRAME_ITEM);
    }

    public void setFrameItem(class_1799 stack) {
        method_5841().method_12778(DATA_FRAME_ITEM, stack);
    }

    public class_1799 getItem() {
        return method_5841().method_12789(DATA_ITEM);
    }

    public void setItem(class_1799 stack) {
        method_5841().method_12778(DATA_ITEM, stack);
    }

    protected void onItemChanged(class_1799 itemStack) {
        if (!itemStack.method_7960()) {
            itemStack.method_27320(this);
        }
    }

    public int getItemRotation() {
        return method_5841().method_12789(DATA_ITEM_ROTATION);
    }

    public void setItemRotation(int rotation) {
        method_5841().method_12778(DATA_ITEM_ROTATION, rotation % 4);
    }

    public boolean isGlowing() {
        return method_5841().method_12789(DATA_GLOWING);
    }

    public void setGlowing(boolean glowing) {
        method_5841().method_12778(DATA_GLOWING, glowing);
    }

    public boolean isStripped() {
        return method_5841().method_12789(DATA_STRIPPED);
    }

    public void setStripped(boolean stripped) {
        method_5841().method_12778(DATA_STRIPPED, stripped);
    }

    @Override
    public @NotNull class_1269 method_5688(@NotNull class_1657 player, @NotNull class_1268 hand) {
        class_1799 itemInHand = player.method_5998(hand);

        if (!isStripped()) {
            if (canStrip(itemInHand)) {
                if (!method_37908().field_9236) {
                    setStripped(true);
                    itemInHand.method_7956(1, player, (pl) -> pl.method_20236(hand));
                    method_32875(class_5712.field_28733, player);
                    method_5783(class_3417.field_14675, 1f, 1f);
                }
                return class_1269.field_5812;
            }
        }
        else if (itemInHand.method_31574(class_1802.field_8600)) {
            if (!method_37908().field_9236) {
                setStripped(false);
                itemInHand.method_7934(1);
                method_32875(class_5712.field_28733, player);
                method_6894();
            }
            return class_1269.field_5812;
        }

        if (itemInHand.method_7909() instanceof PhotographItem && getItem().method_7960()) {
            setItem(itemInHand.method_7972());
            itemInHand.method_7934(1);
            method_32875(class_5712.field_28733, player);
            method_5783(getAddItemSound(), 1.0f, 1.0f);
            return class_1269.field_5812;
        }

        if (itemInHand.method_31574(class_1802.field_28410) && !isGlowing()) {
            setGlowing(true);
            itemInHand.method_7934(1);
            if (!method_37908().field_9236) {
                method_43077(class_3417.field_28392);
                method_32875(class_5712.field_28733, player);
            }
            return class_1269.field_5812;
        }

        if (method_5767()) {
            if (itemInHand.method_31573(class_3489.field_15537)) {
                method_5648(false);
                itemInHand.method_7934(1);
                if (!method_37908().field_9236) {
                    method_6894();
                    method_32875(class_5712.field_28733, player);
                }
                return class_1269.field_5812;
            }
        }
        else if (itemInHand.method_31574(class_1802.field_8141)) {
            method_5648(true);
            itemInHand.method_7934(1);
            if (!method_37908().field_9236) {
                method_5783(Exposure.SoundEvents.FILTER_INSERT.get(), 0.8f, 1.0f);
                method_32875(class_5712.field_28733, player);
            }
            return class_1269.field_5812;
        }

        if (!getItem().method_7960()) {
            if (!method_37908().field_9236) {
                method_5783(getRotateSound(), 1.0F, method_37908().method_8409().method_43057() * 0.2f + 0.9f);
                setItemRotation(getItemRotation() + 1);
                method_32875(class_5712.field_28733, player);
            }
            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }

    public boolean canStrip(class_1799 stack) {
        return PlatformHelper.canStrip(stack);
    }

    @Override
    public boolean method_5643(@NotNull class_1282 damageSource, float amount) {
        if (method_5679(damageSource))
            return false;

        if (!damageSource.method_48789(class_8103.field_42249) && !getItem().method_7960()) {
            if (!method_37908().field_9236) {
                dropItem(damageSource.method_5529(), false);
                method_32875(class_5712.field_28733, damageSource.method_5529());
                method_5783(getRemoveItemSound(), 1.0f, 1.0f);
            }
            return true;
        }

        return super.method_5643(damageSource, amount);
    }

    @Override
    public void method_6889(@Nullable class_1297 brokenEntity) {
        method_5783(getBreakSound(), 1.0f, 1.0f);
        dropItem(brokenEntity, true);
        method_32875(class_5712.field_28733, brokenEntity);
    }

    protected void dropItem(@Nullable class_1297 entity, boolean dropSelf) {
        class_1799 itemStack = getItem();
        setItem(class_1799.field_8037);
        if (!method_37908().method_8450().method_8355(class_1928.field_19393))
            return;

        if (entity instanceof class_1657 player && player.method_7337())
            return;

        // Prevent item phasing through the block when placed on the ceiling (pointing DOWN)
        float yOffset = method_5735() == class_2350.field_11033 ? -0.3f : 0f;

        if (dropSelf)
            method_5699(getFrameItem(), yOffset);

        if (!itemStack.method_7960())
            method_5699(itemStack.method_7972(), yOffset);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (method_37908().field_9236 && isGlowing() && method_37908().method_8409().method_43057() < 0.003f) {
            class_238 bb = method_5829();
            class_2382 normal = method_5735().method_10163();
            method_37908().method_8406(class_2398.field_11207,
                    method_19538().field_1352 + (method_37908().method_8409().method_43057() * (bb.method_17939() * 0.75f) - bb.method_17939() * 0.75f / 2),
                    method_19538().field_1351 + (method_37908().method_8409().method_43057() * (bb.method_17940() * 0.75f) - bb.method_17940() * 0.75f / 2),
                    method_19538().field_1350 + (method_37908().method_8409().method_43057() * (bb.method_17941() * 0.75f) - bb.method_17941() * 0.75f / 2),
                    method_37908().method_8409().method_43057() * 0.02f * normal.method_10263(),
                    method_37908().method_8409().method_43057() * 0.02f * normal.method_10264(),
                    method_37908().method_8409().method_43057() * 0.02f * normal.method_10260());
        }
    }

    @Override
    public @NotNull class_5630 method_32318(int slot) {
        if (slot == 0) {
            return new class_5630(){

                @Override
                public @NotNull class_1799 method_32327() {
                    return PhotographFrameEntity.this.getItem();
                }

                @Override
                public boolean method_32332(class_1799 carried) {
                    PhotographFrameEntity.this.setItem(carried);
                    return true;
                }
            };
        }
        return super.method_32318(slot);
    }

    @Override
    protected @NotNull class_2561 method_23315() {
        if (isGlowing())
            return class_2561.method_43471("entity.exposure.glow_photograph_frame");
        return super.method_23315();
    }

    @Override
    public float method_51152() {
        return (getSize() + 1) / 2f + 0.35f;
    }

    @Override
    public void method_6894() {
        method_5783(getPlaceSound(), 1.0F, method_37908().method_8409().method_43057() * 0.2f + 0.7f);
    }

    public class_3414 getPlaceSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_FRAME_PLACE.get();
    }

    public class_3414 getBreakSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_FRAME_BREAK.get();
    }

    public class_3414 getAddItemSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_FRAME_ADD_ITEM.get();
    }

    public class_3414 getRemoveItemSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_FRAME_REMOVE_ITEM.get();
    }

    public class_3414 getRotateSound() {
        return Exposure.SoundEvents.PHOTOGRAPH_FRAME_ROTATE_ITEM.get();
    }
}
