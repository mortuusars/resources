package io.github.mortuusars.exposure.client;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.gui.ClientGUI;
import io.github.mortuusars.exposure.gui.screen.camera.ViewfinderControlsScreen;
import java.util.Optional;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_746;

public class MouseHandler {
    private static final boolean[] heldMouseButtons = new boolean[12];

    public static boolean handleMouseButtonPress(int button, int action, int modifiers) {
        if (button >= 0 && button < heldMouseButtons.length)
            heldMouseButtons[button] = action == class_3675.field_31997;

        class_746 player = class_310.method_1551().field_1724;
        if (player == null) {
            return false;
        }

        Optional<Camera<?>> cameraOpt = Camera.getCamera(player);
        if (cameraOpt.isEmpty()) {
            return false;
        }

        if (!(class_310.method_1551().field_1755 instanceof ViewfinderControlsScreen)) {
            if (!Config.Common.CAMERA_VIEWFINDER_ATTACK.get() && class_310.method_1551().field_1690.field_1886.method_1433(button))
                return true; // Block attacks

            if (ExposureClient.getCameraControlsKey().method_1433(button)) {
                ClientGUI.openViewfinderControlsScreen();
                // Do not cancel the event to keep sneaking
            }
            else if (Config.Client.VIEWFINDER_MIDDLE_CLICK_CONTROLS.get() && button == class_3675.field_32001) {
                ClientGUI.openViewfinderControlsScreen();
                return true;
            }
        }

        return false;
    }

    public static boolean isMouseButtonHeld(int button) {
        return button >= 0 && button < heldMouseButtons.length && heldMouseButtons[button];
    }
}
