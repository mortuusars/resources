package io.github.mortuusars.exposure.data;

import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public enum ExposureSize implements class_3542 {
    X1(1),
    X2(2),
    X3(3),
    X4(4);

    private final int multiplier;

    ExposureSize(int multiplier) {
        this.multiplier = multiplier;
    }

    public int getMultiplier() {
        return multiplier;
    }

    @Override
    public @NotNull String method_15434() {
        return name().toLowerCase();
    }

    public static @Nullable ExposureSize byName(String name) {
        for (ExposureSize value : values()) {
            if (value.method_15434().equals(name))
                return value;
        }
        return null;
    }
}
