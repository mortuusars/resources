package io.github.mortuusars.exposure.mixin;

import com.mojang.authlib.GameProfile;
import io.github.mortuusars.exposure.camera.Camera;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public abstract class LocalPlayerTickMixin extends class_1657 {
    public LocalPlayerTickMixin(class_1937 level, class_2338 pos, float yRot, GameProfile gameProfile) {
        super(level, pos, yRot, gameProfile);
    }

    @Inject(method = "tick", at = @At(value = "TAIL"))
    private void onPlayerTickEnd(CallbackInfo ci) {
        class_746 player = class_310.method_1551().field_1724;
        if (((class_746)(Object)this).equals(player)) {
            Camera.onLocalPlayerTick(player);
        }
    }
}
