package io.github.mortuusars.exposure.camera.viewfinder;

import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.data.filter.Filters;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.util.ItemAndStack;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class ViewfinderShader {
    @Nullable
    private static class_2960 previousShader;

    public static Optional<class_2960> getCurrent() {
        class_279 effect = class_310.method_1551().field_1773.method_3183();
        if (effect != null) {
            return Optional.of(new class_2960(effect.method_1260()));
        }

        return Optional.empty();
    }

    public static void setPrevious(@Nullable class_2960 shader) {
        previousShader = shader;
    }

    public static void restorePrevious() {
        if (previousShader != null && shouldRestorePreviousShaderEffect()) {
            applyShader(previousShader);
            previousShader = null;
        }
    }

    public static void applyShader(class_2960 shader) {
        @Nullable class_279 effect = class_310.method_1551().field_1773.method_3183();
        if (effect != null && effect.method_1260().equals(shader.toString())) {
            return;
        }

        class_310.method_1551().field_1773.method_3168(shader);
    }

    public static void removeShader() {
        class_310.method_1551().field_1773.method_3207();
    }

    public static void update() {
        Optional<Camera<?>> camera = Camera.getCamera(class_310.method_1551().field_1724);

        if (camera.isEmpty()) {
            removeShader();
            return;
        }

        ItemAndStack<? extends CameraItem> cameraItemAndStack = camera.get().get();
        cameraItemAndStack.getItem().getAttachment(cameraItemAndStack.getStack(), CameraItem.FILTER_ATTACHMENT)
                    .flatMap(Filters::getShaderOf)
                    .ifPresentOrElse(ViewfinderShader::applyShader, ViewfinderShader::removeShader);
    }

    public static boolean shouldRestorePreviousShaderEffect() {
        /*
            Cold Sweat applies a shader effect when having high temperature.
            If we restore effect after exiting viewfinder it will apply blur even if temp is normal.
            Not restoring shader is fine, Cold Sweat will reapply it if needed.
         */
        if (PlatformHelper.isModLoaded("cold_sweat") && previousShader != null
                && previousShader.toString().equals("minecraft:shaders/post/blobs2.json"))
            return false;
        else
            return previousShader != null;
    }
}
