package io.github.mortuusars.exposure.command.argument;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.mortuusars.exposure.data.ExposureSize;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2172;
import net.minecraft.class_2561;

public class ExposureSizeArgument implements ArgumentType<ExposureSize> {
    @Override
    public ExposureSize parse(StringReader reader) throws CommandSyntaxException {
        String string = reader.readString();
        @Nullable ExposureSize size = ExposureSize.byName(string);

        if (size == null)
            throw new SimpleCommandExceptionType(class_2561.method_43469("argument.enum.invalid", string)).create();

        return size;
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return class_2172.method_9264(Arrays.stream(ExposureSize.values())
                .map(ExposureSize::method_15434), builder);
    }

    public static ExposureSize getSize(final CommandContext<?> context, final String name) {
        return context.getArgument(name, ExposureSize.class);
    }
}
