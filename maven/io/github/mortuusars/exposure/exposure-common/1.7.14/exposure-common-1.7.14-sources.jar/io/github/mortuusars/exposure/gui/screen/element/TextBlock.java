package io.github.mortuusars.exposure.gui.screen.element;

import io.github.mortuusars.exposure.gui.screen.element.textbox.HorizontalAlignment;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_8001;

public class TextBlock extends class_339 {
    public int fontColor = 0xFF000000;
    public boolean drawShadow = false;
    public HorizontalAlignment alignment = HorizontalAlignment.LEFT;

    private final class_327 font;
    private final Function<class_2583, Boolean> componentClickedHandler;

    private List<class_5481> renderedLines;
    private List<class_5481> tooltipLines;

    public TextBlock(class_327 font, int x, int y, int width, int height, class_2561 message, Function<class_2583, Boolean> componentClickedHandler) {
        super(x, y, width, height, message);
        this.font = font;
        this.componentClickedHandler = componentClickedHandler;

        makeLines();
    }

    @Override
    public void method_25355(class_2561 message) {
        super.method_25355(message);
        makeLines();
    }

    protected void makeLines() {
        class_2561 text = method_25369();
        List<class_5481> lines = font.method_1728(text, method_25368());

        int availableLines = Math.min(lines.size(), field_22759 / font.field_2000);

        List<class_5481> visibleLines = new ArrayList<>();
        for (int i = 0; i < availableLines; i++) {
            class_5481 line = lines.get(i);

            if (i == availableLines - 1 && availableLines < lines.size()) {
                line = class_5481.method_30742(line,
                        class_2561.method_43470("...").method_27696(text.method_10866()).method_30937());
            }

            visibleLines.add(line);
        }

        List<class_5481> hiddenLines = Collections.emptyList();
        if (availableLines < lines.size()) {
            hiddenLines = new ArrayList<>(lines.stream()
                    .skip(availableLines)
                    .toList());

            hiddenLines.set(0, class_5481.method_30742(
                    class_5481.method_30747("...", text.method_10866()), hiddenLines.get(0)));
        }

        this.renderedLines = visibleLines;
        this.tooltipLines = hiddenLines;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        class_2583 style = getClickedComponentStyleAt(mouseX, mouseY);
        return button == 0 && style != null && componentClickedHandler.apply(style);
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) {
        narrationElementOutput.method_37034(class_6381.field_33788, method_25360());
    }

    @Override
    protected @NotNull class_5250 method_25360() {
        return method_25369().method_27661();
    }

    @Override
    protected void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        for (int i = 0; i < renderedLines.size(); i++) {
            class_5481 line = renderedLines.get(i);

            int x = method_46426() + alignment.align(method_25368(), font.method_30880(line));
            guiGraphics.method_51430(font, line, x, method_46427() + font.field_2000 * i, fontColor, drawShadow);
        }

        if (method_49606()) {
            class_2583 style = getClickedComponentStyleAt(mouseX, mouseY);
            if (style != null)
                guiGraphics.method_51441(this.font, style, mouseX, mouseY);
        }

        if (!tooltipLines.isEmpty() && method_25405(mouseX, mouseY))
            guiGraphics.method_51436(font, tooltipLines, class_8001.field_41687, mouseX, mouseY);
    }

    public @Nullable class_2583 getClickedComponentStyleAt(double mouseX, double mouseY) {
        if (renderedLines.isEmpty())
            return null;

        int x = class_3532.method_15357(mouseX - method_46426());
        int y = class_3532.method_15357(mouseY - method_46427());

        if (x < 0 || y < 0 || x > method_25368() || y > method_25364())
            return null;

        int hoveredLine = y / font.field_2000;

        if (hoveredLine >= renderedLines.size())
            return null;

        class_5481 line = renderedLines.get(hoveredLine);
        int lineStart = alignment.align(method_25368(), font.method_30880(line));

        if (x < lineStart)
            return null;


        return font.method_27527().method_30876(line, x - lineStart);
    }
}
