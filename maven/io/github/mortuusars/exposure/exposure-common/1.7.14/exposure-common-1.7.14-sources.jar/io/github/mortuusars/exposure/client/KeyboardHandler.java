package io.github.mortuusars.exposure.client;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.camera.CameraClient;
import io.github.mortuusars.exposure.camera.infrastructure.ZoomDirection;
import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.gui.ClientGUI;
import io.github.mortuusars.exposure.gui.screen.camera.ViewfinderControlsScreen;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_5498;
import net.minecraft.class_746;

public class KeyboardHandler {
    public static boolean handleViewfinderKeyPress(long windowId, int key, int scanCode, int action, int modifiers) {
        class_310 minecraft = class_310.method_1551();
        @Nullable class_746 player = minecraft.field_1724;
        if (player == null) {
            return false;
        }

        Optional<Camera<?>> cameraOptional = CameraClient.getCamera();
        if (cameraOptional.isEmpty()) {
            return false;
        }

        if (!Config.Common.CAMERA_VIEWFINDER_ATTACK.get()
                && class_310.method_1551().field_1690.field_1886.method_1417(key, scanCode)
                && !(class_310.method_1551().field_1755 instanceof ViewfinderControlsScreen)) {
            return true; // Block attacks
        }

        if (minecraft.field_1690.field_1824.method_1417(key, scanCode)) {
            if (action == class_3675.field_31997)
                return true;

            class_5498 currentCameraType = minecraft.field_1690.method_31044();
            class_5498 newCameraType = currentCameraType == class_5498.field_26664 ? class_5498.field_26666
                    : class_5498.field_26664;

            minecraft.field_1690.method_31043(newCameraType);
            return true;
        }


        if (key == class_3675.field_31958 || minecraft.field_1690.field_1822.method_1417(key, scanCode)) {
            if (action == class_3675.field_31997) { // TODO: Check if activating on release is not causing problems
                if (minecraft.field_1755 instanceof ViewfinderControlsScreen viewfinderControlsScreen) {
                    viewfinderControlsScreen.method_25419();
                } else {
                    CameraClient.deactivate(player);
                }
            }
            return true;
        }

        if (!Viewfinder.isLookingThrough())
            return false;

        if (!(minecraft.field_1755 instanceof ViewfinderControlsScreen)) {
            if (ExposureClient.getCameraControlsKey().method_1417(key, scanCode)) {
                ClientGUI.openViewfinderControlsScreen();
                return false; // Do not handle to keep sneaking
            }

            if (action == 1 || action == 2) { // Press or Hold
                if (key == class_3675.field_31933 || key == class_3675.field_31937) {
                    Viewfinder.zoom(ZoomDirection.IN, false);
                    return true;
                }

                if (key == 333 /*KEY_SUBTRACT*/ || key == class_3675.field_31941) {
                    Viewfinder.zoom(ZoomDirection.OUT, false);
                    return true;
                }
            }
        }

        return false;
    }
}
