package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.util.CameraInHand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_636;
import net.minecraft.class_746;

@Mixin(class_636.class)
public abstract class MultiPlayerGameModeMixin {
    @Inject(method = "interactAt", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/phys/EntityHitResult;getLocation()Lnet/minecraft/world/phys/Vec3;"),
            cancellable = true)
    void onInteractAt(class_1657 player, class_1297 target, class_3966 ray, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        if (exposure$useCamera(player)) {
            cir.setReturnValue(class_1269.field_21466);
        }
    }

    @Inject(method = "useItemOn", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/multiplayer/ClientLevel;getWorldBorder()Lnet/minecraft/world/level/border/WorldBorder;"),
            cancellable = true)
    void onUseItemOn(class_746 player, class_1268 hand, class_3965 result, CallbackInfoReturnable<class_1269> cir) {
        if (exposure$useCamera(player)) {
            cir.setReturnValue(class_1269.field_21466);
        }
    }

    @Unique
    private static boolean exposure$useCamera(class_1657 player) {
        class_636 gameMode = class_310.method_1551().field_1761;
        if (gameMode == null) {
            return false;
        }

        Optional<Camera<?>> cameraOpt = Camera.getCamera(player);
        if (cameraOpt.isEmpty()) {
            return false;
        }

        Camera<?> camera = cameraOpt.get();
        if (camera instanceof CameraInHand<?> cameraInHand) {
            gameMode.method_2919(player, cameraInHand.getHand());
            return true;
        }

        return false;
    }
}
