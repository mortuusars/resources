package io.github.mortuusars.exposure.camera.infrastructure;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_1799;
import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public enum FilmType implements class_3542 {
    BLACK_AND_WHITE("black_and_white", 255, 255, 255, 1.0F, 1.0F, 1.0F, 1.0F),
    COLOR("color", 180, 130, 110, 1.2F, 0.96F, 0.75F, 1.0F);

    @SuppressWarnings("deprecation")
    public static final class_3542.class_7292<FilmType> CODEC = class_3542.method_28140(FilmType::values);

    private final String name;
    public final int frameR, frameG, frameB;
    public final float filmR, filmG, filmB, filmA;

    FilmType(String name, int frameR, int frameG, int frameB, float filmR, float filmG, float filmB, float filmA) {
        this.name = name;
        this.frameR = frameR;
        this.frameG = frameG;
        this.frameB = frameB;

        this.filmR = filmR;
        this.filmG = filmG;
        this.filmB = filmB;
        this.filmA = filmA;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }

    /**
     * @return the FilmType specified by the given name or null if no such FilmType exists
     */
    @Nullable
    public static FilmType byName(@Nullable String name) {
        return CODEC.method_42633(name);
    }

    public class_1799 createItemStack() {
        return new class_1799(this == COLOR ? Exposure.Items.COLOR_FILM.get() : Exposure.Items.BLACK_AND_WHITE_FILM.get());
    }

    public class_1799 createDevelopedItemStack() {
        return new class_1799(this == COLOR ? Exposure.Items.DEVELOPED_COLOR_FILM.get() : Exposure.Items.DEVELOPED_BLACK_AND_WHITE_FILM.get());
    }
}
