package io.github.mortuusars.exposure.gui.screen;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.menu.ItemRenameMenu;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2855;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_465;
import net.minecraft.class_7919;

public class ItemRenameScreen extends class_465<ItemRenameMenu> {
    public static final class_2960 TEXTURE = Exposure.resource("textures/gui/item_rename.png");

    private class_342 name;

    public ItemRenameScreen(ItemRenameMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected void method_25426() {
        field_2792 = 206;
        field_2779 = 66;
        field_25269 = -999;
        field_25270 = -999;
        field_25267 = 28;
        super.method_25426();

        name = new class_342(this.field_22793, field_2776 + 32, field_2800 + 21, 142, 12, class_2561.method_43471("gui.exposure.item_rename.title"));
        name.method_1868(-1);
        name.method_1860(-1);
        name.method_1858(false);
        name.method_1880(ItemRenameMenu.MAX_NAME_LENGTH);
        name.method_1863(this::onNameChanged);
        name.method_1852(method_17577().getItemName());
        method_25429(name);
        method_48265(name);

        class_344 applyButton = new class_344(field_2776 + 133, field_2800 + 42, 19, 19,
                field_2792, 0, 19, TEXTURE, 256, 256,
                button -> confirm(), class_2561.method_43471("gui.exposure.item_rename.apply"));
        applyButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure.item_rename.apply")));
        method_37063(applyButton);

        class_344 cancelButton = new class_344(field_2776 + 154, field_2800 + 42, 19, 19,
                field_2792 + 19, 0, 19, TEXTURE, 256, 256,
                button -> cancel(), class_2561.method_43471("gui.exposure.item_rename.cancel"));
        cancelButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure.item_rename.cancel")));
        method_37063(cancelButton);
    }

    private void confirm() {
        method_17577().method_7604(class_310.method_1551().field_1724, ItemRenameMenu.APPLY_BUTTON_ID);
        Objects.requireNonNull(class_310.method_1551().field_1761).method_2900(method_17577().field_7763, ItemRenameMenu.APPLY_BUTTON_ID);
        method_25419();
    }

    private void cancel() {
        method_25419();
    }

    @Override
    public void method_25410(class_310 minecraft, int width, int height) {
        String string = this.name.method_1882();
        this.method_25423(minecraft, width, height);
        this.name.method_1852(string);
    }

    @Override
    public void method_37432() {
        super.method_37432();
        name.method_1865();
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        method_25420(guiGraphics);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        this.name.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        method_2380(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void method_2380(class_332 guiGraphics, int x, int y) {
        super.method_2380(guiGraphics, x, y);
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        guiGraphics.method_25302(TEXTURE, field_2776, field_2800, 0, 0, field_2792, field_2779);
    }


    private void onNameChanged(String name) {
        class_1799 itemStack = method_17577().method_7611(0).method_7677();
        if (!itemStack.method_7938() && name.equals(itemStack.method_7964().getString())) {
            name = "";
        }

        if (method_17577().setItemName(name) && class_310.method_1551().field_1724 != null) {
            class_310.method_1551().field_1724.field_3944.method_2883(new class_2855(name));
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            method_25419();
        }

        if (keyCode != class_3675.field_31948 && (name.method_25404(keyCode, scanCode, modifiers) || name.method_20315())) {
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == class_3675.field_32002 && name.method_25405(mouseX, mouseY)) {
            name.method_1852("");
            return true;
        }

        return super.method_25402(mouseX, mouseY, button);
    }
}
