package io.github.mortuusars.exposure.command;

import com.mojang.brigadier.CommandDispatcher;
import io.github.mortuusars.exposure.command.exposure.*;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

public class ExposureCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("exposure")
                .requires((stack) -> stack.method_9259(2))
                .then(LoadCommand.get())
                .then(ExposeCommand.get())
                .then(ExportCommand.get())
                .then(ShowCommand.get())
                .then(DebugCommand.get()));
    }
}
