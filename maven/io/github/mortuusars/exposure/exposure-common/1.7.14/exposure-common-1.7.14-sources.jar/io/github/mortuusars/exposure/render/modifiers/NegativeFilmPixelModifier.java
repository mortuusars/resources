package io.github.mortuusars.exposure.render.modifiers;

import net.minecraft.class_3532;
import net.minecraft.class_5253;

@SuppressWarnings("ClassCanBeRecord")
public class NegativeFilmPixelModifier implements IPixelModifier {
    public final boolean simulateFilmTransparency;

    public NegativeFilmPixelModifier(boolean simulateFilmTransparency) {
        this.simulateFilmTransparency = simulateFilmTransparency;
    }

    @Override
    public String getIdSuffix() {
        return simulateFilmTransparency ? "_negative_film" : "_negative";
    }

    @Override
    public int modifyPixel(int ABGR) {
        int alpha = class_5253.class_8045.method_48342(ABGR);
        int blue = class_5253.class_8045.method_48347(ABGR);
        int green = class_5253.class_8045.method_48346(ABGR);
        int red = class_5253.class_8045.method_48345(ABGR);

        if (simulateFilmTransparency) {
            // Modify opacity to make lighter colors transparent, like in real film.
            int brightness = (blue + green + red) / 3;
            int opacity = (int) class_3532.method_15363(brightness * 1.5f, 0, 255);
            alpha = (alpha * opacity) / 255;
        }

        // Invert
        blue = 255 - blue;
        green = 255 - green;
        red = 255 - red;

        return class_5253.class_8045.method_48344(alpha, blue, green, red);
    }

    @Override
    public String toString() {
        return "NegativeFilmPixelModifier{simulateTransparency=" + simulateFilmTransparency + '}';
    }
}
