package io.github.mortuusars.exposure.camera.viewfinder;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.camera.CameraClient;
import io.github.mortuusars.exposure.gui.screen.camera.ViewfinderControlsScreen;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.item.FilmRollItem;
import io.github.mortuusars.exposure.util.GuiUtil;
import io.github.mortuusars.exposure.util.ItemAndStack;
import io.github.mortuusars.exposure.util.Rect2f;
import org.joml.Matrix4f;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;

public class ViewfinderOverlay {
    public static final class_2960 VIEWFINDER_TEXTURE = Exposure.resource("textures/gui/viewfinder/viewfinder.png");
    public static final class_2960 NO_FILM_ICON_TEXTURE = Exposure.resource("textures/gui/viewfinder/icon/no_film.png");
    public static final class_2960 REMAINING_FRAMES_ICON_TEXTURE = Exposure.resource("textures/gui/viewfinder/icon/remaining_frames.png");

    public static Rect2f opening = new Rect2f(0, 0, 0, 0);

    private static final class_4587 POSE_STACK = new class_4587();
    private static class_310 minecraft = class_310.method_1551();
    private static class_1657 player = minecraft.field_1724;

    private static int backgroundColor;

    private static float scale = 1f;

    private static Float xRot = null;
    private static Float yRot = null;
    private static Float xRot0 = null;
    private static Float yRot0 = null;

    public static void setup() {
        minecraft = class_310.method_1551();
        player = minecraft.field_1724;

        backgroundColor = Config.Client.getBackgroundColor();
        scale = 0.5f;
    }

    public static float getScale() {
        return scale;
    }

    public static void render() {
        final int width = minecraft.method_22683().method_4486();
        final int height = minecraft.method_22683().method_4502();

        scale = class_3532.method_16439(Math.min(0.8f * minecraft.method_1534(), 0.8f), scale, 1f);
        float openingSize = Math.min(width, height);

        opening = new Rect2f((width - openingSize) / 2f, (height - openingSize) / 2f, openingSize, openingSize);

        if (minecraft.field_1690.field_1842)
            return;

        Optional<Camera<?>> cameraOpt = CameraClient.getCamera();
        if (cameraOpt.isEmpty()) {
            return;
        }

        Camera<?> camera = cameraOpt.get();
        CameraItem cameraItem = camera.get().getItem();
        class_1799 cameraStack = camera.get().getStack();

        if (xRot == null || yRot == null || xRot0 == null || yRot0 == null) {
            xRot = player.method_36455();
            yRot = player.method_36454();
            xRot0 = xRot;
            yRot0 = yRot;
        }
        float delta = Math.min(0.7f * minecraft.method_1534(), 0.8f);
        xRot0 = class_3532.method_16439(delta, xRot0, xRot);
        yRot0 = class_3532.method_16439(delta, yRot0, yRot);
        xRot = player.method_36455();
        yRot = player.method_36454();
        float xDelay = (xRot - xRot0);
        float yDelay = (yRot - yRot0);
        // Adjust for gui scale:
        xDelay *= width / (float)class_310.method_1551().method_22683().method_4489();
        yDelay *= height / (float)class_310.method_1551().method_22683().method_4506();
        xDelay *= 3.5f;
        yDelay *= 3.5f;

        class_4587 poseStack = POSE_STACK;
        poseStack.method_22903();
        poseStack.method_46416(width / 2f, height / 2f, 0);
        poseStack.method_22905(scale, scale, scale);

        float attackAnim = player.method_6055(minecraft.method_1488());
        if (attackAnim > 0.5f)
            attackAnim = 1f - attackAnim;
        poseStack.method_22905(1f - attackAnim * 0.4f, 1f - attackAnim * 0.6f, 1f - attackAnim * 0.4f);
        poseStack.method_46416(width / 16f * attackAnim, width / 5f * attackAnim, 0);
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(class_3532.method_16439(attackAnim, 0, 10)));
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(class_3532.method_16439(attackAnim, 0, 100)));

        poseStack.method_46416(-width / 2f - yDelay, -height / 2f - xDelay, 0);

        if (minecraft.field_1690.method_42448().method_41753())
            bobView(poseStack, minecraft.method_1488());

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        // -9999 to cover all screen when poseStack is scaled down.
        // Left
        drawRect(poseStack, -9999, opening.y, opening.x, opening.y + opening.height, backgroundColor);
        // Right
        drawRect(poseStack, opening.x + opening.width, opening.y, width + 9999, opening.y + opening.height, backgroundColor);
        // Top
        drawRect(poseStack, -9999, -9999, width + 9999, opening.y, backgroundColor);
        // Bottom
        drawRect(poseStack, -9999, opening.y + opening.height, width + 9999, height + 9999, backgroundColor);

        // Shutter
        if (cameraItem.isShutterOpen(cameraStack)) {
            drawRect(poseStack, opening.x, opening.y, opening.x + opening.width, opening.y + opening.height, 0xfa1f1d1b);
        }

        // Opening Texture
        RenderSystem.enableBlend();
        RenderSystem.setShaderTexture(0, VIEWFINDER_TEXTURE);
        GuiUtil.blit(poseStack, opening.x, opening.x + opening.width, opening.y, opening.y + opening.height, 0f, 0f, 1f, 0f, 1f);

        // Guide
        RenderSystem.setShaderTexture(0, Exposure.resource("textures/gui/viewfinder/composition_guide/" +
                cameraItem.getCompositionGuide(cameraStack).getId() + ".png"));
        GuiUtil.blit(poseStack, opening.x, opening.x + opening.width, opening.y, opening.y + opening.height, -1f, 0f, 1f, 0f, 1f);

        if (!(minecraft.field_1755 instanceof ViewfinderControlsScreen)) {
            renderIcons(poseStack, cameraItem, cameraStack);
        }

        poseStack.method_22909();
    }

    private static void renderIcons(class_4587 poseStack, CameraItem cameraItem, class_1799 cameraStack) {
        Optional<ItemAndStack<FilmRollItem>> film = cameraItem.getFilm(cameraStack);
        if (film.isEmpty() || !film.get().getItem().canAddFrame(film.get().getStack())) {
            RenderSystem.setShaderTexture(0, NO_FILM_ICON_TEXTURE);
            GuiUtil.blit(poseStack, (opening.x + (opening.width / 2) - 12), opening.y + opening.height - 19,
                    24, 19, 0, 0, 24, 19, 0);
        }
        else {
            ItemAndStack<FilmRollItem> f = film.get();
            int maxFrames = f.getItem().getMaxFrameCount(f.getStack());
            int exposedFrames = f.getItem().getExposedFramesCount(f.getStack());
            int remainingFrames = Math.max(0, maxFrames - exposedFrames);
            if (maxFrames > 5 && remainingFrames <= 3) {
                RenderSystem.setShaderTexture(0, REMAINING_FRAMES_ICON_TEXTURE);
                GuiUtil.blit(poseStack, (opening.x + (opening.width / 2) - 17), opening.y + opening.height - 15,
                        33, 15, 0, (remainingFrames - 1) * 15, 33, 45, 0);
            }
        }
    }

    public static void drawRect(class_4587 poseStack, float minX, float minY, float maxX, float maxY, int color) {
        if (minX < maxX) {
            float temp = minX;
            minX = maxX;
            maxX = temp;
        }

        if (minY < maxY) {
            float temp = minY;
            minY = maxY;
            maxY = temp;
        }

        float alpha = (color >> 24 & 255) / 255.0F;
        float r = (color >> 16 & 255) / 255.0F;
        float g = (color >> 8 & 255) / 255.0F;
        float b = (color & 255) / 255.0F;

        Matrix4f matrix = poseStack.method_23760().method_23761();

        class_287 bufferbuilder = class_289.method_1348().method_1349();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34540);
        bufferbuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1576);
        bufferbuilder.method_22918(matrix, minX, maxY, 0.0F).method_22915(r, g, b, alpha).method_1344();
        bufferbuilder.method_22918(matrix, maxX, maxY, 0.0F).method_22915(r, g, b, alpha).method_1344();
        bufferbuilder.method_22918(matrix, maxX, minY, 0.0F).method_22915(r, g, b, alpha).method_1344();
        bufferbuilder.method_22918(matrix, minX, minY, 0.0F).method_22915(r, g, b, alpha).method_1344();
        class_286.method_43433(bufferbuilder.method_1326());
        RenderSystem.disableBlend();
    }

    public static void bobView(class_4587 poseStack, float partialTicks) {
        if (minecraft.method_1560() instanceof class_1657 pl) {
            float f = pl.field_5973 - pl.field_6039;
            float f1 = -(pl.field_5973 + f * partialTicks);
            float f2 = class_3532.method_16439(partialTicks, pl.field_7505, pl.field_7483);
            poseStack.method_22904((class_3532.method_15374(f1 * (float) Math.PI) * f2 * 16F), (-Math.abs(class_3532.method_15362(f1 * (float) Math.PI) * f2 * 32F)), 0.0D);
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(class_3532.method_15374(f1 * (float) Math.PI) * f2 * 3.0F));
        }
    }
}

