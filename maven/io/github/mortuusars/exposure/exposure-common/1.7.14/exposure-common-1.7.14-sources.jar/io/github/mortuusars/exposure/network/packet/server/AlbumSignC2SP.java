package io.github.mortuusars.exposure.network.packet.server;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.item.AlbumItem;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;

public record AlbumSignC2SP(String title) implements IPacket {
    public static final class_2960 ID = Exposure.resource("album_sign");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public static AlbumSignC2SP fromBuffer(class_2540 buffer) {
        return new AlbumSignC2SP(buffer.method_19772());
    }

    @Override
    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10814(title);
        return buffer;
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        Preconditions.checkState(player != null, "Cannot handle packet: Player was null");

        class_1268 hand;
        if (player.method_5998(class_1268.field_5808).method_7909() instanceof AlbumItem albumItem && albumItem.isEditable())
            hand = class_1268.field_5808;
        else if (player.method_5998(class_1268.field_5810).method_7909() instanceof AlbumItem albumItem && albumItem.isEditable())
            hand = class_1268.field_5810;
        else
            throw new IllegalStateException("Player receiving this packet should have an album in one of the hands.");

        class_1799 albumStack = player.method_5998(hand);
        AlbumItem albumItem = (AlbumItem) albumStack.method_7909();

        class_1799 signedAlbum = albumItem.sign(albumStack, title, player.method_5477().getString());
        player.method_6122(hand, signedAlbum);

        player.method_37908().method_43129(null, player, class_3417.field_20671, class_3419.field_15248, 0.8f ,1f);

        return true;
    }
}
