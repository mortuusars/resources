package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public record CreateChromaticExposureS2CP(class_2487 red, class_2487 green, class_2487 blue, String exposureId) implements IPacket {
    public static final class_2960 ID = Exposure.resource("create_chromatic_exposure");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10794(red);
        buffer.method_10794(green);
        buffer.method_10794(blue);
        buffer.method_10814(exposureId);
        return buffer;
    }

    public static CreateChromaticExposureS2CP fromBuffer(class_2540 buffer) {
        return new CreateChromaticExposureS2CP(buffer.method_30617(), buffer.method_30617(), buffer.method_30617(), buffer.method_19772());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        ClientPacketsHandler.createChromaticExposure(this);
        return true;
    }
}
