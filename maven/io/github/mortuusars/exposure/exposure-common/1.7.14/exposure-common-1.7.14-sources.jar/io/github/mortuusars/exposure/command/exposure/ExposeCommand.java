package io.github.mortuusars.exposure.command.exposure;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.ExposeCommandS2CP;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_3222;

public class ExposeCommand {
    public static LiteralArgumentBuilder<class_2168> get() {
        return class_2170.method_9247("expose")
                .executes(context -> expose(context.getSource(), Integer.MAX_VALUE))
                .then(class_2170.method_9244("size", IntegerArgumentType.integer(1, 2048))
                        .executes(context -> expose(context.getSource(), IntegerArgumentType.getInteger(context, "size"))));
    }

    private static int expose(class_2168 stack, int size) throws CommandSyntaxException {
        class_3222 player = stack.method_9207();
        Packets.sendToClient(new ExposeCommandS2CP(size), player);
        return 0;
    }
}
