package io.github.mortuusars.exposure.camera.capture.component;

import io.github.mortuusars.exposure.camera.capture.Capture;
import io.github.mortuusars.exposure.util.ColorChannel;
import net.minecraft.class_5253;

@SuppressWarnings("ClassCanBeRecord")
public class SelectiveChannelBlackAndWhiteComponent implements ICaptureComponent {
    private final ColorChannel channel;

    public SelectiveChannelBlackAndWhiteComponent(ColorChannel channel) {
        this.channel = channel;
    }

    public ColorChannel getChannel() {
        return channel;
    }

    @Override
    public int modifyPixel(Capture capture, int colorABGR) {
        int alpha = class_5253.class_8045.method_48342(colorABGR);

        if (channel == ColorChannel.RED) {
            int red = class_5253.class_8045.method_48345(colorABGR);
            return class_5253.class_8045.method_48344(alpha, red, red, red);
        }
        if (channel == ColorChannel.GREEN) {
            int green = class_5253.class_8045.method_48346(colorABGR);
            return class_5253.class_8045.method_48344(alpha, green, green, green);
        } else {
            int blue = class_5253.class_8045.method_48347(colorABGR);
            return class_5253.class_8045.method_48344(alpha, blue, blue, blue);
        }
    }
}
