package io.github.mortuusars.exposure.util;

import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;

public class LevelUtil {
    public static int getLightLevelAt(class_1937 level, class_2338 pos) {
        level.method_8533(); // This updates 'getSkyDarken' on the client. Otherwise, it always returns 0.
        int skyBrightness = level.method_8314(class_1944.field_9284, pos);
        int blockBrightness = level.method_8314(class_1944.field_9282, pos);
        return skyBrightness < 15 ?
                Math.max(blockBrightness, (int) (skyBrightness * ((15 - level.method_8594()) / 15f))) :
                Math.max(blockBrightness, 15 - level.method_8594());
    }
}
