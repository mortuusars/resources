package io.github.mortuusars.exposure.util;

import io.github.mortuusars.exposure.Exposure;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_3542;

public enum ColorChannel implements class_3542 {
    RED(0xFFD8523E),
    GREEN(0xFF7BC64B),
    BLUE(0xFF4E73CE);

    private final int color;

    ColorChannel(int color) {
        this.color = color;
    }

    public int getRepresentationColor() {
        return color;
    }

    public static Optional<ColorChannel> fromStack(class_1799 stack) {
        if (stack.method_31573(Exposure.Tags.Items.RED_FILTERS))
            return Optional.of(RED);
        else if (stack.method_31573(Exposure.Tags.Items.GREEN_FILTERS))
            return Optional.of(GREEN);
        else if (stack.method_31573(Exposure.Tags.Items.BLUE_FILTERS))
            return Optional.of(BLUE);
        else
            return Optional.empty();
    }

    public static ColorChannel fromStringOrDefault(String serializedName, ColorChannel defaultValue) {
        for (ColorChannel value : values()) {
            if (value.method_15434().equals(serializedName))
                return value;
        }
        return defaultValue;
    }

    public static Optional<ColorChannel> fromString(String serializedName) {
        for (ColorChannel value : values()) {
            if (value.method_15434().equals(serializedName))
                return Optional.of(value);
        }
        return Optional.empty();
    }

    @Override
    public @NotNull String method_15434() {
        return toString().toLowerCase();
    }
}
