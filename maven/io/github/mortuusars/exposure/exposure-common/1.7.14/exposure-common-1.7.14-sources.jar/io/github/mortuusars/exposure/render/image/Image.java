package io.github.mortuusars.exposure.render.image;

import net.minecraft.class_1011;

public class Image implements IImage {
    private final String name;
    private final class_1011 image;

    public Image(String name, class_1011 image) {
        this.name = name;
        this.image = image;
    }

    @Override
    public String getImageId() {
        return name;
    }

    @Override
    public int getWidth() {
        return image.method_4307();
    }

    @Override
    public int getHeight() {
        return image.method_4323();
    }

    @Override
    public int getPixelABGR(int x, int y) {
        return image.method_4315(x, y); // this returns ABGR
    }
}
