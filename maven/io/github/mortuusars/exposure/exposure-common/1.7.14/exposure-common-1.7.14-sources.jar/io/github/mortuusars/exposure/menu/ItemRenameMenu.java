package io.github.mortuusars.exposure.menu;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_1277;
import net.minecraft.class_155;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1706;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ItemRenameMenu extends class_1703 {
    public static final int MAX_NAME_LENGTH = class_1706.field_30751;
    public static final int APPLY_BUTTON_ID = 0;

    protected final class_1661 playerInventory;
    protected final int slot;
    protected final class_1792 item;

    protected String itemName;

    public ItemRenameMenu(int containerId, class_1661 playerInventory, int slot) {
        super(Exposure.MenuTypes.ITEM_RENAME.get(), containerId);
        this.playerInventory = playerInventory;
        this.slot = slot;
        class_1799 itemStack = playerInventory.method_5438(slot);
        Preconditions.checkArgument(!itemStack.method_7960(), "Cannot rename empty item in slot " + slot);
        this.item = itemStack.method_7909();
        this.itemName = itemStack.method_7964().getString();

        class_1277 container = new class_1277(itemStack);
        method_7621(new class_1735(container, 0, 4, 16) {
            @Override
            public boolean method_7680(class_1799 stack) { return false; }
            @Override
            public boolean method_7674(class_1657 player) { return false; }
            @Override
            public boolean method_51306() { return false; }
        });
    }

    public static ItemRenameMenu fromBuffer(int containerId, class_1661 playerInventory, class_2540 buffer) {
        return new ItemRenameMenu(containerId, playerInventory, buffer.readInt());
    }

    public class_1657 getPlayer() {
        return playerInventory.field_7546;
    }

    @Override
    public @NotNull class_1799 method_7601(class_1657 player, int index) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return item.getClass().isAssignableFrom(player.method_31548().method_5438(slot).method_7909().getClass());
    }

    public void updateResult() {
        class_1799 itemStack = method_7611(0).method_7677();
        class_1799 itemStack2 = itemStack.method_7972();

        if (class_156.method_51894(itemName)) {
            if (itemStack.method_7938()) {
                itemStack2.method_7925();
            }
        } else if (!itemName.equals(itemStack.method_7964().getString())) {
            itemStack2.method_7977(class_2561.method_43470(itemName));
        }

        method_7611(0).method_7673(itemStack2);
        method_7623();
    }

    public String getItemName() {
        return itemName;
    }

    public boolean setItemName(String itemName) {
        String string = validateName(itemName);
        if (string == null || !string.equals(itemName)) {
            return false;
        }

        this.itemName = string;

        updateResult();
        return true;
    }

    @Nullable
    public String validateName(String itemName) {
        String string = class_155.method_644(itemName);
        if (string.length() <= MAX_NAME_LENGTH) {
            return string;
        }
        return null;
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (id == APPLY_BUTTON_ID) {
            playerInventory.method_5447(slot, method_7611(0).method_7677());
        }
        return super.method_7604(player, id);
    }
}
