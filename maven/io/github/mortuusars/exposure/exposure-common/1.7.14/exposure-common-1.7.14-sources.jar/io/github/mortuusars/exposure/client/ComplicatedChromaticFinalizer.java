package io.github.mortuusars.exposure.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.capture.component.ExposureStorageSaveComponent;
import io.github.mortuusars.exposure.camera.capture.converter.DitheringColorConverter;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.data.storage.ExposureSavedData;
import io.github.mortuusars.exposure.render.image.ExposureDataImage;
import io.github.mortuusars.exposure.render.image.IImage;
import io.github.mortuusars.exposure.render.image.TextureImage;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedList;
import java.util.Queue;
import net.minecraft.class_1011;
import net.minecraft.class_2487;
import net.minecraft.class_5253;

public class ComplicatedChromaticFinalizer {
    private static final Queue<ChromaticData> processingQueue = new LinkedList<>();

    public static void finalizeChromatic(class_2487 red, class_2487 green, class_2487 blue, String exposureId) {
        processingQueue.add(new ChromaticData(red, green, blue, exposureId, 200));
    }

    public static void clientTick() {
        @Nullable ChromaticData item = processingQueue.peek();
        if (item == null) return;

        item.tick();

        IImage[] images = item.getImages();
        if (images.length >= 3) {
            processChromatic(images[0], images[1], images[2], item.exposureId);
            processingQueue.remove();
        }
        else if (item.attempts < 0) {
            ChromaticData removedItem = processingQueue.remove();
            for (IImage image : removedItem.images) {
                image.close();
            }
            Exposure.LOGGER.error("Cannot finalize a chromatic {}. Couldn't get images in time. {}, {}, {}",
                    removedItem.exposureId, removedItem.red, removedItem.green, removedItem.blue);
        }
    }

    private static void processChromatic(IImage red, IImage green, IImage blue, String exposureId) {
        int width = Math.min(red.getWidth(), Math.min(green.getWidth(), blue.getWidth()));
        int height = Math.min(red.getHeight(), Math.min(green.getHeight(), blue.getHeight()));
        if (width <= 0 ||height <= 0) {
            Exposure.LOGGER.error("Cannot create Chromatic Photograph: Width and Height should be larger than 0. " +
                    "Width '{}', Height: '{}'.", width, height);
            return;
        }

        byte[] mapColorPixels;

        try (class_1011 image = new class_1011(width, height, false)) {
            for (int x = 0; x < image.method_4307(); x++) {
                for (int y = 0; y < image.method_4323(); y++) {
                    int a = class_5253.class_8045.method_48342(red.getPixelABGR(x, y));
                    int b = class_5253.class_8045.method_48347(blue.getPixelABGR(x, y));
                    int g = class_5253.class_8045.method_48346(green.getPixelABGR(x, y));
                    int r = class_5253.class_8045.method_48345(red.getPixelABGR(x, y));

                    int abgr = class_5253.class_8045.method_48344(a, b, g, r);

                    image.method_4305(x, y, abgr);
                }
            }

            mapColorPixels = new DitheringColorConverter().convert(image);
        }

        class_2487 properties = new class_2487();
        properties.method_10582(ExposureSavedData.TYPE_PROPERTY, FilmType.COLOR.method_15434());
        long unixTime = System.currentTimeMillis() / 1000L;
        properties.method_10544(ExposureSavedData.TIMESTAMP_PROPERTY, unixTime);

        ExposureSavedData resultData = new ExposureSavedData(width, height, mapColorPixels, properties);

        ExposureStorageSaveComponent saveComponent = new ExposureStorageSaveComponent(exposureId, true);
        saveComponent.save(resultData.getPixels(), resultData.getWidth(), resultData.getHeight(), properties);

    }

    private static class ChromaticData {
        private final class_2487 red, green, blue;
        private final String exposureId;
        private final IImage[] images = new IImage[3];
        private int attempts;

        public ChromaticData(class_2487 red, class_2487 green, class_2487 blue, String exposureId, int attempts) {
            this.red = red;
            this.green = green;
            this.blue = blue;
            this.exposureId = exposureId;
            this.attempts = attempts;
        }

        public void tick() {
            if (images[0] == null) {
                images[0] = tryGetData(red);
            }

            if (images[1] == null) {
                images[1] = tryGetData(green);
            }

            if (images[2] == null) {
                images[2] = tryGetData(blue);
            }

            attempts--;
        }

        private @Nullable IImage tryGetData(class_2487 frame) {
            return FrameData.getIdOrTexture(frame)
                    .map(id ->  ExposureClient.getExposureStorage().getOrQuery(id)
                                    .map(data -> new ExposureDataImage(id, data))
                                    .orElse(null),
                            TextureImage::new);
        }

        public IImage[] getImages() {
            return images;
        }
    }
}
