package io.github.mortuusars.exposure.network.packet.server;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public record CameraSetZoomC2SP(double focalLength) implements IPacket {
    public static final class_2960 ID = Exposure.resource("camera_set_zoom");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.writeDouble(focalLength);
        return buffer;
    }

    public static CameraSetZoomC2SP fromBuffer(class_2540 buffer) {
        return new CameraSetZoomC2SP(buffer.readDouble());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        Preconditions.checkState(player != null, "Cannot handle packet {}: Player was null", ID);
        Camera.getCamera(player).ifPresent(c -> c.get().getItem().setZoom(c.get().getStack(), focalLength));
        return true;
    }
}
