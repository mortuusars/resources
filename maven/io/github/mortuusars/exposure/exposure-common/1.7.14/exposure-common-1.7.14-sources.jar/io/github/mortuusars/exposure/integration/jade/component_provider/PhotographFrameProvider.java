package io.github.mortuusars.exposure.integration.jade.component_provider;

import io.github.mortuusars.exposure.entity.PhotographFrameEntity;
import io.github.mortuusars.exposure.integration.jade.ExposureJadePlugin;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import snownee.jade.api.EntityAccessor;
import snownee.jade.api.IEntityComponentProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.config.IPluginConfig;
import snownee.jade.api.ui.IDisplayHelper;

public enum PhotographFrameProvider implements IEntityComponentProvider {
    INSTANCE;

    public void appendTooltip(ITooltip tooltip, EntityAccessor accessor, IPluginConfig config) {
        if (accessor.getEntity() instanceof PhotographFrameEntity photographFrame) {
            class_1799 item = photographFrame.getItem();
            if (!item.method_7960()) {
                tooltip.add(IDisplayHelper.get().stripColor(item.method_7964()));
            }
        }
    }

    public class_2960 getUid() {
        return ExposureJadePlugin.PHOTOGRAPH_FRAME;
    }
}