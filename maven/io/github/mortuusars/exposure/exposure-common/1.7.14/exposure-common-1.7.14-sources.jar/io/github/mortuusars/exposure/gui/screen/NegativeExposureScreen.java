package io.github.mortuusars.exposure.gui.screen;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.gui.screen.element.Pager;
import io.github.mortuusars.exposure.render.image.RenderedImageProvider;
import io.github.mortuusars.exposure.render.image.ExposureDataImage;
import io.github.mortuusars.exposure.render.image.IImage;
import io.github.mortuusars.exposure.render.image.TextureImage;
import io.github.mortuusars.exposure.data.storage.ExposureSavedData;
import io.github.mortuusars.exposure.render.modifiers.ExposurePixelModifiers;
import io.github.mortuusars.exposure.util.GuiUtil;
import io.github.mortuusars.exposure.util.PagingDirection;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_289;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_4597;
import net.minecraft.class_765;

public class NegativeExposureScreen extends ZoomableScreen {
    public static final class_2960 TEXTURE = Exposure.resource("textures/gui/film_frame_inspect.png");
    public static final int BG_SIZE = 78;
    public static final int FRAME_SIZE = 54;

    private final Pager pager = new Pager(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get());
    private final List<Either<String, class_2960>> exposures;

    public NegativeExposureScreen(List<Either<String, class_2960>> exposures) {
        super(class_2561.method_43473());
        this.exposures = exposures;
        Preconditions.checkArgument(exposures != null && !exposures.isEmpty());

        zoom.step = 2f;
        zoom.defaultZoom = 1f;
        zoom.targetZoom = 1f;
        zoom.minZoom = zoom.defaultZoom / (float)Math.pow(zoom.step, 1f);
        zoom.maxZoom = zoom.defaultZoom * (float)Math.pow(zoom.step, 5f);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        zoomFactor = 1f / (field_22787.field_1690.method_42474().method_41753() + 1);
        class_344 previousButton = new class_344(0, (int) (field_22790 / 2f - 16 / 2f), 16, 16,
                0, 0, 16, PhotographScreen.WIDGETS_TEXTURE, 256, 256,
                button -> pager.changePage(PagingDirection.PREVIOUS), class_2561.method_43471("gui.exposure.previous_page"));
        method_37063(previousButton);

        class_344 nextButton = new class_344(field_22789 - 16, (int) (field_22790 / 2f - 16 / 2f), 16, 16,
                16, 0, 16, PhotographScreen.WIDGETS_TEXTURE, 256, 256,
                button -> pager.changePage(PagingDirection.NEXT), class_2561.method_43471("gui.exposure.next_page"));
        method_37063(nextButton);

        pager.init(exposures.size(), true, previousButton, nextButton);
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        pager.update();

        method_25420(guiGraphics);

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        Either<String, class_2960> idOrTexture = exposures.get(pager.getCurrentPage());

        @Nullable FilmType type = idOrTexture.map(
                id -> ExposureClient.getExposureStorage().getOrQuery(id).map(ExposureSavedData::getType)
                        .orElse(FilmType.BLACK_AND_WHITE),
                texture -> (texture.method_12832().endsWith("_black_and_white") || texture.method_12832()
                        .endsWith("_bw")) ? FilmType.COLOR : FilmType.BLACK_AND_WHITE);
        if (type == null)
            type = FilmType.BLACK_AND_WHITE;

        @Nullable IImage image = idOrTexture.map(
                id -> ExposureClient.getExposureStorage().getOrQuery(id)
                        .map(data -> new ExposureDataImage(id, data)).orElse(null),
                TextureImage::getTexture
        );

        if (image == null)
            return;

        int width = image.getWidth();
        int height = image.getHeight();

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(x + this.field_22789 / 2f, y + this.field_22790 / 2f, 0);
        guiGraphics.method_51448().method_22905(scale, scale, scale);
        guiGraphics.method_51448().method_46416(-width / 2f, -height / 2f, 0);

        {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShaderTexture(0, TEXTURE);

            guiGraphics.method_51448().method_22903();
            float scale = Math.max((float) width / (FRAME_SIZE), (float) height / (FRAME_SIZE));
            guiGraphics.method_51448().method_22905(scale, scale, scale);
            guiGraphics.method_51448().method_46416(-12, -12, 0);

            GuiUtil.blit(guiGraphics.method_51448(), 0, 0, BG_SIZE, BG_SIZE, 0, 0, 256, 256, 0);

            RenderSystem.setShaderColor(type.filmR, type.filmG, type.filmB, type.filmA);
            GuiUtil.blit(guiGraphics.method_51448(), 0, 0, BG_SIZE, BG_SIZE, 0, BG_SIZE, 256, 256, 0);

            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

            guiGraphics.method_51448().method_22909();
        }

        class_4597.class_4598 bufferSource = class_4597.method_22991(class_289.method_1348().method_1349());
        ExposureClient.getExposureRenderer().render(new RenderedImageProvider(image), ExposurePixelModifiers.NEGATIVE_FILM,
                guiGraphics.method_51448(), bufferSource, 0, 0, width, height, 0, 0, 1, 1,
                class_765.field_32767, type.frameR, type.frameG, type.frameB, 255);
        bufferSource.method_22993();

        guiGraphics.method_51448().method_22909();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        return pager.handleKeyPressed(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        return pager.handleKeyReleased(keyCode, scanCode, modifiers) || super.method_16803(keyCode, scanCode, modifiers);
    }
}
