package io.github.mortuusars.exposure.gui.screen.element;

import net.minecraft.class_332;
import org.jetbrains.annotations.NotNull;

public interface IElementWithTooltip {
    void renderToolTip(@NotNull class_332 guiGraphics, int mouseX, int mouseY);
}
