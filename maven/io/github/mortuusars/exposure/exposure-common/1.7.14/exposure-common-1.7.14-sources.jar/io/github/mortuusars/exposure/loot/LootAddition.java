package io.github.mortuusars.exposure.loot;

import java.util.Map;

public class LootAddition {
//    public static Map<ResourceLocation, ResourceLocation>
}
