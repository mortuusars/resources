package io.github.mortuusars.exposure.data.storage;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.data.ExposureSize;
import io.github.mortuusars.exposure.render.modifiers.ExposurePixelModifiers;
import io.github.mortuusars.exposure.render.modifiers.IPixelModifier;
import io.github.mortuusars.exposure.util.Color;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.imageio.ImageIO;
import net.minecraft.class_2487;
import net.minecraft.class_3620;
import net.minecraft.class_5253;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class ServersideExposureExporter extends ExposureExporter<ServersideExposureExporter> {
    public ServersideExposureExporter(String name) {
        super(name);
    }

    @Override
    public boolean save(byte[] mapColorPixels, int width, int height, class_2487 properties) {
        try {
            BufferedImage image = convertToBufferedImage(mapColorPixels, width, height, properties);
            return save(image, properties);
        }
        catch (Exception e) {
            Exposure.LOGGER.error("Failed to save exposure: {}", e.toString());
            return false;
        }
    }

    public boolean save(BufferedImage image, class_2487 properties) {
        // Existing file would be overwritten
        try {
            String filepath = getFolder() + "/" + (getWorldSubfolder() != null ? getWorldSubfolder() + "/" : "") + getName() + ".png";
            File outputFile = new File(filepath);
            boolean ignored = outputFile.getParentFile().mkdirs();

            if (!ImageIO.write(image, "png", outputFile)) {
                Exposure.LOGGER.error("Exposure was not saved. No appropriate writer has been found.");
                return false;
            }

            if (properties.method_10573(ExposureSavedData.TIMESTAMP_PROPERTY, class_2487.field_33254)) {
                long unixSeconds = properties.method_10537(ExposureSavedData.TIMESTAMP_PROPERTY);
                trySetFileCreationDate(outputFile.getAbsolutePath(), unixSeconds);
            }

            Exposure.LOGGER.info("Exposure saved: {}", outputFile);
            return true;
        } catch (IOException e) {
            Exposure.LOGGER.error("Failed to save exposure to file: {}", e.toString());
            return false;
        }
    }

    @NotNull
    protected BufferedImage convertToBufferedImage(byte[] MapColorPixels, int width, int height, class_2487 properties) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        IPixelModifier modifier = getModifier();

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                int ABGR = class_3620.method_38480(MapColorPixels[x + y * width]); // Mojang returns BGR color
                ABGR = modifier.modifyPixel(ABGR);

                // Tint image like it's rendered in LightroomScreen or NegativeExposureScreen:
                // This is not the best place for it, but I haven't found better a better one.
                if (modifier == ExposurePixelModifiers.NEGATIVE_FILM) {
                    @Nullable FilmType filmType = FilmType.byName(properties.method_10558(ExposureSavedData.TYPE_PROPERTY));
                    if (filmType != null) {

                        int a = class_5253.class_8045.method_48342(ABGR);
                        int b = class_5253.class_8045.method_48347(ABGR);
                        int g = class_5253.class_8045.method_48346(ABGR);
                        int r = class_5253.class_8045.method_48345(ABGR);

                        b = b * filmType.frameB / 255;
                        g = g * filmType.frameG / 255;
                        r = r * filmType.frameR / 255;

                        ABGR = class_5253.class_8045.method_48344(a, b, g, r);
                    }
                }

                image.setRGB(x, y, Color.BGRtoRGB(ABGR));
            }
        }

        if (getSize() != ExposureSize.X1) {
            image = resize(image, getSize());
        }

        return image;
    }

    protected BufferedImage resize(BufferedImage sourceImage, ExposureSize size) {
        int targetWidth = sourceImage.getWidth() * size.getMultiplier();
        int targetHeight = sourceImage.getHeight() * size.getMultiplier();
        Image scaledInstance = sourceImage.getScaledInstance(targetWidth, targetHeight, Image.SCALE_FAST);
        BufferedImage outputImg = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_ARGB);
        outputImg.getGraphics().drawImage(scaledInstance, 0, 0, null);
        return outputImg;
    }
}
