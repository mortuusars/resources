package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.menu.ItemRenameMenu;
import net.minecraft.class_2600;
import net.minecraft.class_2855;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3244.class)
public abstract class ServerGamePacketListenerMixin {
    @Shadow public class_3222 player;

    @Inject(method = "handleRenameItem", at = @At("HEAD"), cancellable = true)
    private void handleRename(class_2855 packet, CallbackInfo ci) {
        class_2600.method_11073(packet, (class_3244)(Object)this, player.method_51469());
        if (player.field_7512 instanceof ItemRenameMenu itemRenameMenu) {
            if (!itemRenameMenu.method_7597(player)) {
                Exposure.LOGGER.debug("Player {} interacted with invalid menu {}", player, itemRenameMenu);
            }
            else {
                itemRenameMenu.setItemName(packet.method_12407());
            }

            ci.cancel();
        }
    }
}
