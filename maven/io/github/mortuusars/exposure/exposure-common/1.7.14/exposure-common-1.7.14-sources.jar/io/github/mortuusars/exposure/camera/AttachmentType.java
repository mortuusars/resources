package io.github.mortuusars.exposure.camera;

import java.util.function.Predicate;
import net.minecraft.class_1799;

public record AttachmentType(String id, int slot, Predicate<class_1799> itemPredicate, AttachmentSound sound) {
    public boolean matches(class_1799 stack) {
        return itemPredicate.test(stack);
    }

    @Override
    public String toString() {
        return "AttachmentType{" +
                "id='" + id + '\'' +
                ", slot=" + slot +
                '}';
    }
}
