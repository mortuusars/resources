package io.github.mortuusars.exposure.gui.screen;

import io.github.mortuusars.exposure.camera.infrastructure.ZoomDirection;
import io.github.mortuusars.exposure.gui.screen.element.ZoomHandler;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;

public abstract class ZoomableScreen extends class_437 {
    protected final ZoomHandler zoom = new ZoomHandler();
    protected float zoomFactor = 1f;
    protected float scale = 1f;
    protected float x;
    protected float y;

    @NotNull
    protected final class_310 field_22787 = class_310.method_1551();

    protected ZoomableScreen(class_2561 title) {
        super(title);
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        zoom.update(partialTick);
        scale = zoom.get() * zoomFactor;
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        boolean handled = super.method_25404(keyCode, scanCode, modifiers);
        if (handled)
            return true;

        if (field_22787.field_1690.field_1822.method_1417(keyCode, scanCode))
            this.method_25419();
        else if (keyCode == class_3675.field_31933 || keyCode == class_3675.field_31937)
            zoom.change(ZoomDirection.IN);
        else if (keyCode == 333 /*KEY_SUBTRACT*/ || keyCode == class_3675.field_31941)
            zoom.change(ZoomDirection.OUT);
        else
            return false;

        return true;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta) {
        boolean handled = super.method_25401(mouseX, mouseY, delta);

        if (!handled) {
            zoom.change(delta >= 0.0 ? ZoomDirection.IN : ZoomDirection.OUT);
            return true;
        }

        return true;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        boolean handled = super.method_25403(mouseX, mouseY, button, dragX, dragY);

        if (!handled && button == 0) { // Left Click
            float centerX = field_22789 / 2f;
            float centerY = field_22790 / 2f;

            x = (float) class_3532.method_15350(x + dragX, -centerX, centerX);
            y = (float) class_3532.method_15350(y + dragY, -centerY, centerY);
            handled = true;
        }

        return handled;
    }
}
