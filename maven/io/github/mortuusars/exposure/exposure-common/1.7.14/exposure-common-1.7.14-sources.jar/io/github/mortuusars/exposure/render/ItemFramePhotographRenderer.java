package io.github.mortuusars.exposure.render;

import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.item.PhotographItem;
import net.minecraft.class_1299;
import net.minecraft.class_1533;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

public class ItemFramePhotographRenderer {
    public static boolean render(class_1533 itemFrameEntity, class_4587 poseStack, class_4597 bufferSource, int packedLight) {
        class_1799 itemStack = itemFrameEntity.method_6940();
        if (!(itemStack.method_7909() instanceof PhotographItem photographItem) || !FrameData.hasIdOrTexture(itemStack))
            return false;

        if (itemFrameEntity.method_5864() == class_1299.field_28401)
            packedLight = class_765.field_32767;

        poseStack.method_22903();

        String entityName = class_7923.field_41177.method_10221(itemFrameEntity.method_5864()).toString();
        if (entityName.equals("quark:glass_frame")) {
            poseStack.method_46416(0, 0, 0.475f);
        }

        // Snap to 90 degrees like a map.
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(45 * itemFrameEntity.method_6934()));

        float size = ExposureClient.getExposureRenderer().getSize();

        float scale = 1f / size;
        float pixelScale = scale / 16f;
        scale -= pixelScale * 6;

        poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
        poseStack.method_22905(scale, scale, scale);
        poseStack.method_46416(-size / 2f, -size / 2f, 10);

        PhotographRenderer.renderPhotograph(photographItem, itemStack, false, false,
                poseStack, bufferSource, packedLight, 255, 255, 255, 255);

        poseStack.method_22909();

        return true;
    }
}
