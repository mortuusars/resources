package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public class ClearRenderingCacheS2CP implements IPacket {
    public static final class_2960 ID = Exposure.resource("clear_rendering_cache");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public static ClearRenderingCacheS2CP fromBuffer(class_2540 buffer) {
        return new ClearRenderingCacheS2CP();
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        ClientPacketsHandler.clearRenderingCache();
        return true;
    }
}