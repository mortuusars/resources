package io.github.mortuusars.exposure.camera.capture.converter;

import io.github.mortuusars.exposure.camera.capture.Capture;
import net.minecraft.class_1011;

public interface IImageToMapColorsConverter {
    byte[] convert(Capture capture, class_1011 image);
    byte[] convert(class_1011 image);
}
