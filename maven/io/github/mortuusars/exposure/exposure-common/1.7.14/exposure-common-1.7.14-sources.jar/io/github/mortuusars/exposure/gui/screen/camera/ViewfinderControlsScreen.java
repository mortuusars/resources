package io.github.mortuusars.exposure.gui.screen.camera;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.camera.CameraClient;
import io.github.mortuusars.exposure.camera.infrastructure.ZoomDirection;
import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.camera.viewfinder.ViewfinderOverlay;
import io.github.mortuusars.exposure.client.MouseHandler;
import io.github.mortuusars.exposure.gui.screen.element.IElementWithTooltip;
import io.github.mortuusars.exposure.gui.screen.camera.button.*;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.util.CameraInHand;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_638;
import net.minecraft.class_757;

public class ViewfinderControlsScreen extends class_437 {
    public static final class_2960 TEXTURE = Exposure.resource("textures/gui/viewfinder/viewfinder_camera_controls.png");

    private final class_1657 player;
    private final class_638 level;
    private final long openedAtTimestamp;

    public ViewfinderControlsScreen() {
        super(class_2561.method_43473());

        player = class_310.method_1551().field_1724;
        level = class_310.method_1551().field_1687;
        assert level != null;
        openedAtTimestamp = level.method_8510();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25393() {
        refreshMovementKeys();
        class_310.method_1551().method_1508();
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        refreshMovementKeys();

        int leftPos = (field_22789 - 256) / 2;
        int topPos = Math.round(ViewfinderOverlay.opening.y + ViewfinderOverlay.opening.height - 256);

        Camera<?> camera = CameraClient.getCamera().orElseThrow();

        boolean hasFlashAttached = camera.get().getItem().getAttachment(camera.get().getStack(), CameraItem.FLASH_ATTACHMENT).isPresent();

        int sideButtonsWidth = 48;
        int buttonWidth = 15;

        int elementX = leftPos + 128 - (sideButtonsWidth + 1 + buttonWidth + 1 + (hasFlashAttached ? buttonWidth + 1 : 0) + sideButtonsWidth) / 2;
        int elementY = topPos + 238;

        // Order of adding influences TAB key behavior

        ShutterSpeedButton shutterSpeedButton = new ShutterSpeedButton(this, leftPos + 94, topPos + 226, 69, 12, 112, 0, TEXTURE);
        method_37063(shutterSpeedButton);

        FocalLengthButton focalLengthButton = new FocalLengthButton(this, elementX, elementY, 48, 18, 0, 0, TEXTURE);
        method_37060(focalLengthButton);
        elementX += focalLengthButton.method_25368();

        class_344 separator1 = new class_344(elementX, elementY, 1, 18, 111, 0, TEXTURE, pButton -> {});
        method_37060(separator1);
        elementX += separator1.method_25368();

        CompositionGuideButton compositionGuideButton = new CompositionGuideButton(this, elementX, elementY, 15, 18, 48, 0, TEXTURE);
        method_37063(compositionGuideButton);
        elementX += compositionGuideButton.method_25368();

        class_344 separator2 = new class_344(elementX, elementY, 1, 18, 111, 0, TEXTURE, pButton -> {});
        method_37060(separator2);
        elementX += separator2.method_25368();

        if (hasFlashAttached) {
            FlashModeButton flashModeButton = new FlashModeButton(this, elementX, elementY, 15, 18, 48, 0, TEXTURE);
            method_37063(flashModeButton);
            elementX += flashModeButton.method_25368();

            class_344 separator3 = new class_344(elementX, elementY, 1, 18, 111, 0, TEXTURE, pButton -> {});
            method_37060(separator3);
            elementX += separator3.method_25368();
        }

        FrameCounterButton frameCounterButton = new FrameCounterButton(this, elementX, elementY, 48, 18, 63, 0, TEXTURE);
        method_37060(frameCounterButton);
    }

    /**
     * When screen is opened - all keys are released. If we do not refresh them - player would stop moving (if they had).
     */
    private void refreshMovementKeys() {
        Consumer<class_304> update = keyMapping -> {
            if (keyMapping.field_1655.method_1442() == class_3675.class_307.field_1672) {
                keyMapping.method_23481(MouseHandler.isMouseButtonHeld(keyMapping.field_1655.method_1444()));
            }
            else {
                long windowId = class_310.method_1551().method_22683().method_4490();
                keyMapping.method_23481(class_3675.method_15987(windowId, keyMapping.field_1655.method_1444()));
            }
        };

        update.accept(ExposureClient.getCameraControlsKey());
        class_315 opt = class_310.method_1551().field_1690;
        update.accept(opt.field_1894);
        update.accept(opt.field_1881);
        update.accept(opt.field_1913);
        update.accept(opt.field_1849);
        update.accept(opt.field_1903);
        update.accept(opt.field_1867);
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (!Viewfinder.isLookingThrough()) {
            this.method_25419();
            return;
        }

        if (class_310.method_1551().field_1690.field_1842)
            return;

        guiGraphics.method_51448().method_22903();

        float viewfinderScale = ViewfinderOverlay.getScale();
        if (viewfinderScale != 1.0f) {
            guiGraphics.method_51448().method_46416(field_22789 / 2f, field_22790 / 2f, 0);
            guiGraphics.method_51448().method_22905(viewfinderScale, viewfinderScale, viewfinderScale);
            guiGraphics.method_51448().method_46416(-field_22789 / 2f, -field_22790 / 2f, 0);
        }

        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderTexture(0, TEXTURE);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        for(class_4068 renderable : this.field_33816) {
            if (renderable instanceof IElementWithTooltip tooltipElement && renderable instanceof class_339 widget
                && widget.field_22764 && widget.method_25367()) {
                tooltipElement.renderToolTip(guiGraphics, mouseX, mouseY);
                break;
            }
        }

        guiGraphics.method_51448().method_22909();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (super.method_25402(mouseX, mouseY, button))
            return true;

        if (button == class_3675.field_32002 && class_310.method_1551().field_1761 != null) {
            Camera<?> camera = CameraClient.getCamera().orElseThrow();

            if (camera instanceof CameraInHand<?> cameraInHand) {
                class_1268 hand = cameraInHand.getHand();
                class_310.method_1551().field_1761.method_2919(player, hand);
            }

            return true;
        }

        return false;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (ExposureClient.getCameraControlsKey().method_1433(button)
                || (Config.Client.VIEWFINDER_MIDDLE_CLICK_CONTROLS.get() && button == class_3675.field_32001)) {
            if (level.method_8510() - openedAtTimestamp >= 5)
                this.method_25419();

            return false;
        }

        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        if (ExposureClient.getCameraControlsKey().method_1417(keyCode, scanCode)) {
            if (level.method_8510() - openedAtTimestamp >= 5)
                this.method_25419();

            return false;
        }

        return super.method_16803(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        Preconditions.checkState(field_22787 != null);

        boolean handled = super.method_25404(keyCode, scanCode, modifiers);
        if (handled)
            return true;

        if (keyCode == class_3675.field_31933 || keyCode == class_3675.field_31937) {
            Viewfinder.zoom(ZoomDirection.IN, true);
            return true;
        }
        else if (keyCode == 333 /*KEY_SUBTRACT*/ || keyCode == class_3675.field_31941) {
            Viewfinder.zoom(ZoomDirection.OUT, true);
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta) {
        if (!super.method_25401(mouseX, mouseY, delta)) {
            Viewfinder.zoom(delta > 0d ? ZoomDirection.IN : ZoomDirection.OUT, true);
            return true;
        }

        return false;
    }
}
