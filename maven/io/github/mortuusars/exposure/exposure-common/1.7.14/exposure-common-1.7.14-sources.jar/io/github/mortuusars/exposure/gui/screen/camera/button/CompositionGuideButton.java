package io.github.mortuusars.exposure.gui.screen.camera.button;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.camera.CameraClient;
import io.github.mortuusars.exposure.camera.infrastructure.CompositionGuide;
import io.github.mortuusars.exposure.camera.infrastructure.CompositionGuides;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1109;
import net.minecraft.class_1144;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5250;

public class CompositionGuideButton extends CycleButton {
    private final List<CompositionGuide> guides;

    public CompositionGuideButton(class_437 screen, int x, int y, int width, int height, int u, int v,  class_2960 texture) {
        super(screen, x, y, width, height, u, v, height, texture);
        guides = CompositionGuides.getGuides();

        Camera<?> camera = CameraClient.getCamera().orElseThrow();

        CompositionGuide guide = camera.get().getItem().getCompositionGuide(camera.get().getStack());

        int currentGuideIndex = 0;

        for (int i = 0; i < guides.size(); i++) {
            if (guides.get(i).getId().equals(guide.getId())) {
                currentGuideIndex = i;
                break;
            }
        }

        setupButtonElements(guides.size(), currentGuideIndex);
    }

    @Override
    public void method_25354(class_1144 handler) {
        handler.method_4873(class_1109.method_4757(Exposure.SoundEvents.CAMERA_BUTTON_CLICK.get(),
                Objects.requireNonNull(class_310.method_1551().field_1687).field_9229.method_43057() * 0.15f + 0.93f, 0.7f));
    }

    @Override
    public void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_48579(guiGraphics, mouseX, mouseY, partialTick);

        // Icon
        guiGraphics.method_25291(Exposure.resource("textures/gui/viewfinder/icon/composition_guide/" + guides.get(currentIndex).getId() + ".png"),
                method_46426(), method_46427() + 4, 0, 0, 0, 15, 14, 15, 14);
    }

    @Override
    public void renderToolTip(@NotNull class_332 guiGraphics, int mouseX, int mouseY) {
        guiGraphics.method_51437(class_310.method_1551().field_1772, List.of(class_2561.method_43471("gui.exposure.viewfinder.composition_guide.tooltip"),
                ((class_5250) method_25369()).method_27692(class_124.field_1080)), Optional.empty(), mouseX, mouseY);
    }

    @Override
    public @NotNull class_2561 method_25369() {
        return guides.get(currentIndex).translate();
    }

    @Override
    protected void onCycle() {
        CameraClient.setCompositionGuide(guides.get(currentIndex));
    }
}
