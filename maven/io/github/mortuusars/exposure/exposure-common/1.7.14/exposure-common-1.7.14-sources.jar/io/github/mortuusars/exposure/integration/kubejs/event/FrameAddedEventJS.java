package io.github.mortuusars.exposure.integration.kubejs.event;

import dev.latvian.mods.kubejs.player.PlayerEventJS;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2487;

/**
 * Fired at the very end of a shot, when frame is added to the film.
 * Fired only on the server side.
 */
public class FrameAddedEventJS extends PlayerEventJS {
    private final class_1657 player;
    private final class_1799 cameraStack;
    private final class_2487 frame;

    public FrameAddedEventJS(class_1657 player, class_1799 cameraStack, class_2487 frame) {
        this.player = player;
        this.cameraStack = cameraStack;
        this.frame = frame;
    }

    @Override
    public class_1657 getEntity() {
        return player;
    }

    @Override
    public class_1657 getPlayer() {
        return player;
    }

    public class_1799 getCameraStack() {
        return cameraStack;
    }

    public class_2487 getFrame() {
        return frame;
    }
}
