package io.github.mortuusars.exposure.block.entity;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.block.LightroomBlock;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.data.storage.ExposureSavedData;
import io.github.mortuusars.exposure.item.*;
import io.github.mortuusars.exposure.menu.LightroomMenu;
import io.github.mortuusars.exposure.util.ItemAndStack;
import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1262;
import net.minecraft.class_1278;
import net.minecraft.class_1303;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2624;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3913;

@SuppressWarnings("unused")
public class LightroomBlockEntity extends class_2624 implements class_1278 {
    
    public static final int CONTAINER_DATA_SIZE = 3;
    public static final int CONTAINER_DATA_PROGRESS_ID = 0;
    public static final int CONTAINER_DATA_PRINT_TIME_ID = 1;
    public static final int CONTAINER_DATA_SELECTED_FRAME_ID = 2;

    protected final class_3913 containerData = new class_3913() {
        public int method_17390(int id) {
            return switch (id) {
                case CONTAINER_DATA_PROGRESS_ID -> LightroomBlockEntity.this.progress;
                case CONTAINER_DATA_PRINT_TIME_ID -> LightroomBlockEntity.this.printTime;
                case CONTAINER_DATA_SELECTED_FRAME_ID -> LightroomBlockEntity.this.getSelectedFrameIndex();
                default -> 0;
            };
        }

        public void method_17391(int id, int value) {
            if (id == CONTAINER_DATA_PROGRESS_ID)
                LightroomBlockEntity.this.progress = value;
            else if (id == CONTAINER_DATA_PRINT_TIME_ID)
                LightroomBlockEntity.this.printTime = value;
            else if (id == CONTAINER_DATA_SELECTED_FRAME_ID)
                LightroomBlockEntity.this.setSelectedFrame(value);
            method_5431();
        }

        public int method_17389() {
            return CONTAINER_DATA_SIZE;
        }
    };

    protected class_2371<class_1799> items = class_2371.method_10213(Lightroom.SLOTS, class_1799.field_8037);

    protected @Nullable String lastPlayerName = null;
    protected int selectedFrame;
    protected int progress;
    protected int printTime;
    protected int storedExperience;
    protected boolean advanceFrame;
    protected Lightroom.Process process = Lightroom.Process.REGULAR;

    public LightroomBlockEntity(class_2338 pos, class_2680 blockState) {
        super(Exposure.BlockEntityTypes.LIGHTROOM.get(), pos, blockState);
    }

    public static <T extends class_2586> void serverTick(class_1937 level, class_2338 blockPos, class_2680 blockState, T blockEntity) {
        if (blockEntity instanceof LightroomBlockEntity lightroomBlockEntity)
            lightroomBlockEntity.tick();
    }

    public void setLastPlayer(class_1657 player) {
        lastPlayerName = player.method_5820();
    }

    protected void tick() {
        if (printTime <= 0 || !canPrint()) {
            stopPrintingProcess();
            return;
        }

        if (progress < printTime) {
            progress++;
            if (progress % 55 == 0 && printTime - progress > 12 && field_11863 != null)
                field_11863.method_8396(null, method_11016(), Exposure.SoundEvents.LIGHTROOM_PRINT.get(), class_3419.field_15245,
                        1f, field_11863.method_8409().method_43057() * 0.3f + 1f);
            return;
        }

        if (tryPrint()) {
            onFramePrinted();
        }

        stopPrintingProcess();
    }

    public float getProgressPercentage() {
        if (progress < 1 || printTime < 1)
            return 0f;

        return progress / (float)printTime;
    }

    protected void onFramePrinted() {
        if (advanceFrame)
            advanceFrame();
    }

    protected void advanceFrame() {
        ItemAndStack<DevelopedFilmItem> film = new ItemAndStack<>(method_5438(Lightroom.FILM_SLOT));
        int frames = film.getItem().getExposedFramesCount(film.getStack());

        if (getSelectedFrameIndex() >= frames - 1) { // On last frame
            if (canEjectFilm())
                ejectFilm();
        } else {
            setSelectedFrame(getSelectedFrameIndex() + 1);
            method_5431();
        }
    }

    public boolean isAdvancingFrameOnPrint() {
        return advanceFrame;
    }

    protected boolean canEjectFilm() {
        if (field_11863 == null || field_11863.field_9236 || method_5438(Lightroom.FILM_SLOT).method_7960())
            return false;

        class_2338 pos = method_11016();
        class_2350 facing = field_11863.method_8320(pos).method_11654(LightroomBlock.FACING);

        return !field_11863.method_8320(pos.method_10093(facing)).method_26225();
    }

    protected void ejectFilm() {
        if (field_11863 == null || field_11863.field_9236 || method_5438(Lightroom.FILM_SLOT).method_7960())
            return;

        class_2338 pos = method_11016();
        class_2350 facing = field_11863.method_8320(pos).method_11654(LightroomBlock.FACING);
        class_1799 filmStack = method_5434(Lightroom.FILM_SLOT, 1);

        class_2382 normal = facing.method_10163();
        class_243 point = class_243.method_24953(pos).method_1031(normal.method_10263() * 0.75f, normal.method_10264() * 0.75f, normal.method_10260() * 0.75f);
        class_1542 itemEntity = new class_1542(field_11863, point.field_1352, point.field_1351, point.field_1350, filmStack);
        itemEntity.method_18800(normal.method_10263() * 0.05f, normal.method_10264() * 0.05f + 0.15f, normal.method_10260() * 0.05f);
        itemEntity.method_6988();
        field_11863.method_8649(itemEntity);

        inventoryContentsChanged(Lightroom.FILM_SLOT);
    }

    public int getSelectedFrameIndex() {
        return selectedFrame;
    }

    public void setSelectedFrame(int index) {
        if (selectedFrame != index) {
            selectedFrame = index;
            stopPrintingProcess();
        }
    }

    /*
        Process setting stays where it was set by the player, But if the frame does not support it -
        image would be printed with supported process (probably regular), WITHOUT changing the process setting -
        this means that this process will be used again if some other image is supporting it.

        This was done to not reset Process in automated setups, if there were some image on a film that doesn't support selected process.
     */

    /**
     * @return Process SETTING. Can be different from actual process that would be used to print an image
     * (if frame does not support this process, for example).
     */
    public Lightroom.Process getProcess() {
        return process;
    }

    /**
     * @return Process, that will be used to print an image.
     */
    public Lightroom.Process getActualProcess(class_1799 filmStack) {
        if (!canPrintChromatic(filmStack, getSelectedFrameIndex())) {
            return Lightroom.Process.REGULAR;
        }

        return process;
    }

    public void setProcess(Lightroom.Process process) {
        this.process = process;
        stopPrintingProcess();
        method_5431();
    }

    public Optional<class_2487> getSelectedFrame(class_1799 film) {
        if (!film.method_7960() && film.method_7909() instanceof DevelopedFilmItem developedFilm) {
            class_2499 frames = developedFilm.getExposedFrames(film);
            if (frames.size() > getSelectedFrameIndex())
                return Optional.of(frames.method_10602(selectedFrame));
        }

        return Optional.empty();
    }

    public boolean isSelectedFrameChromatic(class_1799 film, int selectedFrame) {
        return getSelectedFrame(film)
                .map(frame -> frame.method_10577(FrameData.CHROMATIC))
                .orElse(false);
    }

    public boolean canPrintChromatic(class_1799 filmStack, int selectedFrameIndex) {
        boolean chromaticSelected = getSelectedFrame(filmStack)
                .map(frame -> frame.method_10577(FrameData.CHROMATIC))
                .orElse(false);

        if (chromaticSelected) {
            return true;
        }

        if (filmStack.method_7909() instanceof IFilmItem filmItem && filmItem.getType() == FilmType.BLACK_AND_WHITE && method_10997() != null) {
            return method_10997().method_8320(method_11016().method_10084()).method_26164(Exposure.Tags.Blocks.CHROMATIC_REFRACTORS);
        }

        return false;
    }

    public void startPrintingProcess(boolean advanceFrameOnFinish) {
        if (!canPrint())
            return;

        class_1799 filmStack = method_5438(Lightroom.FILM_SLOT);
        if (!(filmStack.method_7909() instanceof DevelopedFilmItem film))
            return;

        if (getActualProcess(filmStack) == Lightroom.Process.CHROMATIC)
            printTime = Config.Common.LIGHTROOM_CHROMATIC_PRINT_TIME.get();
        else if (film.getType() == FilmType.BLACK_AND_WHITE)
            printTime = Config.Common.LIGHTROOM_BW_PRINT_TIME.get();
        else
            printTime = Config.Common.LIGHTROOM_COLOR_PRINT_TIME.get();

        advanceFrame = advanceFrameOnFinish;

        if (field_11863 != null) {
            field_11863.method_8652(method_11016(), field_11863.method_8320(method_11016())
                    .method_11657(LightroomBlock.LIT, true), class_2248.field_31028);
            field_11863.method_8396(null, method_11016(), Exposure.SoundEvents.LIGHTROOM_PRINT.get(), class_3419.field_15245,
                    1f, field_11863.method_8409().method_43057() * 0.3f + 1f);
        }
    }

    public void stopPrintingProcess() {
        progress = 0;
        printTime = 0;
        advanceFrame = false;
        if (field_11863 != null && field_11863.method_8320(method_11016()).method_26204() instanceof LightroomBlock)
            field_11863.method_8652(method_11016(), field_11863.method_8320(method_11016())
                    .method_11657(LightroomBlock.LIT, false), class_2248.field_31028);
    }

    public boolean isPrinting() {
        return printTime > 0;
    }

    public boolean canPrint() {
        if (getSelectedFrameIndex() < 0) // Upper bound is checked further down
            return false;

        class_1799 filmStack = method_5438(Lightroom.FILM_SLOT);
        if (!(filmStack.method_7909() instanceof DevelopedFilmItem developedFilm) || !developedFilm.hasExposedFrame(filmStack, getSelectedFrameIndex()))
            return false;

        Lightroom.Process process = getActualProcess(filmStack);

        class_1799 paperStack = method_5438(Lightroom.PAPER_SLOT);

        return isPaperValidForPrint(paperStack, filmStack, process)
                && hasDyesForPrint(filmStack, paperStack, process)
                && canOutputToResultSlot(method_5438(Lightroom.RESULT_SLOT), filmStack, process);
    }

    public boolean canPrintInCreativeMode() {
        if (getSelectedFrameIndex() < 0) // Upper bound is checked further down
            return false;

        class_1799 filmStack = method_5438(Lightroom.FILM_SLOT);
        if (!(filmStack.method_7909() instanceof DevelopedFilmItem developedFilm) || !developedFilm.hasExposedFrame(filmStack, getSelectedFrameIndex()))
            return false;

        return canOutputToResultSlot(method_5438(Lightroom.RESULT_SLOT), filmStack, getActualProcess(filmStack));
    }

    protected boolean isPaperValidForPrint(class_1799 paperStack, class_1799 filmStack, Lightroom.Process process) {
        if (paperStack.method_7960())
            return false;

        return process != Lightroom.Process.REGULAR || paperStack.method_31573(Exposure.Tags.Items.PHOTO_PAPERS);
    }

    protected boolean hasDyesForPrint(class_1799 film, class_1799 paper, Lightroom.Process process) {
        int[] dyeSlots = getRequiredDyeSlotsForPrint(film, paper, process);

        for (int slot : dyeSlots) {
            if (method_5438(slot).method_7960())
                return false;
        }

        return true;
    }

    public boolean canOutputToResultSlot(class_1799 resultStack, class_1799 filmStack, Lightroom.Process process) {
        if (canPrintChromatic(filmStack, getSelectedFrameIndex()) && process == Lightroom.Process.CHROMATIC)
            return resultStack.method_7960();

        return resultStack.method_7960() || resultStack.method_7909() instanceof PhotographItem
                || (resultStack.method_7909() instanceof StackedPhotographsItem stackedPhotographsItem
                && stackedPhotographsItem.canAddPhotograph(resultStack));
    }

    protected int[] getRequiredDyeSlotsForPrint(class_1799 film, class_1799 paper, Lightroom.Process process) {
        if (!(film.method_7909() instanceof IFilmItem filmItem))
            return ArrayUtils.EMPTY_INT_ARRAY;

        if (process == Lightroom.Process.REGULAR) {
            return filmItem.getType() == FilmType.COLOR ? Lightroom.DYES_FOR_COLOR : Lightroom.DYES_FOR_BW;
        }

        if (process == Lightroom.Process.CHROMATIC) {
            int chromaticStep = getChromaticStep(paper);
            if (chromaticStep == 0) return Lightroom.DYES_FOR_CHROMATIC_RED;
            if (chromaticStep == 1) return Lightroom.DYES_FOR_CHROMATIC_GREEN;
            if (chromaticStep == 2) return Lightroom.DYES_FOR_CHROMATIC_BLUE;
        }

        return ArrayUtils.EMPTY_INT_ARRAY;
    }

    protected int getChromaticStep(class_1799 paper) {
        if (!(paper.method_7909() instanceof ChromaticSheetItem chromaticFragment))
            return 0;

        return chromaticFragment.getExposures(paper).size();
    }

    public boolean tryPrint() {
        Preconditions.checkState(field_11863 != null && !field_11863.field_9236, "Cannot be called clientside.");
        if (!canPrint())
            return false;

        class_1799 filmStack = method_5438(Lightroom.FILM_SLOT);
        if (!(filmStack.method_7909() instanceof DevelopedFilmItem developedFilm))
            return false;

        Optional<class_2487> selectedFrame = getSelectedFrame(filmStack);
        if (selectedFrame.isEmpty()) {
            Exposure.LOGGER.error("Unable to get selected frame '{}' : {}", getSelectedFrameIndex(), filmStack);
            return false;
        }

        class_2487 frame = selectedFrame.get().method_10553();
        Lightroom.Process process = getActualProcess(filmStack);
        class_1799 paperStack = method_5438(Lightroom.PAPER_SLOT);

        class_1799 printResult = createPrintResult(frame, filmStack, paperStack, process);
        putPrintResultInOutputSlot(printResult);

        // Consume items required for printing:
        int[] dyesSlots = getRequiredDyeSlotsForPrint(filmStack, paperStack, process);
        for (int slot : dyesSlots) {
            method_5438(slot).method_7934(1);
        }
        method_5438(Lightroom.PAPER_SLOT).method_7934(1);

        field_11863.method_8396(null, method_11016(), Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), class_3419.field_15248, 0.8f, 1f);

        storeExperienceForPrint(filmStack, frame, process, printResult);

        if (process != Lightroom.Process.CHROMATIC) { // Chromatics create new exposure. Marking is not needed.
            // Mark exposure as printed
            String id = frame.method_10558(FrameData.ID);
            if (!id.isEmpty()) {
                ExposureServer.getExposureStorage().getOrQuery(id).ifPresent(exposure -> {
                    class_2487 properties = exposure.getProperties();
                    if (!properties.method_10577(ExposureSavedData.WAS_PRINTED_PROPERTY)) {
                        properties.method_10556(ExposureSavedData.WAS_PRINTED_PROPERTY, true);
                        exposure.method_80();
                    }
                });
            }
        }

        return true;
    }

    protected void storeExperienceForPrint(class_1799 film, class_2487 frame, Lightroom.Process process, class_1799 result) {
        if (field_11863 == null)
            return;

        int xp = 0;
        if (process == Lightroom.Process.CHROMATIC) {
            // Printing intermediate channels does not grant xp. Only finished photograph does.
            xp = result.method_7909() instanceof ChromaticSheetItem ? 0 : Config.Common.LIGHTROOM_EXPERIENCE_PER_PRINT_CHROMATIC.get();
        }
        else if (film.method_7909() instanceof IFilmItem filmItem)
            xp = filmItem.getType() == FilmType.COLOR
                    ? Config.Common.LIGHTROOM_EXPERIENCE_PER_PRINT_COLOR.get()
                    : Config.Common.LIGHTROOM_EXPERIENCE_PER_PRINT_BW.get();

        if (xp > 0) {
            float variability = field_11863.method_8409().method_43057() * 0.3f + 1f;
            int variableXp = (int)Math.max(1, Math.ceil(xp * variability));
            storedExperience += variableXp;
        }
    }

    public void printInCreativeMode() {
        Preconditions.checkState(field_11863 != null && !field_11863.field_9236, "Cannot be called clientside.");
        if (!canPrintInCreativeMode())
            return;

        class_1799 filmStack = method_5438(Lightroom.FILM_SLOT);
        if (!(filmStack.method_7909() instanceof DevelopedFilmItem developedFilm))
            return;

        Optional<class_2487> selectedFrame = getSelectedFrame(filmStack);
        if (selectedFrame.isEmpty()) {
            Exposure.LOGGER.error("Unable to get selected frame '{}' : {}", getSelectedFrameIndex(), filmStack);
            return;
        }

        class_2487 frame = selectedFrame.get().method_10553();
        Lightroom.Process process = getActualProcess(filmStack);
        class_1799 paperStack = method_5438(Lightroom.PAPER_SLOT);

        class_1799 printResult = createPrintResult(frame, filmStack, paperStack, process);
        putPrintResultInOutputSlot(printResult);

        if (process == Lightroom.Process.CHROMATIC)
            method_5438(Lightroom.PAPER_SLOT).method_7934(1);

        field_11863.method_8396(null, method_11016(), Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), class_3419.field_15248, 0.8f, 1f);

        if (process != Lightroom.Process.CHROMATIC) { // Chromatics create new exposure. Marking is not needed.
            // Mark exposure as printed
            String id = frame.method_10558(FrameData.ID);
            if (!id.isEmpty()) {
                ExposureServer.getExposureStorage().getOrQuery(id).ifPresent(exposure -> {
                    class_2487 properties = exposure.getProperties();
                    if (!properties.method_10577(ExposureSavedData.WAS_PRINTED_PROPERTY)) {
                        properties.method_10556(ExposureSavedData.WAS_PRINTED_PROPERTY, true);
                        exposure.method_80();
                    }
                });
            }
        }
    }

    protected void putPrintResultInOutputSlot(class_1799 printResult) {
        class_1799 resultStack = method_5438(Lightroom.RESULT_SLOT);
        if (resultStack.method_7960())
            resultStack = printResult;
        else if (resultStack.method_7909() instanceof PhotographItem) {
            StackedPhotographsItem stackedPhotographsItem = Exposure.Items.STACKED_PHOTOGRAPHS.get();
            class_1799 newStackedPhotographs = new class_1799(stackedPhotographsItem);
            stackedPhotographsItem.addPhotographOnTop(newStackedPhotographs, resultStack);
            stackedPhotographsItem.addPhotographOnTop(newStackedPhotographs, printResult);
            resultStack = newStackedPhotographs;
        } else if (resultStack.method_7909() instanceof StackedPhotographsItem stackedPhotographsItem) {
            stackedPhotographsItem.addPhotographOnTop(resultStack, printResult);
        } else {
            Exposure.LOGGER.error("Unexpected item in result slot: " + resultStack);
            return;
        }
        method_5447(Lightroom.RESULT_SLOT, resultStack);
    }

    protected class_1799 createPrintResult(class_2487 frame, class_1799 film, class_1799 paper, Lightroom.Process process) {
        if (!(film.method_7909() instanceof IFilmItem filmItem))
            throw new IllegalStateException("Film stack is invalid: " + film);

        paper = paper.method_7972();

        // Type is currently used to decide what dyes are used when copying photograph.
        // Or for quests. Or other purposes. It's important.
        frame.method_10582(FrameData.TYPE, process == Lightroom.Process.REGULAR
                ? filmItem.getType().method_15434() : FilmType.COLOR.method_15434());

        if (process == Lightroom.Process.CHROMATIC) {
            ItemAndStack<ChromaticSheetItem> chromaticFragment = new ItemAndStack<>(
                    paper.method_7909() instanceof ChromaticSheetItem ? paper
                            : new class_1799(Exposure.Items.CHROMATIC_SHEET.get()));

            chromaticFragment.getItem().addExposure(chromaticFragment.getStack(), frame);

            if (chromaticFragment.getItem().getExposures(chromaticFragment.getStack()).size() >= 3) {
                assert field_11863 != null;
                if (lastPlayerName == null) {
                    return chromaticFragment.getItem().finalize(field_11863, chromaticFragment.getStack(), "Exposure", null);
                }
                else if (field_11863.method_8503() == null) {
                    return chromaticFragment.getItem().finalize(field_11863, chromaticFragment.getStack(), lastPlayerName, null);
                }
                else {
                    @Nullable class_3222 player = field_11863.method_8503().method_3760().method_14566(lastPlayerName);
                    return chromaticFragment.getItem().finalize(field_11863, chromaticFragment.getStack(), lastPlayerName, player);
                }
            }

            return chromaticFragment.getStack();
        }
        else {
            class_1799 photographStack = new class_1799(Exposure.Items.PHOTOGRAPH.get());
            photographStack.method_7980(frame);
            return photographStack;
        }
    }

    public void dropStoredExperience(@Nullable class_1657 player) {
        if (field_11863 instanceof class_3218 serverLevel && storedExperience > 0) {
            class_1303.method_31493(serverLevel, class_243.method_24953(method_11016()), storedExperience);
            storedExperience = 0;
            method_5431();
        }
    }


    // Container

    @Override
    protected @NotNull class_2561 method_17823() {
        return class_2561.method_43471("container.exposure.lightroom");
    }

    @Override
    protected @NotNull class_1703 method_5465(int containerId, class_1661 inventory) {
        return new LightroomMenu(containerId, inventory, this, containerData);
    }

    public boolean isItemValidForSlot(int slot, class_1799 stack) {
        if (slot == Lightroom.FILM_SLOT) return stack.method_7909() instanceof DevelopedFilmItem;
        else if (slot == Lightroom.CYAN_SLOT) return stack.method_31573(Exposure.Tags.Items.CYAN_PRINTING_DYES);
        else if (slot == Lightroom.MAGENTA_SLOT) return stack.method_31573(Exposure.Tags.Items.MAGENTA_PRINTING_DYES);
        else if (slot == Lightroom.YELLOW_SLOT) return stack.method_31573(Exposure.Tags.Items.YELLOW_PRINTING_DYES);
        else if (slot == Lightroom.BLACK_SLOT) return stack.method_31573(Exposure.Tags.Items.BLACK_PRINTING_DYES);
        else if (slot == Lightroom.PAPER_SLOT)
            return stack.method_31573(Exposure.Tags.Items.PHOTO_PAPERS) ||
                    (stack.method_7909() instanceof ChromaticSheetItem chromatic && chromatic.getExposures(stack).size() < 3);
        else if (slot == Lightroom.RESULT_SLOT)
            return stack.method_7909() instanceof PhotographItem || stack.method_7909() instanceof ChromaticSheetItem;
        return false;
    }

    protected void inventoryContentsChanged(int slot) {
        if (slot == Lightroom.FILM_SLOT)
            setSelectedFrame(0);

        method_5431();
    }

    @Override
    public boolean method_5443(@NotNull class_1657 player) {
        return this.field_11863 != null && this.field_11863.method_8321(this.field_11867) == this
                && player.method_5649(this.field_11867.method_10263() + 0.5D,
                this.field_11867.method_10264() + 0.5D,
                this.field_11867.method_10260() + 0.5D) <= 64.0D;
    }

    @Override
    public int @NotNull [] method_5494(@NotNull class_2350 face) {
        return Lightroom.ALL_SLOTS;
    }

    @Override
    public boolean method_5492(int index, @NotNull class_1799 itemStack, @Nullable class_2350 direction) {
        if (direction == class_2350.field_11033)
            return false;
        return method_5437(index, itemStack);
    }

    @Override
    public boolean method_5437(int index, class_1799 stack) {
        return index != Lightroom.RESULT_SLOT && isItemValidForSlot(index, stack) && super.method_5437(index, stack);
    }

    @Override
    public boolean method_5493(int index, @NotNull class_1799 pStack, @NotNull class_2350 direction) {
        for (int outputSlot : Lightroom.OUTPUT_SLOTS) {
            if (index == outputSlot)
                return true;
        }
        return false;
    }


    // Load/Save
    @Override
    public void method_11014(@NotNull class_2487 tag) {
        super.method_11014(tag);

        this.items = class_2371.method_10213(this.method_5439(), class_1799.field_8037);
        class_1262.method_5429(tag, this.items);

        // Backwards compatibility:
        if (tag.method_10573("Inventory", class_2520.field_33260)) {
            class_2487 inventory = tag.method_10562("Inventory");
            class_2499 itemsList = inventory.method_10554("Items", class_2520.field_33260);

            for (int i = 0; i < itemsList.size(); i++) {
                class_2487 itemTags = itemsList.method_10602(i);
                int slot = itemTags.method_10550("Slot");

                if (slot >= 0 && slot < items.size())
                    items.set(slot, class_1799.method_7915(itemTags));
            }
        }

        this.setSelectedFrame(tag.method_10550("SelectedFrame"));
        this.progress = tag.method_10550("Progress");
        this.printTime = tag.method_10550("PrintTime");
        this.storedExperience = tag.method_10550("PrintedPhotographsCount");
        this.advanceFrame = tag.method_10577("AdvanceFrame");
        this.process = Lightroom.Process.fromStringOrDefault(tag.method_10558("Process"), Lightroom.Process.REGULAR);
        if (tag.method_10573("LastPlayerName", class_2520.field_33258)) {
            this.lastPlayerName = tag.method_10558("LastPlayerName");
        }
    }

    @Override
    protected void method_11007(@NotNull class_2487 tag) {
        super.method_11007(tag);
        class_1262.method_5426(tag, items);
        if (getSelectedFrameIndex() > 0)
            tag.method_10569("SelectedFrame", getSelectedFrameIndex());
        if (progress > 0)
            tag.method_10569("Progress", progress);
        if (printTime > 0)
            tag.method_10569("PrintTime", printTime);
        if (storedExperience > 0)
            tag.method_10569("PrintedPhotographsCount", storedExperience);
        if (advanceFrame)
            tag.method_10556("AdvanceFrame", true);
        if (process != Lightroom.Process.REGULAR)
            tag.method_10582("Process", process.method_15434());
        if (lastPlayerName != null)
            tag.method_10582("LastPlayerName", lastPlayerName);
    }

    protected class_2371<class_1799> getItems() {
        return this.items;
    }

    @Override
    public int method_5439() {
        return Lightroom.SLOTS;
    }

    @Override
    public boolean method_5442() {
        return getItems().stream().allMatch(class_1799::method_7960);
    }

    @Override
    public @NotNull class_1799 method_5438(int slot) {
        return getItems().get(slot);
    }

    @Override
    public @NotNull class_1799 method_5434(int slot, int amount) {
        class_1799 itemStack = class_1262.method_5430(getItems(), slot, amount);
        if (!itemStack.method_7960())
            inventoryContentsChanged(slot);
        return itemStack;
    }

    @Override
    public @NotNull class_1799 method_5441(int slot) {
        return class_1262.method_5428(getItems(), slot);
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        this.getItems().set(slot, stack);
        if (stack.method_7947() > this.method_5444()) {
            stack.method_7939(this.method_5444());
        }
        inventoryContentsChanged(slot);
    }

    @Override
    public void method_5448() {
        getItems().clear();
        inventoryContentsChanged(-1);
    }

    @Override
    public void method_5431() {
        super.method_5431();
        if (field_11863 != null && !field_11863.field_9236) {
            field_11863.method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31028);
        }
    }


    // Sync:

    @Override
    @Nullable
    public class_2622 method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public @NotNull class_2487 method_16887() {
        return method_38244();
    }
}
