package io.github.mortuusars.exposure.network.packet.server;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.data.storage.ExposureSavedData;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.packet.IPacket;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public record QueryExposureDataC2SP(String id) implements IPacket {
    
    public static final class_2960 ID = Exposure.resource("query_exposure_data");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10814(id);
        return buffer;
    }

    public static QueryExposureDataC2SP fromBuffer(class_2540 buffer) {
        return new QueryExposureDataC2SP(buffer.method_19772());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        Preconditions.checkArgument(player != null, "Cannot handle QueryExposureDataPacket: Player was null");

        Optional<ExposureSavedData> exposureSavedData = ExposureServer.getExposureStorage().getOrQuery(id);

        if (exposureSavedData.isEmpty())
            Exposure.LOGGER.error("Cannot get exposure data with an id '" + id + "'. Result is null.");
        else {
            ExposureServer.getExposureSender().sendTo(player, id, exposureSavedData.get());
        }

        return true;
    }
}
