package io.github.mortuusars.exposure.data.transfer;

import io.github.mortuusars.exposure.data.storage.ExposureSavedData;
import net.minecraft.class_1657;

public interface IExposureSender {
    void send(String id, ExposureSavedData exposureData);
    void sendTo(class_1657 player, String id, ExposureSavedData exposureData);
}
