package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4184.class)
public abstract class SelfieCameraMixin {
    @Inject(method = "getMaxZoom", at = @At(value = "RETURN"), cancellable = true)
    private void getMaxZoom(double pStartingDistance, CallbackInfoReturnable<Double> cir) {
        if (Viewfinder.isLookingThrough())
            cir.setReturnValue(Math.min(Viewfinder.getSelfieCameraDistance(), cir.getReturnValue()));
    }
}
