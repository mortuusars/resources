package io.github.mortuusars.exposure.data.transfer;

import net.minecraft.class_2487;

public interface IExposureReceiver {
    void receivePart(String id, int width, int height, class_2487 properties, int offset, byte[] partBytes);
}
