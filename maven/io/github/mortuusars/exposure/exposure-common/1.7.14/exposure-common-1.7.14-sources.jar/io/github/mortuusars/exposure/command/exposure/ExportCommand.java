package io.github.mortuusars.exposure.command.exposure;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.command.argument.ExposureLookArgument;
import io.github.mortuusars.exposure.command.argument.ExposureSizeArgument;
import io.github.mortuusars.exposure.command.suggestion.ExposureIdSuggestionProvider;
import io.github.mortuusars.exposure.data.ExposureLook;
import io.github.mortuusars.exposure.data.ExposureSize;
import io.github.mortuusars.exposure.data.storage.ExposureSavedData;
import io.github.mortuusars.exposure.data.storage.ServersideExposureExporter;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_5218;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class ExportCommand {
    public static LiteralArgumentBuilder<class_2168> get() {
        return method_9247("export")
                .requires((stack) -> stack.method_9259(3))
                .then(id())
                .then(all());
    }

    private static ArgumentBuilder<class_2168, ?> id() {
        return method_9247("id")
                .then(method_9244("id", StringArgumentType.string())
                        .suggests(new ExposureIdSuggestionProvider())
                        .executes(context -> exportExposures(context.getSource(),
                                List.of(StringArgumentType.getString(context, "id")),
                                ExposureSize.X1,
                                ExposureLook.REGULAR))
                        .then(method_9244("size", new ExposureSizeArgument())
                                .executes(context -> exportExposures(context.getSource(),
                                        List.of(StringArgumentType.getString(context, "id")),
                                        ExposureSizeArgument.getSize(context, "size"),
                                        ExposureLook.REGULAR))
                                .then(method_9244("look", new ExposureLookArgument())
                                        .executes(context -> exportExposures(context.getSource(),
                                                List.of(StringArgumentType.getString(context, "id")),
                                                ExposureSizeArgument.getSize(context, "size"),
                                                ExposureLookArgument.getLook(context, "look"))))));
    }

    private static ArgumentBuilder<class_2168, ?> all() {
        return method_9247("all")
                .executes(context -> exportAll(context.getSource(), ExposureSize.X1, ExposureLook.REGULAR))
                .then(method_9244("size", new ExposureSizeArgument())
                        .executes(context -> exportAll(context.getSource(),
                                ExposureSizeArgument.getSize(context, "size"),
                                ExposureLook.REGULAR))
                        .then(method_9244("look", new ExposureLookArgument())
                                .executes(context -> exportAll(context.getSource(),
                                        ExposureSizeArgument.getSize(context, "size"),
                                        ExposureLookArgument.getLook(context, "look")))));
    }

    private static int exportAll(class_2168 source, ExposureSize size, ExposureLook look) {
        List<String> ids = ExposureServer.getExposureStorage().getAllIds();
        return exportExposures(source, ids, size, look);
    }

    private static int exportExposures(class_2168 stack, List<String> exposureIds, ExposureSize size, ExposureLook look) {
        int savedCount = 0;

        File folder = stack.method_9211().method_27050(class_5218.field_24188).resolve("exposures").toFile();
        boolean ignored = folder.mkdirs();

        for (String id : exposureIds) {
            Optional<ExposureSavedData> data = ExposureServer.getExposureStorage().getOrQuery(id);
            if (data.isEmpty()) {
                stack.method_9213(class_2561.method_43469("command.exposure.export.failure.not_found", id));
                continue;
            }

            ExposureSavedData exposureSavedData = data.get();
            String name = id + look.getIdSuffix();

            boolean saved = new ServersideExposureExporter(name)
                    .withFolder(folder.getAbsolutePath().replace("\\.\\", "\\").replace("/./", "/"))
                    .withModifier(look.getModifier())
                    .withSize(size)
                    .save(exposureSavedData);

            if (saved)
                stack.method_9226(() ->
                        class_2561.method_43469("command.exposure.export.success.saved_exposure_id", id), true);

            savedCount++;
        }

        if (savedCount > 0) {
            String folderPath = getFolderPath(folder);
            class_2561 folderComponent = class_2561.method_43470(folderPath)
                    .method_27692(class_124.field_1073)
                    .method_27694(arg -> arg.method_10958(new class_2558(class_2558.class_2559.field_11746, folderPath)));
            class_2561 component = class_2561.method_43469("command.exposure.export.success.result", savedCount, folderComponent);
            stack.method_9226(() -> component, true);
        } else
            stack.method_9213(class_2561.method_43471("command.exposure.export.failure.none_saved"));

        return 0;
    }

    @NotNull
    private static String getFolderPath(File folder) {
        String folderPath;
        try {
            folderPath = folder.getCanonicalPath();
        } catch (IOException e) {
            Exposure.LOGGER.error(e.toString());
            folderPath = folder.getAbsolutePath();
        }
        return folderPath;
    }
}
