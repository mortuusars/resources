package io.github.mortuusars.exposure.data.filter;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2960;

@SuppressWarnings("ClassCanBeRecord")
public class Filter {
    public static final class_2960 DEFAULT_GLASS_TEXTURE = Exposure.resource("textures/gui/filter/stained_glass.png");
    public static final int DEFAULT_TINT_COLOR = 0xFFFFFF;

    private final class_1856 ingredient;
    private final class_2960 shader;
    private final class_2960 attachmentTexture;
    private final int tintColor;

    public Filter(class_1856 ingredient, class_2960 shader, class_2960 attachmentTexture, int tintColor) {
        this.ingredient = ingredient;
        this.shader = shader;
        this.attachmentTexture = attachmentTexture;
        this.tintColor = tintColor;
    }

    public boolean matches(class_1799 stack) {
        return ingredient.method_8093(stack);
    }

    public class_1856 getIngredient() {
        return ingredient;
    }

    public class_2960 getShader() {
        return shader;
    }

    public class_2960 getAttachmentTexture() {
        return attachmentTexture;
    }

    public int getTintColor() {
        return tintColor;
    }
}
