package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.camera.CameraClient;
import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.gui.screen.camera.ViewfinderControlsScreen;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public abstract class MinecraftMixin {
    @Inject(method = "setScreen", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;added()V"))
    void onSetScreen(class_437 screen, CallbackInfo ci) {
        if (Viewfinder.isOpen() && !(screen instanceof ViewfinderControlsScreen)) {
            class_746 player = class_310.method_1551().field_1724;
            if (player != null)
                CameraClient.deactivate(player);
        }
    }
}
