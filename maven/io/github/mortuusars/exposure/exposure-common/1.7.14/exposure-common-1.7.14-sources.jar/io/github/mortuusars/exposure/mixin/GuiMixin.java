package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.item.StackedPhotographsItem;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public abstract class GuiMixin {
    @Inject(method = "render", at = @At(value = "HEAD"), cancellable = true)
    private void renderGui(class_332 guiGraphics, float partialTick, CallbackInfo ci) {
        if (Viewfinder.isLookingThrough())
            ci.cancel();
    }

    @Inject(method = "renderCrosshair", at = @At(value = "HEAD"), cancellable = true)
    private void renderCrosshair(class_332 guiGraphics, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (Config.Client.PHOTOGRAPH_IN_HAND_HIDE_CROSSHAIR.get() && mc.field_1724 != null && mc.field_1724.method_36455() > 25f
                && (mc.field_1724.method_6047().method_7909() instanceof PhotographItem || mc.field_1724.method_6047().method_7909() instanceof StackedPhotographsItem)
                && mc.field_1724.method_6079().method_7960())
            ci.cancel();
    }
}
