package io.github.mortuusars.exposure.integration.kubejs.event;

import dev.latvian.mods.kubejs.player.PlayerEventJS;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2487;

/**
 * Can be used to add additional data to the frame or modify existing data. This data can be used in advancements or quests afterward.
 * Fired only on the server side.
 */
public class ModifyFrameDataEventJS extends PlayerEventJS {
    private final class_1657 player;
    private final class_1799 cameraStack;
    private final class_2487 frame;
    private final List<class_1297> entitiesInFrame;

    public ModifyFrameDataEventJS(class_1657 player, class_1799 cameraStack, class_2487 frame, List<class_1297> entitiesInFrame) {
        this.player = player;
        this.cameraStack = cameraStack;
        this.frame = frame;
        this.entitiesInFrame = entitiesInFrame;
    }

    @Override
    public class_1657 getEntity() {
        return player;
    }

    @Override
    public class_1657 getPlayer() {
        return player;
    }

    public class_1799 getCameraStack() {
        return cameraStack;
    }

    public class_2487 getFrame() {
        return frame;
    }

    public List<class_1297> getEntitiesInFrame() {
        return entitiesInFrame;
    }
}
