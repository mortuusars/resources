package io.github.mortuusars.exposure.sound;

import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.PlayOnePerPlayerSoundS2CP;
import io.github.mortuusars.exposure.network.packet.client.StopOnePerPlayerSoundS2CP;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;

public class OnePerPlayerSounds {
    public static void play(class_1657 sourcePlayer, class_3414 soundEvent, class_3419 source, float volume, float pitch) {
        if (sourcePlayer.method_37908().field_9236) {
            OnePerPlayerSoundsClient.play(sourcePlayer, soundEvent, source, volume, pitch);
        }
        else if (sourcePlayer instanceof class_3222 serverSourcePlayer) {
            Packets.sendToOtherClients(new PlayOnePerPlayerSoundS2CP(serverSourcePlayer.method_5667(),
                            soundEvent, source, volume, pitch),
                    serverSourcePlayer,
                    serverPlayer -> serverSourcePlayer.method_5739(serverPlayer) < soundEvent.method_43044(1f));
        }
    }

    public static void stop(class_1657 sourcePlayer, class_3414 soundEvent) {
        if (sourcePlayer.method_37908().field_9236) {
            OnePerPlayerSoundsClient.stop(sourcePlayer, soundEvent);
        }
        else if (sourcePlayer instanceof class_3222 serverSourcePlayer) {
            Packets.sendToOtherClients(new StopOnePerPlayerSoundS2CP(serverSourcePlayer.method_5667(), soundEvent),
                    serverSourcePlayer, serverPlayer -> serverSourcePlayer.method_5739(serverPlayer) < soundEvent.method_43044(1f));
        }
    }

    public static void playForAllClients(class_1657 player, class_3414 soundEvent, class_3419 source, float volume, float pitch) {
        if (!player.method_37908().field_9236)
            Packets.sendToAllClients(new PlayOnePerPlayerSoundS2CP(player.method_5667(), soundEvent, source, volume, pitch));
    }
}
