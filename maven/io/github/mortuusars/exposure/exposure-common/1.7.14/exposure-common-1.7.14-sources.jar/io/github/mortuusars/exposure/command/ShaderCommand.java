package io.github.mortuusars.exposure.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.exposure.command.argument.ShaderLocationArgument;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.ApplyShaderS2CP;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2232;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class ShaderCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("shader")
                .requires((stack) -> stack.method_9259(2))
                .then(class_2170.method_9247("apply")
                        .then(class_2170.method_9244("targets", class_2186.method_9308())
                                .then(class_2170.method_9244("shaderLocation", new ShaderLocationArgument())
                                        .executes(ShaderCommand::applyShader))))
                .then(class_2170.method_9247("remove")
                        .then(class_2170.method_9244("targets", class_2186.method_9308())
                                .executes(ShaderCommand::removeShader))));
    }

    private static int applyShader(CommandContext<class_2168> context) {
        class_2960 shaderLocation = class_2232.method_9443(context, "shaderLocation");
        for (class_3222 targetPlayer : getTargetPlayers(context)) {
            Packets.sendToClient(new ApplyShaderS2CP(shaderLocation), targetPlayer);
        }
        return 0;
    }

    private static int removeShader(CommandContext<class_2168> context) {
        class_2960 shaderLocation = new class_2960("minecraft:none");
        for (class_3222 targetPlayer : getTargetPlayers(context)) {
            Packets.sendToClient(new ApplyShaderS2CP(shaderLocation), targetPlayer);
            context.getSource().method_9226(() -> class_2561.method_43471("command.exposure.shader.removed"), false);
        }
        return 0;
    }

    private static List<class_3222> getTargetPlayers(CommandContext<class_2168> context) {
        try {
            return new ArrayList<>(class_2186.method_9312(context, "targets"));
        } catch (CommandSyntaxException e) {
            return Collections.emptyList();
        }
    }
}
