package io.github.mortuusars.exposure;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3908;

public class PlatformHelper {
    @ExpectPlatform
    public static boolean canShear(class_1799 stack) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean canStrip(class_1799 stack) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_2540> extraDataWriter) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static List<String> getDefaultSpoutDevelopmentColorSequence() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static List<String> getDefaultSpoutDevelopmentBWSequence() {
        throw new AssertionError();
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    @ExpectPlatform
    public static boolean isModLoaded(String modId) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean fireShutterOpeningEvent(class_1657 player, class_1799 cameraStack, int lightLevel, boolean shouldFlashFire) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void fireModifyFrameDataEvent(class_3222 player, class_1799 cameraStack, class_2487 frame, List<class_1297> entitiesInFrame) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void fireFrameAddedEvent(class_3222 player, class_1799 cameraStack, class_2487 frame) {
        throw new AssertionError();
    }
}
