package io.github.mortuusars.exposure.camera;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.util.ItemAndStack;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

public abstract class Camera<T extends CameraItem> {
    private static final SortedMap<class_2960, Function<class_1657, @Nullable Camera<?>>> CAMERA_GETTERS = new TreeMap<>();

    public static void registerCameraGetter(class_2960 id, Function<class_1657, @Nullable Camera<?>> cameraGetter) {
        Preconditions.checkState(!CAMERA_GETTERS.containsKey(id), "Camera getter with ID '{}' is already registered.", id);
        CAMERA_GETTERS.put(id, cameraGetter);
    }

    public static <T extends CameraItem> Optional<Camera<T>> getCamera(class_1657 player, Class<T> clazz) {
        for (Function<class_1657, Camera<?>> getter : CAMERA_GETTERS.values()) {
            @Nullable Camera<?> camera = getter.apply(player);
            if (camera != null && camera.get().getItem().getClass().equals(clazz)) {
                @SuppressWarnings("unchecked")
                Camera<T> cameraOfType = (Camera<T>) camera;
                return Optional.of(cameraOfType);
            }
        }

        return Optional.empty();
    }

    public static Optional<Camera<?>> getCamera(class_1657 player) {
        for (Function<class_1657, Camera<?>> getter : CAMERA_GETTERS.values()) {
            @Nullable Camera<?> camera = getter.apply(player);
            if (camera != null) {
                return Optional.of(camera);
            }
        }

        return Optional.empty();
    }

    public abstract void activate(class_1657 player);
    public abstract void deactivate(class_1657 player);
    public abstract ItemAndStack<T> get();

    public void clientTick() {

    }

    public Camera<T> apply(BiConsumer<T, class_1799> function) {
        get().apply(function);
        return this;
    }

    public static void onLocalPlayerTick(class_1657 player) {
        Preconditions.checkState(player.method_7340(), "{} is not a LocalPlayer.", player);
        boolean viewfinderOpen = Viewfinder.isOpen();

        getCamera(player).ifPresentOrElse(camera -> {
            if (!viewfinderOpen) {
                Viewfinder.open();
            } else {
                Viewfinder.update();
            }
            camera.clientTick();
        }, Viewfinder::close);
    }
}
