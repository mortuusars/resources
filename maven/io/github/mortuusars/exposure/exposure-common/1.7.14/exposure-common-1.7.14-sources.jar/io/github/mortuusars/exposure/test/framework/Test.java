package io.github.mortuusars.exposure.test.framework;

import java.util.function.Consumer;
import net.minecraft.class_3222;

@SuppressWarnings("ClassCanBeRecord")
public class Test {
    public final String name;
    public final Consumer<class_3222> test;

    public Test(String name, Consumer<class_3222> test) {
        this.name = name;
        this.test = test;
    }
}
