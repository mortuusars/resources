package io.github.mortuusars.exposure.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.exposure.test.Tests;
import io.github.mortuusars.exposure.test.framework.TestResult;
import io.github.mortuusars.exposure.test.framework.TestingResult;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;

public class TestCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                class_2170.method_9247("test")
                        .requires((commandSourceStack -> commandSourceStack.method_9259(3)))
                        .then(class_2170.method_9247("exposure")
                                .executes(TestCommand::run)));
    }

    private static int run(CommandContext<class_2168> context) {
        try {
            class_3222 player = context.getSource().method_9207();
            TestingResult testingResult = new Tests(player).run();

            class_5250 message = class_2561.method_43470("Testing: ").method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470("Total: " + testingResult.getTotalTestCount() + ".").method_27692(class_124.field_1068));

            for (TestResult failedTest : testingResult.failed()) {
                if (failedTest.error() != null)
                    context.getSource().method_9213(class_2561.method_43470(failedTest.name() + " failed: " + failedTest.error())
                            .method_27692(class_124.field_1079));
            }

            if (testingResult.passed().size() > 0) {
                message.method_27693(" ");
                message.method_10852(class_2561.method_43470("Passed: " + testingResult.passed()
                        .size() + ".").method_27692(class_124.field_1060));
            }

            if (testingResult.failed().size() > 0) {
                message.method_27693(" ");
                message.method_10852(class_2561.method_43470("Failed: " + testingResult.failed()
                        .size() + ".").method_27692(class_124.field_1061));
            }

            if (testingResult.skipped().size() > 0) {
                message.method_27693(" ");
                message.method_10852(class_2561.method_43470("Skipped: " + testingResult.skipped()
                        .size() + ".").method_27692(class_124.field_1080));
            }

            if (testingResult.failed().size() == 0)
                context.getSource().method_9226(() -> message, false);
            else
                context.getSource().method_9213(message);

        } catch (CommandSyntaxException e) {
            throw new RuntimeException(e);
        }

        return 0;
    }
}
