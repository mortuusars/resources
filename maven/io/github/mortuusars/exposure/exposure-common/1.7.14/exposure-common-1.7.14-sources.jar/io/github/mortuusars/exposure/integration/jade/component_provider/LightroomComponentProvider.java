package io.github.mortuusars.exposure.integration.jade.component_provider;

import io.github.mortuusars.exposure.block.entity.Lightroom;
import io.github.mortuusars.exposure.block.entity.LightroomBlockEntity;
import io.github.mortuusars.exposure.integration.jade.ExposureJadePlugin;
import org.jetbrains.annotations.Nullable;
import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IBlockComponentProvider;
import snownee.jade.api.IServerDataProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.config.IPluginConfig;
import snownee.jade.api.ui.IElementHelper;
import snownee.jade.api.view.IServerExtensionProvider;
import snownee.jade.api.view.ViewGroup;
import snownee.jade.impl.ui.ProgressArrowElement;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_241;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public enum LightroomComponentProvider implements IBlockComponentProvider, IServerDataProvider<BlockAccessor>,
        IServerExtensionProvider<LightroomBlockEntity, class_1799> {
    INSTANCE;

    @Override
    public void appendTooltip(ITooltip tooltip, BlockAccessor blockAccessor, IPluginConfig iPluginConfig) {
        class_2487 tag = blockAccessor.getServerData();

        if (tag.method_10577("Empty"))
            return;

        IElementHelper helper = IElementHelper.get();

        tooltip.add(helper.spacer(0, 0));

        class_1799 film = class_1799.method_7915(tag.method_10562("Film"));
        if (!film.method_7960()) {
            tooltip.append(helper.item(film));
            tooltip.append(helper.text(class_2561.method_43470("|").method_27692(class_124.field_1080))
                    .size(new class_241(11, 12))
                    .translate(new class_241(5, 6))
                    .message(null));
        }

        class_1799 paper = class_1799.method_7915(tag.method_10562("Paper"));
        if (!paper.method_7960()) {
            tooltip.append(helper.item(paper));
            tooltip.append(helper.text(class_2561.method_43470("+").method_27692(class_124.field_1080))
                    .size(new class_241(12, 12))
                    .translate(new class_241(5, 6))
                    .message(null));
        }

        for (String dye : new String[] {"Cyan", "Yellow", "Magenta", "Black"}) {
            class_1799 stack = class_1799.method_7915(tag.method_10562(dye));
            if (!stack.method_7960())
                tooltip.append(helper.item(stack));
        }

        tooltip.append(new ProgressArrowElement(tag.method_10583("Progress")));

        tooltip.append(helper.item(class_1799.method_7915(tag.method_10562("Result"))));


        Lightroom.Process process = Lightroom.Process.fromStringOrDefault(tag.method_10558("Process"), Lightroom.Process.REGULAR);
        if (process != Lightroom.Process.REGULAR)
            tooltip.add(helper.text(class_2561.method_43471("gui.exposure.lightroom.process." + process.method_15434())));

        tooltip.add(helper.spacer(0, 2));
    }

    @Override
    public void appendServerData(class_2487 tag, BlockAccessor blockAccessor) {
        if (blockAccessor.getBlockEntity() instanceof LightroomBlockEntity lightroomBlockEntity) {
            if (lightroomBlockEntity.method_5442()) {
                tag.method_10556("Empty", true);
                return;
            }

            tag.method_10566("Film", lightroomBlockEntity.method_5438(Lightroom.FILM_SLOT).method_7953(new class_2487()));
            tag.method_10566("Paper", lightroomBlockEntity.method_5438(Lightroom.PAPER_SLOT).method_7953(new class_2487()));
            tag.method_10566("Cyan", lightroomBlockEntity.method_5438(Lightroom.CYAN_SLOT).method_7953(new class_2487()));
            tag.method_10566("Yellow", lightroomBlockEntity.method_5438(Lightroom.YELLOW_SLOT).method_7953(new class_2487()));
            tag.method_10566("Magenta", lightroomBlockEntity.method_5438(Lightroom.MAGENTA_SLOT).method_7953(new class_2487()));
            tag.method_10566("Black", lightroomBlockEntity.method_5438(Lightroom.BLACK_SLOT).method_7953(new class_2487()));
            tag.method_10566("Result", lightroomBlockEntity.method_5438(Lightroom.RESULT_SLOT).method_7953(new class_2487()));

            tag.method_10582("Process", lightroomBlockEntity.getProcess().method_15434());

            tag.method_10548("Progress", lightroomBlockEntity.getProgressPercentage());
        }
    }

    @Override
    public @Nullable List<ViewGroup<class_1799>> getGroups(class_3222 serverPlayer, class_3218 serverLevel, LightroomBlockEntity lightroomBlockEntity, boolean b) {
        return null;
    }

    @Override
    public class_2960 getUid() {
        return ExposureJadePlugin.LIGHTROOM;
    }
}
