package io.github.mortuusars.exposure.data.storage;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ExposureSavedData extends class_18 {
    public static final String TYPE_PROPERTY = "Type";
    public static final String WAS_PRINTED_PROPERTY = "WasPrinted";
    public static final String TIMESTAMP_PROPERTY = "Timestamp";
    public static final String FROM_FILE_PROPERTY = "FromFile";

    private final int width;
    private final int height;
    private final byte[] pixels;
    private final class_2487 properties;

    public ExposureSavedData(int width, int height, byte[] pixels, class_2487 properties) {
        Preconditions.checkArgument(width >= 0, "Width cannot be negative.");
        Preconditions.checkArgument(height >= 0, "Height cannot be negative.");

        if (pixels.length > width * height)
            Exposure.LOGGER.warn("Pixel count was larger that it supposed to be. This shouldn't happen.");

        this.width = width;
        this.height = height;
        this.pixels = pixels;
        this.properties = properties;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public byte[] getPixels() {
        return pixels;
    }

    public byte getPixel(int x, int y) {
        return pixels[y * width + x];
    }

    @SuppressWarnings("unused")
    public void setPixel(int x, int y, byte value) {
        Preconditions.checkArgument(x >= 0 && x < width,  "X=" + x + " is out of bounds for Width=" + width);
        Preconditions.checkArgument(y >= 0 && y < height,  "Y=" + x + " is out of bounds for Height=" + height);
        pixels[y * width + x] = value;
    }

    public class_2487 getProperties() {
        return properties;
    }

    public @Nullable FilmType getType() {
        String typeString = properties.method_10558(TYPE_PROPERTY);
        return FilmType.byName(typeString);
    }

    @Override
    public @NotNull class_2487 method_75(class_2487 compoundTag) {
        compoundTag.method_10569("width", width);
        compoundTag.method_10569("height", height);
        compoundTag.method_10570("pixels", pixels);
        compoundTag.method_10566("properties", properties);
        return compoundTag;
    }

    public static ExposureSavedData load(class_2487 compoundTag) {
        class_2487 properties = compoundTag.method_10562("properties");

        // Backwards compatibility:
        if (!properties.method_10545(TYPE_PROPERTY)) {
            properties.method_10582(TYPE_PROPERTY, compoundTag.method_10577("black_and_white") ? "black_and_white" : "color");
        }
        if (!properties.method_10545(WAS_PRINTED_PROPERTY)) {
            properties.method_10556(WAS_PRINTED_PROPERTY, compoundTag.method_10577("printed"));
        }

        return new ExposureSavedData(
                compoundTag.method_10550("width"),
                compoundTag.method_10550("height"),
                compoundTag.method_10547("pixels"),
                properties);
    }
}
