package io.github.mortuusars.exposure.util;

import io.github.mortuusars.exposure.Exposure;
import java.io.File;
import java.nio.file.Path;
import net.minecraft.class_310;

public class ClientsideWorldNameGetter {
    
    public static String getWorldName() {
        try {
            if (class_310.method_1551().method_47392()) {
                if (class_310.method_1551().method_1576() != null)
                    return class_310.method_1551().method_1576().method_27728().method_150()
                            .replace('.', '_'); // Folder name has underscores instead of dots.
                else {
                    String gameDirectory = class_310.method_1551().field_1697.getAbsolutePath();
                    Path savesDir = Path.of(gameDirectory, "/saves");

                    File[] dirs = savesDir.toFile().listFiles((dir, name) -> new File(dir, name).isDirectory());

                    if (dirs == null || dirs.length == 0)
                        return "";

                    File lastModified = dirs[0];

                    for (File dir : dirs) {
                        if (dir.lastModified() > lastModified.lastModified())
                            lastModified = dir;
                    }

                    return lastModified.getName();
                }
            }
            else if (class_310.method_1551().method_1558() != null) {
                return class_310.method_1551().method_1558().field_3752;
            }
            else {
                return "Unknown";
            }
        } catch (Exception e) {
            Exposure.LOGGER.error("Failed to get level name: " + e);
            return "Unknown";
        }
    }
}
