package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public record OnFrameAddedS2CP(class_2487 frame) implements IPacket {
    public static final class_2960 ID = Exposure.resource("on_frame_added");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10794(frame);
        return buffer;
    }

    public static OnFrameAddedS2CP fromBuffer(class_2540 buffer) {
        @Nullable class_2487 frame = buffer.method_30617();
        if (frame == null)
            frame = new class_2487();
        return new OnFrameAddedS2CP(frame);
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        ClientPacketsHandler.onFrameAdded(this);
        return true;
    }
}
