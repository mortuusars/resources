package io.github.mortuusars.exposure.recipe;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

public abstract class AbstractNbtTransferringRecipe extends class_1852 {
    private final class_1799 result;
    private final class_1856 transferIngredient;
    private final class_2371<class_1856> ingredients;

    public AbstractNbtTransferringRecipe(class_2960 id, class_1856 transferIngredient, class_2371<class_1856> ingredients, class_1799 result) {
        super(id, class_7710.field_40251);
        this.transferIngredient = transferIngredient;
        this.ingredients = ingredients;
        this.result = result;
    }

    public @NotNull class_1856 getTransferIngredient() {
        return transferIngredient;
    }

    @Override
    public @NotNull class_2371<class_1856> method_8117() {
        return ingredients;
    }

    @Override
    public @NotNull class_1799 method_8110(class_5455 registryAccess) {
        return getResult();
    }

    public @NotNull class_1799 getResult() {
        return result;
    }

    @Override
    public boolean matches(class_8566 container, class_1937 level) {
        if (getTransferIngredient().method_8103() || ingredients.isEmpty())
            return false;

        List<class_1856> unmatchedIngredients = new ArrayList<>(ingredients);
        unmatchedIngredients.add(0, getTransferIngredient());

        int itemsInCraftingGrid = 0;

        for (int i = 0; i < container.method_5439(); i++) {
            class_1799 stack = container.method_5438(i);
            if (!stack.method_7960())
                itemsInCraftingGrid++;

            if (itemsInCraftingGrid > ingredients.size() + 1)
                return false;

            if (!unmatchedIngredients.isEmpty()) {
                for (int j = 0; j < unmatchedIngredients.size(); j++) {
                    if (unmatchedIngredients.get(j).method_8093(stack)) {
                        unmatchedIngredients.remove(j);
                        break;
                    }
                }
            }
        }

        return unmatchedIngredients.isEmpty() && itemsInCraftingGrid == ingredients.size() + 1;
    }

    @Override
    public @NotNull class_1799 assemble(class_8566 container, @NotNull class_5455 registryAccess) {
        for (int index = 0; index < container.method_5439(); index++) {
            class_1799 itemStack = container.method_5438(index);

            if (getTransferIngredient().method_8093(itemStack)) {
                return transferNbt(itemStack, method_8110(registryAccess).method_7972());
            }
        }

        return method_8110(registryAccess);
    }

    public @NotNull class_1799 transferNbt(class_1799 transferIngredientStack, class_1799 recipeResultStack) {
        @Nullable class_2487 transferTag = transferIngredientStack.method_7969();
        if (transferTag != null) {
            if (recipeResultStack.method_7969() != null)
                recipeResultStack.method_7969().method_10543(transferTag);
            else
                recipeResultStack.method_7980(transferTag.method_10553());
        }
        return recipeResultStack;
    }

    @Override
    public boolean method_8113(int width, int height) {
        return ingredients.size() <= width * height;
    }
}
