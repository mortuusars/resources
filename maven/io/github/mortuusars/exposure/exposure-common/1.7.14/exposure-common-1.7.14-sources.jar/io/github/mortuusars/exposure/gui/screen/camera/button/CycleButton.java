package io.github.mortuusars.exposure.gui.screen.camera.button;

import io.github.mortuusars.exposure.gui.screen.element.IElementWithTooltip;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;

public abstract class CycleButton extends class_344 implements IElementWithTooltip {
    protected final class_437 screen;
    protected int count = 1;
    protected int currentIndex = 0;
    protected boolean loop = true;

    public CycleButton(class_437 screen, int x, int y, int width, int height, int u, int v, int yDiffTex, class_2960 texture) {
        super(x, y, width, height, u, v, yDiffTex, texture, button -> {});
        this.screen = screen;
    }

    @Override
    public void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_48579(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float pPartialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, pPartialTick);
    }

    public void renderToolTip(@NotNull class_332 guiGraphics, int mouseX, int mouseY) { }

    public void setupButtonElements(int count, int startingIndex) {
        this.count = count;
        this.currentIndex = startingIndex;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if ((button == 0 || button == 1) && method_25361(mouseX, mouseY)) {
            cycle(button == 1);
            this.method_25354(class_310.method_1551().method_1483());
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta) {
        cycle(delta < 0d);
        this.method_25354(class_310.method_1551().method_1483());
        return true;
    }

    @Override
    public boolean method_25404(int pKeyCode, int pScanCode, int pModifiers) {
        boolean pressed = super.method_25404(pKeyCode, pScanCode, pModifiers);

        if (pressed)
            cycle(class_437.method_25442());

        return pressed;
    }

    protected void cycle(boolean reverse) {
        int value = currentIndex;
        value += reverse ? -1 : 1;
        if (value < 0)
            value = loop ? count - 1 : 0;
        else if (value >= count)
            value = loop ? 0 : count - 1;

        if (currentIndex != value) {
            currentIndex = value;
            onCycle();
        }
    }

    protected void onCycle() {

    }
}
