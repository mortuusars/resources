package io.github.mortuusars.exposure.data.filter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.util.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4309;

public class Filters {
    private static final Map<class_2960, Filter> filters = new HashMap<>();

    public static Map<class_2960, Filter> getFilters() {
        return filters;
    }

    public static Optional<Filter> of(class_1799 stack) {
        for (var filter : filters.values()) {
            if (filter.matches(stack))
                return Optional.of(filter);
        }

        return Optional.empty();
    }

    public static Optional<class_2960> getShaderOf(class_1799 stack) {
        return of(stack).map(Filter::getShader);
    }

    public static class Loader extends class_4309 {
        public static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
        public static final String DIRECTORY = "filters";

        public Loader() {
            super(GSON, DIRECTORY);
        }

        @Override
        protected void apply(Map<class_2960, JsonElement> content, class_3300 resourceManager, class_3695 profiler) {
            filters.clear();

            Exposure.LOGGER.info("Loading exposure filters:");

            for (var entry : content.entrySet()) {
                class_2960 key = entry.getKey();

                // Lenses should be in data/exposure/filters folder.
                // Excluding other namespaces because it potentially can cause conflicts,
                // if some other mod adds their own type of 'filter'.
                if (!key.method_12836().equals(Exposure.ID)) {
                    continue;
                }

                JsonObject jsonObject = entry.getValue().getAsJsonObject();

                deserializeFilter(key, jsonObject).ifPresent(filter -> {
                    filters.put(key, filter);
                    Exposure.LOGGER.info("Filter [" + key + ", " + filter.getShader() + "] added.");
                });
            }

            if (filters.isEmpty()) {
                Exposure.LOGGER.info("No filters have been loaded.");
            }
        }

        private Optional<Filter> deserializeFilter(class_2960 key, JsonObject jsonObject) {
            try {
                class_1856 ingredient = class_1856.method_52177(jsonObject.get("item"));
                if (ingredient.method_8103()) {
                    Exposure.LOGGER.error("Filter '{}' was not loaded: ingredient cannot be empty.", key);
                    return Optional.empty();
                }

                class_2960 shader = new class_2960(jsonObject.get("shader").getAsString());

                class_2960 attachmentTexture = Filter.DEFAULT_GLASS_TEXTURE;
                if (jsonObject.has("attachment_texture")) {
                    attachmentTexture = new class_2960(jsonObject.get("attachment_texture").getAsString());
                }

                int tintColor = Filter.DEFAULT_TINT_COLOR;
                if (jsonObject.has("tint_color")) {
                    String hexString = jsonObject.get("tint_color").getAsString();
                    tintColor = Color.getRGBFromHex(hexString);
                }

                return Optional.of(new Filter(ingredient, shader, attachmentTexture, tintColor));
            } catch (Exception e) {
                Exposure.LOGGER.error("Filter '{}' was not loaded: {}", key, e);
                return Optional.empty();
            }
        }
    }
}