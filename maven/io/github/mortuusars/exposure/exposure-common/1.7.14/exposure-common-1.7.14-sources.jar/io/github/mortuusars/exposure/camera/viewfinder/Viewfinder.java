package io.github.mortuusars.exposure.camera.viewfinder;


import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.camera.CameraClient;
import io.github.mortuusars.exposure.camera.infrastructure.FocalRange;
import io.github.mortuusars.exposure.camera.infrastructure.ZoomDirection;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.util.Fov;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import net.minecraft.class_746;

public class Viewfinder {
    public static final float ZOOM_STEP = 8f;
    public static final float ZOOM_PRECISE_MODIFIER = 0.25f;
    private static boolean isOpen;

    private static FocalRange focalRange = new FocalRange(18, 55);
    private static double targetFov = 90f;
    private static double currentFov = targetFov;
    private static boolean shouldRestoreFov;

    public static boolean isOpen() {
        return isOpen;
    }

    public static boolean isLookingThrough() {
        return isOpen() && (class_310.method_1551().field_1690.method_31044() == class_5498.field_26664
                || class_310.method_1551().field_1690.method_31044() == class_5498.field_26666);
    }

    public static void open() {
        class_746 player = class_310.method_1551().field_1724;
        Preconditions.checkState(player != null, "Player should not be null");
        Preconditions.checkState(player.method_37908().method_8608(), "This should be called only client-side.");

        if (isOpen())
            return;

        Camera<?> camera = Camera.getCamera(player).orElseThrow();
        CameraItem cameraItem = camera.get().getItem();
        class_1799 cameraStack = camera.get().getStack();

        focalRange = cameraItem.getFocalRange(cameraStack);
        targetFov = Fov.focalLengthToFov(class_3532.method_15363(cameraItem.getFocalLength(cameraStack), focalRange.min(), focalRange.max()));

        isOpen = true;

        ViewfinderShader.setPrevious(ViewfinderShader.getCurrent().orElse(null));
        ViewfinderShader.update();
        ViewfinderOverlay.setup();
    }

    public static void update() {
        @Nullable class_746 player = class_310.method_1551().field_1724;
        if (player == null) return;

        updateSelfieMode();
        ViewfinderShader.update();
    }

    public static void updateSelfieMode() {
        boolean inSelfieMode = class_310.method_1551().field_1690.method_31044() == class_5498.field_26666;
        CameraClient.setSelfieMode(inSelfieMode);
    }

    public static void close() {
        if (!isOpen()) {
            return;
        }

        isOpen = false;
        targetFov = class_310.method_1551().field_1690.method_41808().method_41753();

        ViewfinderShader.removeShader();
        ViewfinderShader.restorePrevious();
    }

    public static FocalRange getFocalRange() {
        return focalRange;
    }

    public static double getCurrentFov() {
        return currentFov;
    }

    public static float getSelfieCameraDistance() {
        return 1.75f;
    }

    public static void zoom(ZoomDirection direction, boolean precise) {
        double step = ZOOM_STEP * (1f - class_3532.method_15350((focalRange.min() - currentFov) / focalRange.min(), 0.3f, 1f));
        double inertia = Math.abs(targetFov - currentFov) * 0.8f;
        double change = step + inertia;

        if (precise)
            change *= ZOOM_PRECISE_MODIFIER;

        double prevFov = targetFov;

        double fov = class_3532.method_15350(targetFov + (direction == ZoomDirection.IN ? -change : +change),
                Fov.focalLengthToFov(focalRange.max()),
                Fov.focalLengthToFov(focalRange.min()));

        if (Math.abs(prevFov - fov) > 0.01f)
            Objects.requireNonNull(class_310.method_1551().field_1724).method_43077(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get());

        targetFov = fov;

        CameraClient.setZoom(Fov.fovToFocalLength(fov));
    }

    public static double modifyMouseSensitivity(double sensitivity) {
        if (!isLookingThrough())
            return sensitivity;

        double modifier = class_3532.method_15350(1f - (Config.Client.VIEWFINDER_ZOOM_SENSITIVITY_MODIFIER.get()
                * ((class_310.method_1551().field_1690.method_41808().method_41753() - currentFov) / 5f)), 0.01, 2f);
        return sensitivity * modifier;
    }

    public static boolean handleMouseScroll(ZoomDirection direction) {
        if (isLookingThrough()) {
            zoom(direction, false);
            return true;
        }

        return false;
    }

    public static double modifyFov(double fov) {
        if (isLookingThrough()) {
            currentFov = class_3532.method_16436(Math.min(0.8f * class_310.method_1551().method_1534(), 0.8f), currentFov, targetFov);
            shouldRestoreFov = true;
            return currentFov;
        }
        else if (shouldRestoreFov && Math.abs(currentFov - fov) > 0.00001) {
            currentFov = class_3532.method_16436(Math.min(0.95f * class_310.method_1551().method_1534(), 0.95f), currentFov, fov);
            return currentFov;
        } else {
            currentFov = fov;
            shouldRestoreFov = false;
            return fov;
        }
    }
}
