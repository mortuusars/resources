package io.github.mortuusars.exposure.util;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.joml.Matrix4f;

public class GuiUtil {
    public static void blit(class_4587 poseStack, float minX, float maxX, float minY, float maxY, float blitOffset, float minU, float maxU, float minV, float maxV) {
        Matrix4f matrix = poseStack.method_23760().method_23761();
        RenderSystem.setShader(class_757::method_34542);
        class_287 bufferbuilder = class_289.method_1348().method_1349();
        bufferbuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1585);
        bufferbuilder.method_22918(matrix, minX, maxY, blitOffset).method_22913(minU, maxV).method_1344();
        bufferbuilder.method_22918(matrix, maxX, maxY, blitOffset).method_22913(maxU, maxV).method_1344();
        bufferbuilder.method_22918(matrix, maxX, minY, blitOffset).method_22913(maxU, minV).method_1344();
        bufferbuilder.method_22918(matrix, minX, minY, blitOffset).method_22913(minU, minV).method_1344();
        class_286.method_43433(bufferbuilder.method_1326());
    }

    public static void blit(class_4587 poseStack, float x, float y, float width, float height, int u, int v, int textureWidth, int textureHeight, float blitOffset) {
        blit(poseStack, x, x + width, y, y + height, blitOffset,
                (u + 0.0F) / (float)textureWidth, (u + width) / (float)textureWidth, (v + 0.0F) / (float)textureHeight, (v + height) / (float)textureHeight);
    }
}
