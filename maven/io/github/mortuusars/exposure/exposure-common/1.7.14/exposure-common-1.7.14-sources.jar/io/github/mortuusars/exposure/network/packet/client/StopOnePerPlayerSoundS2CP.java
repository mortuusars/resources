package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.packet.IPacket;
import io.github.mortuusars.exposure.sound.OnePerPlayerSounds;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_7923;

public record StopOnePerPlayerSoundS2CP(UUID sourcePlayerId, class_3414 soundEvent) implements IPacket {
    
    public static final class_2960 ID = Exposure.resource("stop_one_per_player_sound");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10797(sourcePlayerId);
        buffer.method_10812(soundEvent.method_14833());
        return buffer;
    }

    public static StopOnePerPlayerSoundS2CP fromBuffer(class_2540 buffer) {
        UUID uuid = buffer.method_10790();
        class_2960 soundEventLocation = buffer.method_10810();
        @Nullable class_3414 soundEvent = class_7923.field_41172.method_10223(soundEventLocation);
        if (soundEvent == null)
            soundEvent = class_3417.field_14624.comp_349();

        return new StopOnePerPlayerSoundS2CP(uuid, soundEvent);
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        if (class_310.method_1551().field_1687 != null) {
            @Nullable class_1657 sourcePlayer = class_310.method_1551().field_1687.method_18470(sourcePlayerId);
            if (sourcePlayer != null)
                class_310.method_1551().execute(() -> OnePerPlayerSounds.stop(sourcePlayer, soundEvent));
            else
                Exposure.LOGGER.debug("Cannot stop OnePerPlayer sound. SourcePlayer was not found by it's UUID.");
        }

        return true;
    }
}
