package io.github.mortuusars.exposure.integration.kubejs.event;

import dev.latvian.mods.kubejs.player.PlayerEventJS;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

/**
 * Fired when Camera tries to take a photo. Cancelable.
 * Client-side event wouldn't fire if server-side event was canceled.
 * If canceled only on the client - shutter would be opened, but the image would not be captured.
 * All checks are passed at this point, and if this event is not canceled - photo will be taken.
 */
public class ShutterOpeningEventJS extends PlayerEventJS {
    private final class_1657 player;
    private final class_1799 cameraStack;
    private final int lightLevel;
    private final boolean shouldFlashFire;

    public ShutterOpeningEventJS(class_1657 player, class_1799 cameraStack, int lightLevel, boolean shouldFlashFire) {
        this.player = player;
        this.cameraStack = cameraStack;
        this.lightLevel = lightLevel;
        this.shouldFlashFire = shouldFlashFire;
    }

    @Override
    public class_1657 getEntity() {
        return player;
    }

    @Override
    public class_1657 getPlayer() {
        return player;
    }

    public class_1799 getCameraStack() {
        return cameraStack;
    }

    public int getLightLevel() {
        return lightLevel;
    }

    public boolean shouldFlashFire() {
        return shouldFlashFire;
    }
}
