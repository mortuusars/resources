package io.github.mortuusars.exposure.network.packet.client;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public record StartExposureS2CP(@NotNull String exposureId, @NotNull class_1268 activeHand,
                                boolean flashHasFired, int lightLevel) implements IPacket {
    public static final class_2960 ID = Exposure.resource("start_exposure");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        Preconditions.checkState(!exposureId.isEmpty(), "path cannot be empty.");
        buffer.method_10814(exposureId);
        buffer.method_10817(activeHand);
        buffer.writeBoolean(flashHasFired);
        buffer.writeInt(lightLevel);
        return buffer;
    }

    public static StartExposureS2CP fromBuffer(class_2540 buffer) {
        return new StartExposureS2CP(buffer.method_19772(), buffer.method_10818(class_1268.class), buffer.readBoolean(), buffer.readInt());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        ClientPacketsHandler.startExposure(this);
        return true;
    }
}
