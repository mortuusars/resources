package io.github.mortuusars.exposure.menu;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.item.AlbumItem;
import io.github.mortuusars.exposure.item.AlbumPage;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.server.AlbumSignC2SP;
import io.github.mortuusars.exposure.util.ItemAndStack;
import io.github.mortuusars.exposure.util.Side;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_3675;
import net.minecraft.class_3915;
import net.minecraft.class_3917;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;

public class AlbumMenu extends class_1703 {
    public static final int CANCEL_ADDING_PHOTO_BUTTON = -1;
    public static final int PREVIOUS_PAGE_BUTTON = 0;
    public static final int NEXT_PAGE_BUTTON = 1;
    public static final int LEFT_PAGE_PHOTO_BUTTON = 2;
    public static final int RIGHT_PAGE_PHOTO_BUTTON = 3;
    public static final int ENTER_SIGN_MODE_BUTTON = 4;
    public static final int SIGN_BUTTON = 5;
    public static final int CANCEL_SIGNING_BUTTON = 6;

    protected final ItemAndStack<AlbumItem> album;
    protected final boolean editable;

    protected final List<AlbumPage> pages;

    protected final List<AlbumPhotographSlot> photographSlots = new ArrayList<>();
    protected final List<AlbumPlayerInventorySlot> playerInventorySlots = new ArrayList<>();

    protected class_3915 currentSpreadIndex = class_3915.method_17403();

    @Nullable
    protected Side sideBeingAddedTo = null;
    protected boolean signing;
    protected String title = "";

    protected final Map<Integer, Consumer<class_1657>> buttonActions = new HashMap<>() {{
        put(CANCEL_ADDING_PHOTO_BUTTON, p -> {
            sideBeingAddedTo = null;
            if (!method_34255().method_7960()) {
                p.method_31548().method_7398(method_34255());
                method_34254(class_1799.field_8037);
            }
            updatePlayerInventorySlots();
        });
        put(PREVIOUS_PAGE_BUTTON, p -> {
            method_7604(p, CANCEL_ADDING_PHOTO_BUTTON);
            setCurrentSpreadIndex(Math.max(0, getCurrentSpreadIndex() - 1));
        });
        put(NEXT_PAGE_BUTTON, p -> {
            method_7604(p, CANCEL_ADDING_PHOTO_BUTTON);
            setCurrentSpreadIndex(Math.min((getPages().size() - 1) / 2, getCurrentSpreadIndex() + 1));
        });
        put(LEFT_PAGE_PHOTO_BUTTON, p -> onPhotoButtonPress(p, Side.LEFT));
        put(RIGHT_PAGE_PHOTO_BUTTON, p -> onPhotoButtonPress(p, Side.RIGHT));
        put(ENTER_SIGN_MODE_BUTTON, p -> {
            signing = true;
            sideBeingAddedTo = null;
        });
        put(SIGN_BUTTON, p -> signAlbum(p));
        put(CANCEL_SIGNING_BUTTON, p -> signing = false);
    }};

    public AlbumMenu(int containerId, class_1661 playerInventory, ItemAndStack<AlbumItem> album, boolean editable) {
        this(Exposure.MenuTypes.ALBUM.get(), containerId, playerInventory, album, editable);
    }

    protected AlbumMenu(class_3917<? extends class_1703> type, int containerId, class_1661 playerInventory, ItemAndStack<AlbumItem> album, boolean editable) {
        super(type, containerId);
        this.album = album;
        this.editable = editable;

        List<AlbumPage> albumPages = album.getItem().getPages(album.getStack());
        pages = isAlbumEditable() ? new ArrayList<>(albumPages) : albumPages;

        if (isAlbumEditable()) {
            while (pages.size() < album.getItem().getMaxPages()) {
                addEmptyPage();
            }
        }

        addPhotographSlots();
        addPlayerInventorySlots(playerInventory, 70, 115);
        method_17362(currentSpreadIndex);
    }

    private void addPhotographSlots() {
        class_1799[] photographs = pages.stream().map(AlbumPage::getPhotographStack).toArray(class_1799[]::new);
        class_1277 container = new class_1277(photographs);

        for (int i = 0; i < container.method_5439(); i++) {
            int x = i % 2 == 0 ? 71 : 212;
            int y = 67;
            AlbumPhotographSlot slot = new AlbumPhotographSlot(container, i, x, y);
            method_7621(slot);
            photographSlots.add(slot);
        }

        container.method_5489(c -> {
            List<AlbumPage> pages = getPages();
            for (int pageIndex = 0; pageIndex < pages.size(); pageIndex++) {
                AlbumPage page = pages.get(pageIndex);
                class_1799 stack = container.method_5438(pageIndex);
                page.setPhotographStack(stack);
            }
            updateAlbumStack();
        });
    }

    private void addPlayerInventorySlots(class_1661 playerInventory, int x, int y) {
        // Player inventory slots
        for (int row = 0; row < 3; ++row) {
            for (int column = 0; column < 9; ++column) {
                AlbumPlayerInventorySlot slot = new AlbumPlayerInventorySlot(playerInventory, column + row * 9 + 9,
                        x + column * 18, y + row * 18);
                method_7621(slot);
                playerInventorySlots.add(slot);
            }
        }

        // Player hotbar slots
        // Hotbar should go after main inventory for Shift+Click to work properly.
        for (int index = 0; index < 9; ++index) {
            boolean disabled = index == playerInventory.field_7545 && playerInventory.method_7391().method_7909() instanceof AlbumItem;
            AlbumPlayerInventorySlot slot = new AlbumPlayerInventorySlot(playerInventory, index,
                    x + index * 18, y + 58) {
                @Override
                public boolean method_7674(class_1657 player) {
                    return !disabled;
                }

                @Override
                public boolean method_7680(class_1799 stack) {
                    return !disabled;
                }
            };
            method_7621(slot);
            playerInventorySlots.add(slot);
        }
    }

    protected void updatePlayerInventorySlots() {
        boolean isInAddingPhotographMode = isInAddingPhotographMode();
        for (AlbumPlayerInventorySlot slot : playerInventorySlots) {
            slot.setActive(isInAddingPhotographMode);
        }
    }

    public boolean isAlbumEditable() {
        return editable;
    }

    public boolean isInAddingPhotographMode() {
        return getSideBeingAddedTo() != null;
    }

    public boolean isInSigningMode() {
        return signing;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String authorName) {
        this.title = authorName;
    }

    public boolean canSignAlbum() {
        for (AlbumPage page : getPages()) {
            if (!page.getPhotographStack().method_7960() || page.getNote().left().map(note -> !note.isEmpty()).orElse(false))
                return true;
        }
        return false;
    }

    protected void signAlbum(class_1657 player) {
        if (!player.method_37908().field_9236)
            return;

        if (!canSignAlbum())
            throw new IllegalStateException("Cannot sign the album.\n" + Arrays.toString(getPages().toArray()));

        Packets.sendToServer(new AlbumSignC2SP(title));
    }

    public void updateAlbumStack() {
        List<AlbumPage> pages = getPages();
        for (int pageIndex = 0; pageIndex < pages.size(); pageIndex++) {
            AlbumPage page = pages.get(pageIndex);
            album.getItem().setPage(album.getStack(), page, pageIndex);
        }
    }

    protected void addEmptyPage() {
        AlbumPage page = album.getItem().createEmptyPage();
        pages.add(page);
        album.getItem().addPage(album.getStack(), page);
    }

    public List<AlbumPlayerInventorySlot> getPlayerInventorySlots() {
        return playerInventorySlots;
    }

    public List<AlbumPage> getPages() {
        return pages;
    }

    public Optional<AlbumPage> getPage(Side side) {
        return getPage(getCurrentSpreadIndex() * 2 + side.getIndex());
    }

    public Optional<AlbumPage> getPage(int pageIndex) {
        if (pageIndex <= getPages().size() - 1)
            return Optional.ofNullable(getPages().get(pageIndex));

        return Optional.empty();
    }

    public Optional<AlbumPhotographSlot> getPhotographSlot(Side side) {
        return getPhotographSlot(getCurrentSpreadIndex() * 2 + (side == Side.LEFT ? 0 : 1));
    }

    public Optional<AlbumPhotographSlot> getPhotographSlot(int index) {
        if (index >= 0 && index < photographSlots.size())
            return Optional.ofNullable(photographSlots.get(index));

        return Optional.empty();
    }

    public class_1799 getPhotograph(Side side) {
        return getPhotographSlot(side).map(class_1735::method_7677).orElse(class_1799.field_8037);
    }

    public int getCurrentSpreadIndex() {
        return this.currentSpreadIndex.method_17407();
    }

    public void setCurrentSpreadIndex(int spreadIndex) {
        this.currentSpreadIndex.method_17404(spreadIndex);
    }

    public @Nullable Side getSideBeingAddedTo() {
        return sideBeingAddedTo;
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        @Nullable Consumer<class_1657> buttonAction = buttonActions.get(id);
        if (buttonAction != null) {
            buttonAction.accept(player);
            return true;
        }

        return false;
    }

    private void onPhotoButtonPress(class_1657 player, Side side) {
        Preconditions.checkArgument(isAlbumEditable(),
                "Photo Button should be disabled and hidden when Album is not editable. " + album.getStack());

        Optional<AlbumPhotographSlot> photographSlot = getPhotographSlot(side);
        if (photographSlot.isEmpty())
            return;

        AlbumPhotographSlot slot = photographSlot.get();
        if (!slot.method_7681()) {
            sideBeingAddedTo = side;
        }
        else {
            class_1799 stack = slot.method_7677();
            if (!player.method_31548().method_7394(stack))
                player.method_7328(stack, false);

            slot.method_7673(class_1799.field_8037);
        }

        updatePlayerInventorySlots();
    }

    @Override
    public void method_7593(int slotId, int button, class_1713 clickType, class_1657 player) {
        // Both sides

        if (sideBeingAddedTo == null || slotId < 0 || slotId >= field_7761.size()) {
            super.method_7593(slotId, button, clickType, player);
            return;
        }

        class_1735 slot = field_7761.get(slotId);
        class_1799 stack = slot.method_7677();

        if (button == class_3675.field_32000
                && slot instanceof AlbumPlayerInventorySlot
                && stack.method_7909() instanceof PhotographItem
                && method_34255().method_7960()) {
            int pageIndex = getCurrentSpreadIndex() * 2 + sideBeingAddedTo.getIndex();
            Optional<AlbumPhotographSlot> photographSlot = getPhotographSlot(pageIndex);
            if (photographSlot.isEmpty() || !photographSlot.get().method_7677().method_7960())
                return;

            photographSlot.get().method_7673(stack);
            slot.method_7673(class_1799.field_8037);

            if (player.method_37908().field_9236)
                player.method_5783(Exposure.SoundEvents.PHOTOGRAPH_PLACE.get(), 0.8f, 1.1f);

            sideBeingAddedTo = null;
            updatePlayerInventorySlots();
        }
        else
            super.method_7593(slotId, button, clickType, player);
    }

    @Override
    public @NotNull class_1799 method_7601(class_1657 player, int index) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return !isAlbumEditable() || (player.method_6047().method_7909() instanceof AlbumItem
                || player.method_6079().method_7909() instanceof AlbumItem);
    }

    public static AlbumMenu fromBuffer(int containerId, class_1661 inventory, class_2540 buffer) {
        return new AlbumMenu(containerId, inventory, new ItemAndStack<>(buffer.method_10819()), buffer.readBoolean());
    }
}
