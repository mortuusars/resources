package io.github.mortuusars.exposure;

import io.github.mortuusars.exposure.item.CameraItem;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

public class CommonFunctionality {
    public static void handleItemDrop(@Nullable class_1657 player, @Nullable class_1542 droppedItemEntity) {
        if (player == null || droppedItemEntity == null)
            return;

        class_1799 stack = droppedItemEntity.method_6983();
        if (stack.method_7909() instanceof CameraItem cameraItem && cameraItem.isActive(stack))
            cameraItem.deactivate(player, stack);
    }
}
