package io.github.mortuusars.exposure.block;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.block.entity.FlashBlockEntity;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_5558;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("deprecation")
public class FlashBlock extends class_2248 implements class_2343, class_3737 {
    public static final class_2746 WATERLOGGED = class_2741.field_12508;
    public FlashBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664().method_11657(WATERLOGGED, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> pBuilder) {
        pBuilder.method_11667(WATERLOGGED);
    }

    @Override
    public boolean method_9579(@NotNull class_2680 blockState, @NotNull class_1922 level, @NotNull class_2338 pos) {
        return true;
    }

    @Override
    public @NotNull class_2464 method_9604(@NotNull class_2680 state) {
        return class_2464.field_11455;
    }

    @Override
    public @NotNull class_265 method_9530(@NotNull class_2680 pState, @NotNull class_1922 pLevel, @NotNull class_2338 pPos, class_3726 pContext) {
        return pContext.method_17785(class_1802.field_30904) ? class_259.method_1077() : class_259.method_1073();
    }

    @Override
    public float method_9575(@NotNull class_2680 state, @NotNull class_1922 level, @NotNull class_2338 pos) {
        return 1.0F;
    }

    @Override
    public @NotNull class_2680 method_9559(class_2680 pState, @NotNull class_2350 pDirection, @NotNull class_2680 pNeighborState, @NotNull class_1936 pLevel, @NotNull class_2338 pCurrentPos, @NotNull class_2338 pNeighborPos) {
        if (pState.method_11654(WATERLOGGED)) {
            pLevel.method_39281(pCurrentPos, class_3612.field_15910, class_3612.field_15910.method_15789(pLevel));
        }

        return super.method_9559(pState, pDirection, pNeighborState, pLevel, pCurrentPos, pNeighborPos);
    }

    public @NotNull class_3610 method_9545(class_2680 pState) {
        return pState.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(pState);
    }

    @Nullable
    @Override
    public class_2586 method_10123(@NotNull class_2338 pos, @NotNull class_2680 blockState) {
        return new FlashBlockEntity(pos, blockState);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, @NotNull class_2680 state, @NotNull class_2591<T> blockEntityType) {
        if (!level.field_9236 && blockEntityType == Exposure.BlockEntityTypes.FLASH.get())
            return FlashBlockEntity::serverTick;

        return null;
    }
}
