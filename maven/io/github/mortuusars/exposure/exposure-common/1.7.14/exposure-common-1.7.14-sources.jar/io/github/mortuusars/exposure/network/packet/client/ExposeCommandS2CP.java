package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public record ExposeCommandS2CP(int size) implements IPacket {
    public static final class_2960 ID = Exposure.resource("expose_command");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.writeInt(size);
        return buffer;
    }

    public static ExposeCommandS2CP fromBuffer(class_2540 buffer) {
        return new ExposeCommandS2CP(buffer.readInt());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        ClientPacketsHandler.exposeScreenshot(size);
        return true;
    }
}
