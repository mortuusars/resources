package io.github.mortuusars.exposure.network.packet.server;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public record CameraSetSelfieModeC2SP(boolean isInSelfieMode) implements IPacket {
    public static final class_2960 ID = Exposure.resource("camera_set_selfie_mode");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.writeBoolean(isInSelfieMode);
        return buffer;
    }

    public static CameraSetSelfieModeC2SP fromBuffer(class_2540 buffer) {
        return new CameraSetSelfieModeC2SP(buffer.readBoolean());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        Preconditions.checkState(player != null, "Cannot handle packet: Player was null");

        Camera.getCamera(player).ifPresent(camera -> {
            camera.get().getItem().setSelfieModeWithEffects(player, camera.get().getStack(), isInSelfieMode);
        });

        return true;
    }
}