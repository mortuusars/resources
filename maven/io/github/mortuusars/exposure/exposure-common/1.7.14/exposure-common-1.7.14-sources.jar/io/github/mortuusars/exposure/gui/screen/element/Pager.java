package io.github.mortuusars.exposure.gui.screen.element;

import io.github.mortuusars.exposure.util.PagingDirection;
import net.minecraft.class_1109;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4264;

@SuppressWarnings({"UnusedReturnValue", "BooleanMethodIsAlwaysInverted"})
public class Pager {
    public long lastChangedAt;
    public int changeCooldownMS = 50;
    public boolean playSound = true;
    public class_3414 changeSoundEvent;

    protected class_2960 texture;
    protected int pages;
    protected boolean cycled;
    protected int currentPage;
    protected class_4264 previousButton;
    protected class_4264 nextButton;

    public Pager(class_3414 changeSoundEvent) {
        this.changeSoundEvent = changeSoundEvent;
    }

    public void init(int pages, boolean cycled, class_4264 previousPageButton, class_4264 nextPageButton) {
        this.pages = pages;
        this.cycled = cycled;
        setPage(getCurrentPage());

        this.previousButton = previousPageButton;
        this.nextButton = nextPageButton;
        update();
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setPage(int value) {
        this.currentPage = class_3532.method_15340(value, 0, this.pages);
    }

    public void update() {
        previousButton.field_22764 = canChangePage(PagingDirection.PREVIOUS);
        nextButton.field_22764 = canChangePage(PagingDirection.NEXT);
    }

    public boolean handleKeyPressed(int keyCode, int scanCode, int modifiers) {
        if (class_310.method_1551().field_1690.field_1913.method_1417(keyCode, scanCode) || keyCode == class_3675.field_31983) {
            if (!isOnCooldown())
                changePage(PagingDirection.PREVIOUS);
            return true;
        }
        else if (class_310.method_1551().field_1690.field_1849.method_1417(keyCode, scanCode) || keyCode == class_3675.field_31984) {
            if (!isOnCooldown())
                changePage(PagingDirection.NEXT);
            return true;
        }
        else
            return false;
    }

    public boolean handleKeyReleased(int keyCode, int scanCode, int modifiers) {
        if (class_310.method_1551().field_1690.field_1849.method_1417(keyCode, scanCode) || keyCode == class_3675.field_31984
                || class_310.method_1551().field_1690.field_1913.method_1417(keyCode, scanCode) || keyCode == class_3675.field_31983) {
            lastChangedAt = 0;
            return true;
        }

        return false;
    }

    private boolean isOnCooldown() {
        return class_156.method_658() - lastChangedAt < changeCooldownMS;
    }

    public boolean canChangePage(PagingDirection direction) {
        int newIndex = getCurrentPage() + direction.getValue();
        return pages > 1 && (cycled || (0 <= newIndex && newIndex < pages));
    }

    public boolean changePage(PagingDirection direction) {
        if (!canChangePage(direction))
            return false;

        int oldPage = currentPage;
        int newPage = getCurrentPage() + direction.getValue();

        if (cycled && newPage >= pages)
            newPage = 0;
        else if (cycled && newPage < 0)
            newPage = pages - 1;

        if (oldPage == newPage)
            return false;

        setPage(newPage);
        onPageChanged(direction, oldPage, currentPage);
        return true;
    }

    public void onPageChanged(PagingDirection pagingDirection, int prevPage, int currentPage) {
        lastChangedAt = class_156.method_658();
        if (playSound)
            playChangeSound();
    }

    protected void playChangeSound() {
        class_310.method_1551().method_1483().method_4873(class_1109.method_4757(
                getChangeSound(), 0.8f, 1f));
    }

    protected class_3414 getChangeSound() {
        return changeSoundEvent;
    }
}
