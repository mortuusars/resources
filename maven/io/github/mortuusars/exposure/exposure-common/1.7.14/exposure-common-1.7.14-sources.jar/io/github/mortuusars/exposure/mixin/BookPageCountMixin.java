package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.item.AlbumItem;
import net.minecraft.class_1799;
import net.minecraft.class_1843;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1843.class)
public abstract class BookPageCountMixin {
    @Inject(method = "getPageCount", at = @At("HEAD"), cancellable = true)
    private static void getPageCount(class_1799 stack, CallbackInfoReturnable<Integer> cir) {
        if (stack.method_7909() instanceof AlbumItem albumItem) {
            cir.setReturnValue(albumItem.getPages(stack).size());
        }
    }
}
