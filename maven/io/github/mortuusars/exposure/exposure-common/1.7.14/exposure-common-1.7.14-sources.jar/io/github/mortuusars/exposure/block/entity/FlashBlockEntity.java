package io.github.mortuusars.exposure.block.entity;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.block.FlashBlock;
import java.util.Objects;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class FlashBlockEntity extends class_2586 {
    private int ticks;
    public FlashBlockEntity(class_2338 pos, class_2680 blockState) {
        super(Exposure.BlockEntityTypes.FLASH.get(), pos, blockState);
        ticks = 7;
    }

    @SuppressWarnings("unused")
    public static <T extends class_2586> void serverTick(class_1937 level, class_2338 blockPos, class_2680 blockState, T blockEntity) {
        if (blockEntity instanceof FlashBlockEntity flashBlockEntity)
            flashBlockEntity.tick();
    }

    protected void tick() {
        ticks--;
        if (ticks <= 0) {
            class_2680 blockState = Objects.requireNonNull(field_11863).method_8320(method_11016());
            field_11863.method_8652(method_11016(), blockState.method_11654(FlashBlock.WATERLOGGED) ? class_2246.field_10382.method_9564() : class_2246.field_10124.method_9564(), class_2248.field_31036);
        }
    }
}
