package io.github.mortuusars.exposure.render;

import io.github.mortuusars.exposure.ExposureClient;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;

public class PhotographInHandRenderer {
    public static void renderPhotograph(class_4587 poseStack, class_4597 bufferSource, int combinedLight, class_1799 stack) {
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
        poseStack.method_22905(0.38f, 0.38f, 0.38f);
        poseStack.method_22904(-0.5, -0.5, 0);
        float scale = 1f / ExposureClient.getExposureRenderer().getSize();
        poseStack.method_22905(scale, scale, -scale);

        PhotographRenderer.render(stack, true, false, poseStack, bufferSource,
                combinedLight, 255, 255, 255, 255);
    }
}
