package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.gui.screen.camera.ViewfinderControlsScreen;
import net.minecraft.class_304;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_304.class)
public abstract class KeyMappingMixin {
    @Shadow public boolean isDown;

    /**
     * Allows moving when ControlsScreen is open.
     * This should also handle {@link net.minecraft.class_4666} on fabric (forge has separate mixin for it).
     */
    @Inject(method = "isDown", at = @At(value = "HEAD"), cancellable = true)
    private void isDown(CallbackInfoReturnable<Boolean> cir) {
        if (class_310.method_1551().field_1755 instanceof ViewfinderControlsScreen)
            cir.setReturnValue(this.isDown);
    }
}
