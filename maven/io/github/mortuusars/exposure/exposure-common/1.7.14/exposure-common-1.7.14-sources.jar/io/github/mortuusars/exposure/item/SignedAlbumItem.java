package io.github.mortuusars.exposure.item;

import io.github.mortuusars.exposure.Config;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3544;

public class SignedAlbumItem extends AlbumItem {
    public SignedAlbumItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public boolean isEditable() {
        return false;
    }

    @Override
    public @NotNull class_2561 method_7864(class_1799 stack) {
        if (stack.method_7969() != null && !class_3544.method_15438(stack.method_7969().method_10558(TAG_TITLE))) {
            return class_2561.method_43470(stack.method_7969().method_10558(TAG_TITLE));
        }
        return super.method_7864(stack);
    }
    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 level, List<class_2561> tooltipComponents, class_1836 isAdvanced) {
        if (stack.method_7969() != null) {
            class_2487 compoundTag = stack.method_7969();
            String author = compoundTag.method_10558(TAG_AUTHOR);
            if (!class_3544.method_15438(author)) {
                tooltipComponents.add(class_2561.method_43469("gui.exposure.album.by_author", author).method_27692(class_124.field_1080));
            }
        }
        super.method_7851(stack, level, tooltipComponents, isAdvanced);
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return Config.Client.SIGNED_ALBUM_GLINT.get();
    }
}
