package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_918.class)
public abstract class ItemRendererMixin {
    @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true)
    class_1087 renderItem(class_1087 model, class_1799 itemStack, class_811 displayContext, boolean leftHand,
                          class_4587 poseStack, class_4597 buffer, int combinedLight, int combinedOverlay) {
        if (class_310.method_1551().field_1687 != null && itemStack.method_31574(Exposure.Items.CAMERA.get()) && displayContext == class_811.field_4317) {
            class_1087 guiModel = class_310.method_1551().method_1554()
                    .method_4742(new class_1091("exposure", "camera_gui", "inventory"));

            return guiModel.method_4710().method_3495(guiModel, itemStack, class_310.method_1551().field_1687, null, 0);
        }
        return model;
    }
}
