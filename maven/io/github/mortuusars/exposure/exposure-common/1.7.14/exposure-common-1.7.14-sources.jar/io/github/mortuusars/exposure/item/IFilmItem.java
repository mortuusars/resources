package io.github.mortuusars.exposure.item;

import io.github.mortuusars.exposure.ExposureConstants;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import net.minecraft.class_1799;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3532;

public interface IFilmItem {
    String FRAME_COUNT_TAG = "FrameCount";
    String FRAME_SIZE_TAG = "FrameSize";
    String FRAMES_TAG = "Frames";

    FilmType getType();

    default int getDefaultMaxFrameCount(class_1799 filmStack) {
        return 16;
    }

    default int getMaxFrameCount(class_1799 filmStack) {
        if (filmStack.method_7969() != null && filmStack.method_7969().method_10573(FRAME_COUNT_TAG, class_2520.field_33253))
            return filmStack.method_7969().method_10550(FRAME_COUNT_TAG);
        else
            return getDefaultMaxFrameCount(filmStack);
    }

    default int getDefaultFrameSize() {
        return ExposureConstants.DEFAULT_FRAME_SIZE;
    }

    default int getFrameSize(class_1799 filmStack) {
        if (filmStack.method_7969() != null && filmStack.method_7969().method_10573(FRAME_SIZE_TAG, class_2520.field_33253))
            return class_3532.method_15340(filmStack.method_7948().method_10550(FRAME_SIZE_TAG), 1, 2048);
        else
            return getDefaultFrameSize();
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    default boolean hasExposedFrame(class_1799 filmStack, int index) {
        if (index < 0 || filmStack.method_7969() == null || !filmStack.method_7969().method_10573(FRAMES_TAG, class_2520.field_33259))
            return false;

        class_2499 list = filmStack.method_7969().method_10554(FRAMES_TAG, class_2520.field_33260);
        return index < list.size();
    }

    default int getExposedFramesCount(class_1799 stack) {
        return stack.method_7969() != null && stack.method_7969().method_10573(FRAMES_TAG, class_2520.field_33259) ?
                stack.method_7969().method_10554(FRAMES_TAG, class_2520.field_33260).size() : 0;
    }

    default class_2499 getExposedFrames(class_1799 filmStack) {
        return filmStack.method_7969() != null ? filmStack.method_7969().method_10554(FRAMES_TAG, class_2520.field_33260) : new class_2499();
    }
}
