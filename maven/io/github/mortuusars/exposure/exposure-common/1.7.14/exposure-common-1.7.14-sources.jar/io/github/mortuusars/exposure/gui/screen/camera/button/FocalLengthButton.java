package io.github.mortuusars.exposure.gui.screen.camera.button;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.gui.screen.element.IElementWithTooltip;
import io.github.mortuusars.exposure.util.Fov;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import org.jetbrains.annotations.NotNull;

public class FocalLengthButton extends class_344 implements IElementWithTooltip {
    private final int secondaryFontColor;
    private final int mainFontColor;

    public FocalLengthButton(class_437 screen, int x, int y, int width, int height, int u, int v, class_2960 texture) {
        super(x, y, width, height, u, v, height, texture, 256, 256, button -> {}, class_2561.method_43473());
        secondaryFontColor = Config.Client.getSecondaryFontColor();
        mainFontColor = Config.Client.getMainFontColor();
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float pPartialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, pPartialTick);
    }

    public void renderToolTip(@NotNull class_332 guiGraphics, int mouseX, int mouseY) {
        guiGraphics.method_51438(class_310.method_1551().field_1772, class_2561.method_43471("gui.exposure.viewfinder.focal_length.tooltip"), mouseX, mouseY);
    }

    @Override
    public void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_48579(guiGraphics, mouseX, mouseY, partialTick);

        int focalLength = (int)Math.round(Fov.fovToFocalLength(Viewfinder.getCurrentFov()));

        class_327 font = class_310.method_1551().field_1772;
        class_5250 text = class_2561.method_43469("gui.exposure.viewfinder.focal_length", focalLength);
        int textWidth = font.method_27525(text);
        int xPos = 17 + (29 - textWidth) / 2;

        guiGraphics.method_51439(font, text, method_46426() + xPos, method_46427() + 8, secondaryFontColor, false);
        guiGraphics.method_51439(font, text, method_46426() + xPos, method_46427() + 7, mainFontColor, false);
    }
}
