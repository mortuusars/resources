package io.github.mortuusars.exposure.item;

import com.google.common.base.Preconditions;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.gui.ClientGUI;
import io.github.mortuusars.exposure.gui.component.PhotographTooltip;
import io.github.mortuusars.exposure.util.ItemAndStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3419;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import net.minecraft.class_5632;
import net.minecraft.class_5712;

public class StackedPhotographsItem extends class_1792 {
    public static final String PHOTOGRAPHS_TAG = "Photographs";

    public StackedPhotographsItem(class_1793 properties) {
        super(properties);
    }

    /**
     * @return How many photographs can be stacked together.
     */
    public int getStackLimit() {
        return Config.Common.STACKED_PHOTOGRAPHS_MAX_SIZE.get();
    }

    public int getPhotographsCount(class_1799 stack) {
        return getOrCreatePhotographsListTag(stack).size();
    }

    public List<ItemAndStack<PhotographItem>> getPhotographs(class_1799 stack) {
        return getPhotographs(stack, getStackLimit());
    }

    public List<ItemAndStack<PhotographItem>> getPhotographs(class_1799 stack, int limit) {
        class_2499 listTag = getOrCreatePhotographsListTag(stack);
        if (listTag.isEmpty())
            return Collections.emptyList();

        List<ItemAndStack<PhotographItem>> photographs = new ArrayList<>();
        for (int i = 0; i < Math.min(listTag.size(), limit); i++) {
            photographs.add(getPhotograph(listTag, i));
        }

        return photographs;
    }

    public boolean canAddPhotograph(class_1799 stack) {
        return getPhotographsCount(stack) < getStackLimit();
    }

    public void addPhotograph(class_1799 stack, class_1799 photographStack, int index) {
        Preconditions.checkState(index >= 0 && index <= getPhotographsCount(stack), index + " is out of bounds. Count: " + getPhotographsCount(stack));
        Preconditions.checkState(canAddPhotograph(stack), "Cannot add more photographs than this photo can store. Max count: " + getStackLimit());
        class_2499 listTag = getOrCreatePhotographsListTag(stack);
        listTag.method_10531(index, photographStack.method_7953(new class_2487()));
        stack.method_7948().method_10566(PHOTOGRAPHS_TAG, listTag);
    }

    public void addPhotographOnTop(class_1799 stack, class_1799 photographStack) {
        addPhotograph(stack, photographStack, 0);
    }

    public void addPhotographToBottom(class_1799 stack, class_1799 photographStack) {
        addPhotograph(stack, photographStack, getPhotographsCount(stack));
    }

    public ItemAndStack<PhotographItem> removePhotograph(class_1799 stack, int index) {
        Preconditions.checkState(index >= 0 && index < getPhotographsCount(stack), index + " is out of bounds. Count: " + getPhotographsCount(stack));

        class_2499 listTag = getOrCreatePhotographsListTag(stack);
        class_1799 photographStack = class_1799.method_7915((class_2487)listTag.method_10536(index));
        stack.method_7948().method_10566(PHOTOGRAPHS_TAG, listTag);

        return new ItemAndStack<>(photographStack);
    }

    public ItemAndStack<PhotographItem> removeTopPhotograph(class_1799 stack) {
        return removePhotograph(stack, 0);
    }

    public ItemAndStack<PhotographItem> removeBottomPhotograph(class_1799 stack) {
        return removePhotograph(stack, getPhotographsCount(stack) - 1);
    }

    private class_2499 getOrCreatePhotographsListTag(class_1799 stack) {
        return stack.method_7969() != null ? stack.method_7948().method_10554(PHOTOGRAPHS_TAG, class_2520.field_33260) : new class_2499();
    }

    private ItemAndStack<PhotographItem> getPhotograph(class_2499 photographsList, int index) {
        class_2487 stackTag = photographsList.method_10602(index);
        class_1799 stack = class_1799.method_7915(stackTag);
        return new ItemAndStack<>(stack);
    }

    public @Nullable Either<String, class_2960> getFirstIdOrTexture(class_1799 stack) {
        class_2499 listTag = getOrCreatePhotographsListTag(stack);
        if (listTag.isEmpty())
            return null;

        class_2487 first = listTag.method_10602(0).method_10562("tag");
        String id = first.method_10558(FrameData.ID);
        if (!id.isEmpty())
            return Either.left(id);

        String resource = first.method_10558(FrameData.TEXTURE);
        if (!resource.isEmpty())
            return Either.right(new class_2960(resource));

        return null;
    }

    public List<@Nullable Either<String, class_2960>> getTopPhotographs(class_1799 stack, int count) {
        Preconditions.checkArgument(count > 0, "count '{}' is not valid. > 0", count);

        List<@Nullable Either<String, class_2960>> photographs = new ArrayList<>();
        class_2499 listTag = getOrCreatePhotographsListTag(stack);

        for (int i = 0; i < Math.min(listTag.size(), count); i++) {
            class_2487 photographTag = listTag.method_10602(i).method_10562("tag");

            String id = photographTag.method_10558(FrameData.ID);
            if (!id.isEmpty()) {
                photographs.add(Either.left(id));
                continue;
            }

            String resource = photographTag.method_10558(FrameData.TEXTURE);
            if (!resource.isEmpty()) {
                photographs.add(Either.right(new class_2960(resource)));
                continue;
            }

            photographs.add(null);
        }

        while (photographs.size() < count) {
            photographs.add(null);
        }

        return photographs;
    }

    // ---

    @Override
    public @NotNull Optional<class_5632> method_32346(@NotNull class_1799 stack) {
        List<ItemAndStack<PhotographItem>> photographs = getPhotographs(stack);
        if (photographs.isEmpty())
            return Optional.empty();

        return Optional.of(new PhotographTooltip(new ItemAndStack<>(stack)));
    }

    @Override
    public boolean method_31565(@NotNull class_1799 stack, @NotNull class_1735 slot, @NotNull class_5536 action, @NotNull class_1657 player) {
        if (action != class_5536.field_27014 || getPhotographsCount(stack) == 0 || !slot.method_7680(new class_1799(Exposure.Items.PHOTOGRAPH.get())))
            return false;

        class_1799 slotItem = slot.method_7677();
        if (slotItem.method_7960()) {
            ItemAndStack<PhotographItem> photograph = removeBottomPhotograph(stack);
            slot.method_7673(photograph.getStack());

            if (getPhotographsCount(stack) == 1)
                player.field_7512.method_34254(removeTopPhotograph(stack).getStack());

            playRemoveSoundClientside(player);

            return true;
        }

        if (slotItem.method_7909() instanceof PhotographItem && canAddPhotograph(stack)) {
            addPhotographToBottom(stack, slotItem);
            slot.method_7673(class_1799.field_8037);

            playAddSoundClientside(player);

            return true;
        }

        return false;
    }

    @Override
    public boolean method_31566(@NotNull class_1799 stack, @NotNull class_1799 other, @NotNull class_1735 slot, @NotNull class_5536 action, @NotNull class_1657 player, @NotNull class_5630 access) {
        if (action != class_5536.field_27014 || !slot.method_7680(new class_1799(Exposure.Items.PHOTOGRAPH.get())))
            return false;

        if (getPhotographsCount(stack) > 0 && other.method_7960()) {
            ItemAndStack<PhotographItem> photograph = removeTopPhotograph(stack);
            access.method_32332(photograph.getStack());

            if (getPhotographsCount(stack) == 1) {
                ItemAndStack<PhotographItem> lastPhotograph = removeTopPhotograph(stack);
                slot.method_7673(lastPhotograph.getStack());
            }

            playRemoveSoundClientside(player);

            return true;
        }

        if (other.method_7909() instanceof PhotographItem) {
            if (canAddPhotograph(stack)) {
                addPhotographOnTop(stack, other);
                access.method_32332(class_1799.field_8037);

                playAddSoundClientside(player);

                return true;
            }
            else
                return false;
        }

        if (other.method_7909() instanceof StackedPhotographsItem otherStackedItem) {
            int otherCount = otherStackedItem.getPhotographsCount(other);
            int addedCount = 0;
            for (int i = 0; i < otherCount; i++) {
                if (canAddPhotograph(stack)) {
                    ItemAndStack<PhotographItem> photograph = otherStackedItem.removeBottomPhotograph(other);
                    addPhotographOnTop(stack, photograph.getStack());
                    addedCount++;
                }
            }

            if (otherStackedItem.getPhotographsCount(other) == 0)
                access.method_32332(class_1799.field_8037);
            else if (otherStackedItem.getPhotographsCount(other) == 1)
                access.method_32332(otherStackedItem.removeTopPhotograph(other).getStack());

            if (addedCount > 0)
                playAddSoundClientside(player);

            return true;
        }

        return false;
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(@NotNull class_1937 level, class_1657 player, @NotNull class_1268 hand) {
        class_1799 itemInHand = player.method_5998(hand);

        if (player.method_21823()) {
            cyclePhotographs(itemInHand, player);
            return class_1271.method_22427(itemInHand);
        }

        List<ItemAndStack<PhotographItem>> photographs = getPhotographs(itemInHand);
        if (!photographs.isEmpty()) {
            if (level.field_9236) {
                ClientGUI.openPhotographScreen(photographs);
                player.method_5783(Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), 0.6f, 1.1f);
            }
            return class_1271.method_22427(itemInHand);
        }

        return class_1271.method_22431(itemInHand);
    }

    public boolean cyclePhotographs(class_1799 stack, @Nullable class_1657 player) {
        if (getPhotographsCount(stack) < 2)
            return false;

        ItemAndStack<PhotographItem> topPhotograph = removeTopPhotograph(stack);
        addPhotographToBottom(stack, topPhotograph.getStack());
        if (player != null) {
            player.method_37908().method_43129(player, player, Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), class_3419.field_15248, 0.6f,
                player.method_37908().method_8409().method_43057() * 0.2f + 1.2f);
            player.method_32876(class_5712.field_28146);
        }

        return true;
    }

    public static void playAddSoundClientside(class_1657 player) {
        if (player.method_37908().field_9236)
            player.method_5783(Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), 0.6f,
                    player.method_37908().method_8409().method_43057() * 0.2f + 1.2f);
    }

    public static void playRemoveSoundClientside(class_1657 player) {
        if (player.method_37908().field_9236)
            player.method_5783(Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(), 0.75f,
                    player.method_37908().method_8409().method_43057() * 0.2f + 0.75f);
    }
}
