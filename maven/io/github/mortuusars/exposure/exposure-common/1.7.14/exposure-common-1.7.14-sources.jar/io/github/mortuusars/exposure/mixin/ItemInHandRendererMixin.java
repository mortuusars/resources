package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.render.PhotographInHandRenderer;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.item.StackedPhotographsItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_759.class)
public abstract class ItemInHandRendererMixin {
    @Shadow
    private class_1799 mainHandItem;
    @Shadow
    private class_1799 offHandItem;
    @Shadow
    protected abstract void renderPlayerArm(class_4587 pMatrixStack, class_4597 pBuffer, int pCombinedLight, float pEquippedProgress, float pSwingProgress, class_1306 pSide);
    @Shadow
    protected abstract float calculateMapTilt(float pPitch);
    @Shadow
    protected abstract void renderMapHand(class_4587 pMatrixStack, class_4597 pBuffer, int pCombinedLight, class_1306 pSide);

    @Inject(method = "renderArmWithItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;isEmpty()Z", ordinal = 0),
            locals = LocalCapture.CAPTURE_FAILHARD, cancellable = true)
    private void renderPhotograph(class_742 player, float partialTicks, float pitch, class_1268 hand,
                                  float swingProgress, class_1799 stack, float equipProgress, class_4587 poseStack,
                                  class_4597 buffer, int combinedLight, CallbackInfo ci, boolean isMainHand, class_1306 arm) {
        if (Viewfinder.isLookingThrough()) {
            poseStack.method_22909();
            ci.cancel();
            return;
        }

        if (stack.method_7909() instanceof PhotographItem || stack.method_7909() instanceof StackedPhotographsItem) {
            if (isMainHand && this.offHandItem.method_7960()) {
                exposure$renderTwoHandedPhotograph(player, poseStack, buffer, combinedLight, pitch, equipProgress, swingProgress);
            } else {
                exposure$renderOneHandedPhotograph(player, poseStack, buffer, combinedLight, equipProgress, arm, swingProgress, stack);
            }

            poseStack.method_22909();

            ci.cancel();
        }
    }

    @Unique
    private void exposure$renderOneHandedPhotograph(class_742 player, class_4587 poseStack, class_4597 buffer, int combinedLight, float pEquippedProgress, class_1306 pHand, float pSwingProgress, class_1799 stack) {
        float f = pHand == class_1306.field_6183 ? 1.0F : -1.0F;
        poseStack.method_22904(f * 0.125F, -0.125D, 0.0D);
        if (!player.method_5767()) {
            poseStack.method_22903();
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(f * 10.0F));
            this.renderPlayerArm(poseStack, buffer, combinedLight, pEquippedProgress, pSwingProgress, pHand);
            poseStack.method_22909();
        }

        poseStack.method_22903();
        poseStack.method_22904(f * 0.51F, -0.08F + pEquippedProgress * -1.2F, -0.75D);
        float f1 = class_3532.method_15355(pSwingProgress);
        float f2 = class_3532.method_15374(f1 * (float)Math.PI);
        float f3 = -0.5F * f2;
        float f4 = 0.4F * class_3532.method_15374(f1 * ((float)Math.PI * 2F));
        float f5 = -0.3F * class_3532.method_15374(pSwingProgress * (float)Math.PI);
        poseStack.method_46416(f * f3, f4 - 0.3F * f2, f5);
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(f2 * -45.0F));
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(f * f2 * -30.0F));
        PhotographInHandRenderer.renderPhotograph(poseStack, buffer, combinedLight, stack);
        poseStack.method_22909();
    }

    @Unique
    private void exposure$renderTwoHandedPhotograph(class_742 player, class_4587 pMatrixStack, class_4597 pBuffer, int pCombinedLight, float pPitch, float pEquippedProgress, float pSwingProgress) {
        float f = class_3532.method_15355(pSwingProgress);
        float f1 = -0.2F * class_3532.method_15374(pSwingProgress * (float)Math.PI);
        float f2 = -0.4F * class_3532.method_15374(f * (float)Math.PI);
        pMatrixStack.method_22904(0.0D, -f1 / 2.0F, f2);
        float f3 = this.calculateMapTilt(pPitch);
        pMatrixStack.method_22904(0.0D, 0.04F + pEquippedProgress * -1.2F + f3 * -0.5F, -0.72F);
        pMatrixStack.method_22907(class_7833.field_40714.rotationDegrees(f3 * -85.0F));
        if (!player.method_5767()) {
            pMatrixStack.method_22903();
            pMatrixStack.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
            this.renderMapHand(pMatrixStack, pBuffer, pCombinedLight, class_1306.field_6183);
            this.renderMapHand(pMatrixStack, pBuffer, pCombinedLight, class_1306.field_6182);
            pMatrixStack.method_22909();
        }

        float f4 = class_3532.method_15374(f * (float)Math.PI);
        pMatrixStack.method_22907(class_7833.field_40714.rotationDegrees(f4 * 20.0F));
        pMatrixStack.method_22905(2.0F, 2.0F, 2.0F);
        PhotographInHandRenderer.renderPhotograph(pMatrixStack, pBuffer, pCombinedLight, this.mainHandItem);
    }
}
