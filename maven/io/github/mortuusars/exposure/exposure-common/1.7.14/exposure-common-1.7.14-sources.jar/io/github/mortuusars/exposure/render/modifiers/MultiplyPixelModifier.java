package io.github.mortuusars.exposure.render.modifiers;

import net.minecraft.class_5253;

@SuppressWarnings({"ClassCanBeRecord", "unused"})
public class MultiplyPixelModifier implements IPixelModifier {
    public final int multiplyColor;

    public MultiplyPixelModifier(int multiplyColor) {
        this.multiplyColor = multiplyColor;
    }

    @Override
    public int modifyPixel(int ABGR) {
        if (multiplyColor == 0)
            return ABGR;

        int alpha = class_5253.class_8045.method_48342(ABGR);
        int blue = class_5253.class_8045.method_48347(ABGR);
        int green = class_5253.class_8045.method_48346(ABGR);
        int red = class_5253.class_8045.method_48345(ABGR);

        int tintAlpha = class_5253.class_5254.method_27762(ABGR);
        int tintBlue = class_5253.class_5254.method_27767(ABGR);
        int tintGreen = class_5253.class_5254.method_27766(ABGR);
        int tintRed = class_5253.class_5254.method_27765(ABGR);

        alpha = Math.min(255, (alpha * tintAlpha) / 255);
        blue = Math.min(255, (blue * tintBlue) / 255);
        green = Math.min(255, (green * tintGreen) / 255);
        red = Math.min(255, (red * tintRed) / 255);

        return class_5253.class_8045.method_48344(alpha, blue, green, red);
    }

    @Override
    public String getIdSuffix() {
        return multiplyColor != 0 ? "_tint" + Integer.toHexString(multiplyColor) : "";
    }
}
