package io.github.mortuusars.exposure.item;

import com.mojang.datafixers.util.Either;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class AlbumPage {
    public static final String PHOTOGRAPH_TAG = "Photo";
    public static final String NOTE_TAG = "Note";
    public static final String NOTE_COMPONENT_TAG = "NoteComponent";
    private class_1799 photographStack;
    private Either<String, class_2561> note;

    public AlbumPage(class_1799 photographStack, Either<String, class_2561> note) {
        this.photographStack = photographStack;
        this.note = note;
    }

    public static AlbumPage editable(class_1799 photographStack, String note) {
        return new AlbumPage(photographStack, Either.left(note));
    }

    public static AlbumPage signed(class_1799 photographStack, class_2561 note) {
        return new AlbumPage(photographStack, Either.right(note));
    }

    public boolean isEditable() {
        return note.left().isPresent();
    }

    public boolean isEmpty() {
        return photographStack.method_7960() && note.map(String::isEmpty, c -> c.getString().isEmpty());
    }

    public static AlbumPage fromTag(class_2487 tag, boolean editable) {
        class_1799 photographStack = tag.method_10573(PHOTOGRAPH_TAG, class_2520.field_33260)
                ? class_1799.method_7915(tag.method_10562(PHOTOGRAPH_TAG)) : class_1799.field_8037;

        if (editable) {
            String note;
            if (tag.method_10573(NOTE_TAG, class_2520.field_33258))
                note = tag.method_10558(NOTE_TAG);
            else if (tag.method_10545(NOTE_COMPONENT_TAG)) {
                @Nullable class_5250 component = class_2561.class_2562.method_10877(tag.method_10558(NOTE_COMPONENT_TAG));
                note = component != null ? component.method_10858(512) : "";
            } else
                note = "";

            return editable(photographStack, note);
        } else {
            class_2561 note;
            if (tag.method_10573(NOTE_COMPONENT_TAG, class_2520.field_33258))
                note = class_2561.class_2562.method_10877(tag.method_10558(NOTE_COMPONENT_TAG));
            else if (tag.method_10545(NOTE_TAG))
                note = class_2561.method_43470(tag.method_10558(NOTE_TAG));
            else
                note = class_2561.method_43473();

            return signed(photographStack, note);
        }
    }

    public class_2487 toTag(class_2487 tag) {
        if (!photographStack.method_7960())
            tag.method_10566(PHOTOGRAPH_TAG, photographStack.method_7953(new class_2487()));

        note.ifLeft(string -> { if (!string.isEmpty()) tag.method_10582(NOTE_TAG, string);})
            .ifRight(component -> tag.method_10582(NOTE_COMPONENT_TAG, class_2561.class_2562.method_10867(component)));

        return tag;
    }

    public class_1799 getPhotographStack() {
        return photographStack;
    }

    public class_1799 setPhotographStack(class_1799 photographStack) {
        class_1799 existingStack = this.photographStack;
        this.photographStack = photographStack;
        return existingStack;
    }

    public Either<String, class_2561> getNote() {
        return note;
    }

    public void setNote(Either<String, class_2561> note) {
        this.note = note;
    }

    public AlbumPage toSigned() {
        if (!isEditable())
            return this;

        class_5250 noteComponent = class_2561.method_43470(getNote().left().orElseThrow());
        return signed(getPhotographStack(), noteComponent);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (AlbumPage) obj;
        return Objects.equals(this.photographStack, that.photographStack) &&
                Objects.equals(this.note, that.note);
    }

    @Override
    public int hashCode() {
        return Objects.hash(photographStack, note);
    }

    @Override
    public String toString() {
        return "Page[" +
                "photo=" + photographStack + ", " +
                "note=" + note + ']';
    }
}
