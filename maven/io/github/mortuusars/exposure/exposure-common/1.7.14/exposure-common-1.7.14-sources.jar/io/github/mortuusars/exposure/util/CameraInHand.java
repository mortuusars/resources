package io.github.mortuusars.exposure.util;

import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.item.CameraItem;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

public class CameraInHand<T extends CameraItem> extends Camera<T> {
    private final class_1268 hand;
    private final ItemAndStack<T> cameraItemAndStack;

    public static <T extends CameraItem> @Nullable Camera<T> ofPlayer(class_1657 player, Class<T> clazz) {
        for (class_1268 hand : class_1268.values()) {
            class_1799 itemInHand = player.method_5998(hand);
            if (itemInHand.method_7909() instanceof CameraItem cameraItem && cameraItem.isActive(itemInHand)
                    && itemInHand.method_7909().getClass().equals(clazz)) {
                return new CameraInHand<>(hand, new ItemAndStack<>(itemInHand));
            }
        }
        return null;
    }

    public CameraInHand(class_1268 hand, @Nullable ItemAndStack<T> cameraItemAndStack) {
        this.hand = hand;
        this.cameraItemAndStack = cameraItemAndStack;
    }

    @Override
    public void activate(class_1657 player) {
        get().getItem().activate(player, get().getStack());
    }

    @Override
    public void deactivate(class_1657 player) {
        get().getItem().deactivate(player, get().getStack());
    }

    @Override
    public ItemAndStack<T> get() {
        return cameraItemAndStack;
    }

    public class_1268 getHand() {
        return hand;
    }
}
