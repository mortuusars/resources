package io.github.mortuusars.exposure.data;

import io.github.mortuusars.exposure.camera.infrastructure.FocalRange;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.IPacket;
import io.github.mortuusars.exposure.network.packet.client.SyncLensesS2CP;
import org.jetbrains.annotations.Nullable;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_3222;

public class Lenses {
    private static ConcurrentMap<class_1856, FocalRange> lenses = new ConcurrentHashMap<>();

    public static void reload(ConcurrentMap<class_1856, FocalRange> newLenses) {
        lenses.clear();
        lenses = newLenses;
    }

    public static Optional<FocalRange> getFocalRangeOf(class_1799 stack) {
        for (var lens : lenses.entrySet()) {
            if (lens.getKey().method_8093(stack))
                return Optional.of(lens.getValue());
        }

        return Optional.empty();
    }

    public static IPacket getSyncToClientPacket() {
        return new SyncLensesS2CP(new ConcurrentHashMap<>(lenses));
    }

    public static void onDatapackSync(@Nullable class_3222 joiningPlayer) {
        IPacket packet = getSyncToClientPacket();

        if (joiningPlayer != null)
            Packets.sendToClient(packet, joiningPlayer);
        else
            Packets.sendToAllClients(packet);
    }
}
