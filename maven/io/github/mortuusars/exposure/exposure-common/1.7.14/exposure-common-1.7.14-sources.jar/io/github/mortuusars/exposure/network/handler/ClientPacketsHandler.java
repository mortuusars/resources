package io.github.mortuusars.exposure.network.handler;

import com.google.common.base.Preconditions;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.capture.*;
import io.github.mortuusars.exposure.camera.capture.component.BaseComponent;
import io.github.mortuusars.exposure.camera.capture.component.ExposureStorageSaveComponent;
import io.github.mortuusars.exposure.camera.capture.component.ICaptureComponent;
import io.github.mortuusars.exposure.camera.capture.converter.DitheringColorConverter;
import io.github.mortuusars.exposure.camera.capture.converter.SimpleColorConverter;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.client.ComplicatedChromaticFinalizer;
import io.github.mortuusars.exposure.data.Lenses;
import io.github.mortuusars.exposure.data.ExposureSize;
import io.github.mortuusars.exposure.data.storage.ClientsideExposureExporter;
import io.github.mortuusars.exposure.gui.screen.NegativeExposureScreen;
import io.github.mortuusars.exposure.gui.screen.PhotographScreen;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.network.packet.client.*;
import io.github.mortuusars.exposure.render.modifiers.ExposurePixelModifiers;
import io.github.mortuusars.exposure.util.ClientsideWorldNameGetter;
import io.github.mortuusars.exposure.util.ItemAndStack;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3544;
import net.minecraft.class_437;
import net.minecraft.class_746;

public class ClientPacketsHandler {

    public static void applyShader(ApplyShaderS2CP packet) {
        executeOnMainThread(() -> {
            if (packet.shaderLocation().method_12832().equals("none")) {
                class_310.method_1551().field_1773.method_3207();
            } else {
                class_310.method_1551().field_1773.method_3168(packet.shaderLocation());
            }
        });
    }

    public static void exposeScreenshot(int size) {
        Preconditions.checkState(size > 0, size + " size is invalid. Should be larger than 0.");
        if (size == Integer.MAX_VALUE)
            size = Math.min(class_310.method_1551().method_22683().method_4489(), class_310.method_1551().method_22683()
                    .method_4506());

        int finalSize = size;
        executeOnMainThread(() -> {
            String filename = class_156.method_44893();
            class_2487 frameData = new class_2487();
            frameData.method_10582(FrameData.ID, filename);
            Capture capture = new ScreenshotCapture()
                    .setSize(finalSize)
                    .cropFactor(1f)
                    .setComponents(
                            new BaseComponent(true),
                            new ClientsideExposureExporter(filename)
                                    .organizeByWorld(Config.Client.EXPOSURE_SAVING_LEVEL_SUBFOLDER.get(),
                                            ClientsideWorldNameGetter::getWorldName)
                                    .withModifier(ExposurePixelModifiers.EMPTY)
                                    .withSize(ExposureSize.X1),
                            new ICaptureComponent() {
                                @Override
                                public void end(Capture capture) {
                                    Exposure.LOGGER.info("Saved exposure screenshot: {}", filename);
                                }
                            })
                    .setConverter(new DitheringColorConverter());
            CaptureManager.enqueue(capture);
        });
    }

    public static void loadExposure(String exposureId, String path, int size, boolean dither) {
        class_746 player = class_310.method_1551().field_1724;
        if (class_3544.method_15438(exposureId)) {
            if (player == null)
                throw new IllegalStateException("Cannot load exposure: path is null or empty and player is null.");
            exposureId = player.method_5477().getString() + player.method_37908().method_8510();
        }

        String finalExposureId = exposureId;
        new Thread(() -> {
            Capture capture = new FileCapture(path, error -> { if (player != null) player.method_7353(
                            error.getTechnicalTranslation().method_27692(class_124.field_1061), false); })
                    .setSize(size)
                    .cropFactor(1f)
                    .setComponents(new ExposureStorageSaveComponent(finalExposureId, true))
                    .setConverter(dither ? new DitheringColorConverter() : new SimpleColorConverter());
            CaptureManager.enqueue(capture);

            class_2487 frameData = new class_2487();
            frameData.method_10582(FrameData.ID, finalExposureId);

            CapturedFramesHistory.add(frameData);

            Exposure.LOGGER.info("Loaded exposure from file '{}' with Id: '{}'.", path, finalExposureId);
            Objects.requireNonNull(class_310.method_1551().field_1724).method_7353(
                    class_2561.method_43469("command.exposure.load_from_file.success", finalExposureId)
                            .method_27692(class_124.field_1060), false);
        }).start();
    }

    public static void startExposure(StartExposureS2CP packet) {
        class_310.method_1551().execute(() -> {
            @Nullable class_746 player = class_310.method_1551().field_1724;
            Preconditions.checkState(player != null, "Player cannot be null.");

            class_1799 itemInHand = player.method_5998(packet.activeHand());
            if (!(itemInHand.method_7909() instanceof CameraItem cameraItem) || !cameraItem.isActive(itemInHand))
                throw new IllegalStateException("Player should have active Camera in hand. " + itemInHand);

            cameraItem.exposeFrameClientside(player, packet.activeHand(), packet.exposureId(), packet.flashHasFired(), packet.lightLevel());
        });
    }

    public static void showExposure(ShowExposureS2CP packet) {
        executeOnMainThread(() -> {
            class_746 player = class_310.method_1551().field_1724;
            if (player == null) {
                Exposure.LOGGER.error("Cannot show exposures. Player is null.");
                return;
            }

            boolean negative = packet.negative();

            @Nullable class_437 screen;

            if (packet.latest()) {
                screen = createLatestScreen(player, negative);
            } else {
                if (negative) {
                    Either<String, class_2960> idOrTexture = packet.isTexture() ?
                            Either.right(new class_2960(packet.idOrPath())) : Either.left(packet.idOrPath());
                    screen = new NegativeExposureScreen(List.of(idOrTexture));
                } else {
                    class_1799 stack = new class_1799(Exposure.Items.PHOTOGRAPH.get());
                    class_2487 tag = new class_2487();
                    tag.method_10582(packet.isTexture() ? FrameData.TEXTURE : FrameData.ID, packet.idOrPath());
                    stack.method_7980(tag);

                    screen = new PhotographScreen(List.of(new ItemAndStack<>(stack)));
                }
            }

            if (screen != null)
                class_310.method_1551().method_1507(screen);
        });
    }

    private static @Nullable class_437 createLatestScreen(class_1657 player, boolean negative) {
        List<class_2487> latestFrames = CapturedFramesHistory.get()
                .stream()
                .filter(frame -> !frame.method_10558(FrameData.ID).isEmpty())
                .toList();

        if (latestFrames.isEmpty()) {
            player.method_7353(class_2561.method_43471("command.exposure.show.latest.error.no_exposures"), false);
            return null;
        }

        if (negative) {
            List<Either<String, class_2960>> exposures = new ArrayList<>();
            for (class_2487 frame : latestFrames) {
                String exposureId = frame.method_10558(FrameData.ID);
                exposures.add(Either.left(exposureId));
            }
            return new NegativeExposureScreen(exposures);
        } else {
            List<ItemAndStack<PhotographItem>> photographs = new ArrayList<>();

            for (class_2487 frame : latestFrames) {
                class_1799 stack = new class_1799(Exposure.Items.PHOTOGRAPH.get());
                stack.method_7980(frame);

                photographs.add(new ItemAndStack<>(stack));
            }

            return new PhotographScreen(photographs);
        }
    }

    public static void clearRenderingCache() {
        executeOnMainThread(() -> ExposureClient.getExposureRenderer().clearData());
    }

    public static void syncLenses(SyncLensesS2CP packet) {
        executeOnMainThread(() -> Lenses.reload(packet.lenses()));
    }

    public static void waitForExposureChange(WaitForExposureChangeS2CP packet) {
        executeOnMainThread(() -> ExposureClient.getExposureStorage().putOnWaitingList(packet.exposureId()));
    }

    public static void onExposureChanged(ExposureChangedS2CP packet) {
        executeOnMainThread(() -> {
            ExposureClient.getExposureStorage().remove(packet.exposureId());
            ExposureClient.getExposureRenderer().clearDataSingle(packet.exposureId(), true);
        });
    }

    public static void onFrameAdded(OnFrameAddedS2CP packet) {
        executeOnMainThread(() -> CapturedFramesHistory.add(packet.frame()));
    }

    public static void createChromaticExposure(CreateChromaticExposureS2CP packet) {
        executeOnMainThread(() -> ComplicatedChromaticFinalizer.finalizeChromatic(packet.red(), packet.green(), packet.blue(), packet.exposureId()));
    }

    private static void executeOnMainThread(Runnable runnable) {
        class_310.method_1551().execute(runnable);
    }
}
