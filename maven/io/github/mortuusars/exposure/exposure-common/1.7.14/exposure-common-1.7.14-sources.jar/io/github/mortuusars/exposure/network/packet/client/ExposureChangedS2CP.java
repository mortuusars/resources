package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public record ExposureChangedS2CP(String exposureId) implements IPacket {
    public static final class_2960 ID = Exposure.resource("exposure_changed");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10814(exposureId);
        return buffer;
    }

    public static ExposureChangedS2CP fromBuffer(class_2540 buffer) {
        return new ExposureChangedS2CP(buffer.method_19772());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        ClientPacketsHandler.onExposureChanged(this);
        return true;
    }
}
