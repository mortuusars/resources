package io.github.mortuusars.exposure.item;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.gui.ClientGUI;
import io.github.mortuusars.exposure.menu.ItemRenameMenu;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_5250;

public class FilmRollItem extends class_1792 implements IFilmItem {
    private final FilmType filmType;
    private final int barColor;

    public FilmRollItem(FilmType filmType, int barColor, class_1793 properties) {
        super(properties);
        this.filmType = filmType;
        this.barColor = barColor;
    }

    @Override
    public FilmType getType() {
        return filmType;
    }

    public boolean method_31567(@NotNull class_1799 stack) {
        return getExposedFramesCount(stack) > 0;
    }

    public int method_31569(@NotNull class_1799 stack) {
        return Math.min(1 + 12 * getExposedFramesCount(stack) / getMaxFrameCount(stack), 13);
    }

    public int method_31571(@NotNull class_1799 stack) {
        return barColor;
    }

    public void addFrame(class_1799 filmStack, class_2487 frame) {
        class_2487 tag = filmStack.method_7948();

        if (!tag.method_10573(FRAMES_TAG, class_2520.field_33259)) {
            tag.method_10566(FRAMES_TAG, new class_2499());
        }

        class_2499 listTag = tag.method_10554(FRAMES_TAG, class_2520.field_33260);

        if (listTag.size() >= getMaxFrameCount(filmStack))
            throw new IllegalStateException("Cannot add more frames than film could fit. Size: " + listTag.size());

        listTag.add(frame);
        tag.method_10566(FRAMES_TAG, listTag);
    }

    public boolean canAddFrame(class_1799 filmStack) {
        if (!filmStack.method_7985() || !filmStack.method_7948().method_10573(FRAMES_TAG, class_2520.field_33259))
            return true;

        return filmStack.method_7948().method_10554(FRAMES_TAG, class_2520.field_33260).size() < getMaxFrameCount(filmStack);
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @Nullable class_1937 level, @NotNull List<class_2561> tooltipComponents, @NotNull class_1836 isAdvanced) {
        int exposedFrames = getExposedFramesCount(stack);
        if (exposedFrames > 0) {
            int totalFrames = getMaxFrameCount(stack);
            tooltipComponents.add(class_2561.method_43469("item.exposure.film_roll.tooltip.frame_count", exposedFrames, totalFrames)
                    .method_27692(class_124.field_1080));
        }

        int frameSize = getFrameSize(stack);
        if (frameSize != getDefaultFrameSize()) {
            tooltipComponents.add(class_2561.method_43469("item.exposure.film_roll.tooltip.frame_size",
                    class_2561.method_43470(String.format("%.1f", frameSize / 10f)))
                            .method_27692(class_124.field_1080));
        }

        if (Config.Common.FILM_ROLL_RENAMING.get()) {
            tooltipComponents.add(class_2561.method_43471("item.exposure.film_roll.tooltip.renaming"));
        }

        // Create compat:
        int developingStep = stack.method_7969() != null ? stack.method_7969().method_10550("CurrentDevelopingStep") : 0;
        if (Config.Common.CREATE_SPOUT_DEVELOPING_ENABLED.get() && developingStep > 0) {
            List<? extends String> totalSteps = Config.Common.spoutDevelopingSequence(getType()).get();

            class_5250 stepsComponent = class_2561.method_43470("");

            for (int i = 0; i < developingStep; i++) {
                stepsComponent.method_10852(class_2561.method_43470("I").method_27692(class_124.field_1065));
            }

            for (int i = developingStep; i < totalSteps.size(); i++) {
                stepsComponent.method_10852(class_2561.method_43470("I").method_27692(class_124.field_1063));
            }

            tooltipComponents.add(class_2561.method_43469("item.exposure.film_roll.tooltip.developing_step", stepsComponent)
                    .method_27692(class_124.field_1065));
        }

        //noinspection ConstantValue
        if (exposedFrames > 0 && !PlatformHelper.isModLoaded("jei") && Config.Client.RECIPE_TOOLTIPS_WITHOUT_JEI.get()) {
            ClientGUI.addFilmRollDevelopingTooltip(stack, level, tooltipComponents, isAdvanced);
        }
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        if (!Config.Common.FILM_ROLL_RENAMING.get() || !(player instanceof class_3222 serverPlayer)) {
            return super.method_7836(level, player, usedHand);
        }

        int slot = getMatchingSlotInInventory(player.method_31548(), player.method_5998(usedHand));
        class_3908 menuProvider = new class_3908() {
            @Override
            public @NotNull class_2561 method_5476() {
                return class_2561.method_43471("gui.exposure.item_rename.title");
            }

            @Override
            public @NotNull class_1703 createMenu(int containerId, @NotNull class_1661 playerInventory, @NotNull class_1657 player) {
                return new ItemRenameMenu(containerId, playerInventory, slot);
            }
        };
        PlatformHelper.openMenu(serverPlayer, menuProvider, buffer -> buffer.writeInt(slot));
        return class_1271.method_22427(player.method_5998(usedHand));
    }

    protected int getMatchingSlotInInventory(class_1661 inventory, class_1799 stack) {
        for (int i = 0; i < inventory.method_5439(); i++) {
            if (inventory.method_5438(i).equals(stack)) {
                return i;
            }
        }
        return -1;
    }
}
