package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public record LoadExposureCommandS2CP(String id, String path, int size, boolean dither) implements IPacket {
    public static final class_2960 ID = Exposure.resource("load_exposure");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10814(id);
        buffer.method_10814(path);
        buffer.writeInt(size);
        buffer.writeBoolean(dither);
        return buffer;
    }

    public static LoadExposureCommandS2CP fromBuffer(class_2540 buffer) {
        return new LoadExposureCommandS2CP(buffer.method_19772(), buffer.method_19772(), buffer.readInt(), buffer.readBoolean());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        ClientPacketsHandler.loadExposure(id, path, size, dither);
        return true;
    }
}
