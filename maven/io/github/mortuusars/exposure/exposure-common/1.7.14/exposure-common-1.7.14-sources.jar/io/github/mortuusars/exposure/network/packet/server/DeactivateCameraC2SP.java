package io.github.mortuusars.exposure.network.packet.server;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public record DeactivateCameraC2SP() implements IPacket {
    public static final class_2960 ID = Exposure.resource("deactivate_cameras");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public static DeactivateCameraC2SP fromBuffer(class_2540 buffer) {
        return new DeactivateCameraC2SP();
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        if (player == null)
            throw new IllegalStateException("Cannot handle the packet: Player was null");

        Camera.getCamera(player).ifPresent(camera -> camera.deactivate(player));
        return true;
    }
}
