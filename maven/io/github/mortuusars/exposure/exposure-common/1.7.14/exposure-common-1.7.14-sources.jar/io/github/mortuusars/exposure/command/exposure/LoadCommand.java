package io.github.mortuusars.exposure.command.exposure;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.LoadExposureCommandS2CP;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_3222;

public class LoadCommand {
    public static LiteralArgumentBuilder<class_2168> get() {
        return class_2170.method_9247("load")
                .then(class_2170.method_9247("withDithering")
                        .then(class_2170.method_9244("size", IntegerArgumentType.integer(1, 2048))
                                .then(class_2170.method_9244("path", StringArgumentType.string())
                                        .then(class_2170.method_9244("id", StringArgumentType.string())
                                                .executes(context -> loadExposureFromFile(context.getSource(),
                                                        StringArgumentType.getString(context, "id"),
                                                        StringArgumentType.getString(context, "path"),
                                                        IntegerArgumentType.getInteger(context, "size"), true))))))
                .then(class_2170.method_9244("size", IntegerArgumentType.integer(1, 2048))
                        .then(class_2170.method_9244("path", StringArgumentType.string())
                                .then(class_2170.method_9244("id", StringArgumentType.string())
                                        .executes(context -> loadExposureFromFile(context.getSource(),
                                                StringArgumentType.getString(context, "id"),
                                                StringArgumentType.getString(context, "path"),
                                                IntegerArgumentType.getInteger(context, "size"), false)))));
    }

    private static int loadExposureFromFile(class_2168 stack, String id, String path, int size, boolean dither) throws CommandSyntaxException {
        class_3222 player = stack.method_9207();
        Packets.sendToClient(new LoadExposureCommandS2CP(id, path, size, dither), player);
        return 0;
    }
}
