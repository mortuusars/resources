package io.github.mortuusars.exposure.camera.capture;

import com.google.common.collect.ImmutableList;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2487;

@SuppressWarnings("unused")
public class CapturedFramesHistory {
    
    private static final ArrayList<class_2487> lastExposures = new ArrayList<>();
    private static int limit = 32;

    public static List<class_2487> get() {
        return ImmutableList.copyOf(lastExposures);
    }

    public static void add(class_2487 frame) {
        if (frame.method_10558(FrameData.ID).isEmpty())
            Exposure.LOGGER.warn("{} - frame might not be valid. No ID is present.", frame);

        lastExposures.add(0, frame);

        while (lastExposures.size() > limit) {
            lastExposures.remove(limit);
        }
    }

    public static int getLimit() {
        return limit;
    }

    public static void setLimit(int limit) {
        CapturedFramesHistory.limit = limit;
    }

    public static void clear() {
        lastExposures.clear();
    }
}
