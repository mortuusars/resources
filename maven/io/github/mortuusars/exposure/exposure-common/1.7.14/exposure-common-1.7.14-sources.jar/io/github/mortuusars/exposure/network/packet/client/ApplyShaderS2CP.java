package io.github.mortuusars.exposure.network.packet.client;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public record ApplyShaderS2CP(class_2960 shaderLocation) implements IPacket {
    public static final class_2960 ID = Exposure.resource("apply_shader");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10812(shaderLocation);
        return buffer;
    }

    public static ApplyShaderS2CP fromBuffer(class_2540 buffer) {
        return new ApplyShaderS2CP(buffer.method_10810());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        ClientPacketsHandler.applyShader(this);
        return true;
    }
}
