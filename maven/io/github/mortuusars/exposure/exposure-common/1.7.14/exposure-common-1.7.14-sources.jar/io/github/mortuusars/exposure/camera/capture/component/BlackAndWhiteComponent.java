package io.github.mortuusars.exposure.camera.capture.component;

import io.github.mortuusars.exposure.camera.capture.Capture;
import net.minecraft.class_3532;
import net.minecraft.class_5253;

public class BlackAndWhiteComponent implements ICaptureComponent {
    @Override
    public int modifyPixel(Capture capture, int colorABGR) {
        int alpha = class_5253.class_8045.method_48342(colorABGR);
        int blue = class_5253.class_8045.method_48347(colorABGR);
        int green = class_5253.class_8045.method_48346(colorABGR);
        int red = class_5253.class_8045.method_48345(colorABGR);

        // Weights adding up to more than 1 - to make the image slightly brighter
        int luma = class_3532.method_15340((int) (0.299 * red + 0.587 * green + 0.114 * blue), 0, 255);

        // Slightly increase the contrast
        int contrast = 145;
        luma = class_3532.method_15340((luma - 128) * contrast / 128 + 128, 0, 255);

        return class_5253.class_8045.method_48344(alpha, luma, luma, luma);
    }
}
