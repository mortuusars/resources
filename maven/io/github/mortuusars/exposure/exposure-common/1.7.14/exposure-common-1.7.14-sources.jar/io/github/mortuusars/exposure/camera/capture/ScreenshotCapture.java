package io.github.mortuusars.exposure.camera.capture;

import net.minecraft.class_1011;
import net.minecraft.class_310;
import net.minecraft.class_318;

public class ScreenshotCapture extends Capture {
    @Override
    public class_1011 captureImage() {
        return class_318.method_1663(class_310.method_1551().method_1522());
    }
}
