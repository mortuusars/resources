package io.github.mortuusars.exposure.camera.capture.component;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.camera.capture.Capture;
import net.minecraft.class_1011;
import net.minecraft.class_310;
import net.minecraft.class_5498;

public class BaseComponent implements ICaptureComponent {
    private final boolean hideGuiValue;
    private boolean storedGuiHidden;
    private class_5498 storedCameraType;

    public BaseComponent(boolean hideGuiOnCapture) {
        this.hideGuiValue = hideGuiOnCapture;
        storedGuiHidden = false;
        storedCameraType = class_5498.field_26664;
    }

    public BaseComponent() {
        this(true);
    }

    @Override
    public int getFramesDelay(Capture capture) {
        return 1 + Config.Client.CAPTURE_DELAY_FRAMES.get();
    }

    @Override
    public void onDelayFrame(Capture capture, int delayFramesLeft) {
        if (delayFramesLeft == Math.max(0, getFramesDelay(capture) - 1)) { // Right before capturing
            class_310 mc = class_310.method_1551();
            storedGuiHidden = mc.field_1690.field_1842;
            storedCameraType = mc.field_1690.method_31044();

            mc.field_1690.field_1842 = hideGuiValue;
            class_5498 cameraType = class_310.method_1551().field_1690.method_31044()
                    == class_5498.field_26666 ? class_5498.field_26666 : class_5498.field_26664;
            mc.field_1690.method_31043(cameraType);
        }
    }

    @Override
    public void imageTaken(Capture capture, class_1011 screenshot) {
        class_310 mc = class_310.method_1551();
        mc.field_1690.field_1842 = storedGuiHidden;
        mc.field_1690.method_31043(storedCameraType);
    }
}
