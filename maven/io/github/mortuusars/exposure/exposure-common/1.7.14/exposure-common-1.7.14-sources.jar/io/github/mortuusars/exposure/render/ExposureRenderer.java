package io.github.mortuusars.exposure.render;

import com.mojang.blaze3d.platform.TextureUtil;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.render.image.IImage;
import io.github.mortuusars.exposure.render.image.RenderedImageProvider;
import io.github.mortuusars.exposure.render.modifiers.IPixelModifier;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1043;
import net.minecraft.class_1079;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4668;
import net.minecraft.class_7764;
import net.minecraft.class_7771;

public class ExposureRenderer implements AutoCloseable {
    private final Map<String, ExposureInstance> cache = new HashMap<>();

    public int getSize() {
        return 256;
    }

    public void render(@NotNull RenderedImageProvider imageProvider, IPixelModifier modifier,
                       class_4587 poseStack, class_4597 bufferSource,
                       int packedLight, int r, int g, int b, int a) {
        render(imageProvider, modifier, poseStack, bufferSource, 0, 0, getSize(), getSize(), packedLight, r, g, b, a);
    }

    public void render(@NotNull RenderedImageProvider imageProvider, IPixelModifier modifier,
                       class_4587 poseStack, class_4597 bufferSource, float x, float y, float width, float height,
                       int packedLight, int r, int g, int b, int a) {
        render(imageProvider, modifier, poseStack, bufferSource, x, y, x + width, y + height,
                0, 0, 1, 1, packedLight, r, g, b, a);
    }

    public void render(@NotNull RenderedImageProvider imageProvider, IPixelModifier modifier,
                       class_4587 poseStack, class_4597 bufferSource, float minX, float minY, float maxX, float maxY,
                       float minU, float minV, float maxU, float maxV, int packedLight, int r, int g, int b, int a) {
            getOrCreateExposureInstance(imageProvider, modifier)
                    .draw(poseStack, bufferSource, minX, minY, maxX, maxY, minU, minV, maxU, maxV, packedLight, r, g, b, a);
    }

    private ExposureInstance getOrCreateExposureInstance(RenderedImageProvider imageProvider, IPixelModifier modifier) {
        String instanceId = imageProvider.getInstanceId() + modifier.getIdSuffix();
        return (this.cache).compute(instanceId, (expId, expData) -> {
            if (expData == null) {
                return new ExposureInstance(expId, imageProvider.get(), modifier);
            } else {
                expData.replaceData(imageProvider.get());
                return expData;
            }
        });
    }

    public void clearData() {
        for (ExposureInstance instance : cache.values()) {
            instance.close();
        }

        cache.clear();
    }

    public void clearDataSingle(@NotNull String exposureId, boolean allVariants) {
        // Using cache.entrySet().removeIf(...) would be simpler, but it wouldn't let us .close() the instance
        for(Iterator<Map.Entry<String, ExposureInstance>> it = cache.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<String, ExposureInstance> entry = it.next();
            if(allVariants ? entry.getKey().startsWith(exposureId) : entry.getKey().equals(exposureId)) {
                entry.getValue().close();
                it.remove();

                if (!allVariants)
                    break;
            }
        }
    }

    @Override
    public void close() {
        clearData();
    }

    /**
     * Credits to <a href="https://github.com/Jalvaviel/MapMipMapMod">MapMipMapMod by Jalvaviel</a> for example of mipmap implementation for dynamic images.
     * And to <a href="https://github.com/bravely-beep">bravely-beep</a> for pointing me to it.
     */
    static class ExposureInstance implements AutoCloseable {
        private static final Function<class_2960, class_1921> TEXT_MIPMAP = class_156.method_34866(texture -> class_1921.method_24049("exposure_mipmap",
                class_290.field_20888,
                class_293.class_5596.field_27382,
                786432,
                false,
                true,
                class_1921.class_4688.method_23598()
                        .method_34578(class_1921.field_29427)
                        .method_34577(new class_4668.class_4683(texture, false, true))
                        .method_23615(class_1921.field_21370)
                        .method_23608(class_1921.field_21383)
                        .method_23617(false)));

        protected final class_2960 textureLocation;
        protected final class_1921 renderType;

        private IImage exposure;
        private class_1043 texture;
        private final IPixelModifier pixelModifier;
        private boolean requiresUpload = true;

        ExposureInstance(String id, IImage exposure, IPixelModifier modifier) {
            this.exposure = exposure;
            this.texture = new class_1043(exposure.getWidth(), exposure.getHeight(), true);
            this.pixelModifier = modifier;
            String textureId = createTextureId(id);
            this.textureLocation = class_310.method_1551().method_1531().method_4617(textureId, this.texture);
            int mipmapLevel = class_310.method_1551().field_1690.method_42563().method_41753();
            this.renderType = mipmapLevel > 0 ? TEXT_MIPMAP.apply(textureLocation) : class_1921.method_23028(textureLocation);
        }

        private static String createTextureId(String exposureId) {
            String id = "exposure/" + exposureId.toLowerCase();
            id = id.replace(':', '_');

            // Player nicknames can have non az09 chars
            // we need to remove all invalid chars from the id to create ResourceLocation,
            // otherwise it crashes
            Pattern pattern = Pattern.compile("[^a-z0-9_.-]");
            Matcher matcher = pattern.matcher(id);

            StringBuilder sb = new StringBuilder();
            while (matcher.find()) {
                matcher.appendReplacement(sb, String.valueOf(matcher.group().hashCode()));
            }
            matcher.appendTail(sb);

            return sb.toString();
        }

        private void replaceData(IImage exposure) {
            boolean hasChanged = !this.exposure.getImageId().equals(exposure.getImageId());
            this.exposure = exposure;
            if (hasChanged) {
                this.texture = new class_1043(exposure.getWidth(), exposure.getHeight(), true);
            }
            this.requiresUpload |= hasChanged;
        }

        @SuppressWarnings("unused")
        public void forceUpload() {
            this.requiresUpload = true;
        }

        private void updateTexture() {
            if (texture.method_4525() == null)
                return;

            int width = this.exposure.getWidth();
            int height = this.exposure.getHeight();

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int ABGR = this.exposure.getPixelABGR(x, y);
                    ABGR = pixelModifier.modifyPixel(ABGR);
                    this.texture.method_4525().method_4305(x, y, ABGR); // Texture is in BGR format
                }
            }

            int mipmapLevel = class_310.method_1551().field_1690.method_42563().method_41753();
            if (mipmapLevel > 0 && width > 2 && height > 2) {
                applyMipMap(mipmapLevel, width, height);
            }

            this.texture.method_4524();
        }

        private void applyMipMap(int mipmapLevel, int width, int height) {
            if (texture.method_4525() == null) return;

            try {
                texture.method_4527(false, true);
                TextureUtil.prepareImage(texture.method_4624(), mipmapLevel, width, height);
                class_7764 spriteContents = new class_7764(this.textureLocation,
                        new class_7771(width, height), texture.method_4525(), class_1079.field_21768);

                spriteContents.method_45808(mipmapLevel);
                spriteContents.method_45809(0, 0);
            } catch (Exception e) {
                Exposure.LOGGER.error("Failed to generate mipmaps: {}", e.getMessage());
            }
        }

        void draw(class_4587 poseStack, class_4597 bufferSource, float minX, float minY, float maxX, float maxY,
                  float minU, float minV, float maxU, float maxV, int packedLight, int r, int g, int b, int a) {
            if (this.requiresUpload) {
                this.updateTexture();
                this.requiresUpload = false;
            }

            Matrix4f matrix4f = poseStack.method_23760().method_23761();
            class_4588 vertexconsumer = bufferSource.getBuffer(this.renderType);
            vertexconsumer.method_22918(matrix4f, minX, maxY, 0).method_1336(r, g, b, a).method_22913(minU, maxV).method_22916(packedLight).method_1344();
            vertexconsumer.method_22918(matrix4f, maxX, maxY, 0).method_1336(r, g, b, a).method_22913(maxU, maxV).method_22916(packedLight).method_1344();
            vertexconsumer.method_22918(matrix4f, maxX, minY, 0).method_1336(r, g, b, a).method_22913(maxU, minV).method_22916(packedLight).method_1344();
            vertexconsumer.method_22918(matrix4f, minX, minY, 0).method_1336(r, g, b, a).method_22913(minU, minV).method_22916(packedLight).method_1344();
        }

        public void close() {
            this.texture.close();
        }
    }
}
