package io.github.mortuusars.exposure.network.packet;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.PacketDirection;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public record ExposureDataPartPacket(String id, int width, int height, class_2487 properties, int offset, byte[] partBytes) implements IPacket {
    public static final class_2960 ID = Exposure.resource("exposure_data_part");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10814(id);
        buffer.writeInt(width);
        buffer.writeInt(height);
        buffer.method_10794(properties);
        buffer.writeInt(offset);
        buffer.method_10813(partBytes);
        return buffer;
    }

    public static ExposureDataPartPacket fromBuffer(class_2540 buffer) {
        return new ExposureDataPartPacket(buffer.method_19772(), buffer.readInt(), buffer.readInt(),
                buffer.method_30617(), buffer.readInt(), buffer.method_10795());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        direction.getExposureReceiver().receivePart(id, width, height, properties, offset, partBytes);
        return true;
    }
}
