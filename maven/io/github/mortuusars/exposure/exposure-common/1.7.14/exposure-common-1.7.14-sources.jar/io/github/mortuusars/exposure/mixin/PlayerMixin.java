package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.CommonFunctionality;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class PlayerMixin extends class_1309 {
    protected PlayerMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "drop(Lnet/minecraft/world/item/ItemStack;ZZ)Lnet/minecraft/world/entity/item/ItemEntity;", at = @At(value = "RETURN"))
    void onDrop(class_1799 droppedItem, boolean dropAround, boolean includeThrowerName, CallbackInfoReturnable<class_1542> cir) {
        CommonFunctionality.handleItemDrop((class_1657)(Object)this, cir.getReturnValue());
    }
}
