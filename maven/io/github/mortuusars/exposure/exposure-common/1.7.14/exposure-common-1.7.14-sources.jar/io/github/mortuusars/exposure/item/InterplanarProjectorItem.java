package io.github.mortuusars.exposure.item;

import io.github.mortuusars.exposure.Exposure;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_5536;
import net.minecraft.class_5630;

public class InterplanarProjectorItem extends class_1792 {
    public InterplanarProjectorItem(class_1793 properties) {
        super(properties);
    }

    public boolean isDithered(class_1799 stack) {
        return stack.method_7969() == null || !stack.method_7969().method_10577("Clean");
    }

    public void setDithered(class_1799 stack, boolean dithered) {
        stack.method_7948().method_10556("Clean", !dithered);
    }

    public boolean isConsumable(class_1799 stack) {
        return true;
    }

    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 level, List<class_2561> components, class_1836 isAdvanced) {
        super.method_7851(stack, level, components, isAdvanced);

        if (isDithered(stack)){
            components.add(class_2561.method_43471("item.exposure.interplanar_projector.mode.dithered"));
        }
        else {
            components.add(class_2561.method_43471("item.exposure.interplanar_projector.mode.clear"));
        }

        if (class_437.method_25442()) {
            if (isConsumable(stack)) {
                components.add(class_2561.method_43471("item.exposure.interplanar_projector.tooltip.consumed_info"));
            }
            components.add(class_2561.method_43471("item.exposure.interplanar_projector.tooltip.info"));
            components.add(class_2561.method_43471("item.exposure.interplanar_projector.tooltip.switch_info"));
        }
        else {
            components.add(class_2561.method_43471("tooltip.exposure.hold_for_details"));
        }
    }

    @Override
    public boolean method_31566(class_1799 stack, class_1799 other, class_1735 slot, class_5536 action, class_1657 player, class_5630 access) {
        if (other.method_7960() && action == class_5536.field_27014) {
            setDithered(stack, !isDithered(stack));
            slot.method_7668();
            if (player.method_37908().field_9236) {
                player.method_5783(Exposure.SoundEvents.CAMERA_GENERIC_CLICK.get(), 0.6f, 1f);
            }
            return true;
        }

        return super.method_31566(stack, other, slot, action, player, access);
    }

    public Optional<String> getFilename(class_1799 stack) {
        return stack.method_7938() ? Optional.of(stack.method_7964().getString()) : Optional.empty();
    }
}
