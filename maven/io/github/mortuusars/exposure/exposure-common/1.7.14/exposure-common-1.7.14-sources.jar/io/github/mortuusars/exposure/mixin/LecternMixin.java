package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.item.AlbumItem;
import io.github.mortuusars.exposure.menu.LecternAlbumMenu;
import io.github.mortuusars.exposure.util.ItemAndStack;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.class_3715;
import net.minecraft.class_3722;
import net.minecraft.class_3908;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3715.class)
public abstract class LecternMixin {
    @Inject(method = "openScreen", at = @At(value = "HEAD"), cancellable = true)
    private void openScreen(class_1937 level, class_2338 pos, class_1657 player, CallbackInfo ci) {
        if (level.method_8321(pos) instanceof class_3722 lecternBlockEntity
                && player instanceof class_3222 serverPlayer
                && lecternBlockEntity.method_17520().method_7909() instanceof AlbumItem) {
            exposure$open(serverPlayer, lecternBlockEntity, lecternBlockEntity.method_17520());
            player.method_7281(class_3468.field_17485);
            ci.cancel();
        }
    }

    @Unique
    private void exposure$open(class_3222 player, class_3722 lecternBlockEntity, class_1799 albumStack) {
        class_3908 menuProvider = new class_3908() {
            @Override
            public @NotNull class_2561 method_5476() {
                return albumStack.method_7964();
            }

            @Override
            public @NotNull class_1703 createMenu(int containerId, @NotNull class_1661 playerInventory, @NotNull class_1657 player) {
                LecternBlockEntityAccessor accessor = (LecternBlockEntityAccessor) lecternBlockEntity;
                return new LecternAlbumMenu(containerId, lecternBlockEntity.method_11016(), playerInventory,
                        new ItemAndStack<>(albumStack), accessor.getBookAccess(), accessor.getDataAccess());
            }
        };

        PlatformHelper.openMenu(player, menuProvider, buffer -> {
            buffer.method_10807(lecternBlockEntity.method_11016());
            buffer.method_10793(albumStack);
        });
    }
}
