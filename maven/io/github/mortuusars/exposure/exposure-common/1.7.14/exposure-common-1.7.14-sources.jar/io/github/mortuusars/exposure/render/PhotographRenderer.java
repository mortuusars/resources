package io.github.mortuusars.exposure.render;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.item.StackedPhotographsItem;
import io.github.mortuusars.exposure.render.image.RenderedImageProvider;
import io.github.mortuusars.exposure.util.ItemAndStack;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_757;
import net.minecraft.class_7833;

public class PhotographRenderer {
    public static void render(class_1799 stack, boolean renderPaper, boolean renderBackside, class_4587 poseStack,
                              class_4597 bufferSource, int packedLight, int r, int g, int b, int a) {
        if (stack.method_7909() instanceof PhotographItem photographItem)
            renderPhotograph(photographItem, stack, renderPaper, renderBackside, poseStack, bufferSource, packedLight, r, g, b, a);
        else if (stack.method_7909() instanceof StackedPhotographsItem stackedPhotographsItem)
            renderStackedPhotographs(stackedPhotographsItem, stack, poseStack, bufferSource, packedLight, r, g, b, a);
    }

    public static void renderPhotograph(PhotographItem photographItem, class_1799 stack, boolean renderPaper,
                                        boolean renderBackside, class_4587 poseStack, class_4597 bufferSource,
                                        int packedLight, int r, int g, int b, int a) {
        PhotographRenderProperties properties = PhotographRenderProperties.get(stack);
        int size = ExposureClient.getExposureRenderer().getSize();
        float rotateOffset = size / 2f;

        @Nullable class_2487 frame = stack.method_7969();
        RenderedImageProvider imageProvider = frame != null ? RenderedImageProvider.fromFrame(frame) : RenderedImageProvider.EMPTY;

        int rotation = imageProvider.getInstanceId().hashCode() % 4;

        if (renderPaper) {
            poseStack.method_22903();
            poseStack.method_46416(rotateOffset, rotateOffset, 0);
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(rotation * 90));
            poseStack.method_46416(-rotateOffset, -rotateOffset, 0);

            renderTexture(properties.getPaperTexture(), poseStack, bufferSource, 0, 0,
                    size, size, packedLight, r, g, b, a);

            poseStack.method_22909();

            if (renderBackside) {
                poseStack.method_22903();
                poseStack.method_22907(class_7833.field_40716.rotationDegrees(180));
                poseStack.method_22904(-size, 0, -0.5);

                poseStack.method_46416(rotateOffset, rotateOffset, 0);
                poseStack.method_22907(class_7833.field_40718.rotationDegrees(rotation * 90));
                poseStack.method_46416(-rotateOffset, -rotateOffset, 0);

                renderTexture(properties.getPaperTexture(), poseStack, bufferSource,
                        packedLight, (int) (r * 0.85f), (int) (g * 0.85f), (int) (b * 0.85f), a);

                poseStack.method_22909();
            }
        }

        if (renderPaper) {
            poseStack.method_22903();
            float offset = size * 0.0625f;
            poseStack.method_46416(offset, offset, 1);
            poseStack.method_22905(0.875f, 0.875f, 0.875f);
            ExposureClient.getExposureRenderer().render(imageProvider, properties.getModifier(), poseStack, bufferSource,
                    packedLight, r, g, b, a);
            poseStack.method_22909();
        } else {
            ExposureClient.getExposureRenderer().render(imageProvider, properties.getModifier(), poseStack, bufferSource,
                    packedLight, r, g, b, a);
        }

        if (renderPaper && properties.hasPaperOverlayTexture()) {
            poseStack.method_22903();

            poseStack.method_46416(rotateOffset, rotateOffset, 0);
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(rotation * 90));
            poseStack.method_46416(-rotateOffset, -rotateOffset, 0);

            poseStack.method_46416(0, 0, 2);
            renderTexture(properties.getPaperOverlayTexture(), poseStack, bufferSource, packedLight, r, g, b, a);
            poseStack.method_22909();
        }
    }

    public static void renderStackedPhotographs(StackedPhotographsItem stackedPhotographsItem, class_1799 stack,
                                                class_4587 poseStack, class_4597 bufferSource,
                                                int packedLight, int r, int g, int b, int a) {
        List<ItemAndStack<PhotographItem>> photographs = stackedPhotographsItem.getPhotographs(stack, 3);
        renderStackedPhotographs(photographs, poseStack, bufferSource, packedLight, r, g, b, a);
    }

    public static void renderStackedPhotographs(List<ItemAndStack<PhotographItem>> photographs,
                                                class_4587 poseStack, class_4597 bufferSource,
                                                int packedLight, int r, int g, int b, int a) {
        if (photographs.isEmpty())
            return;

        for (int i = 2; i >= 0; i--) {
            if (photographs.size() - 1 < i)
                continue;

            ItemAndStack<PhotographItem> photograph = photographs.get(i);
            PhotographRenderProperties properties = PhotographRenderProperties.get(photograph.getStack());

            // Top photograph:
            if (i == 0) {
                poseStack.method_22903();
                poseStack.method_46416(0, 0, 2);
                renderPhotograph(photograph.getItem(), photograph.getStack(), true, false, poseStack,
                        bufferSource, packedLight, r, g, b, a);
                poseStack.method_22909();
                break;
            }

            @Nullable class_2487 frame = photograph.getStack().method_7969();
            RenderedImageProvider imageProvider = frame != null ? RenderedImageProvider.fromFrame(frame) : RenderedImageProvider.EMPTY;

            int rotation = imageProvider.getInstanceId().hashCode() % 4;

            // Photographs below (only paper)
            float posOffset = getStackedPhotographOffset() * i;
            float rotateOffset = ExposureClient.getExposureRenderer().getSize() / 2f;

            poseStack.method_22903();
            poseStack.method_46416(posOffset, posOffset, 2 - i);

            poseStack.method_46416(rotateOffset, rotateOffset, 0);
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(rotation * 90));
            poseStack.method_46416(-rotateOffset, -rotateOffset, 0);

            float brightnessMul = 1f - (getStackedBrightnessStep() * i);

            renderTexture(properties.getPaperTexture(), poseStack, bufferSource,
                    packedLight, (int)(r * brightnessMul), (int)(g * brightnessMul), (int)(b * brightnessMul), a);

            poseStack.method_22909();
        }
    }

    public static float getStackedBrightnessStep() {
        return 0.15f;
    }

    public static float getStackedPhotographOffset() {
        // 2 px / Texture size (64px) = 0.03125
        return ExposureClient.getExposureRenderer().getSize() * 0.03125f;
    }

    private static void renderTexture(class_2960 resource, class_4587 poseStack, class_4597 bufferSource,
                                      int packedLight, int r, int g, int b, int a) {
        renderTexture(resource, poseStack, bufferSource, 0, 0, ExposureClient.getExposureRenderer().getSize(),
                ExposureClient.getExposureRenderer().getSize(), packedLight, r, g, b, a);
    }

    private static void renderTexture(class_2960 resource, class_4587 poseStack, class_4597 bufferSource,
                                      float x, float y, float width, float height, int packedLight, int r, int g, int b, int a) {
        renderTexture(resource, poseStack, bufferSource, x, y, x + width, y + height,
                0, 0, 1, 1, packedLight, r, g, b, a);
    }

    private static void renderTexture(class_2960 resource, class_4587 poseStack, class_4597 bufferSource,
                                      float minX, float minY, float maxX, float maxY,
                                      float minU, float minV, float maxU, float maxV, int packedLight, int r, int g, int b, int a) {
        RenderSystem.setShaderTexture(0, resource);
        RenderSystem.setShader(class_757::method_34548);
        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();

        Matrix4f matrix = poseStack.method_23760().method_23761();
        class_4588 bufferBuilder = bufferSource.getBuffer(class_1921.method_23028(resource));
        bufferBuilder.method_22918(matrix, minX, maxY, 0).method_1336(r, g, b, a).method_22913(minU, maxV).method_22916(packedLight).method_1344();
        bufferBuilder.method_22918(matrix, maxX, maxY, 0).method_1336(r, g, b, a).method_22913(maxU, maxV).method_22916(packedLight).method_1344();
        bufferBuilder.method_22918(matrix, maxX, minY, 0).method_1336(r, g, b, a).method_22913(maxU, minV).method_22916(packedLight).method_1344();
        bufferBuilder.method_22918(matrix, minX, minY, 0).method_1336(r, g, b, a).method_22913(minU, minV).method_22916(packedLight).method_1344();
    }
}