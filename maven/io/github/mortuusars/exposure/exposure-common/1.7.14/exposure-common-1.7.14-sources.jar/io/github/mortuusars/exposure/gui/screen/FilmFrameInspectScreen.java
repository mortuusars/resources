package io.github.mortuusars.exposure.gui.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.block.entity.Lightroom;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.item.DevelopedFilmItem;
import io.github.mortuusars.exposure.menu.LightroomMenu;
import io.github.mortuusars.exposure.util.GuiUtil;
import io.github.mortuusars.exposure.util.PagingDirection;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class FilmFrameInspectScreen extends ZoomableScreen {
    public static final class_2960 TEXTURE = Exposure.resource("textures/gui/film_frame_inspect.png");
    public static final class_2960 WIDGETS_TEXTURE = Exposure.resource("textures/gui/widgets.png");
    public static final int BG_SIZE = 78;
    public static final int FRAME_SIZE = 54;
    public static final int BUTTON_SIZE = 16;

    private final LightroomScreen lightroomScreen;
    private final LightroomMenu lightroomMenu;

    private class_344 previousButton;
    private class_344 nextButton;

    public FilmFrameInspectScreen(LightroomScreen lightroomScreen, LightroomMenu lightroomMenu) {
        super(class_2561.method_43473());
        this.lightroomScreen = lightroomScreen;
        this.lightroomMenu = lightroomMenu;
        zoom.minZoom = zoom.defaultZoom / (float) Math.pow(zoom.step, 2f);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private LightroomMenu getLightroomMenu() {
        return lightroomMenu;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        zoomFactor = (float) field_22790 / BG_SIZE;

        previousButton = new class_344(0, (int) (field_22790 / 2f - BUTTON_SIZE / 2f), BUTTON_SIZE, BUTTON_SIZE,
                0, 0, BUTTON_SIZE, WIDGETS_TEXTURE, this::buttonPressed);
        nextButton = new class_344(field_22789 - BUTTON_SIZE, (int) (field_22790 / 2f - BUTTON_SIZE / 2f), BUTTON_SIZE, BUTTON_SIZE,
                16, 0, BUTTON_SIZE, WIDGETS_TEXTURE, this::buttonPressed);

        method_37063(previousButton);
        method_37063(nextButton);
    }

    private void buttonPressed(class_4185 button) {
        if (button == previousButton)
            lightroomScreen.changeFrame(PagingDirection.PREVIOUS);
        else if (button == nextButton)
            lightroomScreen.changeFrame(PagingDirection.NEXT);
    }

    public void close() {
        class_310.method_1551().method_1507(lightroomScreen);
        if (field_22787.field_1724 != null)
            field_22787.field_1724.method_5783(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), 1f, 0.7f);
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        method_25420(guiGraphics);

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(0, 0, 500); // Otherwise exposure will overlap buttons
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        guiGraphics.method_51448().method_22909();

        if (zoom.targetZoom == zoom.minZoom) {
            close();
            return;
        }

        guiGraphics.method_51448().method_22903();

        guiGraphics.method_51448().method_46416(x, y, 0);
        guiGraphics.method_51448().method_46416(field_22789 / 2f, field_22790 / 2f, 0);
        guiGraphics.method_51448().method_22905(scale, scale, scale);

        RenderSystem.setShaderTexture(0, TEXTURE);

        guiGraphics.method_51448().method_46416(BG_SIZE / -2f, BG_SIZE / -2f, 0);

        GuiUtil.blit(guiGraphics.method_51448(), 0, 0, BG_SIZE, BG_SIZE, 0, 0, 256, 256, 0);

        class_1799 filmStack = lightroomMenu.method_7611(Lightroom.FILM_SLOT).method_7677();
        if (!(filmStack.method_7909() instanceof DevelopedFilmItem film))
            return;

        FilmType negative = film.getType();

        RenderSystem.setShaderColor(negative.filmR, negative.filmG, negative.filmB, negative.filmA);

        GuiUtil.blit(guiGraphics.method_51448(), 0, 0, BG_SIZE, BG_SIZE, 0, BG_SIZE, 256, 256, 0);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        guiGraphics.method_51448().method_46416(12, 12, 0);

        int currentFrame = getLightroomMenu().getSelectedFrame();
        @Nullable class_2487 frame = getLightroomMenu().getFrameIdByIndex(currentFrame);
        if (frame != null)
            lightroomScreen.renderFrame(frame, guiGraphics.method_51448(), 0, 0, FRAME_SIZE, 1f, negative);

        guiGraphics.method_51448().method_22909();

        previousButton.field_22764 = currentFrame != 0;
        previousButton.field_22763 = currentFrame != 0;
        nextButton.field_22764 = currentFrame != getLightroomMenu().getTotalFrames() - 1;
        nextButton.field_22763 = currentFrame != getLightroomMenu().getTotalFrames() - 1;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == class_3675.field_31958 || field_22787.field_1690.field_1822.method_1417(keyCode, scanCode))
            zoom.set(0f);
        else if (field_22787.field_1690.field_1913.method_1417(keyCode, scanCode) || keyCode == class_3675.field_31983)
            lightroomScreen.changeFrame(PagingDirection.PREVIOUS);
        else if (field_22787.field_1690.field_1849.method_1417(keyCode, scanCode) || keyCode == class_3675.field_31984)
            lightroomScreen.changeFrame(PagingDirection.NEXT);
        else
            return super.method_25404(keyCode, scanCode, modifiers);

        return true;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        boolean handled = super.method_25402(mouseX, mouseY, button);
        if (handled)
            return true;

        if (button == 1) { // Right Click
            zoom.set(0f);
            return true;
        }

        return false;
    }
}
