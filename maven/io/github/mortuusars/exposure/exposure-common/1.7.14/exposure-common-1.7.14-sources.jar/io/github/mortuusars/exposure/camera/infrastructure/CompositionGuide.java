package io.github.mortuusars.exposure.camera.infrastructure;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_2540;
import net.minecraft.class_2561;

@SuppressWarnings("ClassCanBeRecord")
public class CompositionGuide {
    private final String id;

    public CompositionGuide(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public class_2561 translate() {
        return class_2561.method_43471("gui." + Exposure.ID + ".composition_guide." + id);
    }

    public void toBuffer(class_2540 buffer) {
        buffer.method_10814(id);
    }

    public static CompositionGuide fromBuffer(class_2540 buffer) {
        return CompositionGuides.byIdOrNone(buffer.method_19772());
    }
}
