package io.github.mortuusars.exposure.data.storage;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.capture.component.ICaptureComponent;
import io.github.mortuusars.exposure.camera.infrastructure.FilmType;
import io.github.mortuusars.exposure.data.ExposureSize;
import io.github.mortuusars.exposure.render.modifiers.ExposurePixelModifiers;
import io.github.mortuusars.exposure.render.modifiers.IPixelModifier;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.util.Date;
import net.minecraft.class_1011;
import net.minecraft.class_2487;
import net.minecraft.class_3620;
import net.minecraft.class_5253;

public class ClientsideExposureExporter extends ExposureExporter<ClientsideExposureExporter> implements ICaptureComponent {
    public ClientsideExposureExporter(String name) {
        super(name);
    }

    @Override
    public boolean save(byte[] mapColorPixels, int width, int height, class_2487 properties) {
        try (class_1011 image = convertToNativeImage(mapColorPixels, width, height, properties)) {
            return save(image, properties);
        }
        catch (Exception e) {
            Exposure.LOGGER.error("Cannot convert exposure pixels to NativeImage: {}", e.toString());
            return false;
        }
    }

    public boolean save(class_1011 image, class_2487 properties) {
        // Existing file would be overwritten
        try {
            String filepath = getFolder() + "/" + (getWorldSubfolder() != null ? getWorldSubfolder() + "/" : "") + getName() + ".png";
            File outputFile = new File(filepath);
            boolean ignored = outputFile.getParentFile().mkdirs();

            image.method_4325(outputFile);

            if (properties.method_10573(ExposureSavedData.TIMESTAMP_PROPERTY, class_2487.field_33254)) {
                long unixSeconds = properties.method_10537(ExposureSavedData.TIMESTAMP_PROPERTY);
                trySetFileCreationDate(outputFile.getAbsolutePath(), unixSeconds);
            }

            Exposure.LOGGER.info("Exposure saved: {}", outputFile);
            return true;
        } catch (IOException e) {
            Exposure.LOGGER.error("Failed to save exposure to file: {}", e.toString());
            return false;
        }
    }

    protected void trySetFileCreationDate(String filePath, long creationTimeUnixSeconds) {
        try {
            Date creationDate = Date.from(Instant.ofEpochSecond(creationTimeUnixSeconds));

            BasicFileAttributeView attributes = Files.getFileAttributeView(Paths.get(filePath), BasicFileAttributeView.class);
            FileTime creationTime = FileTime.fromMillis(creationDate.getTime());
            FileTime modifyTime = FileTime.fromMillis(System.currentTimeMillis());
            attributes.setTimes(modifyTime, modifyTime, creationTime);
        }
        catch (Exception ignored) { }
    }

    @NotNull
    protected class_1011 convertToNativeImage(byte[] MapColorPixels, int width, int height, class_2487 properties) {
        class_1011 image = new class_1011(width, height, false);
        IPixelModifier modifier = getModifier();

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                int ABGR = class_3620.method_38480(MapColorPixels[x + y * width]); // Mojang returns BGR color
                ABGR = modifier.modifyPixel(ABGR);

                // Tint image like it's rendered in LightroomScreen or NegativeExposureScreen:
                // This is not the best place for it, but I haven't found better a better one.
                if (modifier == ExposurePixelModifiers.NEGATIVE_FILM) {
                    @Nullable FilmType filmType = FilmType.byName(properties.method_10558(ExposureSavedData.TYPE_PROPERTY));
                    if (filmType != null) {

                        int a = class_5253.class_8045.method_48342(ABGR);
                        int b = class_5253.class_8045.method_48347(ABGR);
                        int g = class_5253.class_8045.method_48346(ABGR);
                        int r = class_5253.class_8045.method_48345(ABGR);

                        b = b * filmType.frameB / 255;
                        g = g * filmType.frameG / 255;
                        r = r * filmType.frameR / 255;

                        ABGR = class_5253.class_8045.method_48344(a, b, g, r);
                    }
                }

                image.method_4305(x, y, ABGR);
            }
        }

        if (getSize() != ExposureSize.X1) {
            int resultWidth = image.method_4307() * getSize().getMultiplier();
            int resultHeight = image.method_4323() * getSize().getMultiplier();
            class_1011 resized = resize(image, 0, 0, image.method_4307(), image.method_4323(), resultWidth, resultHeight);
            image.close();
            image = resized;
        }

        return image;
    }

    protected class_1011 resize(class_1011 source, int sourceX, int sourceY, int sourceWidth, int sourceHeight,
                                              int resultWidth, int resultHeight) {
        class_1011 result = new class_1011(source.method_4318(), resultWidth, resultHeight, false);

        for (int x = 0; x < resultWidth; x++) {
            float ratioX = x / (float)resultWidth;
            int sourcePosX = (int)(sourceX + (sourceWidth * ratioX));

            for (int y = 0; y < resultHeight; y++) {
                float ratioY = y / (float)resultHeight;
                int sourcePosY = (int)(sourceY + (sourceHeight * ratioY));
                int color = source.method_4315(sourcePosX, sourcePosY);
                result.method_4305(x, y, color);
            }
        }

        return result;
    }
}
