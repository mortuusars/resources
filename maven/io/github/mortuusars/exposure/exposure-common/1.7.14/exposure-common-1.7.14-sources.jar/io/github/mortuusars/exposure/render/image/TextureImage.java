package io.github.mortuusars.exposure.render.image;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_1011;
import net.minecraft.class_1044;
import net.minecraft.class_1049;
import net.minecraft.class_1060;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.client.renderer.texture.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.util.concurrent.Executor;

public class TextureImage extends class_1049 implements IImage {
    private final String name;
    @Nullable
    private class_1011 image;

    public TextureImage(class_2960 location) {
        super(location);
        name = location.toString();
    }

    @Override
    public String getImageId() {
        return name;
    }

    @Override
    public int getWidth() {
        @Nullable class_1011 image = getImage();
        return image != null ? image.method_4307() : 1;
    }

    @Override
    public int getHeight() {
        @Nullable class_1011 image = getImage();
        return image != null ? image.method_4323() : 1;
    }

    @Override
    public int getPixelABGR(int x, int y) {
        @Nullable class_1011 image = getImage();
        return image != null ? image.method_4315(x, y) : 0x00000000;
    }

    public static @Nullable io.github.mortuusars.exposure.render.image.TextureImage getTexture(class_2960 location) {
        class_1060 textureManager = class_310.method_1551().method_1531();

        @Nullable class_1044 existingTexture = textureManager.field_5286.get(location);
        if (existingTexture != null) {
            return existingTexture instanceof io.github.mortuusars.exposure.render.image.TextureImage exposureTexture ? exposureTexture : null;
        }

        try {
            io.github.mortuusars.exposure.render.image.TextureImage texture = new io.github.mortuusars.exposure.render.image.TextureImage(location);
            textureManager.method_4616(location, texture);
            return texture;
        }
        catch (Exception e) {
            Exposure.LOGGER.error("Cannot load texture [{}]. {}", location, e);
            return null;
        }
    }

    public @Nullable class_1011 getImage() {
        if (this.image != null)
            return image;

        try {
            class_1011 image = super.method_18153(class_310.method_1551().method_1478()).method_18157();
            this.image = image;
            return image;
        } catch (IOException e) {
            Exposure.LOGGER.error("Cannot load texture: {}", e.toString());
            return null;
        }
    }

    @Override
    public void method_18169(@NotNull class_1060 pTextureManager, @NotNull class_3300 pResourceManager, @NotNull class_2960 pPath, @NotNull Executor pExecutor) {
        super.method_18169(pTextureManager, pResourceManager, pPath, pExecutor);
        if (image != null) {
            image.close();
            image = null;
        }
    }

    @Override
    public void close() {
        super.close();

        if (this.image != null) {
            image.close();
            image = null;
        }
    }
}
