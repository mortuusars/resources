package io.github.mortuusars.exposure.integration.kubejs;

import dev.architectury.injectables.annotations.ExpectPlatform;
import dev.latvian.mods.kubejs.KubeJSPlugin;
import dev.latvian.mods.kubejs.event.EventResult;
import dev.latvian.mods.kubejs.script.ScriptType;
import io.github.mortuusars.exposure.integration.kubejs.event.ExposureJSEvents;
import io.github.mortuusars.exposure.integration.kubejs.event.FrameAddedEventJS;
import io.github.mortuusars.exposure.integration.kubejs.event.ModifyFrameDataEventJS;
import io.github.mortuusars.exposure.integration.kubejs.event.ShutterOpeningEventJS;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_3222;

public class ExposureJSPlugin extends KubeJSPlugin {
    @Override
    public void init() {
        subscribeToEvents();
    }

    @ExpectPlatform
    public static void subscribeToEvents() {
        throw new AssertionError();
    }

    @Override
    public void registerEvents() {
        ExposureJSEvents.register();
    }

    public static boolean fireShutterOpeningEvent(class_1657 player, class_1799 cameraStack, int lightLevel, boolean shouldFlashFire) {
        EventResult result = ExposureJSEvents.SHUTTER_OPENING.post(player.method_37908().field_9236 ? ScriptType.CLIENT : ScriptType.SERVER,
                new ShutterOpeningEventJS(player, cameraStack, lightLevel, shouldFlashFire));
        return result.interruptTrue() || result.interruptFalse() || result.interruptDefault();
    }

    public static void fireModifyFrameDataEvent(class_3222 player, class_1799 cameraStack, class_2487 frame, List<class_1297> entitiesInFrame) {
        ExposureJSEvents.MODIFY_FRAME_DATA.post(ScriptType.SERVER, new ModifyFrameDataEventJS(player, cameraStack, frame, entitiesInFrame));
    }

    public static void fireFrameAddedEvent(class_3222 player, class_1799 cameraStack, class_2487 frame) {
        ExposureJSEvents.FRAME_ADDED.post(ScriptType.SERVER, new FrameAddedEventJS(player, cameraStack, frame));
    }
}
