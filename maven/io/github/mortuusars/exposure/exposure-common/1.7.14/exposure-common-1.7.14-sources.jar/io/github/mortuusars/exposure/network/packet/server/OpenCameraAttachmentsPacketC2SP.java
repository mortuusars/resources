package io.github.mortuusars.exposure.network.packet.server;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

public record OpenCameraAttachmentsPacketC2SP(int cameraSlotIndex) implements IPacket {
    public static final class_2960 ID = Exposure.resource("open_camera_attachments");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public class_2540 toBuffer(class_2540 buffer) {
        buffer.writeInt(cameraSlotIndex);
        return buffer;
    }

    public static OpenCameraAttachmentsPacketC2SP fromBuffer(class_2540 buffer) {
        return new OpenCameraAttachmentsPacketC2SP(buffer.readInt());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        if (player == null) {
            throw new IllegalStateException("Cannot handle the packet: Player was null");
        }

        if (player instanceof class_3222 serverPlayer) {
            serverPlayer.field_13995.execute(() -> {
                class_1799 stack = player.method_31548().method_5438(cameraSlotIndex);
                if (stack.method_7909() instanceof CameraItem cameraItem) {
                    cameraItem.openCameraAttachmentsMenu(player, cameraSlotIndex);
                }
            });
        }

        return true;
    }
}
