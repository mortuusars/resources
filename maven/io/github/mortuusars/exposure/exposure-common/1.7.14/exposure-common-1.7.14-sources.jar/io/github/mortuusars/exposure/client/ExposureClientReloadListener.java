package io.github.mortuusars.exposure.client;

import io.github.mortuusars.exposure.ExposureClient;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4080;
import org.jetbrains.annotations.NotNull;

public class ExposureClientReloadListener extends class_4080<Boolean> {
    @Override
    protected @NotNull Boolean method_18789(class_3300 resourceManager, class_3695 profiler) {
        return true;
    }

    @Override
    protected void apply(Boolean object, class_3300 resourceManager, class_3695 profiler) {
        ExposureClient.getExposureStorage().clear();
        ExposureClient.getExposureRenderer().clearData();
    }
}
