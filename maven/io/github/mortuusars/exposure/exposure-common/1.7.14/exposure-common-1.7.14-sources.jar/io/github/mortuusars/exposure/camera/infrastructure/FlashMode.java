package io.github.mortuusars.exposure.camera.infrastructure;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3542;
import org.jetbrains.annotations.NotNull;

public enum FlashMode implements class_3542 {
    OFF("off"),
    ON("on"),
    AUTO("auto");

    private final String id;

    FlashMode(String id) {
        this.id = id;
    }

    public static FlashMode byIdOrOff(String id) {
        for (FlashMode guide : values()) {
            if (guide.id.equals(id))
                return guide;
        }

        return OFF;
    }

    public String getId() {
        return id;
    }

    @Override
    public @NotNull String method_15434() {
        return id;
    }

    public class_2561 translate() {
        return class_2561.method_43471("gui." + Exposure.ID + ".flash_mode." + id);
    }
    public void toBuffer(class_2540 buffer) {
        buffer.method_10814(getId());
    }

    public static FlashMode fromBuffer(class_2540 buffer) {
        return FlashMode.byIdOrOff(buffer.method_19772());
    }
}
