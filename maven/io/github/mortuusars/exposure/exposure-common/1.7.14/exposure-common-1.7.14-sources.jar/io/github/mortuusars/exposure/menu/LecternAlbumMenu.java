package io.github.mortuusars.exposure.menu;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.item.AlbumItem;
import io.github.mortuusars.exposure.util.ItemAndStack;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_3722;
import net.minecraft.class_3913;
import net.minecraft.class_3917;
import net.minecraft.class_3919;
import net.minecraft.world.inventory.*;

public class LecternAlbumMenu extends AlbumMenu {
    public static final int TAKE_BOOK_BUTTON = 99;

    private final class_1263 lectern;
    private final class_2338 lecternPos;
    private final class_1937 level;

    public LecternAlbumMenu(int containerId, class_2338 lecternPos, class_1661 playerInventory,
                            ItemAndStack<AlbumItem> album, class_1263 lectern, class_3913 lecternData) {
        this(Exposure.MenuTypes.LECTERN_ALBUM.get(), containerId, lecternPos, playerInventory, album, lectern, lecternData);
    }

    protected LecternAlbumMenu(class_3917<? extends class_1703> type, int containerId, class_2338 lecternPos,
                               class_1661 playerInventory, ItemAndStack<AlbumItem> album, class_1263 lectern, class_3913 lecternData) {
        super(type, containerId, playerInventory, new ItemAndStack<>(album.getStack()), false);
        method_17359(lectern, 1);
        method_17361(lecternData, 1);
        this.lecternPos = lecternPos;
        this.lectern = lectern;
        this.level = playerInventory.field_7546.method_37908();
        this.method_7621(new class_1735(lectern, 0, -999, -999) {
            @Override
            public void method_7668() {
                super.method_7668();
                LecternAlbumMenu.this.method_7609(this.field_7871);
            }
        });
        this.method_17360(lecternData);
        setCurrentSpreadIndex(lecternData.method_17390(0));
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (id == TAKE_BOOK_BUTTON) {
            if (!player.method_7294())
                return false;

            class_1799 albumStack = this.lectern.method_5441(0);
            this.lectern.method_5431();
            if (!player.method_31548().method_7394(albumStack))
                player.method_7328(albumStack, false);

            return true;
        }

        return super.method_7604(player, id);
    }

    @Override
    public void setCurrentSpreadIndex(int spreadIndex) {
        spreadIndex = Math.max(0, spreadIndex);
        super.setCurrentSpreadIndex(spreadIndex);
        method_7606(1, spreadIndex);
    }

    @Override
    public void method_7606(int id, int data) {
        super.method_7606(id, data);
        this.method_7623();
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return level.method_8321(lecternPos) instanceof class_3722 lecternBlockEntity
                && lecternBlockEntity.method_17520().method_7909() instanceof AlbumItem
                && class_1263.method_49105(lecternBlockEntity, player);
    }

    public static LecternAlbumMenu fromBuffer(int containerId, class_1661 inventory, class_2540 buffer) {
        return new LecternAlbumMenu(containerId, buffer.method_10811(), inventory,
                new ItemAndStack<>(buffer.method_10819()), new class_1277(1), new class_3919(1));
    }
}
