package io.github.mortuusars.exposure.gui.screen.album;

import io.github.mortuusars.exposure.gui.screen.element.textbox.TextBox;
import io.github.mortuusars.exposure.menu.AlbumMenu;
import io.github.mortuusars.exposure.menu.LecternAlbumMenu;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1712;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_5244;

public class LecternAlbumScreen extends AlbumScreen {
    private final LecternAlbumMenu menu;

    private final class_1712 listener = new class_1712() {
        public void method_7635(class_1703 containerToSend, int dataSlotIndex, class_1799 stack) { }

        public void method_7633(class_1703 containerMenu, int dataSlotIndex, int value) {
            if (dataSlotIndex == 1) {
                method_17577().setCurrentSpreadIndex(value);
                pager.setPage(value);
                for (Page page : pages) {
                    page.noteWidget
                            .ifLeft(TextBox::setCursorToEnd)
                            .ifRight(textBlock -> textBlock.method_25355(getNoteComponent(page.side)));
                }
            }
        }
    };

    public LecternAlbumScreen(AlbumMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
        this.menu = (LecternAlbumMenu) menu;
        menu.method_7596(listener);
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        if (player.method_7294()) {
            method_37063(class_4185.method_46430(class_5244.field_24334, b -> this.method_25419())
                    .method_46434(this.field_22789 / 2 - 100, field_2800 + 196, 98, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43471("lectern.take_book"), b -> sendButtonClick(LecternAlbumMenu.TAKE_BOOK_BUTTON))
                    .method_46434(this.field_22789 / 2 + 2, field_2800 + 196, 98, 20).method_46431());
        }
    }

    public void method_25432() {
        super.method_25432();
        this.menu.method_7603(this.listener);
    }
}
