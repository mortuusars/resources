package io.github.mortuusars.exposure.gui.screen.camera.button;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.Camera;
import io.github.mortuusars.exposure.camera.CameraClient;
import io.github.mortuusars.exposure.camera.infrastructure.ShutterSpeed;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1109;
import net.minecraft.class_1144;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class ShutterSpeedButton extends CycleButton {
    private final List<ShutterSpeed> shutterSpeeds;
    private final int secondaryFontColor;
    private final int mainFontColor;

    public ShutterSpeedButton(class_437 screen, int x, int y, int width, int height, int u, int v, class_2960 texture) {
        super(screen, x, y, width, height, u, v, height, texture);

        Camera<?> camera = CameraClient.getCamera().orElseThrow();

        List<ShutterSpeed> speeds = new ArrayList<>(camera.get().getItem().getAllShutterSpeeds(camera.get().getStack()));
        Collections.reverse(speeds);
        shutterSpeeds = speeds;

        ShutterSpeed shutterSpeed = camera.get().getItem().getShutterSpeed(camera.get().getStack());
        if (!shutterSpeeds.contains(shutterSpeed)) {
            throw new IllegalStateException("Camera {" + camera.get().getStack() + "} has invalid shutter speed.");
        }

        int currentShutterSpeedIndex = 0;
        for (int i = 0; i < shutterSpeeds.size(); i++) {
            if (shutterSpeed.equals(shutterSpeeds.get(i)))
                currentShutterSpeedIndex = i;
        }

        setupButtonElements(shutterSpeeds.size(), currentShutterSpeedIndex);
        secondaryFontColor = Config.Client.getSecondaryFontColor();
        mainFontColor = Config.Client.getMainFontColor();
    }

    @Override
    public void method_25354(class_1144 handler) {
        handler.method_4873(class_1109.method_4757(Exposure.SoundEvents.CAMERA_DIAL_CLICK.get(),
                Objects.requireNonNull(class_310.method_1551().field_1687).field_9229.method_43057() * 0.05f + 0.9f + currentIndex * 0.01f, 0.7f));
    }

    @Override
    public void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_48579(guiGraphics, mouseX, mouseY, partialTick);

        ShutterSpeed shutterSpeed = shutterSpeeds.get(currentIndex);
        String text = shutterSpeed.toString();

        if (shutterSpeed.equals(ShutterSpeed.DEFAULT))
            text = text + "•";

        class_327 font = class_310.method_1551().field_1772;
        int textWidth = font.method_1727(text);
        int xPos = 35 - (textWidth / 2);

        guiGraphics.method_51433(font, text, method_46426() + xPos, method_46427() + 4, secondaryFontColor, false);
        guiGraphics.method_51433(font, text, method_46426() + xPos, method_46427() + 3, mainFontColor, false);
    }

    @Override
    public void renderToolTip(@NotNull class_332 guiGraphics, int mouseX, int mouseY) {
        guiGraphics.method_51438(class_310.method_1551().field_1772, class_2561.method_43471("gui.exposure.viewfinder.shutter_speed.tooltip"), mouseX, mouseY);
    }

    @Override
    protected void onCycle() {
        CameraClient.setShutterSpeed(shutterSpeeds.get(currentIndex));
    }
}
