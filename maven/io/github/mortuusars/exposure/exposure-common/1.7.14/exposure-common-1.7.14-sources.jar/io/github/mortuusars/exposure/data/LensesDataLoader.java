package io.github.mortuusars.exposure.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.infrastructure.FocalRange;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4309;

public class LensesDataLoader extends class_4309 {
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    public static final String DIRECTORY = "lenses";
    
    public LensesDataLoader() {
        super(GSON, DIRECTORY);
    }

    @Override
    protected void apply(Map<class_2960, JsonElement> content, class_3300 resourceManager, class_3695 profiler) {
        ConcurrentMap<class_1856, FocalRange> lenses = new ConcurrentHashMap<>();

        Exposure.LOGGER.info("Loading exposure lenses:");

        for (var entry : content.entrySet()) {
            // Lenses should be in data/exposure/lenses folder.
            // Excluding other namespaces because it potentially can cause conflicts,
            // if some other mod adds their own type of 'lens'.
            if (!entry.getKey().method_12836().equals(Exposure.ID))
                continue;

            try {
                JsonObject jsonObject = entry.getValue().getAsJsonObject();
                JsonElement item = jsonObject.get("item");

                class_1856 ingredient = class_1856.method_52177(item);
                if (ingredient.method_8103())
                    throw new IllegalArgumentException("'item' cannot be empty.");

                JsonElement value = jsonObject.get("focal_range");
                FocalRange focalRange = FocalRange.fromJson(value);

                lenses.put(ingredient, focalRange);

                Exposure.LOGGER.info("Lens [" + entry.getKey() + ", " + focalRange + "] added.");
            }
            catch (Exception e) {
                Exposure.LOGGER.error(e.toString());
            }
        }

        if (lenses.isEmpty())
            Exposure.LOGGER.info("No lenses have been loaded.");

        Lenses.reload(lenses);
    }
}