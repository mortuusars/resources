package io.github.mortuusars.exposure.network.packet.server;

import com.google.common.base.Preconditions;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.item.AlbumPage;
import io.github.mortuusars.exposure.menu.AlbumMenu;
import io.github.mortuusars.exposure.network.PacketDirection;
import io.github.mortuusars.exposure.network.packet.IPacket;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public record AlbumSyncNoteC2SP(int pageIndex, String text) implements IPacket {
    public static final class_2960 ID = Exposure.resource("album_update_note");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public static AlbumSyncNoteC2SP fromBuffer(class_2540 buffer) {
        return new AlbumSyncNoteC2SP(buffer.readInt(), buffer.method_19772());
    }

    @Override
    public class_2540 toBuffer(class_2540 buffer) {
        buffer.writeInt(pageIndex);
        buffer.method_10814(text);
        return buffer;
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        Preconditions.checkState(player != null, "Cannot handle packet: Player was null");

        if (!(player.field_7512 instanceof AlbumMenu albumMenu))
            throw new IllegalStateException("Player receiving this packet should have AlbumMenu open. Current menu: " + player.field_7512);

        AlbumPage page = albumMenu.getPages().get(pageIndex);
        page.setNote(Either.left(text));
        albumMenu.updateAlbumStack();

        return true;
    }
}
