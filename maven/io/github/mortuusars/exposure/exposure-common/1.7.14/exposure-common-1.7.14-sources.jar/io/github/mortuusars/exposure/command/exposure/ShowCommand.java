package io.github.mortuusars.exposure.command.exposure;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.command.argument.TextureLocationArgument;
import io.github.mortuusars.exposure.command.suggestion.ExposureIdSuggestionProvider;
import io.github.mortuusars.exposure.data.storage.ExposureSavedData;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.client.ShowExposureS2CP;
import java.util.Optional;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2232;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class ShowCommand {
    public static LiteralArgumentBuilder<class_2168> get() {
        return class_2170.method_9247("show")
                .then(class_2170.method_9247("latest")
                        .executes(context -> latest(context.getSource(), false))
                        .then(class_2170.method_9247("negative")
                                .executes(context -> latest(context.getSource(), true))))
                .then(class_2170.method_9247("id")
                        .then(class_2170.method_9244("id", StringArgumentType.string())
                                .suggests(new ExposureIdSuggestionProvider())
                                .executes(context -> exposureId(context.getSource(),
                                        StringArgumentType.getString(context, "id"), false))
                                .then(class_2170.method_9247("negative")
                                        .executes(context -> exposureId(context.getSource(),
                                                StringArgumentType.getString(context, "id"), true)))))
                .then(class_2170.method_9247("texture")
                        .then(class_2170.method_9244("path", new TextureLocationArgument())
                                .executes(context -> texture(context.getSource(),
                                        class_2232.method_9443(context, "path"), false))
                                .then(class_2170.method_9247("negative")
                                        .executes(context -> texture(context.getSource(),
                                                class_2232.method_9443(context, "path"), true)))));
    }

    private static int latest(class_2168 stack, boolean negative) {
        class_3222 player = stack.method_44023();
        if (player == null) {
            stack.method_9213(class_2561.method_43471("command.exposure.show.error.not_a_player"));
            return 1;
        }

        Packets.sendToClient(ShowExposureS2CP.latest(negative), player);
        return 0;
    }

    private static int exposureId(class_2168 stack, String id, boolean negative) {
        class_3222 player = stack.method_44023();
        if (player == null) {
            stack.method_9213(class_2561.method_43471("command.exposure.show.error.not_a_player"));
            return 1;
        }

        Optional<ExposureSavedData> exposureData = ExposureServer.getExposureStorage().getOrQuery(id);
        if (exposureData.isEmpty()) {
            stack.method_9213(class_2561.method_43469("command.exposure.show.error.not_found", id));
            return 0;
        }

        ExposureServer.getExposureSender().sendTo(player, id, exposureData.get());

        Packets.sendToClient(ShowExposureS2CP.id(id, negative), player);

        return 0;
    }

    private static int texture(class_2168 stack, class_2960 path, boolean negative) {
        class_3222 player = stack.method_44023();
        if (player == null) {
            stack.method_9213(class_2561.method_43471("command.exposure.show.error.not_a_player"));
            return 1;
        }

        Packets.sendToClient(ShowExposureS2CP.texture(path.toString(), negative), player);

        return 0;
    }
}
