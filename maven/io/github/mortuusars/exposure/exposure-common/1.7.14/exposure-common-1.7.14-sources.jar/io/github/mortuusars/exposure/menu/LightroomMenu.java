package io.github.mortuusars.exposure.menu;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.block.entity.Lightroom;
import io.github.mortuusars.exposure.block.entity.LightroomBlockEntity;
import io.github.mortuusars.exposure.item.DevelopedFilmItem;
import io.github.mortuusars.exposure.item.IFilmItem;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_3532;
import net.minecraft.class_3913;
import net.minecraft.class_3919;

public class LightroomMenu extends class_1703 {
    public static final int PRINT_BUTTON_ID = 0;
    public static final int PRINT_CREATIVE_BUTTON_ID = 1;
    public static final int PREVIOUS_FRAME_BUTTON_ID = 2;
    public static final int NEXT_FRAME_BUTTON_ID = 3;
    public static final int TOGGLE_PROCESS_BUTTON_ID = 4;

    private final LightroomBlockEntity lightroomBlockEntity;
    private final class_3913 data;

    private class_2499 frames = new class_2499();

    public LightroomMenu(int containerId, final class_1661 playerInventory, final LightroomBlockEntity blockEntity, class_3913 containerData) {
        super(Exposure.MenuTypes.LIGHTROOM.get(), containerId);
        this.lightroomBlockEntity = blockEntity;
        this.data = containerData;

        {
            this.method_7621(new class_1735(blockEntity, Lightroom.FILM_SLOT, -20, 42) {
                @Override
                public boolean method_7680(class_1799 stack) {
                    return blockEntity.isItemValidForSlot(Lightroom.FILM_SLOT, stack);
                }

                @Override
                public void method_7668() {
                    frames = method_7677().method_7909() instanceof DevelopedFilmItem developedFilm ?
                            developedFilm.getExposedFrames(method_7677()) : new class_2499();
                    if (lightroomBlockEntity.method_10997() != null && !lightroomBlockEntity.method_10997().field_9236)
                        data.method_17391(LightroomBlockEntity.CONTAINER_DATA_SELECTED_FRAME_ID, 0);
                    super.method_7668();
                }
            });

            this.method_7621(new class_1735(blockEntity, Lightroom.PAPER_SLOT, 8, 92){
                @Override
                public boolean method_7680(class_1799 stack) {
                    return blockEntity.isItemValidForSlot(Lightroom.PAPER_SLOT, stack);
                }
            });
            this.method_7621(new class_1735(blockEntity, Lightroom.CYAN_SLOT, 42, 92){
                @Override
                public boolean method_7680(class_1799 stack) {
                    return blockEntity.isItemValidForSlot(Lightroom.CYAN_SLOT, stack);
                }
            });
            this.method_7621(new class_1735(blockEntity, Lightroom.MAGENTA_SLOT, 60, 92){
                @Override
                public boolean method_7680(class_1799 stack) {
                    return blockEntity.isItemValidForSlot(Lightroom.MAGENTA_SLOT, stack);
                }
            });
            this.method_7621(new class_1735(blockEntity, Lightroom.YELLOW_SLOT, 78, 92){
                @Override
                public boolean method_7680(class_1799 stack) {
                    return blockEntity.isItemValidForSlot(Lightroom.YELLOW_SLOT, stack);
                }
            });
            this.method_7621(new class_1735(blockEntity, Lightroom.BLACK_SLOT, 96, 92){
                @Override
                public boolean method_7680(class_1799 stack) {
                    return blockEntity.isItemValidForSlot(Lightroom.BLACK_SLOT, stack);
                }
            });

            // OUTPUT
            this.method_7621(new class_1735(blockEntity, Lightroom.RESULT_SLOT, 148, 92) {
                @Override
                public boolean method_7680(@NotNull class_1799 stack) {
                    return false;
                }

                @Override
                public void method_7667(@NotNull class_1657 player, @NotNull class_1799 pStack) {
                    super.method_7667(player, pStack);
                    blockEntity.dropStoredExperience(player);
                }

                @Override
                public void method_7670(@NotNull class_1799 oldStackIn, @NotNull class_1799 newStackIn) {
                    super.method_7670(oldStackIn, newStackIn);
                    blockEntity.dropStoredExperience(playerInventory.field_7546);
                }
            });
        }

        // Player inventory slots
        for(int row = 0; row < 3; ++row) {
            for(int column = 0; column < 9; ++column) {
                this.method_7621(new class_1735(playerInventory, column + row * 9 + 9, 8 + column * 18, 127 + row * 18));
            }
        }

        // Player hotbar slots
        // Hotbar should go after main inventory for Shift+Click to work properly.
        for(int index = 0; index < 9; ++index) {
            this.method_7621(new class_1735(playerInventory, index, 8 + index * 18, 185));
        }

        this.method_17360(data);
    }

    public static LightroomMenu fromBuffer(int containerID, class_1661 playerInventory, class_2540 buffer) {
        return new LightroomMenu(containerID, playerInventory, getBlockEntity(playerInventory, buffer),
                new class_3919(LightroomBlockEntity.CONTAINER_DATA_SIZE));
    }

    public LightroomBlockEntity getBlockEntity() {
        return lightroomBlockEntity;
    }

    public class_3913 getData() {
        return data;
    }

    public class_2499 getExposedFrames() {
        return frames;
    }

    public @Nullable class_2487 getFrameIdByIndex(int index) {
        return index >= 0 && index < getExposedFrames().size() ? getExposedFrames().method_10602(index) : null;
    }

    public int getSelectedFrame() {
        return data.method_17390(LightroomBlockEntity.CONTAINER_DATA_SELECTED_FRAME_ID);
    }

    public boolean isPrinting() {
        return data.method_17390(LightroomBlockEntity.CONTAINER_DATA_PRINT_TIME_ID) > 0;
    }

    public int getTotalFrames() {
        class_1799 filmStack = getBlockEntity().method_5438(Lightroom.FILM_SLOT);
        return (!filmStack.method_7960() && filmStack.method_7909() instanceof IFilmItem filmItem) ? filmItem.getExposedFramesCount(filmStack) : 0;
    }

    public boolean canChangeProcess() {
        return getBlockEntity().canPrintChromatic(getBlockEntity().method_5438(Lightroom.FILM_SLOT), getSelectedFrame());
    }

    @Override
    public boolean method_7604(class_1657 player, int buttonId) {
        Preconditions.checkState(!player.method_37908().field_9236, "This should be server-side only.");

        if (buttonId == PREVIOUS_FRAME_BUTTON_ID || buttonId == NEXT_FRAME_BUTTON_ID) {
            class_1799 filmStack = getBlockEntity().method_5438(Lightroom.FILM_SLOT);
            if (!filmStack.method_7960() && filmStack.method_7909() instanceof DevelopedFilmItem) {
                int frames = getTotalFrames();
                if (frames == 0)
                    return true;

                int selectedFrame = data.method_17390(LightroomBlockEntity.CONTAINER_DATA_SELECTED_FRAME_ID);
                selectedFrame = selectedFrame + (buttonId == NEXT_FRAME_BUTTON_ID ? 1 : -1);
                selectedFrame = class_3532.method_15340(selectedFrame, 0, frames - 1);
                data.method_17391(LightroomBlockEntity.CONTAINER_DATA_SELECTED_FRAME_ID, selectedFrame);
                return true;
            }
        }

        if (buttonId == TOGGLE_PROCESS_BUTTON_ID) {
            Lightroom.Process currentProcess = getBlockEntity().getProcess();
            getBlockEntity().setProcess(currentProcess == Lightroom.Process.CHROMATIC ? Lightroom.Process.REGULAR : Lightroom.Process.CHROMATIC);
        }

        if (buttonId == PRINT_BUTTON_ID) {
            getBlockEntity().startPrintingProcess(false);
            return true;
        }

        if (buttonId == PRINT_CREATIVE_BUTTON_ID) {
            if (player.method_7337())
                getBlockEntity().printInCreativeMode();
        }

        return false;
    }

    @Override
    public @NotNull class_1799 method_7601(@NotNull class_1657 player, int index) {
        class_1735 slot = field_7761.get(index);
        class_1799 clickedStack = slot.method_7677();
        class_1799 returnedStack = clickedStack.method_7972();

         if (index < Lightroom.SLOTS) {
            if (!method_7616(clickedStack, Lightroom.SLOTS, field_7761.size(), true)) {
                return class_1799.field_8037;
            }

            if (index == Lightroom.RESULT_SLOT)
                slot.method_7670(clickedStack, returnedStack);
        }
        else if (index < field_7761.size()) {
            if (!method_7616(clickedStack, 0, Lightroom.SLOTS, false))
                return class_1799.field_8037;
        }

        if (clickedStack.method_7960()) {
            slot.method_7673(class_1799.field_8037);
        } else {
            slot.method_7668();
        }

        return returnedStack;
    }

    /**
     * Fixed method to respect slot photo limit.
     */
    @Override
    protected boolean method_7616(class_1799 movedStack, int startIndex, int endIndex, boolean reverseDirection) {
        boolean hasRemainder = false;
        int i = startIndex;
        if (reverseDirection) {
            i = endIndex - 1;
        }
        if (movedStack.method_7946()) {
            while (!movedStack.method_7960() && !(!reverseDirection ? i >= endIndex : i < startIndex)) {
                class_1735 slot = this.field_7761.get(i);
                class_1799 slotStack = slot.method_7677();
                if (!slotStack.method_7960() && class_1799.method_31577(movedStack, slotStack)) {
                    int maxSize;
                    int j = slotStack.method_7947() + movedStack.method_7947();
                    if (j <= (maxSize = Math.min(slot.method_7675(), movedStack.method_7914()))) {
                        movedStack.method_7939(0);
                        slotStack.method_7939(j);
                        slot.method_7668();
                        hasRemainder = true;
                    } else if (slotStack.method_7947() < maxSize) {
                        movedStack.method_7934(maxSize - slotStack.method_7947());
                        slotStack.method_7939(maxSize);
                        slot.method_7668();
                        hasRemainder = true;
                    }
                }
                if (reverseDirection) {
                    --i;
                    continue;
                }
                ++i;
            }
        }
        if (!movedStack.method_7960()) {
            i = reverseDirection ? endIndex - 1 : startIndex;
            while (!(!reverseDirection ? i >= endIndex : i < startIndex)) {
                class_1735 slot1 = this.field_7761.get(i);
                class_1799 itemmovedStack1 = slot1.method_7677();
                if (itemmovedStack1.method_7960() && slot1.method_7680(movedStack)) {
                    if (movedStack.method_7947() > slot1.method_7675()) {
                        slot1.method_48931(movedStack.method_7971(slot1.method_7675()));
                    } else {
                        slot1.method_48931(movedStack.method_7971(movedStack.method_7947()));
                    }
                    slot1.method_7668();
                    hasRemainder = true;
                    break;
                }
                if (reverseDirection) {
                    --i;
                    continue;
                }
                ++i;
            }
        }
        return hasRemainder;
    }

    @Override
    public boolean method_7597(@NotNull class_1657 player) {
        return lightroomBlockEntity.method_5443(player);
    }

    private static LightroomBlockEntity getBlockEntity(final class_1661 playerInventory, final class_2540 data) {
        Objects.requireNonNull(playerInventory, "playerInventory cannot be null");
        Objects.requireNonNull(data, "data cannot be null");
        final class_2586 blockEntityAtPos = playerInventory.field_7546.method_37908().method_8321(data.method_10811());
        if (blockEntityAtPos instanceof LightroomBlockEntity blockEntity)
            return blockEntity;
        throw new IllegalStateException("Block entity is not correct! " + blockEntityAtPos);
    }
}
