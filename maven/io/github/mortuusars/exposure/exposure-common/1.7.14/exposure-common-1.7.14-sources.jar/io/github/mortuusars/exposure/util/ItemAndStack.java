package io.github.mortuusars.exposure.util;

import java.util.function.BiConsumer;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class ItemAndStack<T extends class_1792> {
    private final T item;
    private final class_1799 stack;

    @SuppressWarnings("unchecked")
    public ItemAndStack(class_1799 stack) {
        this.stack = stack;
        this.item = (T) stack.method_7909();
    }

    public T getItem() {
        return item;
    }

    public class_1799 getStack() {
        return stack;
    }

    public ItemAndStack<T> apply(BiConsumer<T, class_1799> function) {
        function.accept(item, stack);
        return this;
    }

    @Override
    public String toString() {
        return "ItemAndStack{" + stack.toString() + '}';
    }
}
