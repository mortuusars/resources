package io.github.mortuusars.exposure.advancement.predicate;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_2048;
import net.minecraft.class_2096;
import net.minecraft.class_2105;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_3222;
import net.minecraft.class_3518;

public class ExposurePredicate {
    public static final ExposurePredicate ANY = new ExposurePredicate(class_2096.class_2100.field_9708, class_2096.class_2100.field_9708,
            class_2105.field_9716, class_2096.class_2100.field_9708, class_2048.field_9599);

    private final class_2096.class_2100 dayTime;
    private final class_2096.class_2100 lightLevel;
    private final class_2105 nbt;
    private final class_2096.class_2100 entitiesInFrameCount;
    private final class_2048 entityInFrame;

    public ExposurePredicate(class_2096.class_2100 dayTime,
                             class_2096.class_2100 lightLevel,
                             class_2105 nbtPredicate,
                             class_2096.class_2100 entitiesInFrameCount,
                             class_2048 entityInFramePredicate) {
        this.dayTime = dayTime;
        this.lightLevel = lightLevel;
        this.nbt = nbtPredicate;
        this.entitiesInFrameCount = entitiesInFrameCount;
        this.entityInFrame = entityInFramePredicate;
    }

    public boolean matches(class_3222 player, class_2487 frameTag, List<class_1297> entitiesInFrame) {
        if (this.equals(ANY)) {
            return true;
        }

        return this.dayTime.method_9054(frameTag.method_10573(FrameData.DAYTIME, class_2520.field_33253) ? frameTag.method_10550(FrameData.DAYTIME) : -1)
                && this.lightLevel.method_9054(frameTag.method_10573(FrameData.LIGHT_LEVEL, class_2520.field_33253) ? frameTag.method_10550(FrameData.LIGHT_LEVEL) : -1)
                && this.entitiesInFrameCount.method_9054(entitiesInFrame.size())
                && this.nbt.method_9077(frameTag)
                && entitiesMatch(player, entitiesInFrame);
    }

    protected boolean entitiesMatch(class_3222 player, List<class_1297> entitiesInFrame) {
        // Handles the case where the list is empty
        if (entityInFrame.equals(class_2048.field_9599)) {
            return true;
        }

        for (class_1297 entity : entitiesInFrame) {
            if (entityInFrame.method_8914(player, entity))
                return true;
        }

        return false;
    }

    public JsonElement serializeToJson() {
        if (this == ANY)
            return JsonNull.INSTANCE;

        JsonObject json = new JsonObject();
        json.add("day_time", lightLevel.method_9036());
        json.add("light_level", lightLevel.method_9036());
        json.add("nbt", nbt.method_9075());
        json.add("entities_count", entitiesInFrameCount.method_9036());
        json.add("entity_in_frame", entityInFrame.method_8912());

        return json;
    }

    public static ExposurePredicate fromJson(@Nullable JsonElement json) {
        if (json == null || json.isJsonNull())
            return ANY;

        JsonObject jsonobject = class_3518.method_15295(json, "exposure");

        return new ExposurePredicate(
                class_2096.class_2100.method_9056(jsonobject.get("day_time")),
                class_2096.class_2100.method_9056(jsonobject.get("light_level")),
                class_2105.method_9073(jsonobject.get("nbt")),
                class_2096.class_2100.method_9056(jsonobject.get("entities_count")),
                class_2048.method_8913(jsonobject.get("entity_in_frame")));
    }
}
