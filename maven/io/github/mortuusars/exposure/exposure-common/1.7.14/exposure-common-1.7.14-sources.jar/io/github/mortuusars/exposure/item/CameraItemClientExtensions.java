package io.github.mortuusars.exposure.item;

import io.github.mortuusars.exposure.PlatformHelper;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4896;
import net.minecraft.class_572;
import net.minecraft.class_630;
import net.minecraft.class_638;

public class CameraItemClientExtensions {
    public static void applyDefaultHoldingPose(class_572<?> model, class_1309 entity, class_1306 arm) {
        if (PlatformHelper.isModLoaded("realcamera")) {
            return;
        }

        model.field_3398.field_3654 += 0.4f; // If we turn head down completely - arms will be too low.
        if (arm == class_1306.field_6183) {
            class_4896.method_25447(model.field_3401, model.field_27433, model.field_3398, true);
        } else if (arm == class_1306.field_6182) {
            class_4896.method_25447(model.field_3401, model.field_27433, model.field_3398, false);
        }
        model.field_3398.field_3654 += 0.3f;
    }

    public static void applySelfieHoldingPose(class_572<?> model, class_1309 entity, class_1306 arm, boolean undoArmBobbing) {
        class_630 cameraArm = arm == class_1306.field_6183 ? model.field_3401 : model.field_27433;

        // Arm follows camera:
        cameraArm.field_3654 = (model.field_3398.field_3654 + Math.abs(model.field_3398.field_3654 * 0.13f)) + (-(float) Math.PI / 2F);
        cameraArm.field_3675 = model.field_3398.field_3675 + (arm == class_1306.field_6183 ? -0.25f : 0.25f);
        if (model.field_3398.field_3654 <= 0) {
            cameraArm.field_3674 = -(model.field_3398.field_3654 * 0.15f);
        } else {
            cameraArm.field_3674 = -(model.field_3398.field_3654 * 0.22f);
        }

        if (undoArmBobbing) {
            class_4896.method_29350(cameraArm, entity.field_6012 + class_310.method_1551().method_1488(),
                    arm == class_1306.field_6182 ? 1.0F : -1.0F);
        }
    }

    public static float itemPropertyFunction(class_1799 stack, class_638 clientLevel, class_1309 livingEntity, int seed) {
        if (stack.method_7909() instanceof CameraItem cameraItem) {
            if (cameraItem.isActive(stack)) {
                if (cameraItem.isInSelfieMode(stack))
                    return livingEntity == class_310.method_1551().field_1724 ? 0.2f : 0.3f;

                return 0.1f;
            }
        }

        return 0f;
    }

    public static void releaseUseButton() {
        class_310.method_1551().field_1690.field_1904.method_23481(false);
    }
}
