package io.github.mortuusars.exposure.render;

import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.entity.PhotographEntity;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_1944;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import org.jetbrains.annotations.NotNull;

public class PhotographEntityRenderer<T extends PhotographEntity> extends class_897<T> {

    public PhotographEntityRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public @NotNull class_2960 getTextureLocation(@NotNull T pEntity) {
        return class_1723.field_21668;
    }

    @Override
    public boolean shouldRender(T livingEntity, class_4604 camera, double camX, double camY, double camZ) {
        return super.method_3933(livingEntity, camera, camX, camY, camZ);
    }

    @Override
    public void render(@NotNull T entity, float entityYaw, float partialTick, @NotNull class_4587 poseStack, @NotNull class_4597 bufferSource, int packedLight) {
        super.method_3936(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);

        poseStack.method_22903();

        poseStack.method_22907(class_7833.field_40714.rotationDegrees(entity.method_36455()));
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F - entity.method_36454()));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees((entity.getRotation() * 360.0F / 4.0F)));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));

        poseStack.method_22904(-0.5, -0.5, 1f / 32f - 0.005);
        float scale = 1f / ExposureClient.getExposureRenderer().getSize();
        poseStack.method_22905(scale, scale, -scale);

        boolean isGlowing = entity.isGlowing();
        if (isGlowing)
            packedLight = class_765.field_32767;

        int brightness = isGlowing ? 255 : getPhotographBrightness(entity);

        class_1799 item = entity.getItem();

        PhotographRenderer.render(item, !entity.method_5767(), true, poseStack, bufferSource, packedLight,
                brightness, brightness, brightness, 255);

        poseStack.method_22909();
    }

    public int getPhotographBrightness(T entity) {
        if (entity.method_5735() == class_2350.field_11036)
            return 255;

        // Darken the photo same way as the block sides darken,
        // but not quite as much and allow light sources to brighten it:
        int lightLevel = entity.method_37908().method_8314(class_1944.field_9282, entity.method_24515());
        float shadeFactor = entity.method_37908().method_24852(entity.method_5735(), true);
        shadeFactor += (1f - shadeFactor) * 0.05f;

        int shadedBrightness = (int)(255 * shadeFactor);
        int missingLight = 255 - shadedBrightness;
        int lightUp = (int)(missingLight * (lightLevel / 15f * 0.7f));
        return Math.min(255, shadedBrightness + lightUp);
    }
}
