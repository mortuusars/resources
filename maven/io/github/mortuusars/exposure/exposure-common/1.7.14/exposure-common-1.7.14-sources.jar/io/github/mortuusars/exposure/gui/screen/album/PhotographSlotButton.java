package io.github.mortuusars.exposure.gui.screen.album;

import com.google.common.collect.Lists;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.render.PhotographRenderProperties;
import io.github.mortuusars.exposure.render.PhotographRenderer;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_289;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_4597;
import net.minecraft.class_765;
import net.minecraft.class_768;
import net.minecraft.class_8494;

public class PhotographSlotButton extends class_344 {

    protected final class_768 exposureArea;
    protected final class_4241 onRightButtonPress;
    protected final Supplier<class_1799> photograph;
    protected final boolean isEditable;
    protected boolean hasPhotograph;

    public PhotographSlotButton(class_768 exposureArea, int x, int y, int width, int height, int xTexStart, int yTexStart,
                                int yDiffTex, class_2960 resourceLocation, int textureWidth, int textureHeight,
                                class_4241 onLeftButtonPress, class_4241 onRightButtonPress, Supplier<class_1799> photographGetter, boolean isEditable) {
        super(x, y, width, height, xTexStart, yTexStart, yDiffTex, resourceLocation, textureWidth, textureHeight, onLeftButtonPress,
                class_2561.method_43471("item.exposure.photograph"));
        this.exposureArea = exposureArea;
        this.onRightButtonPress = onRightButtonPress;
        this.photograph = photographGetter;
        this.isEditable = isEditable;
    }

    public class_1799 getPhotograph() {
        return photograph.get();
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        class_1799 photograph = getPhotograph();

        if (photograph.method_7909() instanceof PhotographItem) {
            hasPhotograph = true;

            PhotographRenderProperties renderProperties = PhotographRenderProperties.get(photograph);

            // Paper
            method_48588(guiGraphics, renderProperties.getAlbumPaperTexture(),
                    method_46426(), method_46427(), 0, 0, 0, field_22758, field_22759, field_22758, field_22759);

            // Exposure
            guiGraphics.method_51448().method_22903();
            float scale = exposureArea.method_3319() / (float) ExposureClient.getExposureRenderer().getSize();
            guiGraphics.method_51448().method_46416(exposureArea.method_3321(), exposureArea.method_3322(), 1);
            guiGraphics.method_51448().method_22905(scale, scale, scale);
            class_4597.class_4598 bufferSource = class_4597.method_22991(class_289.method_1348().method_1349());
            PhotographRenderer.render(photograph, false, false, guiGraphics.method_51448(),
                    bufferSource, class_765.field_32767, 255, 255, 255, 255);
            bufferSource.method_22993();
            guiGraphics.method_51448().method_22909();

            // Paper overlay
            if (renderProperties.hasAlbumPaperOverlayTexture()) {
                guiGraphics.method_51448().method_22903();
                guiGraphics.method_51448().method_46416(0, 0, 2);
                method_48588(guiGraphics, renderProperties.getAlbumPaperOverlayTexture(),
                        method_46426(), method_46427(), 0, 0, 0, field_22758, field_22759, field_22758, field_22759);
                guiGraphics.method_51448().method_22909();
            }
        }
        else {
            hasPhotograph = false;
        }

        // Album pins
        int xTex = field_2126 + (hasPhotograph ? method_25368() : 0);
        method_48588(guiGraphics, field_2127, method_46426(), method_46427(), xTex, field_2125, field_19079, field_22758, field_22759, field_2124, field_19080);
    }

    public void renderTooltip(class_332 guiGraphics, int mouseX, int mouseY) {
        if (isEditable && !hasPhotograph) {
            guiGraphics.method_51438(class_310.method_1551().field_1772,
                    class_2561.method_43471("gui.exposure.album.add_photograph"), mouseX, mouseY);
            return;
        }

        class_1799 photograph = getPhotograph();
        if (photograph.method_7960())
            return;

        List<class_2561> itemTooltip = class_437.method_25408(class_310.method_1551(), photograph);
        itemTooltip.add(class_2561.method_43471("gui.exposure.album.left_click_or_scroll_up_to_view"));
        if (isEditable)
            itemTooltip.add(class_2561.method_43471("gui.exposure.album.right_click_to_remove"));

        // Photograph image in tooltip is not rendered here

        if (method_25370()) {
            guiGraphics.method_51436(class_310.method_1551().field_1772, Lists.transform(itemTooltip,
                    class_2561::method_30937), method_47937(), mouseX, mouseY);
        }
        else
            guiGraphics.method_51437(class_310.method_1551().field_1772, itemTooltip, Optional.empty(), mouseX, mouseY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!this.field_22763 || !this.field_22764 || !method_25361(mouseX, mouseY))
            return false;

        if (button == class_3675.field_32000) {
            this.field_22767.onPress(this);
        } else if (button == class_3675.field_32002) {
            this.onRightButtonPress.onPress(this);
        } else
            return false;

        return true;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta) {
        if (delta > 0 && method_25361(mouseX, mouseY) && hasPhotograph) {
            this.field_22767.onPress(this);
            return true;
        }

        return super.method_25401(mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (this.field_22763 && this.field_22764 && class_437.method_25442() && class_8494.method_51255(keyCode)) {
            onRightButtonPress.onPress(this);
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }
}
