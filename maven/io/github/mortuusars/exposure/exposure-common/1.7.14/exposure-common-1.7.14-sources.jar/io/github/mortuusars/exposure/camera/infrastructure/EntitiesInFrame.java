package io.github.mortuusars.exposure.camera.infrastructure;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.util.Fov;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;

public class EntitiesInFrame {
    public static List<class_1297> get(class_1657 player, double fov, int limit, boolean inSelfieMode) {
        double currentFov = fov / Exposure.CROP_FACTOR;
        double currentFocalLength = Fov.fovToFocalLength(currentFov);
        class_243 cameraPos = class_310.method_1551().field_1773.method_19418().method_19326();

        List<class_1297> entities = player.method_37908().method_8333(player, new class_238(player.method_24515()).method_1014(128),
                entity -> entity instanceof class_1309);

        entities.sort((entity, entity2) -> {
            float dist1 = player.method_5739(entity);
            float dist2 = player.method_5739(entity2);
            if (dist1 == dist2) return 0;
            return dist1 > dist2 ? 1 : -1;
        });

        List<class_1297> entitiesInFrame = new ArrayList<>();

        for (class_1297 entity : entities) {
            if (entitiesInFrame.size() >= limit)
                break;

            if (!isInFOV(currentFov, entity))
                continue; // Not in frame

            if (getPerceivedDistance(cameraPos, entity) > currentFocalLength)
                continue; // Too far to be in frame

            if (!player.method_6057(entity))
                continue; // Not visible

            entitiesInFrame.add(entity);
        }

        if (inSelfieMode)
            entitiesInFrame.add(0, player);

        return entitiesInFrame;
    }

    /**
     * Gets the distance in blocks to the target entity. Perceived == adjusted relative to the size of entity's bounding box.
     */
    public static double getPerceivedDistance(class_243 cameraPos, class_1297 entity) {
        double distanceInBlocks = Math.sqrt(entity.method_5707(cameraPos));

        class_238 boundingBox = entity.method_5830();
        double size = boundingBox.method_995();
        if (Double.isNaN(size) || size == 0.0)
            size = 0.1;

        double sizeModifier = (size - 1.0) * 0.6 + 1.0;
        return (distanceInBlocks / sizeModifier) / Exposure.CROP_FACTOR;
    }

    public static boolean isInFOV(double fov, class_1297 target) {
        class_4184 camera = class_310.method_1551().field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();
        class_243 cameraLookAngle = new class_243(camera.method_19335());
        class_243 targetEyePos = target.method_19538().method_1031(0, target.method_5751(), 0);

        // Valid angles form a circle instead of square.
        // Due to this, entities in the corners of a frame are not considered "in frame".
        // I'm too dumb at maths to fix this.
        
        double relativeAngle = getRelativeAngle(cameraPos, cameraLookAngle, targetEyePos);
        return relativeAngle <= fov / 2f;
    }

    /**
     * L    T (Target)
     * | D /
     * |--/
     * | /
     * |/
     * C (Camera), L (Camera look angle)
     */
    public static double getRelativeAngle(class_243 cameraPos, class_243 cameraLookAngle, class_243 targetEyePos) {
        class_243 originToTargetAngle = targetEyePos.method_1020(cameraPos).method_1029();
        return Math.toDegrees(Math.acos(cameraLookAngle.method_1026(originToTargetAngle)));
    }
}
