package io.github.mortuusars.exposure.recipe;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_2371;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import org.jetbrains.annotations.NotNull;

public class PhotographAgingRecipe extends AbstractNbtTransferringRecipe{
    public PhotographAgingRecipe(class_2960 id, class_1856 transferIngredient,
                                 class_2371<class_1856> ingredients, class_1799 result) {
        super(id, transferIngredient, ingredients, result);
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return Exposure.RecipeSerializers.PHOTOGRAPH_AGING.get();
    }

    public static class Serializer implements class_1865<PhotographAgingRecipe> {
        @Override
        public @NotNull PhotographAgingRecipe method_8121(class_2960 recipeId, JsonObject serializedRecipe) {
            class_1856 photographIngredient = class_1856.method_52177(class_3518.method_52226(serializedRecipe, "photograph"));
            class_2371<class_1856> ingredients = getIngredients(class_3518.method_15261(serializedRecipe, "ingredients"));
            class_1799 result = class_1869.method_35228(class_3518.method_15296(serializedRecipe, "result"));

            if (photographIngredient.method_8103())
                throw new JsonParseException("Recipe should have 'photograph' ingredient.");

            return new PhotographAgingRecipe(recipeId, photographIngredient, ingredients, result);
        }

        @Override
        public @NotNull PhotographAgingRecipe method_8122(class_2960 recipeId, class_2540 buffer) {
            class_1856 transferredIngredient = class_1856.method_8086(buffer);
            int ingredientsCount = buffer.method_10816();
            class_2371<class_1856> ingredients = class_2371.method_10213(ingredientsCount, class_1856.field_9017);
            ingredients.replaceAll(ignored -> class_1856.method_8086(buffer));
            class_1799 result = buffer.method_10819();

            return new PhotographAgingRecipe(recipeId, transferredIngredient, ingredients, result);
        }

        @Override
        public void toNetwork(class_2540 buffer, PhotographAgingRecipe recipe) {
            recipe.getTransferIngredient().method_8088(buffer);
            buffer.method_10804(recipe.method_8117().size());
            for (class_1856 ingredient : recipe.method_8117()) {
                ingredient.method_8088(buffer);
            }
            buffer.method_10793(recipe.getResult());
        }

        private class_2371<class_1856> getIngredients(JsonArray jsonArray) {
            class_2371<class_1856> ingredients = class_2371.method_10211();

            for (int i = 0; i < jsonArray.size(); ++i) {
                class_1856 ingredient = class_1856.method_52177(jsonArray.get(i));
                if (!ingredient.method_8103())
                    ingredients.add(ingredient);
            }

            if (ingredients.isEmpty())
                throw new JsonParseException("No ingredients for a recipe.");
            else if (ingredients.size() > 3 * 3)
                throw new JsonParseException("Too many ingredients for a recipe. The maximum is 9.");
            return ingredients;
        }
    }
}
