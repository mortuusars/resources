package io.github.mortuusars.exposure.gui.screen;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Either;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.camera.infrastructure.FrameData;
import io.github.mortuusars.exposure.data.storage.ClientsideExposureExporter;
import io.github.mortuusars.exposure.gui.screen.element.Pager;
import io.github.mortuusars.exposure.item.PhotographItem;
import io.github.mortuusars.exposure.render.PhotographRenderProperties;
import io.github.mortuusars.exposure.render.PhotographRenderer;
import io.github.mortuusars.exposure.util.ClientsideWorldNameGetter;
import io.github.mortuusars.exposure.util.ItemAndStack;
import io.github.mortuusars.exposure.util.PagingDirection;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_289;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_4597;
import net.minecraft.class_746;
import net.minecraft.class_765;

public class PhotographScreen extends ZoomableScreen {
    public static final class_2960 WIDGETS_TEXTURE = Exposure.resource("textures/gui/widgets.png");

    private final List<ItemAndStack<PhotographItem>> photographs;
    private final List<String> savedExposures = new ArrayList<>();

    private final Pager pager = new Pager(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get());

    public PhotographScreen(List<ItemAndStack<PhotographItem>> photographs) {
        super(class_2561.method_43473());
        Preconditions.checkState(!photographs.isEmpty(), "No photographs to display.");
        this.photographs = photographs;

        if (shouldQueryAllPhotographsImmediately()) {
            queryAllPhotographs(photographs);
        }
    }

    protected boolean shouldQueryAllPhotographsImmediately() {
        return true;
    }

    protected void queryAllPhotographs(List<ItemAndStack<PhotographItem>> photographs) {
        for (ItemAndStack<PhotographItem> photograph : photographs) {
            FrameData.getIdOrTexture(photograph.getStack())
                    .left()
                    .ifPresent(id -> {
                        if (!id.isBlank()) {
                            ExposureClient.getExposureStorage().getOrQuery(id);
                        }
                    });
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        zoomFactor = (float) field_22790 / ExposureClient.getExposureRenderer().getSize();

        class_344 previousButton = new class_344(0, (int) (field_22790 / 2f - 16 / 2f), 16, 16,
                0, 0, 16, WIDGETS_TEXTURE, 256, 256,
                button -> pager.changePage(PagingDirection.PREVIOUS), class_2561.method_43471("gui.exposure.previous_page"));
        method_37063(previousButton);

        class_344 nextButton = new class_344(field_22789 - 16, (int) (field_22790 / 2f - 16 / 2f), 16, 16,
                16, 0, 16, WIDGETS_TEXTURE, 256, 256,
                button -> pager.changePage(PagingDirection.NEXT), class_2561.method_43471("gui.exposure.next_page"));
        method_37063(nextButton);

        pager.init(photographs.size(), true, previousButton, nextButton);
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        pager.update();

        method_25420(guiGraphics);

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(0, 0, 500); // Otherwise exposure will overlap buttons
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        guiGraphics.method_51448().method_22909();

        guiGraphics.method_51448().method_22903();

        guiGraphics.method_51448().method_46416(x, y, 0);
        guiGraphics.method_51448().method_46416(field_22789 / 2f, field_22790 / 2f, 0);
        guiGraphics.method_51448().method_22905(scale, scale, scale);
        guiGraphics.method_51448().method_46416(ExposureClient.getExposureRenderer().getSize() / -2f, ExposureClient.getExposureRenderer().getSize() / -2f, 0);

        class_4597.class_4598 bufferSource = class_4597.method_22991(class_289.method_1348().method_1349());

        ArrayList<ItemAndStack<PhotographItem>> photos = new ArrayList<>(photographs);
        Collections.rotate(photos, -pager.getCurrentPage());
        PhotographRenderer.renderStackedPhotographs(photos, guiGraphics.method_51448(), bufferSource, class_765.field_32767, 255, 255, 255, 255);

        bufferSource.method_22993();

        guiGraphics.method_51448().method_22909();

        ItemAndStack<PhotographItem> photograph = photographs.get(pager.getCurrentPage());

        if (field_22787.field_1724 != null && field_22787.field_1724.method_7337() && FrameData.hasIdOrTexture(photograph.getStack())) {
            guiGraphics.method_25303(field_22793, "?", field_22789 - field_22793.method_1727("?") - 10, 10, 0xFFFFFFFF);

            if (mouseX > field_22789 - 20 && mouseX < field_22789 && mouseY < 20) {
                Either<String, class_2960> idOrTexture = FrameData.getIdOrTexture(photograph.getStack());

                List<class_2561> lines = new ArrayList<>();

                String exposureName = idOrTexture.map(id -> id, class_2960::toString);
                lines.add(class_2561.method_43470(exposureName));

                lines.add(class_2561.method_43469("gui.exposure.photograph_screen.drop_as_item_tooltip", class_2561.method_43470("CTRL + I")));

                lines.add(idOrTexture.map(
                        id -> class_2561.method_43469("gui.exposure.photograph_screen.copy_id_tooltip", "CTRL + C"),
                        texture -> class_2561.method_43469("gui.exposure.photograph_screen.copy_texture_path_tooltip", "CTRL + C")));

                guiGraphics.method_51437(field_22793, lines, Optional.empty(), mouseX, mouseY + 20);
            }
        }

        if (Config.Client.SAVE_EXPOSURE_TO_FILE_WHEN_VIEWED.get())
            trySaveToFile(photograph);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        class_746 player = class_310.method_1551().field_1724;
        ItemAndStack<PhotographItem> photograph = photographs.get(pager.getCurrentPage());
        if (class_437.method_25441() && player != null && player.method_7337() && FrameData.hasIdOrTexture(photograph.getStack())) {
            if (keyCode == class_3675.field_32017) {
                Either<String, class_2960> idOrTexture = FrameData.getIdOrTexture(photograph.getStack());
                String text = idOrTexture.map(id -> id, class_2960::toString);
                class_310.method_1551().field_1774.method_1455(text);
                player.method_7353(class_2561.method_43469("gui.exposure.photograph_screen.copied_message", text), false);
                return true;
            }

            if (keyCode == class_3675.field_32023) {
                if (class_310.method_1551().field_1761 != null) {
                    class_310.method_1551().field_1761.method_2915(photograph.getStack().method_7972());
                    player.method_7353(class_2561.method_43469("gui.exposure.photograph_screen.item_dropped_message",
                            photograph.getStack().toString()), false);
                }
                return true;
            }
        }

        return pager.handleKeyPressed(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        return pager.handleKeyReleased(keyCode, scanCode, modifiers) || super.method_16803(keyCode, scanCode, modifiers);
    }

    private void trySaveToFile(ItemAndStack<PhotographItem> photograph) {
        if (class_310.method_1551().field_1724 == null || photograph.getStack().method_7969() == null)
            return;

        class_2487 tag = photograph.getStack().method_7969();
        if (tag == null
                || class_310.method_1551().field_1724 == null
                || !tag.method_10573(FrameData.PHOTOGRAPHER_ID, class_2520.field_33261)
                || !tag.method_25926(FrameData.PHOTOGRAPHER_ID).equals(class_310.method_1551().field_1724.method_5667())) {
            return;
        }

        FrameData.getIdOrTexture(photograph.getStack()).left().ifPresent(id -> {
            if (id.isBlank()) {
                return;
            }

            PhotographRenderProperties properties = PhotographRenderProperties.get(photograph.getStack());
            String filename = properties != PhotographRenderProperties.DEFAULT ? id + "_" + properties.getId() : id;

            if (savedExposures.contains(filename))
                return;

            ExposureClient.getExposureStorage().getOrQuery(id).ifPresent(exposure -> {
                savedExposures.add(filename);

                new Thread(() -> new ClientsideExposureExporter(filename)
                        .withDefaultFolder()
                        .organizeByWorld(Config.Client.EXPOSURE_SAVING_LEVEL_SUBFOLDER.get(), ClientsideWorldNameGetter::getWorldName)
                        .withModifier(properties.getModifier())
                        .withSize(Config.Client.EXPOSURE_SAVING_SIZE.get())
                        .save(exposure), "ExposureSaving").start();
            });
        });
    }
}
