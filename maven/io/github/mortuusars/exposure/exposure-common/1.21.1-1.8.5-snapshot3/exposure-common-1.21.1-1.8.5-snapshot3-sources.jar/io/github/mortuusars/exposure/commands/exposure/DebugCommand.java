package io.github.mortuusars.exposure.commands.exposure;

import com.google.common.base.Preconditions;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.client.util.bugger.Bugger;
import io.github.mortuusars.exposure.util.PointOfView;
import io.github.mortuusars.exposure.world.camera.*;
import io.github.mortuusars.exposure.world.camera.capture.CaptureProperties;
import io.github.mortuusars.exposure.world.camera.capture.CaptureType;
import io.github.mortuusars.exposure.world.camera.frame.EntitiesInFrame;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.item.camera.CameraSettings;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.world.camera.frame.Photographer;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.item.*;
import io.github.mortuusars.exposure.world.item.camera.Attachment;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.clientbound.ClearRenderingCacheS2CP;
import io.github.mortuusars.exposure.network.packet.clientbound.CaptureStartDebugRGBS2CP;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.network.chat.*;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class DebugCommand {
    public static LiteralArgumentBuilder<class_2168> get() {
        return class_2170.method_9247("debug")
                .then(class_2170.method_9247("clear_rendering_cache")
                        .executes(DebugCommand::clearRenderingCache))
                .then(class_2170.method_9247("highlight_entities_in_frame")
                        .executes(DebugCommand::highlightEntitiesInFrame))
                .then(class_2170.method_9247("expose_rgb")
                        .executes(DebugCommand::exposeRGB))
                .then(class_2170.method_9247("chromatic_from_last_three_exposures")
                        .executes(DebugCommand::chromaticFromLastThreeExposures))
                .then(class_2170.method_9247("develop_film_in_hand")
                        .executes(context -> developFilmInHand(context, true))
                        .then(class_2170.method_9247("keep_original")
                                .executes(context -> developFilmInHand(context, false))));
    }

    private static int clearRenderingCache(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_2168 stack = context.getSource();
        class_3222 player = stack.method_9207();
        Packets.sendToClient(ClearRenderingCacheS2CP.INSTANCE, player);
        return 0;
    }

    private static int highlightEntitiesInFrame(CommandContext<class_2168> context) {
        ExposureServer.debugHighlightEntitiesInFrame = !ExposureServer.debugHighlightEntitiesInFrame;
        context.getSource().method_45068(class_2561.method_43471("system.exposure.debug.highlight_entities_in_frame." +
                (ExposureServer.debugHighlightEntitiesInFrame ? "on" : "off")).method_27692(class_124.field_1061));
        return 0;
    }

    private static int exposeRGB(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_2168 stack = context.getSource();
        class_3222 player = stack.method_9207();

        @Nullable Camera camera = CameraInHand.find(player);
        if (camera == null) {
            camera = new CameraInHand(player, new CameraId(class_156.field_25140), class_1268.field_5808);
        }


        List<CaptureProperties> properties = new ArrayList<>();

        for (int i = 0; i < 3; i++) {
            ColorChannel channel = ColorChannel.values()[i];
            String exposureId = ExposureIdentifier.createId(player, channel.method_15434());

            class_5321<ColorPalette> paletteKey = camera.mapAttachment(Attachment.FILM, FilmItem::getColorPaletteId).orElse(ColorPalettes.DEFAULT);
            class_6880<ColorPalette> colorPalette = ColorPalettes.get(context.getSource().method_30497(), paletteKey);

            CaptureProperties captureProperties = new CaptureProperties.Builder(exposureId)
                    .setCameraHolder(player)
                    .setCameraID(camera.getId().uuid().equals(class_156.field_25140) ? null : camera.getId())
                    .setShutterSpeed(CameraSettings.SHUTTER_SPEED.getOrElse(camera, null))
                    .setFilmType(ExposureType.BLACK_AND_WHITE)
                    .setFrameSize(camera.mapAttachment(Attachment.FILM, FilmItem::getFrameSize).orElse(null))
                    .setCropFactor(camera.map((cameraItem, cameraStack) -> cameraItem.getCropFactor()).orElse(1f))
                    .setColorPalette(colorPalette)
                    .setChromaticChannel(channel)
                    .build();

            properties.add(captureProperties);

            Frame frame = camera
                    .map((cameraItem, cameraStack) -> {
                        PointOfView pov = cameraItem.getPointOfView(player, cameraStack);
                        float fov = cameraItem.getFov(player.method_37908(), cameraStack);
                        List<class_2338> positions = cameraItem.getPositionsInFrame(player, pov, fov);
                        List<class_1309> entities = EntitiesInFrame.get((CameraHolder) player, pov, fov);
                        return cameraItem.createFrame(player, context.getSource().method_9225(), cameraStack, captureProperties, positions,entities);
                    })
                    .orElse(Frame.create().setIdentifier(ExposureIdentifier.id(exposureId))
                            .setType(ExposureType.BLACK_AND_WHITE)
                            .setPhotographer(new Photographer(player))
                            .toImmutable());

            Supplier<class_2561> msg = () -> {
                class_1799 photograph = new class_1799(Exposure.Items.PHOTOGRAPH.get());
                photograph.method_57379(Exposure.DataComponents.PHOTOGRAPH_FRAME, frame);
                return class_2561.method_43470("Captured " + channel.method_15434() + " channel exposure: ")
                        .method_10852(class_2561.method_43470(exposureId)
                                .method_27696(class_2583.field_24360
                                        .method_10958(new class_2558(class_2558.class_2559.field_11750,
                                                "/exposure show id " + exposureId))
                                        .method_10949(new class_2568(class_2568.class_5247.field_24343, new class_2568.class_5249(photograph)))
                                        .method_30938(true)));
            };

            ExposureServer.exposureRepository().expect(player, exposureId, (pl, id) -> context.getSource().method_9226(msg, true));
            ExposureServer.frameHistory().add(player, frame);
        }

        Packets.sendToClient(new CaptureStartDebugRGBS2CP(CaptureType.DEBUG_RGB, properties), player);

        context.getSource().method_9226(() -> class_2561.method_43470("Capturing RGB channels..."), true);

        return 0;
    }

    private static int chromaticFromLastThreeExposures(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_2168 stack = context.getSource();
        class_3222 player = stack.method_9207();

        List<Frame> allFrames = ExposureServer.frameHistory().getFramesOf(player)
                .stream()
                .filter(frame -> !frame.isChromatic())
                .toList();
        List<Frame> frames = new ArrayList<>(allFrames.subList(Math.max(allFrames.size() - 3, 0), allFrames.size()));

        if (frames.size() < 3) {
            stack.method_9213(class_2561.method_43470("Not enough frames captured. 3 is required."));
            return 1;
        }

        try {
            ChromaticSheetItem item = Exposure.Items.CHROMATIC_SHEET.get();
            class_1799 itemStack = new class_1799(item);

            for (Frame frame : frames) {
                item.addLayer(itemStack, frame);
            }

            class_1799 photographStack = item.combineIntoPhotograph(player, itemStack, false);
            @Nullable Frame frame = photographStack.method_57824(Exposure.DataComponents.PHOTOGRAPH_FRAME);
            Preconditions.checkState(frame != null, "Frame data cannot be empty after combining.");

            ExposureServer.frameHistory().add(player, frame);

            Supplier<class_2561> msg = () -> {
                String exposureId = frame.identifier().getId().orElseThrow();
                return class_2561.method_43470("Created chromatic exposure: ")
                        .method_10852(class_2561.method_43470(exposureId)
                                .method_27696(class_2583.field_24360
                                        .method_10958(new class_2558(class_2558.class_2559.field_11750,
                                                "/exposure show latest"))
                                        .method_10949(new class_2568(class_2568.class_5247.field_24343, new class_2568.class_5249(photographStack)))
                                        .method_30938(true)));
            };

            stack.method_9226(msg, true);
        } catch (Exception e) {
            stack.method_9213(class_2561.method_43470("Failed to create chromatic exposure: " + e));
            return 1;
        }

        return 0;
    }

    private static int developFilmInHand(CommandContext<class_2168> context, boolean replace) throws CommandSyntaxException {
        class_2168 stack = context.getSource();
        class_3222 player = stack.method_9207();

        for (class_1268 hand : class_1268.values()) {
            class_1799 itemInHand = player.method_5998(hand);
            if (itemInHand.method_7909() instanceof FilmRollItem filmRollItem) {
                DevelopedFilmItem itemType = filmRollItem.getType() == ExposureType.COLOR
                        ? Exposure.Items.DEVELOPED_COLOR_FILM.get()
                        : Exposure.Items.DEVELOPED_BLACK_AND_WHITE_FILM.get();
                class_1799 developedFilmStack = itemInHand.method_60503(itemType);

                if (replace) {
                    player.method_6122(hand, developedFilmStack);
                } else if (!player.method_7270(developedFilmStack)) {
                    player.method_7329(developedFilmStack, true, false);
                }

                stack.method_9226(() -> class_2561.method_43469("command.exposure.debug.develop.success",
                        itemInHand.method_7954()), true);
                return 0;
            }
        }

        stack.method_9213(class_2561.method_43471("command.exposure.debug.develop.fail.wrong_item"));
        return 1;
    }
}
