package io.github.mortuusars.exposure;

import io.github.mortuusars.exposure.client.animation.CameraModelPoses;
import io.github.mortuusars.exposure.client.animation.CameraPoses;
import io.github.mortuusars.exposure.client.capture.template.*;
import io.github.mortuusars.exposure.client.task.ClearStaleRenderedImagesIndefiniteTask;
import io.github.mortuusars.exposure.client.RenderedExposures;
import io.github.mortuusars.exposure.client.camera.viewfinder.*;
import io.github.mortuusars.exposure.client.image.modifier.ImageModifier;
import io.github.mortuusars.exposure.client.render.image.ImageRenderer;
import io.github.mortuusars.exposure.client.render.photograph.PhotographStyle;
import io.github.mortuusars.exposure.client.render.photograph.PhotographRenderer;
import io.github.mortuusars.exposure.client.render.photograph.PhotographStyles;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.camera.capture.CaptureType;
import io.github.mortuusars.exposure.world.photograph.PhotographType;
import net.minecraft.class_1091;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_9334;
import io.github.mortuusars.exposure.util.cycles.Cycles;
import io.github.mortuusars.exposure.client.ExposureStore;
import io.github.mortuusars.exposure.world.item.AlbumItem;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import io.github.mortuusars.exposure.world.item.ChromaticSheetItem;
import io.github.mortuusars.exposure.world.item.StackedPhotographsItem;

public class ExposureClient {
    private static final Cycles CYCLES = new Cycles();
    private static final ExposureStore EXPOSURE_STORE = new ExposureStore();
    private static final RenderedExposures RENDERED_EXPOSURES = new RenderedExposures();
    private static final ImageRenderer IMAGE_RENDERER = new ImageRenderer();
    private static final PhotographRenderer PHOTOGRAPH_RENDERER = new PhotographRenderer();

    private static boolean isIrisOrOculusInstalled;

    public static void init() {
        CameraModelPoses.register(Exposure.Items.CAMERA.get(), new CameraPoses());

        ViewfinderRegistry.register(Exposure.Items.CAMERA.get(), Viewfinder::new);

        CaptureTemplates.register(CaptureType.CAMERA, new CameraCaptureTemplate());
        CaptureTemplates.register(CaptureType.EXPOSE_COMMAND, new ExposeCaptureTemplate());
        CaptureTemplates.register(CaptureType.LOAD_COMMAND, new PathCaptureTemplate());
        CaptureTemplates.register(CaptureType.DEBUG_RGB, new SingleChannelCaptureTemplate());

        PhotographStyles.register(PhotographType.REGULAR, PhotographStyle.REGULAR);
        PhotographStyles.register(PhotographType.AGED, new PhotographStyle(
                ExposureClient.Textures.Photograph.AGED_PAPER,
                ExposureClient.Textures.Photograph.AGED_OVERLAY,
                ExposureClient.Textures.Photograph.AGED_ALBUM_PAPER,
                ExposureClient.Textures.Photograph.AGED_ALBUM_OVERLAY,
                ImageModifier.AGED));

        cycles().addParallelTask(new ClearStaleRenderedImagesIndefiniteTask());

        registerItemModelProperties();
        isIrisOrOculusInstalled = PlatformHelper.isModLoaded("iris") || PlatformHelper.isModLoaded("oculus");
    }

    public static Cycles cycles() {
        return CYCLES;
    }

    public static ExposureStore exposureStore() {
        return EXPOSURE_STORE;
    }

    public static RenderedExposures renderedExposures() {
        return RENDERED_EXPOSURES;
    }

    public static ImageRenderer imageRenderer() {
        return IMAGE_RENDERER;
    }

    public static PhotographRenderer photographRenderer() {
        return PHOTOGRAPH_RENDERER;
    }

    // --

    public static boolean shouldUseDirectCapture() {
        return isIrisOrOculusInstalled;
    }

    // --

    private static void registerItemModelProperties() {
        class_5272.method_27879(Exposure.Items.CAMERA.get(), Exposure.resource("camera_state"), (stack, level, entity, seed) -> {
            if (!(stack.method_7909() instanceof CameraItem cameraItem) || !cameraItem.isActive(stack)) {
                return 0f;
            }

            if (cameraItem.isInSelfieMode(stack)) {
                // Longer selfie stick for current player (to not obscure the view) and regular for everyone else
                return entity == Minecrft.player() ? 0.2f : 0.3f;
            }

            return 0.1f;
        });
        class_5272.method_27879(Exposure.Items.CHROMATIC_SHEET.get(), Exposure.resource("channels"), (stack, clientLevel, livingEntity, seed) ->
                stack.method_7909() instanceof ChromaticSheetItem chromaticSheet ?
                        chromaticSheet.getLayers(stack).size() / 10f : 0f);
        class_5272.method_27879(Exposure.Items.STACKED_PHOTOGRAPHS.get(), Exposure.resource("count"),
                (stack, clientLevel, livingEntity, seed) ->
                        stack.method_7909() instanceof StackedPhotographsItem stackedPhotographsItem ?
                                stackedPhotographsItem.getPhotographs(stack).size() / 100f : 0f);
        class_5272.method_27879(Exposure.Items.ALBUM.get(), Exposure.resource("photos"),
                (stack, clientLevel, livingEntity, seed) ->
                        stack.method_7909() instanceof AlbumItem albumItem ? albumItem.getPhotographsCount(stack) / 100f : 0f);
        class_5272.method_27879(Exposure.Items.INTERPLANAR_PROJECTOR.get(), Exposure.resource("projector_active"),
                (stack, clientLevel, livingEntity, seed) -> Config.Server.CAN_PROJECT.get() && stack.method_57826(class_9334.field_49631) ? 1f : 0f);
    }

    public static class Models {
        public static final class_1091 CAMERA_GUI =
                new class_1091(Exposure.resource("camera_gui"), "standalone");
        public static final class_1091 PHOTOGRAPH_FRAME_SMALL =
                new class_1091(Exposure.resource("photograph_frame_small"), "standalone");
        public static final class_1091 PHOTOGRAPH_FRAME_MEDIUM =
                new class_1091(Exposure.resource("photograph_frame_medium"), "standalone");
        public static final class_1091 PHOTOGRAPH_FRAME_LARGE =
                new class_1091(Exposure.resource("photograph_frame_large"), "standalone");
        public static final class_1091 CLEAR_PHOTOGRAPH_FRAME_SMALL =
                new class_1091(Exposure.resource("glass_photograph_frame_small"), "standalone");
        public static final class_1091 CLEAR_PHOTOGRAPH_FRAME_MEDIUM =
                new class_1091(Exposure.resource("glass_photograph_frame_medium"), "standalone");
        public static final class_1091 CLEAR_PHOTOGRAPH_FRAME_LARGE =
                new class_1091(Exposure.resource("glass_photograph_frame_large"), "standalone");
    }

    public static class Textures {
        public static final class_2960 EMPTY = Exposure.resource("textures/empty.png");

        public static class Photograph {
            public static final class_2960 REGULAR_PAPER = Exposure.resource("textures/photograph/photograph.png");
            public static final class_2960 REGULAR_ALBUM_PAPER = Exposure.resource("textures/photograph/photograph_album.png");

            public static final class_2960 AGED_PAPER = Exposure.resource("textures/photograph/aged_photograph.png");
            public static final class_2960 AGED_OVERLAY = Exposure.resource("textures/photograph/aged_photograph_overlay.png");
            public static final class_2960 AGED_ALBUM_PAPER = Exposure.resource("textures/photograph/aged_photograph_album.png");
            public static final class_2960 AGED_ALBUM_OVERLAY = Exposure.resource("textures/photograph/aged_photograph_album_overlay.png");
        }
    }
}
