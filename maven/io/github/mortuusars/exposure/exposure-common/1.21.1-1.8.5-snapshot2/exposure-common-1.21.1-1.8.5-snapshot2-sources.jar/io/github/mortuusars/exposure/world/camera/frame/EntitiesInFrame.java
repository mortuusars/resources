package io.github.mortuusars.exposure.world.camera.frame;

import io.github.mortuusars.exposure.util.Fov;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;

public class EntitiesInFrame {
    public static List<class_1309> get(class_1297 photographer, double fov, boolean inSelfieMode) {
        class_243 cameraPos = photographer.method_19538().method_1031(0, photographer.method_5751(), 0);
        class_243 cameraDirection = class_243.method_1030(photographer.method_36455(), photographer.method_36454());

        if (inSelfieMode) {
            cameraDirection = cameraDirection.method_22882();
            float maxDistance = 1.75F;  // This is a default value (used in CameraMixin) for client camera when in selfie mode.
            float maxCameraDistance = getMaxCameraDistance(photographer, cameraPos, cameraDirection, maxDistance);
            cameraPos = cameraPos.method_1019(cameraDirection.method_1029().method_1021(-maxCameraDistance));
        }

        return get(photographer, cameraPos, cameraDirection, fov);
    }

    public static List<class_1309> get(class_1297 photographer, class_243 cameraPos, class_243 cameraDirection, double fov) {
        double focalLength = Fov.fovToFocalLength(fov);

        class_238 area = new class_238(photographer.method_24515()).method_1014(128);
        List<class_1297> entities = photographer.method_37908().method_8335(null, area);

        FrustumCheck frustum = FrustumCheck.createFromCamera(cameraPos, cameraDirection, ((float) Math.toRadians(fov)));

        entities.sort((entity, entity2) -> {
            float dist1 = photographer.method_5739(entity);
            float dist2 = photographer.method_5739(entity2);
            if (dist1 == dist2) return 0;
            return dist1 > dist2 ? 1 : -1;
        });

        List<class_1309> entitiesInFrame = new ArrayList<>();

        for (class_1297 entity : entities) {
            if (!(entity instanceof class_1309 livingEntity)) continue;
            if (!livingEntity.method_5805()) continue;
            if (!frustum.contains(entity.method_33571())) continue; // Not in frame
            if (calculateVisibleDistance(cameraPos, entity) > focalLength) continue; // Too far to be in frame
            if (!hasLineOfSight(cameraPos, entity)) continue; // Not visible

            entitiesInFrame.add(livingEntity);
        }

        return entitiesInFrame;
    }

    /**
     * This method is same as {@link net.minecraft.class_4184}#getMaxZoom.
     * We need it to calculate proper camera position if camera is in third-person mode, so it does not clip into blocks.
     */
    public static float getMaxCameraDistance(class_1297 photographer, class_243 position, class_243 direction, float maxDistance) {
        for (int i = 0; i < 8; i++) {
            float xOff = (float) ((i & 1) * 2 - 1);
            float yOff = (float) ((i >> 1 & 1) * 2 - 1);
            float zOff = (float) ((i >> 2 & 1) * 2 - 1);
            class_243 pos = position.method_1031(xOff * 0.1F, yOff * 0.1F, zOff * 0.1F);
            class_243 endPos = pos.method_1019(direction.method_1021(-maxDistance));
            class_239 hitResult = photographer.method_37908().method_17742(
                    new class_3959(pos, endPos, class_3959.class_3960.field_23142, class_3959.class_242.field_1348, photographer));
            if (hitResult.method_17783() != class_239.class_240.field_1333) {
                float distanceSqr = (float) hitResult.method_17784().method_1025(position);
                if (distanceSqr < class_3532.method_27285(maxDistance)) {
                    maxDistance = class_3532.method_15355(distanceSqr);
                }
            }
        }

        return maxDistance;
    }

    /**
     * Gets the distance in blocks to the target entity.
     */
    public static double calculateVisibleDistance(class_243 cameraPos, class_1297 entity) {
        double distanceInBlocks = Math.sqrt(entity.method_5707(cameraPos));

        class_238 boundingBox = entity.method_5830();
        double size = boundingBox.method_995();
        if (Double.isNaN(size) || size == 0.0)
            size = 0.1;

        double sizeInfluence = (size - 1.0) * 0.6 + 1.0;
        // Makes distance longer, so entity would need to be closer to be "in frame". Very sophisticated math right here.
        double feelsRightInfluence = 1.15;
        return (distanceInBlocks / sizeInfluence) * feelsRightInfluence;
    }

    /**
     * Adaptation of {@link class_1309#method_6057(class_1297)} but using custom camera position instead of an entity.
     */
    public static boolean hasLineOfSight(class_243 cameraPos, class_1297 entity) {
        return entity.method_37908().method_17742(new class_3959(cameraPos, entity.method_33571(),
                class_3959.class_3960.field_17558, class_3959.class_242.field_1348, entity)).method_17783() == class_239.class_240.field_1333;
    }

    /**
     * ChatGPT did a good job with this one.
     */
    public static class FrustumCheck {
        private final class_243 cameraPos;
        private final class_243 forward;
        private final class_243 right;
        private final class_243 up;
        private final float fovRadians;

        public FrustumCheck(class_243 cameraPos, class_243 forward, class_243 right, class_243 up, float fovRadians) {
            this.cameraPos = cameraPos;
            this.forward = forward.method_1029();
            this.right = right.method_1029();
            this.up = up.method_1029();
            this.fovRadians = fovRadians;
        }

        public boolean contains(class_243 pos) {
            // Calculate relative position
            class_243 toEntity = pos.method_1020(cameraPos);

            // Dot product with forward vector for depth
            double depth = toEntity.method_1026(forward);
            if (depth <= 0) {
                // Entity is behind the camera
                return false;
            }

            // Dot product with right and up vectors
            double horizontalOffset = toEntity.method_1026(right);
            double verticalOffset = toEntity.method_1026(up);

            double halfSize = depth * Math.tan(fovRadians / 2);

            // Check if the entity is within the frustum bounds
            return Math.abs(horizontalOffset) <= halfSize && Math.abs(verticalOffset) <= halfSize;
        }

        public static FrustumCheck createFromCamera(class_243 cameraPos, class_243 lookVec, float fov) {
            // Create forward vector (normalized)
            class_243 forward = lookVec.method_1029();

            // Create up vector (assume Y-up world). You may replace this with actual camera up vector if available.
            class_243 worldUp = new class_243(0, 1, 0);

            // Calculate right and adjusted up vectors
            class_243 right = forward.method_1036(worldUp).method_1029();
            class_243 up = right.method_1036(forward).method_1029();

            return new FrustumCheck(cameraPos, forward, right, up, fov);
        }
    }
}
