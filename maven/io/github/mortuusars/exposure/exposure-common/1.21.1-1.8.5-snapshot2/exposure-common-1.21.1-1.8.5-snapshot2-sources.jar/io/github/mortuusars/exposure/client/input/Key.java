package io.github.mortuusars.exposure.client.input;

import java.util.function.Supplier;
import net.minecraft.class_304;
import net.minecraft.class_3675;

@FunctionalInterface
public interface Key {
    boolean matches(int keyCode, int scanCode, int action, int modifiers);

    default Key or(Key matcher) {
        return (key, code, action, mods) -> this.matches(key, code, action, mods) || matcher.matches(key, code, action, mods);
    }

    default KeyBinding executes(Supplier<Boolean> handler) {
        return new KeyBinding(this, handler);
    }

    default KeyBinding executes(Runnable runnable) {
        return new KeyBinding(this, () -> {
            runnable.run();
            return true;
        });
    }

    static boolean actionMatches(int definedAction, int action) {
        if (definedAction == 1 || definedAction == 2) {
            return action == 1 || action == 2;
        }
        return definedAction == action;
    }

    // --

    static Key press(int keyCode) {
        return press(Modifier.NONE, keyCode);
    }

    static Key release(int keyCode) {
        return release(Modifier.NONE, keyCode);
    }

    static Key press(int modifiers, int keyCode) {
        return (key, code, action, mods) -> Key.actionMatches(class_3675.field_31997, action)
                && keyCode == key && mods == modifiers;
    }

    static Key release(int modifiers, int keyCode) {
        return (key, code, action, mods) -> Key.actionMatches(class_3675.field_31998, action)
                && keyCode == key && mods == modifiers;
    }

    static Key press(class_304 keyMapping) {
        return (key, code, action, mods) -> Key.actionMatches(class_3675.field_31997, action)
                && keyMapping.method_1417(key, code) && mods == 0;
    }

    static Key release(class_304 keyMapping) {
        return (key, code, action, mods) -> Key.actionMatches(class_3675.field_31998, action)
                && keyMapping.method_1417(key, code) && mods == 0;
    }
}
