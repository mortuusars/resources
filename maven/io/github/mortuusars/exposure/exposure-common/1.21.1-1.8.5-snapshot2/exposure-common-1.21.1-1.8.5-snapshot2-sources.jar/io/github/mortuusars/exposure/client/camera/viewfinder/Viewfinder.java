package io.github.mortuusars.exposure.client.camera.viewfinder;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.client.camera.CameraClient;
import io.github.mortuusars.exposure.client.input.KeyboardHandler;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_5498;

public class Viewfinder {
    protected final Camera camera;
    protected final ViewfinderZoom zoom;
    protected final ViewfinderOverlay overlay;
    protected final ViewfinderShader shader;
    protected final ComponentConstructor<ViewfinderCameraControlsScreen> controlsScreenConstructor;

    protected @Nullable ViewfinderCameraControlsScreen controlsScreen;

    public Viewfinder(Camera camera,
                      ComponentConstructor<ViewfinderZoom> zoom,
                      ComponentConstructor<ViewfinderOverlay> overlay,
                      ComponentConstructor<ViewfinderShader> shader,
                      ComponentConstructor<ViewfinderCameraControlsScreen> controlsScreen) {
        this.camera = camera;
        this.zoom = zoom.construct(camera, this);
        this.overlay = overlay.construct(camera, this);
        this.shader = shader.construct(camera, this);
        this.controlsScreenConstructor = controlsScreen;
    }

    public Camera camera() {
        return camera;
    }

    public ViewfinderZoom zoom() {
        return zoom;
    }

    public ViewfinderOverlay overlay() {
        return overlay;
    }

    public ViewfinderShader shader() {
        return shader;
    }

    public Optional<ViewfinderCameraControlsScreen> getControlsScreen() {
        return Optional.ofNullable(controlsScreen);
    }

    public void tick() {
        shader().update();
        shader().setActive(isLookingThrough());
    }

    public boolean isLookingThrough() {
        class_5498 cameraType = Minecrft.options().method_31044();
        return cameraType == class_5498.field_26664 || cameraType == class_5498.field_26666;
    }

    public boolean canAttack() {
        return Config.Server.CAMERA_VIEWFINDER_ATTACK.get()
                && !camera.map(CameraItem::isInSelfieMode).orElse(false); // Attacking in selfie mode has weird anim.
    }

    public float getCameraYOffset() {
        return Config.Client.WAIST_LEVEL_VIEWFINDER.get() && camera.getHolder().asEntity() instanceof class_1657 ? -0.35F : 0F;
    }

    public void openControlsScreen() {
        Preconditions.checkNotNull(camera, "No active camera");
        controlsScreen = controlsScreenConstructor.construct(camera, this);
        Minecrft.get().method_1507(controlsScreen);
    }

    public void close() {
        if (shader != null) {
            shader.close();
        }

        if (Minecrft.get().field_1755 instanceof ViewfinderCameraControlsScreen) {
            Minecrft.get().method_1507(null);
        }
    }

    public float getMaxSelfieCameraDistance() {
        return 1.75f;
    }

    public boolean keyPressed(int key, int scanCode, int action) {
        if (!canAttack() && Minecrft.options().field_1886.method_1417(key, scanCode)) {
            return true;
        }

        if (Minecrft.options().field_1824.method_1417(key, scanCode)) {
            if (action == class_3675.field_31997)
                return true;

            class_5498 currentCameraType = Minecrft.options().method_31044();
            class_5498 newCameraType = currentCameraType == class_5498.field_26664 ? class_5498.field_26666
                    : class_5498.field_26664;

            Minecrft.options().method_31043(newCameraType);
            CameraClient.updateSelfieMode();
            return true;
        }

        if (key == class_3675.field_31958 || Minecrft.options().field_1822.method_1417(key, scanCode)) {
            if (action == class_3675.field_31997) {
                if (Minecrft.get().field_1755 instanceof ViewfinderCameraControlsScreen viewfinderControlsScreen) {
                    viewfinderControlsScreen.method_25419();
                } else {
                    CameraClient.deactivate();
                    close();
                }
            }
            return true;
        }

        if (!isLookingThrough()) {
            return false;
        }

        if (!(Minecrft.get().field_1755 instanceof ViewfinderCameraControlsScreen)) {
            if (KeyboardHandler.getCameraControlsKey().method_1417(key, scanCode)) {
                openControlsScreen();
                return false; // false not handle and keep moving/sneaking
            }

            if (zoom.keyPressed(key, scanCode, action)) {
                return true;
            }
        }

        return false;
    }

    public boolean mouseClicked(int button, int action) {
        if (!isLookingThrough()) {
            return false;
        }

        if (Minecrft.get().field_1755 instanceof ViewfinderCameraControlsScreen) return false;

        if (!canAttack() && Minecrft.options().field_1886.method_1433(button))
            return true; // Block attacks

        if (KeyboardHandler.getCameraControlsKey().method_1433(button)) {
            openControlsScreen();
            return false; // Do not cancel the event to keep sneaking
        }

        if (Config.Client.VIEWFINDER_MIDDLE_CLICK_CONTROLS.get() && button == class_3675.field_32001) {
            openControlsScreen();
            return true;
        }

        return false;
    }

    public boolean mouseScrolled(double amount) {
        return isLookingThrough() && !(Minecrft.get().field_1755 instanceof ViewfinderCameraControlsScreen) && zoom.mouseScrolled(amount);
    }

    public double modifyMouseSensitivity(double original) {
        if (!isLookingThrough())
            return original;

        double scale = original / class_310.method_1551().field_1690.method_41808().method_41753();
        double scaledSensitivity = zoom.getCurrentFov() * scale;

        double normalizedDifference = class_3532.method_33722(original - scaledSensitivity, 0, original, 0, 1);
        double influence = Config.Client.VIEWFINDER_ZOOM_SENSITIVITY_INFLUENCE.get();
        double strength = 1f - normalizedDifference * influence;
        strength *= strength; // more influence at smaller FOVs

        return class_3532.method_16436(strength, scaledSensitivity, original);
    }

    @FunctionalInterface
    public interface ComponentConstructor<T> {
        T construct(Camera camera, Viewfinder viewfinder);
    }
}
