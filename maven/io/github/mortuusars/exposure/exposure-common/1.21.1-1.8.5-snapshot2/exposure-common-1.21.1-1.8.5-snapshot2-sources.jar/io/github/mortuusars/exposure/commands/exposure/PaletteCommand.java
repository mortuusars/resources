package io.github.mortuusars.exposure.commands.exposure;

import com.google.gson.*;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.serialization.JsonOps;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.commands.argument.ColorPaletteArgument;
import io.github.mortuusars.exposure.util.color.Color;
import io.github.mortuusars.exposure.data.ColorPalette;
import org.jetbrains.annotations.Nullable;

import javax.imageio.ImageIO;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Arrays;

import static net.minecraft.class_2170.*;

public class PaletteCommand {
    public static LiteralArgumentBuilder<class_2168> get() {
        return method_9247("palette")
                .then(method_9247("export")
                        .then(method_9244("palette", new ColorPaletteArgument())
                                .then(method_9247("json")
                                        .then(method_9244("file_path", StringArgumentType.string())
                                                .executes(context -> exportAsJson(context.getSource(),
                                                        ColorPaletteArgument.method_9443(context, "palette"),
                                                        StringArgumentType.getString(context, "file_path")))))
                                .then(method_9247("png")
                                        .then(method_9244("file_path", StringArgumentType.string())
                                                .executes(context -> exportAsPng(context.getSource(),
                                                        ColorPaletteArgument.method_9443(context, "palette"),
                                                        StringArgumentType.getString(context, "file_path")))))))
                .then(method_9247("convert")
                        .then(method_9247("json_to_png")
                                .then(method_9244("file_path", StringArgumentType.string())
                                        .executes(context -> convertJsonToPng(context.getSource(),
                                                StringArgumentType.getString(context, "file_path")))))
                        .then(method_9247("png_to_json")
                                .then(method_9244("file_path", StringArgumentType.string())
                                        .executes(context -> convertPngToJson(context.getSource(),
                                                StringArgumentType.getString(context, "file_path"))))));
    }

    private static int exportAsJson(class_2168 source, class_2960 paletteId, String filePath) {
        @Nullable ColorPalette palette = source.method_30497().method_30530(Exposure.Registries.COLOR_PALETTE).method_10223(paletteId);
        if (palette == null) {
            source.method_9213(class_2561.method_43470(paletteId + " is not found."));
            return 0;
        }

        try {
            savePaletteAsJson(palette, new File(filePath));
        } catch (Exception e) {
            Exposure.LOGGER.error("Exporting palette '{}' failed: ", paletteId, e);
            source.method_9213(class_2561.method_43470("Exporting palette '" + paletteId + "' failed: " + e.getMessage()));
            return 0;
        }

        source.method_9226(() -> class_2561.method_43470("Exported palette '" + paletteId + "' to file ")
                .method_10852(class_2561.method_43470(filePath).method_27696(class_2583.field_24360
                        .method_30938(true))), true);

        return 0;
    }

    private static int exportAsPng(class_2168 source, class_2960 paletteId, String filePath) {
        @Nullable ColorPalette palette = source.method_30497().method_30530(Exposure.Registries.COLOR_PALETTE).method_10223(paletteId);
        if (palette == null) {
            source.method_9213(class_2561.method_43470(paletteId + " is not found."));
            return 0;
        }

        try {
            savePaletteAsPng(palette, new File(filePath));
            source.method_9226(() -> class_2561.method_43470("Exported palette '" + paletteId + "' to file ")
                    .method_10852(class_2561.method_43470(filePath).method_27696(class_2583.field_24360
                            .method_30938(true))), true);
        } catch (Exception e) {
            Exposure.LOGGER.error("Exporting palette '{}' failed: ", paletteId, e);
            source.method_9213(class_2561.method_43470("Exporting palette '" + paletteId + "' failed: " + e.getMessage()));
        }

        return 0;
    }

    private static int convertJsonToPng(class_2168 source, String filePath) {
        try {
            File file = new File(filePath);
            ColorPalette palette = loadPaletteFromJson(file);
            savePaletteAsPng(palette, replaceExtension(file, "png"));
            source.method_9226(() -> class_2561.method_43470("Converted palette '" + filePath + "' to png."), true);
        } catch (Exception e) {
            Exposure.LOGGER.error("Converting palette '{}' failed: ", filePath, e);
            source.method_9213(class_2561.method_43470("Converting palette '" + filePath + "' failed: " + e.getMessage()));
        }

        return 0;
    }

    private static int convertPngToJson(class_2168 source, String filePath) {

        try {
            File file = new File(filePath);
            BufferedImage image = ImageIO.read(file);

            int[] colors = new int[256];
            Arrays.fill(colors, Color.BLACK.getARGB());
            colors[255] = Color.TRANSPARENT.getARGB();

            int count = 0;

            for (int y = 0; y < image.getHeight(); y++) {
                for (int x = 0; x < image.getWidth(); x++) {
                    if (count > 255) break;

                    int color = image.getRGB(x, y);

                    boolean alreadyAdded = false;
                    for (int addedColor : colors) {
                        if (addedColor == color) {
                            alreadyAdded = true;
                            break;
                        }
                    }

                    if (alreadyAdded) {
                        continue;
                    }

                    colors[count] = color;
                    count++;
                }
            }

            if (colors[255] != Color.TRANSPARENT.getARGB()) {
                colors[255] = Color.TRANSPARENT.getARGB();
                source.method_9213(class_2561.method_43470("Corrected last color to be transparent in '" + filePath + "' palette."));
            }

            ColorPalette palette = new ColorPalette(colors);

            try {
                savePaletteAsJson(palette, replaceExtension(file, "json"));
            } catch (Exception e) {
                Exposure.LOGGER.error("Cannot save converted palette '{}' failed: ", filePath, e);
                source.method_9213(class_2561.method_43470("Cannot save converted palette '" + filePath + "' failed: " + e.getMessage()));
                return 0;
            }

        } catch (Exception e) {
            Exposure.LOGGER.error("Converting palette '{}' failed: ", filePath, e);
            source.method_9213(class_2561.method_43470("Converting palette '" + filePath + "' failed: " + e.getMessage()));
            return 0;
        }

        source.method_9226(() -> class_2561.method_43470("Converted palette '" + filePath + "' to json."), true);

        return 0;
    }

    private static void savePaletteAsJson(ColorPalette palette, File file) throws IOException {
        JsonElement jsonElement = ColorPalette.CODEC.encodeStart(JsonOps.INSTANCE, palette).getOrThrow();
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String json = gson.toJson(jsonElement);

        try (FileWriter writer = new FileWriter(file)) {
            writer.write(json);
        }
    }

    private static void savePaletteAsPng(ColorPalette palette, File file) throws IOException {
        BufferedImage image = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
        int[] colors = palette.colors();

        for (int y = 0; y < 16; y++) {
            for (int x = 0; x < 16; x++) {
                image.setRGB(x, y, colors[y * 16 + x]);
            }
        }

        ImageIO.write(image, "png", file);
    }

    private static ColorPalette loadPaletteFromJson(File file) throws IOException {
        try (FileReader reader = new FileReader(file)) {
            JsonObject jsonObject = new Gson().fromJson(reader, JsonObject.class);
            return ColorPalette.CODEC.decode(JsonOps.INSTANCE, jsonObject).getOrThrow().getFirst();
        }
    }

    private static File replaceExtension(File originalFile, String newExtension) {
        String originalPath = originalFile.getPath();

        int lastDotIndex = originalPath.lastIndexOf('.');

        String newPath = (lastDotIndex == -1)
                ? originalPath + "." + newExtension
                : originalPath.substring(0, lastDotIndex) + "." + newExtension;

        return new File(newPath);
    }
}
