package io.github.mortuusars.exposure.world.item.util;

import java.util.function.*;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class ItemAndStack<T extends class_1792> {
    private final T item;
    private final class_1799 stack;

    public ItemAndStack(class_1799 stack) {
        this.stack = stack;
        //noinspection unchecked
        this.item = (T) stack.method_7909();
    }

    public T getItem() {
        return item;
    }

    public class_1799 getItemStack() {
        return stack;
    }

    public ItemAndStack<T> apply(BiConsumer<T, class_1799> function) {
        function.accept(item, stack);
        return this;
    }

    public <R> R map(BiFunction<T, class_1799, R> mappingFunction) {
        return mappingFunction.apply(item, stack);
    }

    @Override
    public String toString() {
        return "ItemAndStack{" + stack.toString() + '}';
    }
}
