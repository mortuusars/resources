package io.github.mortuusars.exposure.client.util;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import io.github.mortuusars.exposure.util.Rect2f;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

public class GuiUtil {
    public static void blit(class_4587 poseStack, Rect2f rect,
                            int u, int v, int textureWidth, int textureHeight, float zOffset) {
        blit(null, poseStack, rect, u, v, textureWidth, textureHeight, zOffset);
    }

    public static void blit(@Nullable class_2960 texture, class_4587 poseStack, Rect2f rect,
                            int u, int v, int textureWidth, int textureHeight, float zOffset) {
        blit(texture, poseStack, rect.x, rect.y, rect.width, rect.height, u, v, textureWidth, textureHeight, zOffset);
    }

    public static void blit(class_4587 poseStack, float x, float y, float width, float height,
                            int u, int v, int textureWidth, int textureHeight, float zOffset) {
        blit(null, poseStack, x, y, width, height, u, v, textureWidth, textureHeight, zOffset);
    }

    public static void blit(@Nullable class_2960 texture, class_4587 poseStack, float x, float y, float width, float height,
                            int u, int v, int textureWidth, int textureHeight, float zOffset) {
        blit(texture, poseStack, x, x + width, y, y + height, zOffset,
                u / (float)textureWidth, (u + width) / (float)textureWidth,
                v / (float)textureHeight, (v + height) / (float)textureHeight);
    }

    public static void blit(class_4587 poseStack, float minX, float maxX, float minY, float maxY, float zOffset,
                            float minU, float maxU, float minV, float maxV) {
        blit(null, poseStack, minX, maxX, minY, maxY, zOffset, minU, maxU, minV, maxV);
    }

    private static void blit(@Nullable class_2960 texture, class_4587 poseStack,
                             float minX, float maxX, float minY, float maxY, float zOffset,
                             float minU, float maxU, float minV, float maxV) {
        if (texture != null) {
            RenderSystem.setShaderTexture(0, texture);
        }

        Matrix4f matrix = poseStack.method_23760().method_23761();
        RenderSystem.setShader(class_757::method_34542);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        bufferBuilder.method_22918(matrix, minX, maxY, zOffset).method_22913(minU, maxV);
        bufferBuilder.method_22918(matrix, maxX, maxY, zOffset).method_22913(maxU, maxV);
        bufferBuilder.method_22918(matrix, maxX, minY, zOffset).method_22913(maxU, minV);
        bufferBuilder.method_22918(matrix, minX, minY, zOffset).method_22913(minU, minV);
        class_286.method_43433(bufferBuilder.method_60800());
    }

    // --

    public static void drawRect(class_332 guiGraphics, Rect2f rect, int color) {
        drawRect(guiGraphics, rect.x, rect.y, rect.width, rect.height, color);
    }

    public static void drawRect(class_332 guiGraphics, float x, float y, float width, float height, int color) {
        drawRect(guiGraphics.method_51448(), x, y, x + width, y + height, color);
//        float minX = x;
//        float minY = y;
//        float maxX = x + width;
//        float maxY = y + height;
//
//        if (width < 0) {
//            minX = width;
//            maxX = x;
//        }
//
//        if (height < 0) {
//            minY = height;
//            maxY = y;
//        }
//
//        Matrix4f matrix = guiGraphics.pose().last().pose();
//        RenderSystem.setShader(GameRenderer::getPositionColorShader);
//        BufferBuilder bufferBuilder = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
//        bufferBuilder.addVertex(matrix, minX, maxY, 0).setColor(color);
//        bufferBuilder.addVertex(matrix, maxX, maxY, 0).setColor(color);
//        bufferBuilder.addVertex(matrix, maxX, minY, 0).setColor(color);
//        bufferBuilder.addVertex(matrix, minX, minY, 0).setColor(color);
//        BufferUploader.drawWithShader(bufferBuilder.buildOrThrow());
    }

    public static void drawRect(class_4587 poseStack, float minX, float minY, float maxX, float maxY, int color) {
        if (minX < maxX) {
            float temp = minX;
            minX = maxX;
            maxX = temp;
        }

        if (minY < maxY) {
            float temp = minY;
            minY = maxY;
            maxY = temp;
        }

        Matrix4f matrix = poseStack.method_23760().method_23761();
        RenderSystem.setShader(class_757::method_34540);
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22918(matrix, minX, maxY, 0).method_39415(color);
        bufferBuilder.method_22918(matrix, maxX, maxY, 0).method_39415(color);
        bufferBuilder.method_22918(matrix, maxX, minY, 0).method_39415(color);
        bufferBuilder.method_22918(matrix, minX, minY, 0).method_39415(color);
        class_286.method_43433(bufferBuilder.method_60800());
    }
}
