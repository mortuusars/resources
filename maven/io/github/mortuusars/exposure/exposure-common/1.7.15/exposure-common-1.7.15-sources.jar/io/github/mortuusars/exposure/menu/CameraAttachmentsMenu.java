package io.github.mortuusars.exposure.menu;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.camera.AttachmentType;
import io.github.mortuusars.exposure.item.CameraItem;
import io.github.mortuusars.exposure.util.ItemAndStack;
import io.github.mortuusars.exposure.util.supporter.Supporters;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1263;
import net.minecraft.class_1265;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2540;

public class CameraAttachmentsMenu extends class_1703 {
    public static final int SKIN_REGULAR_BUTTON_ID = 100;
    public static final int SKIN_GOLD_BUTTON_ID = 101;

    private final int attachmentSlotsCount;
    private final int cameraSlotIndex;
    private final class_1657 player;
    private final ItemAndStack<CameraItem> camera;

    private boolean clientContentsInitialized;

    public CameraAttachmentsMenu(int containerId, class_1661 playerInventory, int cameraSlotIndex) {
        super(Exposure.MenuTypes.CAMERA.get(), containerId);

        class_1799 cameraStack = playerInventory.field_7547.get(cameraSlotIndex);
        Preconditions.checkState(cameraStack.method_7909() instanceof CameraItem,
                "Failed to open Camera Attachments. " + cameraStack + " is not a CameraItem.");

        this.player = playerInventory.field_7546;
        this.cameraSlotIndex = cameraSlotIndex;
        this.camera = new ItemAndStack<>(cameraStack);

        class_1277 container = new class_1277(getCameraAttachments(camera).toArray(class_1799[]::new)) {
            @Override
            public int method_5444() {
                return 1;
            }
        };

        container.method_5489(new class_1265() {
            @Override
            public void method_5453(class_1263 container) {
                for (int slotId = 0; slotId < container.method_5439(); slotId++) {
                    AttachmentType attachmentType = camera.getItem().getAttachmentTypeForSlot(camera.getStack(), slotId).orElseThrow();

                    camera.getItem().setAttachment(camera.getStack(), attachmentType, container.method_5438(slotId));

                    if (!player.method_37908().method_8608() && player.method_7337()) {
                        // Fixes item not updating properly when not in "Inventory" tab of creative inventory
                        player.method_31548().method_5447(cameraSlotIndex, camera.getStack());
                    }
                }
            }
        });

        this.attachmentSlotsCount = addAttachmentSlots(container);
        addPlayerSlots(playerInventory);
    }

    public ItemAndStack<CameraItem> getCamera() {
        return camera;
    }

    /**
     * Only called client-side.
     */
    @Override
    public void method_7610(int stateId, List<class_1799> items, class_1799 carried) {
        clientContentsInitialized = false;
        super.method_7610(stateId, items, carried);
        clientContentsInitialized = true;
    }

    protected int addAttachmentSlots(class_1263 container) {
        int attachmentSlots = 0;

        int[][] slots = new int[][]{
                // SlotId, x, y, maxStackSize
                {CameraItem.FILM_ATTACHMENT.slot(), 13, 42, 1},
                {CameraItem.FLASH_ATTACHMENT.slot(), 147, 15, 1},
                {CameraItem.LENS_ATTACHMENT.slot(), 147, 43, 1},
                {CameraItem.FILTER_ATTACHMENT.slot(), 147, 71, 1}
        };

        for (int[] slot : slots) {
            Optional<AttachmentType> attachment = camera.getItem()
                    .getAttachmentTypeForSlot(camera.getStack(), slot[0]);

            if (attachment.isPresent()) {
                method_7621(new FilteredSlot(container, slot[0], slot[1], slot[2], slot[3],
                        this::onItemInSlotChanged, attachment.get().itemPredicate()));
                attachmentSlots++;
            }
        }

        return attachmentSlots;
    }

    protected void addPlayerSlots(class_1661 playerInventory) {
        //Player Inventory
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                method_7621(new class_1735(playerInventory, (column + row * 9) + 9, column * 18 + 8, 103 + row * 18){
                    @Override
                    public boolean method_7674(@NotNull class_1657 player) {
                        return super.method_7674(player) && method_34266() != cameraSlotIndex;
                    }

                    @Override
                    public boolean method_7682() {
                        return method_34266() != cameraSlotIndex;
                    }

                    @Override
                    public boolean method_51306() {
                        return method_34266() != cameraSlotIndex;
                    }
                });
            }
        }

        //Hotbar
        for (int slot = 0; slot < 9; slot++) {
            int finalSlot = slot;
            method_7621(new class_1735(playerInventory, finalSlot, slot * 18 + 8, 161) {
                @Override
                public boolean method_7674(@NotNull class_1657 player) {
                    return super.method_7674(player) && method_34266() != cameraSlotIndex;
                }

                @Override
                public boolean method_7682() {
                    return method_34266() != cameraSlotIndex;
                }

                @Override
                public boolean method_51306() {
                    return method_34266() != cameraSlotIndex;
                }
            });
        }
    }

    protected void onItemInSlotChanged(FilteredSlot.SlotChangedArgs args) {
        int slotId = args.slot().getSlotId();
        class_1799 newStack = args.newStack();

        camera.getItem().getAttachmentTypeForSlot(camera.getStack(), slotId).ifPresent(type -> {
            camera.getItem().setAttachment(camera.getStack(), type, newStack);

            if (player.method_37908().method_8608() && clientContentsInitialized)
                type.sound().playOnePerPlayer(player, newStack.method_7960());

            if (!player.method_37908().method_8608() && player.method_7337()) {
                // Fixes item not updating properly when not in "Inventory" tab of creative inventory
                player.method_31548().method_5447(cameraSlotIndex, camera.getStack());
            }
        });
    }

    private static class_2371<class_1799> getCameraAttachments(ItemAndStack<CameraItem> camera) {
        class_2371<class_1799> items = class_2371.method_10211();

        List<AttachmentType> attachmentTypes = camera.getItem().getAttachmentTypes(camera.getStack());
        for (AttachmentType attachmentType : attachmentTypes) {
            items.add(camera.getItem().getAttachment(camera.getStack(), attachmentType).orElse(class_1799.field_8037));
        }

        return items;
    }

    @Override
    public @NotNull class_1799 method_7601(@NotNull class_1657 player, int slotIndex) {
        class_1799 itemstack = class_1799.field_8037;
        class_1735 clickedSlot = this.field_7761.get(slotIndex);
        if (clickedSlot.method_7681()) {
            class_1799 slotStack = clickedSlot.method_7677();
            itemstack = slotStack.method_7972();
            if (slotIndex < attachmentSlotsCount) {
                if (!this.method_7616(slotStack, attachmentSlotsCount, this.field_7761.size(), true))
                    return class_1799.field_8037;
            } else {
                if (!this.method_7616(slotStack, 0, attachmentSlotsCount, false))
                    return class_1799.field_8037;
            }

            if (slotStack.method_7960())
                clickedSlot.method_7673(class_1799.field_8037);
            else
                clickedSlot.method_7668();
        }

        return itemstack;
    }

    /**
     * Fixed method to respect slot photo limit.
     */
    @Override
    protected boolean method_7616(class_1799 movedStack, int startIndex, int endIndex, boolean reverseDirection) {
        boolean hasRemainder = false;
        int i = startIndex;
        if (reverseDirection) {
            i = endIndex - 1;
        }
        if (movedStack.method_7946()) {
            while (!movedStack.method_7960() && !(!reverseDirection ? i >= endIndex : i < startIndex)) {
                class_1735 slot = this.field_7761.get(i);
                class_1799 slotStack = slot.method_7677();
                if (!slotStack.method_7960() && class_1799.method_31577(movedStack, slotStack)) {
                    int maxSize;
                    int j = slotStack.method_7947() + movedStack.method_7947();
                    if (j <= (maxSize = Math.min(slot.method_7675(), movedStack.method_7914()))) {
                        movedStack.method_7939(0);
                        slotStack.method_7939(j);
                        slot.method_7668();
                        hasRemainder = true;
                    } else if (slotStack.method_7947() < maxSize) {
                        movedStack.method_7934(maxSize - slotStack.method_7947());
                        slotStack.method_7939(maxSize);
                        slot.method_7668();
                        hasRemainder = true;
                    }
                }
                if (reverseDirection) {
                    --i;
                    continue;
                }
                ++i;
            }
        }
        if (!movedStack.method_7960()) {
            i = reverseDirection ? endIndex - 1 : startIndex;
            while (!(!reverseDirection ? i >= endIndex : i < startIndex)) {
                class_1735 slot1 = this.field_7761.get(i);
                class_1799 movedStack1 = slot1.method_7677();
                if (movedStack1.method_7960() && slot1.method_7680(movedStack)) {
                    if (movedStack.method_7947() > slot1.method_7675()) {
                        slot1.method_48931(movedStack.method_7971(slot1.method_7675()));
                    } else {
                        slot1.method_48931(movedStack.method_7971(movedStack.method_7947()));
                    }
                    slot1.method_7668();
                    hasRemainder = true;
                    break;
                }
                if (reverseDirection) {
                    --i;
                    continue;
                }
                ++i;
            }
        }
        return hasRemainder;
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (Supporters.hasAccessToGoldenSkin(player.method_5667())) {
            if (id == SKIN_REGULAR_BUTTON_ID) {
                getCamera().apply((i, s) -> s.method_7948().method_10551("GoldenCamera"));
                method_7623();
                return true;
            } else if (id == SKIN_GOLD_BUTTON_ID) {
                getCamera().apply((i, s) -> s.method_7948().method_10556("GoldenCamera", true));
                method_7623();
                return true;
            }
        }
        return false;
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);

        // Without this, client inventory is syncing properly when menu is closed. (only when opened by r-click in GUI)
        player.field_7498.method_34257();
    }

    @Override
    public boolean method_7597(@NotNull class_1657 player) {
        return class_1799.method_31577(player.method_31548().method_5438(cameraSlotIndex), camera.getStack());
    }

    public static CameraAttachmentsMenu fromBuffer(int containerId, class_1661 playerInventory, class_2540 buffer) {
        return new CameraAttachmentsMenu(containerId, playerInventory, buffer.readInt());
    }
}
