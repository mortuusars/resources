package io.github.mortuusars.exposure.util.supporter;

import java.util.UUID;
import net.minecraft.class_156;

public record Supporter(String name, UUID uuid) {
    public boolean matches(UUID uuid) {
        if (uuid.equals(class_156.field_25140)) return false;
        return uuid().equals(uuid);
    }
}