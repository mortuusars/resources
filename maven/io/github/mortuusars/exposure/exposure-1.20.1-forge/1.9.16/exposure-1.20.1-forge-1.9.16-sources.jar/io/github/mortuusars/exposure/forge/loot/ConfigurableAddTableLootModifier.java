package io.github.mortuusars.exposure.forge.loot;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.forge.ExposureForge;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import org.jetbrains.annotations.NotNull;

/**
 * Basically a copy of AddTableLootModifier just to allow disabling it through config.
 */
public class ConfigurableAddTableLootModifier extends AddTableLootModifier {
    public static final Codec<ConfigurableAddTableLootModifier> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                    IGlobalLootModifier.LOOT_CONDITIONS_CODEC.fieldOf("conditions").forGetter(glm -> glm.conditions),
                    ResourceLocation.f_135803_.fieldOf("table").forGetter(ConfigurableAddTableLootModifier::table))
            .apply(instance, ConfigurableAddTableLootModifier::new));

    public ConfigurableAddTableLootModifier(LootItemCondition[] conditions, ResourceLocation table) {
        super(conditions, table);
    }

    @Override
    protected @NotNull ObjectArrayList<ItemStack> doApply(@NotNull ObjectArrayList<ItemStack> generatedLoot, @NotNull LootContext context) {
        if (!Config.Common.GENERATE_LOOT.get()) {
            return generatedLoot;
        }

        return super.doApply(generatedLoot, context);
    }

    @Override
    public @NotNull Codec<ConfigurableAddTableLootModifier> codec() {
        return ExposureForge.LootModifiers.ADD_TABLE.get();
    }
}
