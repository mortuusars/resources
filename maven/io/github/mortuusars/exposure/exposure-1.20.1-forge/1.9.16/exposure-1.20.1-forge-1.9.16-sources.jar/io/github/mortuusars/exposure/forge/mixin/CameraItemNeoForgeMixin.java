package io.github.mortuusars.exposure.forge.mixin;

import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.extensions.IForgeItem;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value = CameraItem.class)
public abstract class CameraItemNeoForgeMixin extends Item implements IForgeItem {
    public CameraItemNeoForgeMixin(Properties properties) {
        super(properties);
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, @NotNull ItemStack newStack, boolean slotChanged) {
        return !ItemStack.m_150942_(newStack, oldStack);
    }
}
