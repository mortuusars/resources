package io.github.mortuusars.exposure.forge.datagen;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.advancements.predicate.*;
import io.github.mortuusars.exposure.advancements.trigger.FrameExposedTrigger;
import io.github.mortuusars.exposure.advancements.trigger.FramePrintedTrigger;
import io.github.mortuusars.exposure.util.ExtraData;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.camera.frame.Photographer;
import io.github.mortuusars.exposure.world.item.camera.CameraSetting;
import io.github.mortuusars.exposure.world.item.camera.CameraSettings;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.FrameType;
import net.minecraft.advancements.critereon.*;
import net.minecraft.client.CameraType;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemEntityPropertyCondition;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.common.data.ForgeAdvancementProvider;

import java.util.*;
import java.util.function.Consumer;

public class ExposureAdvancementGenerator implements ForgeAdvancementProvider.AdvancementGenerator {
    @Override
    public void generate(HolderLookup.Provider arg, Consumer<Advancement> consumer, ExistingFileHelper existingFileHelper) {
        ItemStack camera = Exposure.Items.CAMERA.get().m_7968_();
        Exposure.DataComponents.setCameraActive(camera, true);
        Advancement root = Advancement.Builder.m_138353_()
              .m_138396_(new ResourceLocation("adventure/root"))
              .m_138362_(camera, Component.m_237115_("advancement.exposure.exposure.title"),
                    Component.m_237115_("advancement.exposure.exposure.description"),
                    null, FrameType.TASK, true, true, false)
              .m_138386_("expose_frame", new FrameExposedTrigger.TriggerInstance(ContextAwarePredicate.f_285567_,
                    CameraPredicate.ANY, FramePredicate.ANY, LocationPredicate.f_52592_, new ArrayList<>()))
              .save(consumer, Exposure.resource("adventure/exposure"), existingFileHelper);

        ExtraData selfie = new ExtraData();
        selfie.put(Frame.SELFIE, true);

        Advancement spotlight = Advancement.Builder.m_138353_()
              .m_138398_(root)
              .m_138371_(Items.f_42680_, Component.m_237115_("advancement.exposure.spotlight.title"),
                    Component.m_237115_("advancement.exposure.spotlight.description"),
                    null, FrameType.TASK, true, true, false)
              .m_138386_("take_selfie", new FrameExposedTrigger.TriggerInstance(ContextAwarePredicate.f_285567_,
                    CameraPredicate.ANY, new FramePredicate(Optional.empty(), Optional.empty(),
                    Optional.empty(), Optional.empty(), MinMaxBounds.Ints.f_55364_, MinMaxBounds.Ints.f_55364_,
                    MinMaxBounds.Ints.f_55364_, MinMaxBounds.Ints.m_55371_(1),
                    List.of(new EntityInFramePredicate(Optional.of(new ResourceLocation("player")), Optional.empty(), MinMaxBounds.Ints.f_55364_)),
                    new NbtPredicate(selfie)), LocationPredicate.f_52592_, new ArrayList<>()))
              .save(consumer, Exposure.resource("adventure/spotlight"), existingFileHelper);

        Advancement splittingThePhoton = Advancement.Builder.m_138353_()
              .m_138398_(root)
              .m_138371_(Items.f_42190_, Component.m_237115_("advancement.exposure.splitting_the_photon.title"),
                    Component.m_237115_("advancement.exposure.splitting_the_photon.description"),
                    null, FrameType.TASK, true, true, false)
              .m_138386_("expose_frame_with_rgb_filter", new FrameExposedTrigger.TriggerInstance(ContextAwarePredicate.f_285567_,
                    new CameraPredicate(ItemPredicate.f_45028_, ItemPredicate.Builder.m_45068_().m_151445_(Exposure.Items.BLACK_AND_WHITE_FILM.get(), Exposure.Items.HIGH_SENSITIVITY_BLACK_AND_WHITE_FILM.get()).m_45077_(),
                          ItemPredicate.f_45028_, ItemPredicate.f_45028_, ItemPredicate.Builder.m_45068_().m_151445_(Items.f_42190_
                          , Items.f_42189_, Items.f_42187_).m_45077_(), LocationPredicate.f_52592_), FramePredicate.ANY, LocationPredicate.f_52592_, new ArrayList<>()))
              .save(consumer, Exposure.resource("adventure/splitting_the_photon"), existingFileHelper);

        Advancement momentInTime = Advancement.Builder.m_138353_()
              .m_138398_(root)
              .m_138371_(Exposure.Items.PHOTOGRAPH.get(), Component.m_237115_("advancement.exposure.moment_in_time.title"),
                    Component.m_237115_("advancement.exposure.moment_in_time.description"),
                    null, FrameType.TASK, true, true, false)
              .m_138386_("print_photograph", new FramePrintedTrigger.TriggerInstance(ContextAwarePredicate.f_285567_, LocationPredicate.f_52592_, FramePredicate.ANY,
                    ItemPredicate.Builder.m_45068_().m_151445_(Exposure.Items.PHOTOGRAPH.get()).m_45077_()))
              .save(consumer, Exposure.resource("adventure/moment_in_time"), existingFileHelper);

        ExtraData onStand = new ExtraData();
        onStand.put(Frame.ON_STAND, true);

        Advancement familyPortrait = Advancement.Builder.m_138353_()
              .m_138398_(root)
              .m_138371_(Exposure.Items.CAMERA_STAND.get(), Component.m_237115_("advancement.exposure.family_portrait.title"),
                    Component.m_237115_("advancement.exposure.family_portrait.description"),
                    null, FrameType.TASK, true, true, false)
              .m_138386_("captured_entities",
                    new FrameExposedTrigger.TriggerInstance(ContextAwarePredicate.f_285567_, CameraPredicate.ANY,
                          new FramePredicate(Optional.empty(), Optional.empty(),
                                Optional.empty(), Optional.empty(), MinMaxBounds.Ints.f_55364_, MinMaxBounds.Ints.f_55364_,
                                MinMaxBounds.Ints.f_55364_, MinMaxBounds.Ints.f_55364_,
                                List.of(), NbtPredicate.f_57471_), LocationPredicate.f_52592_,
                          List.of(
                                ContextAwarePredicate.m_286108_(
                                      LootItemEntityPropertyCondition.m_81867_(LootContext.EntityTarget.THIS,
                                            EntityPredicate.Builder.m_36633_().m_36646_(EntityTypePredicate.m_37647_(EntityType.f_20553_))
                                                  .m_218800_(new TamedPredicate(true)).m_36662_()).m_6409_()
                                ),
                                ContextAwarePredicate.m_286108_(
                                      LootItemEntityPropertyCondition.m_81867_(LootContext.EntityTarget.THIS,
                                            EntityPredicate.Builder.m_36633_().m_36646_(EntityTypePredicate.m_37647_(EntityType.f_20499_))
                                                  .m_218800_(new TamedPredicate(true)).m_36662_()).m_6409_()
                                ),
                                ContextAwarePredicate.m_286108_(
                                      LootItemEntityPropertyCondition.m_81867_(LootContext.EntityTarget.THIS,
                                            EntityPredicate.Builder.m_36633_().m_36646_(EntityTypePredicate.m_37647_(EntityType.f_20532_)).m_36662_()).m_6409_()
                                )
                          )))
              .save(consumer, Exposure.resource("adventure/family_portrait"), existingFileHelper);

        ExtraData flash = new ExtraData();
        flash.put(Frame.FLASH, true);

        Advancement lightsUp = Advancement.Builder.m_138353_()
              .m_138398_(spotlight)
              .m_138371_(Items.f_42105_, Component.m_237115_("advancement.exposure.lights_up.title"),
                    Component.m_237115_("advancement.exposure.lights_up.description"),
                    null, FrameType.TASK, true, true, false)
              .m_138386_("flash_in_darkness",
                    new FrameExposedTrigger.TriggerInstance(ContextAwarePredicate.f_285567_, CameraPredicate.ANY,
                          new FramePredicate(Optional.empty(), Optional.empty(),
                                Optional.empty(), Optional.empty(), MinMaxBounds.Ints.f_55364_, MinMaxBounds.Ints.m_154819_(3),
                                MinMaxBounds.Ints.f_55364_, MinMaxBounds.Ints.f_55364_,
                                List.of(), new NbtPredicate(flash)), LocationPredicate.f_52592_,
                          List.of()))
              .save(consumer, Exposure.resource("adventure/lights_up"), existingFileHelper);

        Advancement exposedPaparazzi = Advancement.Builder.m_138353_()
              .m_138398_(lightsUp)
              .m_138371_(Items.f_42055_, Component.m_237115_("advancement.exposure.exposed_paparazzi.title"),
                    Component.m_237115_("advancement.exposure.exposed_paparazzi.description"),
                    null, FrameType.TASK, true, true, true)
              .m_138386_("shoot_with_flash",
                    new FrameExposedTrigger.TriggerInstance(ContextAwarePredicate.f_285567_, CameraPredicate.ANY,
                          new FramePredicate(Optional.empty(), Optional.empty(),
                                Optional.empty(), Optional.empty(), MinMaxBounds.Ints.f_55364_, MinMaxBounds.Ints.f_55364_,
                                MinMaxBounds.Ints.m_154814_(13000, 23000), MinMaxBounds.Ints.f_55364_,
                                List.of(
                                      new EntityInFramePredicate(Optional.of(new ResourceLocation("villager")),
                                            Optional.empty(), MinMaxBounds.Ints.m_55386_(6))
                                ), new NbtPredicate(flash)), LocationPredicate.f_52592_,
                          List.of()))
              .save(consumer, Exposure.resource("adventure/exposed_paparazzi"), existingFileHelper);

        CompoundTag chromatic = new CompoundTag();
        CompoundTag extraData = new CompoundTag();
        CompoundTag p = new ExtraData();
        p.m_128379_(Frame.CHROMATIC.key(), true);
        extraData.m_128365_("extra_data", p);
        chromatic.m_128365_("photograph_frame", extraData);

        Advancement complexCompositeCompound = Advancement.Builder.m_138353_()
              .m_138398_(splittingThePhoton)
              .m_138371_(Exposure.Items.CHROMATIC_SHEET.get(), Component.m_237115_("advancement.exposure.complex_composite_compound.title"),
                    Component.m_237115_("advancement.exposure.complex_composite_compound.description"),
                    null, FrameType.TASK, true, true, false)
              .m_138386_("print_chromatic_photograph", new FramePrintedTrigger.TriggerInstance(
                    ContextAwarePredicate.f_285567_, LocationPredicate.f_52592_, FramePredicate.ANY,
                    ItemPredicate.Builder.m_45068_().m_151445_(Exposure.Items.PHOTOGRAPH.get(), Exposure.Items.AGED_PHOTOGRAPH.get())
                          .m_45075_(chromatic)
                          .m_45077_()))
              .save(consumer, Exposure.resource("adventure/complex_composite_compound"), existingFileHelper);

        Advancement unforeseenConsequences = Advancement.Builder.m_138353_()
              .m_138398_(exposedPaparazzi)
              .m_138371_(Items.f_42545_, Component.m_237115_("advancement.exposure.unforeseen_consequences.title"),
                    Component.m_237115_("advancement.exposure.unforeseen_consequences.description"),
                    null, FrameType.TASK, true, true, true)
              .m_138386_("photograph_enderman_eyes",
                    new PlayerTrigger.TriggerInstance(Exposure.ExposureCriteriaTriggers.PHOTOGRAPH_ENDERMAN_EYES.m_7295_(), ContextAwarePredicate.f_285567_))
              .save(consumer, Exposure.resource("adventure/unforeseen_consequences"), existingFileHelper);

        Advancement photosOfSpiderMan = Advancement.Builder.m_138353_()
              .m_138398_(unforeseenConsequences)
              .m_138371_(Items.f_41863_, Component.m_237115_("advancement.exposure.photos_of_spider_man.title"),
                    Component.m_237115_("advancement.exposure.photos_of_spider_man.description"),
                    null, FrameType.TASK, true, true, true)
              .m_138386_("photograph_spider_man",
                    new FrameExposedTrigger.TriggerInstance(ContextAwarePredicate.f_285567_, CameraPredicate.ANY,
                          FramePredicate.ANY, LocationPredicate.f_52592_,
                          List.of(
                                ContextAwarePredicate.m_286108_(
                                      LootItemEntityPropertyCondition.m_81867_(LootContext.EntityTarget.THIS,
                                            EntityPredicate.Builder.m_36633_().m_36646_(EntityTypePredicate.m_37647_(EntityType.f_20524_))
                                                  .m_36644_(EntityPredicate.Builder.m_36633_().m_36646_(EntityTypePredicate.m_37647_(EntityType.f_20479_))
                                                        .m_36662_()).m_36662_()
                                      ).m_6409_()
                                ))))
              .save(consumer, Exposure.resource("adventure/photos_of_spider_man"), existingFileHelper);

        Advancement piercingGaze = Advancement.Builder.m_138353_()
              .m_138398_(root)
              .m_138371_(Exposure.Items.INTERPLANAR_PROJECTOR.get(), Component.m_237115_("advancement.exposure.piercing_gaze.title"),
                    Component.m_237115_("advancement.exposure.piercing_gaze.description"),
                    null, FrameType.TASK, true, true, false)
              .m_138386_("use_interplanar_projector",
                    new PlayerTrigger.TriggerInstance(Exposure.ExposureCriteriaTriggers.SUCCESSFULLY_PROJECT_IMAGE.m_7295_(), ContextAwarePredicate.f_285567_))
              .save(consumer, Exposure.resource("adventure/piercing_gaze"), existingFileHelper);

        ItemStack stack = Exposure.Items.PHOTOGRAPH.get().m_7968_();
        Exposure.DataComponents.setPhotographFrame(stack, new Frame(ExposureIdentifier.texture(
              Exposure.resource("textures/exposure/mineshaft/skeleton_smirk.png")),
              ExposureType.COLOR,
              Photographer.EMPTY,
              Collections.emptyList(),
              ExtraData.EMPTY));

        Advancement spookySillySkeletons = Advancement.Builder.m_138353_()
              .m_138398_(momentInTime)
              .m_138371_(Items.f_42500_, Component.m_237115_("advancement.exposure.spooky_silly_skeletons.title"),
                    Component.m_237115_("advancement.exposure.spooky_silly_skeletons.description"),
                    null, FrameType.TASK, true, true, true)
              .m_138386_("get_skeleton_smirk_photograph",
                    InventoryChangeTrigger.TriggerInstance.m_43197_(
                          ItemPredicate.Builder.m_45068_().m_151445_(Exposure.Items.PHOTOGRAPH.get(), Exposure.Items.AGED_PHOTOGRAPH.get())
                                .m_45075_(stack.m_41783_())
                                .m_45077_()
                    ))
              .save(consumer, Exposure.resource("adventure/spooky_silly_skeletons"), existingFileHelper);

        Advancement voidA = Advancement.Builder.m_138353_()
              .m_138398_(lightsUp)
              .m_138371_(Items.f_42103_, Component.m_237115_("advancement.exposure.void.title"),
                    Component.m_237115_("advancement.exposure.void.description"),
                    null, FrameType.TASK, true, true, true)
              .m_138386_("photograph_in_end",
                    new FrameExposedTrigger.TriggerInstance(ContextAwarePredicate.f_285567_, new CameraPredicate(
                          ItemPredicate.f_45028_, ItemPredicate.f_45028_, ItemPredicate.f_45028_, ItemPredicate.f_45028_,
                          ItemPredicate.f_45028_, LocationPredicate.m_52638_(Level.f_46430_)
                    ),
                          FramePredicate.ANY, LocationPredicate.f_52592_,
                          List.of()))
              .save(consumer, Exposure.resource("adventure/void"), existingFileHelper);

        Advancement.Builder wildLifeArchivist = Advancement.Builder.m_138353_()
              .m_138398_(root)
              .m_138371_(Items.f_151057_, Component.m_237115_("advancement.exposure.wildlife_archivist.title"),
                    Component.m_237115_("advancement.exposure.wildlife_archivist.description"),
                    null, FrameType.TASK, true, true, false);

        for (Map.Entry<String, FrameExposedTrigger.TriggerInstance> instanceEntry : buildCriteria(List.of(
              EntityType.f_147039_, EntityType.f_20549_, EntityType.f_243976_, EntityType.f_217012_, EntityType.f_147034_,
              EntityType.f_20480_, EntityType.f_20505_, EntityType.f_20508_, EntityType.f_20517_, EntityType.f_271264_,
              EntityType.f_20490_, EntityType.f_20550_, EntityType.f_20559_, EntityType.f_20452_, EntityType.f_147035_,
              EntityType.f_20466_, EntityType.f_20507_, EntityType.f_20514_, EntityType.f_20499_)).entrySet()) {
            wildLifeArchivist.m_138386_(instanceEntry.getKey(), instanceEntry.getValue());
        }
        wildLifeArchivist.save(consumer, Exposure.resource("adventure/wildlife_archivist"), existingFileHelper);
    }

    static Map<String, FrameExposedTrigger.TriggerInstance> buildCriteria(List<EntityType<?>> entityTypes) {
        Map<String, FrameExposedTrigger.TriggerInstance> map = new HashMap<>();
        for (EntityType<?> entityType : entityTypes) {
            String key = BuiltInRegistries.f_256780_.m_7981_(entityType).toString();

            FrameExposedTrigger.TriggerInstance villager = new FrameExposedTrigger.TriggerInstance(ContextAwarePredicate.f_285567_, CameraPredicate.ANY,
                  new FramePredicate(Optional.empty(), Optional.empty(),
                        Optional.empty(), Optional.empty(), MinMaxBounds.Ints.f_55364_, MinMaxBounds.Ints.f_55364_,
                        MinMaxBounds.Ints.f_55364_, MinMaxBounds.Ints.f_55364_,
                        List.of(
                              new EntityInFramePredicate(Optional.of(new ResourceLocation(key)), Optional.empty(), MinMaxBounds.Ints.f_55364_)
                        ), NbtPredicate.f_57471_), LocationPredicate.f_52592_,
                  List.of());
            map.put(key, villager);
        }
        return map;
    }

}
