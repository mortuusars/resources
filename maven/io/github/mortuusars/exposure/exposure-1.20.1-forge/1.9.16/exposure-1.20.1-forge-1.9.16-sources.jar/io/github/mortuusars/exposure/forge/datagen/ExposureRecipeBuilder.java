package io.github.mortuusars.exposure.forge.datagen;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import io.github.mortuusars.exposure.world.item.crafting.recipe.serializer.ComponentTransferringRecipeSerializer;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementRewards;
import net.minecraft.advancements.CriterionTriggerInstance;
import net.minecraft.advancements.RequirementsStrategy;
import net.minecraft.advancements.critereon.RecipeUnlockedTrigger;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.recipes.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.ItemLike;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;

public class ExposureRecipeBuilder extends CraftingRecipeBuilder implements RecipeBuilder {
    private final ComponentTransferringRecipeSerializer<?> serializer;
    private final RecipeCategory category;
    private final Advancement.Builder advancement = Advancement.Builder.m_285878_();
    private final Ingredient targetIngredient;
    private final NonNullList<Ingredient> ingredients = NonNullList.m_122779_();
    private final Item result;

    public ExposureRecipeBuilder(ComponentTransferringRecipeSerializer<?> serializer, RecipeCategory category, Ingredient targetIngredient, Item result) {
        this.serializer = serializer;
        this.category = category;
        this.targetIngredient = targetIngredient;
        this.result = result;
    }

    @Override
    public @NotNull RecipeBuilder m_126132_(@NotNull String criterionName, @NotNull CriterionTriggerInstance criterionTrigger) {
        this.advancement.m_138386_(criterionName, criterionTrigger);
        return this;
    }

    public ExposureRecipeBuilder with(Ingredient ingredient) {
        ingredients.add(ingredient);
        return this;
    }

    public ExposureRecipeBuilder with(ItemLike ingredient) {
        return with(Ingredient.m_43929_(ingredient));
    }

    public ExposureRecipeBuilder with(TagKey<Item> ingredient) {
        return with(Ingredient.m_204132_(ingredient));
    }

    public static ExposureRecipeBuilder exposure(ComponentTransferringRecipeSerializer<?> serializer,
                                                 RecipeCategory category,
                                                 Ingredient targetIngredient,
                                                 Item result) {
        return new ExposureRecipeBuilder(serializer, category, targetIngredient, result);
    }

    public static ExposureRecipeBuilder exposure(ComponentTransferringRecipeSerializer<?> serializer,
                                                 RecipeCategory category,
                                                 ItemLike targetItem,
                                                 Item result) {
        return exposure(serializer, category, Ingredient.m_43929_(targetItem), result);
    }

    @Override
    public @NotNull RecipeBuilder m_126145_(@Nullable String groupName) {
        return this;
    }

    @Override
    public @NotNull Item m_142372_() {
        return result;
    }

    @Override
    public void m_126140_(Consumer<FinishedRecipe> finishedRecipeConsumer, @NotNull ResourceLocation recipeId) {
        this.advancement
              .m_138396_(f_236353_)
              .m_138386_("has_the_recipe", RecipeUnlockedTrigger.m_63728_(recipeId))
              .m_138354_(AdvancementRewards.Builder.m_10009_(recipeId))
              .m_138360_(RequirementsStrategy.f_15979_);

        finishedRecipeConsumer.accept(new Result(serializer,
              recipeId,
              targetIngredient,
              ingredients,
              advancement,
              recipeId.m_246208_("recipes/" + this.category.m_247710_() + "/"),
              this.result,
              m_245179_(RecipeCategory.MISC)));
    }

    public static class Result extends CraftingResult {
        private final ComponentTransferringRecipeSerializer<?> serializer;
        private final ResourceLocation id;
        private final Ingredient targetIngredient;
        private final NonNullList<Ingredient> ingredients;
        private final Advancement.Builder advancement;
        private final ResourceLocation advancementId;
        private final Item result;

        protected Result(ComponentTransferringRecipeSerializer<?> serializer,
                         ResourceLocation id,
                         Ingredient targetIngredient,
                         NonNullList<Ingredient> ingredients,
                         Advancement.Builder advancement,
                         ResourceLocation advancementId,
                         Item result,
                         CraftingBookCategory category) {
            super(category);
            this.serializer = serializer;
            this.id = id;
            this.targetIngredient = targetIngredient;
            this.ingredients = ingredients;
            this.advancement = advancement;
            this.advancementId = advancementId;
            this.result = result;
        }

        @Override
        public @NotNull ResourceLocation m_6445_() {
            return id;
        }

        @Override
        public @NotNull RecipeSerializer<?> m_6637_() {
            return serializer;
        }

        @Override
        public void m_7917_(@NotNull JsonObject json) {
            super.m_7917_(json);
            json.add(serializer.target(), targetIngredient.m_43942_());
            JsonArray jsonArray = new JsonArray();

            for (Ingredient ingredient : this.ingredients) {
                jsonArray.add(ingredient.m_43942_());
            }

            json.add("ingredients", jsonArray);

            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("item", BuiltInRegistries.f_257033_.m_7981_(this.result).toString());

            json.add("result", jsonObject);
        }

        @javax.annotation.Nullable
        @Override
        public JsonObject m_5860_() {
            return this.advancement.m_138400_();
        }

        @javax.annotation.Nullable
        @Override
        public ResourceLocation m_6448_() {
            return this.advancementId;
        }
    }
}
