package io.github.mortuusars.exposure.forge.datagen;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.util.ExtraData;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.camera.frame.Photographer;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.PackOutput;
import net.minecraft.data.loot.LootTableProvider;
import net.minecraft.data.loot.packs.VanillaBlockLoot;
import net.minecraft.data.loot.packs.VanillaChestLoot;
import net.minecraft.data.recipes.*;
import net.minecraft.data.tags.EntityTypeTagsProvider;
import net.minecraft.data.tags.ItemTagsProvider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.ValidationContext;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.SetNbtFunction;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraftforge.client.model.generators.BlockStateProvider;
import net.minecraftforge.common.data.BlockTagsProvider;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.data.event.GatherDataEvent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class ExposureDatagen {
    public static void gather(GatherDataEvent event) {
        DataGenerator generator = event.getGenerator();
        PackOutput packOutput = generator.getPackOutput();
        CompletableFuture<HolderLookup.Provider> lookupProvider = event.getLookupProvider();
        ExistingFileHelper existingFileHelper = event.getExistingFileHelper();
        generator.addProvider(true, new Blockstates(packOutput, existingFileHelper));
        generator.addProvider(true, new Recipes(packOutput));
        generator.addProvider(true, LootTables.create(packOutput));

        BlockTagsProvider blockTagsProvider = new ModBlockTags(packOutput, lookupProvider, existingFileHelper);
        generator.addProvider(true, blockTagsProvider);
        generator.addProvider(true, new ModItemTags(packOutput, lookupProvider, blockTagsProvider.m_274426_(), existingFileHelper));
        generator.addProvider(true, new ModEntityTypeTags(packOutput, lookupProvider, existingFileHelper));

        generator.addProvider(true, new ExposureAdvancements(packOutput, lookupProvider, existingFileHelper, List.of(new ExposureAdvancementGenerator())));
        generator.addProvider(true, new ExposureDatapackRegistryProvider(packOutput, lookupProvider, Set.of(Exposure.ID)));
    }

    static class Blockstates extends BlockStateProvider {

        public Blockstates(PackOutput output, ExistingFileHelper exFileHelper) {
            super(output, Exposure.ID, exFileHelper);
        }

        @Override
        protected void registerStatesAndModels() {
        }
    }

    static class ModItemTags extends ItemTagsProvider {
        public ModItemTags(PackOutput arg, CompletableFuture<HolderLookup.Provider> completableFuture, CompletableFuture<TagLookup<Block>> completableFuture2, @Nullable ExistingFileHelper existingFileHelper) {
            super(arg, completableFuture, completableFuture2, Exposure.ID, existingFileHelper);
        }

        @Override
        protected void m_6577_(HolderLookup.@NotNull Provider provider) {
            m_206424_(Exposure.Tags.Items.PHOTO_AGERS).m_255245_(Items.f_42495_).m_176839_(new ResourceLocation("supplementaries:antique_ink"));
            m_206424_(ItemTags.f_244646_).m_255179_(Exposure.Items.ALBUM.get(), Exposure.Items.SIGNED_ALBUM.get());
            m_206424_(ItemTags.f_13162_).m_255179_(Exposure.Items.ALBUM.get(), Exposure.Items.SIGNED_ALBUM.get());
        }
    }

    static class ModEntityTypeTags extends EntityTypeTagsProvider {
        public ModEntityTypeTags(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, @Nullable ExistingFileHelper existingFileHelper) {
            super(output, lookupProvider, Exposure.ID, existingFileHelper);
        }

        @Override
        protected void m_6577_(HolderLookup.@NotNull Provider provider) {
            m_206424_(Exposure.Tags.Entities.IGNORES_CAMERA).m_255179_(
                  EntityType.f_217015_,
                  EntityType.f_20496_,
                  EntityType.f_20565_,
                  EntityType.f_20563_,
                  EntityType.f_20509_);
        }
    }

    static class ModBlockTags extends BlockTagsProvider {
        public ModBlockTags(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, @Nullable ExistingFileHelper existingFileHelper) {
            super(output, lookupProvider, Exposure.ID, existingFileHelper);
        }

        @Override
        protected void m_6577_(HolderLookup.@NotNull Provider provider) {
            m_206424_(BlockTags.f_144280_).m_255245_(Exposure.Blocks.LIGHTROOM.get());
        }
    }

    static class Recipes extends RecipeProvider {

        public Recipes(PackOutput output) {
            super(output);
        }

        @Override
        protected void m_245200_(@NotNull Consumer<FinishedRecipe> writer) {

            Ingredient ironIngot = Ingredient.m_43929_(Items.f_42416_);
            Ingredient goldIngot = Ingredient.m_43929_(Items.f_42417_);

            ShapelessRecipeBuilder.m_245498_(RecipeCategory.TOOLS, Exposure.Items.ALBUM.get())
                  .m_126209_(Items.f_42614_)
                  .m_126209_(Items.f_42714_)
                  .m_126132_(m_176602_(Items.f_42714_), m_125977_(Items.f_42714_))
                  .m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.TOOLS, Exposure.Items.BLACK_AND_WHITE_FILM.get())
                  .m_126127_('B', Items.f_42499_)
                  .m_126127_('G', Items.f_42403_)
                  .m_126124_('I', ironIngot)
                  .m_126127_('K', Items.f_42576_)
                  .m_126127_('N', Items.f_42749_)
                  .m_126130_("NBB")
                  .m_126130_("IGG")
                  .m_126130_("IKK")
                  .m_126132_(m_176602_(Items.f_42576_), m_125977_(Items.f_42576_)).m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.TOOLS, Exposure.Items.CAMERA.get())
                  .m_206416_('B', ItemTags.f_13171_)
                  .m_126127_('G', Items.f_42027_) //glass_panes colorless
                  .m_126124_('I', ironIngot)
                  .m_126127_('L', Items.f_41966_)
                  .m_126130_("LIB")
                  .m_126130_("IGI")
                  .m_126130_("III")
                  .m_126132_(m_176602_(Items.f_41966_), m_125977_(Items.f_41966_)).m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.TOOLS, Exposure.Items.CAMERA_STAND.get())
                  .m_126127_('S', Items.f_42398_)
                  .m_126127_('B', Items.f_41923_)
                  .m_126124_('I', ironIngot)
                  .m_126130_(" I ")
                  .m_126130_("SSS")
                  .m_126130_("BSB")
                  .m_126132_(m_176602_(Items.f_41923_), m_125977_(Items.f_41923_)).m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.TOOLS, Exposure.Items.COLOR_FILM.get())
                  .m_126127_('L', Items.f_42534_)
                  .m_126127_('G', Items.f_42403_)
                  .m_126124_('I', goldIngot)
                  .m_126127_('K', Items.f_42576_)
                  .m_126127_('N', Items.f_42587_)
                  .m_126130_("NLL")
                  .m_126130_("IGG")
                  .m_126130_("IKK")
                  .m_126132_(m_176602_(Items.f_42576_), m_125977_(Items.f_42576_)).m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.DECORATIONS, Exposure.Items.PHOTOGRAPH_FRAME.get())
                  .m_206416_('P', ItemTags.f_13168_)
                  .m_126127_('F', Items.f_42617_)
                  .m_126127_('S', Items.f_42398_)
                  .m_126130_("SPS")
                  .m_126130_("PFP")
                  .m_126130_("SPS")
                  .m_126132_(m_176602_(Items.f_42617_), m_125977_(Items.f_42617_)).m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.DECORATIONS, Exposure.Items.GLASS_PHOTOGRAPH_FRAME.get())
                  .m_126127_('P', Items.f_42027_)
                  .m_126127_('F', Exposure.Items.PHOTOGRAPH_FRAME.get())
                  .m_126130_(" P ")
                  .m_126130_("PFP")
                  .m_126130_(" P ")
                  .m_126132_(m_176602_(Exposure.Items.PHOTOGRAPH_FRAME.get()), m_125977_(Exposure.Items.PHOTOGRAPH_FRAME.get())).m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.TOOLS, Exposure.Items.HIGH_SENSITIVITY_BLACK_AND_WHITE_FILM.get())
                  .m_126127_('B', Items.f_42499_)
                  .m_126127_('P', Items.f_42696_)
                  .m_126124_('I', ironIngot)
                  .m_126127_('K', Items.f_42576_)
                  .m_126127_('N', Items.f_42749_)
                  .m_126130_("NBB")
                  .m_126130_("IPP")
                  .m_126130_("IKK")
                  .m_126132_(m_176602_(Items.f_42576_), m_125977_(Items.f_42576_)).m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.TOOLS, Exposure.Items.HIGH_SENSITIVITY_COLOR_FILM.get())
                  .m_126127_('L', Items.f_42534_)
                  .m_126127_('P', Items.f_42696_)
                  .m_126124_('I', goldIngot)
                  .m_126127_('K', Items.f_42576_)
                  .m_126127_('N', Items.f_42587_)
                  .m_126130_("NLL")
                  .m_126130_("IPP")
                  .m_126130_("IKK")
                  .m_126132_(m_176602_(Items.f_42576_), m_125977_(Items.f_42576_)).m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.TOOLS, Exposure.Items.INTERPLANAR_PROJECTOR.get())
                  .m_126127_('P', Items.f_151011_)
                  .m_126127_('R', Items.f_42451_)
                  .m_126127_('E', Items.f_42545_)
                  .m_126130_("PRP")
                  .m_126130_("RER")
                  .m_126130_("PRP")
                  .m_126132_(m_176602_(Items.f_42545_), m_125977_(Items.f_42545_)).m_176498_(writer);

            ShapedRecipeBuilder.m_245327_(RecipeCategory.DECORATIONS, Exposure.Items.LIGHTROOM.get())
                  .m_126127_('I', Items.f_42128_)
                  .m_206416_('P', ItemTags.f_13168_)
                  .m_126127_('T', Items.f_41978_)
                  .m_126130_("IT")
                  .m_126130_("PP")
                  .m_126130_("PP")
                  .m_126132_(m_176602_(Items.f_41978_), m_125977_(Items.f_41978_))
                  .m_176498_(writer);

            ExposureRecipeBuilder.exposure(Exposure.RecipeSerializers.PHOTOGRAPH_AGING.get(),
                        RecipeCategory.MISC,
                        Exposure.Items.PHOTOGRAPH.get(),
                        Exposure.Items.AGED_PHOTOGRAPH.get())
                  .with(Exposure.Tags.Items.PHOTO_AGERS)
                  .with(Items.f_271356_)
                  .m_126132_(m_176602_(Exposure.Items.PHOTOGRAPH.get()), m_125977_(Exposure.Items.PHOTOGRAPH.get()))
                  .m_176498_(writer);

            ExposureRecipeBuilder.exposure(Exposure.RecipeSerializers.PHOTOGRAPH_COPYING.get(),
                        RecipeCategory.MISC,
                        Exposure.Items.PHOTOGRAPH.get(),
                        Exposure.Items.PHOTOGRAPH.get())
                  .with(Exposure.Tags.Items.PHOTO_PAPERS)
                  .with(Exposure.Tags.Items.BLACK_PRINTING_DYES)
                  .with(Exposure.Tags.Items.YELLOW_PRINTING_DYES)
                  .with(Exposure.Tags.Items.CYAN_PRINTING_DYES)
                  .with(Exposure.Tags.Items.MAGENTA_PRINTING_DYES)
                  .m_126132_(m_176602_(Exposure.Items.PHOTOGRAPH.get()), m_125977_(Exposure.Items.PHOTOGRAPH.get()))
                  .m_126140_(writer, Exposure.resource("photograph_copying"));

            ExposureRecipeBuilder.exposure(Exposure.RecipeSerializers.COMPONENT_TRANSFERRING.get(),
                        RecipeCategory.MISC,
                        Exposure.Items.BROKEN_INTERPLANAR_PROJECTOR.get(),
                        Exposure.Items.INTERPLANAR_PROJECTOR.get())
                  .with(Items.f_42545_)
                  .m_126132_(
                        m_176602_(Exposure.Items.BROKEN_INTERPLANAR_PROJECTOR.get()),
                        m_125977_(Exposure.Items.BROKEN_INTERPLANAR_PROJECTOR.get()))
                  .m_126140_(writer, Exposure.resource("broken_interplanar_projector_fixing"));
        }
    }

    static class LootTables extends LootTableProvider {
        public LootTables(PackOutput output, Set<ResourceLocation> requiredTables, List<SubProviderEntry> subProviders) {
            super(output, requiredTables, subProviders);
        }

        public static LootTableProvider create(PackOutput pOutput) {
            return new LootTables(pOutput, BuiltInLootTables.m_78766_(),
                  List.of(
                        new SubProviderEntry(ChestLoot::new, LootContextParamSets.f_81411_),
                        new SubProviderEntry(BlockLoot::new, LootContextParamSets.f_81421_)
                  ));
        }

        static class BlockLoot extends VanillaBlockLoot {
            @Override
            public void m_245660_() {
                m_246481_(Exposure.Blocks.LIGHTROOM.get(), this::m_246180_);
            }

            @SuppressWarnings("deprecation")
            @Override
            protected @NotNull Iterable<Block> getKnownBlocks() {
                return BuiltInRegistries.f_256975_.m_123024_().filter(block -> BuiltInRegistries.f_256975_.m_7981_(block).m_135827_().equals(Exposure.ID))
                      .toList();
            }
        }

        static class ChestLoot extends VanillaChestLoot {

            @Override
            public void m_245126_(BiConsumer<ResourceLocation, LootTable.Builder> biConsumer) {
                {
                    ItemStack stack = Exposure.Items.PHOTOGRAPH.get().m_7968_();

                    Exposure.DataComponents.setPhotographFrame(stack, new Frame(ExposureIdentifier.texture(
                          Exposure.resource("textures/exposure/dungeon/skull_on_fire.png")),
                          ExposureType.COLOR,
                          Photographer.EMPTY,
                          Collections.emptyList(),
                          ExtraData.EMPTY));

                    biConsumer.accept(Exposure.LootTables.SIMPLE_DUNGEON_INJECT,
                          LootTable.m_79147_().m_79161_(LootPool.m_79043_()
                                .m_165133_(ConstantValue.m_165692_(1.0F))
                                .m_79076_(LootItem.m_79579_(Exposure.Items.PHOTOGRAPH.get())
                                      .m_79078_(SetNbtFunction.m_81187_(stack.m_41783_()))
                                )
                                .m_79080_(LootItemRandomChanceCondition.m_81927_(.1f)
                                )
                          )
                    );
                }
                {
                    ItemStack stack1 = Exposure.Items.PHOTOGRAPH.get().m_7968_();

                    Exposure.DataComponents.setPhotographFrame(stack1, new Frame(ExposureIdentifier.texture(
                          Exposure.resource("textures/exposure/mineshaft/tunnel.png")),
                          ExposureType.COLOR,
                          Photographer.EMPTY,
                          Collections.emptyList(),
                          ExtraData.EMPTY));

                    ItemStack stack2 = Exposure.Items.PHOTOGRAPH.get().m_7968_();

                    Exposure.DataComponents.setPhotographFrame(stack2, new Frame(ExposureIdentifier.texture(
                          Exposure.resource("textures/exposure/mineshaft/skeleton.png")),
                          ExposureType.COLOR,
                          Photographer.EMPTY,
                          Collections.emptyList(),
                          ExtraData.EMPTY));

                    ItemStack stack3 = Exposure.Items.PHOTOGRAPH.get().m_7968_();

                    Exposure.DataComponents.setPhotographFrame(stack3, new Frame(ExposureIdentifier.texture(
                          Exposure.resource("textures/exposure/mineshaft/skeleton_smirk.png")),
                          ExposureType.COLOR,
                          Photographer.EMPTY,
                          Collections.emptyList(),
                          ExtraData.EMPTY));

                    biConsumer.accept(Exposure.LootTables.ABANDONED_MINESHAFT_INJECT,
                          LootTable.m_79147_().m_79161_(LootPool.m_79043_()
                                .m_165133_(ConstantValue.m_165692_(1.0F))
                                .m_79076_(LootItem.m_79579_(Exposure.Items.PHOTOGRAPH.get())
                                      .m_79078_(SetNbtFunction.m_81187_(stack1.m_41783_())).m_79707_(3)
                                )
                                .m_79076_(LootItem.m_79579_(Exposure.Items.PHOTOGRAPH.get())
                                      .m_79078_(SetNbtFunction.m_81187_(stack2.m_41783_())).m_79707_(3)
                                )
                                .m_79076_(LootItem.m_79579_(Exposure.Items.PHOTOGRAPH.get())
                                      .m_79078_(SetNbtFunction.m_81187_(stack3.m_41783_())).m_79707_(1)
                                )
                                .m_79080_(LootItemRandomChanceCondition.m_81927_(.2f)
                                )
                          )
                    );
                }
                {
                    ItemStack stack1 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                    Exposure.DataComponents.setPhotographFrame(stack1, new Frame(ExposureIdentifier.texture(
                          Exposure.resource("textures/exposure/shipwreck/ship_dock_1.png")),
                          ExposureType.COLOR,
                          Photographer.EMPTY,
                          Collections.emptyList(),
                          ExtraData.EMPTY));

                    ItemStack stack2 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                    Exposure.DataComponents.setPhotographFrame(stack2, new Frame(ExposureIdentifier.texture(
                          Exposure.resource("textures/exposure/shipwreck/ship_dock_2.png")),
                          ExposureType.COLOR,
                          Photographer.EMPTY,
                          Collections.emptyList(),
                          ExtraData.EMPTY));

                    ItemStack stack3 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                    Exposure.DataComponents.setPhotographFrame(stack3, new Frame(ExposureIdentifier.texture(
                          Exposure.resource("textures/exposure/shipwreck/ship_dock_3.png")),
                          ExposureType.COLOR,
                          Photographer.EMPTY,
                          Collections.emptyList(),
                          ExtraData.EMPTY));

                    ItemStack stack4 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                    Exposure.DataComponents.setPhotographFrame(stack4, new Frame(ExposureIdentifier.texture(
                          Exposure.resource("textures/exposure/shipwreck/ship_dock_4.png")),
                          ExposureType.COLOR,
                          Photographer.EMPTY,
                          Collections.emptyList(),
                          ExtraData.EMPTY));

                    ItemStack film1Stack = film1();
                    ItemStack film2Stack = film2();

                    biConsumer.accept(Exposure.LootTables.SHIPWRECK_MAP_INJECT,
                          LootTable.m_79147_()
                                .m_79161_(LootPool.m_79043_()
                                      .m_165133_(ConstantValue.m_165692_(1.0F))
                                      .m_79076_(LootItem.m_79579_(Exposure.Items.AGED_PHOTOGRAPH.get())
                                            .m_79078_(SetNbtFunction.m_81187_(stack1.m_41783_()))
                                      )
                                      .m_79076_(LootItem.m_79579_(Exposure.Items.AGED_PHOTOGRAPH.get())
                                            .m_79078_(SetNbtFunction.m_81187_(stack2.m_41783_()))
                                      )
                                      .m_79080_(LootItemRandomChanceCondition.m_81927_(.1f)
                                      )
                                )
                                .m_79161_(LootPool.m_79043_()
                                      .m_165133_(ConstantValue.m_165692_(1.0F))
                                      .m_79076_(LootItem.m_79579_(Exposure.Items.AGED_PHOTOGRAPH.get())
                                            .m_79078_(SetNbtFunction.m_81187_(stack3.m_41783_()))
                                      )
                                      .m_79076_(LootItem.m_79579_(Exposure.Items.AGED_PHOTOGRAPH.get())
                                            .m_79078_(SetNbtFunction.m_81187_(stack4.m_41783_()))
                                      )
                                      .m_79080_(LootItemRandomChanceCondition.m_81927_(.1f)
                                      )
                                )
                                .m_79161_(LootPool.m_79043_()
                                      .m_165133_(ConstantValue.m_165692_(1.0F))
                                      .m_79076_(LootItem.m_79579_(Exposure.Items.BLACK_AND_WHITE_FILM.get())
                                            .m_79078_(SetNbtFunction.m_81187_(film1Stack.m_41783_()))
                                      )
                                      .m_79076_(LootItem.m_79579_(Exposure.Items.BLACK_AND_WHITE_FILM.get())
                                            .m_79078_(SetNbtFunction.m_81187_(film2Stack.m_41783_()))
                                      )
                                      .m_79080_(LootItemRandomChanceCondition.m_81927_(.15f)
                                      )
                                )
                                .m_79161_(LootPool.m_79043_()
                                      .m_165133_(ConstantValue.m_165692_(2))
                                      .m_79076_(LootItem.m_79579_(Items.f_42190_)
                                      )
                                      .m_79076_(LootItem.m_79579_(Items.f_42189_)
                                      )
                                      .m_79076_(LootItem.m_79579_(Items.f_42187_)
                                      )
                                      .m_79080_(LootItemRandomChanceCondition.m_81927_(.3f)
                                      )
                                )
                    );
                }

                ItemStack photoCorridor1 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                Exposure.DataComponents.setPhotographFrame(photoCorridor1, new Frame(ExposureIdentifier.texture(
                      Exposure.resource("textures/exposure/stronghold/corridor_1.png")),
                      ExposureType.COLOR,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      ExtraData.EMPTY));

                ItemStack photoCorridor2 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                Exposure.DataComponents.setPhotographFrame(photoCorridor2, new Frame(ExposureIdentifier.texture(
                      Exposure.resource("textures/exposure/stronghold/corridor_2.png")),
                      ExposureType.COLOR,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      ExtraData.EMPTY));

                ItemStack photoCorridor3 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                Exposure.DataComponents.setPhotographFrame(photoCorridor3, new Frame(ExposureIdentifier.texture(
                      Exposure.resource("textures/exposure/stronghold/corridor_3.png")),
                      ExposureType.COLOR,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      ExtraData.EMPTY));

                ItemStack photoCorridor4 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                Exposure.DataComponents.setPhotographFrame(photoCorridor4, new Frame(ExposureIdentifier.texture(
                      Exposure.resource("textures/exposure/stronghold/corridor_4.png")),
                      ExposureType.COLOR,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      ExtraData.EMPTY));

                biConsumer.accept(Exposure.LootTables.STRONGHOLD_CROSSING_INJECT,
                      LootTable.m_79147_().m_79161_(LootPool.m_79043_()
                            .m_165133_(ConstantValue.m_165692_(1.0F))
                            .m_79076_(
                                  LootItem.m_79579_(photoCorridor1.m_41720_())
                                        .m_79078_(SetNbtFunction.m_81187_(photoCorridor1.m_41783_()))
                            )
                            .m_79076_(
                                  LootItem.m_79579_(photoCorridor2.m_41720_())
                                        .m_79078_(SetNbtFunction.m_81187_(photoCorridor2.m_41783_()))
                            )
                            .m_79076_(
                                  LootItem.m_79579_(photoCorridor3.m_41720_())
                                        .m_79078_(SetNbtFunction.m_81187_(photoCorridor3.m_41783_()))
                            )
                            .m_79076_(
                                  LootItem.m_79579_(photoCorridor4.m_41720_())
                                        .m_79078_(SetNbtFunction.m_81187_(photoCorridor4.m_41783_()))
                            )
                            .m_79080_(LootItemRandomChanceCondition.m_81927_(.3f)
                            )
                      )
                );

                ItemStack photoVillageAttack1 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                Exposure.DataComponents.setPhotographFrame(photoVillageAttack1, new Frame(ExposureIdentifier.texture(
                      Exposure.resource("textures/exposure/village/attack_1.png")),
                      ExposureType.COLOR,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      ExtraData.EMPTY));

                ItemStack photoVillageAttack2 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                Exposure.DataComponents.setPhotographFrame(photoVillageAttack2, new Frame(ExposureIdentifier.texture(
                      Exposure.resource("textures/exposure/village/attack_2.png")),
                      ExposureType.COLOR,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      ExtraData.EMPTY));

                //////////

                ItemStack photoVillage1 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                Exposure.DataComponents.setPhotographFrame(photoVillage1, new Frame(ExposureIdentifier.texture(
                      Exposure.resource("textures/exposure/village/village_1.png")),
                      ExposureType.COLOR,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      ExtraData.EMPTY));

                ItemStack photoVillage2 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                Exposure.DataComponents.setPhotographFrame(photoVillage2, new Frame(ExposureIdentifier.texture(
                      Exposure.resource("textures/exposure/village/village_2.png")),
                      ExposureType.COLOR,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      ExtraData.EMPTY));

                ItemStack photoVillage3 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                Exposure.DataComponents.setPhotographFrame(photoVillage3, new Frame(ExposureIdentifier.texture(
                      Exposure.resource("textures/exposure/village/village_3.png")),
                      ExposureType.COLOR,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      ExtraData.EMPTY));

                ItemStack photoVillage4 = Exposure.Items.AGED_PHOTOGRAPH.get().m_7968_();

                Exposure.DataComponents.setPhotographFrame(photoVillage4, new Frame(ExposureIdentifier.texture(
                      Exposure.resource("textures/exposure/village/village_4.png")),
                      ExposureType.COLOR,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      ExtraData.EMPTY));

                biConsumer.accept(Exposure.LootTables.VILLAGE_PLAINS_HOUSE_INJECT,
                      LootTable.m_79147_().m_79161_(LootPool.m_79043_()
                                  .m_165133_(ConstantValue.m_165692_(1.0F))
                                  .m_79076_(
                                        LootItem.m_79579_(photoVillage1.m_41720_())
                                              .m_79078_(SetNbtFunction.m_81187_(photoVillage1.m_41783_()))
                                  )
                                  .m_79076_(
                                        LootItem.m_79579_(photoVillage2.m_41720_())
                                              .m_79078_(SetNbtFunction.m_81187_(photoVillage2.m_41783_()))
                                  )
                                  .m_79076_(
                                        LootItem.m_79579_(photoVillage3.m_41720_())
                                              .m_79078_(SetNbtFunction.m_81187_(photoVillage3.m_41783_()))
                                  )
                                  .m_79076_(
                                        LootItem.m_79579_(photoVillage4.m_41720_())
                                              .m_79078_(SetNbtFunction.m_81187_(photoVillage4.m_41783_()))
                                  )
                                  .m_79080_(LootItemRandomChanceCondition.m_81927_(.3f)
                                  )
                            )
                            .m_79161_(
                                  LootPool.m_79043_()
                                        .m_165133_(ConstantValue.m_165692_(1.0F))
                                        .m_79076_(
                                              LootItem.m_79579_(photoVillageAttack1.m_41720_())
                                                    .m_79078_(SetNbtFunction.m_81187_(photoVillageAttack1.m_41783_()))
                                        )
                                        .m_79076_(
                                              LootItem.m_79579_(photoVillageAttack2.m_41720_())
                                                    .m_79078_(SetNbtFunction.m_81187_(photoVillageAttack2.m_41783_()))
                                        )
                                        .m_79080_(LootItemRandomChanceCondition.m_81927_(.15f)
                                        )
                            )
                );
            }

            protected ItemStack film1() {
                ItemStack filmStack = Exposure.Items.BLACK_AND_WHITE_FILM.get().m_7968_();
                Exposure.DataComponents.setFilmFrameSize(filmStack, 56);

                List<Frame> frames = new ArrayList<>();

                frames.addAll(colorSet("textures/exposure/shipwreck/chromatic/cargo_crates"));
                frames.addAll(colorSet("textures/exposure/shipwreck/chromatic/deck_sunset_1"));
                frames.addAll(colorSet("textures/exposure/shipwreck/chromatic/deck_sunset_2"));

                Exposure.DataComponents.setFilmFrames(filmStack, frames);
                return filmStack;
            }

            protected ItemStack film2() {
                ItemStack filmStack = Exposure.Items.BLACK_AND_WHITE_FILM.get().m_7968_();
                Exposure.DataComponents.setFilmFrameSize(filmStack, 56);

                List<Frame> frames = new ArrayList<>();

                frames.addAll(colorSet("textures/exposure/shipwreck/chromatic/cargo_gold_1"));
                frames.addAll(colorSet("textures/exposure/shipwreck/chromatic/cargo_gold_2"));
                frames.addAll(colorSet("textures/exposure/shipwreck/chromatic/deck_sunset_3"));
                frames.addAll(colorSet("textures/exposure/shipwreck/chromatic/deck_sunset_4"));

                Exposure.DataComponents.setFilmFrames(filmStack, frames);
                return filmStack;
            }

            List<Frame> colorSet(String s) {
                List<Frame> frames = new ArrayList<>();
                CompoundTag tagR = new CompoundTag();
                tagR.m_128359_("color_channel", "red");

                CompoundTag tagG = new CompoundTag();
                tagG.m_128359_("color_channel", "green");

                CompoundTag tagB = new CompoundTag();
                tagB.m_128359_("color_channel", "blue");
                frames.add(new Frame(
                      ExposureIdentifier.texture(Exposure.resource(s + "_r.png")),
                      ExposureType.BLACK_AND_WHITE,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      new ExtraData(tagR)));

                frames.add(new Frame(
                      ExposureIdentifier.texture(Exposure.resource(s + "_g.png")),
                      ExposureType.BLACK_AND_WHITE,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      new ExtraData(tagG)));

                frames.add(new Frame(
                      ExposureIdentifier.texture(Exposure.resource(s + "_b.png")),
                      ExposureType.BLACK_AND_WHITE,
                      Photographer.EMPTY,
                      Collections.emptyList(),
                      new ExtraData(tagB)));
                return frames;
            }

        }

        @Override
        protected void validate(@NotNull Map<ResourceLocation, LootTable> map, @NotNull ValidationContext validationtracker) {
        }
    }
}
