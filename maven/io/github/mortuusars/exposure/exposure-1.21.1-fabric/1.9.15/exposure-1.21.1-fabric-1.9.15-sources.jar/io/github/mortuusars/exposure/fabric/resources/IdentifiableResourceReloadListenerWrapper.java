package io.github.mortuusars.exposure.fabric.resources;

import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public class IdentifiableResourceReloadListenerWrapper implements IdentifiableResourceReloadListener {
	private final class_2960 fabricId;
	private final class_3302 listener;

	public IdentifiableResourceReloadListenerWrapper(class_2960 id, class_3302 listener) {
		this.fabricId = id;
		this.listener = listener;
	}

	@Override
	public class_2960 getFabricId() {
		return this.fabricId;
	}

	@Override
	public @NotNull CompletableFuture<Void> reload(PreparationBarrier preparationBarrier, class_3300 resourceManager, class_3695 profilerFiller, class_3695 profilerFiller2, Executor executor, Executor executor2) {
		return listener.method_25931(preparationBarrier, resourceManager, profilerFiller, profilerFiller2, executor, executor2);
	}
}
