package io.github.mortuusars.exposure.fabric.resources;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.client.ExposureClientReloadListener;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2960;

public class ExposureFabricClientReloadListener extends ExposureClientReloadListener implements IdentifiableResourceReloadListener {
    public static final class_2960 ID = Exposure.resource("clear_client_exposures_cache");
    @Override
    public class_2960 getFabricId() {
        return ID;
    }
}
