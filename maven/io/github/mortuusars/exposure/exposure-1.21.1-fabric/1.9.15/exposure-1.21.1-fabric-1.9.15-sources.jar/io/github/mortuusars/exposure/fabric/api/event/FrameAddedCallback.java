package io.github.mortuusars.exposure.fabric.api.event;

import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import java.util.List;

/**
 * Fired at the very end of a shot, when frame is added to the film.
 * Fired only on the server side.
 */
public interface FrameAddedCallback {
    Event<FrameAddedCallback> EVENT = EventFactory.createArrayBacked(FrameAddedCallback.class,
            (listeners) -> (cameraHolder, camera, frame, positionsInFrame, entitiesInFrame) -> {
                for (FrameAddedCallback listener : listeners) {
                    listener.frameAdded(cameraHolder, camera, frame, positionsInFrame, entitiesInFrame);
                }
            });

    void frameAdded(CameraHolder cameraHolder, class_1799 camera, Frame frame, List<class_2338> positionsInFrame, List<class_1309> entitiesInFrame);
}