package io.github.mortuusars.exposure.network.fabric;

import io.github.mortuusars.exposure.network.packet.CommonPackets;
import io.github.mortuusars.exposure.network.packet.S2CPackets;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public class FabricS2CPackets {
    @SuppressWarnings("unchecked")
    public static void register() {
        for (var definition : S2CPackets.getDefinitions()) {
            PayloadTypeRegistry.playS2C().register(
                    (class_8710.class_9154<class_8710>) definition.type(),
                    (class_9139<class_2540, class_8710>) definition.codec());
        }

        for (var definition : CommonPackets.getDefinitions()) {
            PayloadTypeRegistry.playS2C().register(
                    (class_8710.class_9154<class_8710>) definition.type(),
                    (class_9139<class_2540, class_8710>) definition.codec());
        }
    }
}
