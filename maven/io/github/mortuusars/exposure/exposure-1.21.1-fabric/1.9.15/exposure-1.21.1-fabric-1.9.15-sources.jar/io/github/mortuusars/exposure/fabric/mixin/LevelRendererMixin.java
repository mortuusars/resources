package io.github.mortuusars.exposure.fabric.mixin;

import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4599;
import net.minecraft.class_4618;
import net.minecraft.class_5253;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import net.minecraft.client.renderer.*;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class LevelRendererMixin {
    @Shadow private int renderedEntities;
    @Final @Shadow private class_4599 renderBuffers;
    @Shadow protected abstract boolean shouldShowEntityOutlines();
    @Shadow private void renderEntity(class_1297 entity, double camX, double camY, double camZ, float partialTick, class_4587 poseStack, class_4597 bufferSource) {}

    @Inject(method = "renderLevel", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/ClientLevel;entitiesForRendering()Ljava/lang/Iterable;"))
    private void onRenderLevel(class_9779 deltaTracker, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, class_765 lightTexture, Matrix4f frustumMatrix, Matrix4f projectionMatrix, CallbackInfo ci) {
        if (camera.method_19331() instanceof CameraStandEntity) {
            exposure$renderEntity(deltaTracker, camera, Minecrft.player());
        }
    }

    @Unique
    private void exposure$renderEntity(class_9779 deltaTracker, class_4184 camera, class_1297 entity) {
        this.renderedEntities++;
        if (entity.field_6012 == 0) {
            entity.field_6038 = entity.method_23317();
            entity.field_5971 = entity.method_23318();
            entity.field_5989 = entity.method_23321();
        }

        class_4597 multiBufferSource;
        if (this.shouldShowEntityOutlines() && Minecrft.get().shouldEntityAppearGlowing(entity)) {
            class_4618 outlineBufferSource = this.renderBuffers.method_23003();
            multiBufferSource = outlineBufferSource;
            int i = entity.method_22861();
            outlineBufferSource.method_23286(class_5253.class_5254.method_27765(i), class_5253.class_5254.method_27766(i), class_5253.class_5254.method_27767(i), 255);
        } else {
            multiBufferSource = this.renderBuffers.method_23000();
        }

        float partialTick = deltaTracker.method_60637(!Minecrft.level().tickRateManager().isEntityFrozen(entity));
        class_243 position = camera.method_19326();
        class_4587 poseStack = new class_4587();
        this.renderEntity(entity, position.field_1352, position.field_1351, position.field_1350, partialTick, poseStack, multiBufferSource);
    }
}
