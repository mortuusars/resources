package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.data.ColorPalettes;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1799;

public interface FilmItem {
    ExposureType getType();

    // -- Frames

    default int getDefaultMaxFrameCount(class_1799 stack) {
        return 16;
    }

    default int getDefaultFrameSize(class_1799 stack) {
        return Config.Server.DEFAULT_FRAME_SIZE.get();
    }

    default int getMaxFrameCount(class_1799 stack) {
        return Exposure.DataComponents.getFilmFrameCount(stack, getDefaultMaxFrameCount(stack));
    }

    default int getFrameSize(class_1799 stack) {
        return Exposure.DataComponents.getFilmFrameSize(stack, getDefaultFrameSize(stack));
    }

    default List<Frame> getStoredFrames(class_1799 stack) {
        return Exposure.DataComponents.getFilmFrames(stack, Collections.emptyList());
    }

    default int getStoredFramesCount(class_1799 stack) {
        return getStoredFrames(stack).size();
    }

    default boolean hasFrames(class_1799 stack) {
        return !getStoredFrames(stack).isEmpty();
    }

    default boolean hasFrameAt(class_1799 stack, int index) {
        return getStoredFrames(stack).size() > index;
    }

    default float getFullness(class_1799 stack) {
        return (float) getStoredFramesCount(stack) / getMaxFrameCount(stack);
    }

    default boolean isFull(class_1799 stack) {
        return getStoredFramesCount(stack) == getMaxFrameCount(stack);
    }
}
