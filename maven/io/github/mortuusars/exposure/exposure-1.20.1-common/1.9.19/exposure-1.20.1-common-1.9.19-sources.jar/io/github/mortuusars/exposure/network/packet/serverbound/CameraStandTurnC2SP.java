package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record CameraStandTurnC2SP(int entityId, double yRot, double xRot) implements Packet {
    public static final class_2960 ID = Exposure.resource("camera_stand_turn");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.writeInt(entityId);
        buf.writeDouble(yRot);
        buf.writeDouble(xRot);
    }

    public static CameraStandTurnC2SP fromPacket(class_2540 buf) {
        return new CameraStandTurnC2SP(buf.readInt(),buf.readDouble(),buf.readDouble());
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (!(player.method_37908().method_8469(entityId) instanceof CameraStandEntity stand)) return false;
        if (player.equals(stand.operator()) || stand.getOwnerPlayer().map(pl -> pl.equals(player)).orElse(false)) {
            stand.method_5872(yRot, xRot);
        }
        return true;
    }
}