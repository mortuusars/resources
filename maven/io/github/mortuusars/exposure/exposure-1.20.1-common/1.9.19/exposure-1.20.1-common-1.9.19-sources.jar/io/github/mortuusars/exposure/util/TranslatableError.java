package io.github.mortuusars.exposure.util;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public record TranslatableError(String key, String code) {
    public static final TranslatableError GENERIC = new TranslatableError("error.exposure.generic", "ERR_GENERIC");
    public static final TranslatableError TIMED_OUT = new TranslatableError("error.exposure.timed_out", "ERR_TIMED_OUT");

    public static final Codec<TranslatableError> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("key").forGetter(TranslatableError::key),
            Codec.STRING.fieldOf("code").forGetter(TranslatableError::code)
    ).apply(instance, TranslatableError::new));

    public void toPacket(class_2540 buf) {
        buf.method_10814(key);
        buf.method_10814(code);
    }

    public static TranslatableError fromPacket(class_2540 buf) {
        return new TranslatableError(buf.method_19772(),buf.method_19772());
    }

    public class_5250 technical() {
        return class_2561.method_43471(key() + ".technical");
    }

    public class_5250 casual() {
        return class_2561.method_43471(key() + ".casual");
    }
}
