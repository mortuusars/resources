package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.data.export.ExportLook;
import io.github.mortuusars.exposure.data.export.ExportSize;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record ExportS2CP(List<String> ids, ExportSize size, ExportLook look) implements Packet {
    public static final class_2960 ID = Exposure.resource("export");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_34062(ids,class_2540::method_10814);
        buf.method_10817(size);
        buf.method_10817(look);
    }

    public static ExportS2CP fromPacket(class_2540 buf){
        return new ExportS2CP(buf.method_34066(class_2540::method_19772),buf.method_10818(ExportSize.class),buf.method_10818(ExportLook.class));
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        ClientPacketsHandler.exportExposures(this);
        return true;
    }
}
