package io.github.mortuusars.exposure.network.packet;

import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public interface Packet {
    class_2960 getId();
    boolean handle(class_2598 flow, class_1657 player);
    void toPacket(class_2540 buf);
}