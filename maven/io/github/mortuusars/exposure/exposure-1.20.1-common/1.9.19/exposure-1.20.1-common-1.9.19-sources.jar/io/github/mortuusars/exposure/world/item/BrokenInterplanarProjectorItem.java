package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.Exposure;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class BrokenInterplanarProjectorItem extends class_1792 {
    public BrokenInterplanarProjectorItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public void method_7851(class_1799 stack, class_1937 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        if (stack.method_7938()) {
            tooltipComponents.add(class_2561.method_43471("item.exposure.broken_interplanar_projector.tooltip.broken").method_27692(class_124.field_1079));
        }
    }

    public String getErrorCode(class_1799 stack) {
        return Exposure.DataComponents.getInterplanarProjectorErrorCode(stack, "ERR_FAILURE_SEE_LOGS");
    }
}
