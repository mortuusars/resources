package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.world.level.storage.ExposureData;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import io.github.mortuusars.exposure.network.packet.Packet;

public record ExposureDataC2SP(String id, ExposureData exposure) implements Packet {
    public static final class_2960 ID = Exposure.resource("exposure_data");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_10814(id);
        exposure.toPacket(buf);
    }

    public static ExposureDataC2SP fromPacket(class_2540 buf) {
        return new ExposureDataC2SP(buf.method_19772(), ExposureData.fromPacket(buf));
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ExposureServer.exposureRepository().receiveClientUpload(((class_3222) player), id, exposure);
        return true;
    }
}