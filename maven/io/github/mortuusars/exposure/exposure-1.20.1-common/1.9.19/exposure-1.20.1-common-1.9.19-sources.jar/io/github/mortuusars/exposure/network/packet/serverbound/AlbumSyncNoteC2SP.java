package io.github.mortuusars.exposure.network.packet.serverbound;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.inventory.AlbumMenu;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import io.github.mortuusars.exposure.network.packet.Packet;

public record AlbumSyncNoteC2SP(int pageIndex, String text) implements Packet {
    public static final class_2960 ID = Exposure.resource("album_update_note");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.writeInt(pageIndex);
        buf.method_10814(text);
    }

    public static AlbumSyncNoteC2SP fromPacket(class_2540 buf){
        return new AlbumSyncNoteC2SP(buf.readInt(),buf.method_19772());
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        Preconditions.checkState(player != null, "Cannot handle packet: Player was null");

        if (!(player.field_7512 instanceof AlbumMenu albumMenu)) {
            throw new IllegalStateException("Player receiving this packet should have AlbumMenu open. " +
                    "Current menu: " + player.field_7512);
        }

        albumMenu.updatePage(pageIndex, page -> page.setNote(text));
        return true;
    }
}
