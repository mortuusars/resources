package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record ShaderApplyS2CP(Optional<class_2960> shaderLocation) implements Packet {
    public static final class_2960 ID = Exposure.resource("shader_apply");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public ShaderApplyS2CP(class_2960 location) {
        this(Optional.of(location));
    }

    public static final ShaderApplyS2CP REMOVE = new ShaderApplyS2CP(Optional.empty());

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_37435(shaderLocation,class_2540::method_10812);
    }

    public static ShaderApplyS2CP fromPacket(class_2540 buf) {
        return new ShaderApplyS2CP(buf.method_37436(class_2540::method_10810));
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        ClientPacketsHandler.applyShader(this);
        return true;
    }
}
