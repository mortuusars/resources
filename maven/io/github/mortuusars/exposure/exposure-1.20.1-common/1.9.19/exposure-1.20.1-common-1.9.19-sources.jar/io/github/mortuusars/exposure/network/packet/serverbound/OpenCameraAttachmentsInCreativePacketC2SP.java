package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import io.github.mortuusars.exposure.network.packet.Packet;

public record OpenCameraAttachmentsInCreativePacketC2SP(int cameraSlotIndex) implements Packet {
    public static final class_2960 ID = Exposure.resource("open_camera_attachments");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.writeInt(cameraSlotIndex);
    }

    public static OpenCameraAttachmentsInCreativePacketC2SP fromPacket(class_2540 buf) {
        return new OpenCameraAttachmentsInCreativePacketC2SP(buf.readInt());
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (player instanceof class_3222 serverPlayer) {
            serverPlayer.field_13995.execute(() -> {
                class_1799 stack = player.method_31548().method_5438(cameraSlotIndex);
                if (stack.method_7909() instanceof CameraItem cameraItem)
                    cameraItem.openCameraAttachments(player, cameraSlotIndex, true);
            });
        }

        return true;
    }


}
