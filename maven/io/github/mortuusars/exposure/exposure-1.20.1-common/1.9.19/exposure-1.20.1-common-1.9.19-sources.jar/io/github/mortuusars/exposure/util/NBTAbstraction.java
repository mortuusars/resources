package io.github.mortuusars.exposure.util;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.component.CompositionGuide;
import io.github.mortuusars.exposure.world.camera.component.FlashMode;
import io.github.mortuusars.exposure.world.camera.component.SelfTimer;
import io.github.mortuusars.exposure.world.camera.component.ShutterSpeed;
import org.apache.logging.log4j.util.TriConsumer;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import net.minecraft.class_1799;
import net.minecraft.class_2540;

public record NBTAbstraction<T>(BiFunction<class_1799,String,T> reader, TriConsumer<class_1799,String,T> writer,
                                class_2540.class_7461<T> packetReader, class_2540.class_7462<T> packetWriter){



    public static final NBTAbstraction<Boolean> BOOLEAN = new NBTAbstraction<>(Exposure.DataComponents::getBoolean, Exposure.DataComponents::setBoolean
    ,class_2540::readBoolean,class_2540::writeBoolean);
    public static final NBTAbstraction<Float> FLOAT = new NBTAbstraction<>(Exposure.DataComponents::getFloat, Exposure.DataComponents::setFloat,
            class_2540::readFloat,class_2540::writeFloat);
    public static final NBTAbstraction<Double> DOUBLE = new NBTAbstraction<>(Exposure.DataComponents::getDouble, Exposure.DataComponents::setDouble,
            class_2540::readDouble,class_2540::writeDouble);

    public static final NBTAbstraction<ShutterSpeed> SHUTTER_SPEED = new NBTAbstraction<>(Exposure.DataComponents::getShutterSpeed, Exposure.DataComponents::setShutterSpeed,
            ShutterSpeed::fromPacket,(buf, shutterSpeed) -> shutterSpeed.toPacket(buf));

    public static final NBTAbstraction<CompositionGuide> COMPOSITION_GUIDE = new NBTAbstraction<>(Exposure.DataComponents::getCompositionGuide,
            Exposure.DataComponents::setCompositionGuide,
            CompositionGuide::fromPacket,(buf, shutterSpeed) -> shutterSpeed.toPacket(buf));

    public static final NBTAbstraction<SelfTimer> SELF_TIMER = new NBTAbstraction<>(Exposure.DataComponents::getSelfTimer,
            Exposure.DataComponents::setSelfTimer,
            buf -> buf.method_10818(SelfTimer.class), class_2540::method_10817);

    public static final NBTAbstraction<FlashMode> FLASH_MODE = new NBTAbstraction<>(Exposure.DataComponents::getFlashMode,
            Exposure.DataComponents::setFlashMode,
            buf -> buf.method_10818(FlashMode.class), class_2540::method_10817);

    public static <T> NBTAbstraction.Named<T> named(String key,NBTAbstraction<T> abstraction) {
        return new Named<>(key, abstraction);
    }

    public record Named<T>(String key,NBTAbstraction<T> abstraction) {
        public T read(class_1799 stack) {
            return abstraction.reader.apply(stack,key);
        }

        public void write(class_1799 stack,T value) {
            abstraction.writer.accept(stack,key,value);
        }
    }
}
