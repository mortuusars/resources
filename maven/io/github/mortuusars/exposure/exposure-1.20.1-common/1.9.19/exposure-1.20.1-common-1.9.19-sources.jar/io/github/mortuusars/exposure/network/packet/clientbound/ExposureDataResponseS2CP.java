package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.world.level.storage.RequestedPalettedExposure;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import io.github.mortuusars.exposure.network.packet.Packet;

public record ExposureDataResponseS2CP(String id, RequestedPalettedExposure result) implements Packet {
    public static final class_2960 ID = Exposure.resource("exposure_data_response");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_10814(id);
        result.toPacket(buf);
    }

    public static ExposureDataResponseS2CP fromPacket(class_2540 buf) {
        return new ExposureDataResponseS2CP(buf.method_19772(),RequestedPalettedExposure.fromPacket(buf));
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ExposureClient.exposureStore().receive(id, result);
        return true;
    }
}
