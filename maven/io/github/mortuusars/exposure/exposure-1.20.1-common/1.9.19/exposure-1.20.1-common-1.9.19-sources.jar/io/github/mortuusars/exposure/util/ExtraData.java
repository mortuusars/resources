package io.github.mortuusars.exposure.util;

import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2540;
import net.minecraft.nbt.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Function;

/**
 * Extension of CompoundTag to allow better type safety. <br>
 * {@link NbtType} is meant to be stored in a static final field in appropriate places.
 */
public class ExtraData extends class_2487 {
    public static final Codec<ExtraData> CODEC = class_2487.field_25128.xmap(ExtraData::new, Function.identity());

    public static final ExtraData EMPTY = new ExtraData(Collections.emptyMap());
    private final Map<String, class_2520> tags;

    protected ExtraData(Map<String, class_2520> tags) {
        super(tags);
        this.tags = tags;
    }

    public ExtraData() {
        this(new HashMap<>());
    }

    public ExtraData(class_2487 tag) {
        this(new HashMap<>());
        method_10543(tag);
    }

    public void toPacket(class_2540 buf) {
        buf.method_10794(this);
    }

    public static ExtraData fromPacket(class_2540 buf) {
        return new ExtraData(buf.method_10798());
    }

    public <T> Optional<T> get(@NotNull NbtType<T> type) {
        if (!method_10545(type.key())) return Optional.empty();
        try {
            return Optional.ofNullable(type.getter().apply(this, type.key()));
        } catch (Exception e) {
            Exposure.LOGGER.error("Cannot get ExtraData entry: {}", e.getMessage());
            return Optional.empty();
        }
    }

    public <T> T getOrDefault(@NotNull NbtType<T> type, T defaultValue) {
        if (!method_10545(type.key())) return defaultValue;
        try {
            @Nullable T value = type.getter().apply(this, type.key());
            return value != null ? value : defaultValue;
        } catch (Exception e) {
            Exposure.LOGGER.error("Cannot get ExtraData entry: {}", e.getMessage());
            return defaultValue;
        }
    }

    public <T> void put(NbtType<T> type, @NotNull T value) {
        Preconditions.checkNotNull(value, "value");
        type.setter().accept(this, type.key(), value);
    }

    public <T> void remove(NbtType<T> type) {
        method_10551(type.key());
    }

    // --

    @Override
    public @NotNull ExtraData method_10707() {
        Map<String, class_2520> map = Maps.newHashMap(Maps.transformValues(this.tags, class_2520::method_10707));
        return new ExtraData(map);
    }

    @Override
    public @NotNull ExtraData method_10543(class_2487 other) {
        for (String key : other.method_10541()) {
            class_2520 tag = other.method_10580(key);
            assert tag != null;
            if (tag.method_10711() == 10) {
                if (this.method_10573(key, 10)) {
                    class_2487 compoundTag = this.method_10562(key);
                    compoundTag.method_10543((class_2487) tag);
                } else {
                    this.method_10566(key, tag.method_10707());
                }
            } else {
                this.method_10566(key, tag.method_10707());
            }
        }

        return this;
    }

    // --

}
