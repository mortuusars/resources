package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public record ExposureDataChunkBytesC2SP(String id, int offset, byte[] bytes) implements Packet {
    public static final class_2960 ID = Exposure.resource("exposure_data_chunk_bytes");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buffer) {
        buffer.method_10814(id);
        buffer.writeInt(offset);
        buffer.method_10813(bytes);
    }

    public static ExposureDataChunkBytesC2SP fromPacket(class_2540 buffer) {
        return new ExposureDataChunkBytesC2SP(buffer.method_19772(), buffer.readInt(), buffer.method_10795());
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Exposure.LOGGER.error("Cannot receive '{}' packet. Player is not ServerPlayer.", ID);
            return false;
        }

        ExposureServer.exposureRepository().receiveChunkedClientUploadChunk(serverPlayer, id, offset, bytes);
        return true;
    }
}
