package io.github.mortuusars.exposure.client.gui.screen.album;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ModWidgetSprites;
import io.github.mortuusars.exposure.client.gui.BetterImageButton;
import io.github.mortuusars.exposure.client.gui.screen.element.textbox.HorizontalAlignment;
import io.github.mortuusars.exposure.client.gui.screen.element.textbox.TextBox;
import io.github.mortuusars.exposure.client.util.Minecrft;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_7919;

public class AlbumSigningScreen extends class_437 {

    public static final int SELECTION_COLOR = 0xFF8888FF;
    public static final int SELECTION_UNFOCUSED_COLOR = 0xFFBBBBFF;

    public static final ModWidgetSprites CANCEL_BUTTON_SPRITE = ModWidgetSprites.withPrefix(
            Exposure.resource("album/cancel"), Exposure.resource("album/cancel_disabled"),
            Exposure.resource("album/cancel_highlighted"),22,22);

    protected final AlbumScreen parentScreen;
    private final class_2960 texture;
    private final int textureWidth;
    private final int textureHeight;

    protected int imageWidth, imageHeight, leftPos, topPos;

    protected TextBox titleTextBox;
    protected BetterImageButton signButton;
    protected BetterImageButton cancelSigningButton;

    protected String titleText = "";

    public AlbumSigningScreen(AlbumScreen parent, class_2960 texture, int textureWidth, int textureHeight) {
        super(class_2561.method_43473());
        this.parentScreen = parent;
        this.texture = texture;
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;
    }

    @Override
    protected void method_25426() {
        this.imageWidth = 149;
        this.imageHeight = 188;
        this.leftPos = (this.field_22789 - this.imageWidth) / 2;
        this.topPos = (this.field_22790 - this.imageHeight) / 2;

        // TITLE
        titleTextBox = new TextBox(field_22793, leftPos + 21, topPos + 73, 108, 9,
                () -> titleText, text -> titleText = text)
                .setFontColor(Config.getColor(Config.Client.ALBUM_FONT_MAIN_COLOR))
                .setSelectionColor(SELECTION_COLOR, SELECTION_UNFOCUSED_COLOR);
        titleTextBox.textValidator = text -> text != null && field_22793.method_1713(text, 108) <= 9 && !text.contains("\n");
        titleTextBox.horizontalAlignment = HorizontalAlignment.CENTER;
        method_37063(titleTextBox);

        // SIGN
        signButton = new BetterImageButton(leftPos + 46, topPos + 110,22,22,
                AlbumScreen.SIGN_BUTTON_SPRITES, b -> signAlbum(), class_2561.method_43471("gui.exposure.album.sign"));
        class_5250 component = class_2561.method_43471("gui.exposure.album.sign")
                .method_27693("\n").method_10852(class_2561.method_43471("gui.exposure.album.sign.warning").method_27692(class_124.field_1080));
        signButton.method_47400(class_7919.method_47407(component));
        method_37063(signButton);

        // CANCEL
        cancelSigningButton = new BetterImageButton(leftPos + 83, topPos + 111, 22,22,
                CANCEL_BUTTON_SPRITE,b -> cancelSigning(), class_2561.method_43471("gui.exposure.album.cancel_signing"));
        cancelSigningButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure.album.cancel_signing")));
        method_37063(cancelSigningButton);

        method_48265(titleTextBox);

        //        // SIGN
        //        signButton = new ImageButton(leftPos + 46, topPos + 110, 22, 22, 242, 188,
        //                22, texture, textureWidth, textureHeight,
        //                b -> signAlbum(), Component.translatable("gui.exposure.album.sign"));
        //        MutableComponent component = Component.translatable("gui.exposure.album.sign")
        //                .append("\n").append(Component.translatable("gui.exposure.album.sign.warning").withStyle(ChatFormatting.GRAY));
        //        signButton.setTooltip(Tooltip.create(component));
        //        addRenderableWidget(signButton);
        //
        //        // CANCEL
        //        cancelSigningButton = new ImageButton(leftPos + 83, topPos + 111, 22, 22, 264, 188,
        //                22, texture, textureWidth, textureHeight,
        //                b -> cancelSigning(), Component.translatable("gui.exposure.album.cancel_signing"));
        //        cancelSigningButton.setTooltip(Tooltip.create(Component.translatable("gui.exposure.album.cancel_signing")));
        //        addRenderableWidget(cancelSigningButton);
        //
        //        setInitialFocus(titleTextBox);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25393() {
        titleTextBox.tick();
    }

    private void updateButtons() {
        signButton.field_22763 = canSign();
    }

    protected boolean canSign() {
        return !titleText.isEmpty();
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();
        method_25420(guiGraphics);
        guiGraphics.method_25291(AlbumGUI.TEXTURE, leftPos, topPos, 0, 298,
                0, imageWidth, imageHeight, 512, 512);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        renderLabels(guiGraphics);
    }

    private void renderLabels(class_332 guiGraphics) {
        class_5250 component = class_2561.method_43471("gui.exposure.album.enter_title");
        guiGraphics.method_51439(field_22793, component,  leftPos + 149 / 2 - field_22793.method_27525(component) / 2, topPos + 50, 0xf5ebd0, false);

        component = class_2561.method_43469("gui.exposure.album.by_author", Minecrft.player().method_5820());
        guiGraphics.method_51439(field_22793, component, leftPos + 149 / 2 - field_22793.method_27525(component) / 2, topPos + 84, 0xc7b496, false);
    }

    protected void signAlbum() {
        if (canSign()) {
            parentScreen.method_17577().setTitle(titleText);
            parentScreen.method_17577().signAlbum(Minecrft.player());
            this.method_25419();
        }
    }

    protected void cancelSigning() {
        Minecrft.get().method_1507(parentScreen);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == class_3675.field_31948) {
            return super.method_25404(keyCode, scanCode, modifiers);
        }

        if (keyCode == class_3675.field_31958) {
            cancelSigning();
            return true;
        }

        if (titleTextBox.method_25370()) {
            return titleTextBox.method_25404(keyCode, scanCode, modifiers);
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }
}
