package io.github.mortuusars.exposure.client.gui.screen.camera.button;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.ModWidgetSprites;
import io.github.mortuusars.exposure.client.gui.component.CycleButton;
import io.github.mortuusars.exposure.world.camera.component.ShutterSpeed;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Function;
import net.minecraft.class_1109;
import net.minecraft.class_1144;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class ShutterSpeedButton extends CycleButton<ShutterSpeed> {
    protected final int secondaryFontColor;
    protected final int mainFontColor;

    public ShutterSpeedButton(int x, int y, int width, int height, List<ShutterSpeed> values, @NotNull ShutterSpeed startingValue,
                              Function<ShutterSpeed, ModWidgetSprites> spritesFunc, OnCycle<ShutterSpeed> onCycle) {
        super(x, y, width, height, values, startingValue, spritesFunc, onCycle);
        mainFontColor = Config.getColor(Config.Client.VIEWFINDER_FONT_MAIN_COLOR);
        secondaryFontColor = Config.getColor(Config.Client.VIEWFINDER_FONT_SECONDARY_COLOR);
    }

    public ShutterSpeedButton(int x, int y, int width, int height, List<ShutterSpeed> values, @NotNull ShutterSpeed startingValue,
                              Function<ShutterSpeed, ModWidgetSprites> spritesFunc) {
        super(x, y, width, height, values, startingValue, spritesFunc, (button, newValue) -> {});
        mainFontColor = Config.getColor(Config.Client.VIEWFINDER_FONT_MAIN_COLOR);
        secondaryFontColor = Config.getColor(Config.Client.VIEWFINDER_FONT_SECONDARY_COLOR);
    }

    @Override
    public void method_25354(class_1144 handler) {
        if (clickSound != null) {
            handler.method_4873(class_1109.method_4757(clickSound,
                    ThreadLocalRandom.current().nextFloat() * 0.05f + 0.9f + currentIndex * 0.01f, 0.7f));
        }
    }

    @Override
    public void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_48579(guiGraphics, mouseX, mouseY, partialTick);

        ShutterSpeed shutterSpeed = getCurrentValue();
        String text = shutterSpeed.getNotation().replace("1/", "");

        if (shutterSpeed.equals(ShutterSpeed.DEFAULT))
            text = text + "•";

        class_327 font = class_310.method_1551().field_1772;
        int textWidth = font.method_1727(text);
        int xPos = field_22758 / 2 - (textWidth / 2) + 1;

        guiGraphics.method_51433(font, text, method_46426() + xPos, method_46427() + 4, secondaryFontColor, false);
        guiGraphics.method_51433(font, text, method_46426() + xPos, method_46427() + 3, mainFontColor, false);
    }
}
