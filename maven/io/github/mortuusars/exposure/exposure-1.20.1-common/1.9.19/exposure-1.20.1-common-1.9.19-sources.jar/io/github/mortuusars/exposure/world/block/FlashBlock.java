package io.github.mortuusars.exposure.world.block;

import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_5819;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.NotNull;

public class FlashBlock extends class_2248 implements /*EntityBlock,*/ class_3737 {
    public static final int LIFETIME_TICKS = 8;

    public static final class_2746 WATERLOGGED = class_2741.field_12508;

    public FlashBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664().method_11657(WATERLOGGED, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> pBuilder) {
        pBuilder.method_11667(WATERLOGGED);
    }

    @Override
    public boolean method_9579(@NotNull class_2680 blockState, @NotNull class_1922 level, @NotNull class_2338 pos) {
        return true;
    }

    @Override
    public @NotNull class_2464 method_9604(@NotNull class_2680 state) {
        return class_2464.field_11455;
    }

    @Override
    public @NotNull class_265 method_9530(@NotNull class_2680 pState, @NotNull class_1922 pLevel, @NotNull class_2338 pPos, class_3726 pContext) {
        return pContext.method_17785(class_1802.field_30904) ? class_259.method_1077() : class_259.method_1073();
    }

    @Override
    public float method_9575(@NotNull class_2680 state, @NotNull class_1922 level, @NotNull class_2338 pos) {
        return 1.0F;
    }

    @Override
    public @NotNull class_2680 method_9559(class_2680 pState, @NotNull class_2350 pDirection, @NotNull class_2680 pNeighborState, @NotNull class_1936 pLevel, @NotNull class_2338 pCurrentPos, @NotNull class_2338 pNeighborPos) {
        if (pState.method_11654(WATERLOGGED)) {
            pLevel.method_39281(pCurrentPos, class_3612.field_15910, class_3612.field_15910.method_15789(pLevel));
        }

        return super.method_9559(pState, pDirection, pNeighborState, pLevel, pCurrentPos, pNeighborPos);
    }

    public @NotNull class_3610 method_9545(class_2680 pState) {
        return pState.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(pState);
    }

    @Override
    public void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean movedByPiston) {
        super.method_9615(state, level, pos, oldState, movedByPiston);
        level.method_39279(pos, this, LIFETIME_TICKS);
    }

    @Override
    public void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        class_2680 newState = state.method_11654(FlashBlock.WATERLOGGED)
                ? class_2246.field_10382.method_9564()
                : class_2246.field_10124.method_9564();
        level.method_8652(pos, newState, class_2248.field_31036);
    }
}
