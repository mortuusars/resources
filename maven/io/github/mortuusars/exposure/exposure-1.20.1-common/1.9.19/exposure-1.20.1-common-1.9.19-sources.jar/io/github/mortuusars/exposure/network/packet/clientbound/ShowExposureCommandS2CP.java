package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record ShowExposureCommandS2CP(List<Frame> frames,
                                      boolean negative) implements Packet {
    public static final class_2960 ID = Exposure.resource("show_exposure_command");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_34062(frames,(buf1, frame) -> frame.toPacket(buf1));
        buf.writeBoolean(negative);
    }

    public static ShowExposureCommandS2CP fromPacket(class_2540 buf) {
        return new ShowExposureCommandS2CP(buf.method_34066(Frame::fromPacket),buf.readBoolean());
    }

    public static ShowExposureCommandS2CP identifier(ExposureIdentifier identifier, boolean negative) {
        Frame frame = Frame.create().setIdentifier(identifier).toImmutable();
        return new ShowExposureCommandS2CP(List.of(frame), negative);
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.showExposure(this);
        return true;
    }
}
