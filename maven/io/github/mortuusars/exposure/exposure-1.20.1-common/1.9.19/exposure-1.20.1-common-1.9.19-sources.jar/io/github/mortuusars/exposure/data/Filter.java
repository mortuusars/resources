package io.github.mortuusars.exposure.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.Stuff;
import io.github.mortuusars.exposure.util.color.Color;
import net.minecraft.class_2073;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_6899;

public record Filter(class_2073 predicate,
                     class_2960 shader,
                     class_2960 attachmentTexture,
                     Color attachmentTintColor) {
    public static final class_2960 DEFAULT_GLASS_TEXTURE = Exposure.resource("textures/gui/filter/stained_glass.png");

    public static final Codec<class_6880<Filter>> HOLDER_CODEC = class_6899.method_40400(Exposure.Registries.FILTER);

    public static final Codec<Filter> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Stuff.ITEM_PREDICATE_CODEC.fieldOf("predicate").forGetter(Filter::predicate),
            class_2960.field_25139.fieldOf("shader").forGetter(Filter::shader),
            class_2960.field_25139.optionalFieldOf("attachment_texture", DEFAULT_GLASS_TEXTURE).forGetter(Filter::attachmentTexture),
            Color.HEX_STRING_CODEC.optionalFieldOf("attachment_tint", Color.WHITE).forGetter(Filter::attachmentTintColor)
    ).apply(instance, Filter::new));
}
