package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.capture.CaptureParameters;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record CaptureStartDebugRGBS2CP(class_2960 templateId, List<CaptureParameters> captureProperties) implements Packet {
    public static final class_2960 ID = Exposure.resource("capture_start_debug_rgb");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_10812(templateId);
        buf.method_34062(captureProperties,(buf1, captureParameters) -> captureParameters.toPacket(buf1));
    }

    public static CaptureStartDebugRGBS2CP fromPacket(class_2540 buf) {
        return new CaptureStartDebugRGBS2CP(buf.method_10810(),buf.method_34066(CaptureParameters::fromPacket));
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.startDebugRGBCapture(this);
        return true;
    }
}
