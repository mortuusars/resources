package io.github.mortuusars.exposure.advancements.trigger;

import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.advancements.predicate.FramePredicate;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_1799;
import net.minecraft.class_195;
import net.minecraft.class_2073;
import net.minecraft.class_2090;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5257;
import net.minecraft.class_5258;
import net.minecraft.class_5267;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.Optional;

public class FramePrintedTrigger extends class_4558<FramePrintedTrigger.TriggerInstance> {
    public static final class_2960 ID = Exposure.resource("frame_printed");


    public void trigger(class_3222 player,
                        class_2338 pos,
                        Frame frame,
                        class_1799 result) {
        this.method_22510(player, triggerInstance ->
                triggerInstance.matches(player, pos, frame, result));
    }

    @Override
    protected TriggerInstance method_27854(JsonObject json, class_5258 predicate, class_5257 deserializationContext) {
        class_2090 location = class_2090.method_9021(json.get("location"));
        FramePredicate framePredicate = FramePredicate.fromJson(json.get("frame"));
        class_2073 item = class_2073.method_8969(json.get("item"));
        return new TriggerInstance(predicate, location, framePredicate, item);
    }

    @Override
    public class_2960 method_794() {
        return ID;
    }

    public static final class TriggerInstance extends class_195 {

        private final class_2090 location;
        private final FramePredicate frame;
        private final class_2073 item;

        public TriggerInstance(class_5258 player,
                               class_2090 location,
                               FramePredicate frame,
                               class_2073 item) {
            super(ID, player);
            this.location = location;
            this.frame = frame;
            this.item = item;
        }

        public boolean matches(class_3222 player,
                               class_2338 pos,
                               Frame frame,
                               class_1799 result) {

            boolean locationMatch = location.method_9018(player.method_51469(), pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
            boolean frameMatch = this.frame.matches(frame);
            boolean itemMatch = item.method_8970(result);
            return locationMatch
                    && frameMatch
                    && itemMatch;
        }

        @Override
        public JsonObject method_807(class_5267 context) {
            JsonObject jsonObject = super.method_807(context);
            if (location != class_2090.field_9685) {
                jsonObject.add("location", location.method_9019());
            }
            if (frame != FramePredicate.ANY) {
                jsonObject.add("frame", frame.serializeToJson());
            }
            if (item != class_2073.field_9640) {
                jsonObject.add("item", item.method_8971());
            }
            return jsonObject;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) return true;
            if (obj == null || obj.getClass() != this.getClass()) return false;
            var that = (TriggerInstance) obj;
            return Objects.equals(this.location, that.location) &&
                    Objects.equals(this.frame, that.frame) &&
                    Objects.equals(this.item, that.item);
        }

        @Override
        public int hashCode() {
            return Objects.hash(location, frame, item);
        }

        @Override
        public String toString() {
            return "TriggerInstance[" +
                    "location=" + location + ", " +
                    "frame=" + frame + ", " +
                    "item=" + item + ']';
        }
    }
}