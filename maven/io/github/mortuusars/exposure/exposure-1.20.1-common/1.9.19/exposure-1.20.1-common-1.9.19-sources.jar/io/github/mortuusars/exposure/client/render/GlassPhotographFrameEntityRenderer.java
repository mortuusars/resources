package io.github.mortuusars.exposure.client.render;

import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.world.entity.GlassPhotographFrameEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4722;
import net.minecraft.class_5617;
import org.jetbrains.annotations.NotNull;

public class GlassPhotographFrameEntityRenderer extends PhotographFrameEntityRenderer<GlassPhotographFrameEntity> {
    public GlassPhotographFrameEntityRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public class_2960 getModelLocation(GlassPhotographFrameEntity entity, int size) {
        return switch (size) {
            case 0 -> ExposureClient.Models.CLEAR_PHOTOGRAPH_FRAME_SMALL;
            case 1 -> ExposureClient.Models.CLEAR_PHOTOGRAPH_FRAME_MEDIUM;
            case 2 -> ExposureClient.Models.CLEAR_PHOTOGRAPH_FRAME_LARGE;
            default -> throw new IllegalArgumentException("size " + size + " is not valid. Expected 0-2.");
        };
    }

    @Override
    protected @NotNull class_1921 getRenderType() {
        return class_4722.method_24074();
    }
}