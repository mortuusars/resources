package io.github.mortuusars.exposure.client.render;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.PlatformHelperClient;
import io.github.mortuusars.exposure.client.image.modifier.ImageEffect;
import io.github.mortuusars.exposure.client.image.renderable.RenderableImage;
import io.github.mortuusars.exposure.client.render.image.RenderCoordinates;
import io.github.mortuusars.exposure.client.render.photograph.PhotographStyle;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.entity.PhotographFrameEntity;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import net.minecraft.class_1087;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1944;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_5617;
import net.minecraft.class_765;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_897;
import org.jetbrains.annotations.NotNull;

public class PhotographFrameEntityRenderer<T extends PhotographFrameEntity> extends class_897<T> {
    protected final class_776 blockRenderer;

    public PhotographFrameEntityRenderer(class_5617.class_5618 context) {
        super(context);
        this.blockRenderer = context.method_43337();
    }

    @Override
    public @NotNull class_2960 getTextureLocation(@NotNull T pEntity) {
        return class_1723.field_21668;
    }

    public class_2960 getModelLocation(T entity, int size) {
        return switch (size) {
            case 0 -> ExposureClient.Models.PHOTOGRAPH_FRAME_SMALL;
            case 1 -> ExposureClient.Models.PHOTOGRAPH_FRAME_MEDIUM;
            case 2 -> ExposureClient.Models.PHOTOGRAPH_FRAME_LARGE;
            default -> throw new IllegalArgumentException("size " + size + " is not valid. Expected 0-2.");
        };
    }

    protected @NotNull class_1921 getRenderType() {
        return class_4722.method_24073();
    }

    @Override
    public void render(@NotNull T entity, float entityYaw, float partialTick, @NotNull class_4587 poseStack, @NotNull class_4597 bufferSource, int packedLight) {
        if (class_310.method_1551().field_1765 instanceof class_3966 entityHitResult && entityHitResult.method_17782() == entity) {
            class_310.method_1551().field_1692 = entity;
        }

        class_2350 direction = entity.method_5735();
        int size = entity.getSize();

        poseStack.method_22903();
        // Offsets name tag rendering to be like item frame:
        poseStack.method_46416(direction.method_10148() * 0.3f, direction.method_10164() * 0.3f, direction.method_10165() * 0.3f);
        super.method_3936(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        poseStack.method_22909();

        poseStack.method_22903();

        // thickness of the frame is 1px (0.5 - (1/16 * 0.5)) (0.5 is because we are offsetting from the center)
        // stripped frame is thin, so 1/16 becomes 0.15/16 (thickness of the backplate)
        double hangOffset = 0.46875;
        poseStack.method_22904(direction.method_10148() * hangOffset, direction.method_10164() * hangOffset, direction.method_10165() * hangOffset);

        poseStack.method_22907(class_7833.field_40714.rotationDegrees(entity.method_36455()));
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F - entity.method_36454()));

        class_1799 item = entity.getItem();
        if (!item.method_7960()) {
            boolean photographRendered = renderPhotograph(entity, poseStack, bufferSource, packedLight, item, size);

            if (!photographRendered) {
                poseStack.method_22903();
                float scale = 0.65f + entity.getSize() * 0.5f;
                poseStack.method_22904(0, 0, 0.46875);
                poseStack.method_22905(scale, scale, scale * 0.75f);
                poseStack.method_22907(class_7833.field_40718.rotationDegrees((entity.getItemRotation() * 360.0F / 4.0F)));
                Minecrft.get().method_1480().method_23178(item, class_811.field_4319, packedLight, class_4608.field_21444, poseStack, bufferSource, entity.method_37908(), 0);
                poseStack.method_22909();
            }
        }

        if (!entity.isFrameInvisible()) {
            renderFrame(entity, poseStack, bufferSource, packedLight, size);
        }

        poseStack.method_22909();
    }

    protected void renderFrame(@NotNull T entity, @NotNull class_4587 poseStack, @NotNull class_4597 bufferSource,
                               int packedLight, int size) {
        poseStack.method_22903();
        poseStack.method_46416(-0.5f, -0.5f, -0.5f);
        class_2960 modelLocation = getModelLocation(entity, size);
        class_1087 model = PlatformHelperClient.getModel(modelLocation);
        blockRenderer.method_3350().method_3367(poseStack.method_23760(), bufferSource.getBuffer(getRenderType()),
              null, model, 1.0f, 1.0f, 1.0f, packedLight, class_4608.field_21444);
        poseStack.method_22909();
    }

    protected boolean renderPhotograph(@NotNull T entity, @NotNull class_4587 poseStack, @NotNull class_4597 bufferSource,
                                       int packedLight, class_1799 item, int size) {
        poseStack.method_22903();

        boolean frameInvisible = entity.isFrameInvisible();

        float frameBorderOffset = frameInvisible ? 0f : 0.125f; // (2px / 16px = 0.125)
        float offsetFromCenter = frameInvisible ? 0.497f : 0.48f;
        offsetFromCenter -= Config.Client.PHOTOGRAPH_FRAME_IMAGE_OFFSET.get();
        float desiredSize = size + 1 - frameBorderOffset * 2;

        poseStack.method_22907(class_7833.field_40718.rotationDegrees((entity.getItemRotation() * 360.0F / 4.0F)));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
        poseStack.method_22904(-0.5 * (size + 1) + frameBorderOffset, -0.5 * (size + 1) + frameBorderOffset, offsetFromCenter);
        poseStack.method_22905(desiredSize, desiredSize, 1);

        boolean isGlowing = entity.isGlowing();
        if (isGlowing) {
            packedLight = class_765.field_32767;
        }

        int brightness = isGlowing ? 255 : getPhotographBrightness(entity);

        boolean photographRendered = false;

        if (Config.Client.PIXEL_PERFECT_PHOTOGRAPH_FRAME.get()) {
            if (item.method_7909() instanceof PhotographItem photographItem) {
                PhotographStyle style = PhotographStyle.of(item);
                Frame frame = photographItem.getFrame(item);

                RenderableImage image = style.process(ExposureClient.renderedExposures().getOrCreate(frame));

                int pixels = 16 * (entity.getSize() + 1);
                if (!frameInvisible) {
                    pixels -= 4;
                }
                image = image.modifyWith(ImageEffect.Resize.to(pixels)::modify, "pixels-" + pixels);

                ExposureClient.imageRenderer().render(image, poseStack, bufferSource, RenderCoordinates.DEFAULT,
                      packedLight, brightness, brightness, brightness, 255);
                photographRendered = !image.isEmpty();
            }
        } else {
            photographRendered = ExposureClient.photographRenderer().render(item, false, false,
                  poseStack, bufferSource, packedLight, brightness, brightness, brightness, 255);
        }

        poseStack.method_22909();

        return photographRendered;
    }

    public int getPhotographBrightness(T entity) {
        if (entity.method_5735() == class_2350.field_11036)
            return 255;

        // Darken the photo same way as the block sides darken,
        // but not quite as much and allow light sources to brighten it:
        int lightLevel = entity.method_37908().method_8314(class_1944.field_9282, entity.method_24515());
        float shadeFactor = entity.method_37908().method_24852(entity.method_5735(), true);
        shadeFactor += (1f - shadeFactor) * 0.2f;

        int shadedBrightness = (int) (255 * shadeFactor);
        int missingLight = 255 - shadedBrightness;
        int lightUp = (int) (missingLight * (lightLevel / 15f * 0.5f));
        return Math.min(255, shadedBrightness + lightUp);
    }

    /*@Override
    protected void renderNameTag(T entity, Component displayName, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick) {
        double d = this.entityRenderDispatcher.distanceToSqr(entity);
        if (!(d > 4096.0)) {
            Vec3 vec3 = entity.getAttachments().getNullable(EntityAttachment.NAME_TAG, 0, entity.getViewYRot(partialTick));
            if (vec3 != null) {
                boolean bl = !entity.isDiscrete();
                poseStack.pushPose();

                double yOffset = entity.getDirection().getAxis().isHorizontal()
                        ? vec3.y - 0.2 + entity.getSize() * 0.5
                        : entity.getDirection().getStepY() > 0
                            ? vec3.y - 0.5
                            : vec3.y - 1;

                poseStack.translate(vec3.x, vec3.y + yOffset, vec3.z);
                poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
                poseStack.scale(0.025F, -0.025F, 0.025F);
                Matrix4f matrix4f = poseStack.last().pose();
                float f = Minecraft.getInstance().options.getBackgroundOpacity(0.25F);
                int j = (int)(f * 255.0F) << 24;
                Font font = this.getFont();
                float g = (float)(-font.width(displayName) / 2);
                font.drawInBatch(
                        displayName, g, 0, 553648127, false, matrix4f, bufferSource, bl ? Font.DisplayMode.SEE_THROUGH : Font.DisplayMode.NORMAL, j, packedLight
                );
                if (bl) {
                    font.drawInBatch(displayName, g, 0, -1, false, matrix4f, bufferSource, Font.DisplayMode.NORMAL, 0, packedLight);
                }

                poseStack.popPose();
            }
        }
    }*/

    @Override
    protected boolean shouldShowName(T entity) {
        if (class_310.method_1498() && (!entity.getItem().method_7960() && entity.getItem().method_7938()
              && class_310.method_1551().field_1692 == entity)) {
            double distSqr = class_310.method_1551().field_1692.method_5858(entity);
            float showRangeSqr = entity.method_21751() ? 32.0f : 64.0f;
            return distSqr < (double) (showRangeSqr * showRangeSqr);
        }
        return false;
    }

    @Override
    protected void renderNameTag(T entity, class_2561 displayName, class_4587 poseStack, class_4597 buffer, int packedLight) {
        super.method_3926(entity, entity.getItem().method_7964(), poseStack, buffer, packedLight);
    }
}