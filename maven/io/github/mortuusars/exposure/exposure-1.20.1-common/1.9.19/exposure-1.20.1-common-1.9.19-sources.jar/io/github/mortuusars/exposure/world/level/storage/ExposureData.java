package io.github.mortuusars.exposure.world.level.storage;

import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.util.Codecs;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.Objects;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class ExposureData extends class_18 {
    public static final Codec<ExposureData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.fieldOf("width").forGetter(ExposureData::getWidth),
            Codec.INT.fieldOf("height").forGetter(ExposureData::getHeight),
            Codecs.byteArrayCodec(1, 2048 * 2048).fieldOf("pixels").forGetter(ExposureData::getPixels),
            class_2960.field_25139.optionalFieldOf("palette", ColorPalettes.DEFAULT.method_29177()).forGetter(ExposureData::getPaletteId),
            Tag.CODEC.optionalFieldOf("tag", Tag.EMPTY).forGetter(ExposureData::getTag)
    ).apply(instance, ExposureData::new));

    public void toPacket(class_2540 buf){
        buf.writeInt(width);
        buf.writeInt(height);
        buf.method_10813(pixels);
        buf.method_10812(palette);
        tag.toPacket(buf);
    }

    public static ExposureData fromPacket(class_2540 buf) {
        return new ExposureData(buf.readInt(),buf.readInt(),buf.method_10795(),buf.method_10810(),Tag.fromPacket(buf));
    }

    public static final ExposureData EMPTY = new ExposureData(
            1, 1, new byte[]{0}, ColorPalettes.DEFAULT.method_29177(), Tag.EMPTY);

    private final int width;
    private final int height;
    private final byte[] pixels;
    private final class_2960 palette;
    private final Tag tag;

    public ExposureData(int width, int height, byte[] pixels, class_2960 paletteId, Tag tag) {
        Preconditions.checkArgument(width > 0, "Width should be larger than 0. %s", width);
        Preconditions.checkArgument(height > 0, "Height should be larger than 0. %s ", height);
        Preconditions.checkArgument(pixels.length == width * height,
                "Pixel count '%s' is not correct for image dimensions of '%sx%s'. " +
                        "Count should be '%s'.", pixels.length, width, height, width * height);
        this.width = width;
        this.height = height;
        this.pixels = pixels;
        this.palette = paletteId;
        this.tag = tag;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public byte[] getPixels() {
        return pixels;
    }

    public byte getPixel(int x, int y) {
        return pixels[y * width + x];
    }

    public class_2960 getPaletteId() {
        return palette;
    }

    public Tag getTag() {
        return tag;
    }

    public ExposureData withTag(Function<Tag, Tag> updateFunction) {
        return new ExposureData(width, height, pixels, palette, updateFunction.apply(this.tag));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExposureData that = (ExposureData) o;
        return width == that.width && height == that.height && Objects.deepEquals(pixels, that.pixels)
                && Objects.equals(palette, that.palette) && Objects.equals(tag, that.tag);
    }

    @Override
    public int hashCode() {
        return Objects.hash(width, height, Arrays.hashCode(pixels), palette, tag);
    }

    // --

    @Override
    public @NotNull class_2487 method_75(class_2487 tag) {
        DataResult<net.minecraft.class_2520> encodingResult = CODEC.encode(this, class_2509.field_11560, tag);
        if (encodingResult.error().isEmpty()) {
            net.minecraft.class_2520 encodedTag = encodingResult.get().left().get();
            if (encodedTag instanceof class_2487 encodedCompoundTag)
                return encodedCompoundTag;
            else {
                Exposure.LOGGER.error("Cannot save PalettedExposure: '{}'. Encoded tag is not CompoundTag but a {}",
                        this, encodedTag.method_23258());
            }
        }
        encodingResult.error().ifPresent(error -> Exposure.LOGGER.error("Cannot save PalettedExposure: {}", error.message()));

        return tag;
    }

    public static ExposureData load(class_2487 tag) {
        return CODEC.decode(class_2509.field_11560, tag).get().orThrow().getFirst();
    }

    public record Tag(ExposureType type,
                      String creator,
                      long unixTimestamp,
                      boolean loaded,
                      boolean wasPrinted) {
        public static final Codec<Tag> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                ExposureType.CODEC.optionalFieldOf("type", ExposureType.COLOR).forGetter(Tag::type),
                Codec.STRING.optionalFieldOf("creator", "").forGetter(Tag::creator),
                Codec.LONG.optionalFieldOf("timestamp", 1645494000L).forGetter(Tag::unixTimestamp),
                Codec.BOOL.optionalFieldOf("loaded", false).forGetter(Tag::loaded),
                Codec.BOOL.optionalFieldOf("was_printed", false).forGetter(Tag::wasPrinted)
        ).apply(instance, Tag::new));

        public static Tag fromPacket(class_2540 buf) {
            return new Tag(buf.method_10818(ExposureType.class), buf.method_19772(),buf.readLong(),buf.readBoolean(),buf.readBoolean());
        }

        public void toPacket(class_2540 buf) {
            buf.method_10817(type);
            buf.method_10814(creator);
            buf.writeLong(unixTimestamp);
            buf.writeBoolean(loaded);
            buf.writeBoolean(wasPrinted);
        }

        public static final Tag EMPTY = new Tag(ExposureType.COLOR, "", 0, false, false);

        public Tag withType(ExposureType type) {
            return new Tag(type, creator, unixTimestamp, loaded, wasPrinted);
        }

        public Tag withCreator(String creator) {
            return new Tag(type, creator, unixTimestamp, loaded, wasPrinted);
        }

        public Tag withTimestamp(long unixTimestamp) {
            return new Tag(type, creator, unixTimestamp, loaded, wasPrinted);
        }

        public Tag withLoadedSetTo(boolean isLoaded) {
            return new Tag(type, creator, unixTimestamp, isLoaded, wasPrinted);
        }

        public Tag withWasPrintedSetTo(boolean wasPrinted) {
            return new Tag(type, creator, unixTimestamp, loaded, wasPrinted);
        }

        public Tag setPrinted() {
            return new Tag(type, creator, unixTimestamp, loaded, true);
        }
    }
}
