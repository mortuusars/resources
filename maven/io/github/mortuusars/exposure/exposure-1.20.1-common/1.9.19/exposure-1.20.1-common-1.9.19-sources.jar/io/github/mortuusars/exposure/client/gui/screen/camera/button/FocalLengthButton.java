package io.github.mortuusars.exposure.client.gui.screen.camera.button;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.ModWidgetSprites;
import io.github.mortuusars.exposure.client.gui.BetterImageButton;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.util.Fov;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5250;
import org.jetbrains.annotations.NotNull;

public class FocalLengthButton extends BetterImageButton {
    protected final int secondaryFontColor;
    protected final int mainFontColor;

    public FocalLengthButton(int x, int y, int width, int height, ModWidgetSprites sprites) {
        super(x, y, width, height, sprites, button -> {}, class_2561.method_43473());
        mainFontColor = Config.getColor(Config.Client.VIEWFINDER_FONT_MAIN_COLOR);
        secondaryFontColor = Config.getColor(Config.Client.VIEWFINDER_FONT_SECONDARY_COLOR);
    }

    @Override
    public void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_48579(guiGraphics, mouseX, mouseY, partialTick);

        int focalLength = (int)Math.round(Fov.fovToFocalLength(getCurrentFov()));

        class_327 font = class_310.method_1551().field_1772;
        class_5250 text = class_2561.method_43469("gui.exposure.camera_controls.focal_length", focalLength);
        int textWidth = font.method_27525(text);
        int xPos = 17 + (29 - textWidth) / 2;

        guiGraphics.method_51439(font, text, method_46426() + xPos, method_46427() + 8, secondaryFontColor, false);
        guiGraphics.method_51439(font, text, method_46426() + xPos, method_46427() + 7, mainFontColor, false);
    }

    protected double getCurrentFov() {
        return Minecrft.get().field_1773.method_3196(
                Minecrft.get().field_1773.method_19418(),
                Minecrft.get().method_1534(),
                true);
    }
}
