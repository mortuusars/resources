package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.camera.Camera;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public enum ActiveCameraReleaseC2SP implements Packet {
    INSTANCE;

    public static final class_2960 ID = Exposure.resource("active_camera_release");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {

    }

    public static ActiveCameraReleaseC2SP fromPacket(class_2540 buf) {
        return INSTANCE;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        player.getActiveExposureCameraOptional().ifPresentOrElse(
                Camera::release,
                () -> Exposure.LOGGER.error("Cannot release shutter: '{}' does not have an active camera.", player));

        return true;
    }
}
