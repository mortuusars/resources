package io.github.mortuusars.exposure.network.packet.serverbound;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.item.AlbumItem;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3419;
import io.github.mortuusars.exposure.network.packet.Packet;

public record AlbumSignC2SP(int slot, String title, String author) implements Packet {
    public static final class_2960 ID = Exposure.resource("album_sign");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.writeInt(slot);
        buf.method_10814(title);
        buf.method_10814(author);
    }

    public static AlbumSignC2SP fromPacket(class_2540 buf) {
        return new AlbumSignC2SP(buf.readInt(),buf.method_19772(),buf.method_19772());
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        Preconditions.checkState(player != null, "Cannot handle packet: Player was null");

        class_1799 albumStack = player.method_31548().method_5438(slot());
        if (albumStack.method_7909() instanceof AlbumItem albumItem) {
            class_1799 signedAlbumStack = albumItem.sign(albumStack, title(), author());
            player.method_31548().method_5447(slot(), signedAlbumStack);
            player.method_37908().method_43129(null, player, Exposure.SoundEvents.WRITE.get(), class_3419.field_15248, 0.8f ,1f);
        }

        return true;
    }
}
