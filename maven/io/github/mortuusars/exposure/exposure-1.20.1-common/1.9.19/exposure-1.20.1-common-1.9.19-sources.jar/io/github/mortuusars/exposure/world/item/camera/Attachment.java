package io.github.mortuusars.exposure.world.item.camera;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.item.FilmRollItem;
import io.github.mortuusars.exposure.world.item.component.StoredItemStack;
import io.github.mortuusars.exposure.world.sound.Sound;
import io.github.mortuusars.exposure.world.sound.SoundEffect;
import java.util.Optional;
import java.util.function.*;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3419;

/**
 * ItemStacks gotten from this class should NOT be modified under any circumstances.
 * Copy ItemStack and set with {@link Attachment#set(class_1799, class_1799)}.
 */
public record Attachment<T extends class_1792>(class_2960 id,
                                         String component,
                                         Predicate<class_1799> itemPredicate,
                                         Class<T> itemType,
                                         Supplier<Integer> maxCount,
                                         Optional<SoundEffect> insertedSound,
                                         Optional<SoundEffect> removedSound) {
    public static final Attachment<FilmRollItem> FILM = new Attachment<>(
            Exposure.resource("film"),
            "camera_film",
            stack -> stack.method_7909() instanceof FilmRollItem,
            FilmRollItem.class,
            () -> 1,
            new SoundEffect(Exposure.SoundEvents.FILM_ADVANCE, 0.9F, 1F),
            new SoundEffect(Exposure.SoundEvents.FILM_REMOVED, 0.7F, 1F));
    public static final Attachment<class_1792> FLASH = new Attachment<>(
            Exposure.resource("flash"),
            "camera_flash",
            stack -> stack.method_31573(Exposure.Tags.Items.FLASHES),
            class_1792.class,
            () -> 1,
            new SoundEffect(Exposure.SoundEvents.CAMERA_GENERIC_CLICK, 0.6F, 1.15F),
            new SoundEffect(Exposure.SoundEvents.CAMERA_GENERIC_CLICK, 0.35F, 0.95F));
    public static final Attachment<class_1792> LENS = new Attachment<>(
            Exposure.resource("lens"),
            "camera_lens",
            stack -> stack.method_31573(Exposure.Tags.Items.LENSES),
            class_1792.class,
            () -> 1,
            new SoundEffect(Exposure.SoundEvents.LENS_INSERT),
            new SoundEffect(Exposure.SoundEvents.LENS_REMOVE));
    public static final Attachment<class_1792> FILTER = new Attachment<>(
            Exposure.resource("filter"),
            "camera_filter",
            stack -> stack.method_31573(Exposure.Tags.Items.FILTERS),
            class_1792.class,
            () -> 1,
            new SoundEffect(Exposure.SoundEvents.FILTER_INSERT),
            new SoundEffect(Exposure.SoundEvents.FILTER_REMOVE, 0.5F));

    public Attachment(class_2960 id,
                      String component,
                      Predicate<class_1799> itemPredicate,
                      Class<T> itemType,
                      Supplier<Integer> maxCount,
                      SoundEffect insertedSound,
                      SoundEffect removedSound) {
        this(id, component, itemPredicate, itemType, maxCount, Optional.of(insertedSound), Optional.of(removedSound));
    }

    public Attachment(class_2960 id,
                      String component,
                      Predicate<class_1799> itemPredicate,
                      Class<T> itemType,
                      Supplier<Integer> maxCount) {
        this(id, component, itemPredicate, itemType, maxCount, Optional.empty(), Optional.empty());
    }

    public boolean matches(class_1799 stack) {
        return itemPredicate.test(stack);
    }

    public boolean isEmpty(class_1799 stack) {
        StoredItemStack storedItemStack = get(stack);
        return storedItemStack.isEmpty() || !itemType.isInstance(storedItemStack.getItem());
    }

    public boolean isPresent(class_1799 stack) {
        return !isEmpty(stack);
    }

    /**
     * ItemStacks gotten from this method should NOT be modified under any circumstances.
     */
    public StoredItemStack get(class_1799 stack) {
        return Exposure.DataComponents.getStoredItemStack(stack,component, StoredItemStack.EMPTY);
    }

    /**
     * ItemStacks gotten from this method should NOT be modified under any circumstances.
     */
    public Attachment<T> ifPresent(class_1799 stack, BiConsumer<T, class_1799> ifPresent) {
        StoredItemStack storedItemStack = get(stack);
        if (itemType.isInstance(storedItemStack.getItem())) {
            ifPresent.accept(itemType.cast(storedItemStack.getItem()), storedItemStack.getForReading());
        }
        return this;
    }

    /**
     * ItemStacks gotten from this method should NOT be modified under any circumstances.
     */
    public Attachment<T> ifPresent(class_1799 stack, Consumer<class_1799> ifPresent) {
        StoredItemStack storedItemStack = get(stack);
        if (itemType.isInstance(storedItemStack.getItem())) {
            ifPresent.accept(storedItemStack.getForReading());
        }
        return this;
    }

    /**
     * ItemStacks gotten from this method should NOT be modified under any circumstances.
     */
    public Attachment<T> orElse(class_1799 stack, Runnable orElse) {
        StoredItemStack storedItemStack = get(stack);
        if (!itemType.isInstance(storedItemStack.getItem())) {
            orElse.run();
        }
        return this;
    }

    /**
     * ItemStacks gotten from this method should NOT be modified under any circumstances.
     */
    public Attachment<T> ifPresentOrElse(class_1799 stack, BiConsumer<T, class_1799> ifPresent, Runnable orElse) {
        return ifPresent(stack, ifPresent).orElse(stack, orElse);
    }

    /**
     * ItemStacks gotten from this method should NOT be modified under any circumstances.
     */
    public <R> Optional<R> map(class_1799 stack, Function<class_1799, R> mappingFunc) {
        return mapOrElse(stack, (st) -> Optional.of(mappingFunc.apply(st)), Optional::empty);
    }

    /**
     * ItemStacks gotten from this method should NOT be modified under any circumstances.
     */
    public <R> Optional<R> map(class_1799 stack, BiFunction<T, class_1799, R> mappingFunc) {
        return mapOrElse(stack, (it, st) -> Optional.of(mappingFunc.apply(it, st)), Optional::empty);
    }

    /**
     * ItemStacks gotten from this method should NOT be modified under any circumstances.
     */
    public <R> R mapOrElse(class_1799 stack, Function<class_1799, R> ifPresentMappingFunc, Supplier<R> orElseSupplier) {
        StoredItemStack storedItemStack = get(stack);
        return itemType.isInstance(storedItemStack.getItem())
                ? ifPresentMappingFunc.apply(storedItemStack.getForReading())
                : orElseSupplier.get();
    }

    /**
     * ItemStacks gotten from this method should NOT be modified under any circumstances.
     */
    public <R> R mapOrElse(class_1799 stack, BiFunction<T, class_1799, R> ifPresentMappingFunc, Supplier<R> orElseSupplier) {
        StoredItemStack storedItemStack = get(stack);
        return itemType.isInstance(storedItemStack.getItem())
                ? ifPresentMappingFunc.apply(itemType.cast(storedItemStack.getItem()), storedItemStack.getForReading())
                : orElseSupplier.get();
    }

    public Attachment<T> set(class_1799 stack, class_1799 attachment) {
        if (attachment.method_7960()) {
            stack.method_7983(component);
        } else {
            Exposure.DataComponents.setStoredItemStack(stack,component, new StoredItemStack(attachment));
        }
        return this;
    }

    public void playInsertSoundSided(class_1297 entity) {
        insertedSound().ifPresent(sound ->
                Sound.playUniqueSided(Integer.toString(entity.method_5628()), entity, sound, class_3419.field_15248));
    }

    public void playRemoveSoundSided(class_1297 entity) {
        removedSound().ifPresent(sound ->
                Sound.playUniqueSided(Integer.toString(entity.method_5628()), entity, sound, class_3419.field_15248));
    }

    @Override
    public String toString() {
        return "Attachment{id='" + id + "'}";
    }
}
