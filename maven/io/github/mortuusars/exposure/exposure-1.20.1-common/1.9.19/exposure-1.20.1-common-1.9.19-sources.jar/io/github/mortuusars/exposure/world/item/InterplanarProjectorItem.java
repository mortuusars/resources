package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.capture.DitherMode;
import io.github.mortuusars.exposure.world.camera.capture.Projection;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_5536;
import net.minecraft.class_5630;

public class InterplanarProjectorItem extends class_1792 {
    public InterplanarProjectorItem(class_1793 properties) {
        super(properties);
    }

    public DitherMode getMode(class_1799 stack) {
        return Exposure.DataComponents.getInterplanarProjectorMode(stack, DitherMode.DITHERED);
    }

    public void setMode(class_1799 stack, DitherMode mode) {
        Exposure.DataComponents.setInterplanarProjectorMode(stack, mode);
    }

    public boolean isConsumable(class_1799 stack) {
        return isAllowed();
    }

    protected boolean isAllowed() {
        return Config.Server.CAN_PROJECT.get();
    }

    @Override
    public void method_7851(class_1799 stack, class_1937 context, List<class_2561> components, class_1836 tooltipFlag) {
        if (!isAllowed()) {
            components.add(class_2561.method_43471("item.exposure.interplanar_projector.tooltip.disabled"));
        }

        if (getProjection(stack).isPresent()) {
            components.add(getMode(stack).translate());
        }

        if (class_437.method_25442()) {
            if (isConsumable(stack)) {
                components.add(class_2561.method_43471("item.exposure.interplanar_projector.tooltip.consumed_info"));
            }
            components.add(class_2561.method_43471("item.exposure.interplanar_projector.tooltip.info"));
            if (getProjection(stack).isPresent()) {
                components.add(class_2561.method_43471("item.exposure.interplanar_projector.tooltip.change_mode_info"));
            }
        } else {
            components.add(class_2561.method_43471("tooltip.exposure.hold_for_details"));
        }
    }

    @Override
    public boolean method_31566(class_1799 stack, class_1799 other, class_1735 slot, class_5536 action, class_1657 player, class_5630 access) {
        if (other.method_7960() && action == class_5536.field_27014 && getProjection(stack).isPresent()) {
            setMode(stack, getMode(stack).cycle());
            slot.method_7668();
            if (player.method_37908().field_9236) {
                player.method_5783(Exposure.SoundEvents.CAMERA_GENERIC_CLICK.get(), 0.6f, 1f);
            }
            return true;
        }

        return super.method_31566(stack, other, slot, action, player, access);
    }

    public Optional<String> getPath(class_1799 stack) {
        @Nullable class_2561 customName = stack.method_7964();
        return Optional.of(customName.getString());
    }

    public Optional<Projection> getProjection(class_1799 stack) {
        return isAllowed() ? getPath(stack).map(filepath -> new Projection(filepath, getMode(stack))) : Optional.empty();
    }
}
