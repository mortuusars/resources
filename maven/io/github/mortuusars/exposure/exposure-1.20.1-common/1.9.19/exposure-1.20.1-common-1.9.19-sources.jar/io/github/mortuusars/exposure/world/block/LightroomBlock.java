package io.github.mortuusars.exposure.world.block;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.world.block.entity.Lightroom;
import io.github.mortuusars.exposure.world.block.entity.LightroomBlockEntity;
import io.github.mortuusars.exposure.world.item.StackedPhotographsItem;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class LightroomBlock extends class_2248 implements class_2343 {
    public static final class_2753 FACING = class_2383.field_11177;
    public static final class_2746 PRINTING = class_2746.method_11825("printing");
    public static final class_2746 REFRACTED = class_2746.method_11825("refracted");

    public LightroomBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664()
                .method_11657(FACING, class_2350.field_11043)
                .method_11657(PRINTING, false)
                .method_11657(REFRACTED, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> pBuilder) {
        pBuilder.method_11667(FACING, PRINTING, REFRACTED);
    }

    @Override
    public class_2680 method_9605(class_1750 pContext) {
        return this.method_9564().method_11657(FACING, pContext.method_8042().method_10153());
    }

    @Override
    public void method_9536(class_2680 state, @NotNull class_1937 level, @NotNull class_2338 pos, class_2680 newState, boolean isMoving) {
        if (!state.method_27852(newState.method_26204())) {
            if (level.method_8321(pos) instanceof LightroomBlockEntity lightroomBlockEntity) {
                if (level instanceof class_3218 serverLevel) {
                    class_1264.method_5451(serverLevel, pos, lightroomBlockEntity);
                    lightroomBlockEntity.dropStoredExperience(null);
                }

                level.method_8455(pos, this);
            }

            super.method_9536(state, level, pos, newState, isMoving);
        }
    }

    @Override
    public boolean method_9498(@NotNull class_2680 state) {
        return true;
    }

    @Override
    public int method_9572(@NotNull class_2680 blockState, class_1937 level, @NotNull class_2338 pos) {
        if (level.method_8321(pos) instanceof LightroomBlockEntity lightroomBlockEntity) {
            class_1799 resultStack = lightroomBlockEntity.method_5438(Lightroom.RESULT_SLOT);

            if (resultStack.method_7909() instanceof StackedPhotographsItem stackedPhotographsItem) {
                int photographsCount = stackedPhotographsItem.getPhotographs(resultStack).size();
                return (int) ((photographsCount / (float) stackedPhotographsItem.getStackLimit() * 14) + 1);
            } else if (!resultStack.method_7960()) {
                return 1;
            }
        }

        return 0;
    }

    @Override
    public @NotNull class_2680 method_9598(class_2680 pState, class_2470 pRotation) {
        return pState.method_11657(FACING, pRotation.method_10503(pState.method_11654(FACING)));
    }

    @Override
    public @NotNull class_2680 method_9569(class_2680 pState, class_2415 pMirror) {
        return pState.method_26186(pMirror.method_10345(pState.method_11654(FACING)));
    }

    @Override
    public @NotNull class_1269 method_9534(@NotNull class_2680 blockState, class_1937 level, @NotNull class_2338 pos, @NotNull class_1657 player, @NotNull class_1268 hand, @NotNull class_3965 hitResult) {
        if (!(level.method_8321(pos) instanceof LightroomBlockEntity lightroomBlockEntity))
            return class_1269.field_5814;

        player.method_7281(Exposure.Stats.INTERACT_WITH_LIGHTROOM);

        if (player instanceof class_3222 serverPlayer) {
            lightroomBlockEntity.setLastPlayer(serverPlayer);
            lightroomBlockEntity.method_5431(); // Updates state for client. Without this GUI buttons have some problems. (PrintButton active state)
            PlatformHelper.openMenu(serverPlayer, lightroomBlockEntity, buffer -> buffer.method_10807(pos));
        }

        return class_1269.method_29236(level.field_9236);
    }

    @Override
    public void method_9612(@NotNull class_2680 state, class_1937 level, @NotNull class_2338 pos, @NotNull class_2248 block, @NotNull class_2338 fromPos, boolean pIsMoving) {
        if (!level.field_9236) {
            if (!state.method_11654(PRINTING)) {
                for (class_2350 direction : class_2350.values()) {
                    class_2338 relative = pos.method_10093(direction);
                    if (relative.equals(fromPos) && level.method_49808(relative, direction) > 0
                            && level.method_8321(pos) instanceof LightroomBlockEntity lightroomBlockEntity) {
                        lightroomBlockEntity.startPrintingProcess(true);
                        break;
                    }
                }
            }

            level.method_8652(pos, level.method_8320(pos)
                    .method_11657(LightroomBlock.REFRACTED, level.method_8320(pos.method_10084()).method_26164(Exposure.Tags.Blocks.CHROMATIC_REFRACTORS)),
                    class_2248.field_31028);
        }
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return createBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> blockEntityType) {
        return getBlockTicker(level, state, blockEntityType);
    }

    public static class_2586 createBlockEntity(class_2338 pos, class_2680 state) {
        return new LightroomBlockEntity(pos, state);
    }

    public static <T extends class_2586> class_5558<T> getBlockTicker(class_1937 level, class_2680 state, class_2591<T> blockEntityType) {
        if (!level.field_9236 && blockEntityType.equals(Exposure.BlockEntityTypes.LIGHTROOM.get()))
            return LightroomBlockEntity::serverTick;

        return null;
    }
}
