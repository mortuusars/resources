package io.github.mortuusars.exposure.mixin.client;

import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.client.util.bugger.Bugger;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(net.minecraft.class_309.class)
public class BuggerKeyboardHandlerMixin {
    @Inject(method = "keyPress", at = @At(value = "RETURN"), cancellable = true)
    private void keyPress(long windowPointer, int key, int scanCode, int action, int modifiers, CallbackInfo ci) {
        if (!PlatformHelper.isInDevEnv()) return;
        if (!class_310.method_1551().field_1690.field_1866) return;
        if (class_310.method_1551().field_1755 != null) return;
        if (action == class_3675.field_31997 && Bugger.onKeyPress(key, scanCode, modifiers)) ci.cancel();
        if (action == class_3675.field_31999 && Bugger.onKeyRepeat(key, scanCode, modifiers)) ci.cancel();
        if (action == class_3675.field_31998 && Bugger.onKeyRelease(key, scanCode, modifiers)) ci.cancel();
    }
}
