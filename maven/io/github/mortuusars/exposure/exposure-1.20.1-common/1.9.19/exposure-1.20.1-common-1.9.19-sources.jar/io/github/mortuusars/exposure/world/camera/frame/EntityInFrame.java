package io.github.mortuusars.exposure.world.camera.frame;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.util.ExtraData;
import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public record EntityInFrame(class_2960 id, String name, class_2338 pos, int distance, ExtraData extraData) {
    public static Codec<EntityInFrame> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                    class_2960.field_25139.fieldOf("id").forGetter(EntityInFrame::id),
                    Codec.STRING.optionalFieldOf("name", "").forGetter(EntityInFrame::name),
                    class_2338.field_25064.fieldOf("pos").forGetter(EntityInFrame::pos),
                    Codec.INT.optionalFieldOf("distance", Integer.MAX_VALUE).forGetter(EntityInFrame::distance),
                    ExtraData.field_25128.optionalFieldOf("extra_data", ExtraData.EMPTY).forGetter(EntityInFrame::extraData))
            .apply(instance, EntityInFrame::new));

    public void toPacket(class_2540 buf) {
        buf.method_10812(id);
        buf.method_10814(name);
        buf.method_10807(pos);
        buf.writeInt(distance);
        extraData.toPacket(buf);
    }

    public static EntityInFrame fromPacket(class_2540 buf) {
        return new EntityInFrame(buf.method_10810(),buf.method_19772(),buf.method_10811(),buf.readInt(),ExtraData.fromPacket(buf));
    }

    public static EntityInFrame of(class_1297 cameraHolder, class_1297 entity) {
        return of(cameraHolder, entity, ExtraData.EMPTY);
    }

    public static EntityInFrame of(class_1297 cameraHolder, class_1297 entity, Consumer<ExtraData> data) {
        ExtraData extraData = new ExtraData();
        data.accept(extraData);
        return of(cameraHolder, entity, extraData);
    }

    public static EntityInFrame of(class_1297 cameraHolder, class_1297 entity, ExtraData extraData) {
        class_2960 key = class_1299.method_5890(entity.method_5864());
        String name = entity.method_5477().getString();
        int distance = (int) cameraHolder.method_5739(entity);
        return new EntityInFrame(key, name, entity.method_24515(), distance, extraData);
    }
}
