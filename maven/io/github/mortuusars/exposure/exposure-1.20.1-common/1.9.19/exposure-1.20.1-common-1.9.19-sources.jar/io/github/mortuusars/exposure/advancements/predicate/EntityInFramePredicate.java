package io.github.mortuusars.exposure.advancements.predicate;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Stuff;
import io.github.mortuusars.exposure.world.camera.frame.EntityInFrame;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2096;
import net.minecraft.class_2960;

public record EntityInFramePredicate(Optional<class_2960> type,
                                     Optional<String> name,
                                     class_2096.class_2100 distance) {
    public static final Codec<EntityInFramePredicate> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_2960.field_25139.optionalFieldOf("type").forGetter(EntityInFramePredicate::type),
            Codec.STRING.optionalFieldOf("name").forGetter(EntityInFramePredicate::name),
            Stuff.INTS_CODEC.optionalFieldOf("distance", class_2096.class_2100.field_9708).forGetter(EntityInFramePredicate::distance)
    ).apply(instance, EntityInFramePredicate::new));

    public static final EntityInFramePredicate ANY = new EntityInFramePredicate(Optional.empty(),Optional.empty(), class_2096.class_2100.field_9708);

    public boolean matches(EntityInFrame entity) {
        if (type.isPresent() && !type.get().equals(entity.id())) return false;
        if (name.isPresent() && !name.get().equals(entity.name())) return false;
        return distance().method_9054(entity.distance());
    }

    public boolean matches(List<EntityInFrame> entitiesInFrame) {
        return entitiesInFrame.stream().anyMatch(this::matches);
    }
}
