package io.github.mortuusars.exposure.world.item.component.album;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Stuff;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2561;

public record SignedAlbumPage(class_1799 photograph, class_2561 note) {
    public static final Codec<SignedAlbumPage> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_1799.field_24671.optionalFieldOf("photograph", class_1799.field_8037).forGetter(SignedAlbumPage::photograph),
            Stuff.COMPONENT_CODEC.optionalFieldOf("note",class_2561.method_43473()).forGetter(SignedAlbumPage::note)
    ).apply(instance, SignedAlbumPage::new));

    public void toPacket(class_2540 buf) {
        buf.method_10793(photograph);
        buf.method_10805(note);
    }

    public static SignedAlbumPage fromPacket(class_2540 buf) {
        return new SignedAlbumPage(buf.method_10819(),buf.method_10808());
    }

    public static final SignedAlbumPage EMPTY = new SignedAlbumPage(class_1799.field_8037, class_2561.method_43473());

    public boolean isEmpty() {
        return this.equals(EMPTY) || (photograph().method_7960() && note().getString().isEmpty());
    }
}
