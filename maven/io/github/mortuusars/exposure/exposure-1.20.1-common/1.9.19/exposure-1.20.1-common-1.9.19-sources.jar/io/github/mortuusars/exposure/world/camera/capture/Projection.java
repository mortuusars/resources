package io.github.mortuusars.exposure.world.camera.capture;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2540;

public record Projection(String path, DitherMode mode) {
    public static final Codec<Projection> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("path").forGetter(Projection::path),
            DitherMode.CODEC.optionalFieldOf("mode", DitherMode.DITHERED).forGetter(Projection::mode)
    ).apply(instance, Projection::new));

    public void toPacket(class_2540 buf) {
        buf.method_10814(path);
        buf.method_10817(mode);
    }

    public static Projection fromPacket(class_2540 buf) {
        return new Projection(buf.method_19772(),buf.method_10818(DitherMode.class));
    }
}
