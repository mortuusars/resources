package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.world.camera.CameraId;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import io.github.mortuusars.exposure.network.packet.Packet;

public record UniqueSoundPlayShutterTickingS2CP(int entityId,
                                                CameraId cameraId,
                                                float volume,
                                                float pitch,
                                                int durationTicks) implements Packet {
    public static final class_2960 ID = Exposure.resource("unique_sound_play_shutter_ticking");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.writeInt(entityId);
        cameraId.toPacket(buf);
        buf.writeFloat(volume);
        buf.writeFloat(pitch);
        buf.writeInt(durationTicks);
    }

    public static UniqueSoundPlayShutterTickingS2CP fromPacket(class_2540 buf) {
        return new UniqueSoundPlayShutterTickingS2CP(buf.readInt(),CameraId.fromPacket(buf),buf.readFloat(),buf.readFloat(),buf.readInt());
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.playShutterTickingSound(this);
        return true;
    }
}
