package io.github.mortuusars.exposure.network.packet.common;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public enum ActiveCameraDeactivateCommonPacket implements Packet {
    INSTANCE;

    public static final class_2960 ID = Exposure.resource("active_camera_deactivate");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        player.getActiveExposureCameraOptional().ifPresent(camera -> {
            camera.map((item, stack) -> item.deactivate(camera.getHolder().asHolderEntity(), stack));
            player.removeActiveExposureCamera();
        });
        return true;
    }

    @Override
    public void toPacket(class_2540 buf) {

    }

    public static ActiveCameraDeactivateCommonPacket fromBuffer(class_2540 buffer) {
        return INSTANCE;
    }
}
