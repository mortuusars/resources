package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.entity.CameraOperator;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record ActiveCameraRemoveS2CP(int operatorEntityId) implements Packet {
    public static final class_2960 ID = Exposure.resource("active_camera_remove");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.writeInt(operatorEntityId);
    }

    public static ActiveCameraRemoveS2CP fromPacket(class_2540 buf) {
        return new ActiveCameraRemoveS2CP(buf.readInt());
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (player.method_37908().method_8469(operatorEntityId) instanceof CameraOperator operator) {
            operator.removeActiveExposureCamera();
        }
        return true;
    }
}
