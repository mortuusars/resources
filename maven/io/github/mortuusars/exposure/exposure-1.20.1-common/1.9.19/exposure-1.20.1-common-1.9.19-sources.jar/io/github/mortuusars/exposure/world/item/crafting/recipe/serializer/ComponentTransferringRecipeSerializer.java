package io.github.mortuusars.exposure.world.item.crafting.recipe.serializer;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import io.github.mortuusars.exposure.world.item.crafting.recipe.ComponentTransferringRecipe;
import io.github.mortuusars.exposure.world.item.crafting.recipe.FilmDevelopingRecipe;
import io.github.mortuusars.exposure.world.item.crafting.recipe.PhotographAgingRecipe;
import io.github.mortuusars.exposure.world.item.crafting.recipe.PhotographCopyingRecipe;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_2371;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_7710;

public class ComponentTransferringRecipeSerializer<T extends ComponentTransferringRecipe> implements class_1865<T> {

    protected final String target;
    private final Factory<T> factory;

    public ComponentTransferringRecipeSerializer(String target, Factory<T> factory) {
        this.target = target;
        this.factory = factory;
    }

    public String target() {
        return target;
    }

    public static final Factory<ComponentTransferringRecipe> COMPONENT_TRANSFERRING = (id, targetIngredient, ingredients, result) ->
      new ComponentTransferringRecipe(id,class_7710.field_40251,targetIngredient,ingredients,result);

    public static final Factory<ComponentTransferringRecipe> PHOTOGRAPH_AGING = PhotographAgingRecipe::new;
    public static final Factory<ComponentTransferringRecipe> PHOTOGRAPH_COPYING = PhotographCopyingRecipe::new;
    public static final Factory<ComponentTransferringRecipe> FILM_DEVELOPING = FilmDevelopingRecipe::new;

    @Override
    public T method_8121(class_2960 recipeId, JsonObject serializedRecipe) {
        class_1856 targetIngredient = class_1856.method_52177(class_3518.method_52226(serializedRecipe, target));
        class_2371<class_1856> ingredients = getIngredients(class_3518.method_15261(serializedRecipe, "ingredients"));
        class_1799 result = class_1869.method_35228(class_3518.method_15296(serializedRecipe, "result"));
        if (targetIngredient.method_8103())
            throw new JsonParseException("Recipe should have '"+target+"' ingredient.");
        return factory.create(recipeId,targetIngredient,ingredients,result);
    }

    private static class_2371<class_1856> getIngredients(JsonArray jsonArray) {
        class_2371<class_1856> ingredients = class_2371.method_10211();

        for (int i = 0; i < jsonArray.size(); ++i) {
            class_1856 ingredient = class_1856.method_52177(jsonArray.get(i));
            if (!ingredient.method_8103())
                ingredients.add(ingredient);
        }

        if (ingredients.isEmpty())
            throw new JsonParseException("No ingredients for a recipe.");
        else if (ingredients.size() > 3 * 3)
            throw new JsonParseException("Too many ingredients for a recipe. The maximum is 9.");
        return ingredients;
    }

    @Override
    public T method_8122(class_2960 recipeId, class_2540 buffer) {
        class_1856 transferredIngredient = class_1856.method_8086(buffer);
        int ingredientsCount = buffer.method_10816();
        class_2371<class_1856> ingredients = class_2371.method_10213(ingredientsCount, class_1856.field_9017);
        ingredients.replaceAll(ignored -> class_1856.method_8086(buffer));
        class_1799 result = buffer.method_10819();

        return factory.create(recipeId,transferredIngredient,ingredients,result);
    }

    @Override
    public void toNetwork(class_2540 buffer, T recipe) {
        recipe.getSourceIngredient().method_8088(buffer);
        buffer.method_10804(recipe.method_8117().size());
        for (class_1856 ingredient : recipe.method_8117()) {
            ingredient.method_8088(buffer);
        }
        buffer.method_10793(recipe.getResult());
    }

    public interface Factory<T>{
        T create(class_2960 id,class_1856 targetIngredient,class_2371<class_1856> ingredients,class_1799 result);
    }
}
