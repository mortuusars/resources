package io.github.mortuusars.exposure.world.camera.component;

import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_2561;
import net.minecraft.class_3542;
import net.minecraft.class_5250;
import org.jetbrains.annotations.NotNull;

public enum SelfTimer implements class_3542 {
    OFF("off", 0),
    ONE("one", 1),
    TWO("two", 2),
    FIVE("five", 5),
    TEN("ten", 10);

    public static final Codec<SelfTimer> CODEC = class_3542.method_28140(SelfTimer::values);

    private final String name;
    private final int seconds;

    SelfTimer(String name, int seconds) {
        this.name = name;
        this.seconds = seconds;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }

    public int getSeconds() {
        return seconds;
    }

    public int getTicks() {
        return seconds * 20;
    }

    public class_5250 translate() {
        return class_2561.method_43471("gui." + Exposure.ID + ".self_timer." + name);
    }
}
