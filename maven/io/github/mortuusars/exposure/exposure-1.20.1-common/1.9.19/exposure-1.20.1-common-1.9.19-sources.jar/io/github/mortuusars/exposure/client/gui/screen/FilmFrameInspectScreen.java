package io.github.mortuusars.exposure.client.gui.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.client.gui.BetterImageButton;
import io.github.mortuusars.exposure.client.gui.Widgets;
import io.github.mortuusars.exposure.client.gui.component.SteppedZoom;
import io.github.mortuusars.exposure.client.gui.screen.element.Pager;
import io.github.mortuusars.exposure.client.image.modifier.ImageEffect;
import io.github.mortuusars.exposure.client.image.renderable.RenderableImage;
import io.github.mortuusars.exposure.client.input.Key;
import io.github.mortuusars.exposure.client.input.KeyBindings;
import io.github.mortuusars.exposure.client.render.image.RenderCoordinates;
import io.github.mortuusars.exposure.client.util.GuiUtil;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.util.PagingDirection;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.FilmColor;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.sound.SoundEffect;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_4597;

public class FilmFrameInspectScreen extends class_437 {
    public static final class_2960 TEXTURE = Exposure.resource("textures/gui/film_frame_inspect.png");

    public static final int BG_SIZE = 78;
    public static final int FRAME_SIZE = 54;
    public static final int BUTTON_SIZE = 16;

    protected final Pager pager = new Pager()
            .setChangeSound(new SoundEffect(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK))
            .onPageChanged(this::pageChanged);

    protected final SteppedZoom zoom = new SteppedZoom()
            .zoomInSteps(4)
            .zoomOutSteps(4)
            .zoomPerStep(1.4)
            .defaultZoom(1);

    protected final KeyBindings keyBindings = KeyBindings.of(
            Key.press(Minecrft.options().field_1822).executes(this::method_25419),
            Key.press(class_3675.field_31933).or(Key.press(class_3675.field_31937)).executes(zoom::zoomIn),
            Key.press(GLFW.GLFW_KEY_KP_SUBTRACT).or(Key.press(class_3675.field_31941)).executes(zoom::zoomOut),
            Key.press(class_3675.field_31983).or(Key.press(class_3675.field_32015)).executes(pager::previousPage),
            Key.press(class_3675.field_31984).or(Key.press(class_3675.field_32018)).executes(pager::nextPage),
            Key.release(class_3675.field_31983).or(Key.press(class_3675.field_32015)).executes(pager::resetCooldown),
            Key.release(class_3675.field_31984).or(Key.press(class_3675.field_32018)).executes(pager::resetCooldown)
    );

    protected final List<Frame> frames;

    protected float zoomFactor;
    protected float x;
    protected float y;

    public FilmFrameInspectScreen(List<Frame> frames) {
        this(frames, frames.size() - 1);
    }

    public FilmFrameInspectScreen(List<Frame> frames, int startingFrame) {
        super(class_2561.method_43473());
        this.frames = new ArrayList<>(frames);
        initPager(startingFrame);
    }

    protected void initPager(int startingFrame) {
        pager.setPagesCount(frames.size());
        pager.setPage(startingFrame);
        Collections.rotate(frames, -startingFrame);
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        zoomFactor = ((float) field_22790 / BG_SIZE) / (float)zoom.getZoomPerStep();

        /*ImageButton previousButton = new ImageButton(0, (int) (height / 2f - 16 / 2f), 16, 16,
                Widgets.PREVIOUS_BUTTON_SPRITES,
                button -> pager.changePage(PagingDirection.PREVIOUS), Component.translatable("gui.exposure.previous_page"));

        ImageButton nextButton = new ImageButton(width - 16, (int) (height / 2f - 16 / 2f), 16, 16,
                Widgets.NEXT_BUTTON_SPRITES,
                button -> pager.changePage(PagingDirection.NEXT), Component.translatable("gui.exposure.next_page"));*/

        BetterImageButton previousButton = new BetterImageButton(0, (int) (field_22790 / 2f - BUTTON_SIZE / 2f),
                BUTTON_SIZE, BUTTON_SIZE, Widgets.PREVIOUS_BUTTON_SPRITES, button -> pager.changePage(PagingDirection.PREVIOUS));
        BetterImageButton nextButton = new BetterImageButton(field_22789 - BUTTON_SIZE, (int) (field_22790 / 2f - BUTTON_SIZE / 2f), BUTTON_SIZE,
                 BUTTON_SIZE, Widgets.NEXT_BUTTON_SPRITES,button -> pager.changePage(PagingDirection.NEXT));
        method_37063(previousButton);
        method_37063(nextButton);

        pager.setPagesCount(frames.size())
                .setPreviousPageButton(previousButton)
                .setNextPageButton(nextButton);
    }

    protected Frame getCurrentFrame() {
        return frames.get(0);
    }

    protected void pageChanged(int oldPage, int newPage) {
        int distance = newPage - oldPage;
        Collections.rotate(frames, -distance);
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        float scale = (float) (zoom.get() * zoomFactor);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();

        method_25420(guiGraphics);

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(x, y, 0);
        guiGraphics.method_51448().method_46416(field_22789 / 2f, field_22790 / 2f, 50);
        guiGraphics.method_51448().method_22905(scale, scale, scale);

        guiGraphics.method_51448().method_46416(BG_SIZE / -2f, BG_SIZE / -2f, 0);

        RenderSystem.setShaderTexture(0, TEXTURE);
        GuiUtil.blit(guiGraphics.method_51448(), 0, 0, BG_SIZE, BG_SIZE, 0, 0, 256, 256, 0);

        Frame frame = getCurrentFrame();
        ExposureType filmType = frame.type();
        FilmColor filmColor = filmType.getFilmColor();

        RenderSystem.setShaderColor(filmColor.r(), filmColor.g(), filmColor.b(), filmColor.a());
        GuiUtil.blit(guiGraphics.method_51448(), 0, 0, BG_SIZE, BG_SIZE, 0, BG_SIZE, 256, 256, 0);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        guiGraphics.method_51448().method_46416(12, 12, 0);
        RenderableImage image = ExposureClient.renderedExposures().getOrCreate(frame).modifyWith(ImageEffect.NEGATIVE_FILM);
        class_4597.class_4598 bufferSource = class_310.method_1551().method_22940().method_23000();
        ExposureClient.imageRenderer().render(image,  guiGraphics.method_51448(), bufferSource,
                new RenderCoordinates(0, 0, FRAME_SIZE, FRAME_SIZE), filmType.getImageColor());
        bufferSource.method_22993();

        guiGraphics.method_51448().method_22909();

        guiGraphics.method_51448().method_22903();
        // Places widgets above, because they will be covered when photo is zoomed in
//        guiGraphics.pose().translate(0, 0, 100);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        guiGraphics.method_51448().method_22909();
    }

   // @Override
    public void renderBackground(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        // Background is rendered manually in #render method.
        // Otherwise, background will be rendered on top
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        return keyBindings.keyPressed(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        return keyBindings.keyReleased(keyCode, scanCode, modifiers) || super.method_16803(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollY) {
        if (super.method_25401(mouseX, mouseY, scrollY)) return true;

        if (scrollY >= 0.0) {
            zoom.zoomIn();
        } else {
            zoom.zoomOut();
        }
        return true;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (super.method_25403(mouseX, mouseY, button, dragX, dragY)) return true;

        if (button == class_3675.field_32000) {
            float centerX = field_22789 / 2f;
            float centerY = field_22790 / 2f;
            x = (float) class_3532.method_15350(x + dragX, -centerX, centerX);
            y = (float) class_3532.method_15350(y + dragY, -centerY, centerY);
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
