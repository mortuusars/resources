package io.github.mortuusars.exposure.client.gui.screen;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.client.export.ImageExporter;
import io.github.mortuusars.exposure.client.gui.BetterImageButton;
import io.github.mortuusars.exposure.client.gui.Widgets;
import io.github.mortuusars.exposure.client.gui.component.SteppedZoom;
import io.github.mortuusars.exposure.client.gui.screen.element.Pager;
import io.github.mortuusars.exposure.client.image.modifier.ImageEffect;
import io.github.mortuusars.exposure.client.input.Key;
import io.github.mortuusars.exposure.client.input.KeyBindings;
import io.github.mortuusars.exposure.client.input.Modifier;
import io.github.mortuusars.exposure.client.render.photograph.PhotographStyle;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.util.PagingDirection;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import io.github.mortuusars.exposure.world.item.StackedPhotographsItem;
import io.github.mortuusars.exposure.world.item.util.ItemAndStack;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import io.github.mortuusars.exposure.world.photograph.PhotographType;
import io.github.mortuusars.exposure.world.sound.SoundEffect;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.glfw.GLFW;

import java.io.File;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3544;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_4597;
import net.minecraft.class_765;

public class PhotographScreen extends class_437 {
    protected final Pager pager = new Pager()
            .setCycled(true)
            .setChangeSound(new SoundEffect(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK))
            .onPageChanged(this::pageChanged);

    protected final SteppedZoom zoom = new SteppedZoom()
            .zoomInSteps(4)
            .zoomOutSteps(4)
            .zoomPerStep(1.4)
            .defaultZoom(1);

    protected final KeyBindings keyBindings = KeyBindings.of(
            Key.press(Minecrft.options().field_1822).executes(this::method_25419),
            Key.press(class_3675.field_31933).or(Key.press(class_3675.field_31937)).executes(zoom::zoomIn),
            Key.press(GLFW.GLFW_KEY_KP_SUBTRACT).or(Key.press(class_3675.field_31941)).executes(zoom::zoomOut),
            Key.press(Modifier.CONTROL, class_3675.field_32023).executes(this::dropAsItem),
            Key.press(Modifier.CONTROL, class_3675.field_32017).executes(this::copyIdentifierToClipboard),
            Key.press(Modifier.CONTROL | Modifier.SHIFT, class_3675.field_32017).executes(this::copySavedFilePathToClipboard),
            Key.press(Modifier.CONTROL, class_3675.field_31908).executes(this::openSavedFile),
            Key.press(class_3675.field_31983).or(Key.press(class_3675.field_32015)).executes(pager::previousPage),
            Key.press(class_3675.field_31984).or(Key.press(class_3675.field_32018)).executes(pager::nextPage),
            Key.release(class_3675.field_31983).or(Key.press(class_3675.field_32015)).executes(pager::resetCooldown),
            Key.release(class_3675.field_31984).or(Key.press(class_3675.field_32018)).executes(pager::resetCooldown)
    );

    protected final PhotographProvider photographProvider;

    protected float x;
    protected float y;

    protected final Set<String> savedExposureIds = new HashSet<>();
    protected final Map<String, File> savedExposureFiles = new HashMap<>();

    protected ArrayList<ItemAndStack<PhotographItem>> photographs = new ArrayList<>();

    public PhotographScreen(PhotographProvider photographProvider) {
        super(class_2561.method_43473());
        this.photographProvider = photographProvider;
        setPhotographs(photographProvider.get());

        if (shouldQueryAllPhotographsImmediately()) {
            queryAllPhotographs(photographs);
        }
    }

    public PhotographScreen(List<ItemAndStack<PhotographItem>> photographs) {
        this(PhotographProvider.fixed(photographs));
    }

    protected void setPhotographs(List<ItemAndStack<PhotographItem>> photographs) {
        this.photographs.clear();
        this.photographs.addAll(photographs);
        this.pager.setPagesCount(photographs.size());
        this.pager.setPage(0);
    }

    @Override
    public void method_25393() {
        if (photographProvider.shouldRefresh()) {
            setPhotographs(photographProvider.get());
        }
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        BetterImageButton previousButton = new BetterImageButton(0, (int) (field_22790 / 2f - 16 / 2f), 16, 16,
                Widgets.PREVIOUS_BUTTON_SPRITES,
                button -> pager.changePage(PagingDirection.PREVIOUS), class_2561.method_43471("gui.exposure.previous_page"));
        method_37063(previousButton);

        BetterImageButton nextButton = new BetterImageButton(field_22789 - 16, (int) (field_22790 / 2f - 16 / 2f), 16, 16,
                Widgets.NEXT_BUTTON_SPRITES,
                button -> pager.changePage(PagingDirection.NEXT), class_2561.method_43471("gui.exposure.next_page"));
        method_37063(nextButton);

        pager.setPreviousPageButton(previousButton)
             .setNextPageButton(nextButton);
    }

    protected boolean shouldQueryAllPhotographsImmediately() {
        return true;
    }

    protected void queryAllPhotographs(List<ItemAndStack<PhotographItem>> photographs) {
        for (ItemAndStack<PhotographItem> photograph : photographs) {
            photograph.getItem().getIdentifier(photograph.getItemStack())
                    .ifId(id -> ExposureClient.exposureStore().getOrRequest(id));
        }
    }

    public ItemAndStack<PhotographItem> getCurrentPhotograph() {
        return photographs.get(0);
    }

    protected void pageChanged(int oldPage, int newPage) {
        int distance = newPage - oldPage;
        Collections.rotate(photographs, -distance);
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        float zoomFactor = field_22790 * 0.8f;
        float scale = (float) (zoom.get() * zoomFactor);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();

        method_25420(guiGraphics);

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(x, y, 0);
        guiGraphics.method_51448().method_46416(field_22789 / 2f, field_22790 / 2f, 50);
        guiGraphics.method_51448().method_22905(scale, scale, scale);
        guiGraphics.method_51448().method_22904(-0.5, -0.5, 0);

        class_4597.class_4598 bufferSource = Minecrft.get().method_22940().method_23000();

        ExposureClient.photographRenderer().renderStackedPhotographs(photographs, guiGraphics.method_51448(), bufferSource,
                class_765.field_32767, 255, 255, 255, 255);

        bufferSource.method_22993();
        guiGraphics.method_51448().method_22909();

        ItemAndStack<PhotographItem> photograph = getCurrentPhotograph();

        guiGraphics.method_51448().method_22903();
        // Places widgets above photograph, because they will be covered when photo is zoomed in
        guiGraphics.method_51448().method_46416(0, 0, 100);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        renderFrameInfoHint(guiGraphics, mouseX, mouseY, photograph);
        guiGraphics.method_51448().method_22909();

        if (Config.Client.EXPORT_PHOTOGRAPH_WHEN_VIEWED.get()) {
            trySaveToFile(photograph);
        }
    }

    private void renderFrameInfoHint(@NotNull class_332 guiGraphics, int mouseX, int mouseY, ItemAndStack<PhotographItem> photograph) {
        if (Minecrft.get().field_1724 == null || !Minecrft.get().field_1724.method_7337()) {
            return;
        }

        ExposureIdentifier identifier = photograph.getItem().getIdentifier(photograph.getItemStack());
        if (identifier == ExposureIdentifier.EMPTY) {
            return;
        }

        guiGraphics.method_25303(field_22793, "?", field_22789 - field_22793.method_1727("?") - 10, 10, 0xFFFFFFFF);

        if (mouseX > field_22789 - 20 && mouseX < field_22789 && mouseY < 20) {
            String exposureName = identifier.map(id -> id, class_2960::toString);

            List<class_2561> lines = new ArrayList<>();

            lines.add(class_2561.method_43470(exposureName));
            lines.add(class_2561.method_43469("gui.exposure.photograph_screen.drop_as_item_tooltip", class_2561.method_43470("CTRL + I")));
            lines.add(class_2561.method_43469("gui.exposure.photograph_screen.copy_" +
                    identifier.map(id -> "id", texture -> "texture_path") + "_tooltip", "CTRL + C"));

            identifier.getId().ifPresent(id -> {
                if (savedExposureFiles.containsKey(id)) {
                    lines.add(class_2561.method_43469("gui.exposure.photograph_screen.copy_saved_file_path_tooltip", class_2561.method_43470("CTRL + SHIFT + C")));
                    lines.add(class_2561.method_43469("gui.exposure.photograph_screen.open_saved_file_tooltip", class_2561.method_43470("CTRL + S")));
                }
            });

            guiGraphics.method_51437(field_22793, lines, Optional.empty(), mouseX, mouseY + 20);
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        return keyBindings.keyPressed(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        return keyBindings.keyReleased(keyCode, scanCode, modifiers) || super.method_16803(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY,double scrollY) {
        if (super.method_25401(mouseX, mouseY, scrollY)) return true;

        if (scrollY >= 0.0) {
            zoom.zoomIn();
        } else {
            zoom.zoomOut();
        }
        return true;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (super.method_25403(mouseX, mouseY, button, dragX, dragY)) return true;

        if (button == class_3675.field_32000) {
            float centerX = field_22789 / 2f;
            float centerY = field_22790 / 2f;
            x = (float) class_3532.method_15350(x + dragX, -centerX, centerX);
            y = (float) class_3532.method_15350(y + dragY, -centerY, centerY);
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // --

    protected boolean dropAsItem() {
        if (!Minecrft.player().method_7337()) {
            return false;
        }
        class_1799 droppedStack = getCurrentPhotograph().getItemStack().method_7972();

        // Set type so copying recipe works properly.
        Frame frame = Exposure.DataComponents.getPhotographFrame(droppedStack, Frame.EMPTY);
        ExposureType type = frame.type();
        Exposure.DataComponents.setPhotographType(droppedStack, type);

        Minecrft.gameMode().method_2915(droppedStack);
        Minecrft.player().method_7353(class_2561.method_43469("gui.exposure.photograph_screen.item_dropped_message",
                droppedStack.method_7954()), false);
        return true;
    }

    protected boolean copyIdentifierToClipboard() {
        ExposureIdentifier identifier = getCurrentPhotograph().map(PhotographItem::getIdentifier);
        if (!Minecrft.player().method_7337() || identifier.equals(ExposureIdentifier.EMPTY)) {
            return false;
        }
        String text = identifier.map(id -> id, class_2960::toString);
        Minecrft.get().field_1774.method_1455(text);
        Minecrft.player().method_7353(
                class_2561.method_43469("gui.exposure.photograph_screen.copied_message", text), false);
        return true;
    }

    protected boolean copySavedFilePathToClipboard() {
        return getCurrentPhotograph()
                .map(PhotographItem::getIdentifier)
                .mapId(id -> {
                    File file = savedExposureFiles.get(id) ;
                        Minecrft.get().field_1774.method_1455(file.getAbsolutePath());
                        Minecrft.player().method_7353(
                                class_2561.method_43469("gui.exposure.photograph_screen.copied_message", file.getAbsolutePath()), false);
                        return true;
                }).orElse(false);
    }

    protected boolean openSavedFile() {
        return getCurrentPhotograph()
                .map(PhotographItem::getIdentifier)
                .mapId(id -> {
                    File file = savedExposureFiles.get(id);
                        class_156.method_668().method_672(file);
                        return true;
                }).orElse(false);
    }

    // --

    protected void trySaveToFile(ItemAndStack<PhotographItem> photograph) {
        Frame frame = photograph.getItem().getFrame(photograph.getItemStack());

        if (frame == Frame.EMPTY || !frame.identifier().isId() || !frame.isTakenBy(Minecrft.player())) {
            return;
        }

        String id = frame.identifier().getId().orElseThrow();

        PhotographType photographType = photograph.getItem().getType(photograph.getItemStack());
        PhotographStyle photographStyle = PhotographStyle.of(photograph.getItemStack());

        String filename = getFilename(id, photographType);

        if (savedExposureIds.contains(filename)) {
            return;
        }

        ExposureClient.exposureStore().getOrRequest(id).getData().ifPresent(exposure -> {
            savedExposureIds.add(filename);

            CompletableFuture.runAsync(() -> new ImageExporter(exposure, filename)
                            .modify(ImageEffect.chain(
                                    photographStyle.modifier(),
                                    ImageEffect.Resize.multiplier(Config.Client.EXPORT_SIZE_MULTIPLIER.get())
                            ))
                            .toExposuresFolder()
                            .organizeByWorld(Config.Client.EXPORT_ORGANIZE_BY_WORLD.get())
                            .setCreationDate(exposure.getTag().unixTimestamp())
                            .onExport(file -> savedExposureFiles.put(id, file))
                            .export())
                    .handle((unused, throwable) -> {
                        Exposure.LOGGER.error(throwable.getMessage());
                        return null;
                    });
        });
    }

    protected @NotNull String getFilename(String id, PhotographType photographType) {
        String suffix = photographType.getFileSuffix();
        if (!class_3544.method_15438(suffix)) {
            return id + "_" + suffix;
        }
        return id;
    }

    public interface PhotographProvider {
        boolean shouldRefresh();

        /**
         * Should have at least one photograph.
         */
        List<ItemAndStack<PhotographItem>> get();

        static PhotographProvider fixed(List<ItemAndStack<PhotographItem>> photographs) {
            Preconditions.checkState(!photographs.isEmpty(), "No photographs to display.");
            return new PhotographProvider() {
                private final List<ItemAndStack<PhotographItem>> list = photographs;

                @Override
                public boolean shouldRefresh() {
                    return false;
                }

                @Override
                public List<ItemAndStack<PhotographItem>> get() {
                    return list;
                }
            };
        }

        static PhotographProvider fromPhotographItem(int slot) {
            return new ItemProvider(() -> Minecrft.player().method_31548().method_5438(slot));
        }

        class ItemProvider implements PhotographProvider {
            protected Supplier<class_1799> itemSupplier;
            protected List<ItemAndStack<PhotographItem>> photographs;

            public ItemProvider(Supplier<class_1799> itemSupplier) {
                this.itemSupplier = itemSupplier;
                class_1799 stack = itemSupplier.get();
                Preconditions.checkState(stack.method_7909() instanceof PhotographItem || stack.method_7909() instanceof StackedPhotographsItem,
                        "itemSupplier should supply valid Photograph or Stacked Photographs item stack at the moment of creation.");
                this.photographs = fromItemStack(stack);
            }

            protected List<ItemAndStack<PhotographItem>> fromItemStack(class_1799 stack) {
                if (stack.method_7909() instanceof PhotographItem) {
                    return List.of(new ItemAndStack<>(stack));
                }

                if (stack.method_7909() instanceof StackedPhotographsItem stackedPhotographsItem) {
                    return stackedPhotographsItem.getPhotographs(stack);
                }

                return Collections.emptyList();
            }

            @Override
            public boolean shouldRefresh() {
                class_1799 item = itemSupplier.get();
                List<ItemAndStack<PhotographItem>> newPhotographs = fromItemStack(item);

                if (newPhotographs.isEmpty()) {
                    return false;
                }

                boolean shouldRefresh = !get().equals(newPhotographs);
                if (shouldRefresh) {
                    photographs = newPhotographs;
                }
                return shouldRefresh;
            }

            @Override
            public List<ItemAndStack<PhotographItem>> get() {
                return photographs;
            }
        }
    }
}