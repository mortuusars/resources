package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public record ExposureRequestC2SP(String id) implements Packet {
    public static final class_2960 ID = Exposure.resource("exposure_request");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_10814(id);
    }

    public static ExposureRequestC2SP fromPacket(class_2540 buf) {
        return new ExposureRequestC2SP(buf.method_19772());
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ExposureServer.exposureRepository().handleClientRequest((class_3222) player, id);
        return true;
    }
}
