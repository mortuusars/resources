package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.camera.CameraOnStand;
import io.github.mortuusars.exposure.world.item.camera.CameraSetting;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import io.github.mortuusars.exposure.network.packet.Packet;
import org.jetbrains.annotations.Nullable;

public record ActiveCameraSetSettingC2SP(CameraSetting<?> setting, byte[] encodedValue) implements Packet {
    public static final class_2960 ID = Exposure.resource("active_camera_set_setting");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        setting.toPacket(buf);
        buf.method_10813(encodedValue);
    }

    public static ActiveCameraSetSettingC2SP fromPacket(class_2540 buf) {
        return new ActiveCameraSetSettingC2SP(CameraSetting.fromPacket(buf), buf.method_10795());
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        @Nullable Camera camera = player.getActiveExposureCamera();
        if (camera == null || camera.isEmpty()) return false;

        setting.decodeAndSet(camera.getHolder(), camera.getItemStack(), encodedValue);
        if (camera instanceof CameraOnStand cameraOnStand) {
            cameraOnStand.getStand().forceUpdate();
        }
        return true;
    }
}