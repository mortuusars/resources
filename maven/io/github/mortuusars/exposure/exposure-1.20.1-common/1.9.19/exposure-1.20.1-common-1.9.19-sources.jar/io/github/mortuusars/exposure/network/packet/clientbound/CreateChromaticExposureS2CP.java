package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record CreateChromaticExposureS2CP(String id, List<ExposureIdentifier> layers) implements Packet {
    public static final class_2960 ID = Exposure.resource("create_chromatic_exposure");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_10814(id);
        buf.method_34062(layers,(buf1, exposureIdentifier) -> exposureIdentifier.toPacket(buf1));
    }

    public static CreateChromaticExposureS2CP fromPacket(class_2540 buf) {
        return new CreateChromaticExposureS2CP(buf.method_19772(),buf.method_34066(ExposureIdentifier::fromPacket));
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.createChromaticExposure(this);
        return true;
    }
}
