package io.github.mortuusars.exposure.world.block.entity;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.world.block.LightroomBlock;
import io.github.mortuusars.exposure.world.level.LevelUtil;
import io.github.mortuusars.exposure.world.lightroom.PrintingMode;
import io.github.mortuusars.exposure.world.lightroom.PrintingProcess;
import io.github.mortuusars.exposure.world.level.storage.ExposureData;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.inventory.LightroomMenu;
import io.github.mortuusars.exposure.world.item.util.ItemAndStack;
import io.github.mortuusars.exposure.world.item.ChromaticSheetItem;
import io.github.mortuusars.exposure.world.item.DevelopedFilmItem;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import io.github.mortuusars.exposure.world.item.StackedPhotographsItem;
import net.minecraft.class_1262;
import net.minecraft.class_1278;
import net.minecraft.class_1303;
import net.minecraft.class_1542;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2624;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3913;
import net.minecraft.core.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Comparator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class LightroomBlockEntity extends class_2624 implements class_1278 {
    public static final int CONTAINER_DATA_SIZE = 3;
    public static final int CONTAINER_DATA_PROGRESS_ID = 0;
    public static final int CONTAINER_DATA_PRINT_TIME_ID = 1;
    public static final int CONTAINER_DATA_SELECTED_FRAME_ID = 2;

    protected final class_3913 containerData = new class_3913() {
        public int method_17390(int id) {
            return switch (id) {
                case CONTAINER_DATA_PROGRESS_ID -> LightroomBlockEntity.this.progress;
                case CONTAINER_DATA_PRINT_TIME_ID -> LightroomBlockEntity.this.printTime;
                case CONTAINER_DATA_SELECTED_FRAME_ID -> LightroomBlockEntity.this.getSelectedFrameIndex();
                default -> 0;
            };
        }

        public void method_17391(int id, int value) {
            if (id == CONTAINER_DATA_PROGRESS_ID)
                LightroomBlockEntity.this.progress = value;
            else if (id == CONTAINER_DATA_PRINT_TIME_ID)
                LightroomBlockEntity.this.printTime = value;
            else if (id == CONTAINER_DATA_SELECTED_FRAME_ID)
                LightroomBlockEntity.this.setSelectedFrameIndex(value);
            method_5431();
        }

        public int method_17389() {
            return CONTAINER_DATA_SIZE;
        }
    };

    public static final Map<class_1767, Integer> DYE_SLOTS = Map.of(
            class_1767.field_7955, Lightroom.CYAN_SLOT,
            class_1767.field_7958, Lightroom.MAGENTA_SLOT,
            class_1767.field_7947, Lightroom.YELLOW_SLOT,
            class_1767.field_7963, Lightroom.BLACK_SLOT
    );

    protected class_2371<class_1799> items = class_2371.method_10213(Lightroom.SLOTS, class_1799.field_8037);
    protected UUID lastPlayerId = class_156.field_25140;
    protected int selectedFrameIndex;
    protected int progress;
    protected int printTime;
    protected int storedExperience;
    protected boolean advanceFrame;
    protected PrintingMode printingMode = PrintingMode.REGULAR;

    protected @Nullable Frame selectedFrame;

    public LightroomBlockEntity(class_2338 pos, class_2680 blockState) {
        super(Exposure.BlockEntityTypes.LIGHTROOM.get(), pos, blockState);
    }

    public static <T extends class_2586> void serverTick(class_1937 ignoredLevel, class_2338 ignoredBlockPos,
                                                          class_2680 ignoredBlockState, T blockEntity) {
        if (blockEntity instanceof LightroomBlockEntity lightroomBlockEntity) {
            lightroomBlockEntity.tick();
        }
    }

    protected void tick() {
        if (printTime <= 0 || !canPrint()) {
            stopPrintingProcess();
            return;
        }

        if (progress < printTime) {
            progress++;
            if (progress % 55 == 0 && printTime - progress > 12) {
                playPrintingSound();
            }
            return;
        }

        @Nullable Frame frame = getSelectedFrame();
        Preconditions.checkState(frame != null,
                "Frame cannot be null here because of 'canPrint' check. If it is - something went wrong.");

        PrintingProcess process = getPrintingProcess(frame);

        printFrame(frame, process, true);
        stopPrintingProcess();
    }

    public void setLastPlayer(class_1657 player) {
        lastPlayerId = player.method_5667();
    }

    public float getProgressPercentage() {
        if (progress < 1 || printTime < 1)
            return 0f;

        return progress / (float) printTime;
    }

    public boolean isPrinting() {
        return field_11863 != null && field_11863.method_8320(method_11016()).method_11654(LightroomBlock.PRINTING);
    }

    public boolean isAdvancingFrameOnPrint() {
        return advanceFrame;
    }

    protected boolean canEjectFilm() {
        if (field_11863 == null || field_11863.field_9236 || method_5438(Lightroom.FILM_SLOT).method_7960())
            return false;

        class_2338 pos = method_11016();
        class_2350 facing = field_11863.method_8320(pos).method_11654(LightroomBlock.FACING);

        return !field_11863.method_8320(pos.method_10093(facing)).method_26225();
    }

    protected void ejectFilm() {
        if (field_11863 == null || field_11863.field_9236 || method_5438(Lightroom.FILM_SLOT).method_7960())
            return;

        class_2338 pos = method_11016();
        class_2350 facing = field_11863.method_8320(pos).method_11654(LightroomBlock.FACING);
        class_1799 filmStack = method_5434(Lightroom.FILM_SLOT, 1);

        class_2382 normal = facing.method_10163();
        class_243 point = class_243.method_24953(pos).method_1031(normal.method_10263() * 0.75f, normal.method_10264() * 0.75f, normal.method_10260() * 0.75f);
        class_1542 itemEntity = new class_1542(field_11863, point.field_1352, point.field_1351, point.field_1350, filmStack);
        itemEntity.method_18800(normal.method_10263() * 0.05f, normal.method_10264() * 0.05f + 0.15f, normal.method_10260() * 0.05f);
        itemEntity.method_6988();
        field_11863.method_8649(itemEntity);

        inventoryContentsChanged(Lightroom.FILM_SLOT);
    }

    public int getSelectedFrameIndex() {
        return selectedFrameIndex;
    }

    public void setSelectedFrameIndex(int index) {
        if (selectedFrameIndex != index) {
            selectedFrameIndex = index;
            stopPrintingProcess();
        }

        class_1799 filmStack = method_5438(Lightroom.FILM_SLOT);
        if (filmStack.method_7909() instanceof DevelopedFilmItem developedFilm && developedFilm.hasFrameAt(filmStack, getSelectedFrameIndex())) {
            selectedFrame = developedFilm.getStoredFrames(filmStack).get(getSelectedFrameIndex());
        } else {
            selectedFrame = null;
        }
    }

    public PrintingMode getActualPrintingMode() {
        return isRefracted() ? printingMode : PrintingMode.REGULAR;
    }

    public PrintingMode getPrintingMode() {
        return printingMode;
    }

    public void setPrintMode(PrintingMode printingMode) {
        this.printingMode = printingMode;
        stopPrintingProcess();
        method_5431();
    }

    @Nullable
    public Frame getSelectedFrame() {
        return selectedFrame;
    }

    public boolean isRefracted() {
        return field_11863 != null && field_11863.method_8320(method_11016()).method_11654(LightroomBlock.REFRACTED);
    }

    public void startPrintingProcess(boolean advanceFrameOnFinish) {
        if (!canPrint())
            return;

        @Nullable Frame frame = getSelectedFrame();
        Preconditions.checkState(frame != null,
                "Frame cannot be null here because of 'canPrint' check. If it is - something went wrong.");

        PrintingProcess process = getPrintingProcess(frame);

        int time = process.getPrintTime();
        printTime = isRefracted() && process.isRegular() ? time * 3 : time;

        advanceFrame = advanceFrameOnFinish;

        if (field_11863 != null) {
            class_2680 state = field_11863.method_8320(method_11016());
            if (state.method_26204() instanceof LightroomBlock && !state.method_11654(LightroomBlock.PRINTING)) {
                field_11863.method_8652(method_11016(), state.method_11657(LightroomBlock.PRINTING, true), class_2248.field_31028);
                playPrintingStartedSound();
            }
        }
    }

    public void stopPrintingProcess() {
        progress = 0;
        printTime = 0;
        advanceFrame = false;
        if (field_11863 != null) {
            class_2680 state = field_11863.method_8320(method_11016());
            if (state.method_26204() instanceof LightroomBlock && state.method_11654(LightroomBlock.PRINTING)) {
                field_11863.method_8652(method_11016(), state
                        .method_11657(LightroomBlock.PRINTING, false), class_2248.field_31028);
            }
        }
    }

    public boolean canPrint() {
        @Nullable Frame frame = getSelectedFrame();
        if (frame == null) {
            return false;
        }

        class_1799 paperStack = method_5438(Lightroom.PAPER_SLOT);
        if (paperStack.method_7960()) {
            return false;
        }

        PrintingProcess process = getPrintingProcess(frame);

        return isPaperValidForPrint(frame, process)
                && canOutputToResultSlot(frame, process)
                && hasDyesForPrint(frame, process)
                && hasSufficientLightLevel();
    }
    
    public boolean hasSufficientLightLevel() {
        if (field_11863 == null) return false;
        int requiredLightLevel = Config.Server.LIGHTROOM_LIGHT_REQUIREMENT.get();
        class_2338 above = method_11016().method_10084();
        if (isRefracted()) {
            return LevelUtil.getLightLevelAt(field_11863, above.method_10084()) >= requiredLightLevel
                    || LevelUtil.getLightLevelAt(field_11863, above.method_10093(class_2350.field_11043)) >= requiredLightLevel
                    || LevelUtil.getLightLevelAt(field_11863, above.method_10093(class_2350.field_11034)) >= requiredLightLevel
                    || LevelUtil.getLightLevelAt(field_11863, above.method_10093(class_2350.field_11035)) >= requiredLightLevel
                    || LevelUtil.getLightLevelAt(field_11863, above.method_10093(class_2350.field_11039)) >= requiredLightLevel;
        }
        return LevelUtil.getLightLevelAt(field_11863, above) >= requiredLightLevel;
    }

    public boolean canPrintInCreativeMode() {
        @Nullable Frame frame = getSelectedFrame();
        if (frame == null) {
            return false;
        }

        PrintingProcess process = getPrintingProcess(frame);

        return canOutputToResultSlot(frame, process);
    }

    protected PrintingProcess getPrintingProcess(@NotNull Frame frame) {
        return switch (getActualPrintingMode()) {
            case REGULAR -> PrintingProcess.fromExposureType(frame.type());
            case CHROMATIC -> PrintingProcess.fromChromaticStep(getChromaticStep(method_5438(Lightroom.PAPER_SLOT)));
        };
    }

    protected boolean isPaperValidForPrint(Frame frame, PrintingProcess process) {
        class_1799 paperStack = method_5438(Lightroom.PAPER_SLOT);

        if (paperStack.method_7960()) {
            return false;
        }

        if (process.isChromatic()) {
            return paperStack.method_31573(Exposure.Tags.Items.PHOTO_PAPERS) ||
                    (paperStack.method_7909() instanceof ChromaticSheetItem chromaticSheet
                            && !chromaticSheet.canCombine(paperStack));
        }

        return paperStack.method_31573(Exposure.Tags.Items.PHOTO_PAPERS);
    }

    protected boolean hasDyesForPrint(Frame frame, PrintingProcess process) {
        for (class_1767 requiredDye : process.getRequiredDyes()) {
            int slotIndex = DYE_SLOTS.get(requiredDye);
            if (method_5438(slotIndex).method_7960()) {
                return false;
            }
        }

        return true;
    }

    public boolean canOutputToResultSlot(Frame frame, PrintingProcess process) {
        class_1799 resultStack = method_5438(Lightroom.RESULT_SLOT);

        if (process.isChromatic()) {
            return resultStack.method_7960();
        }

        return resultStack.method_7960() || resultStack.method_7909() instanceof PhotographItem
                || (resultStack.method_7909() instanceof StackedPhotographsItem stackedPhotographsItem
                && stackedPhotographsItem.canAddPhotograph(resultStack));
    }

    protected int getChromaticStep(class_1799 paper) {
        if (!(paper.method_7909() instanceof ChromaticSheetItem chromaticSheet))
            return 0;

        return chromaticSheet.getLayers(paper).size();
    }

    protected void printFrame(Frame frame, PrintingProcess process, boolean consumeIngredients) {
        class_1799 printResult = createPrintResult(frame, process);
        putPrintResultInOutputSlot(printResult);

        if (consumeIngredients) {
            consumePrintIngredients(frame, process);
            awardExperienceForPrint(frame, process, printResult);
        }

        onFramePrinted(frame, process, printResult);
    }

    public void printFrameInCreative() {
        @Nullable Frame frame = getSelectedFrame();
        if (frame == null) {
            Exposure.LOGGER.error("Cannot creatively print a frame: No frame is selected.");
            return;
        }

        PrintingProcess process = getPrintingProcess(frame);
        printFrame(frame, process, false);

        // Band-aid fix to not leave sheet in input slot.
        if (method_5438(Lightroom.PAPER_SLOT).method_7909() instanceof ChromaticSheetItem) {
            method_5438(Lightroom.PAPER_SLOT).method_7934(1);
            method_5431();
        }
    }

    protected class_1799 createPrintResult(Frame frame, PrintingProcess process) {
        if (process.isChromatic()) {
            class_1799 paperStack = method_5438(Lightroom.PAPER_SLOT);
            class_1799 chromaticStack = paperStack.method_7909() instanceof ChromaticSheetItem
                    ? paperStack.method_7972()
                    : new class_1799(Exposure.Items.CHROMATIC_SHEET.get());
            ChromaticSheetItem chromaticItem = ((ChromaticSheetItem) chromaticStack.method_7909());

            chromaticItem.addLayer(chromaticStack, frame);

            @Nullable class_3222 player = getLastOrClosestPlayer();
            if (chromaticItem.canCombine(chromaticStack)) {
                if (player != null) {
                    return chromaticItem.combineIntoPhotograph(player, chromaticStack, true);
                } else {
                    // This will be used when creating exposure to set 'wasPrinted' in exposure tag.
                  //  CompoundTag tag = new CompoundTag();
                   // tag.putBoolean("printed", true);
                    chromaticStack.method_7948().method_10556("printed",true);
                }
            }

            return chromaticStack;
        } else {
            class_1799 photographStack = new class_1799(Exposure.Items.PHOTOGRAPH.get());
            Exposure.DataComponents.setPhotographFrame(photographStack,frame);
            Exposure.DataComponents.setPhotographType(photographStack,frame.type());
            return photographStack;
        }
    }

    protected @Nullable class_3222 getLastOrClosestPlayer() {
        if (!(method_10997() instanceof class_3218 serverLevel)) {
            return null;
        }

        if (serverLevel.method_18470(lastPlayerId) instanceof class_3222 lastPlayer) {
            return lastPlayer;
        }

        class_2338 pos = method_11016();
        return serverLevel.method_18456().stream()
                .min(Comparator.comparingDouble(pl -> pl.method_5649(pos.method_10263(), pos.method_10264(), pos.method_10260())))
                .orElse(null);
    }

    protected void putPrintResultInOutputSlot(class_1799 printResult) {
        class_1799 resultStack = method_5438(Lightroom.RESULT_SLOT);
        if (resultStack.method_7960()) {
            resultStack = printResult;
        } else if (resultStack.method_7909() instanceof PhotographItem) {
            StackedPhotographsItem stackedPhotographsItem = Exposure.Items.STACKED_PHOTOGRAPHS.get();
            class_1799 newStackedPhotographs = new class_1799(stackedPhotographsItem);
            stackedPhotographsItem.addPhotographOnTop(newStackedPhotographs, resultStack);
            stackedPhotographsItem.addPhotographOnTop(newStackedPhotographs, printResult);
            resultStack = newStackedPhotographs;
        } else if (resultStack.method_7909() instanceof StackedPhotographsItem stackedPhotographsItem) {
            stackedPhotographsItem.addPhotographOnTop(resultStack, printResult);
        } else {
            Exposure.LOGGER.error("Unexpected item in result slot: {}", resultStack);
            return;
        }
        method_5447(Lightroom.RESULT_SLOT, resultStack);
    }

    protected void consumePrintIngredients(Frame frame, PrintingProcess process) {
        method_5438(Lightroom.PAPER_SLOT).method_7934(1);
        process.getRequiredDyes().forEach(dye -> method_5438(DYE_SLOTS.get(dye)).method_7934(1));
        method_5431();
    }

    protected void awardExperienceForPrint(Frame frame, PrintingProcess process, class_1799 result) {
        int xp = process.getExperiencePerPrint();

        if (xp > 0) {
            float variability = ThreadLocalRandom.current().nextFloat() * 0.3f + 1f;
            int variableXp = (int) Math.max(1, Math.ceil(xp * variability));
            storedExperience += variableXp;
        }
    }

    protected void onFramePrinted(Frame frame, PrintingProcess process, class_1799 result) {
        if (process.isRegular()) { // Chromatics create new exposure. Marking is not needed.
            frame.identifier().ifId(id ->
                    ExposureServer.exposureRepository().update(id, exposure ->
                            exposure.withTag(ExposureData.Tag::setPrinted)));
        }

        class_3222 player = getLastOrClosestPlayer();
        if (player != null) {
            Exposure.ExposureCriteriaTriggers.FRAME_PRINTED.trigger(player, method_11016(), frame, result);
        }

        if (advanceFrame) {
            advanceFrame();
        }

        playPrintingFinishedSound();
    }

    protected void advanceFrame() {
        ItemAndStack<DevelopedFilmItem> film = new ItemAndStack<>(method_5438(Lightroom.FILM_SLOT));
        int frames = film.getItem().getStoredFramesCount(film.getItemStack());

        if (getSelectedFrameIndex() >= frames - 1) { // On last frame
            if (canEjectFilm())
                ejectFilm();
        } else {
            setSelectedFrameIndex(getSelectedFrameIndex() + 1);
            method_5431();
        }
    }

    public void dropStoredExperience(@Nullable class_1657 player) {
        if (field_11863 instanceof class_3218 serverLevel && storedExperience > 0) {
            class_1303.method_31493(serverLevel, class_243.method_24953(method_11016()), storedExperience);
            storedExperience = 0;
            method_5431();
        }
    }

    protected void playPrintingStartedSound() {
        if (field_11863 != null) {
            field_11863.method_8396(null, method_11016(), Exposure.SoundEvents.LIGHTROOM_PRINT.get(), class_3419.field_15245,
                    1f, field_11863.method_8409().method_43057() * 0.3f + 1f);
        }
    }

    protected void playPrintingSound() {
        if (field_11863 != null) {
            field_11863.method_8396(null, method_11016(), Exposure.SoundEvents.LIGHTROOM_PRINT.get(), class_3419.field_15245,
                    1f, field_11863.method_8409().method_43057() * 0.3f + 1f);
        }
    }

    protected void playPrintingFinishedSound() {
        if (field_11863 != null) {
            field_11863.method_8396(null, method_11016(), Exposure.SoundEvents.PHOTOGRAPH_RUSTLE.get(),
                    class_3419.field_15248, 0.8f, 1f);
        }
    }


    // Container

    @Override
    protected @NotNull class_2561 method_17823() {
        return class_2561.method_43471("container.exposure.lightroom");
    }

    @Override
    protected @NotNull class_1703 method_5465(int containerId, class_1661 inventory) {
        return new LightroomMenu(containerId, inventory, this, containerData);
    }

    public boolean isItemValidForSlot(int slot, class_1799 stack) {
        if (slot == Lightroom.FILM_SLOT) return stack.method_7909() instanceof DevelopedFilmItem;
        else if (slot == Lightroom.CYAN_SLOT) return stack.method_31573(Exposure.Tags.Items.CYAN_PRINTING_DYES);
        else if (slot == Lightroom.MAGENTA_SLOT) return stack.method_31573(Exposure.Tags.Items.MAGENTA_PRINTING_DYES);
        else if (slot == Lightroom.YELLOW_SLOT) return stack.method_31573(Exposure.Tags.Items.YELLOW_PRINTING_DYES);
        else if (slot == Lightroom.BLACK_SLOT) return stack.method_31573(Exposure.Tags.Items.BLACK_PRINTING_DYES);
        else if (slot == Lightroom.PAPER_SLOT)
            return stack.method_31573(Exposure.Tags.Items.PHOTO_PAPERS) ||
                    (stack.method_7909() instanceof ChromaticSheetItem chromatic && chromatic.getLayers(stack).size() < 3);
        else if (slot == Lightroom.RESULT_SLOT)
            return stack.method_7909() instanceof PhotographItem
                    || stack.method_7909() instanceof StackedPhotographsItem
                    || stack.method_7909() instanceof ChromaticSheetItem;
        return false;
    }

    protected void inventoryContentsChanged(int slot) {
        if (slot == Lightroom.FILM_SLOT)
            setSelectedFrameIndex(0);

        method_5431();
    }

    @Override
    public boolean method_5443(@NotNull class_1657 player) {
        return this.field_11863 != null && this.field_11863.method_8321(this.field_11867) == this
                && player.method_5649(this.field_11867.method_10263() + 0.5D,
                this.field_11867.method_10264() + 0.5D,
                this.field_11867.method_10260() + 0.5D) <= 64.0D;
    }

    @Override
    public int @NotNull [] method_5494(@NotNull class_2350 face) {
        return Lightroom.ALL_SLOTS;
    }

    @Override
    public boolean method_5492(int index, @NotNull class_1799 itemStack, @Nullable class_2350 direction) {
        if (direction == class_2350.field_11033)
            return false;
        return method_5437(index, itemStack);
    }

    @Override
    public boolean method_5437(int index, class_1799 stack) {
        return index != Lightroom.RESULT_SLOT && isItemValidForSlot(index, stack) && super.method_5437(index, stack);
    }

    @Override
    public boolean method_5493(int index, @NotNull class_1799 pStack, @NotNull class_2350 direction) {
        for (int outputSlot : Lightroom.OUTPUT_SLOTS) {
            if (index == outputSlot)
                return true;
        }
        return false;
    }


    // Load/Save

    @Override
    public void method_11014(class_2487 tag) {
        this.items = class_2371.method_10213(this.method_5439(), class_1799.field_8037);
        class_1262.method_5429(tag, this.items);

        // Backwards compatibility:
        if (tag.method_10573("Inventory", class_2520.field_33260)) {
            class_2487 inventory = tag.method_10562("Inventory");
            class_2499 itemsList = inventory.method_10554("Items", class_2520.field_33260);

            for (int i = 0; i < itemsList.size(); i++) {
                class_2487 itemTag = itemsList.method_10602(i);
                int slot = itemTag.method_10550("Slot");

                if (slot >= 0 && slot < items.size()) {
                    items.set(slot,class_1799.method_7915(itemTag));
                }
            }
        }

        this.setSelectedFrameIndex(tag.method_10550("SelectedFrame"));
        this.progress = tag.method_10550("Progress");
        this.printTime = tag.method_10550("PrintTime");
        this.storedExperience = tag.method_10550("PrintedPhotographsCount");
        this.advanceFrame = tag.method_10577("AdvanceFrame");
        this.printingMode = PrintingMode.fromStringOrDefault(tag.method_10558("PrintMode"), PrintingMode.REGULAR);
        if (tag.method_10573("LastPlayerId", class_2520.field_33261)) {
            this.lastPlayerId = tag.method_25926("LastPlayerId");
        }
    }

    @Override
    protected void method_11007(class_2487 tag) {
        super.method_11007(tag);
        class_1262.method_5426(tag, items);
        if (getSelectedFrameIndex() > 0)
            tag.method_10569("SelectedFrame", getSelectedFrameIndex());
        if (progress > 0)
            tag.method_10569("Progress", progress);
        if (printTime > 0)
            tag.method_10569("PrintTime", printTime);
        if (storedExperience > 0)
            tag.method_10569("PrintedPhotographsCount", storedExperience);
        if (advanceFrame)
            tag.method_10556("AdvanceFrame", true);
        if (printingMode != PrintingMode.REGULAR)
            tag.method_10582("PrintMode", printingMode.method_15434());
        if (!lastPlayerId.equals(class_156.field_25140))
            tag.method_25927("LastPlayerId", lastPlayerId);
    }

    protected @NotNull class_2371<class_1799> getItems() {
        return this.items;
    }

    //@Override
    protected void setItems(class_2371<class_1799> items) {
        this.items = items;
    }

    @Override
    public int method_5439() {
        return Lightroom.SLOTS;
    }

    @Override
    public boolean method_5442() {
        return getItems().stream().allMatch(class_1799::method_7960);
    }

    @Override
    public @NotNull class_1799 method_5438(int slot) {
        return getItems().get(slot);
    }

    @Override
    public @NotNull class_1799 method_5434(int slot, int amount) {
        class_1799 itemStack = class_1262.method_5430(getItems(), slot, amount);
        if (!itemStack.method_7960())
            inventoryContentsChanged(slot);
        return itemStack;
    }

    @Override
    public @NotNull class_1799 method_5441(int slot) {
        return class_1262.method_5428(getItems(), slot);
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        this.getItems().set(slot, stack);
        if (stack.method_7947() > this.method_5444()) {
            stack.method_7939(this.method_5444());
        }
        inventoryContentsChanged(slot);
    }

    @Override
    public void method_5448() {
        getItems().clear();
        inventoryContentsChanged(-1);
    }

    @Override
    public void method_5431() {
        super.method_5431();
        if (field_11863 != null && !field_11863.field_9236) {
            field_11863.method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31028);
        }
    }


    // Sync:

    @Override
    @Nullable
    public class_2622 method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public @NotNull class_2487 method_16887() {
        return method_38244();
    }
}
