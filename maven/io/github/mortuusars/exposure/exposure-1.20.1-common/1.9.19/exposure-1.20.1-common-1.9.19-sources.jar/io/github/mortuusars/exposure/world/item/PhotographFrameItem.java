package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.world.entity.PhotographFrameEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_5712;
import org.jetbrains.annotations.NotNull;

public class PhotographFrameItem extends class_1792 {
    public PhotographFrameItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_2338 clickedPos = context.method_8037();
        class_2350 direction = context.method_8038();
        class_2338 resultPos = clickedPos.method_10093(direction);
        class_1657 player = context.method_8036();
        class_1799 itemInHand = context.method_8041();
        if (player == null || player.method_37908().method_31606(resultPos) || !player.method_7343(resultPos, direction, itemInHand))
            return class_1269.field_5814;

        class_1937 level = context.method_8045();
        PhotographFrameEntity frameEntity = createEntity(level, resultPos, direction);

        class_2487 customData = itemInHand.method_7969();
        if (customData != null && !customData.method_33133()) {
            class_1299.method_5881(level, player, frameEntity, customData);
        }

        for (int i = 2; i >= 0; i--) {
            frameEntity.setSize(i);
            if (frameEntity.method_6888()) {
                if (!level.field_9236) {
                    frameEntity.method_6894();
                    level.method_43275(player, class_5712.field_28738, frameEntity.method_19538());
                    level.method_8649(frameEntity);
                }

                frameEntity.setFrameItem((player.method_7337() ? itemInHand.method_7972() : itemInHand).method_7971(1));

                return class_1269.method_29236(level.field_9236);
            }
        }

        return class_1269.field_5814;
    }

    public @NotNull PhotographFrameEntity createEntity(class_1937 level, class_2338 pos, class_2350 direction) {
        return new PhotographFrameEntity(level, pos, direction);
    }
}
