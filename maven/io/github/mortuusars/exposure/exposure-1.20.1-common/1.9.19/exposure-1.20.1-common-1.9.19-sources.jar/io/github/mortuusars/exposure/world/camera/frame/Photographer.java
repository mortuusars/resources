package io.github.mortuusars.exposure.world.camera.frame;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_4844;

public final class Photographer {
    public static final Photographer EMPTY = new Photographer("", class_156.field_25140);

    public static final Codec<Photographer> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                    Codec.STRING.optionalFieldOf("name", "").forGetter(Photographer::name),
                    class_4844.field_25122.optionalFieldOf("uuid", class_156.field_25140).forGetter(Photographer::uuid))
            .apply(instance, Photographer::new));

    public void toPacket(class_2540 buf) {
        buf.method_10814(name);
        buf.method_10797(uuid);
    }

    public static Photographer fromPacket(class_2540 buf) {
        return new Photographer(buf.method_19772(),buf.method_10790());
    }

    private final String name;
    private final UUID uuid;

    private Photographer(String name, UUID uuid) {
        this.name = name;
        this.uuid = uuid;
    }

    public Photographer(CameraHolder cameraHolder) {
        class_1297 owner = cameraHolder.getExposureAuthorEntity();
        this.name = owner instanceof class_1657 ? owner.method_5820() : class_1299.method_5890(owner.method_5864()).toString();
        // UUID of non-player entities are not recorded because they are usually short-lived.
        this.uuid = owner instanceof class_1657 ? owner.method_5667() : class_156.field_25140;
    }

    public boolean matches(class_1297 entity) {
        return uuid.equals(entity.method_5667());
    }

    public boolean isPlayer() {
        return !name.isBlank() && !uuid.equals(class_156.field_25140);
    }

    public boolean isNPC() {
        return !name.isBlank() && uuid.equals(class_156.field_25140);
    }

    public boolean isEmpty() {
        return this.equals(EMPTY);
    }

    public String name() {
        return name;
    }

    public UUID uuid() {
        return uuid;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (Photographer) obj;
        return Objects.equals(this.name, that.name) &&
                Objects.equals(this.uuid, that.uuid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, uuid);
    }

    @Override
    public String toString() {
        return "Photographer[" +
                "name=" + name + ", " +
                "uuid=" + uuid + ']';
    }

}
