package io.github.mortuusars.exposure;

import net.minecraft.class_2960;

public record ModWidgetSprites(class_2960 enabled,
                               class_2960 disabled,
                               class_2960 enabledFocused,
                               class_2960 disabledFocused,
                               int width,
                               int height) {
    ModWidgetSprites(class_2960 enabled, class_2960 disabled, int width, int height) {
        this(enabled, enabled, disabled, disabled, width, height);
    }

    ModWidgetSprites(class_2960 enabled, class_2960 disabled, class_2960 enabledFocused,
                     int width, int height) {
        this(enabled, disabled, enabledFocused, disabled, width, height);
    }

    public static ModWidgetSprites withPrefix(class_2960 enabled, class_2960 disabled, class_2960 enabledFocused,
                                              int width, int height) {
        return new ModWidgetSprites(enabled.method_45138("textures/gui/sprites/").method_48331(".png"),
              disabled.method_45138("textures/gui/sprites/").method_48331(".png"),
              enabledFocused.method_45138("textures/gui/sprites/").method_48331(".png"), width, height);
    }

    public static ModWidgetSprites withPrefix(class_2960 enabled, class_2960 disabled, int width, int height) {
        return new ModWidgetSprites(enabled.method_45138("textures/gui/sprites/").method_48331(".png"),
              disabled.method_45138("textures/gui/sprites/").method_48331(".png"), width, height);
    }

    public class_2960 get(boolean enabled, boolean focused) {
        if (enabled) {
            return focused ? this.enabledFocused : this.enabled;
        } else {
            return focused ? this.disabledFocused : this.disabled;
        }
    }
}
