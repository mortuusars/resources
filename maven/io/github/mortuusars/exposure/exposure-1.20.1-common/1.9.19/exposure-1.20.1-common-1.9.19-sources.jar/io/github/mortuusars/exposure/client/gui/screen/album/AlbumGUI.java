package io.github.mortuusars.exposure.client.gui.screen.album;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ModWidgetSprites;
import net.minecraft.class_2960;

public class AlbumGUI {
    public static final ModWidgetSprites PREVIOUS_PAGE_BUTTON_SPRITES = ModWidgetSprites.withPrefix(
            Exposure.resource("album/previous_page"), Exposure.resource("album/previous_page_highlighted"),13,15);
    public static final ModWidgetSprites NEXT_PAGE_BUTTON_SPRITES = ModWidgetSprites.withPrefix(
            Exposure.resource("album/next_page"), Exposure.resource("album/next_page_highlighted"),13,15);

    public static final class_2960 TEXTURE = Exposure.resource("textures/gui/album.png");
}
