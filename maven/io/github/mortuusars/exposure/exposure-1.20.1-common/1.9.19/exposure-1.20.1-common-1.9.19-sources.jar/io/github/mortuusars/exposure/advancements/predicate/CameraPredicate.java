package io.github.mortuusars.exposure.advancements.predicate;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.Stuff;
import io.github.mortuusars.exposure.world.item.camera.Attachment;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2073;
import net.minecraft.class_2090;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3518;

public record CameraPredicate(class_2073 camera,
                              class_2073 film,
                              class_2073 flash,
                              class_2073 lens,
                              class_2073 filter,
                              class_2090 location) {


    public static final Codec<CameraPredicate> CODEC = RecordCodecBuilder.create(cameraPredicateInstance ->
            cameraPredicateInstance.group(
                    Stuff.ITEM_PREDICATE_CODEC.optionalFieldOf("camera",class_2073.field_9640).forGetter(CameraPredicate::camera),
                    Stuff.ITEM_PREDICATE_CODEC.optionalFieldOf("film",class_2073.field_9640).forGetter(CameraPredicate::film),
                    Stuff.ITEM_PREDICATE_CODEC.optionalFieldOf("flash",class_2073.field_9640).forGetter(CameraPredicate::flash),
                    Stuff.ITEM_PREDICATE_CODEC.optionalFieldOf("lens",class_2073.field_9640).forGetter(CameraPredicate::lens),
                    Stuff.ITEM_PREDICATE_CODEC.optionalFieldOf("filter",class_2073.field_9640).forGetter(CameraPredicate::filter),
                    Stuff.LOCATION_PREDICATE_CODEC.optionalFieldOf("location",class_2090.field_9685).forGetter(CameraPredicate::location)
            ).apply(cameraPredicateInstance,CameraPredicate::new));

    public static final CameraPredicate ANY = new CameraPredicate(class_2073.field_9640, class_2073.field_9640, class_2073.field_9640, class_2073.field_9640,
            class_2073.field_9640,class_2090.field_9685);


    public static CameraPredicate fromJson(@Nullable JsonElement json) {
        if (json == null || json.isJsonNull())
            return ANY;

        JsonObject jsonObj = class_3518.method_15295(json, "camera");

        return new CameraPredicate(
                class_2073.method_8969(jsonObj.getAsJsonObject("camera")),
                class_2073.method_8969(jsonObj.getAsJsonObject("film")),
                class_2073.method_8969(jsonObj.getAsJsonObject("flash")),
                class_2073.method_8969(jsonObj.getAsJsonObject("lens")),
                class_2073.method_8969(jsonObj.getAsJsonObject("filter")),
                class_2090.method_9021(jsonObj.getAsJsonObject("location"))
        );
    }

    public JsonElement serializeToJson() {
        if (this == ANY) {
            return JsonNull.INSTANCE;
        } else {
            return CODEC.encodeStart(JsonOps.INSTANCE,this).resultOrPartial(Exposure.LOGGER::error).orElseThrow();
        }
    }

    public boolean matches(class_3218 level, class_1799 cameraStack, class_243 cameraLocation) {
        if (!(cameraStack.method_7909() instanceof CameraItem)) return false;

        return (camera.method_8970(cameraStack))
                && (film.method_8970(Attachment.FILM.get(cameraStack).getForReading()))
                && (flash.method_8970(Attachment.FLASH.get(cameraStack).getForReading()))
                && (lens.method_8970(Attachment.LENS.get(cameraStack).getForReading()))
                && (filter.method_8970(Attachment.FILTER.get(cameraStack).getForReading()))
                && (location.method_9018(level, cameraLocation.field_1352, cameraLocation.field_1351, cameraLocation.field_1350));
    }
}
