package io.github.mortuusars.exposure.world.camera.component;

import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_2561;
import net.minecraft.class_3542;
import net.minecraft.class_5250;
import org.jetbrains.annotations.NotNull;

public enum FlashMode implements class_3542 {
    OFF("off"),
    ON("on"),
    AUTO("auto");

    public static final Codec<FlashMode> CODEC = class_3542.method_28140(FlashMode::values);

    private final String name;

    FlashMode(String name) {
        this.name = name;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }

    public class_5250 translate() {
        return class_2561.method_43471("gui." + Exposure.ID + ".flash_mode." + name);
    }
}
