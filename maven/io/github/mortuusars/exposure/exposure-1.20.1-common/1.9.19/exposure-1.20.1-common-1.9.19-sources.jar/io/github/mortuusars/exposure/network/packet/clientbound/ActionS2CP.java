package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public enum ActionS2CP implements Packet {
    CLEAR_RENDERING_CACHE,SHUTTER_OPENED,EXPORT_STOPPED;

    public static final class_2960 ID = Exposure.resource("clear_rendering_cache");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_10817(this);
    }

    public static ActionS2CP fromPacket(class_2540 buf) {
        return buf.method_10818(ActionS2CP.class);
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        switch (this){
            case CLEAR_RENDERING_CACHE -> ClientPacketsHandler.clearRenderingCache();
            case SHUTTER_OPENED -> ClientPacketsHandler.shutterOpened();
            case EXPORT_STOPPED -> ClientPacketsHandler.stopExportTask();
        }
        return true;
    }
}