package io.github.mortuusars.exposure.world.item.component.album;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2561;

public record AlbumPage(class_1799 photograph, String note) {
    public static final Codec<AlbumPage> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_1799.field_24671.optionalFieldOf("photograph", class_1799.field_8037).forGetter(AlbumPage::photograph),
            Codec.STRING.optionalFieldOf("note", "").forGetter(AlbumPage::note)
    ).apply(instance, AlbumPage::new));

    public void toPacket(class_2540 buf) {
        buf.method_10793(photograph);
        buf.method_10814(note);
    }

    public static AlbumPage fromPacket(class_2540 buf) {
        return new AlbumPage(buf.method_10819(),buf.method_19772());
    }

    public static final AlbumPage EMPTY = new AlbumPage(class_1799.field_8037, "");

    public boolean isEmpty() {
        return photograph().method_7960() && note().isEmpty();
    }

    public AlbumPage setPhotograph(class_1799 stack) {
        return new AlbumPage(stack, note);
    }

    public AlbumPage setNote(String note) {
        return new AlbumPage(photograph, note);
    }

    public SignedAlbumPage convertToSigned() {
        return new SignedAlbumPage(photograph, class_2561.method_43470(note));
    }
}
