package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import io.github.mortuusars.exposure.client.sound.UniqueSoundManager;
import org.jetbrains.annotations.Nullable;

public record UniqueSoundPlayS2CP(String id, int entityId, class_3414 sound, class_3419 source,
                                  float volume, float pitch) implements Packet {
    public static final class_2960 ID = Exposure.resource("unique_sound_play");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_10814(id);
        buf.writeInt(entityId);
        sound.method_47958(buf);
        buf.method_10817(source);
        buf.writeFloat(volume);
        buf.writeFloat(pitch);
    }

    public static UniqueSoundPlayS2CP fromPacket(class_2540 buf) {
        return new UniqueSoundPlayS2CP(
              buf.method_19772(),
              buf.readInt(),
              class_3414.method_47961(buf),
              buf.method_10818(class_3419.class),
              buf.readFloat(),
              buf.readFloat());
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        @Nullable class_1297 entity = player.method_37908().method_8469(entityId);
        if (entity != null) {
            UniqueSoundManager.play(id, entity, sound, source, volume, pitch);
        }
        return true;
    }
}
