package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.world.camera.CameraInHand;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.entity.CameraOperator;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record ActiveCameraInHandSetS2CP(int operatorEntityId, CameraId cameraId, class_1268 hand) implements Packet {
    public static final class_2960 ID = Exposure.resource("active_camera_in_hand_set");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.writeInt(operatorEntityId);
        cameraId.toPacket(buf);
        buf.method_10817(hand);
    }

    public static ActiveCameraInHandSetS2CP fromPacket(class_2540 buf) {
        return new ActiveCameraInHandSetS2CP(buf.readInt(), CameraId.fromPacket(buf), buf.method_10818(class_1268.class));
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (player.method_37908().method_8469(operatorEntityId) instanceof class_1309 entity
                && entity instanceof CameraOperator operator
                && entity instanceof CameraHolder holder) {
            operator.setActiveExposureCamera(new CameraInHand(holder, cameraId, hand));
        }
        return true;
    }
}
