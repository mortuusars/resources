package io.github.mortuusars.exposure.world.item.crafting.recipe;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_7710;
import net.minecraft.class_8566;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;

public class FilmDevelopingRecipe extends ComponentTransferringRecipe {
    public FilmDevelopingRecipe(class_2960 id, class_1856 filmIngredient, class_2371<class_1856> ingredients, class_1799 result) {
        super(id,class_7710.field_40251, filmIngredient, ingredients, result);
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return Exposure.RecipeSerializers.FILM_DEVELOPING.get();
    }

    @Override
    public @NotNull class_2371<class_1799> getRemainingItems(class_8566 input) {
        class_2371<class_1799> remainingItems = super.method_8111(input);

        for (int i = 0; i < input.method_5439(); ++i) {
            class_1799 item = input.method_5438(i);
            if (item.method_7909() instanceof class_1812 && remainingItems.get(i).method_7960()) {
                remainingItems.set(i, new class_1799(class_1802.field_8469));
            }
        }

        return remainingItems;
    }


}
