package io.github.mortuusars.exposure.client.image.renderable;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_156;
import net.minecraft.class_2960;

public record RenderableImageIdentifier(String base, String variant) {
    public RenderableImageIdentifier(String base) {
        this(base, "");
    }

    public RenderableImageIdentifier appendVariant(String appendedVariant) {
        if (appendedVariant.isBlank()) return this;
        if (variant.isBlank()) return new RenderableImageIdentifier(base, appendedVariant);
        else return new RenderableImageIdentifier(base, variant + "_" + appendedVariant);
    }

    public class_2960 toResourceLocation() {
        String path = variant.isBlank() ? base : base + "/" + variant;
        String validPath = class_156.method_30309(path, class_2960::method_29184);
        return Exposure.resource(validPath);
    }
}
