package io.github.mortuusars.exposure.world.item.crafting.recipe;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class ComponentTransferringRecipe extends class_1852 {
    private final class_1856 sourceIngredient;
    private final class_2371<class_1856> ingredients;
    private final class_1799 result;

    public ComponentTransferringRecipe(class_2960 id,class_7710 category, class_1856 sourceIngredient, class_2371<class_1856> ingredients, class_1799 result) {
        super(id,category);
        this.sourceIngredient = sourceIngredient;
        this.ingredients = ingredients;
        this.result = result;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return Exposure.RecipeSerializers.COMPONENT_TRANSFERRING.get();
    }

    public @NotNull class_1856 getSourceIngredient() {
        return sourceIngredient;
    }

    @Override
    public @NotNull class_2371<class_1856> method_8117() {
        return ingredients;
    }

    @Override
    public @NotNull class_1799 method_8110(class_5455 registries) {
        return getResult();
    }

    public @NotNull class_1799 getResult() {
        return result;
    }

    @Override
    public boolean matches(class_8566 input, class_1937 level) {
        if (getSourceIngredient().method_8103() || ingredients.isEmpty())
            return false;

        List<class_1856> unmatchedIngredients = new ArrayList<>(ingredients);
        unmatchedIngredients.add(0, getSourceIngredient());

        int itemsInCraftingGrid = 0;

        for (int i = 0; i < input.method_5439(); i++) {
            class_1799 stack = input.method_5438(i);
            if (!stack.method_7960())
                itemsInCraftingGrid++;

            if (itemsInCraftingGrid > ingredients.size() + 1)
                return false;

            if (!unmatchedIngredients.isEmpty()) {
                for (int j = 0; j < unmatchedIngredients.size(); j++) {
                    if (unmatchedIngredients.get(j).method_8093(stack)) {
                        unmatchedIngredients.remove(j);
                        break;
                    }
                }
            }
        }

        return unmatchedIngredients.isEmpty() && itemsInCraftingGrid == ingredients.size() + 1;
    }

    @Override
    public @NotNull class_1799 assemble(class_8566 input, class_5455 registries) {
        for (int index = 0; index < input.method_5439(); index++) {
            class_1799 itemStack = input.method_5438(index);

            if (getSourceIngredient().method_8093(itemStack)) {
                return transferNbt(itemStack, method_8110(registries).method_7972());
            }
        }

        return method_8110(registries);
    }

    public @NotNull class_1799 transferNbt(class_1799 transferIngredientStack, class_1799 recipeResultStack) {
        @Nullable class_2487 transferTag = transferIngredientStack.method_7969();
        if (transferTag != null) {
            if (recipeResultStack.method_7969() != null)
                recipeResultStack.method_7969().method_10543(transferTag);
            else
                recipeResultStack.method_7980(transferTag.method_10553());
        }
        return recipeResultStack;
    }

    @Override
    public boolean method_8113(int width, int height) {
        return ingredients.size() <= width * height;
    }
}
