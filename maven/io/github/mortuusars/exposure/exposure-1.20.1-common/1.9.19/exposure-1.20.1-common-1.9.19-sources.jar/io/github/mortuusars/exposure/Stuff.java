package io.github.mortuusars.exposure;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_1792;
import net.minecraft.class_1842;
import net.minecraft.class_1887;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2035;
import net.minecraft.class_2073;
import net.minecraft.class_2090;
import net.minecraft.class_2096;
import net.minecraft.class_2105;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3195;
import net.minecraft.class_3611;
import net.minecraft.class_4550;
import net.minecraft.class_4551;
import net.minecraft.class_4552;
import net.minecraft.class_4559;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Stuff {

    public static final Codec<class_2096.class_2100> INTS_CODEC = RecordCodecBuilder.create(
            intsInstance -> intsInstance.group(Codec.INT.optionalFieldOf("min")
                            .forGetter(object -> Optional.ofNullable(object.method_9038())),
                    Codec.INT.optionalFieldOf("max")
                            .forGetter(ints -> Optional.ofNullable(ints.method_9042()))
            ).apply(intsInstance, (integer, integer2) -> new class_2096.class_2100(integer.orElse(null),integer2.orElse(null))));

    public static final Codec<class_2096.class_2099> DOUBLES_CODEC = RecordCodecBuilder.create(
            intsInstance -> intsInstance.group(Codec.DOUBLE.fieldOf("min")
                            .forGetter(class_2096::method_9038),
                    Codec.DOUBLE.fieldOf("max")
                            .forGetter(class_2096::method_9042)
            ).apply(intsInstance, class_2096.class_2099::method_35285));

    public static final Codec<class_2035> ENCHANTMENT_PREDICATE_CODEC = RecordCodecBuilder.create(enchantmentPredicateInstance ->
            enchantmentPredicateInstance.group(
                    class_7923.field_41176.method_39673().optionalFieldOf("enchantment").forGetter(object -> Optional.ofNullable(object.field_9569)),
                    INTS_CODEC.fieldOf("levels").forGetter(object -> object.field_9570)
            ).apply(enchantmentPredicateInstance, Stuff::fromCodec));

    public static final Codec<class_2105> NBT_PREDICATE_CODEC = RecordCodecBuilder.create(nbtPredicateInstance -> nbtPredicateInstance.group(
            class_2487.field_25128.optionalFieldOf("nbt").forGetter(object -> Optional.ofNullable(object.field_9715))
    ).apply(nbtPredicateInstance, compoundTag -> new class_2105(compoundTag.orElse(null))));

    public static final Codec<class_4552> LIGHT_PREDICATE_CODEC = RecordCodecBuilder.create(
    p_337376_ -> p_337376_.group(INTS_CODEC.optionalFieldOf("light", class_2096.class_2100.field_9708).forGetter(lightPredicate -> lightPredicate.field_20713))
            .apply(p_337376_, class_4552::new)
    );


    public static final Codec<class_2073> ITEM_PREDICATE_CODEC = RecordCodecBuilder
            .create(itemPredicateInstance ->
                    itemPredicateInstance.group(
                                    class_6862.method_40090(class_7924.field_41197).optionalFieldOf("tag").forGetter(i -> Optional.ofNullable(i.field_9643)),
                                    class_7923.field_41178.method_39673().listOf().xmap(Set::copyOf, List::copyOf)
                                            .optionalFieldOf("items").forGetter(i -> Optional.ofNullable(i.field_9644)),
                                    INTS_CODEC.optionalFieldOf("count", class_2096.class_2100.field_9708).forGetter(i -> i.field_9641),
                                    INTS_CODEC.optionalFieldOf("durability", class_2096.class_2100.field_9708).forGetter(i -> i.field_9646),
                                    ENCHANTMENT_PREDICATE_CODEC.listOf().optionalFieldOf("enchantments",new ArrayList<>()).forGetter(i -> Arrays.asList(i.field_9647)),
                                    ENCHANTMENT_PREDICATE_CODEC.listOf().optionalFieldOf("stored_enchantments",new ArrayList<>()).forGetter(i -> Arrays.asList(i.field_20689)),
                                    class_7923.field_41179.method_39673().optionalFieldOf("potion").forGetter(i -> Optional.ofNullable(i.field_9642)),
                                    NBT_PREDICATE_CODEC.optionalFieldOf("nbt",class_2105.field_9716).forGetter(i -> i.field_9645)
                            ).apply(itemPredicateInstance, Stuff::fromItemCodec));

    public static final Codec<class_4559.class_4561> EXACT_VALUE_CODEC = RecordCodecBuilder.create(
            exactPropertyMatcherInstance -> exactPropertyMatcherInstance.group(
                    Codec.STRING.fieldOf("name").forGetter(class_4559.class_4562::method_22533),
                    Codec.STRING.fieldOf("value").forGetter(p -> p.field_20739)
            ).apply(exactPropertyMatcherInstance, class_4559.class_4561::new)
    );

    public static final Codec<class_4559.class_4563> RANGED_VALUE_CODEC = RecordCodecBuilder.create(
            exactPropertyMatcherInstance -> exactPropertyMatcherInstance.group(
                    Codec.STRING.fieldOf("name").forGetter(class_4559.class_4562::method_22533),
                    Codec.STRING.fieldOf("value").forGetter(p -> p.field_20741),
                    Codec.STRING.fieldOf("value").forGetter(p -> p.field_20742)
            ).apply(exactPropertyMatcherInstance, class_4559.class_4563::new)
    );

    public static <U> U unwrap(final Either<? extends U, ? extends U> either) {
        return either.map(Function.identity(), Function.identity());
    }

    static final Codec<class_4559.class_4562> VALUE_CODEC = Codec.either(
                    EXACT_VALUE_CODEC, RANGED_VALUE_CODEC
            )
            .xmap(Stuff::unwrap, p_299089_ -> {
                if (p_299089_ instanceof class_4559.class_4561 statepropertiespredicate$exactmatcher) {
                    return Either.left(statepropertiespredicate$exactmatcher);
                } else if (p_299089_ instanceof class_4559.class_4563 statepropertiespredicate$rangedmatcher) {
                    return Either.right(statepropertiespredicate$rangedmatcher);
                } else {
                    throw new UnsupportedOperationException();
                }
            });

    private static final Codec<List<class_4559.class_4562>> PROPERTIES_CODEC = Codec.unboundedMap(
                    Codec.STRING, VALUE_CODEC
            )
            .xmap(
                    p_297916_ -> p_297916_.entrySet()
                            .stream()
                            .map(entry -> {
                                class_4559.class_4562 value = entry.getValue();

                                if (value instanceof class_4559.class_4561 exactPropertyMatcher) {
                                    return exactPropertyMatcher;
                                } else if (value instanceof class_4559.class_4563 rangedPropertyMatcher) {
                                    return rangedPropertyMatcher;
                                } else throw new RuntimeException();
                            })
                            .toList(),
                    p_297915_ -> p_297915_.stream()
                            .collect(Collectors.toMap(class_4559.class_4562::method_22533, propertyMatcher -> propertyMatcher))
            );



    public static final Codec<class_4559> STATE_PROPERTIES_PREDICATE_CODEC = PROPERTIES_CODEC.xmap(class_4559::new, s -> s.field_20737);

    public static final Codec<class_4550> BLOCK_PREDICATE_CODEC = RecordCodecBuilder.create(
            p_337342_ -> p_337342_.group(
                            class_6862.method_40090(class_7924.field_41254).optionalFieldOf("tag").forGetter(i -> Optional.ofNullable(i.field_20693)),
                            class_7923.field_41175.method_39673().listOf()
                                    .xmap(Set::copyOf, List::copyOf).optionalFieldOf("blocks").forGetter(b -> Optional.ofNullable(b.field_20694)),
                            STATE_PROPERTIES_PREDICATE_CODEC.fieldOf("state").forGetter(b -> b.field_20695),
                            NBT_PREDICATE_CODEC.fieldOf("nbt").forGetter(b -> b.field_20696)
                    )
                    .apply(p_337342_, (Optional<class_6862<class_2248>> tag, Optional<Set<class_2248>> blocks, class_4559 properties, class_2105 nbt) -> new class_4550(
                            tag.orElse(null), blocks.orElse(null), properties,nbt)));

    public static final Codec<class_4551> FLUID_PREDICATE_CODEC = RecordCodecBuilder.create(
            p_337342_ -> p_337342_.group(
                            class_6862.method_40090(class_7924.field_41270).optionalFieldOf("tag").forGetter(i -> Optional.ofNullable(i.field_20709)),
                            class_7923.field_41173.method_39673().optionalFieldOf("fluid").forGetter(b -> Optional.ofNullable(b.field_20710)),
                            STATE_PROPERTIES_PREDICATE_CODEC.fieldOf("state").forGetter(b -> b.field_20711)
                    )
                    .apply(p_337342_, (Optional<class_6862<class_3611>> tag, Optional<class_3611> blocks, class_4559 properties) -> new class_4551(
                            tag.orElse(null), blocks.orElse(null), properties)));

    public static final Codec<class_2090> LOCATION_PREDICATE_CODEC = RecordCodecBuilder.create(locationPredicateInstance -> {
        return locationPredicateInstance.group(
                PositionPredicate.CODEC.optionalFieldOf("location",PositionPredicate.ANY)
                        .forGetter(locationPredicate -> new PositionPredicate(locationPredicate.field_9682,locationPredicate.field_9684,locationPredicate.field_9681)),
                class_5321.method_39154(class_7924.field_41236).optionalFieldOf("biomes").forGetter(l -> Optional.ofNullable(l.field_9683)),
                class_5321.method_39154(class_7924.field_41246).optionalFieldOf("structures").forGetter(l -> Optional.ofNullable(l.field_9687)),
                class_5321.method_39154(class_7924.field_41223).optionalFieldOf("dimension").forGetter(l -> Optional.ofNullable(l.field_9686)),
                Codec.BOOL.optionalFieldOf("smokey").forGetter(l -> Optional.ofNullable(l.field_24500)),
                LIGHT_PREDICATE_CODEC.optionalFieldOf("light",class_4552.field_20712).forGetter(l -> l.field_20714),
                BLOCK_PREDICATE_CODEC.optionalFieldOf("block",class_4550.field_20692).forGetter(l -> l.field_20715),
                FLUID_PREDICATE_CODEC.optionalFieldOf("fluid",class_4551.field_20708).forGetter(l -> l.field_20716)
        ).apply(locationPredicateInstance, Stuff::fromLocationCodec);
    });

    private static class_2090 fromLocationCodec(PositionPredicate t1, Optional<class_5321<class_1959>> t2, Optional<class_5321<class_3195>> t3,
                                                       Optional<class_5321<class_1937>> t4, Optional<Boolean> t5, class_4552 t6, class_4550 t7, class_4551 t8) {
        return new class_2090(t1.x,t1.y,t1.z,t2.orElse(null),t3.orElse(null),t4.orElse(null),t5.orElse(null),t6,t7,t8);
    }

    private static class_2073 fromItemCodec(Optional<class_6862<class_1792>> itemTagKey, Optional<Set<class_1792>> items, class_2096.class_2100 ints,
                                           class_2096.class_2100 ints2, List<class_2035> enchantmentPredicates,
                                           List<class_2035> enchantmentPredicates2, Optional<class_1842> potion, class_2105 nbtPredicate) {
        return new class_2073(itemTagKey.orElse(null),items.orElse(null),ints,ints2,
                enchantmentPredicates.toArray(class_2035[]::new),enchantmentPredicates.toArray(class_2035[]::new),
                potion.orElse(null),nbtPredicate);
    }

    public static final Codec<class_2561> COMPONENT_CODEC = Codec.STRING.xmap(class_2561.class_2562::method_10877, class_2561.class_2562::method_10867);

    //    public static final Codec<ItemStack> CODEC = RecordCodecBuilder.create((instance) -> {
    //        return instance.group(BuiltInRegistries.ITEM.byNameCodec().fieldOf("id").forGetter(ItemStack::getItem), Codec.INT.fieldOf("Count").forGetter(ItemStack::getCount), CompoundTag.CODEC.optionalFieldOf("tag").forGetter((itemStack) -> {
    //            return Optional.ofNullable(itemStack.getTag());
    //        })).apply(instance, ItemStack::new);
    //    });

    public static final int MILLIS_PER_TICK = 50;

    static class_2035 fromCodec(Optional<class_1887> enchantment, class_2096.class_2100 levels) {
        return new class_2035(enchantment.orElse(null), levels);
    }

    public record PositionPredicate(class_2096.class_2099 x, class_2096.class_2099 y, class_2096.class_2099 z) {

        public static final PositionPredicate ANY = new PositionPredicate(class_2096.class_2099.field_9705, class_2096.class_2099.field_9705, class_2096.class_2099.field_9705);

        public static final Codec<PositionPredicate> CODEC = RecordCodecBuilder.create(
                p_337379_ -> p_337379_.group(
                                DOUBLES_CODEC.optionalFieldOf("x", class_2096.class_2099.field_9705).forGetter(PositionPredicate::x),
                                DOUBLES_CODEC.optionalFieldOf("y", class_2096.class_2099.field_9705).forGetter(PositionPredicate::y),
                                DOUBLES_CODEC.optionalFieldOf("z", class_2096.class_2099.field_9705).forGetter(PositionPredicate::z)
                        )
                        .apply(p_337379_, PositionPredicate::new)
        );

        static Optional<PositionPredicate> of(class_2096.class_2099 x, class_2096.class_2099 y, class_2096.class_2099 z) {
            return x.method_9041() && y.method_9041() && z.method_9041()
                    ? Optional.empty()
                    : Optional.of(new PositionPredicate(x, y, z));
        }

        public boolean matches(double x, double y, double z) {
            return this.x.method_9047(x) && this.y.method_9047(y) && this.z.method_9047(z);
        }
    }
}
