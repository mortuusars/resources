package io.github.mortuusars.exposure.world.camera.film.properties;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.capture.DitherMode;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_2540;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5699;
import net.minecraft.class_6880;

public record FilmProperties(ExposureType type,
                             Optional<Integer> size,
                             class_5321<ColorPalette> colorPalette,
                             DitherMode ditherMode,
                             FilmStyle style) {
    public FilmProperties {
        size.ifPresent(s -> Preconditions.checkArgument(s > 0 && s <= 2048,
                "size must be 1-2048: " + size));
    }

    public static final Codec<FilmProperties> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            ExposureType.CODEC.optionalFieldOf("type", ExposureType.COLOR).forGetter(FilmProperties::type),
            class_5699.method_48766(0, 2048).optionalFieldOf("frame_size").forGetter(FilmProperties::size),
            class_5321.method_39154(Exposure.Registries.COLOR_PALETTE).optionalFieldOf("color_palette", ColorPalettes.DEFAULT).forGetter(FilmProperties::colorPalette),
            DitherMode.CODEC.optionalFieldOf("dither_mode", DitherMode.DITHERED).forGetter(FilmProperties::ditherMode),
            FilmStyle.CODEC.optionalFieldOf("style", FilmStyle.EMPTY).forGetter(FilmProperties::style)
    ).apply(instance, FilmProperties::new));

    public void toPacket(class_2540 buf) {
        buf.method_10817(type);
        buf.method_37435(size,class_2540::writeInt);
        buf.method_44116(colorPalette);
        buf.method_10817(ditherMode);
        style.toPacket(buf);
    }

    public static FilmProperties fromPacket(class_2540 buf){
        return new FilmProperties(buf.method_10818(ExposureType.class),buf.method_37436(class_2540::readInt),buf.method_44112(Exposure.Registries.COLOR_PALETTE),
                buf.method_10818(DitherMode.class),FilmStyle.fromPacket(buf)
        );
    }

    public static final FilmProperties EMPTY = new FilmProperties(
            ExposureType.COLOR,
            Optional.empty(),
            ColorPalettes.DEFAULT,
            DitherMode.DITHERED,
            FilmStyle.EMPTY);

    public FilmProperties withType(ExposureType type) {
        return new FilmProperties(type, size, colorPalette, ditherMode, style);
    }

    public FilmProperties withSize(@Nullable Integer size) {
        return new FilmProperties(type, Optional.ofNullable(size), colorPalette, ditherMode, style);
    }

    public FilmProperties withColorPalette(@NotNull class_5321<ColorPalette> colorPalette) {
        return new FilmProperties(type, size, colorPalette, ditherMode, style);
    }

    public FilmProperties withDitherMode(DitherMode ditherMode) {
        return new FilmProperties(type, size, colorPalette, ditherMode, style);
    }

    public FilmProperties withStyle(@NotNull FilmStyle style) {
        return new FilmProperties(type, size, colorPalette, ditherMode, style);
    }

    // --

    public int getSize() {
        return size.orElse(Config.Server.DEFAULT_FRAME_SIZE.get());
    }

    public class_6880<ColorPalette> getColorPalette(class_5455 access) {
        return ColorPalettes.get(access, colorPalette);
    }
}