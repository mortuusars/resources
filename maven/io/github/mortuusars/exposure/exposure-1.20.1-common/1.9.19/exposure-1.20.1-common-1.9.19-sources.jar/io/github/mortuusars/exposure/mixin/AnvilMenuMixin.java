package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.world.item.InterplanarProjectorItem;
import net.minecraft.class_155;
import net.minecraft.class_1661;
import net.minecraft.class_1706;
import net.minecraft.class_3914;
import net.minecraft.class_3917;
import net.minecraft.class_4861;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1706.class)
public abstract class AnvilMenuMixin extends class_4861 {
    @Shadow
    @Nullable
    private static String validateName(String itemName) {
        return null;
    }

    public AnvilMenuMixin(@Nullable class_3917<?> type, int containerId, class_1661 playerInventory, class_3914 access) {
        super(type, containerId, playerInventory, access);
    }

    @Redirect(method = "setItemName", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/inventory/AnvilMenu;validateName(Ljava/lang/String;)Ljava/lang/String;"))
    private String onSetItemName(String itemName) {
        if (!Config.Server.INTERPLANAR_PROJECTOR_LARGER_RENAMING_LIMIT.get()
                || !(field_22480.method_5438(0).method_7909() instanceof InterplanarProjectorItem)) {
            return validateName(itemName);
        }
        String filtered = class_155.method_644(itemName);
        return filtered.length() <= 150 ? filtered : null;
    }
}
