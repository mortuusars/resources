package io.github.mortuusars.exposure.world.entity;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.item.PhotographFrameItem;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public class GlassPhotographFrameEntity extends PhotographFrameEntity {
    public GlassPhotographFrameEntity(class_1299<? extends PhotographFrameEntity> entityType, class_1937 level) {
        super(entityType, level);
    }

    public GlassPhotographFrameEntity(class_1937 level, class_2338 pos, class_2350 facingDirection) {
        super(Exposure.EntityTypes.CLEAR_PHOTOGRAPH_FRAME.get(), level, pos, facingDirection);
    }

    protected GlassPhotographFrameEntity(class_1299<? extends PhotographFrameEntity> entityType, class_1937 level, class_2338 pos, class_2350 facingDirection) {
        super(entityType, level, pos, facingDirection);
    }

    @Override
    public PhotographFrameItem getBaseFrameItem() {
        return Exposure.Items.GLASS_PHOTOGRAPH_FRAME.get();
    }

    @Override
    public boolean isFrameInvisible() {
        return super.isFrameInvisible() || !getItem().method_7960();
    }
}