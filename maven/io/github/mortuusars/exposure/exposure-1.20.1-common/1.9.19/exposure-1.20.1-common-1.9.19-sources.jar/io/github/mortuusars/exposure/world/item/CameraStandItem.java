package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_5712;

public class CameraStandItem extends class_1792 {
    public CameraStandItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_2350 direction = context.method_8038();
        if (direction == class_2350.field_11033) return class_1269.field_5814;

        class_1937 level = context.method_8045();
        class_1750 blockPlaceContext = new class_1750(context);
        class_2338 blockPos = blockPlaceContext.method_8037();
        class_1799 itemStack = context.method_8041();
        class_243 pos = class_243.method_24955(blockPos);
        class_238 aabb = Exposure.EntityTypes.CAMERA_STAND.get().method_18386().method_30231(pos.method_10216(), pos.method_10214(), pos.method_10215());
        if (!level.method_8587(null, aabb) || !level.method_8335(null, aabb).isEmpty()) return class_1269.field_5814;

        if (level instanceof class_3218 serverLevel) {
            Consumer<CameraStandEntity> consumer = class_1299.method_48009(serverLevel, itemStack, context.method_8036());
            CameraStandEntity cameraStand = Exposure.EntityTypes.CAMERA_STAND.get()
                    .method_5888(serverLevel,null, consumer, blockPos, class_3730.field_16465, true, true);
            if (cameraStand == null) {
                return class_1269.field_5814;
            }

            if (context.method_8036() != null) {
                cameraStand.setOwnerPlayer(context.method_8036());
            }
            cameraStand.method_5808(cameraStand.method_23317(), cameraStand.method_23318(), cameraStand.method_23321(), 0.0F, 0.0F);
            serverLevel.method_30771(cameraStand);
            cameraStand.playPlaceSound();
            cameraStand.method_32875(class_5712.field_28738, context.method_8036());
        }

        itemStack.method_7934(1);
        return class_1269.method_29236(level.field_9236);
    }

    public class_1269 interactWithBoat(class_1657 player, class_1268 hand, class_1690 boat) {
        if (!player.method_21823()) return class_1269.field_5811;
        class_1799 itemStack = player.method_5998(hand);
        if (!(itemStack.method_7909() instanceof CameraStandItem)) return class_1269.field_5811;
        if (boat.method_5685().size() >= 2) return class_1269.field_5811;

        if (player.method_37908() instanceof class_3218 serverLevel) {
            Consumer<CameraStandEntity> consumer = class_1299.method_48009(serverLevel, itemStack, player);
            CameraStandEntity cameraStand = Exposure.EntityTypes.CAMERA_STAND.get()
                    .method_5888(serverLevel,null, consumer, boat.method_24515(), class_3730.field_16465, true, true);
            if (cameraStand == null) {
                return class_1269.field_5814;
            }

            cameraStand.setOwnerPlayer(player);

            cameraStand.method_5804(boat);
            boat.method_24201(cameraStand);

            serverLevel.method_30771(cameraStand);
            cameraStand.playPlaceSound();
            cameraStand.method_32875(class_5712.field_28738, player);

            itemStack.method_7934(1);
            player.method_6122(hand, itemStack);
            return class_1269.field_5812;
        }

        return class_1269.field_21466;
    }
}
