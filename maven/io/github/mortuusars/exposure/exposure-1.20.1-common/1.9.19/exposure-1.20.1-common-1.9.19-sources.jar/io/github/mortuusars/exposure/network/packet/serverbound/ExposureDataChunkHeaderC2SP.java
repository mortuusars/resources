package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureServer;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.level.storage.ExposureData;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public record ExposureDataChunkHeaderC2SP(String id, int width, int height,
                                          class_2960 palette, ExposureData.Tag tag) implements Packet {
    public static final class_2960 ID = Exposure.resource("exposure_data_chunk_header");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buffer) {
        buffer.method_10814(id);
        buffer.writeInt(width);
        buffer.writeInt(height);
        buffer.method_10812(palette);
        tag.toPacket(buffer);
    }

    public static ExposureDataChunkHeaderC2SP fromPacket(class_2540 buffer) {
        return new ExposureDataChunkHeaderC2SP(buffer.method_19772(),
              buffer.readInt(),
              buffer.readInt(),
              buffer.method_10810(),
              ExposureData.Tag.fromPacket(buffer));
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Exposure.LOGGER.error("Cannot receive '{}' packet. Player is not ServerPlayer.", ID);
            return false;
        }

        ExposureServer.exposureRepository().receiveChunkedClientUploadHeader(serverPlayer, id, width, height, palette, tag);
        return true;
    }

}
