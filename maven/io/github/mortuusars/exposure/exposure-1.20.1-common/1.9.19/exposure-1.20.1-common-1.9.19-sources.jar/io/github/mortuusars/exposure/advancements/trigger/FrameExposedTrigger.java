package io.github.mortuusars.exposure.advancements.trigger;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.advancements.predicate.CameraPredicate;
import io.github.mortuusars.exposure.advancements.predicate.FramePredicate;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_173;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_195;
import net.minecraft.class_2090;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3518;
import net.minecraft.class_4558;
import net.minecraft.class_47;
import net.minecraft.class_5257;
import net.minecraft.class_5258;
import net.minecraft.class_5267;
import net.minecraft.class_8567;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class FrameExposedTrigger extends class_4558<FrameExposedTrigger.TriggerInstance> {

    public static final class_2960 ID = Exposure.resource("frame_exposed");

    public void trigger(class_3222 player,
                        CameraHolder cameraHolder,
                        class_1799 cameraStack,
                        Frame frame,
                        List<class_2338> locationsInFrame,
                        List<class_1309> entitiesInFrame) {
        this.method_22510(player, triggerInstance ->
                triggerInstance.matches(player, cameraHolder, cameraStack, frame, locationsInFrame, entitiesInFrame));
    }

    @Override
    protected TriggerInstance method_27854(JsonObject json, class_5258 predicate, class_5257 deserializationContext) {
        CameraPredicate camera = CameraPredicate.fromJson(json.get("camera"));
        FramePredicate frame = FramePredicate.fromJson(json.get("frame"));
        class_2090 location = class_2090.method_9021(json.get("location_in_frame"));

        List<class_5258> entitiesInFrame = new ArrayList<>();
        if (json.has("entities_in_frame")) {
            JsonArray array = class_3518.method_15261(json,"entities_in_frame");
            for (JsonElement element : array) {
                entitiesInFrame.add(class_5258.method_27807(null,deserializationContext,element,class_173.field_44788));
            }
        }

        return new TriggerInstance(predicate, camera, frame, location,entitiesInFrame);
    }

    @Override
    public class_2960 method_794() {
        return ID;
    }

    public static final class TriggerInstance extends class_195 {

        private final CameraPredicate camera;
        private final FramePredicate frame;
        private final class_2090 locationInFrame;
        private final List<class_5258> entitiesInFrame;

        public TriggerInstance(class_5258 player,
                               CameraPredicate camera,
                               FramePredicate frame,
                               class_2090 locationInFrame,
                               List<class_5258> entitiesInFrame) {
            super(ID, player);
            this.camera = camera;
            this.frame = frame;
            this.locationInFrame = locationInFrame;
            this.entitiesInFrame = entitiesInFrame;
        }

            public boolean matches(class_3222 player,
                                   CameraHolder cameraHolder,
                                   class_1799 cameraStack,
                                   Frame frame,
                                   List<class_2338> locationsInFrame,
                                   List<class_1309> entitiesInFrame) {
                return (camera.matches(player.method_51469(), cameraStack, cameraHolder.asHolderEntity().method_19538()))
                        && (this.frame.matches(frame))
                        && locationsMatch(player, locationsInFrame)
                        && entitiesInFrameMatch(player, cameraHolder, entitiesInFrame);
            }

            private boolean locationsMatch(class_3222 player, List<class_2338> locationsInFrame) {
                return locationInFrame == class_2090.field_9685 || locationsInFrame.stream().anyMatch(pos ->
                        locationInFrame.method_9018(player.method_51469(), pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5));
            }

            private boolean entitiesInFrameMatch(class_3222 player, CameraHolder cameraHolder, List<class_1309> entitiesInFrame) {
                return this.entitiesInFrame.isEmpty() || this.entitiesInFrame.stream().allMatch(predicate ->
                        entitiesInFrame.stream().anyMatch(entity -> {
                            class_47 context = createContextForHolder(player.method_51469(), cameraHolder, entity);
                            return predicate.method_27806(context);
                        }));
            }

            public static class_47 createContextForHolder(class_3218 level, CameraHolder holder, class_1297 entity) {
                class_8567 lootParams = new class_8567.class_8568(level)
                        .method_51874(class_181.field_1226, entity)
                        .method_51874(class_181.field_24424, holder.asHolderEntity().method_19538())
                        .method_51875(class_173.field_24423);
                return new class_47.class_48(lootParams).method_309(ID);
            }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) return true;
            if (obj == null || obj.getClass() != this.getClass()) return false;
            var that = (TriggerInstance) obj;
            return
                    Objects.equals(this.camera, that.camera) &&
                    Objects.equals(this.frame, that.frame) &&
                    Objects.equals(this.locationInFrame, that.locationInFrame) &&
                    Objects.equals(this.entitiesInFrame, that.entitiesInFrame);
        }

        @Override
        public int hashCode() {
            return Objects.hash(camera, frame, locationInFrame, entitiesInFrame);
        }

        @Override
        public JsonObject method_807(class_5267 context) {
            JsonObject jsonObject = super.method_807(context);
            if (camera != CameraPredicate.ANY) {
                jsonObject.add("camera", camera.serializeToJson());
            }
            if (frame != FramePredicate.ANY) {
                jsonObject.add("frame", frame.serializeToJson());
            }
            if (locationInFrame != class_2090.field_9685) {
                jsonObject.add("location_in_frame",locationInFrame.method_9019());
            }
            if (!entitiesInFrame.isEmpty()) {
                JsonArray jsonArray = new JsonArray();
                for (class_5258 contextAwarePredicate : entitiesInFrame) {
                    jsonArray.add(contextAwarePredicate.method_27804(context));
                }
                jsonObject.add("entities_in_frame",jsonArray);
            }
            return jsonObject;
        }

        @Override
        public String toString() {
            return "TriggerInstance[" +
                    "camera=" + camera + ", " +
                    "frame=" + frame + ", " +
                    "locationInFrame=" + locationInFrame + ", " +
                    "entitiesInFrame=" + entitiesInFrame + ']';
        }

        }
}