package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.client.gui.ClientGUI;
import io.github.mortuusars.exposure.world.item.component.album.SignedAlbumContent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3715;

public class SignedAlbumItem extends class_1792 {
    public SignedAlbumItem(class_1793 properties) {
        super(properties);
    }

    public SignedAlbumContent getContent(class_1799 stack) {
        return Exposure.DataComponents.getSignedAlbumContent(stack,SignedAlbumContent.EMPTY);
    }

    @Override
    public @NotNull class_2561 method_7864(class_1799 stack) {
        @Nullable SignedAlbumContent content = Exposure.DataComponents.getSignedAlbumContent(stack);
        if (content != null) {
            String title = content.title();
            if (!title.isBlank()) {
                return class_2561.method_43470(title);
            }
        }

        return super.method_7864(stack);
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        if (level.method_8608()) {
            ClientGUI.openAlbumViewScreen(player.method_5998(usedHand));
        }
        return class_1271.method_22427(player.method_5998(usedHand));
    }

    @Override
    public @NotNull class_1269 method_7884(class_1838 context) {
        class_2338 blockPos = context.method_8037();
        class_1937 level = context.method_8045();
        class_2680 blockState = level.method_8320(blockPos);
        if (blockState.method_27852(class_2246.field_16330))
            return class_3715.method_17472(context.method_8036(), level, blockPos, blockState,
                  context.method_8041()) ? class_1269.method_29236(level.field_9236) : class_1269.field_5811;
        return class_1269.field_5811;
    }

    @Override
    public void method_7851(class_1799 stack, class_1937 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        @Nullable SignedAlbumContent content = Exposure.DataComponents.getSignedAlbumContent(stack);

        if (content != null) {
            String author = content.author();
            if (!author.isBlank()) {
                tooltipComponents.add(class_2561.method_43469("gui.exposure.album.by_author", author).method_27692(class_124.field_1080));
            }

            if (Config.Client.ALBUM_PHOTOS_COUNT_TOOLTIP.get()) {
                int photographsCount = (int)content.pages().stream().filter(page -> !page.photograph().method_7960()).count();
                if (photographsCount > 0)
                    tooltipComponents.add(class_2561.method_43469("item.exposure.album.tooltip.photos_count", photographsCount));
            }
        }

    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return Config.Common.SIGNED_ALBUM_GLINT.get();
    }
}
