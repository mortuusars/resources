package io.github.mortuusars.exposure.world.camera.component;

import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;

public record CompositionGuide(String name) {
    public static final Codec<CompositionGuide> CODEC = Codec.STRING.xmap(CompositionGuides::byNameOrNone, CompositionGuide::name);

    public void toPacket(class_2540 buf) {
        buf.method_10814(name);
    }

    public static CompositionGuide fromPacket(class_2540 buf) {
        return CompositionGuides.byNameOrNone(buf.method_19772());
    }

    public class_5250 translate() {
        return class_2561.method_43471("gui." + Exposure.ID + ".composition_guide." + name);
    }

    public class_2960 overlayTextureLocation() {
        return Exposure.resource("textures/gui/viewfinder/composition_guide/" + name + ".png");
    }

    public class_2960 buttonSpriteLocation() {
        return Exposure.resource("camera_controls/composition_guide/" + name);
    }
}
