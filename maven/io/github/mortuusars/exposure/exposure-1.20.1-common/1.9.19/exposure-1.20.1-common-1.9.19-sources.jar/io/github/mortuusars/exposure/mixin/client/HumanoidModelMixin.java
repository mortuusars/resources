package io.github.mortuusars.exposure.mixin.client;

import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.client.animation.CameraModelPoses;
import io.github.mortuusars.exposure.client.animation.CameraPoses;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.camera.CameraInHand;
import io.github.mortuusars.exposure.world.camera.CameraOnStand;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.entity.CameraOperator;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_4592;
import net.minecraft.class_4896;
import net.minecraft.class_572;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_572.class)
public abstract class HumanoidModelMixin<T extends class_1309> extends class_4592<T> {
    @Shadow
    @Final
    public class_630 leftArm;
    @Shadow
    @Final
    public class_630 rightArm;

    // Allows reducing/removing arm bobbing. Doing the bobbing in reverse does not work correctly - arms shiver for some reason.
    @Unique
    private float exposure$LeftArmBobbingMultiplier = 1F;
    @Unique
    private float exposure$RightArmBobbingMultiplier = 1F;

    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/AnimationUtils;bobModelPart(Lnet/minecraft/client/model/geom/ModelPart;FF)V", ordinal = 0))
    void onSetupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci) {
        if (!(entity instanceof CameraOperator operator)) {
            exposure$LeftArmBobbingMultiplier = 1F;
            exposure$RightArmBobbingMultiplier = 1F;
            return;
        }

        Camera camera = operator.getActiveExposureCamera();
        if (camera!=null && camera.getItemStack().method_7909() instanceof CameraItem item) {
            CameraPoses poses = CameraModelPoses.get(item);
            class_1306 arm = camera instanceof CameraInHand cameraInHand && cameraInHand.getHand() == class_1268.field_5810
                    ? class_310.method_1551().field_1690.method_42552().method_41753().method_5928()
                    : class_310.method_1551().field_1690.method_42552().method_41753();

            if (camera instanceof CameraOnStand cameraOnStand) {
                poses.applyStand((class_572<?>) (Object) this, entity, arm, cameraOnStand.getStand());
                exposure$LeftArmBobbingMultiplier = 1F;
                exposure$RightArmBobbingMultiplier = 1F;
                return;
            }

            if (item.isInSelfieMode(camera.getItemStack())) {
                poses.applySelfie((class_572<?>) (Object) this, entity, arm, false);

                if (arm == class_1306.field_6182) {
                    exposure$LeftArmBobbingMultiplier = 0F;
                    exposure$RightArmBobbingMultiplier = 1F;
                } else {
                    exposure$LeftArmBobbingMultiplier = 1F;
                    exposure$RightArmBobbingMultiplier = 0F;
                }

                return;
            }

            //noinspection ConstantValue
            if (Minecrft.player().equals(entity) && PlatformHelper.isModLoaded("realcamera")) {
                return;
            }

            poses.applyHolding(((class_572<?>) (Object) this), entity, arm);
            exposure$LeftArmBobbingMultiplier = arm == class_1306.field_6182 ? 0.1F : 0.5F;
            exposure$RightArmBobbingMultiplier = arm == class_1306.field_6183 ? 0.1F : 0.5F;
            return;
        }

        if (entity instanceof CameraHolder holder) {
            CameraInHand cameraInHand =CameraInHand.find(holder);
            if (cameraInHand!= null) {
                cameraInHand.ifPresent((item, stack) -> {
                    CameraPoses poses = CameraModelPoses.get(item);
                    if (item.isDisassembled(stack)) {
                        class_1306 arm = cameraInHand.getHand() == class_1268.field_5810
                                ? class_310.method_1551().field_1690.method_42552().method_41753().method_5928()
                                : class_310.method_1551().field_1690.method_42552().method_41753();
                        poses.applyDisassembled((class_572<?>) (Object) this, entity, arm);
                    }
                });
            }
        }
        exposure$LeftArmBobbingMultiplier = 1F;
        exposure$RightArmBobbingMultiplier = 1F;
    }

    @Redirect(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/AnimationUtils;bobModelPart(Lnet/minecraft/client/model/geom/ModelPart;FF)V"))
    private void removeBobbing(class_630 modelPart, float ageInTicks, float multiplier) {
        if (exposure$LeftArmBobbingMultiplier != 1F && modelPart == leftArm) {
            multiplier = exposure$LeftArmBobbingMultiplier * -1;
        }
        if (exposure$RightArmBobbingMultiplier != 1F && modelPart == rightArm) {
            multiplier = exposure$RightArmBobbingMultiplier;
        }
        class_4896.method_29350(modelPart, ageInTicks, multiplier);
    }
}