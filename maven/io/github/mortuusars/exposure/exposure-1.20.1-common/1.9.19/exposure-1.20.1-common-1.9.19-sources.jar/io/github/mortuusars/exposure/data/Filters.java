package io.github.mortuusars.exposure.data;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.util.color.Color;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2073;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_7891;

public class Filters {

    public static final class_5321<Filter> BLACK_PANE = key("black_pane");
    public static final class_5321<Filter> BLUE_PANE = key("blue_pane");
    public static final class_5321<Filter> BROKEN_INTERPLANAR_PROJECTOR = key("broken_interplanar_projector");
    public static final class_5321<Filter> BROWN_PANE = key("brown_pane");
    public static final class_5321<Filter> CYAN_PANE = key("cyan_pane");
    public static final class_5321<Filter> GLASS_PANE = key("glass_pane");
    public static final class_5321<Filter> GRAY_PANE = key("gray_pane");
    public static final class_5321<Filter> GREEN_PANE = key("green_pane");
    public static final class_5321<Filter> INTERPLANAR_PROJECTOR = key("interplanar_projector");
    public static final class_5321<Filter> LIGHT_BLUE_PANE = key("light_blue_pane");
    public static final class_5321<Filter> LIGHT_GRAY_PANE = key("light_gray_pane");
    public static final class_5321<Filter> LIME_PANE = key("lime_pane");
    public static final class_5321<Filter> MAGENTA_PANE = key("magenta_pane");
    public static final class_5321<Filter> ORANGE_PANE = key("orange_pane");
    public static final class_5321<Filter> PINK_PANE = key("pink_pane");
    public static final class_5321<Filter> PURPLE_PANE = key("purple_pane");
    public static final class_5321<Filter> RED_PANE = key("red_pane");
    public static final class_5321<Filter> WHITE_PANE = key("white_pane");
    public static final class_5321<Filter> YELLOW_PANE = key("yellow_pane");

    public static Optional<Filter> of(class_5455 registryAccess, class_1799 stack) {
        return registryAccess.method_30530(Exposure.Registries.FILTER)
                .method_10220()
                .filter(filter -> filter.predicate().method_8970(stack))
                .findFirst();
    }

    public static Optional<class_2960> locationOf(class_5455 registryAccess, Filter filter) {
        return Optional.ofNullable(registryAccess.method_30530(Exposure.Registries.FILTER).method_10221(filter));
    }



    public static void bootstrap(class_7891<Filter> ctx) {
        ctx.method_46838(BLACK_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8157).method_8976(),
                Exposure.resource("shaders/post/black_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("1E1B1B")));
        ctx.method_46838(BLUE_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8747).method_8976(),
                Exposure.resource("shaders/post/blue_filter.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("253192")));
        ctx.method_46838(BROKEN_INTERPLANAR_PROJECTOR,new Filter(class_2073.class_2074.method_8973().method_8977(Exposure.Items.BROKEN_INTERPLANAR_PROJECTOR.get()).method_8976(),
                Exposure.resource("shaders/post/bsod.json"),
                Exposure.resource("textures/gui/filter/broken_interplanar_projector.png"), Color.WHITE));
        ctx.method_46838(BROWN_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8501).method_8976(),
                Exposure.resource("shaders/post/brown_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("51301A")));
        ctx.method_46838(CYAN_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8085).method_8976(),
                Exposure.resource("shaders/post/cyan_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("287697")));
        ctx.method_46838(GLASS_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8141).method_8976(),
                Exposure.resource("shaders/post/crisp.json"),
                Exposure.resource("textures/gui/filter/glass.png"), Color.WHITE));
        ctx.method_46838(GRAY_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8871).method_8976(),
                Exposure.resource("shaders/post/gray_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("434343")));
        ctx.method_46838(GREEN_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8656).method_8976(),
                Exposure.resource("shaders/post/green_filter.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("3B511A")));
        ctx.method_46838(INTERPLANAR_PROJECTOR,new Filter(class_2073.class_2074.method_8973().method_8977(Exposure.Items.INTERPLANAR_PROJECTOR.get()).method_8976(),
                Exposure.resource("shaders/post/invert.json"),
                Exposure.resource("textures/gui/filter/interplanar_projector.png"), Color.WHITE));
        ctx.method_46838(LIGHT_BLUE_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8196).method_8976(),
                Exposure.resource("shaders/post/light_blue_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("6689D3")));
        ctx.method_46838(LIGHT_GRAY_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8240).method_8976(),
                Exposure.resource("shaders/post/light_gray_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("ABABAB")));
        ctx.method_46838(LIME_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8581).method_8976(),
                Exposure.resource("shaders/post/lime_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("41CD34")));
        ctx.method_46838(MAGENTA_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8119).method_8976(),
                Exposure.resource("shaders/post/magenta_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("C354CD")));
        ctx.method_46838(ORANGE_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8761).method_8976(),
                Exposure.resource("shaders/post/orange_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("EB8844")));
        ctx.method_46838(PINK_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8500).method_8976(),
                Exposure.resource("shaders/post/pink_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("D88198")));
        ctx.method_46838(PURPLE_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8739).method_8976(),
                Exposure.resource("shaders/post/purple_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("7B2FBE")));
        ctx.method_46838(RED_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8879).method_8976(),
                Exposure.resource("shaders/post/red_filter.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("B3312C")));
        ctx.method_46838(WHITE_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8736).method_8976(),
                Exposure.resource("shaders/post/white_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.WHITE));
        ctx.method_46838(YELLOW_PANE,new Filter(class_2073.class_2074.method_8973().method_8977(class_1802.field_8703).method_8976(),
                Exposure.resource("shaders/post/yellow_tint.json"), Filter.DEFAULT_GLASS_TEXTURE, Color.fromHex("DECF2A")));
    }

    private static class_5321<Filter> key(String name) {
        return class_5321.method_29179(Exposure.Registries.FILTER, Exposure.resource(name));
    }
}