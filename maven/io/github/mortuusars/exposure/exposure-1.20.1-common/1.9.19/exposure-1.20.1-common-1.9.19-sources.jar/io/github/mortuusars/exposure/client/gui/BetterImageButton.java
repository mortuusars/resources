package io.github.mortuusars.exposure.client.gui;

import io.github.mortuusars.exposure.ModWidgetSprites;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_5244;

/**
 * backport of ImageButton from 1.21.1
 */
public class BetterImageButton extends class_4185 {
    protected final ModWidgetSprites sprites;

    public BetterImageButton(int x, int y, int width, int height, ModWidgetSprites sprites, class_4185.class_4241 onPress) {
        this(x, y, width, height, sprites, onPress, class_5244.field_39003);
    }

    public BetterImageButton(int x, int y, int width, int height, ModWidgetSprites sprites, class_4185.class_4241 onPress, class_2561 message) {
        super(x, y, width, height, message, onPress, field_40754);
        this.sprites = sprites;
    }

    public BetterImageButton(int width, int height, ModWidgetSprites sprites, class_4185.class_4241 onPress, class_2561 message) {
        this(0, 0, width, height, sprites, onPress, message);
    }

    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        class_2960 resourceLocation = this.sprites.get(this.method_37303(), this.method_25367());
        guiGraphics.method_25290(resourceLocation, this.method_46426(), this.method_46427(), 0, 0, this.field_22758, this.field_22759, field_22758, field_22759);
    }
}
