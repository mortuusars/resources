package io.github.mortuusars.exposure.client.gui.component;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_7172;
import net.minecraft.class_7919;
import net.minecraft.class_7940;
import org.jetbrains.annotations.Nullable;

public class FutureCheckbox  extends class_4264 {
    private static final class_2960 CHECKBOX_SELECTED_HIGHLIGHTED_SPRITE = new class_2960("widget/checkbox_selected_highlighted");
    private static final class_2960 CHECKBOX_SELECTED_SPRITE = new class_2960("widget/checkbox_selected");
    private static final class_2960 CHECKBOX_HIGHLIGHTED_SPRITE = new class_2960("widget/checkbox_highlighted");
    private static final class_2960 CHECKBOX_SPRITE = new class_2960("widget/checkbox");
    private static final int TEXT_COLOR = 14737632;
    private static final int SPACING = 4;
    private static final int BOX_PADDING = 8;
    private boolean selected;
    private final OnValueChange onValueChange;
    private final class_7940 textWidget;

    FutureCheckbox(int x, int y, int maxWidth, class_2561 message, class_327 font, boolean selected, OnValueChange onValueChange) {
        super(x, y, 0, 0, message);
        this.field_22758 = this.getAdjustedWidth(maxWidth, message, font);
        this.textWidget = new class_7940(message, font).method_48984(this.field_22758).method_48983(14737632);
        this.field_22759 = this.getAdjustedHeight(font);
        this.selected = selected;
        this.onValueChange = onValueChange;
    }

    private int getAdjustedWidth(int maxWidth, class_2561 message, class_327 font) {
        return Math.min(getDefaultWidth(message, font), maxWidth);
    }

    private int getAdjustedHeight(class_327 font) {
        return Math.max(getBoxSize(font), this.textWidget.method_25364());
    }

    static int getDefaultWidth(class_2561 message, class_327 font) {
        return getBoxSize(font) + 4 + font.method_27525(message);
    }

    public static FutureCheckbox.Builder builder(class_2561 message, class_327 font) {
        return new FutureCheckbox.Builder(message, font);
    }

    public static int getBoxSize(class_327 font) {
        return 9 + 8;
    }

    @Override
    public void method_25306() {
        this.selected = !this.selected;
        this.onValueChange.onValueChange(this, this.selected);
    }

    public boolean selected() {
        return this.selected;
    }

    @Override
    public void method_47399(class_6382 narrationElementOutput) {
        narrationElementOutput.method_37034(class_6381.field_33788, this.method_25360());
        if (this.field_22763) {
            if (this.method_25370()) {
                narrationElementOutput.method_37034(class_6381.field_33791, class_2561.method_43471("narration.checkbox.usage.focused"));
            } else {
                narrationElementOutput.method_37034(class_6381.field_33791, class_2561.method_43471("narration.checkbox.usage.hovered"));
            }
        }
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        class_310 minecraft = class_310.method_1551();
        RenderSystem.enableDepthTest();
        class_327 font = minecraft.field_1772;
        guiGraphics.method_51422(1.0F, 1.0F, 1.0F, this.field_22765);
        RenderSystem.enableBlend();
        class_2960 resourcelocation;
        if (this.selected) {
            resourcelocation = this.method_25370() ? CHECKBOX_SELECTED_HIGHLIGHTED_SPRITE : CHECKBOX_SELECTED_SPRITE;
        } else {
            resourcelocation = this.method_25370() ? CHECKBOX_HIGHLIGHTED_SPRITE : CHECKBOX_SPRITE;
        }

        int i = getBoxSize(font);
        guiGraphics.method_25302(resourcelocation, this.method_46426(), this.method_46427(),0,0, i, i);
        int j = this.method_46426() + i + 4;
        int k = this.method_46427() + i / 2 - this.textWidget.method_25364() / 2;
        this.textWidget.method_48229(j, k);
        this.textWidget.method_48579(guiGraphics, mouseX, mouseY, partialTick);
    }

    public static class Builder {
        private final class_2561 message;
        private final class_327 font;
        private int maxWidth;
        private int x = 0;
        private int y = 0;
        private OnValueChange onValueChange = OnValueChange.NOP;
        private boolean selected = false;
        @Nullable
        private class_7172<Boolean> option = null;
        @Nullable
        private class_7919 tooltip = null;

        Builder(class_2561 message, class_327 font) {
            this.message = message;
            this.font = font;
            this.maxWidth = FutureCheckbox.getDefaultWidth(message, font);
        }

        public Builder pos(int x, int y) {
            this.x = x;
            this.y = y;
            return this;
        }

        public Builder onValueChange(OnValueChange onValueChange) {
            this.onValueChange = onValueChange;
            return this;
        }

        public Builder selected(boolean selected) {
            this.selected = selected;
            this.option = null;
            return this;
        }

        public Builder selected(class_7172<Boolean> option) {
            this.option = option;
            this.selected = option.method_41753();
            return this;
        }

        public Builder tooltip(class_7919 tooltip) {
            this.tooltip = tooltip;
            return this;
        }

        public Builder maxWidth(int maxWidth) {
            this.maxWidth = maxWidth;
            return this;
        }

        public FutureCheckbox build() {
            OnValueChange checkbox$onvaluechange = this.option == null ? this.onValueChange : (p_309064_, p_308939_) -> {
                this.option.method_41748(p_308939_);
                this.onValueChange.onValueChange(p_309064_, p_308939_);
            };
            FutureCheckbox checkbox = new FutureCheckbox(this.x, this.y, this.maxWidth, this.message, this.font, this.selected, checkbox$onvaluechange);
            checkbox.method_47400(this.tooltip);
            return checkbox;
        }
    }

    public interface OnValueChange {
        OnValueChange NOP = (p_309046_, p_309014_) -> {
        };

        void onValueChange(FutureCheckbox checkbox, boolean value);
    }
}