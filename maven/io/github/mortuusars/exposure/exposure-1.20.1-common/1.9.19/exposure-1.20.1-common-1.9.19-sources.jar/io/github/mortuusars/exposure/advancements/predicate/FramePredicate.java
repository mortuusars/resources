package io.github.mortuusars.exposure.advancements.predicate;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.Stuff;
import io.github.mortuusars.exposure.util.NbtType;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2096;
import net.minecraft.class_2105;
import net.minecraft.class_2487;
import net.minecraft.class_3518;

public record FramePredicate(Optional<ExposureIdentifier> identifier,
                             Optional<String> type,
                             Optional<String> photographer,
                             Optional<ShutterSpeedPredicate> shutterSpeed,
                             class_2096.class_2100 focalLength,
                             class_2096.class_2100 lightLevel,
                             class_2096.class_2100 dayTime,
                             class_2096.class_2100 entitiesInFrameCount,
                             List<EntityInFramePredicate> entitiesInFrame,
                             class_2105 extraData) {
    public static final Codec<FramePredicate> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            ExposureIdentifier.CODEC.optionalFieldOf("identifier").forGetter(FramePredicate::identifier),
            Codec.STRING.optionalFieldOf("type").forGetter(FramePredicate::type),
            Codec.STRING.optionalFieldOf("photographer").forGetter(FramePredicate::photographer),
            ShutterSpeedPredicate.CODEC.optionalFieldOf("shutter_speed").forGetter(FramePredicate::shutterSpeed),
            Stuff.INTS_CODEC.optionalFieldOf("focal_length", class_2096.class_2100.field_9708).forGetter(FramePredicate::focalLength),
            Stuff.INTS_CODEC.optionalFieldOf("light_level", class_2096.class_2100.field_9708).forGetter(FramePredicate::lightLevel),
            Stuff.INTS_CODEC.optionalFieldOf("day_time", class_2096.class_2100.field_9708).forGetter(FramePredicate::dayTime),
            Stuff.INTS_CODEC.optionalFieldOf("entities_in_frame_count", class_2096.class_2100.field_9708).forGetter(FramePredicate::entitiesInFrameCount),
            EntityInFramePredicate.CODEC.listOf().optionalFieldOf("entities_in_frame",List.of()).forGetter(FramePredicate::entitiesInFrame),
            Stuff.NBT_PREDICATE_CODEC.optionalFieldOf("extra_data",class_2105.field_9716).forGetter(FramePredicate::extraData)
    ).apply(instance, FramePredicate::new));

    public static final FramePredicate ANY = new FramePredicate(Optional.empty(),Optional.empty(),
            Optional.empty(),Optional.empty(), class_2096.class_2100.field_9708, class_2096.class_2100.field_9708,
            class_2096.class_2100.field_9708, class_2096.class_2100.field_9708,new ArrayList<>(),class_2105.field_9716);

    public static FramePredicate fromJson(@Nullable JsonElement json) {
        if (json == null || json.isJsonNull())
            return ANY;

        JsonObject jsonObj = class_3518.method_15295(json, "frame");

        return CODEC.decode(JsonOps.INSTANCE,jsonObj).resultOrPartial(Exposure.LOGGER::error).get().getFirst();
    }

    public JsonElement serializeToJson() {
        if (this == ANY) {
            return JsonNull.INSTANCE;
        } else {
            return CODEC.encodeStart(JsonOps.INSTANCE,this).resultOrPartial(Exposure.LOGGER::error).get();
        }
    }


        public boolean matches(class_1799 stack, Frame frame) {
        return matches(frame);
    }

    public boolean matches(Frame frame) {
        class_2487 extraData = frame.extraData();
        return (identifier.isEmpty() || identifier.get().equals(frame.identifier()))
                && (type.isEmpty() || type.get().equals(frame.type().method_15434()))
                && (photographer.isEmpty() || photographer.get().equals(frame.photographer().name()))
                && (shutterSpeed.isEmpty() || shutterSpeed.get().matches(NbtType.get(extraData,Frame.SHUTTER_SPEED)))
                && (NbtType.get(extraData,Frame.FOCAL_LENGTH).map(focalLength::method_9054).orElse(false))
                && (NbtType.get(extraData,Frame.LIGHT_LEVEL).map(lightLevel::method_9054).orElse(false))
                && (NbtType.get(extraData,Frame.DAY_TIME).map(dayTime::method_9054).orElse(false))
                && (entitiesInFrameCount.method_9054(frame.entitiesInFrame().size()))
                && (entitiesInFrame.isEmpty() || entitiesInFrame.stream().allMatch(predicate -> predicate.matches(frame.entitiesInFrame())))
                && (this.extraData.method_9077(frame.extraData()));
    }
}
