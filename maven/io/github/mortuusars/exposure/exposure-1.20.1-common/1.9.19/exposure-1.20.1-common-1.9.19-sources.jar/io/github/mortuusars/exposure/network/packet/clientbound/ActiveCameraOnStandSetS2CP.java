package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.world.camera.CameraOnStand;
import io.github.mortuusars.exposure.world.entity.CameraOperator;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record ActiveCameraOnStandSetS2CP(int operatorEntityId, int cameraStandId, CameraId cameraId) implements Packet {
    public static final class_2960 ID = Exposure.resource("active_camera_on_stand_set");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public void toPacket(class_2540 buf) {
        buf.writeInt(operatorEntityId);
        buf.writeInt(cameraStandId);
        cameraId.toPacket(buf);
    }

    public static ActiveCameraOnStandSetS2CP fromPacket(class_2540 buf) {
        return new ActiveCameraOnStandSetS2CP(buf.readInt(),buf.readInt(),CameraId.fromPacket(buf));
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        if (player.method_37908().method_8469(operatorEntityId) instanceof CameraOperator operator
                && player.method_37908().method_8469(cameraStandId) instanceof CameraStandEntity cameraStand) {
            operator.setActiveExposureCamera(new CameraOnStand(operator, cameraStand, cameraId));
        }
        return true;
    }
}
