package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.capture.CaptureParameters;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;

public record CaptureStartS2CP(class_2960 templateId, CaptureParameters captureParameters) implements Packet {
    public static final class_2960 ID = Exposure.resource("capture_start");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_10812(templateId);
        captureParameters.toPacket(buf);
    }

    public static CaptureStartS2CP fromPacket(class_2540 buf) {
        return new CaptureStartS2CP(buf.method_10810(),CaptureParameters.fromPacket(buf));
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.startCapture(this);
        return true;
    }
}
