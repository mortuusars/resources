package io.github.mortuusars.exposure.client.sound;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import io.github.mortuusars.exposure.client.util.Minecrft;
import net.minecraft.class_1106;
import net.minecraft.class_1113;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;

public class UniqueSoundManager {
    private static final Table<String, class_2960, class_1113> SOUNDS = HashBasedTable.create();

    public static void play(String id, class_1113 instance) {
        stop(id, instance.method_4775());

        SOUNDS.put(id, instance.method_4775(), instance);
        Minecrft.get().method_1483().method_4873(instance);
    }

    public static void play(String id, class_1297 entity, class_3414 sound, class_3419 source, float volume, float pitch) {
        class_1113 soundInstance = createEntityBoundInstance(entity, sound, source, volume, pitch);
        play(id, soundInstance);
    }

    public static void play(class_1297 entity, class_3414 sound, class_3419 source, float volume, float pitch) {
        String id = entity.method_5820();
        play(id, entity, sound, source, volume, pitch);
    }

    public static void stop(String id, class_2960 location) {
        @Nullable class_1113 instance = SOUNDS.remove(id, location);
        if (instance != null) Minecrft.get().method_1483().method_4870(instance);
    }

    public static void stop(String id, class_3414 sound) {
        stop(id, sound.method_14833());
    }

    public static void stopAllOf(class_3414 sound) {
        class_2960 location = sound.method_14833();
        SOUNDS.cellSet().removeIf(cell -> {
            if (cell.getColumnKey().equals(location)) {
                Minecrft.get().method_1483().method_4870(cell.getValue());
                return true;
            }
            return false;
        });
    }

//    public static void update(String id, SoundEvent sound, Consumer<SoundInstance> updater) {
//        @Nullable SoundInstance instance = SOUNDS.get(id, sound.getLocation());
//        if (instance != null) {
//            updater.accept(instance);
//        }
//    }

    private static class_1113 createEntityBoundInstance(class_1297 entity, class_3414 soundEvent, class_3419 source,
                                                           float volume, float pitch) {
        return new class_1106(soundEvent, source, volume, pitch, entity, entity.method_37908().method_8409().method_43055());
    }
}
