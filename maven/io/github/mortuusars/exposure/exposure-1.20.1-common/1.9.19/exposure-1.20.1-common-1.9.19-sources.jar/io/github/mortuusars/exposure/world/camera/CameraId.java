package io.github.mortuusars.exposure.world.camera;

import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.Exposure;
import java.util.UUID;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_4844;

public record CameraId(UUID uuid) {
    public static final Codec<CameraId> CODEC = class_4844.field_25122.xmap(CameraId::new, CameraId::uuid);

    public static CameraId create() {
        return new CameraId(UUID.randomUUID());
    }

    public static final CameraId NIL = new CameraId(class_156.field_25140);

    public static CameraId ofStack(class_1799 stack) {
        CameraId cameraId = Exposure.DataComponents.getCameraId(stack);
        return cameraId == null ? NIL : cameraId;
    }

    public boolean matches(class_1799 stack) {
        return equals(Exposure.DataComponents.getCameraId(stack));
    }

    public void toPacket(class_2540 buf) {
        buf.method_10797(uuid);
    }

    public static CameraId fromPacket(class_2540 buf) {
        return new CameraId(buf.method_10790());
    }

    @Override
    public String toString() {
        return uuid().toString();
    }
}
