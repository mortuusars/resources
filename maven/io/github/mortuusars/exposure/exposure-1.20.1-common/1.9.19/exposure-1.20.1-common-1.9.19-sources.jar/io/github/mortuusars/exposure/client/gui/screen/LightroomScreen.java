package io.github.mortuusars.exposure.client.gui.screen;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.ModWidgetSprites;
import io.github.mortuusars.exposure.client.gui.BetterImageButton;
import io.github.mortuusars.exposure.client.gui.component.CycleButton;
import io.github.mortuusars.exposure.client.gui.toast.BetterTutorialToast;
import io.github.mortuusars.exposure.client.gui.toast.ToastIcon;
import io.github.mortuusars.exposure.client.image.modifier.ImageEffect;
import io.github.mortuusars.exposure.client.image.renderable.RenderableImage;
import io.github.mortuusars.exposure.client.input.Key;
import io.github.mortuusars.exposure.client.input.KeyBindings;
import io.github.mortuusars.exposure.client.render.image.RenderCoordinates;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.util.PagingDirection;
import io.github.mortuusars.exposure.world.block.entity.Lightroom;
import io.github.mortuusars.exposure.world.block.entity.LightroomBlockEntity;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.FilmColor;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.inventory.LightroomMenu;
import io.github.mortuusars.exposure.world.item.DevelopedFilmItem;
import io.github.mortuusars.exposure.world.item.FilmRollItem;
import io.github.mortuusars.exposure.world.lightroom.PrintingMode;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1109;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_465;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_757;
import net.minecraft.class_768;
import net.minecraft.class_7919;

public class LightroomScreen extends class_465<LightroomMenu> {
    public static final class_2960 MAIN_TEXTURE = Exposure.resource("textures/gui/lightroom.png");
    public static final class_2960 FILM_OVERLAYS_TEXTURE = Exposure.resource("textures/gui/lightroom_film_overlays.png");

    public static final ModWidgetSprites PRINT_BUTTON_SPRITES = ModWidgetSprites.withPrefix(
            Exposure.resource("lightroom/print_button"),
            Exposure.resource("lightroom/print_button_disabled"),
            Exposure.resource("lightroom/print_button_highlighted"),22,22);

    public static final ModWidgetSprites PRINTING_MODE_TOGGLE_REGULAR_SPRITES = ModWidgetSprites.withPrefix(
            Exposure.resource("lightroom/printing_mode_regular"),
            Exposure.resource("lightroom/printing_mode_regular_highlighted"),18,18);

    public static final ModWidgetSprites PRINTING_MODE_TOGGLE_CHROMATIC_SPRITES = ModWidgetSprites.withPrefix(
            Exposure.resource("lightroom/printing_mode_chromatic"),
            Exposure.resource("lightroom/printing_mode_chromatic_highlighted"),18,18);

    public static final int FRAME_SIZE = 54;

    protected final KeyBindings keyBindings = KeyBindings.of(
            Key.press(class_3675.field_31933).or(Key.press(class_3675.field_31937)).executes(this::enterFrameInspectMode),
            Key.press(class_3675.field_31983).or(Key.press(class_3675.field_32015)).executes(() -> changeFrame(PagingDirection.PREVIOUS)),
            Key.press(class_3675.field_31984).or(Key.press(class_3675.field_32018)).executes(() -> changeFrame(PagingDirection.NEXT))
    );

    protected class_1657 player;
    protected class_4185 printButton;
    protected PrintingMode mode;
    protected CycleButton<PrintingMode> printingModeToggleButton;

    protected Map<Integer, class_768> slotPlaceholders = Collections.emptyMap();

    protected boolean hasShownDevelopingToast;

    public LightroomScreen(LightroomMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
        this.player = playerInventory.field_7546;

        this.mode = method_17577().getBlockEntity().getActualPrintingMode();
    }

    @Override
    protected void method_25426() {
        field_2792 = 176;
        field_2779 = 209;
        super.method_25426();
        field_25270 = 116;

        slotPlaceholders = Map.of(
                Lightroom.FILM_SLOT, new class_768(238, 0, 18, 18),
                Lightroom.PAPER_SLOT, new class_768(238, 18, 18, 18),
                Lightroom.CYAN_SLOT, new class_768(238, 36, 18, 18),
                Lightroom.MAGENTA_SLOT, new class_768(238, 54, 18, 18),
                Lightroom.YELLOW_SLOT, new class_768(238, 72, 18, 18),
                Lightroom.BLACK_SLOT, new class_768(238, 90, 18, 18)
        );

        printButton = new BetterImageButton(field_2776 + 117, field_2800 + 89, 22, 22, PRINT_BUTTON_SPRITES,
                button -> {
                    int buttonId = class_437.method_25442() && player.method_7337() ? LightroomMenu.PRINT_CREATIVE_BUTTON_ID : LightroomMenu.PRINT_BUTTON_ID;
                    clickButton(buttonId);
                }, class_2561.method_43471("gui.exposure.lightroom.print"));
        updatePrintButtonTooltip();

        method_37063(printButton);

        printingModeToggleButton = createPrintingModeToggleButton();
        method_37063(printingModeToggleButton);

        updateButtons();
    }

    protected void updatePrintButtonTooltip() {
        class_5250 tooltip = class_2561.method_43471("gui.exposure.lightroom.print");
        if (!method_17577().getBlockEntity().hasSufficientLightLevel()) {
            tooltip.method_27693("\n")
                    .method_10852(class_2561.method_43471("gui.exposure.lightroom.print.not_enough_light_tooltip").method_27692(class_124.field_1061));
        }

        if (player.method_7337()) {
            tooltip.method_27693("\n")
                    .method_10852(class_2561.method_43471("gui.exposure.lightroom.print.creative_tooltip"));
        }

        printButton.method_47400(class_7919.method_47407(tooltip));
    }

    protected CycleButton<PrintingMode> createPrintingModeToggleButton() {
        Map<PrintingMode,ModWidgetSprites> spritesMap = Map.of(PrintingMode.REGULAR, PRINTING_MODE_TOGGLE_REGULAR_SPRITES,
                PrintingMode.CHROMATIC, PRINTING_MODE_TOGGLE_CHROMATIC_SPRITES);
        Map<PrintingMode, class_7919> tooltipMap = Map.of(
                PrintingMode.REGULAR, class_7919.method_47407(class_2561.method_43471("gui.exposure.lightroom.printing_mode.regular")
                        .method_10852(class_5244.field_33849)
                        .method_10852(class_2561.method_43471("gui.exposure.lightroom.printing_mode.regular.info").method_27692(class_124.field_1080))),
                PrintingMode.CHROMATIC, class_7919.method_47407(class_2561.method_43471("gui.exposure.lightroom.printing_mode.chromatic")
                        .method_10852(class_5244.field_33849)
                        .method_10852(class_2561.method_43471("gui.exposure.lightroom.printing_mode.chromatic.info").method_27692(class_124.field_1080))));
        return new CycleButton<>(field_2776 - 17, field_2800 + 91, 18, 18,
                Arrays.asList(PrintingMode.values()), method_17577().getBlockEntity().getActualPrintingMode(),
                spritesMap, (button, newMode) -> clickButton(LightroomMenu.TOGGLE_PROCESS_BUTTON_ID))
                .setClickSound(class_3417.field_15015.comp_349())
                .setTooltips(tooltipMap);
    }

    protected void clickButton(int buttonId) {
        method_17577().method_7604(player, buttonId);
        Minecrft.gameMode().method_2900(method_17577().field_7763, buttonId);
    }

    @Override
    protected void method_37432() {
        PrintingMode currentMode = method_17577().getBlockEntity().getActualPrintingMode();
        if (currentMode != printingModeToggleButton.getCurrentValue()) {
            printingModeToggleButton.setCurrentValue(currentMode);
        }
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        updateButtons();
        method_25420(guiGraphics);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        method_2380(guiGraphics, mouseX, mouseY);
    }

    protected void updateButtons() {
        printButton.field_22763 = method_17577().getBlockEntity().canPrint() || (player.method_7337() && class_437.method_25442() && method_17577().getBlockEntity().canPrintInCreativeMode());
        printButton.field_22764 = !method_17577().isPrinting();
        updatePrintButtonTooltip();

        printingModeToggleButton.field_22763 = true;
        printingModeToggleButton.field_22764 = method_17577().canChangeProcess();
    }

    @Override
    protected void method_2389(@NotNull class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.method_25302(MAIN_TEXTURE, field_2776, field_2800, 0, 0, field_2792, field_2779);
        guiGraphics.method_25302(MAIN_TEXTURE, field_2776 - 27, field_2800 + 35, 0, 209, 28, 31);

        renderSlotPlaceholders(guiGraphics, mouseX, mouseY, partialTick);

        if (method_17577().isPrinting()) {
            int progress = method_17577().getData().method_17390(LightroomBlockEntity.CONTAINER_DATA_PROGRESS_ID);
            int time = method_17577().getData().method_17390(LightroomBlockEntity.CONTAINER_DATA_PRINT_TIME_ID);
            int width = progress != 0 && time != 0 ? progress * 24 / time : 0;
            guiGraphics.method_25302(MAIN_TEXTURE, field_2776 + 116, field_2800 + 91, 176, 0, width, 17);
        }

        List<Frame> frames = method_17577().getExposedFrames();
        if (frames.isEmpty()) {
            guiGraphics.method_25302(FILM_OVERLAYS_TEXTURE, field_2776 + 4, field_2800 + 15, 0, 136, 168, 68);
            return;
        }

        class_1799 filmStack = method_17577().method_7611(Lightroom.FILM_SLOT).method_7677();
        if (!(filmStack.method_7909() instanceof DevelopedFilmItem film))
            return;

        ExposureType exposureType = film.getType();
        FilmColor filmColor = exposureType.getFilmColor();

        int selectedFrame = method_17577().getSelectedFrame();
        @Nullable Frame leftFrame = method_17577().getFrameByIndex(selectedFrame - 1);
        @Nullable Frame centerFrame = method_17577().getFrameByIndex(selectedFrame);
        @Nullable Frame rightFrame = method_17577().getFrameByIndex(selectedFrame + 1);

        RenderSystem.setShaderColor(filmColor.r(), filmColor.g(), filmColor.b(), filmColor.a());

        // Left film part
        guiGraphics.method_25302(FILM_OVERLAYS_TEXTURE, field_2776 + 1, field_2800 + 15, 0, leftFrame != null ? 68 : 0, 54, 68);
        // Center film part
        guiGraphics.method_25302(FILM_OVERLAYS_TEXTURE, field_2776 + 55, field_2800 + 15, 55, rightFrame != null ? 0 : 68, 64, 68);
        // Right film part
        if (rightFrame != null) {
            boolean hasMoreFrames = selectedFrame + 2 < frames.size();
            guiGraphics.method_25302(FILM_OVERLAYS_TEXTURE, field_2776 + 119, field_2800 + 15, 120, hasMoreFrames ? 68 : 0, 56, 68);
        }

        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        class_4587 poseStack = guiGraphics.method_51448();

        if (leftFrame != null)
            renderFrame(leftFrame, poseStack, field_2776 + 6, field_2800 + 22, FRAME_SIZE, isOverLeftFrame(mouseX, mouseY) ? 0.8f : 0.25f, exposureType);
        if (centerFrame != null)
            renderFrame(centerFrame, poseStack, field_2776 + 61, field_2800 + 22, FRAME_SIZE, 0.9f, exposureType);
        if (rightFrame != null)
            renderFrame(rightFrame, poseStack, field_2776 + 116, field_2800 + 22, FRAME_SIZE, isOverRightFrame(mouseX, mouseY) ? 0.8f : 0.25f, exposureType);

        RenderSystem.setShaderColor(filmColor.r(), filmColor.g(), filmColor.b(), filmColor.a());

        if (method_17577().getBlockEntity().isAdvancingFrameOnPrint()) {
            poseStack.method_22903();
            poseStack.method_46416(0, 0, 800);

            if (selectedFrame < method_17577().getTotalFramesCount() - 1) {
                // Advance Arrow
                guiGraphics.method_25302(MAIN_TEXTURE, field_2776 + 111, field_2800 + 44, 200, 0, 10, 10);
            } else {
                // Eject Arrow
                guiGraphics.method_25302(MAIN_TEXTURE, field_2776 + 111, field_2800 + 44, 210, 0, 10, 10);
            }

            poseStack.method_22909();
        }

        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    private void renderSlotPlaceholders(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        for (int slotIndex : slotPlaceholders.keySet()) {
            class_1735 slot = method_17577().method_7611(slotIndex);
            if (!slot.method_7681()) {
                class_768 placeholder = slotPlaceholders.get(slotIndex);
                guiGraphics.method_25302(MAIN_TEXTURE, field_2776 + slot.field_7873 - 1, field_2800 + slot.field_7872 - 1,
                        placeholder.method_3321(), placeholder.method_3322(), placeholder.method_3319(), placeholder.method_3320());
            }
        }
    }

    @Override
    protected void method_2380(@NotNull class_332 guiGraphics, int mouseX, int mouseY) {
        super.method_2380(guiGraphics, mouseX, mouseY);

        boolean advancedTooltips = class_310.method_1551().field_1690.field_1827;
        int selectedFrame = method_17577().getSelectedFrame();
        List<class_2561> tooltipLines = new ArrayList<>();

        int hoveredFrameIndex = -1;

        if (isOverLeftFrame(mouseX, mouseY)) {
            hoveredFrameIndex = selectedFrame - 1;
            tooltipLines.add(class_2561.method_43471("gui.exposure.lightroom.previous_frame"));
        } else if (isOverCenterFrame(mouseX, mouseY)) {
            hoveredFrameIndex = selectedFrame;
            tooltipLines.add(class_2561.method_43469("gui.exposure.lightroom.current_frame", Integer.toString(method_17577().getSelectedFrame() + 1)));
        } else if (isOverRightFrame(mouseX, mouseY)) {
            hoveredFrameIndex = selectedFrame + 1;
            tooltipLines.add(class_2561.method_43471("gui.exposure.lightroom.next_frame"));
        }

        if (hoveredFrameIndex != -1) {
            addFrameInfoTooltipLines(tooltipLines, hoveredFrameIndex, advancedTooltips);
        }

        if (isOverCenterFrame(mouseX, mouseY)) {
            tooltipLines.add(class_2561.method_43471("gui.exposure.lightroom.zoom_in.tooltip"));
        }

        guiGraphics.method_51437(class_310.method_1551().field_1772, tooltipLines, Optional.empty(), mouseX, mouseY);
    }

    private void addFrameInfoTooltipLines(List<class_2561> tooltipLines, int frameIndex, boolean isAdvancedTooltips) {
        @Nullable Frame frame = method_17577().getFrameByIndex(frameIndex);
        if (frame != null) {
            if (method_17577().getBlockEntity().isRefracted()) {
                frame.getColorChannel().ifPresent(c ->
                        tooltipLines.add(class_2561.method_43471("gui.exposure.channel." + c.method_15434())
                            .method_27696(class_2583.field_24360.method_36139(c.getRepresentationColor()))));
            }

            if (isAdvancedTooltips) {
                class_2561 component = frame.identifier().map(
                                id -> !id.isEmpty() ? class_2561.method_43469("gui.exposure.frame.id",
                                        class_2561.method_43470(id).method_27692(class_124.field_1080)) : class_2561.method_43473(),
                                texture -> class_2561.method_43469("gui.exposure.frame.texture",
                                        class_2561.method_43470(texture.toString()).method_27692(class_124.field_1080)))
                        .method_27692(class_124.field_1063);
                tooltipLines.add(component);
            }
        }
    }

    private boolean isOverLeftFrame(int mouseX, int mouseY) {
        List<Frame> frames = method_17577().getExposedFrames();
        int selectedFrame = method_17577().getSelectedFrame();
        return selectedFrame - 1 >= 0 && selectedFrame - 1 < frames.size() && method_2378(6, 22, FRAME_SIZE, FRAME_SIZE, mouseX, mouseY);
    }

    private boolean isOverCenterFrame(int mouseX, int mouseY) {
        List<Frame> frames = method_17577().getExposedFrames();
        int selectedFrame = method_17577().getSelectedFrame();
        return selectedFrame >= 0 && selectedFrame < frames.size() && method_2378(61, 22, FRAME_SIZE, FRAME_SIZE, mouseX, mouseY);
    }

    private boolean isOverRightFrame(int mouseX, int mouseY) {
        List<Frame> frames = method_17577().getExposedFrames();
        int selectedFrame = method_17577().getSelectedFrame();
        return selectedFrame + 1 >= 0 && selectedFrame + 1 < frames.size() && method_2378(116, 22, FRAME_SIZE, FRAME_SIZE, mouseX, mouseY);
    }

    public void renderFrame(@NotNull Frame frame, class_4587 poseStack,
                            float x, float y, float size, float alpha, ExposureType exposureType) {
        RenderableImage image = ExposureClient.renderedExposures().getOrCreate(frame).modifyWith(ImageEffect.NEGATIVE_FILM);

        class_4597.class_4598 bufferSource = class_310.method_1551().method_22940().method_23000();
        ExposureClient.imageRenderer().render(image, poseStack, bufferSource, new RenderCoordinates(x, y, size, size),
                exposureType.getImageColor().withAlpha((int) (alpha * 255)));
        bufferSource.method_22993();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        return keyBindings.keyPressed(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        return keyBindings.keyReleased(keyCode, scanCode, modifiers) || super.method_16803(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY,  double scrollY) {
        boolean handled = super.method_25401(mouseX, mouseY, scrollY);

        if (!handled) {
            if (scrollY >= 0.0 && isOverCenterFrame((int) mouseX, (int) mouseY)) // Scroll Up
                enterFrameInspectMode();
        }

        return handled;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            class_1735 filmSlot = method_17577().method_7611(Lightroom.FILM_SLOT);
            if (!hasShownDevelopingToast && !filmSlot.method_7681()
                    && method_2378(filmSlot.field_7873, filmSlot.field_7872, 16, 16, mouseX, mouseY)
                    && method_17577().method_34255().method_7909() instanceof FilmRollItem) {
                Minecrft.get().method_1566().method_1999(new BetterTutorialToast(ToastIcon.HEADS_UP,
                        class_2561.method_43471("gui.exposure.lightroom.toast.develop_film.title"),
                        null, BetterTutorialToast.DEFAULT_SHOW_DURATION_MS));
                hasShownDevelopingToast = true;
            }

            if (isOverCenterFrame((int) mouseX, (int) mouseY)) {
                enterFrameInspectMode();
                return true;
            }

            if (isOverLeftFrame((int) mouseX, (int) mouseY)) {
                changeFrame(PagingDirection.PREVIOUS);
                return true;
            }

            if (isOverRightFrame((int) mouseX, (int) mouseY)) {
                changeFrame(PagingDirection.NEXT);
                return true;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    public void changeFrame(PagingDirection navigation) {
        if ((navigation == PagingDirection.PREVIOUS && method_17577().getSelectedFrame() == 0)
                || (navigation == PagingDirection.NEXT && method_17577().getSelectedFrame() == method_17577().getTotalFramesCount() - 1)) {
            return;
        }

        Preconditions.checkState(field_22787 != null);
        Preconditions.checkState(field_22787.field_1724 != null);
        Preconditions.checkState(field_22787.field_1761 != null);
        int buttonId = navigation == PagingDirection.NEXT ? LightroomMenu.NEXT_FRAME_BUTTON_ID : LightroomMenu.PREVIOUS_FRAME_BUTTON_ID;
        clickButton(buttonId);
        Minecrft.get().method_1483().method_4873(class_1109.method_4757(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(),
                1f, ThreadLocalRandom.current().nextFloat() * 0.4f + 0.8f));

        // Update block entity clientside to faster update advance frame arrows:
        method_17577().getBlockEntity().setSelectedFrameIndex(method_17577().getBlockEntity().getSelectedFrameIndex() + (navigation == PagingDirection.NEXT ? 1 : -1));
    }

    private void enterFrameInspectMode() {
        class_310.method_1551().method_1507(new LightroomFrameInspectScreen(this));
        player.method_5783(Exposure.SoundEvents.CAMERA_LENS_RING_CLICK.get(), 1f, 1.3f);
    }

    @Override
    protected boolean method_2381(double mouseX, double mouseY, int guiLeft, int guiTop, int mouseButton) {
        return super.method_2381(mouseX, mouseY, guiLeft, guiTop, mouseButton)
                && field_2787 == null;
    }
}
