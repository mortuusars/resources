package io.github.mortuusars.exposure.mixin;

import io.github.mortuusars.exposure.Config;
import org.spongepowered.asm.mixin.Debug;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Collection;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_1847;

@Mixin(class_1844.class)
@Debug(export = true)
public abstract class PotionUtilsMixin {

    @Redirect(method = "getColor(Lnet/minecraft/world/item/ItemStack;)I",at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/alchemy/PotionUtils;getColor(Ljava/util/Collection;)I"))
    private static int customPotionColor(Collection<class_1293> effects,class_1799 stack) {
        if (Config.Common.DIFFERENT_DEVELOPING_POTION_COLORS.get()) {
            class_1842 potion = class_1844.method_8063(stack);
            if (potion == class_1847.field_8967) {
                return 0xFF424D8F;
            } else if (potion == class_1847.field_8999) {
                return 0xFF653594;
            } else if (potion == class_1847.field_8985) {
                return 0xFF3E7782;
            }
        }
        return class_1844.method_8055(effects);
    }

    @Inject(method = "getColor(Lnet/minecraft/world/item/alchemy/Potion;)I", at = @At("HEAD"), cancellable = true)
    private static void customColors(class_1842 potion, CallbackInfoReturnable<Integer> cir) {
        if (Config.Common.DIFFERENT_DEVELOPING_POTION_COLORS.get()) {
            if (potion == class_1847.field_8967) {
                cir.setReturnValue(0xFF424D8F);
            } else if (potion == class_1847.field_8999) {
                cir.setReturnValue(0xFF653594);
            } else if (potion == class_1847.field_8985) {
                cir.setReturnValue(0xFF3E7782);
            }
        }
    }
}
