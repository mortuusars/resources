package io.github.mortuusars.exposure.mixin.client;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.world.item.BrokenInterplanarProjectorItem;
import io.github.mortuusars.exposure.world.item.InterplanarProjectorItem;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_342;
import net.minecraft.class_471;
import net.minecraft.class_4894;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_471.class)
public abstract class AnvilScreenMixin extends class_4894<class_1706> {
    @Shadow private class_342 name;

    public AnvilScreenMixin(class_1706 menu, class_1661 playerInventory, class_2561 title, class_2960 menuResource) {
        super(menu, playerInventory, title, menuResource);
    }

    @Inject(method = "slotChanged", at = @At("HEAD"))
    private void onSlotChanged(class_1703 containerToSend, int dataSlotIndex, class_1799 stack, CallbackInfo ci) {
        if (dataSlotIndex == 0 && Config.Server.INTERPLANAR_PROJECTOR_LARGER_RENAMING_LIMIT.get()) {
            int maxLength = stack.method_7909() instanceof InterplanarProjectorItem || stack.method_7909() instanceof BrokenInterplanarProjectorItem ? 150 : 50;
            this.name.method_1880(maxLength);
        }
    }
}
