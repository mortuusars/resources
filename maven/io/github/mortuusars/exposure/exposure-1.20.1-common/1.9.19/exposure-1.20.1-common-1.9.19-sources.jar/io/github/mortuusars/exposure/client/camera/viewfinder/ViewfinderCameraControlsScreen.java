package io.github.mortuusars.exposure.client.camera.viewfinder;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ModWidgetSprites;
import io.github.mortuusars.exposure.client.gui.Widgets;
import io.github.mortuusars.exposure.client.gui.component.CycleButton;
import io.github.mortuusars.exposure.client.gui.screen.camera.button.FocalLengthButton;
import io.github.mortuusars.exposure.client.gui.screen.camera.button.FrameCounterButton;
import io.github.mortuusars.exposure.client.gui.screen.camera.button.ShutterSpeedButton;
import io.github.mortuusars.exposure.client.input.KeyboardHandler;
import io.github.mortuusars.exposure.client.input.MouseHandler;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.client.util.ZoomDirection;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.serverbound.ActiveCameraReleaseC2SP;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.camera.component.*;
import io.github.mortuusars.exposure.world.item.camera.CameraSettings;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7919;
import net.minecraft.class_8208;

public class ViewfinderCameraControlsScreen extends class_437 {
    public static final ModWidgetSprites SHUTTER_SPEED_SPRITES = ModWidgetSprites.withPrefix(
            Exposure.resource("camera_controls/shutter_speed_dial"),
            Exposure.resource("camera_controls/shutter_speed_dial_disabled"),
            Exposure.resource("camera_controls/shutter_speed_dial_highlighted"),69,12);

    public static final ModWidgetSprites FOCAL_LENGTH_SPRITES = ModWidgetSprites.withPrefix(
            Exposure.resource("camera_controls/focal_length"),
            Exposure.resource("camera_controls/focal_length_disabled"),
            Exposure.resource("camera_controls/focal_length_highlighted"),49,18);

    public static final ModWidgetSprites FRAME_COUNTER_SPRITES = ModWidgetSprites.withPrefix(
            Exposure.resource("camera_controls/frame_counter"),
            Exposure.resource("camera_controls/frame_counter_disabled"),
            Exposure.resource("camera_controls/frame_counter_highlighted"),49,18);

    public static final class_2960 SEPARATOR_SPRITE = Exposure.resource("textures/gui/sprites/camera_controls/button_separator.png");

    protected static final int SEPARATOR_WIDTH = 1;
    protected static final int BUTTON_HEIGHT = 18;
    protected static final int SIDE_BUTTONS_WIDTH = 49;
    protected static final int BUTTON_WIDTH = 15;

    protected final Camera camera;
    protected final Viewfinder viewfinder;
    protected final long openedAt;

    protected int leftPos;
    protected int topPos;

    public ViewfinderCameraControlsScreen(Camera camera, Viewfinder viewfinder) {
        super(class_5244.field_39003);
        this.camera = camera;
        this.viewfinder = viewfinder;
        this.openedAt = Minecrft.level().method_8510();
    }

    public Camera getCamera() {
        return camera;
    }

    public Viewfinder getViewfinder() {
        return viewfinder;
    }

    // --

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25393() {
        refreshMovementKeys();
        class_310.method_1551().method_1508();
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        refreshMovementKeys();

        leftPos = (field_22789 - 256) / 2;
        topPos = Math.round(viewfinder.overlay().getOpening().y + viewfinder.overlay().getOpening().height - 256);

        boolean hasFlash = camera.map((i, s) -> i.getFlash().isAvailable(s)).orElse(false);

        int elementX = leftPos + 128 - (SIDE_BUTTONS_WIDTH + 1 + BUTTON_WIDTH + 1 + BUTTON_WIDTH + 1 + (hasFlash ? BUTTON_WIDTH + 1 : 0) + SIDE_BUTTONS_WIDTH) / 2;
        int elementY = topPos + 238;

        // Order of adding influences TAB key behavior

        class_4185 shutterSpeedButton = createShutterSpeedButton();
        method_37063(shutterSpeedButton);

        FocalLengthButton focalLengthButton = new FocalLengthButton(elementX, elementY, SIDE_BUTTONS_WIDTH, BUTTON_HEIGHT, FOCAL_LENGTH_SPRITES);
        focalLengthButton.method_47400(class_7919.method_47407(class_2561.method_43471("gui.exposure.camera_controls.focal_length.tooltip")));
        method_37060(focalLengthButton);
        elementX += focalLengthButton.method_25368();

        addSeparator(elementX, elementY);
        elementX += SEPARATOR_WIDTH;

        class_4185 compositionGuideButton = createCompositionGuideButton();
        compositionGuideButton.method_46421(elementX);
        compositionGuideButton.method_46419(elementY);
        method_37063(compositionGuideButton);
        elementX += compositionGuideButton.method_25368();

        addSeparator(elementX, elementY);
        elementX += SEPARATOR_WIDTH;

        class_4185 selfTimerButton = createSelfTimerButton();
        selfTimerButton.method_46421(elementX);
        selfTimerButton.method_46419(elementY);
        method_37063(selfTimerButton);
        elementX += selfTimerButton.method_25368();

        addSeparator(elementX, elementY);
        elementX += SEPARATOR_WIDTH;

        if (hasFlash) {
            class_4185 flashModeButton = createFlashModeButton();
            flashModeButton.method_46421(elementX);
            flashModeButton.method_46419(elementY);
            method_37063(flashModeButton);
            elementX += flashModeButton.method_25368();

            addSeparator(elementX, elementY);
            elementX += SEPARATOR_WIDTH;
        }

        FrameCounterButton frameCounterButton = new FrameCounterButton(elementX, elementY, SIDE_BUTTONS_WIDTH, BUTTON_HEIGHT, FRAME_COUNTER_SPRITES);
        method_37060(frameCounterButton);
    }

    protected @NotNull class_4185 createShutterSpeedButton() {
        List<ShutterSpeed> shutterSpeeds = camera.map((item, stack) -> item.getAvailableShutterSpeeds(), List.of(ShutterSpeed.DEFAULT));
        ShutterSpeed currentShutterSpeed = camera.map(CameraSettings.SHUTTER_SPEED::getOrDefault, ShutterSpeed.DEFAULT);

        return new ShutterSpeedButton(leftPos + 94, topPos + 226, 69, 12, shutterSpeeds,
                currentShutterSpeed, speed -> SHUTTER_SPEED_SPRITES)
                .setDefaultTooltip(class_7919.method_47407(class_2561.method_43471("gui.exposure.camera_controls.shutter_speed.tooltip")))
                .onCycle(speed -> CameraSettings.SHUTTER_SPEED.setAndSync(camera, speed));
    }

    protected @NotNull class_4185 createCompositionGuideButton() {
        List<CompositionGuide> guides = CompositionGuides.getGuides();
        CompositionGuide currentGuide = camera.map(CameraSettings.COMPOSITION_GUIDE::getOrDefault, CompositionGuides.NONE);
        Function<CompositionGuide, ModWidgetSprites> spritesFunc = guide ->
              Widgets.threeStateSprites(guide.buttonSpriteLocation(), 15, 18);

        return new CycleButton<>(0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, guides, currentGuide, spritesFunc)
                .setDefaultTooltip(class_7919.method_47407(class_2561.method_43471("gui.exposure.camera_controls.composition_guide.tooltip")))
                .setTooltips(guide -> class_2561.method_43471("gui.exposure.camera_controls.composition_guide.tooltip")
                        .method_10852(class_5244.field_33849)
                        .method_10852(guide.translate().method_27692(class_124.field_1080)))
                .onCycle(guide -> CameraSettings.COMPOSITION_GUIDE.setAndSync(camera, guide));
    }

    protected @NotNull class_4185 createSelfTimerButton() {
        List<SelfTimer> values = Arrays.asList(SelfTimer.values());
        SelfTimer currentValue = camera.map(CameraSettings.SELF_TIMER::getOrDefault, SelfTimer.OFF);
        Function<SelfTimer, ModWidgetSprites> spritesFunc = mode ->
              Widgets.threeStateSprites(Exposure.resource("camera_controls/self_timer/timer_" + mode.method_15434()), 15, 18);

        return new CycleButton<>(0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, values, currentValue, spritesFunc)
                .setDefaultTooltip(class_7919.method_47407(class_2561.method_43471("gui.exposure.camera_controls.self_timer.tooltip")))
                .setTooltips(mode -> class_2561.method_43471("gui.exposure.camera_controls.self_timer.tooltip")
                        .method_10852(class_5244.field_33849)
                        .method_10852(mode.translate().method_27692(class_124.field_1080)))
                .onCycle(value -> CameraSettings.SELF_TIMER.setAndSync(camera, value));
    }

    protected @NotNull class_4185 createFlashModeButton() {
        List<FlashMode> modes = Arrays.asList(FlashMode.values());
        FlashMode currentMode = camera.map(CameraSettings.FLASH_MODE::getOrDefault, FlashMode.OFF);
        Function<FlashMode, ModWidgetSprites> spritesFunc = mode ->
              Widgets.threeStateSprites(Exposure.resource("camera_controls/flash_mode/flash_" + mode.method_15434()), 15, 18);

        return new CycleButton<>(0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, modes, currentMode, spritesFunc)
                .setDefaultTooltip(class_7919.method_47407(class_2561.method_43471("gui.exposure.camera_controls.flash_mode.tooltip")))
                .setTooltips(mode -> class_2561.method_43471("gui.exposure.camera_controls.flash_mode.tooltip")
                        .method_10852(class_5244.field_33849)
                        .method_10852(mode.translate().method_27692(class_124.field_1080)))
                .onCycle(mode -> CameraSettings.FLASH_MODE.setAndSync(camera, mode));
    }

    protected void addSeparator(int x, int y) {
        class_8208 sprite = new class_8208(SEPARATOR_WIDTH, BUTTON_HEIGHT, SEPARATOR_SPRITE);
        sprite.method_46421(x);
        sprite.method_46419(y);
        method_37060(sprite);
    }

    /**
     * When screen is opened - all keys are released. If we do not refresh them - player would stop moving (if they had).
     */
    protected void refreshMovementKeys() {
        Consumer<class_304> update = keyMapping -> {
            if (keyMapping.field_1655.method_1442() == class_3675.class_307.field_1672) {
                keyMapping.method_23481(MouseHandler.isMouseButtonHeld(keyMapping.field_1655.method_1444()));
            } else {
                long windowId = class_310.method_1551().method_22683().method_4490();
                keyMapping.method_23481(class_3675.method_15987(windowId, keyMapping.field_1655.method_1444()));
            }
        };

        update.accept(KeyboardHandler.getCameraControlsKey());
        class_315 opt = Minecrft.options();
        update.accept(opt.field_1894);
        update.accept(opt.field_1881);
        update.accept(opt.field_1913);
        update.accept(opt.field_1849);
        update.accept(opt.field_1903);
        update.accept(opt.field_1867);
    }

    @Override
    public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (!viewfinder.isLookingThrough()) {
            this.method_25419();
            return;
        }

        if (Minecrft.options().field_1842) return;

        guiGraphics.method_51448().method_22903();

        float viewfinderScale = viewfinder.overlay().getScale();
        if (viewfinderScale != 1.0f) {
            guiGraphics.method_51448().method_46416(field_22789 / 2f, field_22790 / 2f, 0);
            guiGraphics.method_51448().method_22905(viewfinderScale, viewfinderScale, viewfinderScale);
            guiGraphics.method_51448().method_46416(-field_22789 / 2f, -field_22790 / 2f, 0);
        }

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        guiGraphics.method_51448().method_22909();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (super.method_25402(mouseX, mouseY, button)) return true;

        if (button == class_3675.field_32002) {
            if (camera.isActive()) {
                camera.release();
                Packets.sendToServer(ActiveCameraReleaseC2SP.INSTANCE);
            }
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (KeyboardHandler.getCameraControlsKey().method_1433(button)
                || (Config.Client.VIEWFINDER_MIDDLE_CLICK_CONTROLS.get() && button == class_3675.field_32001)) {
            if (isToggleTimeReached()) {
                this.method_25419();
            }

            return false;
        }

        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (super.method_25403(mouseX, mouseY, button, dragX, dragY)) return true;

        if (button != class_3675.field_32000) return false;

        if (camera.inSelfieMode() && Minecrft.options().field_1867.field_1653) {
            // Parameters are correct. Stop nagging me, Intellij
            //noinspection SuspiciousNameCombination
            viewfinder.selfie.rotateCamera(dragY, dragX, true);
            return true;
        }

        // Dragging the view with mouse:
        double fov = viewfinder.zoom().getCurrentFov();
        int windowWidth = Minecrft.get().method_22683().method_4506();
        int windowHeight = Minecrft.get().method_22683().method_4506();
        double xRot = (dragY / windowHeight) * fov;
        double yRot = (dragX / windowWidth) * (fov * ((double) windowHeight / windowWidth));
        Minecrft.player().method_5872(-yRot * 20, -xRot * 20);

        return true;
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        if (KeyboardHandler.getCameraControlsKey().method_1417(keyCode, scanCode)) {
            if (isToggleTimeReached())
                this.method_25419();

            return false;
        }

        return super.method_16803(keyCode, scanCode, modifiers);
    }

    protected boolean isToggleTimeReached() {
        return Minecrft.level().method_8510() - openedAt >= 5;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (super.method_25404(keyCode, scanCode, modifiers)) return true;

        if (keyCode == class_3675.field_31933 || keyCode == class_3675.field_31937) {
            viewfinder.zoom().zoom(ZoomDirection.IN, true);
            return true;
        } else if (keyCode == 333 /*KEY_SUBTRACT*/ || keyCode == class_3675.field_31941) {
            viewfinder.zoom().zoom(ZoomDirection.OUT, true);
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollY) {
        if (!super.method_25401(mouseX, mouseY,  scrollY)) {
            viewfinder.zoom().zoom(scrollY > 0d ? ZoomDirection.IN : ZoomDirection.OUT, true);
            return true;
        }

        return false;
    }
}
