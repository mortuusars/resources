package io.github.mortuusars.exposure.client.gui.screen.test;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Pair;
import io.github.mortuusars.exposure.client.util.Minecrft;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.text.DecimalFormat;
import java.util.function.Consumer;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4588;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_8015;
import net.minecraft.class_8494;

public class Slider extends class_339 {
    public static final class_2960 SLIDER_SPRITE = new class_2960("widget/slider");
    public static final class_2960 HIGHLIGHTED_SPRITE = new class_2960("widget/slider_highlighted");
    public static final class_2960 SLIDER_HANDLE_SPRITE = new class_2960("widget/slider_handle");
    public static final class_2960 SLIDER_HANDLE_HIGHLIGHTED_SPRITE = new class_2960("widget/slider_handle_highlighted");

    protected static final int TEXT_MARGIN = 2;
    protected static final int HANDLE_WIDTH = 8;
    protected static final int HANDLE_HALF_WIDTH = 4;

    protected double position;
    protected boolean canChangeValue;

    protected final double defaultValue;
    protected final double min;
    protected final double max;
    protected final DecimalFormat displayFormat;
    protected final String name;
    protected final Consumer<Double> onChanged;

    @Nullable
    protected Pair<Integer, Integer> horizontalGradient;

    public Slider(int x, int y, int width, int height,
                  double defaultValue, double min, double max, int displayedPrecision, String name, Consumer<Double> onChanged) {
        this(x, y, width, height, class_5244.field_39003, defaultValue, min, max, displayedPrecision, name, onChanged);
    }

    public Slider(int x, int y, int width, int height, class_2561 message,
                  double defaultValue, double min, double max, int displayedPrecision, String name, Consumer<Double> onChanged) {
        super(x, y, width, height, message);
        this.position = (defaultValue - min) / (max - min);
        this.defaultValue = class_3532.method_15350(defaultValue, min, max);
        this.min = min;
        this.max = max;
        String zeros = "#".repeat(displayedPrecision);
        this.displayFormat = new DecimalFormat("#" + (zeros.isEmpty() ? "" : "." + zeros));
        this.name = name;
        this.onChanged = onChanged;
        updateMessage();
    }

    public Slider setHorizontalGradient(int leftColor, int rightColor) {
        this.horizontalGradient = Pair.of(leftColor, rightColor);
        return this;
    }

    public void removeHorizontalGradient() {
        this.horizontalGradient = null;
    }

    protected class_2960 getSprite() {
        return this.method_25370() && !this.canChangeValue ? HIGHLIGHTED_SPRITE : SLIDER_SPRITE;
    }

    protected class_2960 getHandleSprite() {
        return !this.field_22762 && !this.canChangeValue ? SLIDER_HANDLE_SPRITE : SLIDER_HANDLE_HIGHLIGHTED_SPRITE;
    }

    // -- Value

    public double getPosition() {
        return this.position;
    }

    public void setPosition(double position) {
        double d = this.position;
        this.position = class_3532.method_15350(position, 0.0, 1.0);
        if (d != this.position) {
            this.applyValue();
        }

        this.updateMessage();
    }

    public Double getValue() {
        return class_3532.method_15390(min, max, position);
    }

    public void setValue(double value) {
        double positionFromValue = (value - min) / (max - min);
        setPosition(positionFromValue);
    }

    public void resetToDefault() {
        setValue(defaultValue);
    }

    protected void updateMessage() {
        method_25355(class_2561.method_43470(name + ": " + displayFormat.format(getValue())));
    }

    protected void applyValue() {
        onChanged.accept(getValue());
    }

    // -- Input

    @Override
    public void method_25348(double mouseX, double mouseY) {
        this.setPositionFromMouse(mouseX);
    }

    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (!focused) {
            this.canChangeValue = false;
        } else {
            class_8015 inputType = class_310.method_1551().method_48186();
            if (inputType == class_8015.field_41778 || inputType == class_8015.field_41780) {
                this.canChangeValue = true;
            }
        }
    }

    protected void setPositionFromMouse(double mouseX) {
        this.setPosition((mouseX - (double)(this.method_46426() + HANDLE_HALF_WIDTH)) / (double)(this.field_22758 - HANDLE_WIDTH));
    }

    @Override
    public void method_25357(double mouseX, double mouseY) {
        super.method_25354(class_310.method_1551().method_1483());
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == class_3675.field_32002 && field_22763 && field_22764 && method_25361(mouseX, mouseY)) {
            resetToDefault();
            method_25354(Minecrft.get().method_1483());
            return true;
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    protected void method_25349(double mouseX, double mouseY, double dragX, double dragY) {
        this.setPositionFromMouse(mouseX);
        super.method_25349(mouseX, mouseY, dragX, dragY);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (class_8494.method_51255(keyCode)) {
            this.canChangeValue = !this.canChangeValue;
            return true;
        } else {
            if (this.canChangeValue) {
                boolean bl = keyCode == 263;
                if (bl || keyCode == 262) {
                    float f = bl ? -1.0F : 1.0F;
                    this.setPosition(position + (double)(f / (float)(field_22758 - HANDLE_WIDTH)));
                    return true;
                }
            }

            return false;
        }
    }

    // -- Render

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        class_310 minecraft = class_310.method_1551();
        guiGraphics.method_51422(1.0F, 1.0F, 1.0F, field_22765);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        guiGraphics.method_25302(getSprite(), method_46426(), method_46427(),0,0, method_25368(), method_25364());

        if (field_22763 && horizontalGradient != null) {
            fillHorizontalGradient(guiGraphics, method_46426() + 1, method_46427() + 1, method_46426() + method_25368() - 1,
                    method_46427() + method_25364() - 1, horizontalGradient.getFirst(), horizontalGradient.getSecond());
        }

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(0, 0, 50);

        guiGraphics.method_25302(getHandleSprite(), method_46426() + (int)(position * (double)(field_22758 - HANDLE_WIDTH)), method_46427(),0,0, HANDLE_WIDTH, method_25364());
        guiGraphics.method_51422(1.0F, 1.0F, 1.0F, 1.0F);
        int textColor = (field_22763 ? 0xFFFFFF : 0xA0A0A0) | class_3532.method_15386(field_22765 * 255.0F) << 24;
        method_49604(guiGraphics, minecraft.field_1772, TEXT_MARGIN, textColor);
        guiGraphics.method_51448().method_22909();
    }

    private void fillHorizontalGradient(class_332 guiGraphics, int x1, int y1, int x2, int y2, int colorFrom, int colorTo) {
        class_4588 consumer = guiGraphics.method_51450().getBuffer(class_1921.method_51784());
        Matrix4f matrix4f = guiGraphics.method_51448().method_23760().method_23761();
        consumer.method_22918(matrix4f, (float)x1, (float)y1, 0).method_39415(colorFrom).method_1344();
        consumer.method_22918(matrix4f, (float)x1, (float)y2, 0).method_39415(colorFrom).method_1344();
        consumer.method_22918(matrix4f, (float)x2, (float)y2, 0).method_39415(colorTo).method_1344();
        consumer.method_22918(matrix4f, (float)x2, (float)y1, 0).method_39415(colorTo).method_1344();
    }

    // --

    @Override
    protected @NotNull class_5250 method_25360() {
        return class_2561.method_43469("gui.narrate.slider", this.method_25369());
    }

    @Override
    public void method_47399(class_6382 narrationElementOutput) {
        narrationElementOutput.method_37034(class_6381.field_33788, this.method_25360());
        if (this.field_22763) {
            if (this.method_25370()) {
                narrationElementOutput.method_37034(class_6381.field_33791, class_2561.method_43471("narration.slider.usage.focused"));
            } else {
                narrationElementOutput.method_37034(class_6381.field_33791, class_2561.method_43471("narration.slider.usage.hovered"));
            }
        }
    }
}
