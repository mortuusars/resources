package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record CameraStandStopControllingS2CP(int standId) implements Packet {
    public static final class_2960 ID = Exposure.resource("camera_stand_stop_controlling");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.writeInt(standId);
    }

    public static CameraStandStopControllingS2CP fromPacket(class_2540 buf) {
        return new CameraStandStopControllingS2CP(buf.readInt());
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.stopControllingCameraStand(this);
        return true;
    }
}
