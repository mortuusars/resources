package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.handler.ClientPacketsHandler;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record ExposureDataChangedS2CP(String id) implements Packet {
    public static final class_2960 ID = Exposure.resource("exposure_data_changed");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_10814(id);
    }

    public static ExposureDataChangedS2CP fromPacket(class_2540 buf) {
        return new ExposureDataChangedS2CP(buf.method_19772());
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ClientPacketsHandler.exposureDataChanged(this);
        return true;
    }
}
