package io.github.mortuusars.exposure;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1087;
import net.minecraft.class_2960;

public class PlatformHelperClient {
    @ExpectPlatform
    public static class_1087 getModel(class_2960 model) {
        throw new AssertionError();
    }
}
