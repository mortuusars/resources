package io.github.mortuusars.exposure.util;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3542;
import net.minecraft.nbt.*;
import org.apache.logging.log4j.util.TriConsumer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;

public record NbtType<T>(String key, BiFunction<class_2487, String, @Nullable T> getter,
                         TriConsumer<class_2487, String, T> setter) {
    public static NbtType<String> string(String key) {
        return new NbtType<>(key, class_2487::method_10558, class_2487::method_10582);
    }

    public static NbtType<Boolean> bool(String key) {
        return new NbtType<>(key, class_2487::method_10577, class_2487::method_10556);
    }

    public static NbtType<Integer> intVal(String key) {
        return new NbtType<>(key, class_2487::method_10550, class_2487::method_10569);
    }

    public static NbtType<Long> longVal(String key) {
        return new NbtType<>(key, class_2487::method_10537, class_2487::method_10544);
    }

    public static NbtType<Float> floatVal(String key) {
        return new NbtType<>(key, class_2487::method_10583, class_2487::method_10548);
    }

    public static NbtType<Double> doubleVal(String key) {
        return new NbtType<>(key, class_2487::method_10574, class_2487::method_10549);
    }

    public static <T extends class_3542> NbtType<T> stringRepresentable(String key, Function<String, @Nullable T> deserializeFunction) {
        return new NbtType<>(key,
                (data, k) -> deserializeFunction.apply(data.method_10558(k)),
                (data, k, value) -> data.method_10582(k, value.method_15434()));
    }

    public static NbtType<class_243> vec3(String key) {
        return new NbtType<>(key,
                (data, k) -> {
                    class_2499 pos = data.method_10554(k, class_2489.field_33256);
                    return new class_243(pos.method_10611(0), pos.method_10611(1), pos.method_10611(2));
                },
                (data, k, value) -> {
                    class_2499 pos = new class_2499();
                    pos.add(class_2489.method_23241(value.method_10216()));
                    pos.add(class_2489.method_23241(value.method_10214()));
                    pos.add(class_2489.method_23241(value.method_10215()));
                    data.method_10566(k, pos);
                });
    }

    public static NbtType<class_2960> resourceLocation(String key) {
        return new NbtType<>(key,
                (data, k) -> new class_2960(data.method_10558(k)),
                (data, k, value) -> data.method_10582(k, value.toString()));
    }

    public static <T> NbtType<List<T>> list(String key, int tagType, Function<class_2520, T> extractFunc, Function<T, class_2520> packFunc) {
        return new NbtType<>(key,
                (data, k) -> data.method_10554(k, tagType).stream()
                        .map(extractFunc)
                        .toList(),
                (data, k, value) -> {
                    class_2499 list = new class_2499();
                    list.addAll(value.stream()
                            .map(packFunc)
                            .toList());
                    data.method_10566(k, list);
                });
    }

    public static <T> NbtType<List<T>> stringBasedList(String key, Function<String, T> extractFunc, Function<T, String> packFunc) {
        return list(key, class_2520.field_33258, tag -> extractFunc.apply(tag.method_10714()), value -> class_2519.method_23256(packFunc.apply(value)));
    }


    public static <T> Optional<T> get(class_2487 tag,@NotNull NbtType<T> type) {
        if (!tag.method_10545(type.key())) return Optional.empty();
        try {
            return Optional.ofNullable(type.getter().apply(tag, type.key()));
        } catch (Exception e) {
            Exposure.LOGGER.error("Cannot get CompoundTag entry: {}", e.getMessage());
            return Optional.empty();
        }
    }

    public static <T> void put(class_2487 tag,NbtType<T> type, @NotNull T value) {
        Preconditions.checkNotNull(value, "value");
        type.setter().accept(tag, type.key(), value);
    }

}
