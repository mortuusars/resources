package io.github.mortuusars.exposure.client.gui.screen.element.textbox;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.util.Pos2i;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3675;
import net.minecraft.class_3728;
import net.minecraft.class_437;
import net.minecraft.class_5225;
import net.minecraft.class_5244;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_768;

public class TextBox extends class_339 {
    public final class_327 font;
    public Supplier<String> textGetter;
    public Consumer<String> textSetter;
    public Predicate<String> textValidator = text -> text != null
            && getFont().method_1713(text, field_22758) + (text.endsWith("\n") ? getFont().field_2000 : 0) <= field_22759;

    public HorizontalAlignment horizontalAlignment = HorizontalAlignment.LEFT;
    public int fontColor = 0xFF000000;
    public int fontUnfocusedColor = 0xFF000000;
    public int selectionColor = 0xFF0000FF;
    public int selectionUnfocusedColor = 0x880000FF;

    public final class_3728 textFieldHelper;
    protected DisplayCache displayCache = new DisplayCache();
    protected int frameTick;
    protected long lastClickTime;
    protected int lastIndex = -1;

    public TextBox(@NotNull class_327 font, int x, int y, int width, int height,
                   Supplier<String> textGetter, Consumer<String> textSetter) {
        super(x, y, width, height, class_2561.method_43473());
        this.font = font;
        this.textGetter = textGetter;
        this.textSetter = textSetter;
        textFieldHelper = new class_3728(this::getText, this::setText,
                class_3728.method_27550(class_310.method_1551()),
                class_3728.method_27561(class_310.method_1551()),
                this::validateText);
    }

    public void tick() {
        ++frameTick;
    }

    public class_327 getFont() {
        return font;
    }

    public @NotNull String getText() {
        return textGetter.get();
    }

    public TextBox setText(@NotNull String text) {
        textSetter.accept(text);
        clearDisplayCache();
        return this;
    }

    protected boolean validateText(String text) {
        return textValidator.test(text);
    }

    public void setHeight(int height) {
        this.field_22759 = height;
        clearDisplayCache();
    }

    public int getCurrentFontColor() {
        return method_25370() ? fontColor : fontUnfocusedColor;
    }

    public TextBox setFontColor(int fontColor, int fontUnfocusedColor) {
        this.fontColor = fontColor;
        this.fontUnfocusedColor = fontUnfocusedColor;
        clearDisplayCache();
        return this;
    }

    public TextBox setFontColor(int fontColor) {
        this.fontColor = fontColor;
        this.fontUnfocusedColor = fontColor;
        clearDisplayCache();
        return this;
    }

    public TextBox setSelectionColor(int selectionColor, int selectionUnfocusedColor) {
        this.selectionColor = selectionColor;
        this.selectionUnfocusedColor = selectionUnfocusedColor;
        clearDisplayCache();
        return this;
    }

    public void setCursorToEnd() {
        textFieldHelper.method_16204();
        clearDisplayCache();
    }

    public void refresh() {
        clearDisplayCache();
    }

    protected DisplayCache getDisplayCache() {
        if (displayCache.needsRebuilding)
            displayCache.rebuild(font, getText(), textFieldHelper.method_16201(), textFieldHelper.method_16203(),
                    method_46426(), method_46427(), method_25368(), method_25364(), horizontalAlignment);
        return displayCache;
    }

    protected void clearDisplayCache() {
        displayCache.needsRebuilding = true;
    }

    protected Pos2i convertLocalToScreen(Pos2i pos) {
        return new Pos2i(method_46426() + pos.x, method_46427() + pos.y);
    }

    protected Pos2i convertScreenToLocal(Pos2i screenPos) {
        return new Pos2i(screenPos.x - method_46426(), screenPos.y - method_46427());
    }

    @Override
    protected void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        DisplayCache displayCache = this.getDisplayCache();
        for (DisplayCache.LineInfo lineInfo : displayCache.lines) {
            guiGraphics.method_51439(this.font, lineInfo.asComponent, method_46426() + lineInfo.x, method_46427() + lineInfo.y, getCurrentFontColor(), false);
        }
        this.renderHighlight(guiGraphics, displayCache.selectionAreas);
        if (method_25370())
            this.renderCursor(guiGraphics, displayCache.cursorPos, displayCache.cursorAtEnd);
    }

    protected void renderHighlight(class_332 guiGraphics, class_768[] highlightAreas) {
        for (class_768 selection : highlightAreas) {
            int x = method_46426() + selection.method_3321();
            int y = method_46427() + selection.method_3322();
            int x1 = x + selection.method_3319();
            int y1 = y + selection.method_3320();
            guiGraphics.method_51739(class_1921.method_51786(), x, y - 1, x1, y1, method_25370() ? selectionColor : selectionUnfocusedColor);
        }
    }

    protected void renderCursor(class_332 guiGraphics, Pos2i cursorPos, boolean isEndOfText) {
        if (this.frameTick / 6 % 2 == 0) {
            cursorPos = convertLocalToScreen(cursorPos);
            if (isEndOfText)
                guiGraphics.method_51433(this.font, "_", cursorPos.x, cursorPos.y, getCurrentFontColor(), false);
            else {
                guiGraphics.method_51448().method_22903();
                guiGraphics.method_51448().method_46416(0, 0, 50);
                RenderSystem.disableBlend();
                guiGraphics.method_25294(cursorPos.x, cursorPos.y - 1, cursorPos.x + 1, cursorPos.y + this.font.field_2000, getCurrentFontColor());
                guiGraphics.method_51448().method_22909();
            }
        }
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) {
        narrationElementOutput.method_37034(class_6381.field_33788, method_25360());
    }

    @Override
    public @NotNull class_2561 method_25369() {
        return class_2561.method_43470(getText());
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (!method_25370())
            return false;
        boolean handled = handleKeyPressed(keyCode, scanCode, modifiers);
        if (handled)
            clearDisplayCache();
        return handled;
    }

    protected boolean handleKeyPressed(int keyCode, int scanCode, int modifiers) {
        class_3728.class_7279 cursorStep = class_437.method_25441() ? class_3728.class_7279.field_38309 : class_3728.class_7279.field_38308;
        if (keyCode == class_3675.field_31932) {
            changeLine(-1);
            return true;
        } else if (keyCode == class_3675.field_31982) {
            changeLine(1);
            return true;
        } else if (keyCode == class_3675.field_31989) {
            keyHome();
            return true;
        } else if (keyCode == class_3675.field_31988) {
            keyEnd();
            return true;
        } else if (keyCode == class_3675.field_31986) {
            textFieldHelper.method_42574(-1, cursorStep);
            return true;
        } else if (keyCode == class_3675.field_31987) {
            textFieldHelper.method_42574(1, cursorStep);
            return true;
        } else if (keyCode == class_3675.field_31957 || keyCode == class_3675.field_31980) {
            textFieldHelper.method_16197(class_5244.field_33849.getString());
            return true;
        }

        return textFieldHelper.method_16202(keyCode);
    }

    public boolean method_25400(char codePoint, int modifiers) {
        if (!method_25370())
            return false;

        boolean typed = textFieldHelper.method_16199(codePoint);
        if (typed)
            clearDisplayCache();
        return typed;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (field_22762 && field_22764 && method_37303() && button == 0) {
            long currentTime = class_156.method_658();
            DisplayCache displayCache = getDisplayCache();
            int index = displayCache.getIndexAtPosition(font, convertScreenToLocal(new Pos2i((int) mouseX, (int) mouseY)));

            if (index >= 0) {
                if (index == lastIndex && currentTime - lastClickTime < 250L) {
                    if (!textFieldHelper.method_27568()) {
                        selectWord(index);
                    } else {
                        textFieldHelper.method_27563();
                    }
                } else {
                    textFieldHelper.method_27560(index, class_437.method_25442());
                }
                clearDisplayCache();
            }

            lastIndex = index;
            lastClickTime = currentTime;
            return true;
        }

        return false;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (button == 0) {
            DisplayCache displayCache = this.getDisplayCache();
            int index = displayCache.getIndexAtPosition(this.font, this.convertScreenToLocal(new Pos2i((int) mouseX, (int) mouseY)));
            this.textFieldHelper.method_27560(index, true);
            this.clearDisplayCache();
        }
        return true;
    }

    protected void selectWord(int index) {
        String string = this.getText();
        this.textFieldHelper.method_27548(class_5225.method_27483(string, -1, index, false),
                class_5225.method_27483(string, 1, index, false));
    }

    protected void changeLine(int yChange) {
        int cursorPos = this.textFieldHelper.method_16201();
        int line = this.getDisplayCache().changeLine(cursorPos, yChange);
        this.textFieldHelper.method_27560(line, class_437.method_25442());
    }

    protected void keyHome() {
        if (class_437.method_25441()) {
            this.textFieldHelper.method_27553(class_437.method_25442());
        } else {
            int cursorIndex = this.textFieldHelper.method_16201();
            int lineStartIndex = this.getDisplayCache().findLineStart(cursorIndex);
            this.textFieldHelper.method_27560(lineStartIndex, class_437.method_25442());
        }
    }

    protected void keyEnd() {
        if (class_437.method_25441()) {
            this.textFieldHelper.method_27558(class_437.method_25442());
        } else {
            DisplayCache displayCache = this.getDisplayCache();
            int cursorIndex = this.textFieldHelper.method_16201();
            int lineEndIndex = displayCache.findLineEnd(cursorIndex);
            this.textFieldHelper.method_27560(lineEndIndex, class_437.method_25442());
        }
    }
}
