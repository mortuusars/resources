package io.github.mortuusars.exposure.network.packet.serverbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.server.CameraInstances;
import io.github.mortuusars.exposure.util.TranslatableError;
import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record InterplanarProjectionFinishedC2SP(CameraId cameraId,
                                                boolean successful,
                                                Optional<TranslatableError> error) implements Packet {
    public static final class_2960 ID = Exposure.resource("interplanar_projection_finished");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        cameraId.toPacket(buf);
        buf.writeBoolean(successful);
        buf.method_37435(error,(buf1, translatableError) -> translatableError.toPacket(buf1));
    }

    public static InterplanarProjectionFinishedC2SP fromPacket(class_2540 buf) {
        return new InterplanarProjectionFinishedC2SP(CameraId.fromPacket(buf),buf.readBoolean(),buf.method_37436(TranslatableError::fromPacket));
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        CameraInstances.ifPresent(cameraId, cameraInstance -> cameraInstance.setProjectionResult(player.method_37908(), successful, error));
        return true;
    }
}
