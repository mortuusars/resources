package io.github.mortuusars.exposure.client.util.bugger;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import io.github.mortuusars.exposure.client.gui.screen.test.TestImageScreen;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.mixin.client.BuggerScreenRenderLinesInvoker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_437;
import net.minecraft.class_746;

public class Bugger {
    public static int page = -1;

    private static int zoom;
    private static int scroll;

    public static boolean onKeyPress(int key, int scanCode, int modifiers) {
        if (key == class_3675.field_31932) up();
        if (key == class_3675.field_31982) down();
        if (key == class_3675.field_31990) zoom = 0;
        if (key == class_3675.field_31989) scroll = 0;
        if (key == class_3675.field_31983) page = class_3532.method_15340(page - 1, -1, 1);
        if (key == class_3675.field_31984) page = class_3532.method_15340(page + 1, -1, 1);

        if (key == class_3675.field_31988) test();
        return false;
    }

    public static boolean onKeyRepeat(int key, int scanCode, int modifiers) {
        if (key == class_3675.field_31932) up();
        if (key == class_3675.field_31982) down();
        if (key == class_3675.field_31983) page = class_3532.method_15340(page - 1, -1, 1);
        if (key == class_3675.field_31984) page = class_3532.method_15340(page + 1, -1, 1);
        return false;
    }

    public static boolean onKeyRelease(int key, int scanCode, int modifiers) {
        return false;
    }

    private static void test() {
        Minecrft.get().method_1507(new TestImageScreen());
    }

    // --

    private static void up() {
        if (class_437.method_25441()) {
            boolean shift = class_437.method_25442();
            zoom = shift ? zoom + 5 : zoom + 1;
        } else {
            boolean shift = class_437.method_25442();
            scroll = Math.max(shift ? scroll - 5 : scroll - 1, 0);
        }
    }

    private static void down() {
        if (class_437.method_25441()) {
            boolean shift = class_437.method_25442();
            zoom = shift ? zoom - 5 : zoom - 1;
        } else {
            boolean shift = class_437.method_25442();
            scroll = Math.max(shift ? scroll + 5 : scroll + 1, 0);
        }
    }

    public static void renderMainPage(class_332 guiGraphics) {
        float scale = (zoom + 100) / 100f;

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_22905(scale, scale, scale);
        List<String> leftLines = collectLeftLines().stream().skip(scroll).toList();
        ((BuggerScreenRenderLinesInvoker) class_310.method_1551().field_1709).drawLines(guiGraphics, leftLines, true);
        List<String> rightLines = collectRightLines().stream().skip(scroll).toList();
        ((BuggerScreenRenderLinesInvoker) class_310.method_1551().field_1709).drawLines(guiGraphics, rightLines, false);
        guiGraphics.method_51448().method_22909();
    }

    private static List<String> collectLeftLines() {
        List<String> lines = new ArrayList<>();

        return lines;
    }

    private static List<String> collectRightLines() {
        List<String> lines = new ArrayList<>();

        return lines;
    }

    private static class_1799 getItemInHand() {
        @Nullable class_746 player = class_310.method_1551().field_1724;
        if (player == null) return class_1799.field_8037;

        class_1799 mainHandItem = player.method_5998(class_1268.field_5808);
        return mainHandItem.method_7960() ? player.method_5998(class_1268.field_5810) : mainHandItem;
    }

    public static List<String> splitString(String text, int size) {
        List<String> ret = new ArrayList<>((text.length() + size - 1) / size);

        for (int start = 0; start < text.length(); start += size) {
            ret.add(text.substring(start, Math.min(text.length(), start + size)));
        }
        return ret;
    }

    public static void renderTagPage(class_332 guiGraphics) {
        List<String> tagLines = getTagPageLines();

        int maxScroll = Math.max(tagLines.size() - 8, 0);
        scroll = class_3532.method_15340(scroll, 0, maxScroll);

        List<String> lines = tagLines.stream().skip(scroll).toList();

        float scale = (zoom + 100) / 100f;

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_22905(scale, scale, scale);
        ((BuggerScreenRenderLinesInvoker) Minecrft.get().field_1709).drawLines(guiGraphics, lines, true);
        guiGraphics.method_51448().method_22909();
    }

    private static @NotNull List<String> getTagPageLines() {
        @Nullable class_239 hitResult = Minecrft.get().field_1765;
        if (hitResult == null || hitResult.method_17783() == class_239.class_240.field_1333) {
            class_1799 itemInHand = getItemInHand();

            JsonElement json = class_1799.field_24671.encodeStart(JsonOps.INSTANCE, itemInHand).result().orElse(new JsonObject());
            String jsonString = new GsonBuilder().setPrettyPrinting().create().toJson(json);

            jsonString = JsonSyntaxHighlighter.highlight(jsonString);

            List<String> lines = new ArrayList<>(Arrays.stream(jsonString.split("\n")).toList());
            lines.add(0,"");
            lines.add(0,itemInHand.method_7964().getString());
            return lines;
        } else if (hitResult instanceof class_3965 blockHitResult) {
            class_2338 blockPos = blockHitResult.method_17777();
            @Nullable class_2586 blockEntity = Minecrft.level().method_8321(blockPos);
            if (blockEntity != null) {
                class_2487 beTag = blockEntity.method_38242();
                JsonElement json = class_2487.field_25128.encodeStart(JsonOps.INSTANCE, beTag).result().orElse(new JsonObject());

                String jsonString = new GsonBuilder().setPrettyPrinting().create().toJson(json);

                jsonString = JsonSyntaxHighlighter.highlight(jsonString);

                List<String> lines = new ArrayList<>(Arrays.stream(jsonString.split("\n")).toList());
                lines.add(0,"");
                lines.add(0,blockEntity.method_11010().method_26204().method_9518().getString());
                return lines;
            } else {
                return List.of(Minecrft.level().method_8320(blockPos).method_26204().method_9518().getString());
            }
        } else if (hitResult instanceof class_3966 entityHitResult) {
            class_1297 entity = entityHitResult.method_17782();

            class_2487 entityTag = new class_2487();
            entity.method_5662(entityTag);

            JsonElement json = class_2487.field_25128.encodeStart(JsonOps.INSTANCE, entityTag).result().orElse(new JsonObject());

            String jsonString = new GsonBuilder().setPrettyPrinting().create().toJson(json);

            jsonString = JsonSyntaxHighlighter.highlight(jsonString);

            List<String> lines = new ArrayList<>(Arrays.stream(jsonString.split("\n")).toList());
            lines.add(0,"");
            lines.add(0,entity.method_5477().getString());
            return lines;
        }

        return Collections.emptyList();
    }
}
