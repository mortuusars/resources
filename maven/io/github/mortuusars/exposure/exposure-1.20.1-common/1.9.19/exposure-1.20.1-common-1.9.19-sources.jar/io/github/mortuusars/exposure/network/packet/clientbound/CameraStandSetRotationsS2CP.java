package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record CameraStandSetRotationsS2CP(int entityId, float yRot, float xRot) implements Packet {
    public static final class_2960 ID = Exposure.resource("camera_stand_set_rotations");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.writeInt(entityId);
        buf.writeFloat(yRot);
        buf.writeFloat(xRot);
    }

    public static CameraStandSetRotationsS2CP fromPacket(class_2540 buf) {
        return new CameraStandSetRotationsS2CP(buf.readInt(),buf.readFloat(),buf.readFloat());
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (player.method_37908().method_8469(entityId) instanceof CameraStandEntity stand) {
            stand.method_36456(yRot);
            stand.method_36457(xRot);
        }
        return true;
    }
}