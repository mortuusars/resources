package io.github.mortuusars.exposure.client.gui.screen;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.client.animation.Animation;
import io.github.mortuusars.exposure.client.animation.EasingFunction;
import io.github.mortuusars.exposure.client.util.Minecrft;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1109;
import net.minecraft.class_1277;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_757;

public class ItemListScreen extends class_437 {
    public static final class_2960 TEXTURE = Exposure.resource("textures/gui/item_list.png");

    protected final class_437 parent;
    protected final List<class_1799> items;
    protected final int rowsCount;
    protected final Animation openingAnimation;

    protected int imageWidth = 176;
    protected int imageHeight = 166;
    protected int titleLabelX = 8;
    protected int titleLabelY = 6;
    protected int leftPos;
    protected int topPos;

    @Nullable
    protected class_1735 hoveredSlot;
    protected List<class_1735> slots = new ArrayList<>();

    protected long openedAt;

    public ItemListScreen(class_437 parent, class_2561 title, List<class_1799> items) {
        super(title);
        this.parent = parent;
        this.items = items;
        List<List<class_1799>> rows = Lists.partition(items, 9);
        this.rowsCount = rows.size();
        this.openingAnimation = new Animation(200, EasingFunction.EASE_OUT_EXPO);

        this.openedAt = class_156.method_658();

        class_1277 container = new class_1277(items.toArray(class_1799[]::new));

        int rowX = 8;
        int rowY = 18;

        for (int row = 0; row < rows.size(); row++) {
            List<class_1799> stacks = rows.get(row);

            // Centers row if it has fewer items than 9
            int rowXToCenterOffset = ((9 * 18) - (stacks.size() * 18)) / 2;

            for (int column = 0; column < stacks.size(); column++) {
                int slotIndex = row * 9 + column;
                slots.add(new class_1735(container, slotIndex, rowX + rowXToCenterOffset + (column * 18), rowY) {
                    @Override
                    public boolean method_7680(class_1799 stack) {
                        return false;
                    }

                    @Override
                    public boolean method_7674(class_1657 player) {
                        return false;
                    }
                });
            }

            rowY += 18;
        }

        Minecrft.get().method_1483().method_4873(class_1109.method_4758(Exposure.SoundEvents.CAMERA_GENERIC_CLICK.get(), 1f));
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    protected void method_25426() {
        this.imageWidth = 176;
        this.imageHeight = 24 + (rowsCount * 18);
        this.leftPos = (this.field_22789 - this.imageWidth) / 2;
        this.topPos = (this.field_22790 - this.imageHeight) / 2;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        int left = leftPos;
        int top = topPos;

        method_25420(guiGraphics);

        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416((field_22789 / 2f), (field_22790 / 2f), 0.0f);
        float animProgress = (float)openingAnimation.getValue();
        guiGraphics.method_51448().method_22905(animProgress, animProgress, animProgress);
        guiGraphics.method_51448().method_46416(-(field_22789 / 2f), -(field_22790 / 2f), 0.0f);

        renderBg(guiGraphics, mouseX, mouseY, partialTick);
        RenderSystem.disableDepthTest();
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        {
            guiGraphics.method_51448().method_22903();
            guiGraphics.method_51448().method_46416(left, top, 0.0f);
            hoveredSlot = null;
            for (class_1735 slot : slots) {
                if (slot.method_7682()) {
                    renderSlot(guiGraphics, slot);
                }
                if (!isHovering(slot, mouseX, mouseY) || !slot.method_7682()) {
                    continue;
                }
                this.hoveredSlot = slot;
                if (!hoveredSlot.method_51306()) {
                    continue;
                }
                renderSlotHighlight(guiGraphics, slot.field_7873, slot.field_7872, 0);
            }
            this.renderLabels(guiGraphics, mouseX, mouseY);
            guiGraphics.method_51448().method_22909();
        }
        RenderSystem.enableDepthTest();
        guiGraphics.method_51448().method_22909();

        renderTooltip(guiGraphics, mouseX, mouseY);
    }


    protected void renderBg(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        // Render BG expanding it according to number of rows
        guiGraphics.method_25302(TEXTURE, leftPos, topPos, 0, 0, imageWidth, 17);
        for (int i = 0; i < rowsCount; i++) {
            guiGraphics.method_25302(TEXTURE, leftPos, topPos + 17 + (i * 18), 0, 17, imageWidth, 18);
        }
        guiGraphics.method_25302(TEXTURE, leftPos, topPos + 17 + (rowsCount * 18), 0, 35, imageWidth, 7);

        for (class_1735 slot : slots) {
            guiGraphics.method_25302(TEXTURE, leftPos + slot.field_7873 - 1, topPos + slot.field_7872 - 1, 176, 0, 18, 18);
        }
    }

    protected void renderLabels(class_332 guiGraphics, int mouseX, int mouseY) {
        guiGraphics.method_51439(this.field_22793, this.field_22785, this.titleLabelX, this.titleLabelY, 0x404040, false);
    }

    protected void renderSlot(class_332 guiGraphics, class_1735 slot) {
        int x = slot.field_7873;
        int y = slot.field_7872;
        class_1799 itemStack = slot.method_7677();
        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(0.0f, 0.0f, 100.0f);
        guiGraphics.method_51428(itemStack, x, y, slot.field_7873 + slot.field_7872 * imageWidth);
        guiGraphics.method_51432(field_22793, itemStack, x, y, null);
        guiGraphics.method_51448().method_22909();
    }

    public static void renderSlotHighlight(class_332 guiGraphics, int x, int y, int blitOffset) {
        guiGraphics.method_51740(class_1921.method_51785(), x, y, x + 16, y + 16, -2130706433, -2130706433, blitOffset);
    }

    protected void renderTooltip(class_332 guiGraphics, int x, int y) {
        if (hoveredSlot != null && hoveredSlot.method_7681()) {
            class_1799 itemStack = hoveredSlot.method_7677();

            List<class_2561> tooltipLines = parent instanceof class_465<?> abstractContainerScreen
                    ? abstractContainerScreen.method_51454(itemStack)
                    : class_437.method_25408(Minecrft.get(), itemStack);

            guiGraphics.method_51437(field_22793, tooltipLines, itemStack.method_32347(), x, y);
        }
    }

    protected boolean isHovering(class_1735 slot, double mouseX, double mouseY) {
        return this.isHovering(slot.field_7873, slot.field_7872, 16, 16, mouseX, mouseY);
    }

    protected boolean isHovering(int x, int y, int width, int height, double mouseX, double mouseY) {
        int i = this.leftPos;
        int j = this.topPos;
        return (mouseX -= (double) i) >= (double) (x - 1) && mouseX < (double) (x + width + 1) && (mouseY -= (double) j) >= (double) (y - 1) && mouseY < (double) (y + height + 1);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (Minecrft.options().field_1822.method_1417(keyCode, scanCode)) {
            method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (super.method_25402(mouseX, mouseY, button)) return true;

        if (!isHovering(0, 0, imageWidth, imageHeight, mouseX, mouseY)) {
            method_25419();
            return true;
        }

        return false;
    }

    @Override
    public void method_25419() {
        Minecrft.get().method_1507(parent);
    }
}
