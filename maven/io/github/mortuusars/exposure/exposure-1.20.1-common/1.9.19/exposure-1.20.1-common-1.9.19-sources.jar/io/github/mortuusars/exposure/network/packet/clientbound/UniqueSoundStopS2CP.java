package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import io.github.mortuusars.exposure.client.sound.UniqueSoundManager;

public record UniqueSoundStopS2CP(String id, class_3414 sound) implements Packet {
    public static final class_2960 ID = Exposure.resource("unique_sound_stop");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buf) {
        buf.method_10814(id);
        sound.method_47958(buf);
    }

    public static UniqueSoundStopS2CP fromPacket(class_2540 buf){
        return new UniqueSoundStopS2CP(buf.method_19772(),class_3414.method_47961(buf));
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        UniqueSoundManager.stop(id, sound);
        return true;
    }
}
