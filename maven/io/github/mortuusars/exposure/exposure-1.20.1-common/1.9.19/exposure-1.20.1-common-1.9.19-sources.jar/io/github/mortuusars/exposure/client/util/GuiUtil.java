package io.github.mortuusars.exposure.client.util;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import io.github.mortuusars.exposure.util.Rect2f;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

public class GuiUtil {
    public static void blit(class_4587 poseStack, Rect2f rect,
                            int u, int v, int textureWidth, int textureHeight, float zOffset) {
        blit(null, poseStack, rect, u, v, textureWidth, textureHeight, zOffset);
    }

    public static void blit(@Nullable class_2960 texture, class_4587 poseStack, Rect2f rect,
                            int u, int v, int textureWidth, int textureHeight, float zOffset) {
        blit(texture, poseStack, rect.x, rect.y, rect.width, rect.height, u, v, textureWidth, textureHeight, zOffset);
    }

    public static void blit(class_4587 poseStack, float x, float y, float width, float height,
                            int u, int v, int textureWidth, int textureHeight, float zOffset) {
        blit(null, poseStack, x, y, width, height, u, v, textureWidth, textureHeight, zOffset);
    }

    public static void blit(@Nullable class_2960 texture, class_4587 poseStack, float x, float y, float width, float height,
                            int u, int v, int textureWidth, int textureHeight, float zOffset) {
        blit(texture, poseStack, x, x + width, y, y + height, zOffset,
                u / (float)textureWidth, (u + width) / (float)textureWidth,
                v / (float)textureHeight, (v + height) / (float)textureHeight);
    }

    public static void blit(class_4587 poseStack, float minX, float maxX, float minY, float maxY, float zOffset,
                            float minU, float maxU, float minV, float maxV) {
        blit(null, poseStack, minX, maxX, minY, maxY, zOffset, minU, maxU, minV, maxV);
    }

    private static void blit(@Nullable class_2960 texture, class_4587 poseStack,
                             float minX, float maxX, float minY, float maxY, float zOffset,
                             float minU, float maxU, float minV, float maxV) {
        if (texture != null) {
            RenderSystem.setShaderTexture(0, texture);
        }

        Matrix4f matrix = poseStack.method_23760().method_23761();
        RenderSystem.setShader(class_757::method_34542);
        class_289 tesselator = class_289.method_1348();
        class_287 bufferBuilder = tesselator.method_1349();
        bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1585);
        bufferBuilder.method_22918(matrix, minX, maxY, zOffset).method_22913(minU, maxV).method_1344();
        bufferBuilder.method_22918(matrix, maxX, maxY, zOffset).method_22913(maxU, maxV).method_1344();
        bufferBuilder.method_22918(matrix, maxX, minY, zOffset).method_22913(maxU, minV).method_1344();
        bufferBuilder.method_22918(matrix, minX, minY, zOffset).method_22913(minU, minV).method_1344();
        class_286.method_43433(bufferBuilder.method_1326());
    }

    // --

    public static void drawRect(class_332 guiGraphics, Rect2f rect, int color) {
        drawRect(guiGraphics, rect.x, rect.y, rect.width, rect.height, color);
    }

    public static void drawRect(class_332 guiGraphics, float x, float y, float width, float height, int color) {
        drawRect(guiGraphics.method_51448(), x, y, x + width, y + height, color);
    }

    public static void drawRect(class_4587 poseStack, float minX, float minY, float maxX, float maxY, int color) {
        if (minX < maxX) {
            float temp = minX;
            minX = maxX;
            maxX = temp;
        }

        if (minY < maxY) {
            float temp = minY;
            minY = maxY;
            maxY = temp;
        }

        Matrix4f matrix = poseStack.method_23760().method_23761();
        RenderSystem.setShader(class_757::method_34540);
        class_287 bufferBuilder = class_289.method_1348().method_1349();
        bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22918(matrix, minX, maxY, 0).method_39415(color).method_1344();
        bufferBuilder.method_22918(matrix, maxX, maxY, 0).method_39415(color).method_1344();
        bufferBuilder.method_22918(matrix, maxX, minY, 0).method_39415(color).method_1344();
        bufferBuilder.method_22918(matrix, minX, minY, 0).method_39415(color).method_1344();
        class_286.method_43433(bufferBuilder.method_1326());
    }

    // --

    public static void renderScrollingString(class_332 guiGraphics, class_327 font, class_2561 text, int x, int y, int width, int color) {
        renderScrollingString(guiGraphics, font, text, x, y, x + width, y + font.field_2000, color);
    }

    public static void renderScrollingString(class_332 guiGraphics, class_327 font, class_2561 text, int minX, int minY, int maxX, int maxY, int color) {
        renderScrollingString(guiGraphics, font, text, (minX + maxX) / 2, minX, minY, maxX, maxY, color);
    }

    // Doesn't work in toast for some reason.
    public static void renderScrollingString(class_332 guiGraphics, class_327 font, class_2561 text, int centerX, int minX, int minY, int maxX, int maxY, int color) {
        int fontWidth = font.method_27525(text);
        int y = (minY + maxY - 9) / 2 + 1;
        int width = maxX - minX;
        if (fontWidth > width) {
            int remaining = fontWidth - width;
            double d = (double) class_156.method_658() / 400;
            double e = Math.max((double)remaining * 0.5, 3.0);
            double f = Math.sin((Math.PI / 2) * Math.cos((Math.PI * 2) * d / e)) / 2.0 + 0.5;
            double g = class_3532.method_16436(f, 0.0, remaining);
            guiGraphics.method_44379(minX, minY, maxX, maxY);
            guiGraphics.method_51439(font, text, minX - (int)g, y, color, false);
            guiGraphics.method_44380();
        } else {
            int l = class_3532.method_15340(centerX, minX + fontWidth / 2, maxX - fontWidth / 2);
            guiGraphics.method_27534(font, text, l, y, color);
        }
    }
}
