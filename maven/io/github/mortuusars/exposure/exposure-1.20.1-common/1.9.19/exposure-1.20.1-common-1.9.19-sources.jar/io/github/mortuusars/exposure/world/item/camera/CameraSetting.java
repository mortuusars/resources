package io.github.mortuusars.exposure.world.item.camera;

import com.mojang.serialization.Codec;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.serverbound.ActiveCameraSetSettingC2SP;
import io.github.mortuusars.exposure.util.NBTAbstraction;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import io.github.mortuusars.exposure.world.sound.Sound;
import io.github.mortuusars.exposure.world.sound.SoundEffect;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3419;

public record CameraSetting<T>(NBTAbstraction.Named<T> function, T defaultValue, Optional<SoundEffect> sound) {
    public static final Codec<CameraSetting<?>> CODEC = class_2960.field_25139.xmap(CameraSettings::byId, CameraSettings::idOf);

    public void toPacket(class_2540 buf) {
        buf.method_10812(CameraSettings.idOf(this));
    }

    public static CameraSetting<?> fromPacket(class_2540 buf) {
        return CameraSettings.byId(buf.method_10810());
    }

    public CameraSetting(NBTAbstraction.Named<T> function, T defaultValue, SoundEffect sound) {
        this(function, defaultValue, Optional.ofNullable(sound));
    }

    public CameraSetting(NBTAbstraction.Named<T> function, T defaultValue) {
        this(function, defaultValue, Optional.empty());
    }

    // --

    public @Nullable T get(class_1799 stack) {
        return function.read(stack);
    }

    public Optional<T> getOptional(class_1799 stack) {
        return Optional.ofNullable(get(stack));
    }

    public T getOrDefault(class_1799 stack) {
        T t = get(stack);
        return t == null ? defaultValue : t;
    }

    public T getOrElse(class_1799 stack, T defaultValue) {
        T t = get(stack);
        return t == null ? defaultValue : t;
    }

    public @Nullable T get(Camera camera) {
        return function.read(camera.getItemStack());
    }

    public Optional<T> getOptional(Camera camera) {
        return Optional.ofNullable(get(camera));
    }

    public T getOrDefault(Camera camera) {
        T t = function.read(camera.getItemStack());
        return t == null ? defaultValue : t;
    }

    public T getOrElse(Camera camera, T defaultValue) {
        T t = function.read(camera.getItemStack());
        return t == null ? defaultValue : t;
    }

    // --

    public boolean set(class_1799 stack, T value) {
        if (stack.method_7960() || getOrDefault(stack).equals(value)) return false;

        if (value instanceof Boolean bool && !bool) {
            stack.method_7983(function.key());
        } else {
            function.write(stack,value);
        }
        return true;
    }

    public boolean set(CameraHolder holder, class_1799 stack, T value) {
        if (stack.method_7909() instanceof CameraItem cameraItem && set(stack, value)) {
            cameraItem.actionPerformed(stack, holder);
            sound.ifPresent(sound ->
                    Sound.playSided(holder.asHolderEntity(), sound.sound().get(), class_3419.field_15248,
                            sound.volume(), sound.pitch(), sound.pitchVariability()));
            return true;
        }
        return false;
    }

    public boolean set(Camera camera, T value) {
        return camera.map((item, stack) -> set(camera.getHolder(), stack, value)).orElse(false);
    }

    public boolean setAndSync(Camera camera, T value) {
        return camera.map((item, stack) -> {
            if (set(camera.getHolder(), stack, value)) {
                byte[] bytes = encodeValue(value);
                Packets.sendToServer(new ActiveCameraSetSettingC2SP(this, bytes));
                return true;
            }
            return false;
        }).orElse(false);
    }

    public boolean decodeAndSet(class_1799 stack, byte[] bytes) {
        T value = decodeValue(bytes);
        return set(stack, value);
    }

    public boolean decodeAndSet(CameraHolder holder, class_1799 stack, byte[] bytes) {
        T value = decodeValue(bytes);
        return set(holder, stack, value);
    }

    // --

    public byte[] encodeValue(T value) {
        class_2540 buffer = new class_2540(Unpooled.buffer());
        try {
            function.abstraction().packetWriter().accept(buffer, value);
            return buffer.array().clone();
        } finally {
            buffer.release();
        }
    }

    public T decodeValue(byte[] bytes) {
        class_2540 buffer = new class_2540(Unpooled.buffer());
        try {
            buffer.writeBytes(bytes);
            return function.abstraction().packetReader().apply(buffer);
        } finally {
            buffer.release();
        }
    }
}
