package io.github.mortuusars.exposure.world.camera.capture;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.util.Codecs;
import io.github.mortuusars.exposure.util.ExtraData;
import io.github.mortuusars.exposure.util.NbtType;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.world.camera.ColorChannel;
import io.github.mortuusars.exposure.world.camera.component.ShutterSpeed;
import io.github.mortuusars.exposure.world.camera.film.properties.FilmProperties;
import io.github.mortuusars.exposure.world.entity.CameraHolder;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public record CaptureParameters(String exposureId,
                                Optional<CameraId> cameraId,
                                Optional<Integer> cameraHolderId,
                                Optional<Double> fov,
                                float cropFactor,
                                Optional<class_2960> filter,
                                Optional<Projection> projection,
                                Optional<ColorChannel> singleChannel,
                                FilmProperties filmProperties,
                                ExtraData extraData) {

    public static final NbtType<ShutterSpeed> SHUTTER_SPEED =
            NbtType.stringRepresentable("shutter_speed", ShutterSpeed::new);
    public static final NbtType<Boolean> FLASH =
            new NbtType<>("flash", class_2487::method_10577, class_2487::method_10556);
    public static final NbtType<Integer> LIGHT_LEVEL =
            new NbtType<>("light_level", class_2487::method_10550, class_2487::method_10569);

    // --

    public static final Codec<CaptureParameters> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("id").forGetter(CaptureParameters::exposureId),
            CameraId.CODEC.optionalFieldOf("camera_id").forGetter(CaptureParameters::cameraId),
            Codec.INT.optionalFieldOf("camera_holder_id").forGetter(CaptureParameters::cameraHolderId),
            Codecs.POSITIVE_DOUBLE.optionalFieldOf("fov").forGetter(CaptureParameters::fov),
            Codecs.floatRange(0.001f, 1f).optionalFieldOf("crop_factor", 1f).forGetter(CaptureParameters::cropFactor),
            class_2960.field_25139.optionalFieldOf("filter").forGetter(CaptureParameters::filter),
            Projection.CODEC.optionalFieldOf("projection").forGetter(CaptureParameters::projection),
            ColorChannel.CODEC.optionalFieldOf("single_channel").forGetter(CaptureParameters::singleChannel),
            FilmProperties.CODEC.optionalFieldOf("film", FilmProperties.EMPTY).forGetter(CaptureParameters::filmProperties),
            ExtraData.field_25128.optionalFieldOf("extra_data", ExtraData.EMPTY).forGetter(CaptureParameters::extraData)
    ).apply(instance, CaptureParameters::new));

    public void toPacket(class_2540 buf) {
        buf.method_10814(exposureId);
        buf.method_37435(cameraId,(buf1, cameraId1) -> cameraId1.toPacket(buf1));
        buf.method_37435(cameraHolderId, class_2540::writeInt);
        buf.method_37435(fov,class_2540::writeDouble);
        buf.writeFloat(cropFactor);
        buf.method_37435(filter,class_2540::method_10812);
        buf.method_37435(projection,(buf1, projection1) -> projection1.toPacket(buf1));
        buf.method_37435(singleChannel,class_2540::method_10817);
        filmProperties.toPacket(buf);
        extraData.toPacket(buf);
    }

    public static CaptureParameters fromPacket(class_2540 buf) {
        return new CaptureParameters(buf.method_19772(),buf.method_37436(CameraId::fromPacket),buf.method_37436(class_2540::readInt),
                buf.method_37436(class_2540::readDouble),buf.readFloat(),buf.method_37436(class_2540::method_10810),
                buf.method_37436(Projection::fromPacket),buf.method_37436(buf1 -> buf1.method_10818(ColorChannel.class)),FilmProperties.fromPacket(buf),ExtraData.fromPacket(buf));
    }

    public ShutterSpeed getShutterSpeed() {
        return extraData.get(SHUTTER_SPEED).orElse(ShutterSpeed.DEFAULT);
    }

    public boolean getFlash() {
        return extraData.get(FLASH).orElse(false);
    }

    public Optional<Integer> getLightLevel() {
        return extraData.get(LIGHT_LEVEL);
    }

    public Builder mutable() {
        return new Builder(this);
    }

    public static final class Builder {
        private final String exposureId;
        private @Nullable CameraId cameraId;
        private @Nullable Integer cameraHolderEntityID;
        private @Nullable Double fov;
        private float cropFactor = 1f;
        private @Nullable class_2960 filter = null;
        private @Nullable Projection projection;
        private @Nullable ColorChannel chromaticChannel;
        private FilmProperties filmProperties = FilmProperties.EMPTY;
        private final ExtraData extraData = new ExtraData();

        public Builder(String exposureId) {
            this.exposureId = exposureId;
        }

        public Builder(CaptureParameters params) {
            this.exposureId = params.exposureId();
            this.cameraId = params.cameraId().orElse(null);
            this.cameraHolderEntityID = params.cameraHolderId().orElse(null);
            this.fov = params.fov.orElse(null);
            this.cropFactor = params.cropFactor();
            this.filter = params.filter().orElse(null);
            this.projection = params.projection().orElse(null);
            this.chromaticChannel = params.singleChannel().orElse(null);
            this.filmProperties = params.filmProperties();
            extraData.method_10543(params.extraData());
        }

        public Builder setCameraID(@Nullable CameraId cameraId) {
            this.cameraId = cameraId;
            return this;
        }

        public Builder setCameraHolder(@Nullable CameraHolder holder) {
            if (holder == null) cameraHolderEntityID = null;
            else cameraHolderEntityID = holder.asHolderEntity().method_5628();
            return this;
        }

        public Builder setFilter(@Nullable class_2960 filter) {
            this.filter = filter;
            return this;
        }

        public Builder setFov(@Nullable Double fov) {
            this.fov = fov;
            return this;
        }

        public Builder setCropFactor(float cropFactor) {
            this.cropFactor = cropFactor;
            return this;
        }

        public Builder setProjectionInfo(@Nullable Projection projection) {
            this.projection = projection;
            return this;
        }

        public Builder setProjection(Optional<Projection> projection) {
            this.projection = projection.orElse(null);
            return this;
        }

        public Builder setChromaticChannel(@Nullable ColorChannel chromaticChannel) {
            this.chromaticChannel = chromaticChannel;
            return this;
        }

        public Builder setChromaticChannel(Optional<ColorChannel> chromaticChannel) {
            this.chromaticChannel = chromaticChannel.orElse(null);
            return this;
        }

        public Builder setFilmProperties(FilmProperties filmProperties) {
            this.filmProperties = filmProperties;
            return this;
        }

        public Builder extraData(Consumer<ExtraData> extraDataUpdater) {
            extraDataUpdater.accept(extraData);
            return this;
        }

        public <T> Builder extraData(NbtType<T> type, T value) {
            extraData.put(type, value);
            return this;
        }

        public CaptureParameters build() {
            return new CaptureParameters(exposureId,
                    Optional.ofNullable(this.cameraId),
                    Optional.ofNullable(this.cameraHolderEntityID),
                    Optional.ofNullable(this.fov),
                    this.cropFactor,
                    Optional.ofNullable(this.filter),
                    Optional.ofNullable(this.projection),
                    Optional.ofNullable(this.chromaticChannel),
                    this.filmProperties,
                    this.extraData);
        }
    }
}
