package io.github.mortuusars.exposure.world.item.util;

import java.util.Objects;
import java.util.function.*;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2540;

public class ItemAndStack<T extends class_1792> {
    private final T item;
    private final class_1799 stack;

    public ItemAndStack(class_1799 stack) {
        this.stack = stack;
        //noinspection unchecked
        this.item = (T) stack.method_7909();
    }

    public T getItem() {
        return item;
    }

    public class_1799 getItemStack() {
        return stack;
    }

    public ItemAndStack<T> apply(BiConsumer<T, class_1799> function) {
        function.accept(item, stack);
        return this;
    }

    public void toPacket(class_2540 buf) {
        buf.method_10793(stack);
    }

    public static ItemAndStack<?> fromPacket(class_2540 buf) {
        return new ItemAndStack<>(buf.method_10819());
    }

    public <R> R map(BiFunction<T, class_1799, R> mappingFunction) {
        return mappingFunction.apply(item, stack);
    }

    @Override
    public String toString() {
        return "ItemAndStack{" + stack.toString() + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ItemAndStack<?> that = (ItemAndStack<?>) o;
        return Objects.equals(item, that.item) && class_1799.method_31577(stack, that.stack);//can't use .equals on itemstacks!
    }

    @Override
    public int hashCode() {
        return Objects.hash(item, stack);
    }
}
