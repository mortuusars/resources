package io.github.mortuusars.exposure.world.camera.frame;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.util.NbtType;
import io.github.mortuusars.exposure.world.camera.ColorChannel;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.world.camera.component.ShutterSpeed;
import io.github.mortuusars.exposure.world.level.storage.ExposureIdentifier;
import org.jetbrains.annotations.NotNull;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public record Frame(ExposureIdentifier identifier,
                    ExposureType type,
                    Photographer photographer,
                    List<EntityInFrame> entitiesInFrame,
                    class_2487 extraData) {
    public static final NbtType<Boolean> PROJECTED = NbtType.bool("projected");
    public static final NbtType<Boolean> CHROMATIC = NbtType.bool("chromatic");

    public static final NbtType<ColorChannel> COLOR_CHANNEL =
            NbtType.stringRepresentable("color_channel", ColorChannel::fromStringOrThrow);
    public static final NbtType<ShutterSpeed> SHUTTER_SPEED =
            NbtType.stringRepresentable("shutter_speed", ShutterSpeed::new);

    public static final NbtType<Long> TIMESTAMP = NbtType.longVal("timestamp");
    public static final NbtType<Integer> FOCAL_LENGTH = NbtType.intVal("focal_length");
    public static final NbtType<Boolean> FLASH = NbtType.bool("flash");
    public static final NbtType<Boolean> SELFIE = NbtType.bool("selfie");
    public static final NbtType<Boolean> ON_STAND = NbtType.bool("on_stand");

    public static final NbtType<class_243> POSITION = NbtType.vec3("pos");
    public static final NbtType<Float> PITCH = NbtType.floatVal("pitch");
    public static final NbtType<Float> YAW = NbtType.floatVal("yaw");
    public static final NbtType<Integer> LIGHT_LEVEL = NbtType.intVal("light_level");
    public static final NbtType<Integer> DAY_TIME = NbtType.intVal("day_time");
    public static final NbtType<class_2960> DIMENSION = NbtType.resourceLocation("dimension");
    public static final NbtType<class_2960> BIOME = NbtType.resourceLocation("biome");
    public static final NbtType<String> WEATHER = NbtType.string("weather");
    public static final NbtType<Boolean> IN_CAVE = NbtType.bool("in_cave");
    public static final NbtType<Boolean> UNDERWATER = NbtType.bool("underwater");
    public static final NbtType<List<class_2960>> STRUCTURES = NbtType.stringBasedList("structures",
            class_2960::new, class_2960::toString);
    // --

    public static final Frame EMPTY = new Frame(
            ExposureIdentifier.EMPTY,
            ExposureType.COLOR,
            Photographer.EMPTY,
            Collections.emptyList(),
            new class_2487());

    public static final Codec<Frame> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                    ExposureIdentifier.CODEC.fieldOf("identifier").forGetter(Frame::identifier),
                    ExposureType.CODEC.optionalFieldOf("type", ExposureType.COLOR).forGetter(Frame::type),
                    Photographer.CODEC.optionalFieldOf("photographer", Photographer.EMPTY).forGetter(Frame::photographer),
                    EntityInFrame.CODEC.listOf().optionalFieldOf("entities_in_frame", Collections.emptyList()).forGetter(Frame::entitiesInFrame),
                    class_2487.field_25128.optionalFieldOf("extra_data", new class_2487()).forGetter(Frame::extraData))
            .apply(instance, Frame::new));


    public static Frame fromPacket(class_2540 buf) {
        return new Frame(ExposureIdentifier.fromPacket(buf),buf.method_10818(ExposureType.class),
                Photographer.fromPacket(buf),buf.method_34066(EntityInFrame::fromPacket),buf.method_10798());
    }

    public void toPacket(class_2540 buf) {
        identifier.toPacket(buf);
        buf.method_10817(type);
        photographer.toPacket(buf);
        buf.method_34062(entitiesInFrame,(buf1, entityInFrame) -> entityInFrame.toPacket(buf1));
        buf.method_10794(extraData);
    }

    public static Mutable create() {
        return new Mutable(EMPTY);
    }

    /**
     * Creates a frame that has data common to all frames in a provided list.
     * If value is not common to all objects - default value will be used.
     * Currently used in Chromatic Sheets to create a common data object from 3 layers.
     */
    public static Frame intersect(ExposureIdentifier identifier, List<Frame> frames) {
        Mutable result = EMPTY.toMutable().setIdentifier(identifier);

        if (frames.isEmpty()) {
            return result.toImmutable();
        }

        result.setType(getCommonValueOrDefault(frames, Frame::type));
        result.setPhotographer(getCommonValueOrDefault(frames, Frame::photographer));

        List<EntityInFrame> commonEntitiesInFrame = frames.stream()
                .map(Frame::entitiesInFrame)
                .map(HashSet::new)
                .reduce((set1, set2) -> {
                    set1.retainAll(set2);
                    return set1;
                })
                .map(ArrayList::new)
                .orElse(new ArrayList<>());
        result.setEntitiesInFrame(commonEntitiesInFrame);

        class_2487 mergedTag = frames.stream()
                .map(f -> f.extraData.method_10553())
                .reduce(new class_2487(), class_2487::method_10543);
        result.setTag(mergedTag);

        return result.toImmutable();
    }

    private static <V> V getCommonValueOrDefault(List<Frame> objects, Function<Frame, V> propertyGetter) {
        V referenceValue = propertyGetter.apply(objects.get(0));
        return objects.stream().allMatch(data -> propertyGetter.apply(data) == referenceValue) ? referenceValue : propertyGetter.apply(EMPTY);
    }

    private static <T, V> V getCommonValueOrElse(List<T> objects, Function<T, V> propertyGetter, V fallbackValue) {
        V referenceValue = propertyGetter.apply(objects.get(0));
        return objects.stream().allMatch(data -> propertyGetter.apply(data) == referenceValue) ? referenceValue : fallbackValue;
    }

    public boolean isTakenBy(class_1309 entity) {
        return photographer().matches(entity);
    }

    /**
     * Do not modify the tag here! It may cause unwanted side effects.
     */
    public class_2487 getExtraDataForReading() {
        return extraData();
    }

    public boolean isProjected() {
        return NbtType.get(getExtraDataForReading(),PROJECTED).orElse(false);
    }

    public boolean isChromatic() {
        return NbtType.get(getExtraDataForReading(),CHROMATIC).orElse(false);
    }

    public Optional<ColorChannel> getColorChannel() {
        return NbtType.get(getExtraDataForReading(),COLOR_CHANNEL);
    }

    public boolean wasTakenWithChromaticFilter() {
        return getColorChannel().isPresent();
    }

    public Mutable toMutable() {
        return new Mutable(this);
    }

    public static class Mutable {
        private ExposureIdentifier identifier;
        private ExposureType type;
        private Photographer photographer;
        private List<EntityInFrame> entitiesInFrame;
        private class_2487 tag;

        public Mutable(Frame photographData) {
            this.identifier = photographData.identifier();
            this.type = photographData.type();
            this.photographer = photographData.photographer();
            this.entitiesInFrame = new ArrayList<>(photographData.entitiesInFrame());
            this.tag = photographData.extraData().method_10553();
        }

        public ExposureIdentifier getIdentifier() {
            return identifier;
        }

        public Mutable setIdentifier(ExposureIdentifier identifier) {
            this.identifier = identifier;
            return this;
        }

        public ExposureType getType() {
            return type;
        }

        public Mutable setType(ExposureType type) {
            this.type = type;
            return this;
        }

        public Photographer getPhotographer() {
            return photographer;
        }

        public Mutable setPhotographer(@NotNull Photographer photographer) {
            this.photographer = photographer;
            return this;
        }

        public List<EntityInFrame> getEntitiesInFrame() {
            return entitiesInFrame;
        }

        public Mutable setEntitiesInFrame(List<EntityInFrame> entitiesInFrame) {
            this.entitiesInFrame = entitiesInFrame;
            return this;
        }

        public class_2487 getTag() {
            return tag;
        }

        public Mutable setTag(class_2487 tag) {
            this.tag = tag;
            return this;
        }

        public Mutable updateExtraData(Consumer<class_2487> updater) {
            updater.accept(tag);
            return this;
        }

        public <T> Mutable addExtraData(NbtType<T> type, T value) {
            NbtType.put(tag,type, value);
            return this;
        }

        public Mutable setChromatic(boolean chromatic) {
            return updateExtraData(tag -> NbtType.put(tag,CHROMATIC, chromatic));
        }

        public Frame toImmutable() {
            return new Frame(
                    this.identifier,
                    this.type,
                    this.photographer,
                    this.entitiesInFrame,
                    this.tag);
        }
    }
}
