package io.github.mortuusars.exposure.advancements.predicate;

import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_1297;
import net.minecraft.class_1321;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_7376;
import org.jetbrains.annotations.Nullable;

public record TamedPredicate(boolean isTamed) implements class_7376 {
    public static final Codec<TamedPredicate> CODEC = RecordCodecBuilder.create(
            instance -> instance.group(Codec.BOOL.fieldOf("is_tamed").forGetter(TamedPredicate::isTamed))
                    .apply(instance, TamedPredicate::new)
    );

    @Override
    public boolean method_22497(class_1297 entity, class_3218 level, @Nullable class_243 position) {
        return entity instanceof class_1321 animal && animal.method_6181() == isTamed;
    }

    @Override
    public JsonObject method_22494() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("is_tamed",isTamed);
        return jsonObject;
    }

    @Override
    public class_7377 method_43099() {
        return Exposure.EntitySubPredicates.TAMED;
    }
}
