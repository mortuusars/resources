package io.github.mortuusars.exposure.client;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.PlatformHelperClient;
import io.github.mortuusars.exposure.client.camera.CameraClient;
import io.github.mortuusars.exposure.client.camera.viewfinder.Viewfinder;
import io.github.mortuusars.exposure.client.render.model.CameraModel;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import io.github.mortuusars.exposure.world.item.StackedPhotographsItem;
import net.minecraft.class_1087;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_811;
import org.jetbrains.annotations.Nullable;

public class ModelHooks {
    public static class_1087 renderItem(class_1087 model, class_1799 stack, class_811 displayContext, boolean leftHand,
                                        class_4587 poseStack, class_4597 buffer, int combinedLight, int combinedOverlay) {
        if (class_310.method_1551().field_1687 == null) return model;
        if (!stack.method_31574(Exposure.Items.CAMERA.get())) return model;

        if (displayContext == class_811.field_4317) {
            class_1087 guiModel = PlatformHelperClient.getModel(ExposureClient.Models.CAMERA_GUI);
            class_1087 resolve = guiModel.method_4710().method_3495(guiModel, stack, Minecrft.level(), Minecrft.player(), 0);
            return resolve;
        }

        return model;
    }

    public static class_1087 getModel(class_1087 original, class_1799 stack, @Nullable class_1937 level, @Nullable class_1309 entity, int seed) {
        if (stack.method_31574(Exposure.Items.CAMERA.get())) {
            @Nullable class_638 clientLevel = level instanceof class_638 lv ? lv : null;
            return CameraModel.modifyCameraModel(stack, clientLevel, entity, seed, original);
        }

        return original;
    }

    public static boolean renderGui(class_332 guiGraphics, float partialTick) {
        Viewfinder viewfinder = CameraClient.viewfinder();
        if (viewfinder != null && viewfinder.isLookingThrough()) {
            viewfinder.overlay().render(guiGraphics, partialTick);
            if (Config.Client.HIDE_HUD_WHILE_IN_VIEWFINDER.get()) {
                return true;
            }
        }
        return false;
    }

    public static boolean renderCrosshair() {
        class_746 player = (class_746) Minecrft.player();
        if (Config.Client.PHOTOGRAPH_IN_HAND_HIDE_CROSSHAIR.get() && player.method_36455() > 25f
              && (player.method_6047().method_7909() instanceof PhotographItem || player.method_6047().method_7909() instanceof StackedPhotographsItem)
              && player.method_6079().method_7960())
            return true;
        return false;
    }
}
