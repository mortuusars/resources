package io.github.mortuusars.exposure.client.camera.viewfinder;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.client.camera.CameraClient;
import io.github.mortuusars.exposure.client.input.*;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.world.camera.Camera;
import io.github.mortuusars.exposure.world.entity.CameraStandEntity;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_5498;

public class Viewfinder {
    protected final Camera camera;
    protected final ViewfinderZoom zoom;
    protected final ViewfinderOverlay overlay;
    protected final ViewfinderShader shader;
    protected final ViewfinderSelfie selfie;

    protected KeyBindings keyBindings = KeyBindings.of(
            Key.press(Minecrft.options().field_1886).executes(() -> !canAttack()),
            Key.press(Minecrft.options().field_1824).executes(() -> selfie().toggle()),
            Key.press(Minecrft.options().field_1822).or(Key.press(class_3675.field_31958)).executes(() -> {
                if (Minecrft.get().field_1755 instanceof ViewfinderCameraControlsScreen viewfinderControlsScreen) {
                    viewfinderControlsScreen.method_25419();
                    controlsScreen = null;
                } else {
                    CameraClient.deactivate();
                    close();
                }
            }),
            Key.press(KeyboardHandler.getCameraControlsKey())
                    .onlyIf(this::isLookingThrough)
                    .onlyIf(() -> !controlsActive())
                    .executes(() -> {
                        openControlsScreen();
                        return false; // false not handle and keep moving/sneaking
                    })
    );

    protected @Nullable ViewfinderCameraControlsScreen controlsScreen;

    public Viewfinder(@NotNull Camera camera) {
        this.camera = camera;
        this.zoom = createZoom(camera);
        this.overlay = createOverlay(camera);
        this.shader = createShader(camera);
        this.selfie = createSelfie(camera);
    }

    protected ViewfinderZoom createZoom(Camera camera) {
        return new ViewfinderZoom(camera, this);
    }

    protected ViewfinderOverlay createOverlay(Camera camera) {
        return new ViewfinderOverlay(camera, this);
    }

    protected ViewfinderShader createShader(Camera camera) {
        return new ViewfinderShader(camera, this);
    }

    protected ViewfinderSelfie createSelfie(Camera camera) {
        return new ViewfinderSelfie(camera, this);
    }

    protected ViewfinderCameraControlsScreen createControlsScreen(Camera camera) {
        return new ViewfinderCameraControlsScreen(camera, this);
    }

    // --

    public Camera camera() {
        return camera;
    }

    public ViewfinderZoom zoom() {
        return zoom;
    }

    public ViewfinderOverlay overlay() {
        return overlay;
    }

    public ViewfinderShader shader() {
        return shader;
    }

    public ViewfinderSelfie selfie() {
        return selfie;
    }

    public Optional<ViewfinderCameraControlsScreen> controlsScreen() {
        return Optional.ofNullable(controlsScreen);
    }

    public void tick() {
        shader().update();
        selfie().tick();
    }

    public boolean isLookingThrough() {
        class_5498 cameraType = Minecrft.options().method_31044();
        return cameraType == class_5498.field_26664 || cameraType == class_5498.field_26666;
    }

    public boolean controlsActive() {
        return Minecrft.get().field_1755 instanceof ViewfinderCameraControlsScreen;
    }

    public boolean canAttack() {
        if (!Config.Server.CAMERA_VIEWFINDER_ATTACK.get()) return false;
        if (camera.getHolder() instanceof CameraStandEntity) return false;
        return !camera.map(CameraItem::isInSelfieMode).orElse(false); // Attacking in selfie mode has weird anim.
    }

    public void openControlsScreen() {
        Preconditions.checkNotNull(camera, "No active camera");
        controlsScreen = createControlsScreen(camera);
        Minecrft.get().method_1507(controlsScreen);
    }

    public void close() {
        if (shader != null) {
            shader.close();
        }

        if (controlsActive()) {
            Minecrft.get().method_1507(null);
        }
    }

    public boolean keyPressed(int key, int scanCode, int action, int modifiers) {
        return (action == class_3675.field_31997 && keyBindings.keyPressed(key, scanCode, modifiers))
                || (action == class_3675.field_31998 && keyBindings.keyReleased(key, scanCode, modifiers))
                || zoom().keyPressed(key, scanCode, action, modifiers);
    }

    public boolean mouseClicked(int button, int action) {
        if (!isLookingThrough()) {
            return false;
        }

        if (controlsActive()) return false;

        if (!canAttack() && Minecrft.options().field_1886.method_1433(button))
            return true; // Block attacks

        if (KeyboardHandler.getCameraControlsKey().method_1433(button)) {
            openControlsScreen();
            return false; // Do not cancel the event to keep sneaking
        }

        if (Config.Client.VIEWFINDER_MIDDLE_CLICK_CONTROLS.get() && button == class_3675.field_32001) {
            openControlsScreen();
            return true;
        }

        return false;
    }

    public boolean mouseScrolled(double amount) {
        if (isLookingThrough() && !controlsActive()) {
            return zoom.mouseScrolled(amount);
        }
        return false;
    }

    public double modifyMouseSensitivity(double original) {
        if (!isLookingThrough()) {
            return original;
        }

        double scale = original / class_310.method_1551().field_1690.method_41808().method_41753();
        double scaledSensitivity = zoom.getCurrentFov() * scale;
        return class_3532.method_16436(Config.Client.VIEWFINDER_ZOOM_SENSITIVITY_INFLUENCE.get(), original, scaledSensitivity);
    }
}
