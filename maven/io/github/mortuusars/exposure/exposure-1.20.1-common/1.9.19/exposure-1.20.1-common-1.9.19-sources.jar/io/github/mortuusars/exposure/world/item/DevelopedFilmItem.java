package io.github.mortuusars.exposure.world.item;

import io.github.mortuusars.exposure.world.camera.ExposureType;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class DevelopedFilmItem extends class_1792 implements FilmItem {
    private final ExposureType type;

    public DevelopedFilmItem(ExposureType type, class_1793 properties) {
        super(properties);
        this.type = type;
    }

    @Override
    public ExposureType getType() {
        return type;
    }

    @Override
    public void method_7851(class_1799 stack, class_1937 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        int exposedFrames = getStoredFramesCount(stack);
        if (exposedFrames > 0) {
            tooltipComponents.add(class_2561.method_43469("item.exposure.developed_film.tooltip.frame_count", exposedFrames)
                    .method_27692(class_124.field_1080));
        }

        int frameSize = getFrameSize(stack);
        if (frameSize != getDefaultFrameSize(stack)) {
            tooltipComponents.add(class_2561.method_43469("item.exposure.film_roll.tooltip.frame_size",
                            class_2561.method_43470(String.format("%.1f", frameSize / 10f)))
                    .method_27692(class_124.field_1080));
        }
    }
}
