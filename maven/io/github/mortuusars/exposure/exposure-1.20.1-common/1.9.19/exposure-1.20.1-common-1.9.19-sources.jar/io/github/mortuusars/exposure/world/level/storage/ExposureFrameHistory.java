package io.github.mortuusars.exposure.world.level.storage;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import net.minecraft.class_1297;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_4844;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public class ExposureFrameHistory extends class_18 {
    public static final Codec<ExposureFrameHistory> CODEC = Codec.unboundedMap(class_4844.field_41525, Codec.list(Frame.CODEC)).stable()
            .xmap(ExposureFrameHistory::new, ExposureFrameHistory::getFrames);

    public static final int LIMIT = 32;

    private final Map<UUID, List<Frame>> frames;

    public ExposureFrameHistory(Map<UUID, List<Frame>> frames) {
        this.frames = new HashMap<>(frames);
    }

    public Map<UUID, List<Frame>> getFrames() {
        return frames;
    }

    public List<Frame> getFramesOf(class_1297 entity) {
        return getFramesOf(entity.method_5667());
    }

    public List<Frame> getFramesOf(UUID uuid) {
        return frames.getOrDefault(uuid, Collections.emptyList());
    }

    public void add(class_1297 entity, Frame frame) {
        add(entity.method_5667(), frame);
    }

    public void add(UUID uuid, Frame frame) {
        List<Frame> list = frames.compute(uuid, (id, framesList) ->
                framesList == null ? new ArrayList<>() : new ArrayList<>(framesList));
        while (list.size() >= LIMIT) {
            list.remove(0);
        }
        list.add(frame);
        method_80();
    }

    public void clear() {
        frames.clear();
    }

    public void clearOf(class_1297 entity) {
        frames.remove(entity.method_5667());
    }

    @Override
    public @NotNull class_2487 method_75(class_2487 tag) {
        DataResult<class_2520> encodingResult = CODEC.encode(this, class_2509.field_11560, tag);
        if (encodingResult.error().isEmpty()) {
            class_2520 encodedTag = encodingResult.get().left().get();
            if (encodedTag instanceof class_2487 encodedCompoundTag)
                return encodedCompoundTag;
            else {
                Exposure.LOGGER.error("Cannot save FramesHistory: '{}'. Encoded tag is not CompoundTag but a {}",
                        this, encodedTag.method_23258());
            }
        }
        encodingResult.error().ifPresent(error -> {
            Exposure.LOGGER.error("Cannot save FramesHistory: {}", error.message());
        });

        return tag;
    }

    public static ExposureFrameHistory load(class_2487 tag) {
        return CODEC.decode(class_2509.field_11560, tag).get().orThrow().getFirst();
    }

    public static @NotNull ExposureFrameHistory loadOrCreate(MinecraftServer server) {
        return server.method_30002().method_17983().method_17924(ExposureFrameHistory::load,() -> new ExposureFrameHistory(new HashMap<>()) ,"exposure_frame_history");
    }
}
