package io.github.mortuusars.exposure.network.packet.clientbound;

import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;

public record ExposureDataChunkResponseBytesS2CP(String id, int offset, byte[] bytes) implements Packet {
    public static final class_2960 ID = Exposure.resource("exposure_data_chunk_bytes");

    @Override
    public class_2960 getId() {
        return ID;
    }

    @Override
    public void toPacket(class_2540 buffer) {
        buffer.method_10814(id);
        buffer.writeInt(offset);
        buffer.method_10813(bytes);
    }

    public static ExposureDataChunkResponseBytesS2CP fromPacket(class_2540 buffer) {
        return new ExposureDataChunkResponseBytesS2CP(buffer.method_19772(), buffer.readInt(), buffer.method_10795());
    }

    @Override
    public boolean handle(class_2598 flow, class_1657 player) {
        ExposureClient.exposureStore().receiveChunkedResponseChunk(id, offset, bytes);
        return true;
    }
}
