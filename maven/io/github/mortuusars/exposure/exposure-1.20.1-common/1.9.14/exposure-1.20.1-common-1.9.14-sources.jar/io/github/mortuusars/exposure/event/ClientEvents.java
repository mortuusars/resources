package io.github.mortuusars.exposure.event;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.client.render.ItemFramePhotographRenderer;
import io.github.mortuusars.exposure.world.item.PhotographItem;
import net.minecraft.class_1533;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

public class ClientEvents {
    public static void levelUnloaded() {
    }

    public static void disconnect() {
        resetRenderData();
    }

    public static void resetRenderData() {
        ExposureClient.exposureStore().clear();
        ExposureClient.renderedExposures().clearCache();
        ExposureClient.imageRenderer().clearCache();
    }

    public static boolean renderItemFrameItem(class_1533 itemFrame, class_4587 poseStack, class_4597 buffer, int packedLight) {
        if (!Config.Client.PHOTOGRAPH_RENDERS_IN_ITEM_FRAME.get()) return false;
        if (!(itemFrame.method_6940().method_7909() instanceof PhotographItem photographItem)) return false;
        if (photographItem.getFrame(itemFrame.method_6940()).identifier().isEmpty()) return false;

        poseStack.method_22903();
        poseStack.method_22905(2F, 2F, 2F);
        ItemFramePhotographRenderer.render(itemFrame, poseStack, buffer, packedLight, photographItem, itemFrame.method_6940());
        poseStack.method_22909();

        return true;
    }

    public static void resourcesReloaded() {
        ExposureClient.exposureStore().clear();
        ExposureClient.renderedExposures().clearCache();
        ExposureClient.imageRenderer().clearCache();
    }
}
