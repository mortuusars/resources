package io.github.mortuusars.exposure.world.entity;

import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.client.camera.CameraClient;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.network.Packets;
import io.github.mortuusars.exposure.network.packet.clientbound.CameraStandSetRotationsS2CP;
import io.github.mortuusars.exposure.network.packet.clientbound.CameraStandStopControllingS2CP;
import io.github.mortuusars.exposure.world.camera.CameraId;
import io.github.mortuusars.exposure.world.inventory.CameraOnStandAttachmentsMenu;
import io.github.mortuusars.exposure.world.item.InterplanarProjectorItem;
import io.github.mortuusars.exposure.world.item.camera.Attachment;
import io.github.mortuusars.exposure.world.item.camera.CameraItem;
import io.github.mortuusars.exposure.world.sound.Sound;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1542;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1688;
import net.minecraft.class_1690;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3908;
import net.minecraft.class_5712;

public class CameraStandEntity extends class_1297 implements CameraHolder {
    protected static final class_2940<Integer> DATA_ID_HURT =
            class_2945.method_12791(CameraStandEntity.class, class_2943.field_13327);
    protected static final class_2940<Integer> DATA_ID_HURTDIR =
            class_2945.method_12791(CameraStandEntity.class, class_2943.field_13327);
    protected static final class_2940<Float> DATA_ID_DAMAGE =
            class_2945.method_12791(CameraStandEntity.class, class_2943.field_13320);
    protected static final class_2940<class_1799> DATA_ID_CAMERA =
            class_2945.method_12791(CameraStandEntity.class, class_2943.field_13322);
    protected static final class_2940<Integer> DATA_ID_COOLDOWN_TIME =
            class_2945.method_12791(CameraStandEntity.class, class_2943.field_13327);
    protected static final class_2940<Integer> DATA_ID_COOLDOWN =
            class_2945.method_12791(CameraStandEntity.class, class_2943.field_13327);
    protected static final class_2940<Integer> DATA_ID_OPERATOR_ID =
            class_2945.method_12791(CameraStandEntity.class, class_2943.field_13327);
    protected static final class_2940<Boolean> DATA_ID_MALFUNCTIONED =
            class_2945.method_12791(CameraStandEntity.class, class_2943.field_13323);

    protected static final Predicate<class_1297> RIDABLE_MINECARTS = entity -> entity instanceof class_1688
            && ((class_1688) entity).method_7518() == class_1688.class_1689.field_7674;

    protected CameraStandRedstoneControl redstoneControl = new CameraStandRedstoneControl(this);
    protected UUID ownerPlayerId = class_156.field_25140;

    public CameraStandEntity(class_1299<? extends CameraStandEntity> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Override
    protected void method_5693() {
        field_6011.method_12784(DATA_ID_HURT, 0);
        field_6011.method_12784(DATA_ID_HURTDIR, 1);
        field_6011.method_12784(DATA_ID_DAMAGE, 0.0F);
        field_6011.method_12784(DATA_ID_CAMERA, class_1799.field_8037);
        field_6011.method_12784(DATA_ID_OPERATOR_ID, -1);
        field_6011.method_12784(DATA_ID_COOLDOWN_TIME, 0);
        field_6011.method_12784(DATA_ID_COOLDOWN, 0);
        field_6011.method_12784(DATA_ID_MALFUNCTIONED, false);
    }

    @Override
    public void method_5674(class_2940<?> dataAccessor) {
        if (dataAccessor.equals(DATA_ID_CAMERA)) {
            class_1799 camera = getCamera();
            if (!camera.method_7960()) {
                camera.method_27320(this);
            }
        }
    }

    @Override
    protected void method_5652(class_2487 tag) {
        tag.method_10569("CooldownTime", getCooldownTime());
        tag.method_10569("Cooldown", getCooldown());
        tag.method_10556("Malfunctioned", isMalfunctioned());
        if (!getCamera().method_7960()) {
            tag.method_10566("Camera", getCamera().method_7953(new class_2487()));
        }

        redstoneControl.save(tag);

        if (!ownerPlayerId.equals(class_156.field_25140)) {
            tag.method_25927("Owner", ownerPlayerId);
        }
    }

    @Override
    protected void method_5749(class_2487 tag) {
        setCooldownTime(tag.method_10550("CooldownTime"));
        setCooldown(tag.method_10550("Cooldown"));
        setMalfunctioned(tag.method_10577("Malfunctioned"));
        setCamera(class_1799.method_7915(tag.method_10562("Camera")));

        redstoneControl.load(tag);

        if (tag.method_10573("Owner", class_2487.field_33261)) {
            ownerPlayerId = tag.method_25926("Owner");
        }
    }

    // -- Camera

    public class_1799 getCamera() {
        return method_5841().method_12789(DATA_ID_CAMERA);
    }

    public void setCamera(class_1799 cameraStack) {
        if (!isClientSide() && (cameraStack.method_7960() || !CameraId.ofStack(getCamera()).matches(cameraStack))) {
            method_37908().method_18456().stream()
                    .filter(pl -> pl instanceof class_3222 && pl.field_7512 instanceof CameraOnStandAttachmentsMenu)
                    .forEach(pl -> ((class_3222) pl).method_7346());
        }

        method_5841().method_12778(DATA_ID_CAMERA, cameraStack);
    }

    public boolean isCameraActive() {
        return getCamera().method_7909() instanceof CameraItem cameraItem && cameraItem.isActive(getCamera());
    }

    public Optional<class_1657> getOwnerPlayer() {
        return Optional.ofNullable(method_37908().method_18470(ownerPlayerId));
    }

    public UUID getOwnerPlayerUuid() {
        return ownerPlayerId;
    }

    public void setOwnerPlayer(class_1657 player) {
        this.ownerPlayerId = player.method_5667();
    }

    public Optional<? extends class_1657> getClosestPlayerInRange() {
        return method_37908().method_18456().stream()
                .min(Comparator.comparingDouble(player -> player.method_5739(this)))
                .filter(this::isInRangeForPhoto);
    }

    public int getCooldownTime() {
        return method_5841().method_12789(DATA_ID_COOLDOWN_TIME);
    }

    public void setCooldownTime(int cooldown) {
        method_5841().method_12778(DATA_ID_COOLDOWN_TIME, cooldown);
    }

    public int getCooldown() {
        return method_5841().method_12789(DATA_ID_COOLDOWN);
    }

    public void setCooldown(int cooldown) {
        method_5841().method_12778(DATA_ID_COOLDOWN, cooldown);
    }

    public void startCooldown(int cooldown) {
        setCooldownTime(cooldown);
        setCooldown(cooldown);
    }

    public boolean isOnCooldown() {
        return getCooldown() > 0;
    }

    public float getCooldownPercent() {
        float cooldownTime = getCooldownTime();
        float cooldown = getCooldown();
        return class_3532.method_15363(cooldown / cooldownTime, 0.0F, 1.0F);
    }

    public boolean isMalfunctioned() {
        return method_5841().method_12789(DATA_ID_MALFUNCTIONED);
    }

    public void setMalfunctioned(boolean malfunctioned) {
        method_5841().method_12778(DATA_ID_MALFUNCTIONED, malfunctioned);
    }

    // -- Operator

    public int getOperatorId() {
        return method_5841().method_12789(DATA_ID_OPERATOR_ID);
    }

    public @Nullable CameraOperator operator() {
        int id = getOperatorId();
        return id >= 0 && method_37908().method_8469(id) instanceof CameraOperator operator ? operator : null;
    }

    public void setOperator(@Nullable CameraOperator operator) {
        method_5841().method_12778(DATA_ID_OPERATOR_ID, operator != null ? operator.asOperatorEntity().method_5628() : -1);
    }

    // -- Holder

    public boolean isInRangeForPhoto(class_1657 player) {
        return player.method_5739(this) < Config.Server.CAMERA_STAND_WORKING_RANGE.get();
    }

    @Override
    public Optional<class_1657> getPlayerExecutingExposure() {
        if (Config.Server.CAMERA_STAND_FALLBACK_TO_OTHER_PLAYERS.get()) {
            return getOwnerPlayer().filter(this::isInRangeForPhoto).or(this::getClosestPlayerInRange);
        } else {
            return getOwnerPlayer().filter(this::isInRangeForPhoto);
        }
    }

    @Override
    public Optional<class_1657> getPlayerAwardedForExposure() {
        return getOwnerPlayer().or(this::getClosestPlayerInRange);
    }

    @Override
    public @NotNull class_1297 getExposureAuthorEntity() {
        return getOwnerPlayer().or(this::getClosestPlayerInRange).map(pl -> (class_1297) pl).orElse(this);
    }

    @Override
    public Optional<CameraOperator> getExposureCameraOperator() {
        return Optional.ofNullable(operator());
    }

    // -- Interact

    public boolean isInInteractionRange(class_1309 entity) {
        double range = 5;//todo entity.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE);
        return this.method_5829().method_49271(entity.method_33571()) < range * range;
    }

    @Override
    public @NotNull class_1269 method_5688(class_1657 player, class_1268 hand) {
        if (!canUse(player)) {
            player.method_7353(class_2561.method_43471("gui.exposure.camera_stand.error.in_use")
                    .method_27692(class_124.field_1061), true);
            return class_1269.field_5814;
        }

        if (isMalfunctioned()) {
            if (!isClientSide()) {
                setMalfunctioned(false);
                player.method_7353(class_2561.method_43471("gui.exposure.camera_stand.malfunction_fixed"), true);
                method_5783(class_3417.field_22463, 0.9f, 1.3f);
                showRepairingParticles();
            }

            return class_1269.field_5812;
        }

        class_1799 handStack = player.method_5998(hand);
        class_1799 cameraStack = getCamera();

        if (handStack.method_31574(class_1802.field_8688) && !cameraStack.method_7960()) {
            malfunction();
            return class_1269.field_5812;
        }

        if (cameraStack.method_7960() && handStack.method_7909() instanceof CameraItem) {
            setCamera(handStack);
            player.method_6122(hand, class_1799.field_8037);

            if (!isClientSide()) {
                playCameraSetSound();
            }

            // Set initial camera direction.
            if (method_36454() == 0 && method_36455() == 0) { // If rotations are at 0 - player likely hasn't chosen a direction yet.
                method_36456(class_3532.method_15393(player.method_36454()));
                if (!isClientSide()) {
                    syncRotationToClients();
                }
            }

            return class_1269.field_5812;
        }

        if (cameraStack.method_7960()) return class_1269.field_5811;
        if (!(cameraStack.method_7909() instanceof CameraItem cameraItem)) return class_1269.field_5811;

        if (PlatformHelper.isCreateDeployer(player, hand)) {
            if (Config.Server.CREATE_DEPLOYER_STAND_HOTSWAP.get()) {
                return handleSneakInteraction(player, hand, cameraItem, cameraStack, handStack);
            }
            return class_1269.field_21466;
        }

        if (player.method_21823()) {
            return handleSneakInteraction(player, hand, cameraItem, cameraStack, handStack);
        }

        startControlling(player, cameraItem);
        return class_1269.field_21466; // To not cause arm swing, which causes viewfinder use/attack animation.
    }

    protected class_1269 handleSneakInteraction(class_1657 player, class_1268 hand, CameraItem cameraItem, class_1799 cameraStack, class_1799 handStack) {
        if (isOnCooldown()) return class_1269.field_5814;
        if (cameraItem.getShutter().isOpen(cameraStack)) return class_1269.field_5814;

        if (handStack.method_7960() && cameraItem.hasAttachmentsMenu()) {
            return openAttachmentsMenu(player, hand);
        }

        class_1269 result = cameraItem.handleStandSneakInteraction(this, player, hand, cameraStack);
        if (result == class_1269.field_5814) {
            return class_1269.field_5814;
        }

        if (result == class_1269.field_5811) {
            return cameraItem.hasAttachmentsMenu()
                    ? openAttachmentsMenu(player, hand)
                    : class_1269.field_5811;
        }

        cameraItem.getTimer().stop(cameraStack);

        forceUpdate();
        return result;
    }

    public boolean canUse(class_1657 player) {
        return (operator() == null || player.equals(operator())) && method_37908().method_18456().stream()
                .filter(pl -> !pl.equals(player))
                .noneMatch(pl -> pl.field_7512 instanceof CameraOnStandAttachmentsMenu);
    }

    public class_1269 openAttachmentsMenu(class_1657 player, class_1268 hand) {
        if (!canUse(player)) {
            player.method_7353(class_2561.method_43471("gui.exposure.camera_stand.error.in_use")
                    .method_27692(class_124.field_1061), true);
            return class_1269.field_5814;
        }

        class_1799 cameraStack = getCamera();

        if (cameraStack.method_7960() || !(cameraStack.method_7909() instanceof CameraItem cameraItem))
            return class_1269.field_5814;

        if (cameraItem.getShutter().isOpen(cameraStack)) {
            player.method_7353(class_2561.method_43471("item.exposure.camera.camera_attachments.fail.shutter_open")
                    .method_27692(class_124.field_1061), true);
            return class_1269.field_5814;
        }

        cameraItem.getOrCreateId(cameraStack);

        if (player instanceof class_3222 serverPlayer) {
            setOperator(serverPlayer);
            cameraItem.getTimer().stop(cameraStack);

            class_3908 menuProvider = new class_3908() {
                @Override
                public @NotNull class_2561 method_5476() {
                    return cameraStack.method_7964();
                }

                @Override
                public @NotNull class_1703 createMenu(int containerId, @NotNull class_1661 playerInventory, @NotNull class_1657 player) {
                    return new CameraOnStandAttachmentsMenu(containerId, playerInventory, CameraStandEntity.this);
                }
            };

            forceUpdate();

            PlatformHelper.openMenu(serverPlayer, menuProvider,
                    buffer -> buffer.writeInt(method_5628()));
        }

        cameraItem.setDisassembled(cameraStack, true);
        Sound.play(player, Exposure.SoundEvents.CAMERA_GENERIC_CLICK.get(), class_3419.field_15248, 0.9f, 0.9f, 0.2f);

        return class_1269.field_5812;
    }

    public void startControlling(class_1657 player, CameraItem cameraItem) {
        cameraItem.activateOnStand(player, getCamera(), this);
        setOperator(player);

        if (getOwnerPlayerUuid().equals(class_156.field_25140)) {
            setOwnerPlayer(player);
        }

        if (isClientSide()) {
            CameraClient.setCameraEntity(this);
            Minecrft.stopPlayerMovement();
        } else {
            forceUpdate();
        }
    }

    public void stopControlling() {
        if (getCamera().method_7909() instanceof CameraItem cameraItem && cameraItem.isActive(getCamera())) {
            cameraItem.deactivate(this, getCamera());
        }
        if (operator() != null) {
            if (isClientSide()) {
                CameraClient.resetCameraEntity();
            } else if (operator() instanceof class_3222 serverPlayer) {
                // This method is usually called on both sides, but in the case of client/server desync,
                // (which is sometimes happening on contraptions)
                // this will ensure that client will be updated properly, otherwise cameraEntity will not be set back to player.
                Packets.sendToClient(new CameraStandStopControllingS2CP(this.method_5628()), serverPlayer);
            }
        }
        setOperator(null);

        if (!isClientSide()) {
            forceUpdate();
        }
    }

    public void release() {
        if (!isMalfunctioned() && !isOnCooldown() && getCamera().method_7909() instanceof CameraItem cameraItem) {
            getPlayerExecutingExposure()
                    .filter(player -> !shouldMalfunction(player))
                    .ifPresentOrElse(
                            player -> cameraItem.release(this, getCamera()),
                            this::malfunction);
            forceUpdate();
        }
    }

    protected boolean shouldMalfunction(class_1657 player) {
        if (!Config.Server.CAMERA_STAND_FALLBACK_TO_OTHER_PLAYERS_PROJECTOR.get()
                && Attachment.FILTER.get(getCamera()).getItem() instanceof InterplanarProjectorItem
                && !player.method_5667().equals(getOwnerPlayerUuid())) {
            return true;
        }

        return false;
    }

    protected void malfunction() {
        if (getCamera().method_7960()) return;
        if (!Config.Server.CAMERA_STAND_RANGE_MALFUNCTION.get()) return;
        stopControlling();
        setMalfunctioned(true);
        method_43077(Exposure.SoundEvents.CAMERA_GENERIC_CLICK.get());
    }

    // --

    @Override
    public void method_5773() {
        super.method_5773();
        travel();
        checkForBoats();
        checkForMinecarts();
        pushEntities();

        if (getHurtTime() > 0) {
            setHurtTime(getHurtTime() - 1);
        }

        if (getDamage() > 0.0F) {
            setDamage(getDamage() - 1.0F);
        }

        int cooldown = getCooldown();
        if (cooldown > 0) {
            setCooldown(cooldown - 1);
        }

        if (isClientSide()) {
            return;
        }

        redstoneControl.tick();

        if (getCamera().method_7909() instanceof CameraItem cameraItem && cameraItem.tick(this, getCamera())) {
            forceUpdate();
        }

        @Nullable CameraOperator operator = operator();
        if (operator == null) {
            if (getCamera().method_7909() instanceof CameraItem cameraItem && cameraItem.isActive(getCamera())) {
                cameraItem.deactivate(this, getCamera());
            }
        } else {
            if (!isInInteractionRange(operator.asOperatorEntity())) {
                stopControlling();
            } else if (!isCameraActive() && !(operator instanceof class_1657 player
                    && player.field_7512 instanceof CameraOnStandAttachmentsMenu)) {
                stopControlling();
            }
        }
    }

    protected void travel() {
        this.field_6014 = this.method_23317();
        this.field_6036 = this.method_23318();
        this.field_5969 = this.method_23321();

        //this.applyGravity();

        if (this.method_5799() && this.method_5861(class_3486.field_15517) > 0.1F) {
            this.setUnderwaterMovement();
        } else if (this.method_5771() && this.method_5861(class_3486.field_15518) > 0.1F) {
            this.setUnderLavaMovement();
        }

        if (this.method_37908().field_9236) {
            this.field_5960 = false;
        } else {
            this.field_5960 = !this.method_37908().method_8587(this, this.method_5829().method_1011(1.0E-7));
            if (this.field_5960) {
                this.method_5632(this.method_23317(), (this.method_5829().field_1322 + this.method_5829().field_1325) / 2.0, this.method_23321());
            }
        }

        if (!this.method_24828() || this.method_18798().method_37268() > 1.0E-5F || (this.field_6012 + this.method_5628()) % 4 == 0) {
            this.method_5784(class_1313.field_6308, this.method_18798());
            float f = 0.98F;
            if (this.method_24828()) {
                f = this.method_37908().method_8320(this.method_23314()).method_26204().method_9499() * 0.98F;
            }

            this.method_18799(this.method_18798().method_18805(f, 0.98, f));
            if (this.method_24828()) {
                class_243 vec32 = this.method_18798();
                if (vec32.field_1351 < 0.0) {
                    this.method_18799(vec32.method_18805(1.0, -0.5, 1.0));
                }
            }
        }
    }

    protected void setUnderwaterMovement() {
        class_243 vec3 = this.method_18798();
        this.method_18800(vec3.field_1352 * 0.9F, vec3.field_1351 * 0.23F, vec3.field_1350 * 0.9F);
    }

    protected void setUnderLavaMovement() {
        class_243 vec3 = this.method_18798();
        this.method_18800(vec3.field_1352 * 0.5F, vec3.field_1351 * 0.1F, vec3.field_1350 * 0.5F);
    }

    protected void checkForBoats() {
        if (!isClientSide() && !method_5765()) {
            List<class_1297> boats = method_37908().method_8333(this, method_5829().method_1009(0.4F, 0.2F, 0.4F),
                    e -> e instanceof class_1690);
            for (class_1297 entity : boats) {
                class_1690 boat = ((class_1690) entity);
                if (boat.method_5685().size() < 2 && boat.method_49182(this)) {
                    this.method_5804(boat);
                }
            }
        }
    }

    protected void checkForMinecarts() {
        if (!isClientSide() && !method_5765()) {
            List<class_1297> minecarts = method_37908().method_8333(this, method_5829().method_1009(0.4F, 0.2F, 0.4F),
                    e -> e instanceof class_1688 cart && cart.method_7518() == class_1688.class_1689.field_7674);
            for (class_1297 entity : minecarts) {
                class_1688 minecart = ((class_1688) entity);
                if (!minecart.method_5782()) {
                    this.method_5804(minecart);
                }
            }
        }
    }

    protected void pushEntities() {
        for (class_1297 entity : this.method_37908().method_8333(this, this.method_5829(), RIDABLE_MINECARTS)) {
            if (this.method_5858(entity) <= 0.2) {
                entity.method_5697(this);
            }
        }
    }

    // -- Hurt

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (method_31481()) return true;
        if (method_5679(source)) return false;

        method_5785();

        if (!getCamera().method_7960()) {
            if (!isClientSide()) {
                @Nullable class_1542 itemEntity = method_5699(getCamera(), method_5751());
                if (itemEntity != null) {
                    itemEntity.method_6982(5);
                }
                playCameraRemoveSound();
            }
            setCamera(class_1799.field_8037);

            if (source.method_5530()) {
                return true; // Prevent discard at the same hit as removing the camera.
            }

            amount = 1.0f; // Prevent one-hit harvesting.
        }

        if (!isClientSide()) {
            setHurtDir(-getHurtDir());
            setHurtTime(10);
            method_5785();
            setDamage(getDamage() + amount * 10.0F);
            method_32875(class_5712.field_28736, source.method_5529());
            playHitSound();

            if (source.method_5530()) {
                method_31472();
                showBreakingParticles();
                playBreakSound();
            } else if (getDamage() > 10.0F) {
                destroy(source);
                showBreakingParticles();
                playBreakSound();
            }

        }

        return true;
    }

    public void setHurtTime(int hurtTime) {
        this.field_6011.method_12778(DATA_ID_HURT, hurtTime);
    }

    public void setHurtDir(int hurtDir) {
        this.field_6011.method_12778(DATA_ID_HURTDIR, hurtDir);
    }

    public void setDamage(float damage) {
        this.field_6011.method_12778(DATA_ID_DAMAGE, damage);
    }

    public float getDamage() {
        return this.field_6011.method_12789(DATA_ID_DAMAGE);
    }

    public int getHurtTime() {
        return this.field_6011.method_12789(DATA_ID_HURT);
    }

    public int getHurtDir() {
        return this.field_6011.method_12789(DATA_ID_HURTDIR);
    }

    protected void destroy(class_1282 source) {
        this.destroy(this.getDropItem());
    }

    public void destroy(class_1792 dropItem) {
        this.method_5768();
        if (this.method_37908().method_8450().method_8355(class_1928.field_19393)) {
            class_1799 itemStack = new class_1799(dropItem);
            itemStack.method_7977(this.method_5797());
            this.method_5699(itemStack, 0.5f);
        }
    }

    protected void showBreakingParticles() {
        if (this.method_37908() instanceof class_3218) {
            ((class_3218) this.method_37908())
                    .method_14199(
                            new class_2388(class_2398.field_11217, class_2246.field_10161.method_9564()),
                            this.method_23317(),
                            this.method_23323(0.25f),
                            this.method_23321(),
                            6,
                            (this.method_17681() / 6.0F),
                            (this.method_17682() / 6.0F),
                            (this.method_17681() / 6.0F),
                            0.05
                    );
        }
    }

    protected void showRepairingParticles() {
        if (this.method_37908() instanceof class_3218) {
            ((class_3218) this.method_37908())
                    .method_14199(
                            new class_2388(class_2398.field_11217, class_2246.field_10312.method_9564()),
                            this.method_23317(),
                            this.method_23323(0.75f),
                            this.method_23321(),
                            4,
                            (this.method_17681() / 8.0F),
                            (this.method_17682() / 8.0F),
                            (this.method_17681() / 8.0F),
                            0.05
                    );
        }
    }

    protected class_1792 getDropItem() {
        return Exposure.Items.CAMERA_STAND.get();
    }

    // --

    @Override
    public boolean method_5863() {
        return true;
    }

    @Nullable
    @Override
    public class_1799 method_31480() {
        return new class_1799(getDropItem());
    }

    @Override
    public @NotNull class_3419 method_5634() {
        return class_3419.field_15245;
    }

    public void playPlaceSound() {
        this.method_37908().method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(),
                Exposure.SoundEvents.CAMERA_STAND_PLACE.get(), this.method_5634(), 0.8F, 1.0F);
    }

    public void playHitSound() {
        this.method_37908().method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(),
                Exposure.SoundEvents.CAMERA_STAND_HIT.get(), this.method_5634(), 0.8F, 1.0F);
    }

    public void playBreakSound() {
        this.method_37908().method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(),
                Exposure.SoundEvents.CAMERA_STAND_BREAK.get(), this.method_5634(), 1.0F, 1.0F);
    }

    public void playCameraSetSound() {
        this.method_37908().method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(),
                Exposure.SoundEvents.CAMERA_STAND_SET_CAMERA.get(), this.method_5634(), 0.8F, 1.0F);
    }

    public void playCameraRemoveSound() {
        this.method_37908().method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(),
                Exposure.SoundEvents.CAMERA_STAND_REMOVE_CAMERA.get(), this.method_5634(), 0.8F, 1.0F);
    }

    /**
     * Forces data sync to the client.
     */
    public void forceUpdate() {
        method_5841().method_49743(DATA_ID_CAMERA, getCamera(), true);
    }

    public boolean isClientSide() {
        return method_37908().field_9236;
    }

    @Override
    public boolean method_5787() {
        return operator() instanceof class_1657 player && player.method_7340() || super.method_5787();
    }

    // --

    //@Override
    public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps) {
        this.method_5814(x, y, z);
        // this method is called when client receives packet from server,
        // and it makes camera rotation jump around and be janky.
        // we sync rotations manually instead
        // this.setRot(yRot, xRot);
    }

    public void syncRotationToClientsIfNeeded() {
        if (isClientSide()) return;
        if (operator() != null || (field_6012 % 10 == 0)) {
            syncRotationToClients();
        }
    }

    public void syncRotationToClients() {
        Packets.sendToClients(new CameraStandSetRotationsS2CP(this.method_5628(), method_36454(), method_36455()), pl -> !pl.equals(operator()));
    }
}
