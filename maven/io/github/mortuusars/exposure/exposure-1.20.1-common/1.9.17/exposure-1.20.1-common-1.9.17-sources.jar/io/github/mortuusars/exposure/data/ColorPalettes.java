package io.github.mortuusars.exposure.data;

import io.github.mortuusars.exposure.Exposure;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6880;

public class ColorPalettes {
    public static final class_5321<ColorPalette> DEFAULT = createKey(Exposure.resource("map_colors_plus"));
    public static final class_5321<ColorPalette> MAP_COLORS = createKey(Exposure.resource("map_colors"));

    public static class_5321<ColorPalette> createKey(class_2960 location) {
        return class_5321.method_29179(Exposure.Registries.COLOR_PALETTE, location);
    }

    public static class_6880<ColorPalette> get(class_5455 registryAccess, class_5321<ColorPalette> key) {
        class_2378<ColorPalette> registry = registryAccess.method_30530(Exposure.Registries.COLOR_PALETTE);
        return registry.method_40264(key).or(() -> registry.method_40264(DEFAULT)).orElseThrow();
    }

    public static class_6880<ColorPalette> get(class_5455 registryAccess, class_2960 key) {
        return get(registryAccess,createKey(key));
    }

    public static class_6880<ColorPalette> getDefault(class_5455 registryAccess) {
        return get(registryAccess, DEFAULT);
    }
}
