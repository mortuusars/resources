package io.github.mortuusars.exposure.world.item;

import com.google.common.base.Preconditions;
import io.github.mortuusars.exposure.Config;
import io.github.mortuusars.exposure.Exposure;
import io.github.mortuusars.exposure.PlatformHelper;
import io.github.mortuusars.exposure.data.ColorPalette;
import io.github.mortuusars.exposure.data.ColorPalettes;
import io.github.mortuusars.exposure.world.camera.ExposureType;
import io.github.mortuusars.exposure.client.gui.ClientGUI;
import io.github.mortuusars.exposure.world.camera.film.properties.FilmProperties;
import io.github.mortuusars.exposure.world.camera.film.properties.FilmStyle;
import io.github.mortuusars.exposure.world.camera.frame.Frame;
import io.github.mortuusars.exposure.world.inventory.ItemRenameMenu;
import io.github.mortuusars.exposure.world.item.interfaces.DefaultFilmStyle;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3908;

public class FilmRollItem extends class_1792 implements SensitiveFilmItem, DefaultFilmStyle {
    public static final int BAR_BLACK_AND_WHITE = class_3532.method_15353(0.8F, 0.8F, 0.9F);
    public static final int BAR_COLOR = class_3532.method_15353(0.4F, 0.4F, 1.0F);

    protected final ExposureType type;
    protected final int barColor;
    private final FilmStyle filmStyle;

    public FilmRollItem(ExposureType type, int barColor, class_1793 properties, FilmStyle filmStyle) {
        super(properties);
        this.type = type;
        this.barColor = barColor;
        this.filmStyle = filmStyle;
    }

    @Override
    public FilmStyle getDefaultFilmStyle() {
        return filmStyle;
    }

    @Override
    public ExposureType getType() {
        return type;
    }

    // --

    public boolean canAddFrame(class_1799 stack) {
        return getStoredFramesCount(stack) < getMaxFrameCount(stack);
    }

    public void addFrame(class_1799 stack, Frame frame) {
        Preconditions.checkState(getStoredFramesCount(stack) < getMaxFrameCount(stack),
                "Cannot add more frames than film could fit. Size: " + getMaxFrameCount(stack));

        List<Frame> frames = new ArrayList<>(Exposure.DataComponents.getFilmFrames(stack, Collections.emptyList()));
        frames.add(frame);

        Exposure.DataComponents.setFilmFrames(stack, frames);
    }

    // --

    @Override
    public void method_7851(class_1799 stack, class_1937 context, List<class_2561> list, class_1836 tooltipFlag) {
        int exposedFrames = getStoredFramesCount(stack);
        if (exposedFrames > 0) {
            int totalFrames = getMaxFrameCount(stack);
            list.add(class_2561.method_43469("item.exposure.film_roll.tooltip.frame_count", exposedFrames, totalFrames)
                    .method_27692(class_124.field_1080));
        }

        addFrameSizeToTooltip(stack, list);

        if (tooltipFlag.method_8035()) {
            addPaletteToTooltip(stack, list);
            addStyleToTooltip(stack, list);
        }

        if (Config.Server.FILM_ROLL_EASY_RENAMING.get()) {
            list.add(class_2561.method_43471("item.exposure.film_roll.tooltip.renaming"));
        }

        //noinspection ConstantValue
        if (exposedFrames > 0 && !PlatformHelper.isModLoaded("jei") && Config.Client.RECIPE_TOOLTIPS_WITHOUT_JEI.get()) {
            ClientGUI.addFilmRollDevelopingTooltip(stack, context, list, tooltipFlag);
        }
    }

    @Override
    public @NotNull class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        if (!Config.Server.FILM_ROLL_EASY_RENAMING.get() || !(player instanceof class_3222 serverPlayer)) {
            return super.method_7836(level, player, usedHand);
        }

        int slot = getMatchingSlotInInventory(player.method_31548(), player.method_5998(usedHand));
        class_3908 menuProvider = new class_3908() {
            @Override
            public @NotNull class_2561 method_5476() {
                return class_2561.method_43471("gui.exposure.item_rename.title");
            }

            @Override
            public @NotNull class_1703 createMenu(int containerId, @NotNull class_1661 playerInventory, @NotNull class_1657 player) {
                return new ItemRenameMenu(containerId, playerInventory, slot);
            }
        };
        PlatformHelper.openMenu(serverPlayer, menuProvider, buffer -> buffer.writeInt(slot));
        return class_1271.method_22427(player.method_5998(usedHand));
    }

    // -- Bar

    @Override
    public int method_31571(@NotNull class_1799 stack) {
        return barColor;
    }

    @Override
    public boolean method_31567(@NotNull class_1799 stack) {
        return hasFrames(stack);
    }

    @Override
    public int method_31569(@NotNull class_1799 stack) {
        return Math.min(1 + 12 * getStoredFramesCount(stack) / getMaxFrameCount(stack), 13);
    }

    // --

    protected int getMatchingSlotInInventory(class_1661 inventory, class_1799 stack) {
        for (int i = 0; i < inventory.method_5439(); i++) {
            if (inventory.method_5438(i).equals(stack)) {
                return i;
            }
        }
        return -1;
    }
}
