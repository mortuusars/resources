package io.github.mortuusars.exposure.client.task;

import io.github.mortuusars.exposure.ExposureClient;
import io.github.mortuusars.exposure.client.util.Minecrft;
import io.github.mortuusars.exposure.util.cycles.task.Task;

import java.util.concurrent.CompletableFuture;

public class ClearStaleRenderedImagesIndefiniteTask extends Task<Void> {
    private final CompletableFuture<Void> future = new CompletableFuture<>();

    @Override
    public CompletableFuture<Void> execute() {
        return future;
    }

    @Override
    public void tick() {
        if (Minecrft.get().field_1687 != null && Minecrft.get().field_1687.method_8510() % 2400 == 0) { // 2 minutes
            ExposureClient.renderedExposures().clearStale();
        }
    }
}
