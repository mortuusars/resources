package io.github.mortuusars.exposure.mixin.client;

import io.github.mortuusars.exposure.client.input.KeyboardHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(net.minecraft.class_309.class)
public abstract class KeyboardHandlerMixin {
    @Inject(method = "keyPress", at = @At(value = "HEAD"), cancellable = true)
    private void keyPress(long windowPointer, int key, int scanCode, int action, int modifiers, CallbackInfo ci) {
        if (KeyboardHandler.handleKeyPress(windowPointer, key, scanCode, action, modifiers))
            ci.cancel();
    }
}
