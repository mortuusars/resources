package io.github.mortuusars.thief.advancement.trigger;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2048;
import net.minecraft.class_2073;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public class VillagerGiftTrigger extends class_4558<VillagerGiftTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player, class_1309 entity, class_1799 giftStack) {
        this.method_22510(player, triggerInstance ->
                triggerInstance.matches(player, entity, giftStack));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  Optional<class_5258> entity,
                                  Optional<class_2073> gift) implements class_4558.class_8788 {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                        class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::comp_2029),
                        class_2048.field_47250.optionalFieldOf("entity").forGetter(TriggerInstance::entity),
                        class_2073.field_45754.optionalFieldOf("gift").forGetter(TriggerInstance::gift))
                .apply(instance, TriggerInstance::new));

        public boolean matches(class_3222 player,
                               class_1309 entity,
                               class_1799 gift) {
            return (this.entity.isEmpty() || this.entity.get().method_27806(class_2048.method_27802(player, entity)))
                    && (this.gift.isEmpty() || this.gift.get().method_8970(gift));
        }
    }
}