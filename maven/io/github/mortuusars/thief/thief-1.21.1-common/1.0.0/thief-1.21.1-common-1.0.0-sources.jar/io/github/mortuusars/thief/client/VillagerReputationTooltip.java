package io.github.mortuusars.thief.client;

import io.github.mortuusars.thief.Config;
import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.network.Packets;
import io.github.mortuusars.thief.network.packet.serverbound.QueryVillagerReputationC2SP;
import io.github.mortuusars.thief.world.Reputation;
import java.util.ArrayList;
import net.minecraft.class_1646;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3966;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_9779;

public class VillagerReputationTooltip {
    private static int lastVillagerId = -1;
    private static long lastRequestTime = -1L;
    private static int lastReputation = 0;

    // Gossips
    private static int lastGossipsVillagerId = -1;
    private static int lastMajorNegative;
    private static int lastMinorNegative;
    private static int lastMinorPositive;
    private static int lastMajorPositive;
    private static int lastTrading;

    public static void render(class_332 guiGraphics, class_9779 deltaTracker) {
        if (!Config.Client.SHOW_VILLAGER_REPUTATION_TOOLTIP.get()) return;

        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1687 == null || minecraft.field_1724 == null || minecraft.field_1724.method_7325() || minecraft.field_1755 != null
                || !minecraft.field_1724.method_6047().method_31573(Thief.Tags.Items.VILLAGER_GIFTS)
                || !(minecraft.field_1765 instanceof class_3966 entityHitResult)
                || !(entityHitResult.method_17782() instanceof class_1646 villager)) {
            return;
        }

        long gameTime = minecraft.field_1687.method_8510();
        if (gameTime - lastRequestTime > 5) {
            Packets.sendToServer(new QueryVillagerReputationC2SP(villager.method_5628(), class_310.method_1551().field_1690.field_1827));
            lastRequestTime = gameTime;
        }

        if (lastVillagerId != villager.method_5628()) {
            return;
        }

        Reputation reputation = Reputation.fromValue(lastReputation);

        class_5250 name = reputation.getLocalizedNameWithColor();
        if (class_310.method_1551().field_1690.field_1827) {
            name.method_27693(" (" + lastReputation + ")");
        }

        ArrayList<class_5481> lines = new ArrayList<>();
        lines.add(class_2561.method_43469("gui.thief.reputation", name).method_30937());
        lines.addAll(class_310.method_1551().field_1772.method_1728(reputation.getLocalizedDescription(), 170));

        if (class_310.method_1551().field_1690.field_1827 && lastGossipsVillagerId == villager.method_5628()) {
            lines.add(class_2561.method_43471("gui.thief.gossips").method_30937());
            lines.add(class_2561.method_43469("gui.thief.gossips.major_negative", "§8" + lastMajorNegative).method_30937());
            lines.add(class_2561.method_43469("gui.thief.gossips.minor_negative", "§8" + lastMinorNegative).method_30937());
            lines.add(class_2561.method_43469("gui.thief.gossips.minor_positive", "§8" + lastMinorPositive).method_30937());
            lines.add(class_2561.method_43469("gui.thief.gossips.major_positive", "§8" + lastMajorPositive).method_30937());
            lines.add(class_2561.method_43469("gui.thief.gossips.trading", "§8" + lastTrading).method_30937());
        }

        int x = minecraft.method_22683().method_4486() / 2 + 8;
        int y = minecraft.method_22683().method_4502() / 2 - (int)(lines.size() / 2f * 9f);
        guiGraphics.method_51447(minecraft.field_1772, lines, x, y + 10);
    }

    public static void updateReputation(int villagerId, int reputation) {
        lastVillagerId = villagerId;
        lastReputation = reputation;
    }

    public static void updateGossips(int villagerId, int majorNegative, int minorNegative,
                                     int minorPositive, int majorPositive, int trading) {
        lastGossipsVillagerId = villagerId;
        lastMajorNegative = majorNegative;
        lastMinorNegative = minorNegative;
        lastMinorPositive = minorPositive;
        lastMajorPositive = majorPositive;
        lastTrading = trading;
    }
}
