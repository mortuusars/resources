package io.github.mortuusars.thief.event;

import com.mojang.brigadier.CommandDispatcher;
import io.github.mortuusars.thief.Config;
import io.github.mortuusars.thief.PlatformHelper;
import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.command.ThiefCommand;
import io.github.mortuusars.thief.world.Reputation;
import io.github.mortuusars.thief.world.Witness;
import io.github.mortuusars.thief.world.stealth.Stealth;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2398;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4139;
import net.minecraft.class_4168;
import net.minecraft.class_6024;
import net.minecraft.class_7157;

public class CommonEvents {
    private static long lastGiftSoundPlayedAt = -1;

    public static class_1269 onEntityInteracted(class_1657 player, class_1268 hand, class_1297 target) {
        if (hand != class_1268.field_5808 || !(player instanceof class_3222 serverPlayer) || !(target instanceof class_1646 villager)) {
            return class_1269.field_5811;
        }

        class_1799 item = player.method_5998(hand);
        if ((!Config.Server.REQUIRES_SNEAK.get() || player.method_21823()) && canGift(serverPlayer, villager, item)) {
            class_1799 gift = item.method_7971(1);

            villager.method_21651().method_19072(player.method_5667(), class_4139.field_18426,
                    Config.Server.GIFTS_MINOR_POSITIVE_INCREASE.get());
            villager.method_21651().method_35126(player.method_5667(), class_4139.field_18425,
                    Config.Server.GIFTS_MINOR_NEGATIVE_REDUCTION.get());

            // Calm down panicking villager
            if (villager.method_18868().method_18906(class_4168.field_18599) && villager.method_20594(player) > -60) {
                villager.method_18868().method_24526(class_4168.field_18595);
            }

            player.method_37908().method_8421(villager, class_6024.field_30039);
            if (player.method_37908().method_8510() - lastGiftSoundPlayedAt > 10) { // Prevent sound spam
                player.method_37908().method_43129(null, villager, class_3417.field_19152, class_3419.field_15254, 1, 1);
                lastGiftSoundPlayedAt = player.method_37908().method_8510();
            }

            PlatformHelper.fireGiftGivenEvent(serverPlayer, villager, gift);

            Thief.CriteriaTriggers.VILLAGER_GIFT.get().trigger(serverPlayer, villager, gift);

            return class_1269.field_5812;
        }

        if (!Reputation.fromValue(villager, player).canTrade()) {
            // Prevent trading
            villager.method_20264();
            return class_1269.field_51370;
        }

        return class_1269.field_5811;
    }

    public static boolean canGift(class_3222 player, class_1646 villager, class_1799 item) {
        if (!Config.Server.GIFTS_ENABLED.get()) return false;
        if (!item.method_31573(Thief.Tags.Items.VILLAGER_GIFTS)) return false;
        int minorPositiveRep = villager.method_21651().method_19073(player.method_5667(), gossipType -> gossipType == class_4139.field_18426);
        int minorNegativeRep = villager.method_21651().method_19073(player.method_5667(), gossipType -> gossipType == class_4139.field_18425);
        return minorPositiveRep < class_4139.field_18426.field_18432 || minorNegativeRep < 0;
    }

    public static void onPlayerTick(class_1657 player) {
        if (ThiefCommand.showNoticeDistanceAndWitnesses
                && player instanceof class_3222 serverPlayer
                && player.method_37908().method_8510() % 2 == 0) {

            List<class_1309> witnesses = Witness.getWitnesses(player);
            for (class_1309 witness : witnesses) {
                witness.method_6092(new class_1293(class_1294.field_5912, 3));
            }

            double radius = Config.Server.WITNESS_MAX_DISTANCE.get() * Stealth.getVisibility(serverPlayer);
            int particles = 64;

            for (int i = 0; i < particles; i++) {
                double angle = 2 * Math.PI * i / particles;
                double x = player.method_23317() + radius * Math.cos(angle);
                double z = player.method_23321() + radius * Math.sin(angle);
                double y = player.method_23318() + 1;

                serverPlayer.method_51469().method_14166(serverPlayer, class_2398.field_11236,
                      true, x, y, z, 1, 0, 0, 0, 0);
            }
        }
    }

    public static void registerCommands(CommandDispatcher<class_2168> dispatcher,
                                        class_7157 context, class_2170.class_5364 environment) {
        ThiefCommand.register(dispatcher);
    }
}
