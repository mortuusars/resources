package io.github.mortuusars.thief.world;

import io.github.mortuusars.thief.Config;
import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.world.stealth.Stealth;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1439;
import net.minecraft.class_1657;
import net.minecraft.class_238;

public class Witness {
    public static List<class_1309> getWitnesses(class_1309 criminal) {
        return getWitnesses(criminal, class_1309.class);
    }

    public static <T extends class_1309> List<T> getWitnesses(class_1309 criminal, Class<T> entityClass) {
        if (criminal instanceof class_1657 player && (player.method_7337() || player.method_7325())) {
            return Collections.emptyList();
        }

        double visibility = Stealth.getVisibility(criminal);

        int radius = Config.Server.WITNESS_MAX_DISTANCE.get();
        class_238 crimeScene = new class_238(criminal.method_24515()).method_1009(radius, radius * 0.5f, radius);

        return criminal.method_37908().method_18467(entityClass, crimeScene)
                .stream()
                .filter(e -> isWitness(criminal, e, visibility))
                .toList();
    }

    public static boolean isWitness(class_1309 criminal, class_1309 entity, double visibility) {
        if (!entity.method_5864().method_20210(Thief.Tags.EntityTypes.WITNESSES)) return false;
        if (entity instanceof class_1439 golem && golem.method_6496()) return false;
        float distance = entity.method_5739(criminal);
        if (distance <= Config.Server.WITNESS_ALWAYS_NOTICE_DISTANCE.get() / 2.0) return true; // Too close. Always hears or sees the crime.
        if (entity.method_6113()) return false; // Cannot hear the crime.
        if (distance <= Config.Server.WITNESS_ALWAYS_NOTICE_DISTANCE.get()) return true; // Hears or sees if not sleeping.
        if (distance > Config.Server.WITNESS_MAX_DISTANCE.get() * visibility) return false;
        return entity.method_6057(criminal);
    }
}
