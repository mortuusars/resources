package io.github.mortuusars.thief.world;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.thief.Config;
import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.api.witness.WitnessReaction;
import io.github.mortuusars.thief.compat.Mods;
import io.github.mortuusars.thief.compat.lithostitched.LithostitchedCompat;
import org.slf4j.Logger;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4151;

public enum Crime implements class_4151 {
    LIGHT("light"),
    MEDIUM("medium"),
    HEAVY("heavy");

    private static final Logger LOGGER = LogUtils.getLogger();

    private final String name;

    Crime(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public int getMajorNegativeChange() {
        return switch (this) {
            case LIGHT -> Config.Server.PUNISHMENT_LIGHT_MAJOR_NEGATIVE.get();
            case MEDIUM -> Config.Server.PUNISHMENT_MEDIUM_MAJOR_NEGATIVE.get();
            case HEAVY -> Config.Server.PUNISHMENT_HEAVY_MAJOR_NEGATIVE.get();
        };
    }

    public int getMinorNegativeChange() {
        return switch (this) {
            case LIGHT -> Config.Server.PUNISHMENT_LIGHT_MINOR_NEGATIVE.get();
            case MEDIUM -> Config.Server.PUNISHMENT_MEDIUM_MINOR_NEGATIVE.get();
            case HEAVY -> Config.Server.PUNISHMENT_HEAVY_MINOR_NEGATIVE.get();
        };
    }

    public class_2960 getStat() {
        return switch (this) {
            case LIGHT -> Thief.Stats.CAUGHT_ON_VILLAGE_LIGHT_THEFTS.get();
            case MEDIUM -> Thief.Stats.CAUGHT_ON_VILLAGE_MEDIUM_THEFTS.get();
            case HEAVY -> Thief.Stats.CAUGHT_ON_VILLAGE_HEAVY_THEFTS.get();
        };
    }

    public boolean isOverGuardAttackThreshold() {
        return Config.Server.GUARD_ATTACK_THRESHOLD.get().getCrime()
                .map(crime -> this.ordinal() >= crime.ordinal())
                .orElse(false);
    }

    public boolean shouldGuardsAttack(class_3218 level, class_1309 witness, class_1309 criminal) {
        return isOverGuardAttackThreshold()
                && !Reputation.averageFromCrowd(criminal, Witness.getWitnesses(criminal)).ignores(this);
    }

    @Override
    public String toString() {
        return name;
    }

    // --

    public Outcome commit(class_3218 level, class_1309 criminal, class_2338 crimeTargetPosition) {
        if (Config.Server.HERO_OF_THE_VILLAGE_CAN_STEAL.get() && criminal.method_6059(class_1294.field_18980)) {
            return Outcome.NONE;
        }

        if (Config.Server.CRIME_ONLY_IN_PROTECTED_STRUCTURE.get() && !isInProtectedStructure(level, crimeTargetPosition)) {
            return Outcome.NONE;
        }

        List<class_1309> witnesses = Witness.getWitnesses(criminal);
        if (witnesses.isEmpty()) {
            return Outcome.NONE;
        }

        Reputation reputation = Reputation.averageFromCrowd(criminal, witnesses);

        if (reputation.ignores(this)) {
            return Outcome.NONE;
        }

        for (class_1309 witness : witnesses) {
            WitnessReaction.handle(level, this, witness, criminal);
        }

        if (criminal instanceof class_1657 player) {
            player.method_7353(class_2561.method_43471("gui.thief.crime_commited." + getName()), true);
            player.method_7281(getStat());
        }

        LOGGER.debug("{} with average reputation '{}', has commited a {} crime and was seen by {} witnesses.",
                criminal.method_5477(), reputation.getName(), getName(), witnesses.size());

        return new Outcome(true, witnesses);
    }

    public static boolean isInProtectedStructure(class_3218 level, class_2338 pos) {
        if (Mods.LITHOSTITCHED.isLoaded()) {
            return LithostitchedCompat.getStructureWithPieceAt(level, pos, Thief.Tags.Structures.PROTECTED).method_16657();
        }
        return level.method_27056().method_57560(pos, Thief.Tags.Structures.PROTECTED).method_16657();
    }

    // --

    public static PotentialCrime fromBlockStateBreaking(class_3222 player, class_2338 pos, class_2680 state) {
        // Reverse order to select heaviest offence if added to multiple tags:
        if (state.method_26164(Thief.Tags.Blocks.BREAK_PROTECTED_HEAVY)) return PotentialCrime.HEAVY;
        if (state.method_26164(Thief.Tags.Blocks.BREAK_PROTECTED_MEDIUM)) return PotentialCrime.MEDIUM;
        if (state.method_26164(Thief.Tags.Blocks.BREAK_PROTECTED_LIGHT)) return PotentialCrime.LIGHT;
        return PotentialCrime.NONE;
    }

    public static PotentialCrime fromBlockStateInteracting(class_3222 player, class_2338 pos, class_2680 state) {
        // Reverse order to select heaviest offence if added to multiple tags:
        if (state.method_26164(Thief.Tags.Blocks.INTERACT_PROTECTED_HEAVY)) return PotentialCrime.HEAVY;
        if (state.method_26164(Thief.Tags.Blocks.INTERACT_PROTECTED_MEDIUM)) return PotentialCrime.MEDIUM;
        if (state.method_26164(Thief.Tags.Blocks.INTERACT_PROTECTED_LIGHT)) return PotentialCrime.LIGHT;
        return PotentialCrime.NONE;
    }

    public static PotentialCrime fromKilling(class_3222 player, class_1309 target) {
        // Reverse order to select heaviest offence if added to multiple tags:
        if (target.method_5864().method_20210(Thief.Tags.EntityTypes.KILLING_PROTECTED_HEAVY)) return PotentialCrime.HEAVY;
        if (target.method_5864().method_20210(Thief.Tags.EntityTypes.KILLING_PROTECTED_MEDIUM)) return PotentialCrime.MEDIUM;
        if (target.method_5864().method_20210(Thief.Tags.EntityTypes.KILLING_PROTECTED_LIGHT)) return PotentialCrime.LIGHT;
        return PotentialCrime.NONE;
    }

    // --

    public record Outcome(boolean punished, List<class_1309> witnesses) {
        public static final Outcome NONE = new Outcome(false, Collections.emptyList());
    }
}
