package io.github.mortuusars.thief.mixin.carryon_compat;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.thief.event.ServerEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import tschipp.carryon.common.carry.PickupHandler;

@Mixin(PickupHandler.class)
public abstract class PickupHandlerMixin {
    @ModifyReturnValue(method = "tryPickupEntity", at = @At("RETURN"), require = 0)
    private static boolean onTryPickupEntity(boolean pickedUp, @Local(argsOnly = true) class_3222 player, @Local(argsOnly = true) class_1297 entity) {
        if (pickedUp && entity instanceof class_1309 target) {
            ServerEvents.onEntityPickedUp(player, target);
        }
        return pickedUp;
    }
}
