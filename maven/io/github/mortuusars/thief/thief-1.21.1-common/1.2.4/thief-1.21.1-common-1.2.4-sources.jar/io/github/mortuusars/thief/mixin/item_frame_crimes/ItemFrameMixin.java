package io.github.mortuusars.thief.mixin.item_frame_crimes;

import io.github.mortuusars.thief.Config;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1530;
import net.minecraft.class_1533;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1533.class)
public abstract class ItemFrameMixin extends class_1530 {
    @Shadow
    private boolean fixed;

    @Shadow
    public abstract class_1799 getItem();

    protected ItemFrameMixin(class_1299<? extends class_1530> type, class_1937 level) {
        super(type, level);
    }

    @Inject(method = "dropItem(Lnet/minecraft/world/entity/Entity;Z)V", at = @At("HEAD"))
    private void onDropItem(@Nullable class_1297 entity, boolean dropSelf, CallbackInfo ci) {
        class_1799 item = getItem();
        if (!fixed && !item.method_7960() && entity instanceof class_1309 criminal && entity.method_37908() instanceof class_3218 serverLevel) {
            Config.Server.CRIME_FOR_LOOTING_ITEM_FRAME.get().getCrime().ifPresent(crime -> {
                crime.commit(serverLevel, criminal, method_24515());
            });
        }
    }
}
