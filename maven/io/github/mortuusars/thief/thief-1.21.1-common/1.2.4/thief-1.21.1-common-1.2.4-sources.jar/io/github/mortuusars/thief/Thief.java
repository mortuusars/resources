package io.github.mortuusars.thief;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.thief.advancement.trigger.CrimeCommitedTrigger;
import io.github.mortuusars.thief.advancement.trigger.GuardAttacksCriminalTrigger;
import io.github.mortuusars.thief.advancement.trigger.VillagerGiftTrigger;
import org.slf4j.Logger;

import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3414;
import net.minecraft.class_3446;
import net.minecraft.class_6862;

public class Thief {
    public static final String ID = "thief";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static void init() {
        Blocks.init();
        BlockEntityTypes.init();
        EntityTypes.init();
        Items.init();
        DataComponents.init();
        Stats.init();
        CriteriaTriggers.init();
        ItemSubPredicates.init();
        MenuTypes.init();
        RecipeSerializers.init();
        SoundEvents.init();
        ArgumentTypes.init();
    }

    /**
     * Creates resource location in the mod namespace with the given path.
     */
    public static class_2960 resource(String path) {
        return class_2960.method_60655(ID, path);
    }

    public static class Blocks {
        static void init() {
        }
    }

    public static class BlockEntityTypes {
        static void init() {
        }
    }

    public static class Items {
        static void init() {
        }
    }

    public static class DataComponents {
        static void init() {
        }
    }

    public static class EntityTypes {
        static void init() {
        }
    }

    public static class MenuTypes {
        static void init() {
        }
    }

    public static class RecipeSerializers {
        static void init() {
        }
    }

    public static class SoundEvents {
        private static Supplier<class_3414> register(String category, String key) {
            Preconditions.checkState(category != null && !category.isEmpty(), "'category' should not be empty.");
            Preconditions.checkState(key != null && !key.isEmpty(), "'key' should not be empty.");
            String path = category + "." + key;
            return Register.soundEvent(path, () -> class_3414.method_47908(Thief.resource(path)));
        }

        static void init() {
        }
    }

    public static class Stats {
        public static final Supplier<class_2960> CAUGHT_ON_VILLAGE_LIGHT_THEFTS =
                Register.stat(resource("caught_at_light_thefts_in_village"), class_3446.field_16975);
        public static final Supplier<class_2960> CAUGHT_ON_VILLAGE_MEDIUM_THEFTS =
                Register.stat(resource("caught_at_medium_thefts_in_village"), class_3446.field_16975);
        public static final Supplier<class_2960> CAUGHT_ON_VILLAGE_HEAVY_THEFTS =
                Register.stat(resource("caught_at_heavy_thefts_in_village"), class_3446.field_16975);

        public static void init() {
        }
    }

    public static class CriteriaTriggers {
        public static Supplier<CrimeCommitedTrigger> CRIME_COMMITED = Register.criterionTrigger("crime_committed", CrimeCommitedTrigger::new);
        public static Supplier<VillagerGiftTrigger> VILLAGER_GIFT = Register.criterionTrigger("villager_gift", VillagerGiftTrigger::new);
        public static Supplier<GuardAttacksCriminalTrigger> GUARD_ATTACKS_CRIMINAL = Register.criterionTrigger("guard_attacks_criminal", GuardAttacksCriminalTrigger::new);

        public static void init() {
        }
    }

    public static class ItemSubPredicates {
        public static void init() {
        }
    }

    public static class LootTables {
    }

    public static class Tags {
        public static class Items {
            public static final class_6862<class_1792> VILLAGER_GIFTS =
                    class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("villager_gifts"));
        }

        public static class Blocks {
            public static final class_6862<class_2248> BREAK_PROTECTED_LIGHT =
                    class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("break_protected/light"));
            public static final class_6862<class_2248> BREAK_PROTECTED_MEDIUM =
                    class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("break_protected/medium"));
            public static final class_6862<class_2248> BREAK_PROTECTED_HEAVY =
                    class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("break_protected/heavy"));

            public static final class_6862<class_2248> INTERACT_PROTECTED_LIGHT =
                    class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("interact_protected/light"));
            public static final class_6862<class_2248> INTERACT_PROTECTED_MEDIUM =
                    class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("interact_protected/medium"));
            public static final class_6862<class_2248> INTERACT_PROTECTED_HEAVY =
                    class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("interact_protected/heavy"));
        }

        public static class EntityTypes {
            public static final class_6862<class_1299<?>> KILLING_PROTECTED_LIGHT =
                    class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("killing_protected/light"));
            public static final class_6862<class_1299<?>> KILLING_PROTECTED_MEDIUM =
                    class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("killing_protected/medium"));
            public static final class_6862<class_1299<?>> KILLING_PROTECTED_HEAVY =
                    class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("killing_protected/heavy"));

            public static final class_6862<class_1299<?>> PICKUP_PROTECTED_LIGHT =
                  class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("pickup_protected/light"));
            public static final class_6862<class_1299<?>> PICKUP_PROTECTED_MEDIUM =
                  class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("pickup_protected/medium"));
            public static final class_6862<class_1299<?>> PICKUP_PROTECTED_HEAVY =
                  class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("pickup_protected/heavy"));

            public static final class_6862<class_1299<?>> WITNESSES =
                    class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("witnesses"));

            public static final class_6862<class_1299<?>> GUARDS =
                    class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("guards"));
        }

        public static class Structures {
            public static final class_6862<class_3195> PROTECTED =
                    class_6862.method_40092(net.minecraft.class_7924.field_41246, resource("protected"));
        }
    }

    public static class ArgumentTypes {
        public static void init() {
        }
    }

    public static class Registries {
    }
}
