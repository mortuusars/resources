package io.github.mortuusars.thief.api.witness;

import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.world.Crime;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5354;
import net.minecraft.class_6024;

/**
 * Allows registering custom handlers for witness reactions of a crime.<br>
 * Can be used for entities other than villagers.<br>
 * Use {@link WitnessReaction#register} to register handlers.
 */
public class WitnessReaction {
    private static final List<WitnessReactionHandler> handlers = new ArrayList<>();

    static {
        register((level, crime, witness, criminal) -> {
            if (!(witness instanceof class_1646 villager)) return false;
            villager.method_20264();
            level.method_19496(crime, criminal, villager);
            level.method_8421(villager, class_6024.field_30038);
            return true;
        });

        register((level, crime, witness, criminal) -> {
            if (witness.method_5864().method_20210(Thief.Tags.EntityTypes.GUARDS)
                    && witness instanceof class_5354 neutralMob
                    && crime.shouldGuardsAttack(level, criminal)
                    && witness.method_18395(criminal)
                    && neutralMob.method_5968() == null) { // Only if not already attacking something
                neutralMob.method_5980(criminal); // Attack

                if (criminal instanceof class_3222 player) {
                    Thief.CriteriaTriggers.GUARD_ATTACKS_CRIMINAL.get().trigger(player, witness);
                }

                for (int i = 0; i < 5; i++) {
                    double d = witness.method_59922().method_43059() * 0.02;
                    double e = witness.method_59922().method_43059() * 0.02;
                    double f = witness.method_59922().method_43059() * 0.02;
                    level.method_14199(class_2398.field_11231,
                            witness.method_23322(1.0),
                            witness.method_23319() + 1.0,
                            witness.method_23325(1.0),
                            5, d, e, f, 0.01);
                }

                return true;
            }
            return false;
        });
    }

    public static void register(WitnessReactionHandler handler) {
        handlers.add(handler);
    }

    public static boolean handle(class_3218 serverLevel, Crime crime, class_1309 witness, class_1309 criminal) {
        for (WitnessReactionHandler handler : handlers) {
            boolean result = handler.handle(serverLevel, crime, witness, criminal);
            if (result) {
                return true;
            }
        }
        return false;
    }
}
