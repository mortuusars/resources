package io.github.mortuusars.thief;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3908;

public class PlatformHelper {
    @ExpectPlatform
    public static boolean canShear(class_1799 stack) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean canStrip(class_1799 stack) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_2540> extraDataWriter) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isModLoaded(String modId) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isModLoading(String modId) {
        throw new AssertionError();
    }
}
