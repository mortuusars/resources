package io.github.mortuusars.thief.event;

import io.github.mortuusars.thief.Config;
import io.github.mortuusars.thief.api.block_interaction.BlockInteraction;
import io.github.mortuusars.thief.world.Crime;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public class ServerEvents {
    public static void onBlockDestroyedByPlayer(class_3222 player, class_2338 pos, class_2680 state) {
        if (!Config.Common.CRIME_FOR_BREAKING_PROTECTED_BLOCKS.get()) return;
        Crime.fromBlockStateBreaking(player, pos, state).getCrime().ifPresent(crime ->
                crime.commit(player.method_51469(), player, pos));
    }

    public static void onBlockInteract(class_3222 player, class_2338 pos, class_1268 hand) {
        if (!Config.Common.CRIME_FOR_INTERACTING_WITH_PROTECTED_BLOCKS.get()) return;
        if (hand == class_1268.field_5810) return; // Handling only main hand should be enough.

        class_2680 state = player.method_37908().method_8320(pos);

        if (BlockInteraction.handle(player, pos, state) != class_1269.field_5811) {
            return;
        }

        Crime.fromBlockStateInteracting(player, pos, state).getCrime().ifPresent(crime ->
                crime.commit(player.method_51469(), player, pos));
    }
}
