package io.github.mortuusars.thief.compat.kubejs;

import dev.architectury.injectables.annotations.ExpectPlatform;
import dev.latvian.mods.kubejs.KubeJSPlugin;
import dev.latvian.mods.kubejs.script.ScriptType;
import io.github.mortuusars.thief.world.Crime;
import io.github.mortuusars.thief.world.Reputation;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

public class ThiefKubeJSPlugin extends KubeJSPlugin {
    @Override
    public void init() {
        subscribeToEvents();
    }

    @ExpectPlatform
    public static void subscribeToEvents() {
        throw new AssertionError();
    }

    @Override
    public void registerEvents() {
        ThiefJSEvents.register();
    }

    public static void fireCrimeCommitedEvent(class_1309 criminal, Crime crime, List<class_1309> witnesses) {
        ThiefJSEvents.CRIME_COMMITED.post(ScriptType.SERVER, new CrimeCommitedEventJS(criminal, crime, witnesses));
    }

    public static void fireGiftGivenEvent(class_3222 player, class_1646 villager, class_1799 gift) {
        ThiefJSEvents.GIFT_GIVEN.post(ScriptType.SERVER, new GiftGivenEventJS(player, villager, gift));
    }

    public static void fireReputationLevelChangedEvent(class_1309 criminal, class_1646 villager, Reputation oldReputation, Reputation newReputation) {
        ThiefJSEvents.REPUTATION_LEVEL_CHANGED.post(ScriptType.SERVER, new ReputationLevelChangedEventJS(criminal, villager, oldReputation, newReputation));
    }
}
