package io.github.mortuusars.thief.fabric.api.event;

import io.github.mortuusars.thief.world.Crime;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1309;
import java.util.List;

/**
 * Fired when the entity (usually player) is punished for a crime.
 */
public interface CrimeCommitedCallback {
    Event<CrimeCommitedCallback> EVENT = EventFactory.createArrayBacked(CrimeCommitedCallback.class,
            (listeners) -> (criminal, crime, witnesses) -> {
                for (CrimeCommitedCallback listener : listeners) {
                    listener.crimeCommited(criminal, crime, witnesses);
                }
            });

    void crimeCommited(class_1309 criminal, Crime crime, List<class_1309> witnesses);
}