package io.github.mortuusars.thief.mixin.guard_attacks_advancement;

import io.github.mortuusars.thief.Thief;
import net.minecraft.class_1309;
import net.minecraft.class_1397;
import net.minecraft.class_1439;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1397.class)
public class DefendVillageTargetGoalMixin {
    @Final
    @Shadow @Nullable private class_1439 golem;
    @Shadow @Nullable private class_1309 potentialTarget;

    @Inject(method = "start", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ai/goal/target/TargetGoal;start()V"))
    private void onStart(CallbackInfo ci) {
        if (potentialTarget instanceof class_3222 player) {
            Thief.CriteriaTriggers.GUARD_ATTACKS_CRIMINAL.trigger(player, golem);
        }
    }
}
