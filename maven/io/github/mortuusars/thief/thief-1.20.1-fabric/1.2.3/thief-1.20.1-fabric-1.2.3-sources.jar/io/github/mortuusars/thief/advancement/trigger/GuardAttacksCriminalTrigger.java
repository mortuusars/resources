package io.github.mortuusars.thief.advancement.trigger;

import com.google.gson.JsonObject;
import io.github.mortuusars.thief.Thief;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_1309;
import net.minecraft.class_195;
import net.minecraft.class_2048;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5257;
import net.minecraft.class_5258;
import net.minecraft.class_5267;
import org.jetbrains.annotations.NotNull;

public class GuardAttacksCriminalTrigger extends class_4558<GuardAttacksCriminalTrigger.TriggerInstance> {
    public static final class_2960 ID = Thief.resource("guard_attacks_criminal");

    public @NotNull class_2960 method_794() {
        return ID;
    }

    @Override
    protected @NotNull TriggerInstance method_27854(JsonObject json, @NotNull class_5258 predicate,
                                                      @NotNull class_5257 deserializationContext) {
        class_2048 guard = class_2048.method_8913(json.get("guard"));
        return new TriggerInstance(predicate, guard);
    }

    public void trigger(class_3222 player, class_1309 guard) {
        this.method_22510(player, triggerInstance -> triggerInstance.matches(player, guard));
    }

    public static class TriggerInstance extends class_195 {
        private final class_2048 guard;

        public TriggerInstance(class_5258 predicate, class_2048 guard) {
            super(ID, predicate);
            this.guard = guard;
        }

        public boolean matches(class_3222 player, class_1309 guard) {
            return this.guard.equals(class_2048.field_9599) || this.guard.method_8914(player, guard);
        }

        public @NotNull JsonObject method_807(@NotNull class_5267 conditions) {
            JsonObject jsonobject = super.method_807(conditions);
            jsonobject.add("guard", this.guard.method_8912());
            return jsonobject;
        }
    }
}