package io.github.mortuusars.thief.advancement.trigger;

import com.google.gson.JsonObject;
import io.github.mortuusars.thief.Thief;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_1646;
import net.minecraft.class_1799;
import net.minecraft.class_195;
import net.minecraft.class_2048;
import net.minecraft.class_2073;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5257;
import net.minecraft.class_5258;
import net.minecraft.class_5267;
import org.jetbrains.annotations.NotNull;

public class VillagerGiftTrigger extends class_4558<VillagerGiftTrigger.TriggerInstance> {
    public static final class_2960 ID = Thief.resource("villager_gift");

    public @NotNull class_2960 method_794() {
        return ID;
    }

    @Override
    protected @NotNull TriggerInstance method_27854(JsonObject json, @NotNull class_5258 predicate,
                                                      @NotNull class_5257 deserializationContext) {
        class_2048 entityPredicate = class_2048.method_8913(json.get("entity"));
        class_2073 itemPredicate = class_2073.method_8969(json.get("gift"));
        return new TriggerInstance(predicate, entityPredicate, itemPredicate);
    }

    public void trigger(class_3222 player, class_1646 villager, class_1799 gift) {
        this.method_22510(player, triggerInstance -> triggerInstance.matches(player, villager, gift));
    }

    public static class TriggerInstance extends class_195 {
        private final class_2048 entityPredicate;
        private final class_2073 itemPredicate;

        public TriggerInstance(class_5258 predicate, class_2048 entityPredicate, class_2073 itemPredicate) {
            super(ID, predicate);
            this.entityPredicate = entityPredicate;
            this.itemPredicate = itemPredicate;
        }

        public boolean matches(class_3222 player, class_1646 villager, class_1799 gift) {
            return (this.entityPredicate.equals(class_2048.field_9599) || this.entityPredicate.method_8914(player, villager))
                    && (this.itemPredicate.equals(class_2073.field_9640) || this.itemPredicate.method_8970(gift));
        }

        public @NotNull JsonObject method_807(@NotNull class_5267 conditions) {
            JsonObject jsonobject = super.method_807(conditions);
            jsonobject.add("entity", this.entityPredicate.method_8912());
            jsonobject.add("gift", this.itemPredicate.method_8971());
            return jsonobject;
        }
    }
}