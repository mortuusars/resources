package io.github.mortuusars.thief.event;

import io.github.mortuusars.thief.client.VillagerReputationTooltip;
import net.minecraft.class_332;

public class ClientEvents {
    public static void renderGui(class_332 guiGraphics, float partialTicks) {
        VillagerReputationTooltip.render(guiGraphics, partialTicks);
    }
}
