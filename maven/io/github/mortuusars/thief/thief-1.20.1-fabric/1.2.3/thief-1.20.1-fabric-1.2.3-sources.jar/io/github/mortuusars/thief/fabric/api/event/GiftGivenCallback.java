package io.github.mortuusars.thief.fabric.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1646;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

/**
 * Fired when the player gifts an item to a villager
 */
public interface GiftGivenCallback {
    Event<GiftGivenCallback> EVENT = EventFactory.createArrayBacked(GiftGivenCallback.class,
            (listeners) -> (player, target, gift) -> {
                for (GiftGivenCallback listener : listeners) {
                    listener.giftGiven(player, target, gift);
                }
            });

    void giftGiven(class_3222 player, class_1646 villager, class_1799 gift);
}