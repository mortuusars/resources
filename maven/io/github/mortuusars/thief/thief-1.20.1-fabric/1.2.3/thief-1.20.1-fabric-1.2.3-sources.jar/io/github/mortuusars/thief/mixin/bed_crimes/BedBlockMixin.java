package io.github.mortuusars.thief.mixin.bed_crimes;

import io.github.mortuusars.thief.Config;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2244;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2244.class)
public class BedBlockMixin {
    @Inject(method = "use", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/BedBlock;kickVillagerOutOfBed(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)Z"))
    private void onUseWithoutItem(class_2680 state, class_1937 level, class_2338 pos, class_1657 player,
                                  class_1268 hand, class_3965 hit, CallbackInfoReturnable<class_1269> cir) {
        if (!(level instanceof class_3218 serverLevel)) return;
        Config.Common.CRIME_FOR_KICKING_VILLAGER_OUT_OF_BED.get().getCrime().ifPresent(crime -> {
            if (!level.method_8390(class_1646.class, new class_238(pos), class_1309::method_6113).isEmpty()) {
                crime.commit(serverLevel, player, pos);
            }
        });
    }
}
