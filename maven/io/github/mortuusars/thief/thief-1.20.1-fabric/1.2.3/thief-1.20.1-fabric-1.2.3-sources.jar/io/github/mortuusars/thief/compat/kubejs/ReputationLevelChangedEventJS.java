package io.github.mortuusars.thief.compat.kubejs;

import dev.latvian.mods.kubejs.entity.LivingEntityEventJS;
import io.github.mortuusars.thief.world.Reputation;
import net.minecraft.class_1309;
import net.minecraft.class_1646;

/**
 * Fired when the entity reputation with specific villager changes.
 */
public class ReputationLevelChangedEventJS extends LivingEntityEventJS {
    private final class_1309 criminal;
    private final class_1646 villager;
    private final Reputation oldReputation;
    private final Reputation newReputation;

    public ReputationLevelChangedEventJS(class_1309 criminal, class_1646 villager, Reputation oldReputation, Reputation newReputation) {
        this.criminal = criminal;
        this.villager = villager;
        this.oldReputation = oldReputation;
        this.newReputation = newReputation;
    }

    @Override
    public class_1309 getEntity() {
        return criminal;
    }

    public class_1309 getCriminal() {
        return criminal;
    }

    public class_1646 getVillager() {
        return villager;
    }

    public Reputation getOldReputation() {
        return oldReputation;
    }

    public Reputation getNewReputation() {
        return newReputation;
    }
}
