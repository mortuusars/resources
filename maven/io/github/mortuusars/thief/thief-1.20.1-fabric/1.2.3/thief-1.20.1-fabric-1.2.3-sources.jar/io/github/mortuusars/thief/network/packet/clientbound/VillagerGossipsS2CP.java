package io.github.mortuusars.thief.network.packet.clientbound;

import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.network.PacketDirection;
import io.github.mortuusars.thief.network.handler.ClientPacketsHandler;
import io.github.mortuusars.thief.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public record VillagerGossipsS2CP(int villagerId, int majorNegative, int minorNegative, int minorPositive,
                                  int majorPositive, int trading) implements Packet {
    public static final class_2960 ID = Thief.resource("villager_gossips");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public class_2540 toBuffer(class_2540 buffer) {
        buffer.method_10804(villagerId);
        buffer.method_10804(majorNegative);
        buffer.method_10804(minorNegative);
        buffer.method_10804(minorPositive);
        buffer.method_10804(majorPositive);
        buffer.method_10804(trading);
        return buffer;
    }

    public static VillagerGossipsS2CP fromBuffer(class_2540 buffer) {
        return new VillagerGossipsS2CP(
                buffer.method_10816(),
                buffer.method_10816(),
                buffer.method_10816(),
                buffer.method_10816(),
                buffer.method_10816(),
                buffer.method_10816());
    }

    @Override
    public boolean handle(PacketDirection direction, @Nullable class_1657 player) {
        ClientPacketsHandler.receiveVillagerGossips(this);
        return true;
    }
}
