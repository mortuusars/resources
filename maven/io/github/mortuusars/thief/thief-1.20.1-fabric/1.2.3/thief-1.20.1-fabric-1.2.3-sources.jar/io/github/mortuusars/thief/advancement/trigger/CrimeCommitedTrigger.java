package io.github.mortuusars.thief.advancement.trigger;

import com.google.gson.JsonObject;
import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.world.Crime;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_1309;
import net.minecraft.class_195;
import net.minecraft.class_2048;
import net.minecraft.class_2096;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5257;
import net.minecraft.class_5258;
import net.minecraft.class_5267;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class CrimeCommitedTrigger extends class_4558<CrimeCommitedTrigger.TriggerInstance> {
    public static final class_2960 ID = Thief.resource("crime_commited");

    public @NotNull class_2960 method_794() {
        return ID;
    }

    @Override
    protected @NotNull TriggerInstance method_27854(JsonObject json, @NotNull class_5258 predicate,
                                                      @NotNull class_5257 deserializationContext) {
        class_2096.class_2100 crime = class_2096.class_2100.method_9056(json.get("crime"));
        class_2048 witness = class_2048.method_8913(json.get("witness"));
        return new TriggerInstance(predicate, crime, witness);
    }

    public void trigger(class_3222 player, Crime crime, List<class_1309> witnesses) {
        this.method_22510(player, triggerInstance -> triggerInstance.matches(player, crime, witnesses));
    }

    public static class TriggerInstance extends class_195 {
        private final class_2096.class_2100 crime;
        private final class_2048 witness;

        public TriggerInstance(class_5258 predicate, class_2096.class_2100 crime, class_2048 witness) {
            super(ID, predicate);
            this.crime = crime;
            this.witness = witness;
        }

        public boolean matches(class_3222 player, Crime crime, List<class_1309> witnesses) {
            return (this.crime.method_9041() || this.crime.method_9054(crime.ordinal())
                    && (witness.equals(class_2048.field_9599) || witnesses.stream().allMatch(w -> witness.method_8914(player, w))));
        }

        public @NotNull JsonObject method_807(@NotNull class_5267 conditions) {
            JsonObject jsonobject = super.method_807(conditions);
            jsonobject.add("crime", this.crime.method_9036());
            jsonobject.add("witness", this.witness.method_8912());
            return jsonobject;
        }
    }
}