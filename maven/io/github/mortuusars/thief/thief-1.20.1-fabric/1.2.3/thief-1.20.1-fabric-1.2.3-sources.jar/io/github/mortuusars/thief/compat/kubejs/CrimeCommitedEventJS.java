package io.github.mortuusars.thief.compat.kubejs;

import dev.latvian.mods.kubejs.entity.LivingEntityEventJS;
import io.github.mortuusars.thief.world.Crime;
import java.util.List;
import net.minecraft.class_1309;

/**
 * Fired when the entity (usually player) is punished for a crime.
 */
public class CrimeCommitedEventJS extends LivingEntityEventJS {
    private final class_1309 criminal;
    private final Crime crime;
    private final List<class_1309> witnesses;

    public CrimeCommitedEventJS(class_1309 criminal, Crime crime, List<class_1309> witnesses) {
        this.criminal = criminal;
        this.crime = crime;
        this.witnesses = witnesses;
    }

    @Override
    public class_1309 getEntity() {
        return criminal;
    }

    public class_1309 getCriminal() {
        return criminal;
    }

    public Crime getCrime() {
        return crime;
    }

    public List<class_1309> getWitnesses() {
        return witnesses;
    }
}