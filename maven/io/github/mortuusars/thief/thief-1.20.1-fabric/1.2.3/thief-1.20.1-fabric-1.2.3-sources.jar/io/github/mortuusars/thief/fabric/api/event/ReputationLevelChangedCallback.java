
package io.github.mortuusars.thief.fabric.api.event;

import io.github.mortuusars.thief.world.Reputation;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1309;
import net.minecraft.class_1646;

/**
 * Fired when the entity reputation with specific villager changes.
 */
public interface ReputationLevelChangedCallback {
    Event<ReputationLevelChangedCallback> EVENT = EventFactory.createArrayBacked(ReputationLevelChangedCallback.class,
            (listeners) -> (criminal, villager, oldReputation, newReputation) -> {
                for (ReputationLevelChangedCallback listener : listeners) {
                    listener.giftGiven(criminal, villager, oldReputation, newReputation);
                }
            });

    void giftGiven(class_1309 criminal, class_1646 villager, Reputation oldReputation, Reputation newReputation);
}