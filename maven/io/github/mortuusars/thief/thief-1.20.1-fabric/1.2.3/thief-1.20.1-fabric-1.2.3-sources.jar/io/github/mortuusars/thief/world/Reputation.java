package io.github.mortuusars.thief.world;

import io.github.mortuusars.thief.Config;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;

public enum Reputation {
    HATED("hated", 0xFFFF4949),
    UNWELCOME("unwelcome", 0xFFFF884E),
    DISTRUSTED("distrusted", 0xFFFEB259),
    NEUTRAL("neutral", 0xFFFFF8B9),
    ACCEPTED("accepted", 0xFFEFFF82),
    RESPECTED("respected", 0xFF8EF057),
    HONORED("honored", 0xFF54FFC9);

    private final String name;
    private final int color;

    Reputation(String name, int color) {
        this.name = name;
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public int getColor() {
        return color;
    }

    public class_5250 getLocalizedName() {
        return class_2561.method_43471("gui.thief.reputation." + name);
    }

    public class_5250 getLocalizedNameWithColor() {
        return getLocalizedName().method_27696(class_2583.field_24360.method_36139(color));
    }

    public class_5250 getLocalizedDescription() {
        return class_2561.method_43471("gui.thief.reputation." + name + ".description");
    }

    public boolean isLowerOrEqualTo(Reputation reputation) {
        return ordinal() <= reputation.ordinal();
    }

    public boolean isGreaterOrEqualTo(Reputation reputation) {
        return ordinal() >= reputation.ordinal();
    }

    public boolean ignores(Crime crime) {
        return switch (crime) {
            case LIGHT -> isGreaterOrEqualTo(ACCEPTED);
            case MEDIUM -> isGreaterOrEqualTo(RESPECTED);
            case HEAVY -> isGreaterOrEqualTo(HONORED);
        };
    }

    public boolean canTrade() {
        return isGreaterOrEqualTo(Config.Common.TRADE_REPUTATION_THRESHOLD.get());
    }

    // --

    public static Reputation fromValue(class_1646 villager, class_1309 entity) {
        int reputation = villager.method_21651().method_19073(entity.method_5667(), gossipType -> true);
        return fromValue(reputation);
    }

    public static Reputation fromValue(int reputation) {
        if (reputation <= -100) return HATED;
        if (reputation <= -50) return UNWELCOME;
        if (reputation < 0) return DISTRUSTED;
        if (reputation < 10) return NEUTRAL;
        if (reputation < 20) return ACCEPTED;
        if (reputation < 30) return RESPECTED;
        return HONORED;
    }

    public static int averageValueFromVillagers(class_1309 subject, List<class_1646> villagers) {
        return (int) villagers.stream()
                .mapToInt(villager -> villager.method_21651().method_19073(subject.method_5667(), gossipType -> true))
                .average().orElse(0);
    }

    public static Reputation averageFromVillagers(class_1309 subject, List<class_1646> villagers) {
        return fromValue(averageValueFromVillagers(subject, villagers));
    }

    public static int averageValueFromCrowd(class_1309 entity, List<class_1309> crowd) {
        return (int) crowd.stream()
                .mapToInt(e -> valueOf(entity, e))
                .average().orElse(0);
    }

    public static Reputation averageFromCrowd(class_1309 subject, List<class_1309> crowd) {
        return fromValue(averageValueFromCrowd(subject, crowd));
    }

    public static int valueOf(class_1309 subject, class_1309 entityWithReputation) {
        if (entityWithReputation instanceof class_1646 villager) {
            return villager.method_21651().method_19073(subject.method_5667(), gossipType -> true);
        }
        return 0;
    }
}
