package io.github.mortuusars.thief.compat.kubejs;

import dev.latvian.mods.kubejs.player.PlayerEventJS;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

/**
 * Fired when the player gifts an item to a villager
 */
public class GiftGivenEventJS extends PlayerEventJS {
    private final class_3222 player;
    private final class_1309 villager;
    private final class_1799 gift;

    public GiftGivenEventJS(class_3222 player, class_1646 villager, class_1799 gift) {
        this.player = player;
        this.villager = villager;
        this.gift = gift;
    }

    @Override
    public class_1657 getEntity() {
        return player;
    }

    @Override
    public class_3222 getPlayer() {
        return player;
    }

    public class_1309 getVillager() {
        return villager;
    }

    public class_1799 getGift() {
        return gift;
    }
}
