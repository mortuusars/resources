package io.github.mortuusars.thief;

import dev.architectury.injectables.annotations.ExpectPlatform;
import io.github.mortuusars.thief.world.Crime;
import io.github.mortuusars.thief.world.Reputation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.ItemStack;

import java.util.List;

public class PlatformHelper {
    @ExpectPlatform
    public static boolean isModLoaded(String modId) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void fireCrimeCommitedEvent(LivingEntity criminal, Crime crime, List<LivingEntity> witnesses) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void fireGiftGivenEvent(ServerPlayer player, Villager villager, ItemStack gift) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void fireReputationLevelChangedEvent(LivingEntity criminal, Villager villager, Reputation oldReputation, Reputation newReputation) {
        throw new AssertionError();
    }
}
