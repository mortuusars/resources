package io.github.mortuusars.thief.network.packet;

import io.github.mortuusars.thief.network.packet.clientbound.VillagerGossipsS2CP;
import io.github.mortuusars.thief.network.packet.clientbound.VillagerReputationS2CP;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;

public class S2CPackets {
    public static List<class_8710.class_9155<? extends class_2540, ? extends class_8710>> getDefinitions() {
        return List.of(
                new class_8710.class_9155<>(VillagerReputationS2CP.TYPE, VillagerReputationS2CP.STREAM_CODEC),
                new class_8710.class_9155<>(VillagerGossipsS2CP.TYPE, VillagerGossipsS2CP.STREAM_CODEC)
        );
    }
}