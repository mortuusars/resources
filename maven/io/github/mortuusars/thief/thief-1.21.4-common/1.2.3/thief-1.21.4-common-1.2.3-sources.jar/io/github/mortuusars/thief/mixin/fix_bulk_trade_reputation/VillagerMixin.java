package io.github.mortuusars.thief.mixin.fix_bulk_trade_reputation;

import io.github.mortuusars.thief.Config;
import net.minecraft.class_1299;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1914;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3988;
import net.minecraft.class_4151;
import net.minecraft.class_6024;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1646.class)
public abstract class VillagerMixin extends class_3988 {
    @Shadow private @Nullable class_1657 lastTradedPlayer;

    public VillagerMixin(class_1299<? extends class_3988> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "rewardTradeXp", at = @At("HEAD"))
    private void onRewardTradeXp(class_1914 offer, CallbackInfo ci) {
        if (Config.Server.FIX_SHIFT_CLICK_TRADE_REPUTATION.get()
                && lastTradedPlayer != null && method_37908() instanceof class_3218 serverLevel) {
            serverLevel.method_19496(class_4151.field_18478, this.lastTradedPlayer, (class_1646)(Object)this);
            method_37908().method_8421(this, class_6024.field_30039);
            lastTradedPlayer = null;
        }
    }
}
