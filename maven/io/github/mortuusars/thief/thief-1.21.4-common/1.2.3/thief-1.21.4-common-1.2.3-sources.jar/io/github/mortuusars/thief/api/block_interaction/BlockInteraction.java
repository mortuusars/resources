package io.github.mortuusars.thief.api.block_interaction;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

/**
 * Allows registering custom handlers for block interaction in case default Thief logic is not suitable.<br>
 * Can be used in cases where only some interactions are considered a crime, and others do not.<br>
 * Or to prevent a crime depending on certain conditions.<br><br>
 * Use {@link BlockInteraction#register} to register handlers.
 */
public class BlockInteraction {
    private static final List<CustomBlockInteractHandler> handlers = new ArrayList<>();

    public static void register(CustomBlockInteractHandler handler) {
        handlers.add(handler);
    }

    public static class_1269 handle(class_3222 player, class_2338 pos, class_2680 state) {
        for (CustomBlockInteractHandler handler : handlers) {
            class_1269 result = handler.handle(player, pos, state);
            if (result != class_1269.field_5811) {
                return result;
            }
        }
        return class_1269.field_5811;
    }
}
