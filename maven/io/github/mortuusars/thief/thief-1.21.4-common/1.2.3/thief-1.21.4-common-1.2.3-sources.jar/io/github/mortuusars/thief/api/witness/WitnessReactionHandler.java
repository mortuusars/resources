package io.github.mortuusars.thief.api.witness;

import io.github.mortuusars.thief.world.Crime;
import net.minecraft.class_1309;
import net.minecraft.class_3218;

public interface WitnessReactionHandler {
    /**
     * What to do when witness sees a crime.
     * @return true means 'handled' and will terminate any following handlers for the witness.
     */
    boolean handle(class_3218 serverLevel, Crime crime, class_1309 witness, class_1309 criminal);
}
