package io.github.mortuusars.thief.world.stealth.modifier;

import io.github.mortuusars.thief.world.stealth.Stealth;
import net.minecraft.class_1294;
import net.minecraft.class_1309;

public class InvisibilityModifier implements Stealth.VisibilityModifier {
    @Override
    public double modify(class_1309 entity, double value) {
        return entity.method_6112(class_1294.field_5905) != null
                ? value * 0.25f
                : value;
    }
}
