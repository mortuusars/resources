package io.github.mortuusars.thief.world.stealth.modifier;

import io.github.mortuusars.thief.world.stealth.Stealth;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

public class SneakingModifier implements Stealth.VisibilityModifier {
    @Override
    public double modify(class_1309 entity, double value) {
        return entity instanceof class_1657 player && player.method_21823()
                ? value * 0.5f
                : value;
    }
}
