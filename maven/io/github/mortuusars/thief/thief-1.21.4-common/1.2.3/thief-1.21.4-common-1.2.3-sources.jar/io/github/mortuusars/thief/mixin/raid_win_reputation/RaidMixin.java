package io.github.mortuusars.thief.mixin.raid_win_reputation;

import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.thief.Config;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_3765;
import net.minecraft.class_4139;

@Mixin(class_3765.class)
public abstract class RaidMixin {
    @Shadow public abstract class_1937 getLevel();
    @Shadow public abstract class_2338 getCenter();

    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;awardStat(Lnet/minecraft/resources/ResourceLocation;)V"))
    private void onTick(CallbackInfo ci, @Local class_1309 entity) {
        List<class_1646> villagers = getLevel().method_18467(class_1646.class, new class_238(getCenter()).method_1014(128));
        for (class_1646 villager : villagers) {
            int major = Config.Server.HERO_MAJOR_POSITIVE_INCREASE.get();
            if (major > 0) {
                villager.method_21651().method_19072(entity.method_5667(), class_4139.field_18427, major);
            }

            int minor = Config.Server.HERO_MINOR_POSITIVE_INCREASE.get();
            if (minor > 0) {
                villager.method_21651().method_19072(entity.method_5667(), class_4139.field_18426, minor);
            }
        }
    }
}
