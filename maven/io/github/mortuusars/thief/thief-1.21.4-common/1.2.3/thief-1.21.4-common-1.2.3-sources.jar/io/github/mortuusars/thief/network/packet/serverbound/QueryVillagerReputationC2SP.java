package io.github.mortuusars.thief.network.packet.serverbound;

import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.network.Packets;
import io.github.mortuusars.thief.network.packet.Packet;
import io.github.mortuusars.thief.network.packet.clientbound.VillagerGossipsS2CP;
import io.github.mortuusars.thief.network.packet.clientbound.VillagerReputationS2CP;
import net.minecraft.class_1297;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4139;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public record QueryVillagerReputationC2SP(int villagerId, boolean withGossips) implements Packet {
    public static final class_2960 ID = Thief.resource("query_villager_reputation");
    public static final class_8710.class_9154<QueryVillagerReputationC2SP> TYPE = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, QueryVillagerReputationC2SP> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48550, QueryVillagerReputationC2SP::villagerId,
            class_9135.field_48547, QueryVillagerReputationC2SP::withGossips,
            QueryVillagerReputationC2SP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Thief.LOGGER.error("Cannot handle {} packet: player is not ServerPlayer.", ID);
            return false;
        }

        @Nullable class_1297 entity = serverPlayer.method_51469().method_8469(villagerId);
        if (entity instanceof class_1646 villager) {
            Packets.sendToClient(new VillagerReputationS2CP(entity.method_5628(), villager.method_20594(player)), serverPlayer);
            if (withGossips) {
                Packets.sendToClient(new VillagerGossipsS2CP(entity.method_5628(),
                        villager.method_21651().method_19073(player.method_5667(), type -> type == class_4139.field_18424),
                        villager.method_21651().method_19073(player.method_5667(), type -> type == class_4139.field_18425),
                        villager.method_21651().method_19073(player.method_5667(), type -> type == class_4139.field_18426),
                        villager.method_21651().method_19073(player.method_5667(), type -> type == class_4139.field_18427),
                        villager.method_21651().method_19073(player.method_5667(), type -> type == class_4139.field_18428)
                ), serverPlayer);
            }
        }

        return true;
    }
}
