package io.github.mortuusars.thief.advancement.trigger;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_1309;
import net.minecraft.class_2048;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public class GuardAttacksCriminalTrigger extends class_4558<GuardAttacksCriminalTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player, class_1309 guard) {
        this.method_22510(player, triggerInstance ->
                triggerInstance.matches(player, guard));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  Optional<class_5258> guard) implements class_4558.class_8788 {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                        class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::comp_2029),
                        class_2048.field_47250.optionalFieldOf("guard").forGetter(TriggerInstance::guard))
                .apply(instance, TriggerInstance::new));

        public boolean matches(class_3222 player, class_1309 guard) {
            return this.guard.isEmpty() || this.guard.get().method_27806(class_2048.method_27802(player, guard));
        }
    }
}