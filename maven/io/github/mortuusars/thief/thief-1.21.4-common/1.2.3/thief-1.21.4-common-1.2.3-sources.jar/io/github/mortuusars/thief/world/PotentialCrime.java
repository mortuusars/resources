package io.github.mortuusars.thief.world;

import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import java.util.function.IntFunction;
import net.minecraft.class_3542;
import net.minecraft.class_7995;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public enum PotentialCrime implements class_3542 {
    NONE("none", Optional.empty()),
    LIGHT("light", Optional.of(Crime.LIGHT)),
    MEDIUM("medium", Optional.of(Crime.MEDIUM)),
    HEAVY("heavy", Optional.of(Crime.HEAVY));

    public static final Codec<PotentialCrime> CODEC = class_3542.method_28140(PotentialCrime::values);
    public static final IntFunction<PotentialCrime> BY_ID = class_7995.method_47914(PotentialCrime::ordinal, values(), class_7995.class_7996.field_41664);
    public static final class_9139<ByteBuf, PotentialCrime> STREAM_CODEC = class_9135.method_56375(BY_ID, PotentialCrime::ordinal);

    private final String name;
    private final Optional<Crime> offence;

    PotentialCrime(String name, Optional<Crime> offence) {
        this.name = name;
        this.offence = offence;
    }

    public Optional<Crime> getCrime() {
        return offence;
    }

    @Override
    public @NotNull String method_15434() {
        return name;
    }
}
