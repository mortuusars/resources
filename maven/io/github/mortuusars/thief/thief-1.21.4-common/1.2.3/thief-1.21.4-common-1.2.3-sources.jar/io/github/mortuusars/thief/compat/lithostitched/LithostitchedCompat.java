package io.github.mortuusars.thief.compat.lithostitched;

import dev.worldgen.lithostitched.worldgen.structure.DelegatingStructure;
import java.util.Iterator;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3449;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class LithostitchedCompat {
    public static class_3449 getStructureWithPieceAt(class_3218 level, class_2338 pos, class_6862<class_3195> structureTag) {
        class_2378<class_3195> registry = level.method_30349().method_30530(class_7924.field_41246);
        Iterator<class_3449> structures = level.method_27056().method_41035(new class_1923(pos),
                structure -> {
                    if (structure instanceof DelegatingStructure delegatingStructure) {
                        structure = delegatingStructure.delegate();
                    }
                    return registry.method_40265(registry.method_10206(structure))
                            .map(reference -> reference.method_40220(structureTag))
                            .orElse(false);
                }).iterator();

        class_3449 structureStart;
        do {
            if (!structures.hasNext()) {
                return class_3449.field_16713;
            }
            structureStart = structures.next();
        } while (!level.method_27056().method_41033(pos, structureStart));
        return structureStart;
    }
}
