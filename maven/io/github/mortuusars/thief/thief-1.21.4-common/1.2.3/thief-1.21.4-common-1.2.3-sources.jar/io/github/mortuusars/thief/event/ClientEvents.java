package io.github.mortuusars.thief.event;

import io.github.mortuusars.thief.client.VillagerReputationTooltip;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public class ClientEvents {
    public static void renderGui(class_332 guiGraphics, class_9779 deltaTracker) {
        VillagerReputationTooltip.render(guiGraphics, deltaTracker);
    }
}
