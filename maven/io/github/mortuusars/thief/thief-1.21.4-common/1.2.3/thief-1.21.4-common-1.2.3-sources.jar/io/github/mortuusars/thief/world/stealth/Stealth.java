package io.github.mortuusars.thief.world.stealth;

import io.github.mortuusars.thief.world.stealth.modifier.DarknessModifier;
import io.github.mortuusars.thief.world.stealth.modifier.InvisibilityModifier;
import io.github.mortuusars.thief.world.stealth.modifier.SneakingModifier;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_3532;

public class Stealth {
    private static final List<VisibilityModifier> visibilityModifiers;

    static {
        visibilityModifiers = new ArrayList<>();
        addModifier(new InvisibilityModifier());
        addModifier(new SneakingModifier());
        addModifier(new DarknessModifier());
    }

    public static List<VisibilityModifier> getVisibilityModifiers() {
        return visibilityModifiers;
    }

    public static void addModifier(VisibilityModifier modifier) {
        visibilityModifiers.add(modifier);
    }

    // --

    public static double getVisibility(class_1309 criminal) {
        double value = 1f;
        for (VisibilityModifier modifier : visibilityModifiers) {
            value = modifier.modify(criminal, value);
        }
        return class_3532.method_15350(value, 0.0, 1.0);
    }

    // --

    public interface VisibilityModifier {
        double modify(class_1309 entity, double value);
    }
}
