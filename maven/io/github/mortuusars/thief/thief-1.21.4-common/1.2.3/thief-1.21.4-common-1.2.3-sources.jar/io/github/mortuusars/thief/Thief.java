package io.github.mortuusars.thief;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.thief.advancement.trigger.CrimeCommitedTrigger;
import io.github.mortuusars.thief.advancement.trigger.GuardAttacksCriminalTrigger;
import io.github.mortuusars.thief.advancement.trigger.VillagerGiftTrigger;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3446;
import net.minecraft.class_6862;
import net.minecraft.class_7923;

public class Thief {
    public static final String ID = "thief";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static void init() {
        CriteriaTriggers.init();
    }

    /**
     * Creates resource location in the mod namespace with the given path.
     */
    public static class_2960 resource(String path) {
        return class_2960.method_60655(ID, path);
    }

    public static class Stats {
        public static final Map<class_2960, class_3446> STATS = new HashMap<>();

        public static final class_2960 CAUGHT_COMMITING_LIGHT_CRIMES =
              register(resource("caught_commiting_light_crimes"), class_3446.field_16975);
        public static final class_2960 CAUGHT_COMMITING_MEDIUM_CRIMES =
              register(resource("caught_commiting_medium_crimes"), class_3446.field_16975);
        public static final class_2960 CAUGHT_COMMITING_HEAVY_CRIMES =
              register(resource("caught_commiting_heavy_crimes"), class_3446.field_16975);

        @SuppressWarnings("SameParameterValue")
        private static class_2960 register(class_2960 location, class_3446 formatter) {
            STATS.put(location, formatter);
            return location;
        }

        public static void register() {
            STATS.forEach((location, formatter) -> {
                class_2378.method_10230(class_7923.field_41183, location, location);
                net.minecraft.class_3468.field_15419.method_14955(location, formatter);
            });
        }
    }

    public static class CriteriaTriggers {
        public static Supplier<CrimeCommitedTrigger> CRIME_COMMITED = Register.criterionTrigger("crime_committed", CrimeCommitedTrigger::new);
        public static Supplier<VillagerGiftTrigger> VILLAGER_GIFT = Register.criterionTrigger("villager_gift", VillagerGiftTrigger::new);
        public static Supplier<GuardAttacksCriminalTrigger> GUARD_ATTACKS_CRIMINAL = Register.criterionTrigger("guard_attacks_criminal", GuardAttacksCriminalTrigger::new);

        public static void init() {
        }
    }

    public static class Tags {
        public static class Items {
            public static final class_6862<class_1792> VILLAGER_GIFTS =
                    class_6862.method_40092(net.minecraft.class_7924.field_41197, resource("villager_gifts"));
        }

        public static class Blocks {
            public static final class_6862<class_2248> BREAK_PROTECTED_LIGHT =
                    class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("break_protected/light"));
            public static final class_6862<class_2248> BREAK_PROTECTED_MEDIUM =
                    class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("break_protected/medium"));
            public static final class_6862<class_2248> BREAK_PROTECTED_HEAVY =
                    class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("break_protected/heavy"));

            public static final class_6862<class_2248> INTERACT_PROTECTED_LIGHT =
                    class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("interact_protected/light"));
            public static final class_6862<class_2248> INTERACT_PROTECTED_MEDIUM =
                    class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("interact_protected/medium"));
            public static final class_6862<class_2248> INTERACT_PROTECTED_HEAVY =
                    class_6862.method_40092(net.minecraft.class_7924.field_41254, resource("interact_protected/heavy"));
        }

        public static class EntityTypes {
            public static final class_6862<class_1299<?>> KILLING_PROTECTED_LIGHT =
                    class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("killing_protected/light"));
            public static final class_6862<class_1299<?>> KILLING_PROTECTED_MEDIUM =
                    class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("killing_protected/medium"));
            public static final class_6862<class_1299<?>> KILLING_PROTECTED_HEAVY =
                    class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("killing_protected/heavy"));

            public static final class_6862<class_1299<?>> WITNESSES =
                    class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("witnesses"));

            public static final class_6862<class_1299<?>> GUARDS =
                    class_6862.method_40092(net.minecraft.class_7924.field_41266, resource("guards"));
        }

        public static class Structures {
            public static final class_6862<class_3195> PROTECTED =
                    class_6862.method_40092(net.minecraft.class_7924.field_41246, resource("protected"));
        }
    }
}
