package io.github.mortuusars.thief.mixin.thief_reputation_events;

import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalIntRef;
import io.github.mortuusars.thief.PlatformHelper;
import io.github.mortuusars.thief.world.Crime;
import io.github.mortuusars.thief.world.Reputation;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_1937;
import net.minecraft.class_3988;
import net.minecraft.class_4136;
import net.minecraft.class_4139;
import net.minecraft.class_4151;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1646.class)
public abstract class VillagerMixin extends class_3988 {
    @Shadow @Final private class_4136 gossips;

    @Shadow public abstract class_4136 getGossips();

    public VillagerMixin(class_1299<? extends class_3988> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "onReputationEventFrom", at = @At("HEAD"))
    private void onReputationEventPre(class_4151 type, class_1297 target, CallbackInfo ci,
                                      @Share("reputationBefore") LocalIntRef reputationBefore) {
        reputationBefore.set(getGossips().method_19073(target.method_5667(), gossip -> true));

        if (type instanceof Crime crime) {
            int major = crime.getMajorNegativeChange();
            if (major > 0) {
                gossips.method_19072(target.method_5667(), class_4139.field_18424, major);
            }

            int minor = crime.getMinorNegativeChange();
            if (minor > 0) {
                gossips.method_19072(target.method_5667(), class_4139.field_18425, minor);
            }
        }
    }

    @Inject(method = "onReputationEventFrom", at = @At("RETURN"))
    private void onReputationEventPost(class_4151 type, class_1297 target, CallbackInfo ci,
                                       @Share("reputationBefore") LocalIntRef reputationBefore) {
        Reputation before = Reputation.fromValue(reputationBefore.get());
        Reputation after = Reputation.fromValue(getGossips().method_19073(target.method_5667(), gossip -> true));

        if (before != after && target instanceof class_1309 livingEntity) {
            PlatformHelper.fireReputationLevelChangedEvent(livingEntity, (class_1646)(Object)this, before, after);
        }
    }
}
