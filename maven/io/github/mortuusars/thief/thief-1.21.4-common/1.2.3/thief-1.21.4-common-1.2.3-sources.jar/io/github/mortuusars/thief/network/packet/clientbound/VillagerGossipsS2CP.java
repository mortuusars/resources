package io.github.mortuusars.thief.network.packet.clientbound;

import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.network.handler.ClientPacketsHandler;
import io.github.mortuusars.thief.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record VillagerGossipsS2CP(int villagerId, int majorNegative, int minorNegative, int minorPositive,
                                  int majorPositive, int trading) implements Packet {
    public static final class_2960 ID = Thief.resource("villager_gossips");
    public static final class_9154<VillagerGossipsS2CP> TYPE = new class_9154<>(ID);

    public static final class_9139<class_2540, VillagerGossipsS2CP> STREAM_CODEC = class_9139.method_58025(
            class_9135.field_48550, VillagerGossipsS2CP::villagerId,
            class_9135.field_48550, VillagerGossipsS2CP::majorNegative,
            class_9135.field_48550, VillagerGossipsS2CP::minorNegative,
            class_9135.field_48550, VillagerGossipsS2CP::minorPositive,
            class_9135.field_48550, VillagerGossipsS2CP::majorPositive,
            class_9135.field_48550, VillagerGossipsS2CP::trading,
            VillagerGossipsS2CP::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        ClientPacketsHandler.receiveVillagerGossips(this);
        return true;
    }
}
