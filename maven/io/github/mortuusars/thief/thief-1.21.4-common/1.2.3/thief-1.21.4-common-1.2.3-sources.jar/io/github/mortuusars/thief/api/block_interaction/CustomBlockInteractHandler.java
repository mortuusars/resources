package io.github.mortuusars.thief.api.block_interaction;

import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public interface CustomBlockInteractHandler {
    /**
     * Handles block interaction. This is called for every block, not just ones tagged as #thief:interact_protected/level.
     * @return If anything other than PASS is returned, default Thief logic is cancelled, and no justice will be served.<br>
     */
    class_1269 handle(class_3222 player, class_2338 pos, class_2680 state);
}
