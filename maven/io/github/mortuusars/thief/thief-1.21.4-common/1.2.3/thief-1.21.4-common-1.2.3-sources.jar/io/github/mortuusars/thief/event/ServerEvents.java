package io.github.mortuusars.thief.event;

import io.github.mortuusars.thief.api.block_interaction.BlockInteraction;
import io.github.mortuusars.thief.world.Crime;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public class ServerEvents {
    public static void onBlockDestroyedByPlayer(class_3222 player, class_2338 pos, class_2680 state) {
        Crime.fromBlockStateBreaking(player, pos, state).getCrime().ifPresent(crime ->
                crime.commit(player.method_51469(), player, pos));
    }

    public static void onBlockInteract(class_3222 player, class_2338 pos, class_1268 hand) {
        if (hand == class_1268.field_5810) {
            return; // Handling only main hand should be enough.
        }

        class_2680 state = player.method_37908().method_8320(pos);

        if (BlockInteraction.handle(player, pos, state) != class_1269.field_5811) {
            return;
        }

        Crime.fromBlockStateInteracting(player, pos, state).getCrime().ifPresent(crime ->
                crime.commit(player.method_51469(), player, pos));
    }

    public static void onEntityKilled(class_3222 player, class_1309 target, class_1282 damageSource) {
        Crime.fromKilling(player, target).getCrime().ifPresent(crime ->
              crime.commit(player.method_51469(), player, target.method_24515()));
    }
}
