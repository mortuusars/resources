package io.github.mortuusars.thief.fabric;

import io.github.mortuusars.thief.fabric.api.event.CrimeCommitedCallback;
import io.github.mortuusars.thief.fabric.api.event.GiftGivenCallback;
import io.github.mortuusars.thief.fabric.api.event.ReputationLevelChangedCallback;
import io.github.mortuusars.thief.world.Crime;
import io.github.mortuusars.thief.world.Reputation;
import io.netty.buffer.ByteBufUtil;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_9129;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;

public class PlatformHelperImpl {
    public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_9129> extraDataWriter) {
        ExtendedScreenHandlerFactory<byte[]> extendedScreenHandlerFactory = new ExtendedScreenHandlerFactory<byte[]>() {
            @Override
            public byte[] getScreenOpeningData(class_3222 player) {
                class_9129 buffer = new class_9129(PacketByteBufs.create(), player.method_56673());
                extraDataWriter.accept(buffer);
                byte[] bytes = ByteBufUtil.getBytes(buffer);
                buffer.release();
                return bytes;
            }

            @Nullable
            @Override
            public class_1703 createMenu(int i, @NotNull class_1661 inventory, @NotNull class_1657 player) {
                return menuProvider.createMenu(i, inventory, player);
            }

            @Override
            public @NotNull class_2561 getDisplayName() {
                return menuProvider.method_5476();
            }
        };

        serverPlayer.method_17355(extendedScreenHandlerFactory);
    }

    public static boolean isModLoaded(String modId) {
        return FabricLoader.getInstance().isModLoaded(modId);
    }

    public static boolean isInDevEnv() {
        return FabricLoader.getInstance().isDevelopmentEnvironment();
    }

    public static void fireCrimeCommitedEvent(class_1309 criminal, Crime crime, List<class_1309> witnesses) {
        CrimeCommitedCallback.EVENT.invoker().crimeCommited(criminal, crime, witnesses);
    }

    public static void fireGiftGivenEvent(class_3222 player, class_1646 villager, class_1799 gift) {
        GiftGivenCallback.EVENT.invoker().giftGiven(player, villager, gift);
    }

    public static void fireReputationLevelChangedEvent(class_1309 criminal, class_1646 villager, Reputation oldReputation, Reputation newReputation) {
        ReputationLevelChangedCallback.EVENT.invoker().giftGiven(criminal, villager, oldReputation, newReputation);
    }
}
