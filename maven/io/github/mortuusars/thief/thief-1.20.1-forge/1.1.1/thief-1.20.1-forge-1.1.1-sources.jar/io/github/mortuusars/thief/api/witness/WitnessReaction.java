package io.github.mortuusars.thief.api.witness;

import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.world.Crime;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityEvent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.npc.Villager;

import java.util.ArrayList;
import java.util.List;

/**
 * Allows registering custom handlers for witness reactions of a crime.<br>
 * Can be used for entities other than villagers.<br>
 * Use {@link WitnessReaction#register} to register handlers.
 */
public class WitnessReaction {
    private static final List<WitnessReactionHandler> handlers = new ArrayList<>();

    static {
        register((level, crime, witness, criminal) -> {
            if (witness instanceof Villager villager) {
                villager.m_35518_();
                level.m_8670_(crime, criminal, villager);
                level.m_7605_(villager, EntityEvent.f_147017_);
                return true;
            }
            return false;
        });

        register((level, crime, witness, criminal) -> {
            if (witness.m_6095_().m_204039_(Thief.Tags.EntityTypes.GUARDS)
                    && witness instanceof NeutralMob neutralMob
                    && crime.shouldGuardsAttack(level, witness, criminal)
                    && witness.m_6779_(criminal)
                    && neutralMob.m_5448_() == null) { // Only if not already attacking something
                neutralMob.m_6710_(criminal); // Attack

                for (int i = 0; i < 5; i++) {
                    double d = witness.m_217043_().m_188583_() * 0.02;
                    double e = witness.m_217043_().m_188583_() * 0.02;
                    double f = witness.m_217043_().m_188583_() * 0.02;
                    level.m_8767_(ParticleTypes.f_123792_,
                            witness.m_20208_(1.0),
                            witness.m_20187_() + 1.0,
                            witness.m_20262_(1.0),
                            5, d, e, f, 0.01);
                }

                return true;
            }
            return false;
        });
    }

    public static void register(WitnessReactionHandler handler) {
        handlers.add(handler);
    }

    public static boolean handle(ServerLevel serverLevel, Crime crime, LivingEntity witness, LivingEntity criminal) {
        for (WitnessReactionHandler handler : handlers) {
            boolean result = handler.handle(serverLevel, crime, witness, criminal);
            if (result) {
                return true;
            }
        }
        return false;
    }
}
