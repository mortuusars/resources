package io.github.mortuusars.thief.world;

import io.github.mortuusars.thief.Config;
import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.world.stealth.Stealth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

import java.util.Collections;
import java.util.List;

public class Witness {
    public static List<LivingEntity> getWitnesses(LivingEntity criminal) {
        if (criminal instanceof Player player && (player.m_7500_() || player.m_5833_())) {
            return Collections.emptyList();
        }

        double visibility = Stealth.getVisibility(criminal);

        int radius = Config.Common.WITNESS_MAX_DISTANCE.get();
        AABB crimeScene = new AABB(criminal.m_20183_()).m_82377_(radius, radius * 0.5f, radius);

        return criminal.m_9236_().m_45976_(LivingEntity.class, crimeScene)
                .stream()
                .filter(e -> isWitness(criminal, e, visibility))
                .toList();
    }

    public static <T extends LivingEntity> List<T> getWitnesses(LivingEntity criminal, Class<T> entityClass) {
        if (criminal instanceof Player player && (player.m_7500_() || player.m_5833_())) {
            return Collections.emptyList();
        }

        double visibility = Stealth.getVisibility(criminal);

        int radius = Config.Common.WITNESS_MAX_DISTANCE.get();
        AABB crimeScene = new AABB(criminal.m_20183_()).m_82377_(radius, radius * 0.5f, radius);

        return criminal.m_9236_().m_45976_(entityClass, crimeScene)
                .stream()
                .filter(e -> isWitness(criminal, e, visibility))
                .toList();
    }

    public static boolean isWitness(LivingEntity criminal, LivingEntity entity, double visibility) {
        if (!entity.m_6095_().m_204039_(Thief.Tags.EntityTypes.WITNESSES)) return false;
        float distance = entity.m_20270_(criminal);
        if (distance <= Config.Common.WITNESS_ALWAYS_NOTICE_DISTANCE.get() / 2.0) return true; // Too close. Always hears or sees the crime.
        if (entity.m_5803_()) return false; // Cannot hear the crime.
        if (distance <= Config.Common.WITNESS_ALWAYS_NOTICE_DISTANCE.get()) return true; // Hears or sees if not sleeping.
        if (distance > Config.Common.WITNESS_MAX_DISTANCE.get() * visibility) return false;
        return entity.m_142582_(criminal);
    }
}
