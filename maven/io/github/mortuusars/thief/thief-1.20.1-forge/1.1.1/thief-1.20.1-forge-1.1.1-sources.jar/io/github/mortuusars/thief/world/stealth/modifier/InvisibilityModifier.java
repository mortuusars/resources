package io.github.mortuusars.thief.world.stealth.modifier;

import io.github.mortuusars.thief.world.stealth.Stealth;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;

public class InvisibilityModifier implements Stealth.VisibilityModifier {
    @Override
    public double modify(LivingEntity entity, double value) {
        return entity.m_21124_(MobEffects.f_19609_) != null
                ? value * 0.25f
                : value;
    }
}
