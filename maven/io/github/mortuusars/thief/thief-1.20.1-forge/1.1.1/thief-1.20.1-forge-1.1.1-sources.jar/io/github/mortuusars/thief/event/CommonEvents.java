package io.github.mortuusars.thief.event;

import com.mojang.brigadier.CommandDispatcher;
import io.github.mortuusars.thief.Config;
import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.command.ThiefCommand;
import io.github.mortuusars.thief.world.Crime;
import io.github.mortuusars.thief.world.Reputation;
import io.github.mortuusars.thief.world.Witness;
import io.github.mortuusars.thief.world.stealth.Stealth;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityEvent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.gossip.GossipType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.schedule.Activity;
import net.minecraft.world.item.ItemStack;

import java.util.List;

public class CommonEvents {
    private static long lastGiftSoundPlayedAt = -1;

    public static InteractionResult onEntityInteracted(Player player, InteractionHand hand, Entity target) {
        if (hand != InteractionHand.MAIN_HAND || !(player instanceof ServerPlayer serverPlayer) || !(target instanceof Villager villager)) {
            return InteractionResult.PASS;
        }

        ItemStack item = player.m_21120_(hand);
        if ((!Config.Common.REQUIRES_SNEAK.get() || player.m_36341_()) && canGift(serverPlayer, villager, item)) {
            ItemStack gift = item.m_41620_(1);

            int minorPositiveRep = villager.m_35517_().m_26195_(player.m_20148_(), gossipType -> gossipType == GossipType.MINOR_POSITIVE);
            if (minorPositiveRep < 20) {
                villager.m_35517_().m_26191_(player.m_20148_(), GossipType.MINOR_POSITIVE,
                        Config.Common.GIFTS_MINOR_POSITIVE_INCREASE.get());
            }
            villager.m_35517_().m_148175_(player.m_20148_(), GossipType.MINOR_NEGATIVE,
                    Config.Common.GIFTS_MINOR_NEGATIVE_REDUCTION.get());

            // Calm down panicking villager
            if (villager.m_6274_().m_21954_(Activity.f_37984_) && villager.m_35532_(player) > -60) {
                villager.m_6274_().m_21889_(Activity.f_37979_);
            }

            player.m_9236_().m_7605_(villager, EntityEvent.f_147018_);
            if (player.m_9236_().m_46467_() - lastGiftSoundPlayedAt > 10) { // Prevent sound spam
                player.m_9236_().m_6269_(null, villager, SoundEvents.f_12504_, SoundSource.NEUTRAL, 1, 1);
                lastGiftSoundPlayedAt = player.m_9236_().m_46467_();
            }

            Thief.CriteriaTriggers.VILLAGER_GIFT.trigger(serverPlayer, villager, gift);

            return InteractionResult.SUCCESS;
        }

        if (!Reputation.fromValue(villager, player).canTrade()) {
            // Prevent trading
            villager.m_35518_();
            return InteractionResult.SUCCESS;
        }

        return InteractionResult.PASS;
    }

    public static boolean canGift(ServerPlayer player, Villager villager, ItemStack item) {
        if (!Config.Common.GIFTS_ENABLED.get()) return false;
        if (!item.m_204117_(Thief.Tags.Items.VILLAGER_GIFTS)) return false;
        int minorPositiveRep = villager.m_35517_().m_26195_(player.m_20148_(), gossipType -> gossipType == GossipType.MINOR_POSITIVE);
        int minorNegativeRep = villager.m_35517_().m_26195_(player.m_20148_(), gossipType -> gossipType == GossipType.MINOR_NEGATIVE);
        return minorPositiveRep < 20 /* limit as in 1.21*/ || minorNegativeRep < 0;
    }

    public static void onPlayerTick(Player player) {
        if (ThiefCommand.showNoticeDistanceAndWitnesses
                && player instanceof ServerPlayer serverPlayer
                && player.m_9236_().m_46467_() % 3 == 0) {

            List<LivingEntity> witnesses = Witness.getWitnesses(player);
            for (LivingEntity witness : witnesses) {
                witness.m_7292_(new MobEffectInstance(MobEffects.f_19619_, 4));
            }

            double radius = Config.Common.WITNESS_MAX_DISTANCE.get() * Stealth.getVisibility(serverPlayer);
            int particles = 64; // number of particles in the ring

            for (int i = 0; i < particles; i++) {
                double angle = 2 * Math.PI * i / particles;
                double x = player.m_20185_() + radius * Math.cos(angle);
                double z = player.m_20189_() + radius * Math.sin(angle);
                double y = player.m_20186_() + 1;

                serverPlayer.m_284548_().m_8624_(serverPlayer, ParticleTypes.f_123813_, true, x, y, z, 1, 0, 0, 0, 0);
            }
        }
    }

    public static void registerCommands(CommandDispatcher<CommandSourceStack> dispatcher,
                                        CommandBuildContext context, Commands.CommandSelection environment) {
        ThiefCommand.register(dispatcher);
    }
}
