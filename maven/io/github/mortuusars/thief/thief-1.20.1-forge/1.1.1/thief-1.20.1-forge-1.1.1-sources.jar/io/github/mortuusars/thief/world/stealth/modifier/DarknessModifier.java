package io.github.mortuusars.thief.world.stealth.modifier;

import io.github.mortuusars.thief.world.stealth.Stealth;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;

public class DarknessModifier implements Stealth.VisibilityModifier {
    @Override
    public double modify(LivingEntity entity, double value) {
        int lightLevel = getLightLevelAt(entity.m_9236_(), entity.m_20183_());
        return value * Mth.m_184637_(lightLevel, 0, 15, 0.25f, 1f);
    }

    public static int getLightLevelAt(Level level, BlockPos pos) {
        if (level.f_46443_) {
            // This updates 'getSkyDarken' on the client. It'll return 0 if we don't update it.
            level.m_46465_();
        }
        int skyBrightness = level.m_45517_(LightLayer.SKY, pos);
        int blockBrightness = level.m_45517_(LightLayer.BLOCK, pos);
        return skyBrightness < 15 ?
                Math.max(blockBrightness, (int) (skyBrightness * ((15 - level.m_7445_()) / 15f))) :
                Math.max(blockBrightness, 15 - level.m_7445_());
    }
}
