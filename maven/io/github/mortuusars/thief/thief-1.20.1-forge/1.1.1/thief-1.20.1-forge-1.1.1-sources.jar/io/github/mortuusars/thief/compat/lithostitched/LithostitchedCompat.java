package io.github.mortuusars.thief.compat.lithostitched;

import dev.worldgen.lithostitched.worldgen.structure.DelegatingStructure;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureStart;

import java.util.Iterator;

public class LithostitchedCompat {
    public static StructureStart getStructureWithPieceAt(ServerLevel level, BlockPos pos, TagKey<Structure> structureTag) {
        Registry<Structure> registry = level.m_9598_().m_175515_(Registries.f_256944_);
        Iterator<StructureStart> structures = level.m_215010_().m_220477_(new ChunkPos(pos),
                structure -> {
                    if (structure instanceof DelegatingStructure delegatingStructure) {
                        structure = delegatingStructure.delegate();
                    }
                    return registry.m_203300_(registry.m_7447_(structure))
                            .map(reference -> reference.m_203656_(structureTag))
                            .orElse(false);
                }).iterator();

        StructureStart structureStart;
        do {
            if (!structures.hasNext()) {
                return StructureStart.f_73561_;
            }
            structureStart = structures.next();
        } while (!level.m_215010_().m_220497_(pos, structureStart));
        return structureStart;
    }
}
