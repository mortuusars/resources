package io.github.mortuusars.thief.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.thief.world.Crime;
import io.github.mortuusars.thief.world.Reputation;
import io.github.mortuusars.thief.world.Witness;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.Villager;

import java.util.List;

public class ThiefCommand {
    public static boolean showNoticeDistanceAndWitnesses = false;

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.m_82127_("thief")
                .requires((stack) -> stack.m_6761_(2))
                .then(Commands.m_82127_("debug")
                        .then(Commands.m_82127_("is_in_protected_structure")
                                .executes(ThiefCommand::isInProtectedStructure))
                        .then(Commands.m_82127_("show_notice_distance_and_witnesses")
                                .executes(ThiefCommand::showNoticeDistance))
                        .then(Commands.m_82127_("show_witness_reputation")
                                .executes(ThiefCommand::showWitnessReputation)))
                .then(Commands.m_82127_("commit_crime")
                        .then(Commands.m_82129_("player", EntityArgument.m_91466_())
                                .then(Commands.m_82127_("light")
                                        .executes(context -> commitCrime(context, Crime.LIGHT)))
                                .then(Commands.m_82127_("medium")
                                        .executes(context -> commitCrime(context, Crime.MEDIUM)))
                                .then(Commands.m_82127_("heavy")
                                        .executes(context -> commitCrime(context, Crime.HEAVY))))));
    }

    // Debug --

    private static int isInProtectedStructure(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer player = context.getSource().m_81375_();
        context.getSource().m_288197_(() -> Component.m_237113_("Is in '#thief:protected' structure: " +
                Crime.isInProtectedStructure(context.getSource().m_81372_(), player.m_20183_())), true);
        return 0;
    }

    private static int showNoticeDistance(CommandContext<CommandSourceStack> context) {
        if (showNoticeDistanceAndWitnesses) {
            showNoticeDistanceAndWitnesses = false;
            context.getSource().m_288197_(() -> Component.m_237113_("Turned off thief notice distance showing."), true);
        } else {
            showNoticeDistanceAndWitnesses = true;
            context.getSource().m_288197_(() -> Component.m_237113_("Showing thief notice distance."), true);
        }
        return 0;
    }

    private static int showWitnessReputation(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer player = context.getSource().m_81375_();

        if (player.m_7500_() || player.m_5833_()) {
            context.getSource().m_288197_(() -> Component.m_237113_("You need to be in survival mode to be noticed by others."), true);
            return 0;
        }

        List<Villager> villagers = Witness.getWitnesses(player)
                .stream()
                .filter(entity -> entity instanceof Villager)
                .map(entity -> (Villager) entity)
                .toList();

        if (villagers.isEmpty()) {
            context.getSource().m_288197_(() -> Component.m_237113_("No witnesses."), true);
            return 0;
        }

        int averageValue = Reputation.averageValueFromVillagers(player, villagers);
        Reputation reputation = Reputation.fromValue(averageValue);

        context.getSource().m_288197_(() -> Component.m_237113_("Average reputation of " + villagers.size() + " witnesses is: ")
                .m_7220_(reputation.getLocalizedNameWithColor())
                .m_7220_(Component.m_237113_(" (" + averageValue + ")").m_130948_(
                        Style.f_131099_.m_178520_(reputation.getColor()))), true);

        return 0;
    }

    private static int commitCrime(CommandContext<CommandSourceStack> context, Crime crime) throws CommandSyntaxException {
        ServerPlayer player = context.getSource().m_81375_();

        Crime.Outcome outcome = crime.commit(player.m_284548_(), player, player.m_20183_());
        if (outcome.punished()) {
            context.getSource().m_288197_(() -> Component.m_237113_(
                            player.m_6302_() + " has commited " + crime.getName() + " crime with "
                                    + outcome.witnesses().size() + " witnesses.")
                    .m_130940_(ChatFormatting.RED), true);
        } else {
            context.getSource().m_288197_(() -> Component.m_237113_(
                            player.m_6302_() + " has commited " + crime.getName() + " crime, but no one saw that.")
                    .m_130940_(ChatFormatting.RED), true);
        }

        return 0;
    }
}
