package io.github.mortuusars.thief.mixin.raid_win_reputation;

import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.thief.Config;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.gossip.GossipType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.raid.Raid;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(Raid.class)
public abstract class RaidMixin {
    @Shadow public abstract Level getLevel();
    @Shadow public abstract BlockPos getCenter();

    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;awardStat(Lnet/minecraft/resources/ResourceLocation;)V"))
    private void onTick(CallbackInfo ci, @Local LivingEntity entity) {
        List<Villager> villagers = getLevel().m_45976_(Villager.class, new AABB(getCenter()).m_82400_(128));
        for (Villager villager : villagers) {
            int major = Config.Common.HERO_MAJOR_POSITIVE_INCREASE.get();
            if (major > 0) {
                villager.m_35517_().m_26191_(entity.m_20148_(), GossipType.MAJOR_POSITIVE, major);
            }

            int minor = Config.Common.HERO_MINOR_POSITIVE_INCREASE.get();
            if (minor > 0) {
                villager.m_35517_().m_26191_(entity.m_20148_(), GossipType.MINOR_POSITIVE, minor);
            }
        }
    }
}
