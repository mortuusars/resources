package io.github.mortuusars.thief.advancement.trigger;

import com.google.gson.JsonObject;
import io.github.mortuusars.thief.Thief;
import net.minecraft.advancements.critereon.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

public class VillagerGiftTrigger extends SimpleCriterionTrigger<VillagerGiftTrigger.TriggerInstance> {
    public static final ResourceLocation ID = Thief.resource("villager_gift");

    public @NotNull ResourceLocation m_7295_() {
        return ID;
    }

    @Override
    protected @NotNull TriggerInstance m_7214_(JsonObject json, @NotNull ContextAwarePredicate predicate,
                                                      @NotNull DeserializationContext deserializationContext) {
        EntityPredicate entityPredicate = EntityPredicate.m_36614_(json.get("entity"));
        ItemPredicate itemPredicate = ItemPredicate.m_45051_(json.get("gift"));
        return new TriggerInstance(predicate, entityPredicate, itemPredicate);
    }

    public void trigger(ServerPlayer player, Villager villager, ItemStack gift) {
        this.m_66234_(player, triggerInstance -> triggerInstance.matches(player, villager, gift));
    }

    public static class TriggerInstance extends AbstractCriterionTriggerInstance {
        private final EntityPredicate entityPredicate;
        private final ItemPredicate itemPredicate;

        public TriggerInstance(ContextAwarePredicate predicate, EntityPredicate entityPredicate, ItemPredicate itemPredicate) {
            super(ID, predicate);
            this.entityPredicate = entityPredicate;
            this.itemPredicate = itemPredicate;
        }

        public boolean matches(ServerPlayer player, Villager villager, ItemStack gift) {
            return (this.entityPredicate.equals(EntityPredicate.f_36550_) || this.entityPredicate.m_36611_(player, villager))
                    && (this.itemPredicate.equals(ItemPredicate.f_45028_) || this.itemPredicate.m_45049_(gift));
        }

        public @NotNull JsonObject m_7683_(@NotNull SerializationContext conditions) {
            JsonObject jsonobject = super.m_7683_(conditions);
            jsonobject.add("entity", this.entityPredicate.m_36606_());
            jsonobject.add("gift", this.itemPredicate.m_45048_());
            return jsonobject;
        }
    }
}