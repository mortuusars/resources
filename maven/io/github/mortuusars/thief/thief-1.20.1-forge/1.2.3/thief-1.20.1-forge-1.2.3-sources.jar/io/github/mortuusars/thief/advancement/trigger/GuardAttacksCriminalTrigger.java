package io.github.mortuusars.thief.advancement.trigger;

import com.google.gson.JsonObject;
import io.github.mortuusars.thief.Thief;
import net.minecraft.advancements.critereon.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import org.jetbrains.annotations.NotNull;

public class GuardAttacksCriminalTrigger extends SimpleCriterionTrigger<GuardAttacksCriminalTrigger.TriggerInstance> {
    public static final ResourceLocation ID = Thief.resource("guard_attacks_criminal");

    public @NotNull ResourceLocation m_7295_() {
        return ID;
    }

    @Override
    protected @NotNull TriggerInstance m_7214_(JsonObject json, @NotNull ContextAwarePredicate predicate,
                                                      @NotNull DeserializationContext deserializationContext) {
        EntityPredicate guard = EntityPredicate.m_36614_(json.get("guard"));
        return new TriggerInstance(predicate, guard);
    }

    public void trigger(ServerPlayer player, LivingEntity guard) {
        this.m_66234_(player, triggerInstance -> triggerInstance.matches(player, guard));
    }

    public static class TriggerInstance extends AbstractCriterionTriggerInstance {
        private final EntityPredicate guard;

        public TriggerInstance(ContextAwarePredicate predicate, EntityPredicate guard) {
            super(ID, predicate);
            this.guard = guard;
        }

        public boolean matches(ServerPlayer player, LivingEntity guard) {
            return this.guard.equals(EntityPredicate.f_36550_) || this.guard.m_36611_(player, guard);
        }

        public @NotNull JsonObject m_7683_(@NotNull SerializationContext conditions) {
            JsonObject jsonobject = super.m_7683_(conditions);
            jsonobject.add("guard", this.guard.m_36606_());
            return jsonobject;
        }
    }
}