package io.github.mortuusars.thief.client;

import io.github.mortuusars.thief.Config;
import io.github.mortuusars.thief.Thief;
import io.github.mortuusars.thief.network.Packets;
import io.github.mortuusars.thief.network.packet.serverbound.QueryVillagerReputationC2SP;
import io.github.mortuusars.thief.world.Reputation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.phys.EntityHitResult;

import java.util.ArrayList;

public class VillagerReputationTooltip {
    private static int lastVillagerId = -1;
    private static long lastRequestTime = -1L;
    private static int lastReputation = 0;

    // Gossips
    private static int lastGossipsVillagerId = -1;
    private static int lastMajorNegative;
    private static int lastMinorNegative;
    private static int lastMinorPositive;
    private static int lastMajorPositive;
    private static int lastTrading;

    public static void render(GuiGraphics guiGraphics, float partialTicks) {
        if (!Config.Client.SHOW_VILLAGER_REPUTATION_TOOLTIP.get()) return;

        Minecraft minecraft = Minecraft.m_91087_();
        if (minecraft.f_91073_ == null || minecraft.f_91074_ == null || minecraft.f_91074_.m_5833_() || minecraft.f_91080_ != null
                || !minecraft.f_91074_.m_21205_().m_204117_(Thief.Tags.Items.VILLAGER_GIFTS)
                || !(minecraft.f_91077_ instanceof EntityHitResult entityHitResult)
                || !(entityHitResult.m_82443_() instanceof Villager villager)) {
            return;
        }

        long gameTime = minecraft.f_91073_.m_46467_();
        if (gameTime - lastRequestTime > 5) {
            Packets.sendToServer(new QueryVillagerReputationC2SP(villager.m_19879_(), Minecraft.m_91087_().f_91066_.f_92125_));
            lastRequestTime = gameTime;
        }

        if (lastVillagerId != villager.m_19879_()) {
            return;
        }

        Reputation reputation = Reputation.fromValue(lastReputation);

        MutableComponent name = reputation.getLocalizedNameWithColor();
        if (Minecraft.m_91087_().f_91066_.f_92125_) {
            name.m_130946_(" (" + lastReputation + ")");
        }

        ArrayList<FormattedCharSequence> lines = new ArrayList<>();
        lines.add(Component.m_237110_("gui.thief.reputation", name).m_7532_());
        lines.addAll(Minecraft.m_91087_().f_91062_.m_92923_(reputation.getLocalizedDescription(), 170));

        if (Minecraft.m_91087_().f_91066_.f_92125_ && lastGossipsVillagerId == villager.m_19879_()) {
            lines.add(Component.m_237115_("gui.thief.gossips").m_7532_());
            lines.add(Component.m_237110_("gui.thief.gossips.major_negative", "§8" + lastMajorNegative).m_7532_());
            lines.add(Component.m_237110_("gui.thief.gossips.minor_negative", "§8" + lastMinorNegative).m_7532_());
            lines.add(Component.m_237110_("gui.thief.gossips.minor_positive", "§8" + lastMinorPositive).m_7532_());
            lines.add(Component.m_237110_("gui.thief.gossips.major_positive", "§8" + lastMajorPositive).m_7532_());
            lines.add(Component.m_237110_("gui.thief.gossips.trading", "§8" + lastTrading).m_7532_());
        }

        int x = minecraft.m_91268_().m_85445_() / 2 + 8;
        int y = minecraft.m_91268_().m_85446_() / 2 - (int)(lines.size() / 2f * 9f);
        guiGraphics.m_280245_(minecraft.f_91062_, lines, x, y + 10);
    }

    public static void updateReputation(int villagerId, int reputation) {
        lastVillagerId = villagerId;
        lastReputation = reputation;
    }

    public static void updateGossips(int villagerId, int majorNegative, int minorNegative,
                                     int minorPositive, int majorPositive, int trading) {
        lastGossipsVillagerId = villagerId;
        lastMajorNegative = majorNegative;
        lastMinorNegative = minorNegative;
        lastMinorPositive = minorPositive;
        lastMajorPositive = majorPositive;
        lastTrading = trading;
    }
}
