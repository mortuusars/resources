package io.github.mortuusars.thief.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.thief.Config;
import io.github.mortuusars.thief.world.Crime;
import io.github.mortuusars.thief.world.Reputation;
import io.github.mortuusars.thief.world.Witness;
import io.github.mortuusars.thief.world.stealth.Stealth;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class ThiefCommand {
    private static boolean showNoticeDistanceAndWitnesses = false;

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("thief")
                .requires((stack) -> stack.method_9259(2))
                .then(class_2170.method_9247("debug")
                        .then(class_2170.method_9247("is_in_protected_structure")
                                .executes(ThiefCommand::isInProtectedStructure))
                        .then(class_2170.method_9247("show_notice_distance_and_witnesses")
                                .executes(ThiefCommand::showNoticeDistance))
                        .then(class_2170.method_9247("show_witness_reputation")
                                .executes(ThiefCommand::showWitnessReputation)))
                .then(class_2170.method_9247("commit_crime")
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .then(class_2170.method_9247("light")
                                        .executes(context -> commitCrime(context, Crime.LIGHT)))
                                .then(class_2170.method_9247("medium")
                                        .executes(context -> commitCrime(context, Crime.MEDIUM)))
                                .then(class_2170.method_9247("heavy")
                                        .executes(context -> commitCrime(context, Crime.HEAVY))))));
    }

    // Debug --

    private static int isInProtectedStructure(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_3222 player = context.getSource().method_9207();
        context.getSource().method_9226(() -> class_2561.method_43470("Is in '#thief:protected' structure: " +
                Crime.isInProtectedStructure(context.getSource().method_9225(), player.method_24515())), true);
        return 0;
    }

    private static int showNoticeDistance(CommandContext<class_2168> context) {
        if (showNoticeDistanceAndWitnesses) {
            showNoticeDistanceAndWitnesses = false;
            context.getSource().method_9226(() -> class_2561.method_43470("Turned off thief notice distance showing."), true);
        } else {
            showNoticeDistanceAndWitnesses = true;
            context.getSource().method_9226(() -> class_2561.method_43470("Showing thief notice distance."), true);
        }
        return 0;
    }

    private static int showWitnessReputation(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_3222 player = context.getSource().method_9207();

        if (player.method_68878() || player.method_7325()) {
            context.getSource().method_9226(() -> class_2561.method_43470("You need to be in survival mode to be noticed by others."), true);
            return 0;
        }

        List<class_1646> villagers = Witness.getWitnesses(player)
                .stream()
                .filter(entity -> entity instanceof class_1646)
                .map(entity -> (class_1646) entity)
                .toList();

        if (villagers.isEmpty()) {
            context.getSource().method_9226(() -> class_2561.method_43470("No witnesses."), true);
            return 0;
        }

        int averageValue = Reputation.averageValueFromVillagers(player, villagers);
        Reputation reputation = Reputation.fromValue(averageValue);

        context.getSource().method_9226(() -> class_2561.method_43470("Average reputation of " + villagers.size() + " witnesses is: ")
                .method_10852(reputation.getLocalizedNameWithColor())
                .method_10852(class_2561.method_43470(" (" + averageValue + ")").method_54663(reputation.getColor())), true);

        return 0;
    }

    private static int commitCrime(CommandContext<class_2168> context, Crime crime) throws CommandSyntaxException {
        class_3222 player = context.getSource().method_9207();

        Crime.Outcome outcome = crime.commit(player.method_51469(), player, player.method_24515());
        if (outcome.punished()) {
            context.getSource().method_9226(() -> class_2561.method_43470(
                            player.method_5820() + " has commited " + crime.getName() + " crime with "
                                    + outcome.witnesses().size() + " witnesses.")
                    .method_27692(class_124.field_1061), true);
        } else {
            context.getSource().method_9226(() -> class_2561.method_43470(
                            player.method_5820() + " has commited " + crime.getName() + " crime, but no one saw that.")
                    .method_27692(class_124.field_1061), true);
        }

        return 0;
    }

    public static void onPlayerTick(class_3222 player) {
        if (showNoticeDistanceAndWitnesses && player.method_51469().method_8510() % 3 == 0) {
            List<class_1309> witnesses = Witness.getWitnesses(player);
            for (class_1309 witness : witnesses) {
                witness.method_6092(new class_1293(class_1294.field_5912, 4));
            }

            double radius = Config.Server.WITNESS_MAX_DISTANCE.get() * Stealth.getVisibility(player);
            int particles = 64; // number of particles in the ring

            for (int i = 0; i < particles; i++) {
                double angle = 2 * Math.PI * i / particles;
                double x = player.method_23317() + radius * Math.cos(angle);
                double z = player.method_23321() + radius * Math.sin(angle);
                double y = player.method_23318() + 1;

                player.method_51469().method_14166(player, class_2398.field_11236, true, true,
                      x, y, z, 1, 0, 0, 0, 0);
            }
        }
    }
}
