package io.github.mortuusars.thief.mixin.dont_show_traders_to_criminals;

import io.github.mortuusars.thief.world.Reputation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1646;
import net.minecraft.class_3218;
import net.minecraft.class_4130;
import net.minecraft.class_4140;

@Mixin(class_4130.class)
public class ShowTradesToPlayerMixin {
    // Prevent showing trade offers when villager shouldn't trade with a player
    @Inject(method = "checkExtraStartConditions(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/npc/villager/Villager;)Z",
            at = @At("HEAD"),
            cancellable = true)
    private void onCheckExtraStartConditions(class_3218 level, class_1646 owner, CallbackInfoReturnable<Boolean> cir) {
        Optional<Reputation> reputation = owner.method_18868()
                .method_18904(class_4140.field_18447)
                .map(target -> Reputation.fromValue(owner, target));

        if (reputation.isPresent() && !reputation.get().canTrade()) {
            cir.setReturnValue(false);
        }
    }
}
