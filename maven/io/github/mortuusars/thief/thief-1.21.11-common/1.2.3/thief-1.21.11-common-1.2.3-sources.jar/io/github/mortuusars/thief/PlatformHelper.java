package io.github.mortuusars.thief;

import dev.architectury.injectables.annotations.ExpectPlatform;
import io.github.mortuusars.thief.world.Crime;
import io.github.mortuusars.thief.world.Reputation;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3908;

public class PlatformHelper {
    @ExpectPlatform
    public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_2540> extraDataWriter) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isModLoaded(String modId) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void fireCrimeCommitedEvent(class_1309 criminal, Crime crime, List<class_1309> witnesses) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void fireGiftGivenEvent(class_3222 player, class_1646 villager, class_1799 gift) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static void fireReputationLevelChangedEvent(class_1309 criminal, class_1646 villager, Reputation oldReputation, Reputation newReputation) {
        throw new AssertionError();
    }
}
