package io.github.mortuusars.thief.mixin.bed_crimes;

import com.mojang.datafixers.util.Either;
import io.github.mortuusars.thief.Config;
import io.github.mortuusars.thief.world.Witness;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3902;
import net.minecraft.class_4140;

@Mixin(class_1657.class)
public abstract class PlayerMixin extends class_1309 {
    protected PlayerMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "startSleepInBed", at = @At("HEAD"))
    private void onStartSleepInBed(class_2338 bedPos, CallbackInfoReturnable<Either<class_1657.class_1658, class_3902>> cir) {
        if (!(method_73183() instanceof class_3218 level)) return;

        Config.Server.CRIME_FOR_SLEEPING_IN_VILLAGERS_BED.get().getCrime().ifPresent(crime -> {
            List<class_1646> witnesses = Witness.getWitnesses((class_1657) (Object) this, class_1646.class);
            for (class_1646 witness : witnesses) {
                if (witness.method_18868().method_18904(class_4140.field_18438).map(p -> p.comp_2208().equals(bedPos)).orElse(false)) {
                    crime.commit(level, this, bedPos);
                    return;
                }
            }
        });
    }
}
