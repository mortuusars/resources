package io.github.mortuusars.thief.advancement.trigger;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.thief.world.Crime;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_2048;
import net.minecraft.class_2096;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;

public class CrimeCommitedTrigger extends class_4558<CrimeCommitedTrigger.TriggerInstance> {
    @Override
    public @NotNull Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player, Crime crime, List<class_1309> witnesses) {
        this.method_22510(player, triggerInstance ->
                triggerInstance.matches(player, crime, witnesses));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  Optional<class_2096.class_2100> crime,
                                  Optional<class_5258> witness) implements class_4558.class_8788 {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::comp_2029),
                class_2096.class_2100.field_45763.optionalFieldOf("crime").forGetter(TriggerInstance::crime),
                class_2048.field_47250.optionalFieldOf("witness").forGetter(TriggerInstance::witness))
                .apply(instance, TriggerInstance::new));

        public boolean matches(class_3222 player, Crime crime, List<class_1309> witnesses) {
            return (this.crime.isEmpty() || this.crime.get().method_9054(crime.ordinal())
                    && (witness.isEmpty() || witnesses.stream().allMatch(w -> witness.get().method_27806(class_2048.method_27802(player, w)))));
        }
    }
}