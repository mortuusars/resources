package io.github.mortuusars.thief.world.stealth.modifier;

import io.github.mortuusars.thief.world.stealth.Stealth;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_3532;

public class DarknessModifier implements Stealth.VisibilityModifier {
    @Override
    public double modify(class_1309 entity, double value) {
        int lightLevel = getLightLevelAt(entity.method_73183(), entity.method_24515());
        return value * class_3532.method_37959(lightLevel, 0, 15, 0.25f, 1f);
    }

    public static int getLightLevelAt(class_1937 level, class_2338 pos) {
        if (level.method_8608()) {
            // This updates 'getSkyDarken' on the client. It'll return 0 if we don't update it.
            level.method_8533();
        }
        int skyBrightness = level.method_8314(class_1944.field_9284, pos);
        int blockBrightness = level.method_8314(class_1944.field_9282, pos);
        return skyBrightness < 15 ?
                Math.max(blockBrightness, (int) (skyBrightness * ((15 - level.method_8594()) / 15f))) :
                Math.max(blockBrightness, 15 - level.method_8594());
    }
}
