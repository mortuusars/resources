package io.github.mortuusars.mortaar.neoforge.event;

public class NeoForgeClientEvents {

}