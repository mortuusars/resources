package io.github.mortuusars.mortaar.fabric;

import io.netty.buffer.ByteBufUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.menu.v1.ExtendedMenuProvider;
import net.fabricmc.fabric.api.networking.v1.FriendlyByteBufs;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import java.util.function.Consumer;

@SuppressWarnings("unused")
public class PlatformImpl {
    public static boolean isInDevEnv() {
        return FabricLoader.getInstance().isDevelopmentEnvironment();
    }

    public static boolean isClient() {
        return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
    }

    public static boolean isModLoaded(String modId) {
        return FabricLoader.getInstance().isModLoaded(modId);
    }

    /**
     * This method is here because on forge checking if mod is loaded at mixin apply time is different (LoadingModList vs ModList)
     * But on fabric we can use the same code.
     */
    public static boolean isModLoading(String modId) {
        return isModLoaded(modId);
    }

    public static Path getGameDirectory() {
        return FabricLoader.getInstance().getGameDir();
    }

    public static Path getConfigDirectory() {
        return FabricLoader.getInstance().getConfigDir();
    }

    public static @Nullable MinecraftServer getCurrentServer() {
        return MortaarFabric.server;
    }

    public static void openMenu(ServerPlayer serverPlayer, MenuProvider menuProvider, Consumer<RegistryFriendlyByteBuf> extraDataWriter) {
        HiddenFromScaryClassLoader.openMenu(serverPlayer, menuProvider, extraDataWriter);
    }

    /**
     * Hides the classes from being eaten by a class loader too early
     * <br>
     * (ScreenFactory mixins are failing when isModLoading gets called early)
     */
    private static class HiddenFromScaryClassLoader {
        public static void openMenu(ServerPlayer serverPlayer, MenuProvider menuProvider, Consumer<RegistryFriendlyByteBuf> extraDataWriter) {
            ExtendedMenuProvider<byte[]> extendedScreenHandlerFactory = new ExtendedMenuProvider<>() {
                @Override
                public byte[] getScreenOpeningData(ServerPlayer player) {
                    RegistryFriendlyByteBuf buffer = new RegistryFriendlyByteBuf(FriendlyByteBufs.create(), player.registryAccess());
                    extraDataWriter.accept(buffer);
                    byte[] bytes = ByteBufUtil.getBytes(buffer);
                    buffer.release();
                    return bytes;
                }

                @Nullable
                @Override
                public AbstractContainerMenu createMenu(int i, @NotNull Inventory inventory, @NotNull Player player) {
                    return menuProvider.createMenu(i, inventory, player);
                }

                @Override
                public @NotNull Component getDisplayName() {
                    return menuProvider.getDisplayName();
                }
            };

            serverPlayer.openMenu(extendedScreenHandlerFactory);
        }
    }
}
