package io.github.mortuusars.mortaar.mixin.item_application;

import io.github.mortuusars.mortaar.client.Minecrft;
import io.github.mortuusars.mortaar.world.item.ApplicationTargetItem;
import io.github.mortuusars.mortaar.world.item.ApplicatorItem;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(AbstractContainerScreen.class)
public abstract class AbstractContainerScreenMixin<T extends AbstractContainerMenu> extends Screen {
    protected AbstractContainerScreenMixin(Component title) {
        super(title);
    }

    @Shadow
    public abstract T getMenu();

    @Shadow
    @Nullable
    protected Slot hoveredSlot;

    @Shadow
    protected abstract List<Component> getTooltipFromContainerItem(ItemStack itemStack);

    /**
     * Because tooltip is not rendered when carrying an item,
     * we render it manually when {@link ApplicatorItem} or {@link ApplicationTargetItem} needs it.<br>
     * This helps to choose/see the item you're changing.
     */
    @Inject(method = "extractTooltip", at = @At("HEAD"), cancellable = true)
    private void onRenderTooltip(GuiGraphicsExtractor graphics, int mouseX, int mouseY, CallbackInfo ci) {
        if (hoveredSlot == null || !hoveredSlot.hasItem()) {
            return;
        }

        ItemStack carried = getMenu().getCarried();

        if (carried.isEmpty()) {
            return;
        }

        ItemStack hovered = hoveredSlot.getItem();

        if (carried.getItem() instanceof ApplicatorItem applicator) {
            if (applicator.shouldRenderSlotTooltipWhileCarrying(Minecrft.player(), getMenu(), hoveredSlot, carried)) {
                List<Component> lines = applicator.addTooltipLinesToTarget(Minecrft.player(), getMenu(), hoveredSlot,
                      carried, new ArrayList<>(getTooltipFromContainerItem(hovered)));
                graphics.setTooltipForNextFrame(font, lines, hovered.getTooltipImage(), mouseX, mouseY);
                ci.cancel();
            }
        }

        if (hovered.getItem() instanceof ApplicationTargetItem applicationTarget) {
            if (applicationTarget.shouldRenderSlotTooltipWhileCarrying(Minecrft.player(), getMenu(), hoveredSlot, carried)) {
                List<Component> lines = applicationTarget.addTooltipLinesToItself(Minecrft.player(), getMenu(), hoveredSlot,
                      carried, new ArrayList<>(getTooltipFromContainerItem(hovered)));
                graphics.setTooltipForNextFrame(font, lines, hovered.getTooltipImage(), mouseX, mouseY);
                ci.cancel();
            }
        }
    }
}
