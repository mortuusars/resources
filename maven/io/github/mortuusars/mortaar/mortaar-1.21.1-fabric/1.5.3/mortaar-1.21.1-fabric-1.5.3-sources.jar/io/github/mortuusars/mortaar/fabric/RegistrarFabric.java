package io.github.mortuusars.mortaar.fabric;

import com.mojang.brigadier.arguments.ArgumentType;
import io.github.mortuusars.mortaar.Registrar;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.command.v2.ArgumentTypeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1703;
import net.minecraft.class_179;
import net.minecraft.class_1792;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2248;
import net.minecraft.class_2314;
import net.minecraft.class_2378;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2941;
import net.minecraft.class_2943;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3414;
import net.minecraft.class_3446;
import net.minecraft.class_3917;
import net.minecraft.class_3956;
import net.minecraft.class_4158;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9331;
import net.minecraft.class_9360;
import net.minecraft.class_9695;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class RegistrarFabric implements Registrar {
    private final String modId;

    public RegistrarFabric(String modId) {
        this.modId = modId;
    }

    @Override
    public String getModId() {
        return modId;
    }

    public <T extends class_2248> Supplier<T> block(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(modId, id), supplier.get());
        return () -> obj;
    }

    @Override
    public <T extends class_2591<E>, E extends class_2586> Supplier<T> blockEntityType(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(modId, id), supplier.get());
        return () -> obj;
    }

    @Override
    public <T extends class_2586> class_2591<T> newBlockEntityType(BlockEntitySupplier<T> blockEntitySupplier, class_2248... validBlocks) {
        return class_2591.class_2592.method_20528(blockEntitySupplier::create, validBlocks).build();
    }

    @Override
    public Supplier<class_4158> poiType(class_5321<class_4158> key, int ticketCount, int searchDistance, Supplier<Set<class_2680>> states) {
        class_4158 type = PointOfInterestHelper.register(key.method_29177(), ticketCount, searchDistance, states.get());
        return () -> type;
    }

    @Override
    public <T extends class_1792> Supplier<T> item(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(modId, id), supplier.get());
        return () -> obj;
    }

    @Override
    public <T extends class_1297> Supplier<class_1299<T>> entityType(String id, class_1299.class_4049<T> factory,
                                                                        class_1311 category, float width, float height,
                                                                        int clientTrackingRange, boolean velocityUpdates, int updateInterval) {
        class_1299<T> type = class_2378.method_10230(class_7923.field_41177, class_2960.method_60655(modId, id),
              class_1299.class_1300.method_5903(factory, category)
                    .method_17687(width, height)
                    .method_27299(clientTrackingRange)
                    .alwaysUpdateVelocity(velocityUpdates)
                    .method_27300(updateInterval)
                    .build());
        return () -> type;
    }

    @Override
    public <T extends class_1297> Supplier<class_1299<T>> entityType(String id, class_1299.class_4049<T> factory, class_1311 category, boolean receiveVelocityUpdates, Consumer<class_1299.class_1300<T>> typeBuilder) {
        class_1299.class_1300<T> builder = class_1299.class_1300.method_5903(factory, category);
        typeBuilder.accept(builder);
        builder.alwaysUpdateVelocity(receiveVelocityUpdates);
        class_1299<T> type = class_2378.method_10230(class_7923.field_41177, class_2960.method_60655(modId, id), builder.build());
        return () -> type;
    }

    @Override
    public <T> Supplier<class_2941<T>> entityDataSerializer(String id, class_2941<T> serializer) {
        class_2943.method_12720(serializer);
        return () -> serializer;
    }

    @Override
    public <T extends class_3414> Supplier<T> soundEvent(String id, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_41172, class_2960.method_60655(modId, id), supplier.get());
        return () -> obj;
    }

    @Override
    public <T extends class_1703> Supplier<class_3917<T>> menuType(String id, MenuTypeSupplier<T> supplier) {
        ExtendedScreenHandlerType<T, byte[]> type = new ExtendedScreenHandlerType<>((syncId, inventory, data) -> {
            class_9129 buffer = new class_9129(Unpooled.wrappedBuffer(data), inventory.field_7546.method_56673());
            T menu = supplier.create(syncId, inventory, buffer);
            buffer.release();
            return menu;
        }, class_9135.field_48987.method_56439(Function.identity()));

        class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(modId, id), type);

        return () -> type;
    }

    @Override
    public <T extends class_1860<I>, I extends class_9695> Supplier<class_3956<T>> recipeType(String id, Supplier<class_3956<T>> supplier) {
        class_3956<T> obj = class_2378.method_10230(class_7923.field_41188, class_2960.method_60655(modId, id), supplier.get());
        return () -> obj;
    }

    @Override
    public <T extends class_1860<?>> Supplier<class_1865<T>> recipeSerializer(String id, Supplier<class_1865<T>> supplier) {
        class_1865<T> obj = class_2378.method_10230(class_7923.field_41189, class_2960.method_60655(modId, id), supplier.get());
        return () -> obj;
    }

    @Override
    public <T extends class_179<?>> Supplier<T> criterionTrigger(String name, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_47496, class_2960.method_60655(modId, name), supplier.get());
        return () -> obj;
    }

    @Override
    public <T extends class_9360.class_8745<?>> Supplier<T> itemSubPredicate(String name, Supplier<T> supplier) {
        T obj = class_2378.method_10230(class_7923.field_49912, class_2960.method_60655(modId, name), supplier.get());
        return () -> obj;
    }

    @Override
    public <A extends ArgumentType<?>, T extends class_2314.class_7217<A>, I extends class_2314<A, T>>
    Supplier<class_2314<A, T>> commandArgumentType(String id, Class<A> infoClass, I argumentTypeInfo) {
        ArgumentTypeRegistry.registerArgumentType(class_2960.method_60655(modId, id), infoClass, argumentTypeInfo);
        return () -> argumentTypeInfo;
    }

    @Override
    public <T extends class_3037> Supplier<class_3031<?>> worldGenFeature(String name, Supplier<class_3031<T>> featureSupplier) {
        class_3031<T> feature = class_2378.method_10226(class_7923.field_41144, name, featureSupplier.get());
        return () -> feature;
    }

    @Override
    public <T> class_9331<T> dataComponentType(String name, Consumer<class_9331.class_9332<T>> builderConsumer) {
        var builder = class_9331.<T>method_57873();
        builderConsumer.accept(builder);
        var componentType = builder.method_57880();
        return class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(modId, name), componentType);
    }

    @Override
    public <T extends class_2396<? extends class_2394>> Supplier<T> particleType(String name, Supplier<T> supplier) {
        T particleType = class_2378.method_10226(class_7923.field_41180, name, supplier.get());
        return () -> particleType;
    }

    @Override
    public Supplier<class_2960> stat(class_2960 location, class_3446 formatter) {
        net.minecraft.class_2378.method_10230(class_7923.field_41183, location, location);
        net.minecraft.class_3468.field_15419.method_14955(location, formatter);
        return () -> location;
    }
}
