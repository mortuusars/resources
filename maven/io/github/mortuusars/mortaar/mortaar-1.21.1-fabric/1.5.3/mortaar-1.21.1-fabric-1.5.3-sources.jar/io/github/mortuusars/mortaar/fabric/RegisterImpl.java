package io.github.mortuusars.mortaar.fabric;

import io.github.mortuusars.mortaar.Registrar;
import io.github.mortuusars.mortaar.network.packet.Packet;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import java.util.HashMap;
import java.util.Map;

public class RegisterImpl {
    public static final Map<String, RegistrarFabric> REGISTRARS = new HashMap<>();

    public static Registrar registrar(String modId) {
        return REGISTRARS.computeIfAbsent(modId, RegistrarFabric::new);
    }

    // --

    @SuppressWarnings("unchecked")
    public static void serverboundPacket(class_8710.class_9154<? extends Packet> type, class_9139<? extends class_2540, ? extends Packet> codec) {
        PayloadTypeRegistry.playC2S().register(
              (class_8710.class_9154<Packet>) type, (class_9139<class_2540, Packet>) codec);
        ServerPlayNetworking.registerGlobalReceiver(
              (class_8710.class_9154<Packet>) type, (payload, context) -> payload.handle(class_2598.field_11941, context.player()));
    }

    @SuppressWarnings("unchecked")
    public static void clientboundPacket(class_8710.class_9154<? extends Packet> type, class_9139<? extends class_2540, ? extends Packet> codec) {
        PayloadTypeRegistry.playS2C().register(
              (class_8710.class_9154<Packet>) type, (class_9139<class_2540, Packet>) codec);

        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            Client.registerPacketReceiver((class_8710.class_9154<Packet>) type);
        }
    }

    @SuppressWarnings("unchecked")
    public static void bidirectionalPacket(class_8710.class_9154<? extends Packet> type, class_9139<? extends class_2540, ? extends Packet> codec) {
        PayloadTypeRegistry.playC2S().register(
              (class_8710.class_9154<Packet>) type, (class_9139<class_2540, Packet>) codec);
        ServerPlayNetworking.registerGlobalReceiver(
              (class_8710.class_9154<Packet>) type, (payload, context) -> payload.handle(class_2598.field_11941, context.player()));
        PayloadTypeRegistry.playS2C().register(
              (class_8710.class_9154<Packet>) type, (class_9139<class_2540, Packet>) codec);
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            Client.registerPacketReceiver((class_8710.class_9154<Packet>) type);
        }
    }

    /**
     * Putting code in the inner class prevents classloading on the wrong environment.
     */
    private static class Client {
        public static void registerPacketReceiver(class_8710.class_9154<Packet> type) {
            ClientPlayNetworking.registerGlobalReceiver(
                  type, (payload, context) -> payload.handle(class_2598.field_11942, context.player()));
        }
    }
}
