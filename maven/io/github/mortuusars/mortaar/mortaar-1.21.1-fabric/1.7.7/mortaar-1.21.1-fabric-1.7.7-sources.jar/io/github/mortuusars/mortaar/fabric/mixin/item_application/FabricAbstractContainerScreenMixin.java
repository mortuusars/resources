package io.github.mortuusars.mortaar.fabric.mixin.item_application;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.mortuusars.mortaar.client.Minecrft;
import io.github.mortuusars.mortaar.world.item.ApplicationTargetItem;
import io.github.mortuusars.mortaar.world.item.ApplicatorItem;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_465.class)
public abstract class FabricAbstractContainerScreenMixin<T extends class_1703> extends class_437 {
    protected FabricAbstractContainerScreenMixin(class_2561 title) {
        super(title);
    }

    @Shadow
    public abstract T getMenu();

    @WrapOperation(method = "renderSlot", at= @At(value = "INVOKE",
          target = "Lnet/minecraft/client/gui/GuiGraphics;renderItemDecorations(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;IILjava/lang/String;)V"))
    private void onRenderItemDecorations(class_332 instance, class_327 font, class_1799 stack, int x, int y,
                                         String text, Operation<Void> original, @Local(argsOnly = true) class_1735 slot) {
        original.call(instance, font, stack, x, y, text);

        class_1799 carried = getMenu().method_34255();
        if (carried.method_7960()) {
            return;
        }

        boolean shouldDraw = false;

        if (carried.method_7909() instanceof ApplicatorItem applicator
              && applicator.canBeAppliedTo(Minecrft.player(), getMenu(), slot, carried)) {
            shouldDraw = true;
        }

        if (slot.method_7677().method_7909() instanceof ApplicationTargetItem applicationTarget
              && applicationTarget.canApplyCarried(Minecrft.player(), getMenu(), slot, carried)) {
            shouldDraw = true;
        }

        if (shouldDraw) {
            instance.method_51448().method_22903();
            instance.method_51448().method_46416(0.0F, 0.0F, 200.0F);
            instance.method_51433(font, "+", x + 19 - 2 - font.method_1727("+"), y - 1, 0xFFFFD74E, true);
            instance.method_51448().method_22909();
        }
    }
}
