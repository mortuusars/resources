package io.github.mortuusars.mortaar.fabric;

import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_310;

public class PlatformClientImpl {
    public static class_1087 getModel(class_1091 model) {
        // Fabric adds it's "fabric_resource" to id. NeoForge uses model location as is.
        return class_310.method_1551().method_1554().getModel(model.comp_2875());
    }
}
