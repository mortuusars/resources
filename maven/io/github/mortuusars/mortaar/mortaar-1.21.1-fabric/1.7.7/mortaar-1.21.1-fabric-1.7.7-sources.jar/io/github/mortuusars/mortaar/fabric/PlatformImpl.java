package io.github.mortuusars.mortaar.fabric;

import io.netty.buffer.ByteBufUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_9129;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import java.util.function.Consumer;

@SuppressWarnings("unused")
public class PlatformImpl {
    public static boolean isInDevEnv() {
        return FabricLoader.getInstance().isDevelopmentEnvironment();
    }

    public static boolean isClient() {
        return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
    }

    public static boolean isModLoaded(String modId) {
        return FabricLoader.getInstance().isModLoaded(modId);
    }

    /**
     * This method is here because on forge checking if mod is loaded at mixin apply time is different (LoadingModList vs ModList)
     * But on fabric we can use the same code.
     */
    public static boolean isModLoading(String modId) {
        return isModLoaded(modId);
    }

    public static Path getGameDirectory() {
        return FabricLoader.getInstance().getGameDir();
    }

    public static Path getConfigDirectory() {
        return FabricLoader.getInstance().getConfigDir();
    }

    public static @Nullable MinecraftServer getCurrentServer() {
        return MortaarFabric.server;
    }

    public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_9129> extraDataWriter) {
        HiddenFromScaryClassLoader.openMenu(serverPlayer, menuProvider, extraDataWriter);
    }

    /**
     * Hides the classes from being eaten by a class loader too early
     * <br>
     * (ScreenFactory mixins are failing when isModLoading gets called early)
     */
    private static class HiddenFromScaryClassLoader {
        public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_9129> extraDataWriter) {
            ExtendedScreenHandlerFactory<byte[]> extendedScreenHandlerFactory = new ExtendedScreenHandlerFactory<>() {
                @Override
                public byte[] getScreenOpeningData(class_3222 player) {
                    class_9129 buffer = new class_9129(PacketByteBufs.create(), player.method_56673());
                    extraDataWriter.accept(buffer);
                    byte[] bytes = ByteBufUtil.getBytes(buffer);
                    buffer.release();
                    return bytes;
                }

                @Nullable
                @Override
                public class_1703 createMenu(int i, @NotNull class_1661 inventory, @NotNull class_1657 player) {
                    return menuProvider.createMenu(i, inventory, player);
                }

                @Override
                public @NotNull class_2561 method_5476() {
                    return menuProvider.method_5476();
                }
            };

            serverPlayer.method_17355(extendedScreenHandlerFactory);
        }
    }
}
