package io.github.mortuusars.mortaar.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.mortaar.Config;
import net.minecraft.class_2168;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

public class MortaarCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 context) {
//        dispatcher.register(Commands.literal("mortaar")
//              .requires((stack) -> stack.hasPermission(3))
//              .then(Commands.literal("debug")
//                    .executes(MortaarCommand::toggleDebugMode)
//                    .then(Commands.literal("test")
//                          .executes(MortaarCommand::test))));
    }

//    private static int toggleDebugMode(CommandContext<CommandSourceStack> context) {
//        boolean newValue = !Config.Server.DEBUG_MODE.get();
//        Config.Server.DEBUG_MODE.set(newValue);
//        Config.Server.DEBUG_MODE.save();
//        context.getSource().sendSuccess(() -> Component.literal("Debug mode: " + (newValue ? "Enabled" : "Disabled")).withStyle(ChatFormatting.GRAY), true);
//        return 0;
//    }

    private static int test(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_3222 player = context.getSource().method_9207();
        return 0;
    }
}
