package io.github.mortuusars.mortaar.advancement.predicate;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_2096;
import net.minecraft.class_5253;

public record ColorPredicate(Optional<Integer> exact,
                             Optional<class_2096.class_2100> red,
                             Optional<class_2096.class_2100> green,
                             Optional<class_2096.class_2100> blue,
                             Optional<class_2096.class_2100> alpha) {
    public static final Codec<ColorPredicate> CODEC = RecordCodecBuilder.create(i -> i.group(
          Codec.INT.optionalFieldOf("exact").forGetter(ColorPredicate::exact),
          class_2096.class_2100.field_45763.optionalFieldOf("red").forGetter(ColorPredicate::red),
          class_2096.class_2100.field_45763.optionalFieldOf("green").forGetter(ColorPredicate::green),
          class_2096.class_2100.field_45763.optionalFieldOf("blue").forGetter(ColorPredicate::blue),
          class_2096.class_2100.field_45763.optionalFieldOf("alpha").forGetter(ColorPredicate::alpha)
    ).apply(i, ColorPredicate::new));

    public boolean matches(int colorARGB) {
        return (exact().isEmpty() || exact().get() == colorARGB)
              && (red().isEmpty() || red.get().method_9054(class_5253.class_5254.method_27765(colorARGB)))
              && (green().isEmpty() || green.get().method_9054(class_5253.class_5254.method_27766(colorARGB)))
              && (blue().isEmpty() || blue.get().method_9054(class_5253.class_5254.method_27767(colorARGB)))
              && (alpha().isEmpty() || alpha.get().method_9054(class_5253.class_5254.method_27762(colorARGB)));
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        @Nullable Integer exact;
        @Nullable class_2096.class_2100 red;
        @Nullable class_2096.class_2100 green;
        @Nullable class_2096.class_2100 blue;
        @Nullable class_2096.class_2100 alpha;

        public Builder exact(@Nullable Integer exact) {
            this.exact = exact;
            return this;
        }

        public Builder red(@Nullable class_2096.class_2100 red) {
            this.red = red;
            return this;
        }

        public Builder green(@Nullable class_2096.class_2100 green) {
            this.green = green;
            return this;
        }

        public Builder blue(@Nullable class_2096.class_2100 blue) {
            this.blue = blue;
            return this;
        }

        public Builder alpha(@Nullable class_2096.class_2100 alpha) {
            this.alpha = alpha;
            return this;
        }

        public ColorPredicate build() {
            return new ColorPredicate(
                  Optional.ofNullable(exact),
                  Optional.ofNullable(red),
                  Optional.ofNullable(green),
                  Optional.ofNullable(blue),
                  Optional.ofNullable(alpha)
            );
        }
    }
}
