package io.github.mortuusars.mortaar.client;

import java.util.Objects;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_5455;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;

public abstract class Minecrft {
    public static class_310 get() {
        return class_310.method_1551();
    }

    public static class_746 player() {
        return Objects.requireNonNull(get().field_1724, "Player is not available.");
    }

    public static class_638 level() {
        return Objects.requireNonNull(get().field_1687, "Level is not available.");
    }

    public static class_5455 registryAccess() {
        return level().method_30349();
    }

    public static class_636 gameMode() {
        return Objects.requireNonNull(get().field_1761, "GameMode is not available.");
    }

    public static class_315 options() {
        return get().field_1690;
    }

    public static void execute(Runnable runnable) {
        get().execute(runnable);
    }

    public static void releaseUseButton() {
        options().field_1904.method_23481(false);
    }
}
