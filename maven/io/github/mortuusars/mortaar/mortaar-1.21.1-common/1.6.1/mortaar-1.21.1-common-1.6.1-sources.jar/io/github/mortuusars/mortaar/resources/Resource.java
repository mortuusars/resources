package io.github.mortuusars.mortaar.resources;

import io.github.mortuusars.mortaar.Platform;
import java.util.Optional;
import java.util.function.Function;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;

public abstract class Resource {
    public static <T> Optional<class_6880<T>> get(class_5321<T> key, class_7225.class_7874 registries) {
        return registries.method_46762(key.method_58273()).method_46746(key)
              .map(holder -> holder); // Typical generics in java stuff
    }

    public static <T> class_6880<T> getOrAny(class_5321<T> key, class_7225.class_7874 registries) {
        class_7225.class_7226<T> registry = registries.method_46762(key.method_58273());
        return registry.method_46746(key).orElse(registry.method_42017().findFirst().orElseThrow());
    }

    public static <T> class_6880<T> getOrThrow(class_5321<T> key, class_7225.class_7874 registries) {
        return registries.method_46762(key.method_58273()).method_46747(key);
    }

    public static <T, R> Optional<R> map(class_5321<T> key, Function<class_6880<T>, R> mappingFunction, class_7225.class_7874 registries) {
        return get(key, registries).map(mappingFunction);
    }

    public static <T, R> R mapOrThrow(class_5321<T> key, Function<class_6880<T>, R> mappingFunction, class_7225.class_7874 registries) {
        return mappingFunction.apply(getOrThrow(key, registries));
    }

    // --

    /**
     * Uses current server to access the registry. Use with caution.
     */
    public static <T> class_6880<T> getOrThrow(class_5321<T> key) {
        return getOrThrow(key, Platform.getCurrentServerOrThrow().method_30611());
    }

    /**
     * Uses current server to access the registry. Use with caution.
     */
    public static <T> Optional<class_6880<T>> get(class_5321<T> key) {
        return get(key, Platform.getCurrentServerOrThrow().method_30611());
    }

    /**
     * Uses current server to access the registry. Use with caution.
     */
    public static <T, R> Optional<R> map(class_5321<T> key, Function<class_6880<T>, R> mappingFunction) {
        return get(key).map(mappingFunction);
    }

    /**
     * Uses current server to access the registry. Use with caution.
     */
    public static <T, R> R mapOrThrow(class_5321<T> key, Function<class_6880<T>, R> mappingFunction) {
        return mappingFunction.apply(getOrThrow(key));
    }
}
