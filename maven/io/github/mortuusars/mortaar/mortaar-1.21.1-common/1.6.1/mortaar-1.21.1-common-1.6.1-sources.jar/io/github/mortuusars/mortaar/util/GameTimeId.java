package io.github.mortuusars.mortaar.util;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import io.netty.buffer.ByteBuf;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_1937;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Game Time (based) Identifier<br>
 * Simpler alternative to UUID, for cases when short representation is more important than safety.
 */
public class GameTimeId implements GameTime, Comparable<GameTimeId> {
    public static final Codec<GameTimeId> CODEC = Codec.STRING.comapFlatMap(GameTimeId::parseFromHex, GameTimeId::toString);
    public static final Codec<GameTimeId> CODEC_DECIMAL = Codec.STRING.comapFlatMap(GameTimeId::parseFromDecimal, GameTimeId::toStringDecimal);

    public static final class_9139<ByteBuf, GameTimeId> STREAM_CODEC = class_9139.method_56435(
          class_9135.field_48551, GameTimeId::getTick,
          class_9135.field_48550, GameTimeId::getSuffix,
          GameTimeId::new
    );

    protected static volatile long currentClientTick;
    protected static final AtomicInteger currentClientSuffix = new AtomicInteger();
    protected static volatile long currentServerTick;
    protected static final AtomicInteger currentServerSuffix = new AtomicInteger();

    protected final long tick;
    protected final int suffix;

    protected GameTimeId(long tick, int suffix) {
        Preconditions.checkArgument(tick >= 0, "Tick must be >= 0. Value: " + tick);
        Preconditions.checkArgument(suffix >= 0, "Suffix must be >= 0. Value: " + suffix);
        this.tick = tick;
        this.suffix = suffix;
    }

    /**
     * Creates a GTID based on current gameTime tick.<br>
     * - Each consecutive ID created on the same tick will have a suffix to make it unique.<br>
     * - Client and Server has their own suffix tracking.<br><br>
     * Uniqueness is guaranteed only for "correct" flow of time. Each time gameTime tick changes - suffix resets.
     */
    public static GameTimeId create(class_1937 level) {
        return new GameTimeId(level.method_8510(), getAndUpdateSuffix(level.method_8510(), level.method_8608()));
    }

    /**
     * Note: Using this method can break uniqueness of {@link #create(class_1937)}, if different tick is passed. Avoid using this method if possible.<br><br>
     * Creates a GTID based on provided tick.<br>
     * - Each consecutive ID created on the same tick will have a suffix to make it unique.<br>
     * - Client and Server has their own suffix tracking.<br><br>
     * Uniqueness is guaranteed only for "correct" flow of time. Each time tick changes - suffix resets.
     */
    public static GameTimeId createChecked(long tick, boolean clientSide) {
        return new GameTimeId(tick, getAndUpdateSuffix(tick, clientSide));
    }

    /**
     *  Creates a GTID from provided values.<br>
     *  No attempts to make the ID unique is done here.
     */
    public static GameTimeId createUncheked(long tick, int suffix) {
        return new GameTimeId(tick, suffix);
    }

    /**
     *  Creates a GTID from provided value.<br>
     *  No attempts to make the ID unique is done here.
     */
    public static GameTimeId createUncheked(long tick) {
        return createUncheked(tick, 0);
    }

    protected static int getAndUpdateSuffix(long tick, boolean clientSide) {
        if (clientSide) {
            if (tick != currentClientTick) {
                currentClientTick = tick;
                currentClientSuffix.set(0);
            }
            return currentClientSuffix.getAndIncrement();
        } else {
            if (tick != currentServerTick) {
                currentServerTick = tick;
                currentServerSuffix.set(0);
            }
            return currentServerSuffix.getAndIncrement();
        }
    }

    // --

    @Override
    public long getTick() {
        return tick;
    }

    public int getSuffix() {
        return suffix;
    }

    @Override
    public int compareTo(@NotNull GameTimeId other) {
        Preconditions.checkNotNull(other);
        if (equals(other)) return 0;
        if (tick == other.tick) return Integer.compare(suffix, other.suffix);
        return Long.compare(tick, other.tick);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GameTimeId id = (GameTimeId) o;
        return tick == id.tick && suffix == id.suffix;
    }

    @Override
    public int hashCode() {
        return Objects.hash(tick, suffix);
    }

    @Override
    public String toString() {
        return (suffix > 0
              ? Long.toHexString(tick) + "-" + Integer.toHexString(suffix)
              : Long.toHexString(tick)).toUpperCase();
    }

    public String toStringDecimal() {
        return (suffix > 0
              ? tick + "-" + suffix
              : Long.toString(tick)).toUpperCase();
    }

    // --

    /**
     * Parses GTID from hex-based string.<br>
     * Format is:<br>
     * - '7F7F7F-7F7F' (tick-suffix)<br>
     * - '7F7F7F' (only tick)
     */
    public static DataResult<GameTimeId> parseFromHex(String input) {
        if (input == null || input.isBlank()) {
            return DataResult.error(() -> "GTID string is null or empty.");
        }

        int dashIndex = input.indexOf('-');

        if (dashIndex == -1) {
            try {
                long tick = Long.parseLong(input, 16);
                if (tick < 0) {
                    return DataResult.error(() -> "Tick must be larger or equal to 0: " + input);
                }
                return DataResult.success(new GameTimeId(tick, 0));
            } catch (NumberFormatException e) {
                return DataResult.error(() -> "Invalid number in GTID: " + input + " - " + e.getMessage());
            }
        }

        try {
            String tickPart = input.substring(0, dashIndex);
            String suffixPart = input.substring(dashIndex + 1);

            long tick = Long.parseLong(tickPart, 16);
            if (tick < 0) {
                return DataResult.error(() -> "Tick must be larger or equal to 0: " + input);
            }
            int suffix = Integer.parseInt(suffixPart, 16);
            if (suffix < 0) {
                return DataResult.error(() -> "Suffix must be larger or equal to 0: " + input);
            }
            return DataResult.success(new GameTimeId(tick, suffix));
        } catch (Exception e) {
            return DataResult.error(() -> "Invalid input for GTID: " + input + " - " + e.getMessage());
        }
    }

    public static DataResult<GameTimeId> parseFromDecimal(String input) {
        if (input == null || input.isBlank()) {
            return DataResult.error(() -> "GTID string is null or empty.");
        }

        int dashIndex = input.indexOf('-');

        if (dashIndex == -1) {
            try {
                long tick = Long.parseLong(input);
                if (tick < 0) {
                    return DataResult.error(() -> "Tick must be larger or equal to 0: " + input);
                }
                return DataResult.success(new GameTimeId(tick, 0));
            } catch (NumberFormatException e) {
                return DataResult.error(() -> "Invalid number in GTID: " + input + " - " + e.getMessage());
            }
        }

        try {
            String tickPart = input.substring(0, dashIndex);
            String suffixPart = input.substring(dashIndex + 1);

            long tick = Long.parseLong(tickPart);
            if (tick < 0) {
                return DataResult.error(() -> "Tick must be larger or equal to 0: " + input);
            }
            int suffix = Integer.parseInt(suffixPart);
            if (suffix < 0) {
                return DataResult.error(() -> "Suffix must be larger or equal to 0: " + input);
            }
            return DataResult.success(new GameTimeId(tick, suffix));
        } catch (Exception e) {
            return DataResult.error(() -> "Invalid input for GTID: " + input + " - " + e.getMessage());
        }
    }
}