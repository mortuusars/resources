package io.github.mortuusars.mortaar.bugger;

import io.github.mortuusars.mortaar.bugger.test.BuggerTests;
import io.github.mortuusars.mortaar.bugger.test.TestResults;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * Utility to make in-game debugging easier.
 */
public class Bugger {
    public static Supplier<Boolean> enabler = () -> false;
    public static boolean RunningTests = false;

    private static Collection<Supplier<BuggerTests>> tests = Collections.synchronizedCollection(new ArrayList<>());

    public static boolean isEnabled() {
        return enabler.get();
    }

    public static void addTests(Supplier<BuggerTests> testsSupplier) {
        tests.add(testsSupplier);
    }

    public static void runTests(class_3222 player, Consumer<class_2561> reporter) {
        if (RunningTests) {
            reporter.accept(class_2561.method_43470("Tests are already running.").method_27692(class_124.field_1061));
            return;
        }

        RunningTests = true;
        BuggerTests allTests = new BuggerTests();
        for (Supplier<BuggerTests> testsSupplier : tests) {
            allTests.addFrom(testsSupplier.get());
        }

        TestResults results = allTests.run(player, count -> reporter.accept(class_2561.method_43470("Running " + count + " bugger tests.")));

        reporter.accept(class_2561.method_43470("Bugger tests finished:"));

        if (results.failed().isEmpty()) {
            reporter.accept(class_2561.method_43470("All tests are passed!")
                  .method_27692(class_124.field_1060));
        } else {
            reporter.accept(class_2561.method_43470("Passed: " + results.passed().size() + "\n"));
            reporter.accept(class_2561.method_43470("Failed: " + results.failed().size() + ":")
                  .method_27692(class_124.field_1061));

            results.failed().forEach(failedTest -> {
                reporter.accept(class_2561.method_43470(" " + failedTest.name() + ": " + failedTest.error())
                      .method_27692(class_124.field_1061));
            });
        }
        RunningTests = false;
    }
}