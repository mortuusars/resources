package io.github.mortuusars.mortaar.bugger.test;

import com.mojang.serialization.DataResult;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_3222;

public record Test(String name, Function<class_3222, DataResult<Boolean>> function) {
    public static Function<class_3222, DataResult<Boolean>> isTrue(Function<class_3222, Boolean> function) {
        return player -> function.apply(player)
              ? DataResult.success(true)
              : DataResult.error(() -> "Expected 'true', was 'false'.");
    }

    public static Function<class_3222, DataResult<Boolean>> isFalse(Function<class_3222, Boolean> function) {
        return player -> !function.apply(player)
              ? DataResult.success(true)
              : DataResult.error(() -> "Expected 'false', was 'true'.");
    }

    public static Function<class_3222, DataResult<Boolean>> equals(Object expected, Function<class_3222, Object> function) {
        return player -> {
            Object actual = function.apply(player);
            return actual.equals(expected)
                  ? DataResult.success(true)
                  : DataResult.error(() -> "Expected '" + expected + "', got '" + actual + "'.");
        };
    }

    public static Function<class_3222, DataResult<Boolean>> notEquals(Object notExpected, Function<class_3222, Object> function) {
        return player -> {
            Object actual = function.apply(player);
            return actual.equals(notExpected)
                  ? DataResult.success(true)
                  : DataResult.error(() -> "Expected different from '" + notExpected + "', got equal '" + actual + "'.");
        };
    }

    public static Function<class_3222, DataResult<Boolean>> throwsException(Class<? extends Exception> exceptionClass, Consumer<class_3222> function) {
        return player -> {
            try {
                function.accept(player);
                return DataResult.error(() -> "Expected thrown exception of '"+ exceptionClass.getName() + "', but no exception was thrown.");
            } catch (Exception e) {
                if (exceptionClass.isInstance(e)) {
                    return DataResult.success(true);
                }
                return DataResult.error(() -> "Expected thrown exception of '"+ exceptionClass.getName() + "', but got '" + e.getClass().getName() + "' instead.");
            }
        };
    }
}
