package io.github.mortuusars.mortaar.bugger.data;

import com.mojang.serialization.Codec;
import io.github.mortuusars.mortaar.client.Minecrft;
import java.util.Optional;
import java.util.function.BiConsumer;
import net.minecraft.class_1297;
import net.minecraft.class_2960;

public class OptionalEntityData<T> extends PairData<Integer, Optional<T>> {
    protected BiConsumer<class_1297, Optional<T>> handler = (entity, data) -> {
    };

    public OptionalEntityData(class_2960 id, Codec<T> codec) {
        super(id, Codec.INT.fieldOf("id"), codec.optionalFieldOf("data"));
    }

    public OptionalEntityData<T> handle(BiConsumer<class_1297, Optional<T>> handler) {
        this.handler = handler;
        return this;
    }

    @Override
    public void handle(Integer id, Optional<T> data) {
        if (Minecrft.level().method_8469(id) instanceof class_1297 entity) {
            handler.accept(entity, data);
        }
    }
}
