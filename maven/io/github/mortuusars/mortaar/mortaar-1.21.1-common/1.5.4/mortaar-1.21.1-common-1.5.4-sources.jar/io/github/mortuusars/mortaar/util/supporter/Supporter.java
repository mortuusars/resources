package io.github.mortuusars.mortaar.util.supporter;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_156;
import net.minecraft.class_4844;

public record Supporter(String name, UUID uuid, boolean active) {
    public static final Codec<Supporter> CODEC = RecordCodecBuilder.create(i -> i.group(
          Codec.STRING.fieldOf("name").forGetter(Supporter::name),
          class_4844.field_41525.fieldOf("uuid").forGetter(Supporter::uuid),
          Codec.BOOL.optionalFieldOf("active", false).forGetter(Supporter::active)
    ).apply(i, Supporter::new));

    public static final Codec<List<Supporter>> LIST_CODEC = Supporter.CODEC.listOf();

    public boolean matches(UUID uuid) {
        if (uuid.equals(class_156.field_25140)) return false;
        return uuid().equals(uuid);
    }
}
