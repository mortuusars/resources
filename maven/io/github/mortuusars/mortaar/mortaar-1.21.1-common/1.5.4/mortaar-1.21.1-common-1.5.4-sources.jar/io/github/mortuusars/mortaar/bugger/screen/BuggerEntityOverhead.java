package io.github.mortuusars.mortaar.bugger.screen;

import io.github.mortuusars.mortaar.client.Minecrft;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5250;
import net.minecraft.class_898;
import net.minecraft.class_9064;

public class BuggerEntityOverhead {
    private static final ArrayList<class_2561> LINES = new ArrayList<>();
    private static final ArrayList<EntityOverheadDisplay> DATA = new ArrayList<>();

    public static void addData(EntityOverheadDisplay data) {
        DATA.add(data);
    }

    public static <T extends class_1297> void onRenderEntity(class_898 dispatcher, T entity, float partialTick,
                                                         class_4587 poseStack, class_4597 bufferSource, int packedLight) {
        if (!BuggerScreen.active()) return;
        if (dispatcher.method_23168(entity) > 4096.0) return;

        @Nullable class_243 vec3 = entity.method_56072().method_55675(class_9064.field_47745, 0, entity.method_5705(partialTick));
        if (vec3 == null) return;

        List<class_2561> lines = getOverheadEntityInfoLines(entity);
        if (lines.isEmpty()) return;

        poseStack.method_22903();
        poseStack.method_22904(vec3.field_1352, vec3.field_1351 + 0.5, vec3.field_1350);
        poseStack.method_22907(dispatcher.method_24197());
        poseStack.method_22905(0.015F, -0.015F, 0.015F);
        Matrix4f matrix4f = poseStack.method_23760().method_23761();
        float opacity = class_310.method_1551().field_1690.method_19343(0.25F);
        int backgroundColor = (int) (opacity * 255.0F) << 24;
        class_327 font = Minecrft.get().field_1772;

        float y = -5 - lines.size() * (font.field_2000 + 1);
        for (class_2561 text : lines) {
            float x = (float) (-font.method_27525(text) / 2);
            font.method_30882(text, x, y, 0x20FFFFFF, false, matrix4f,
                  bufferSource, class_327.class_6415.field_33994, backgroundColor, packedLight);
            font.method_30882(text, x, y, -1, false, matrix4f, bufferSource, class_327.class_6415.field_33993, 0, packedLight);
            y += font.field_2000 + 1;
        }

        poseStack.method_22909();
    }

    private static List<class_2561> getOverheadEntityInfoLines(class_1297 entity) {
        LINES.clear();
        DATA.forEach(data -> data.addLines(entity, LINES));
        return LINES;
    }

    public interface EntityOverheadDisplay {
        void addLines(class_1297 entity, ArrayList<class_2561> lines);

        default class_5250 line(String text) {
            return class_2561.method_43470(text);
        }
    }
}
