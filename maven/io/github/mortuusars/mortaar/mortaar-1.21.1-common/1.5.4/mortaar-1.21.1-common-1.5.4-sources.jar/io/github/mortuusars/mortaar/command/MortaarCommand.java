package io.github.mortuusars.mortaar.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.mortuusars.mortaar.Config;
import io.github.mortuusars.mortaar.network.Packets;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

public class MortaarCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 context) {
        dispatcher.register(class_2170.method_9247("mortaar")
              .requires((stack) -> stack.method_9259(3))
              .then(class_2170.method_9247("debug")
                    .executes(MortaarCommand::toggleDebugMode)
                    /*.then(Commands.literal("test")
                          .executes(MortaarCommand::test))*/));
    }

    private static int toggleDebugMode(CommandContext<class_2168> context) {
        boolean newValue = !Config.Server.DEBUG_MODE.get();
        Config.Server.DEBUG_MODE.set(newValue);
        Config.Server.DEBUG_MODE.save();
        context.getSource().method_9226(() -> class_2561.method_43470("Debug mode: " + (newValue ? "Enabled" : "Disabled")).method_27692(class_124.field_1080), true);
        return 0;
    }

    private static int test(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_3222 player = context.getSource().method_9207();
        return 0;
    }
}
