package io.github.mortuusars.mortaar.serialization;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import net.minecraft.class_1856;
import net.minecraft.class_2371;
import net.minecraft.class_3956;

public interface Codecs {
    Codec<Integer> HEX_COLOR = Codec.STRING.comapFlatMap(
          hex -> {
              try {
                  int color = (int) Long.parseLong(hex.replace("#", ""), 16);
                  return DataResult.success(color);
              } catch (NumberFormatException e) {
                  return DataResult.error(() -> "Invalid color value: " + hex);
              }
          },
          color -> "#" + String.format("%08X", color));

    Codec<Float> NON_NEGATIVE_FLOAT = Codec.FLOAT
          .validate(value -> value.compareTo(0.0f) >= 0.0f && value.compareTo(1.0f) <= 0
                ? DataResult.success(value)
                : DataResult.error(() -> "Value must be within 0.0 to 1.0 range."));

    static Codec<class_2371<class_1856>> recipeIngredients(int size, class_3956<?> type) {
        return class_1856.field_46096
              .listOf()
              .flatXmap(
                    list -> {
                        class_1856[] ingredients = list.stream().filter(ingredient -> !ingredient.method_8103()).toArray(class_1856[]::new);
                        if (ingredients.length == 0) {
                            return DataResult.error(() -> "No ingredients for " + type.toString() + " recipe");
                        } else {
                            return ingredients.length > size
                                  ? DataResult.error(() -> "Too many ingredients for " + type.toString() + " recipe")
                                  : DataResult.success(class_2371.method_10212(class_1856.field_9017, ingredients));
                        }
                    },
                    DataResult::success
              );
    }
}
