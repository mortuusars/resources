package io.github.mortuusars.mortaar.bugger.network;

import io.github.mortuusars.mortaar.Mortaar;
import io.github.mortuusars.mortaar.bugger.BuggerData;
import io.github.mortuusars.mortaar.network.packet.Packet;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2598;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record ClientboundBuggerDataPacket(class_2960 id, class_2487 data) implements Packet {
    public static final class_2960 ID = Mortaar.resource("bugger_data");
    public static final class_9154<ClientboundBuggerDataPacket> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, ClientboundBuggerDataPacket> STREAM_CODEC = class_9139.method_56435(
          class_2960.field_48267, ClientboundBuggerDataPacket::id,
          class_9135.field_48556, ClientboundBuggerDataPacket::data,
          ClientboundBuggerDataPacket::new
    );

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    @Override
    public boolean handle(class_2598 direction, class_1657 player) {
        BuggerData.receive(id, data, player.method_56673());
        return true;
    }
}
