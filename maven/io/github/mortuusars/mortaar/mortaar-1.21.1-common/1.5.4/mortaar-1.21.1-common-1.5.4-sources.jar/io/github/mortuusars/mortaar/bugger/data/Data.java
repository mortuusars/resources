package io.github.mortuusars.mortaar.bugger.data;

import com.google.common.base.Preconditions;
import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import io.github.mortuusars.mortaar.bugger.Bugger;
import io.github.mortuusars.mortaar.bugger.BuggerData;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.Optional;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_5455;

public class Data<T> {
    private static final Logger LOGGER = LogUtils.getLogger();
    private final class_2960 id;
    private final Codec<T> codec;

    public Data(class_2960 id, Codec<T> codec) {
        @Nullable Data<?> definition = BuggerData.DEFINITIONS.get(id);
        Preconditions.checkArgument(definition == null || definition.codec().equals(codec),
              "Duplicate definition detected: '" + id + "'.");
        BuggerData.DEFINITIONS.put(id, this);
        this.id = id;
        this.codec = codec;
    }

    public class_2960 id() {
        return id;
    }

    public Codec<T> codec() {
        return codec;
    }

    public Optional<T> get() {
        return BuggerData.get(id);
    }

    public void send(@Nullable T value) {
        if (!Bugger.isEnabled()) return;
        BuggerData.send(id, registryAccess -> encode(value, registryAccess));
    }

    public T apply(T oldValue, T newValue) {
        return newValue;
    }

    public void handle(T value) {
    }

    // --

    public @Nullable class_2520 encode(@Nullable T value, class_5455 registryAccess) {
        if (value == null) return null;
        return codec().encodeStart(registryAccess.method_57093(class_2509.field_11560), value)
              .ifError(e -> LOGGER.error("Cannot encode '{}' bugger data: '{}'. Value: '{}'", id, e.message(), value))
              .result()
              .orElse(null);
    }

    public @Nullable T decode(class_2520 tag, class_5455 registryAccess) {
        try {
            return codec().decode(registryAccess.method_57093(class_2509.field_11560), tag)
                  .ifError(e -> LOGGER.error("Cannot decode '{}' bugger data: '{}'. Tag: '{}'", id, e.message(), tag))
                  .result()
                  .map(Pair::getFirst)
                  .orElse(null);
        } catch (Exception e) {
            LOGGER.error("Cannot decode '{}' bugger data: '{}'. Tag: '{}'", id, e.getMessage(), tag);
            return null;
        }
    }
}
