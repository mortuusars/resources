package io.github.mortuusars.mortaar.bugger.data;

import com.mojang.serialization.Codec;
import io.github.mortuusars.mortaar.client.Minecrft;
import java.util.function.BiConsumer;
import net.minecraft.class_1297;
import net.minecraft.class_2960;

public class EntityData<T> extends PairData<Integer, T> {
    protected BiConsumer<class_1297, T> handler = (entity, data) -> {
    };

    public EntityData(class_2960 id, Codec<T> codec) {
        super(id, Codec.INT.fieldOf("id"), codec.fieldOf("data"));
    }

    public EntityData<T> handle(BiConsumer<class_1297, T> handler) {
        this.handler = handler;
        return this;
    }

    @Override
    public void handle(Integer id, T data) {
        if (Minecrft.level().method_8469(id) instanceof class_1297 entity) {
            handler.accept(entity, data);
        }
    }
}
