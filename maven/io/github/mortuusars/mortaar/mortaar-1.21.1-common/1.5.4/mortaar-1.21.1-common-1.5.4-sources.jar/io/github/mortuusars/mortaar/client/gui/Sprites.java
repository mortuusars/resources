package io.github.mortuusars.mortaar.client.gui;

import com.google.common.base.Preconditions;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_2960;
import net.minecraft.class_8666;

public abstract class Sprites {
    public static class_8666 normalOnly(class_2960 base) {
        return new class_8666(base, base);
    }

    public static class_8666 normalAndHighlighted(class_2960 base) {
        return new class_8666(base, base,
                class_2960.method_60655(base.method_12836(), base.method_12832() + "_highlighted"));
    }

    public static class_8666 normalAndHighlighted(class_2960 normal, class_2960 highlighted) {
        return new class_8666(normal, normal, highlighted);
    }

    public static class_8666 threeStates(class_2960 base) {
        return new class_8666(base,
                class_2960.method_60655(base.method_12836(), base.method_12832() + "_disabled"),
                class_2960.method_60655(base.method_12836(), base.method_12832() + "_highlighted"));
    }

    public static <T> Map<T, class_8666> createMap(List<T> values, Function<T, class_8666> convertFunc) {
        Preconditions.checkArgument(!values.isEmpty(), "values list must not be empty.");
        Map<T, class_8666> map = new HashMap<>();
        for (T value : values) {
            map.put(value, convertFunc.apply(value));
        }
        return map;
    }
}
