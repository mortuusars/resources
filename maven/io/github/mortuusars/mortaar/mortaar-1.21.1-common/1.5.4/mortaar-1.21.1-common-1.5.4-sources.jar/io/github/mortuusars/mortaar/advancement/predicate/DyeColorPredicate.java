package io.github.mortuusars.mortaar.advancement.predicate;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1767;

public record DyeColorPredicate(@NotNull List<class_1767> colors) {
    public static final Codec<DyeColorPredicate> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_1767.field_41600.listOf().fieldOf("colors").forGetter(DyeColorPredicate::colors))
            .apply(instance, DyeColorPredicate::new));

    public boolean matches(class_1767 color) {
        if (colors.isEmpty()) {
            return true;
        }

        return colors.stream().anyMatch(c -> c.equals(color));
    }
}
