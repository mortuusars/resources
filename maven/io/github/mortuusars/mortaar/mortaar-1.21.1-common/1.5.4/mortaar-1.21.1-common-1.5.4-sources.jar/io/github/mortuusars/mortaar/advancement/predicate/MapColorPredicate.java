package io.github.mortuusars.mortaar.advancement.predicate;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_3620;

public record MapColorPredicate(@NotNull List<class_3620> colors) {
    public static final Codec<MapColorPredicate> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                    Codec.INT.xmap(class_3620::method_38479, color -> color.field_16021).listOf().fieldOf("colors").forGetter(MapColorPredicate::colors))
            .apply(instance, MapColorPredicate::new));

    public boolean matches(@NotNull class_3620 color) {
        if (colors.isEmpty()) {
            return true;
        }

        return colors.stream().anyMatch(c -> c.equals(color));
    }
}
