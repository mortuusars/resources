package io.github.mortuusars.mortaar.util.color;

import com.mojang.serialization.Codec;
import io.github.mortuusars.mortaar.serialization.Codecs;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_3532;
import net.minecraft.class_5253;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Represents modification to the color to tint it into various shades.<br>
 * Values larger than 1.0f will brighten the channel, lower than 1.0f - darken.
 * <br><br>
 * Created primarily to make working with RenderSystem#setShaderColor easier.<br>
 * Previewing the effect in Photoshop can be done with a Channel Mixer, by setting each channel to it's corresponding percentage (r = 1.32f -> Red = 132%).
 */
public record TintColor(float r, float g, float b, float a) {
    public static final Codec<TintColor> CODEC = Codecs.HEX_COLOR.xmap(TintColor::of, TintColor::tint);
    public static final class_9139<ByteBuf, TintColor> STREAM_CODEC = class_9135.field_49675.method_56432(TintColor::of, TintColor::tint);

    /**
     * Creates a TintColor from packet color.<br>
     * #7F7F7F corresponds to r=1, g=1, b=1, a=1, ie. untinted.
     */
    public static TintColor of(int argb) {
        float a = (float) (class_5253.class_5254.method_27762(argb) - 127) / 127 + 1;
        float r = (float) (class_5253.class_5254.method_27765(argb) - 127) / 127 + 1;
        float g = (float) (class_5253.class_5254.method_27766(argb) - 127) / 127 + 1;
        float b = (float) (class_5253.class_5254.method_27767(argb) - 127) / 127 + 1;
        return new TintColor(r, g, b, a);
    }

    /**
     * Tints the neutral color.
     */
    public int tint() {
        return tint(0xFF7F7F7F);
    }

    /**
     * Tints the packed color.
     */
    public int tint(int argb) {
        int a = (int)class_3532.method_15363(class_5253.class_5254.method_27762(argb) * this.a, 0, 255);
        int r = (int)class_3532.method_15363(class_5253.class_5254.method_27765(argb) * this.r, 0, 255);
        int g = (int)class_3532.method_15363(class_5253.class_5254.method_27766(argb) * this.g, 0, 255);
        int b = (int)class_3532.method_15363(class_5253.class_5254.method_27767(argb) * this.b, 0, 255);
        return class_5253.class_5254.method_27764(a, r, g, b);
    }
}
