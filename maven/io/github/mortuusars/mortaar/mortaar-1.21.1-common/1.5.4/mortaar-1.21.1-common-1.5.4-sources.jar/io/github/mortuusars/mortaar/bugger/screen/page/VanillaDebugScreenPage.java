package io.github.mortuusars.mortaar.bugger.screen.page;

public class VanillaDebugScreenPage implements BuggerScreenPage {
    @Override
    public String getTitle() {
        return "Debug";
    }
}
