package io.github.mortuusars.mortaar.advancement.predicate;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.mortuusars.mortaar.util.color.Color;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_2096;
import net.minecraft.class_5253;

public record ColorPredicate(Optional<Integer> exact,
                             Optional<class_2096.class_2100> red,
                             Optional<class_2096.class_2100> green,
                             Optional<class_2096.class_2100> blue,
                             Optional<class_2096.class_2100> alpha,
                             Optional<class_2096.class_2099> hue,
                             Optional<class_2096.class_2099> saturation,
                             Optional<class_2096.class_2099> brightness) {
    public static final Codec<ColorPredicate> CODEC = RecordCodecBuilder.create(i -> i.group(
          Codec.INT.optionalFieldOf("exact").forGetter(ColorPredicate::exact),
          class_2096.class_2100.field_45763.optionalFieldOf("red").forGetter(ColorPredicate::red),
          class_2096.class_2100.field_45763.optionalFieldOf("green").forGetter(ColorPredicate::green),
          class_2096.class_2100.field_45763.optionalFieldOf("blue").forGetter(ColorPredicate::blue),
          class_2096.class_2100.field_45763.optionalFieldOf("alpha").forGetter(ColorPredicate::alpha),
          class_2096.class_2099.field_45762.optionalFieldOf("hue").forGetter(ColorPredicate::hue),
          class_2096.class_2099.field_45762.optionalFieldOf("saturation").forGetter(ColorPredicate::saturation),
          class_2096.class_2099.field_45762.optionalFieldOf("brightness").forGetter(ColorPredicate::brightness)
    ).apply(i, ColorPredicate::new));

    public boolean matches(int colorARGB) {
        return (exact.isEmpty() || exact.get() == colorARGB)
              && (red.isEmpty() || red.get().method_9054(class_5253.class_5254.method_27765(colorARGB)))
              && (green.isEmpty() || green.get().method_9054(class_5253.class_5254.method_27766(colorARGB)))
              && (blue.isEmpty() || blue.get().method_9054(class_5253.class_5254.method_27767(colorARGB)))
              && (alpha.isEmpty() || alpha.get().method_9054(class_5253.class_5254.method_27762(colorARGB)))
              && hsbMatches(colorARGB);
    }

    private boolean hsbMatches(int colorARGB) {
        if (hue().isEmpty() && saturation().isEmpty() && brightness().isEmpty()) {
            return true;
        }

        float[] hsb = Color.HSB.RGBtoHSB(Color.rgb(colorARGB));

        return (this.hue.isEmpty() || this.hue.get().method_9047(hsb[0]))
              && (this.saturation.isEmpty() || this.saturation.get().method_9047(hsb[1]))
              && (this.brightness.isEmpty() || this.brightness.get().method_9047(hsb[2]));
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        @Nullable Integer exact;
        @Nullable class_2096.class_2100 red;
        @Nullable class_2096.class_2100 green;
        @Nullable class_2096.class_2100 blue;
        @Nullable class_2096.class_2100 alpha;
        @Nullable class_2096.class_2099 hue;
        @Nullable class_2096.class_2099 saturation;
        @Nullable class_2096.class_2099 brightness;

        public Builder exact(@Nullable Integer exact) {
            this.exact = exact;
            return this;
        }

        public Builder red(@Nullable class_2096.class_2100 red) {
            this.red = red;
            return this;
        }

        public Builder green(@Nullable class_2096.class_2100 green) {
            this.green = green;
            return this;
        }

        public Builder blue(@Nullable class_2096.class_2100 blue) {
            this.blue = blue;
            return this;
        }

        public Builder alpha(@Nullable class_2096.class_2100 alpha) {
            this.alpha = alpha;
            return this;
        }

        public Builder hue(@Nullable class_2096.class_2099 hue) {
            this.hue = hue;
            return this;
        }

        public Builder saturation(@Nullable class_2096.class_2099 saturation) {
            this.saturation = saturation;
            return this;
        }

        public Builder brightness(@Nullable class_2096.class_2099 brightness) {
            this.brightness = brightness;
            return this;
        }

        public ColorPredicate build() {
            return new ColorPredicate(
                  Optional.ofNullable(exact),
                  Optional.ofNullable(red),
                  Optional.ofNullable(green),
                  Optional.ofNullable(blue),
                  Optional.ofNullable(alpha),
                  Optional.ofNullable(hue),
                  Optional.ofNullable(saturation),
                  Optional.ofNullable(brightness)
            );
        }
    }
}
