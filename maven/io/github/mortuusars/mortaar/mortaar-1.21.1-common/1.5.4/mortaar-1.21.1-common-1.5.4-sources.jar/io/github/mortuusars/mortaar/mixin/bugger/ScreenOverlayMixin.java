package io.github.mortuusars.mortaar.mixin.bugger;

import io.github.mortuusars.mortaar.bugger.screen.BuggerScreen;
import net.minecraft.class_332;
import net.minecraft.class_340;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_340.class)
public class ScreenOverlayMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void onRender(class_332 guiGraphics, CallbackInfo ci) {
        if (BuggerScreen.render(guiGraphics)) {
            ci.cancel();
        }
    }
}
