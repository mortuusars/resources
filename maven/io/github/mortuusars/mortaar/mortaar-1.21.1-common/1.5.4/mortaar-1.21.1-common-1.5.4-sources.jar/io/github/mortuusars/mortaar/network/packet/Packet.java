package io.github.mortuusars.mortaar.network.packet;

import io.github.mortuusars.mortaar.network.Packets;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

public interface Packet extends class_8710 {
    boolean handle(class_2598 flow, class_1657 player);

    default void sendToServer() {
        Packets.sendToServer(this);
    }

    default void sendToClient(class_3222 player) {
        Packets.sendToClient(this, player);
    }

    default void sendToAllClients() {
        Packets.sendToAllClients(this);
    }

    default void sendToOtherClients(@NotNull class_3222 except) {
        Packets.sendToOtherClients(this, except);
    }

    default void sendToClients(Predicate<class_3222> filter) {
        Packets.sendToClients(this, filter);
    }

    default void sendToPlayersNear(class_3218 level, @Nullable class_3222 excluded,
                                         class_1297 entity, double radius) {
        Packets.sendToPlayersNear(this, level, excluded, entity, radius);
    }

    default void sendToPlayersNear(@NotNull class_3218 level, @Nullable class_3222 excludedPlayer,
                                         double x, double y, double z, double radius) {
        Packets.sendToPlayersNear(this, level, excludedPlayer, x, y, z, radius);
    }
}
