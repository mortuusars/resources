package io.github.mortuusars.mortaar.bugger;

import com.mojang.logging.LogUtils;
import io.github.mortuusars.mortaar.Platform;
import io.github.mortuusars.mortaar.bugger.data.Data;
import io.github.mortuusars.mortaar.bugger.network.ClientboundBuggerDataPacket;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;

/**
 * Utility system to simplify debug data transferring from server to client.<br>
 * Data is stored only on the client, server only sends.<br>
 * Uses CompoundTag to encode/decode data, which is not ideal for sending data over network (StreamCodecs exist),
 * but it simplifies data writing and reading (and allows sending arbitrary data), which is more important than performance for debug cases.
 */
public class BuggerData {
    public static final Map<class_2960, Data<?>> DEFINITIONS = new HashMap<>();
    public static final Map<class_2960, Object> DATA = new HashMap<>();

    private static final Logger LOGGER = LogUtils.getLogger();

    public static <T> Optional<T> get(class_2960 id) {
        if (!Bugger.isEnabled()) {
            return Optional.empty();
        }

        try {
            @SuppressWarnings("unchecked")
            T value = (T) BuggerData.DATA.get(id);
            return Optional.ofNullable(value);
        } catch (ClassCastException e) {
            LOGGER.error("Stored bugger data '{}' has incorrect type: ", id, e);
            return Optional.empty();
        }
    }

    public static void send(class_2960 id, Function<class_5455, @Nullable class_2520> dataSupplier) {
        //noinspection ConstantValue
        if (!Bugger.isEnabled() || !(Platform.getCurrentServer() instanceof MinecraftServer server)) {
            return;
        }

        class_2487 tag = new class_2487();
        @Nullable class_2520 data = dataSupplier.apply(server.method_30611());
        if (data != null) tag.method_10566("data", data);
        new ClientboundBuggerDataPacket(id, tag).sendToAllClients();
    }

    public static void receive(class_2960 id, class_2487 tag, class_5455 registryAccess) {
        if (!Bugger.isEnabled()) {
            return;
        }

        Data<?> definition = Objects.requireNonNull(DEFINITIONS.get(id), "Definition '" + id + "' was not registered.");
        @Nullable Object newValue = tag.method_10545("data") ? definition.decode(tag.method_10580("data"), registryAccess) : null;

        if (newValue == null) {
            DATA.put(id, null);
        } else {
            receiveInternal(definition, id, newValue);
        }
    }

    // Glorious generics magick
    private static <T> void receiveInternal(Data<T> definition, class_2960 id, @NotNull Object newValueObj) {
        DATA.compute(id, (dataId, existingValueObj) -> {
            if (existingValueObj == null) return newValueObj;
            @SuppressWarnings("unchecked")
            T existingValue = (T) existingValueObj;
            @SuppressWarnings("unchecked")
            T newValue = (T) newValueObj;
            T appliedValue = definition.apply(existingValue, newValue);
            definition.handle(appliedValue);
            return appliedValue;
        });
    }
}
