package io.github.mortuusars.mortaar.client.gui.widget;

import com.google.common.base.Preconditions;
import io.github.mortuusars.mortaar.client.gui.Sprites;
import io.github.mortuusars.mortaar.client.gui.tooltip.Tooltips;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1060;
import net.minecraft.class_1109;
import net.minecraft.class_1144;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7919;
import net.minecraft.class_8666;

public class CycleButton<T> extends class_4185 {
    protected final List<T> values;
    protected final T startingValue;
    protected final Map<T, class_8666> spritesMap;

    protected OnCycle<T> onCycle;
    protected boolean loop = true;
    protected @Nullable class_7919 defaultTooltip;
    protected Map<T, @Nullable class_7919> tooltips = Collections.emptyMap();
    protected @Nullable class_3414 clickSound;

    protected int currentIndex;

    public CycleButton(int x, int y, int width, int height, List<T> values, @NotNull T startingValue,
                       Map<T, class_8666> spritesMap, OnCycle<T> onCycle) {
        super(x, y, width, height, class_5244.field_39003, b -> {}, field_40754);
        Preconditions.checkArgument(!values.isEmpty(), "Cannot create a CycleButton with 0 possible values.");
        this.values = values;
        this.startingValue = startingValue;
        Preconditions.checkArgument(!spritesMap.isEmpty(), "Cannot create a CycleButton with 0 sprites.");
        this.spritesMap = spritesMap;
        this.onCycle = onCycle;

        setCurrentIndex(Math.max(values.indexOf(startingValue), 0));
    }

    public CycleButton(int x, int y, int width, int height, List<T> values, @NotNull T startingValue,
                       Map<T, class_8666> spritesMap) {
        this(x, y, width, height, values, startingValue, spritesMap, (b, v) -> {});
    }

    public CycleButton(int x, int y, int width, int height, List<T> values, @NotNull T startingValue,
                       Function<T, class_8666> spritesFunc, OnCycle<T> onCycle) {
        this(x, y, width, height, values, startingValue, Sprites.createMap(values, spritesFunc), onCycle);
    }

    public CycleButton(int x, int y, int width, int height, List<T> values, @NotNull T startingValue,
                       Function<T, class_8666> spritesFunc) {
        this(x, y, width, height, values, startingValue, Sprites.createMap(values, spritesFunc), (b, v) -> {});
    }

    public CycleButton<T> setLooping(boolean loop) {
        this.loop = loop;
        return this;
    }

    public CycleButton<T> setDefaultTooltip(class_7919 tooltip) {
        this.defaultTooltip = tooltip;
        updateVisuals();
        return this;
    }

    public CycleButton<T> setTooltips(Map<T, class_7919> tooltips) {
        this.tooltips = tooltips;
        updateVisuals();
        return this;
    }

    public CycleButton<T> setTooltips(Function<T, class_2561> tooltipFunc) {
        this.tooltips = Tooltips.createMap(values, tooltipFunc);
        updateVisuals();
        return this;
    }

    public CycleButton<T> setClickSound(class_3414 soundEvent) {
        this.clickSound = soundEvent;
        return this;
    }

    public CycleButton<T> onCycle(OnCycle<T> onCycle) {
        this.onCycle = onCycle;
        return this;
    }

    public CycleButton<T> onCycle(Consumer<T> onCycle) {
        this.onCycle = (button, newValue) -> onCycle.accept(newValue);
        return this;
    }

    public T getCurrentValue() {
        return values.get(class_3532.method_15340(currentIndex, 0, values.size() - 1));
    }

    public void setCurrentValue(T value) {
        setCurrentIndex(class_3532.method_15340(values.indexOf(value), 0, values.size() - 1));
    }

    public void setCurrentIndex(int index) {
        this.currentIndex = index;
        updateVisuals();
    }

    public void cycle(boolean reverse) {
        int value = currentIndex;
        value += reverse ? -1 : 1;
        if (value < 0)
            value = loop ? values.size() - 1 : 0;
        else if (value >= values.size())
            value = loop ? 0 : values.size() - 1;

        if (currentIndex != value) {
            currentIndex = value;
            onCycle();
        }
    }

    protected void onCycle() {
        updateVisuals();
        onCycle.onCycle(this, getCurrentValue());
    }

    private void updateVisuals() {
        @Nullable class_7919 tooltip = tooltips.getOrDefault(getCurrentValue(), defaultTooltip);
        if (tooltip != null) {
            method_47400(tooltip);
        }
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        @Nullable class_8666 sprites = spritesMap.get(getCurrentValue());
        class_2960 spriteLocation = sprites != null
                ? sprites.method_52729(method_37303(), method_25367())
                : class_1060.field_5285;
        guiGraphics.method_52706(spriteLocation, method_46426(), method_46427(), method_25368(), method_25364());
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if ((button == 0 || button == 1) && method_25361(mouseX, mouseY)) {
            cycle(button == 1);
            method_25354(class_310.method_1551().method_1483());
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        cycle(scrollY < 0d);
        method_25354(class_310.method_1551().method_1483());
        return true;
    }

    @Override
    public boolean method_25404(int pKeyCode, int pScanCode, int pModifiers) {
        boolean pressed = super.method_25404(pKeyCode, pScanCode, pModifiers);

        if (pressed)
            cycle(class_437.method_25442());

        return pressed;
    }

    @Override
    public void method_25354(class_1144 handler) {
        if (clickSound != null) {
            handler.method_4873(class_1109.method_4758(clickSound, 1.0F));
        }
    }

    public interface OnCycle<T> {
        void onCycle(CycleButton<T> button, T newValue);
    }
}
