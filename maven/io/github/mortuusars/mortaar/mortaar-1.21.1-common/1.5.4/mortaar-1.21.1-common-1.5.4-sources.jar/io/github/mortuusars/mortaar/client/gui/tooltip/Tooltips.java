package io.github.mortuusars.mortaar.client.gui.tooltip;

import com.google.common.base.Preconditions;
import com.mojang.logging.LogUtils;
import io.github.mortuusars.mortaar.client.gui.tooltip.component.CompositeTooltipComponent;
import io.github.mortuusars.mortaar.world.item.tooltip.CompositeTooltip;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import net.minecraft.class_7919;

public abstract class Tooltips {
    private static final Logger LOGGER = LogUtils.getLogger();

    private static final Map<Class<? extends class_5632>, Function<class_5632, class_5684>> constructors = new ConcurrentHashMap<>();

    @SuppressWarnings("unchecked")
    public static <T extends class_5632> void register(Class<T> componentClass, Function<T, class_5684> constructor) {
        if (constructors.containsKey(componentClass)) {
            LOGGER.warn("{} already has a tooltip constructor registered. New constructor will replace the old one.", componentClass.getName());
        }
        constructors.put(componentClass, (Function<class_5632, class_5684>)constructor);
    }

    public static @Nullable class_5684 create(class_5632 component) {
        if (component instanceof CompositeTooltip(List<class_5632> components)) {
            return new CompositeTooltipComponent(components.stream().map(class_5684::method_32663).toList());
        }

        @Nullable Function<class_5632, class_5684> constructor = constructors.get(component.getClass());
        if (constructor != null) {
            return constructor.apply(component);
        }

        return null;
    }

    // --

    public static <T> Map<T, class_7919> createMap(List<T> values, Function<T, class_2561> convertFunc) {
        Preconditions.checkArgument(!values.isEmpty(), "values list must not be empty.");
        Map<T, class_7919> map = new HashMap<>();
        for (T value : values) {
            map.put(value, class_7919.method_47407(convertFunc.apply(value)));
        }
        return map;
    }
}
