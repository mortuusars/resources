package io.github.mortuusars.mortaar.bugger.screen.page;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import io.github.mortuusars.mortaar.util.JsonSyntaxHighlighter;
import io.github.mortuusars.mortaar.client.Minecrft;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_746;
import net.minecraft.class_7923;

public class DataScreenPage implements BuggerScreenPage {
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    @Override
    public String getTitle() {
        return "Data";
    }

    @Override
    public List<String> getLeftLines() {
        @Nullable class_239 hitResult = Minecrft.get().field_1765;
        ArrayList<String> lines = new ArrayList<>();

        if (hitResult instanceof class_3965 blockHitResult && blockHitResult.method_17783() != class_239.class_240.field_1333) {
            class_2338 pos = blockHitResult.method_17777();
            class_2248 block = Minecrft.level().method_8320(pos).method_26204();

            lines.add(block.method_9518().getString());
            lines.add(class_7923.field_41175.method_10221(block).toString());
            lines.add("");

            if (Minecrft.level().method_8321(pos) instanceof class_2586 be) {
                class_2487 nbt = be.method_38242(Minecrft.level().method_30349());
                lines.addAll(highlightAndSplitJson(class_2487.field_25128.encodeStart(JsonOps.INSTANCE, nbt)));
            }

            return lines;
        } else if (hitResult instanceof class_3966 entityHitResult) {
            class_1297 entity = entityHitResult.method_17782();

            lines.add(entity.method_5477().getString());
            lines.add(class_7923.field_41177.method_10221(entity.method_5864()).toString());
            lines.add("");

            class_2487 nbt = class_156.method_654(new class_2487(), entity::method_5662);
            lines.addAll(highlightAndSplitJson(class_2487.field_25128.encodeStart(JsonOps.INSTANCE, nbt)));

            return lines;
        } else {
            class_1799 itemInHand = getItemInHand();

            lines.add(itemInHand.method_7964().getString());
            lines.add(class_7923.field_41178.method_10221(itemInHand.method_7909()).toString());
            lines.add("");

            DataResult<JsonElement> encodeResult = class_1799.field_24671.encodeStart(Minecrft.registryAccess()
                  .method_57093(JsonOps.INSTANCE), itemInHand);
            lines.addAll(highlightAndSplitJson(encodeResult));

            return lines;
        }
    }

    protected List<String> highlightAndSplitJson(DataResult<JsonElement> encodingResult) {
        JsonElement json = encodingResult.result().orElse(new JsonObject());
        String jsonString = JsonSyntaxHighlighter.highlight(GSON.toJson(json));
        return Arrays.asList(jsonString.split("\n"));
    }

    @Override
    public List<String> getRightLines() {
        @Nullable class_239 hitResult = Minecrft.get().field_1765;
        if (hitResult instanceof class_3965 blockHitResult && blockHitResult.method_17783() != class_239.class_240.field_1333) {
            return Minecrft.level().method_8320(blockHitResult.method_17777()).method_40144().map(key -> "#" + key.comp_327()).toList();
        } else if (hitResult instanceof class_3966 entityHitResult) {
            //noinspection deprecation
            return entityHitResult.method_17782().method_5864().method_40124().method_40228().map(key -> "#" + key.comp_327()).toList();
        } else {
            return getItemInHand().method_40133().map(key -> "#" + key.comp_327()).toList();
        }
    }

    private class_1799 getItemInHand() {
        @Nullable class_746 player = class_310.method_1551().field_1724;
        if (player == null) return class_1799.field_8037;

        class_1799 mainHandItem = player.method_5998(class_1268.field_5808);
        return mainHandItem.method_7960() ? player.method_5998(class_1268.field_5810) : mainHandItem;
    }
}
