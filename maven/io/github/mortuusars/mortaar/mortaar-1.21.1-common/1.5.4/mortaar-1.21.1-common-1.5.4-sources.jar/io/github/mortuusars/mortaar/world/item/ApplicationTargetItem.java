package io.github.mortuusars.mortaar.world.item;

import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public interface ApplicationTargetItem {
    /**
     * @deprecated Use fuller version {@link #shouldRenderSlotTooltipWhileCarrying(class_1657, class_1703, class_1735, class_1799)} instead.
     */
    @Deprecated(since = "1.2.2", forRemoval = true)
    default boolean shouldRenderSlotTooltipWhileCarrying(class_1937 level, class_1799 carried, class_1799 hovered) {
        return false;
    }

    default boolean shouldRenderSlotTooltipWhileCarrying(class_1657 player, class_1703 menu, class_1735 slot, class_1799 carried) {
        return false;
    }
}
