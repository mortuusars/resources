package io.github.mortuusars.mortaar;

import dev.architectury.injectables.annotations.ExpectPlatform;
import io.github.mortuusars.mortaar.network.packet.Packet;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public class Register {
    /**
     * Gets or creates mod-specific registrar, that allows for easy registering of blocks, items, block-entities, menu-types, etc.,
     * without needing to handle platform specific code,
     * @return First call per modId will create the registrar, subsequent calls will return the same instance.
     */
    @ExpectPlatform
    public static Registrar registrar(String modId) {
        throw new AssertionError();
    }

    // --

    /**
     * Registers serverbound (play to server) packet.
     */
    @ExpectPlatform
    public static void serverboundPacket(class_8710.class_9154<? extends Packet> type, class_9139<? extends class_2540, ? extends Packet> codec) {
        throw new AssertionError();
    }

    /**
     * Registers clientbound (play to client) packet.
     */
    @ExpectPlatform
    public static void clientboundPacket(class_8710.class_9154<? extends Packet> type, class_9139<? extends class_2540, ? extends Packet> codec) {
        throw new AssertionError();
    }

    /**
     * Registers bidirectional (play to server and play to client) packet.
     */
    @ExpectPlatform
    public static void bidirectionalPacket(class_8710.class_9154<? extends Packet> type, class_9139<? extends class_2540, ? extends Packet> codec) {
        throw new AssertionError();
    }
}
