package io.github.mortuusars.mortaar.network.packet;

import io.github.mortuusars.mortaar.Mortaar;
import net.minecraft.class_1657;
import net.minecraft.class_2598;
import net.minecraft.class_3222;

public interface ServerboundPacket extends Packet {
    boolean handle(class_2598 flow, class_3222 player);

    @Override
    default boolean handle(class_2598 flow, class_1657 player) {
        if (!(player instanceof class_3222 serverPlayer)) {
            Mortaar.LOGGER.error("Cannot handle '{}' packet. Player is not a ServerPlayer, but {}", method_56479().comp_2242(), player.getClass().getName());
            return false;
        }
        return handle(flow, serverPlayer);
    }
}
