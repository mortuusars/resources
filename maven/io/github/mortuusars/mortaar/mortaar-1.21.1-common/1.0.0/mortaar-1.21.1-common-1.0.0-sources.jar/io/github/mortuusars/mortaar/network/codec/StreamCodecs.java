package io.github.mortuusars.mortaar.network.codec;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_3965;
import net.minecraft.class_7995;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class StreamCodecs {
    public static final class_9139<ByteBuf, class_243> VEC3 = class_9139.method_56437(
          (buf, vec) -> {
              buf.writeDouble(vec.field_1352);
              buf.writeDouble(vec.field_1351);
              buf.writeDouble(vec.field_1350);
          },
          buf -> new class_243(
                buf.readDouble(),
                buf.readDouble(),
                buf.readDouble()
          )
    );

    public static final class_9139<ByteBuf, class_1268> INTERACTION_HAND = class_9135.method_56375(
          class_7995.method_47914(Enum::ordinal, class_1268.values(), class_7995.class_7996.field_41665), Enum::ordinal);

    public static final class_9139<class_2540, class_3965> BLOCK_HIT_RESULT = class_9139.method_56905(
          VEC3, class_3965::method_17784,
          class_2350.field_48450, class_3965::method_17780,
          class_2338.field_48404, class_3965::method_17777,
          class_9135.field_48547, class_3965::method_17781,
          class_3965::new
    );
}
