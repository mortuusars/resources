package io.github.mortuusars.mortaar.world.item;

import net.minecraft.class_1799;
import net.minecraft.class_1937;

public interface ApplicatorItem {
    default boolean shouldRenderSlotTooltipWhileCarrying(class_1937 level, class_1799 carried, class_1799 hovered) {
        return false;
    }
}
