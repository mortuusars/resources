package io.github.mortuusars.mortaar;

public class MortaarClient {
    public static void init() {
    }
}
