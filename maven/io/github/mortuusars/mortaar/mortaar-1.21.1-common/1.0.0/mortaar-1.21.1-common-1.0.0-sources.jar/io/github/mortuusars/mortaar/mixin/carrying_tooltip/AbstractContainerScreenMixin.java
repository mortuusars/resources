package io.github.mortuusars.mortaar.mixin.carrying_tooltip;

import io.github.mortuusars.mortaar.client.Minecrft;
import io.github.mortuusars.mortaar.world.item.ApplicationTargetItem;
import io.github.mortuusars.mortaar.world.item.ApplicatorItem;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;

@Mixin(class_465.class)
public abstract class AbstractContainerScreenMixin<T extends class_1703> extends class_437 {
    protected AbstractContainerScreenMixin(class_2561 title) {
        super(title);
    }

    @Shadow
    public abstract T getMenu();

    @Shadow
    @Nullable
    protected class_1735 hoveredSlot;

    @Shadow
    protected abstract List<class_2561> getTooltipFromContainerItem(class_1799 stack);

    /**
     * Because tooltip is not rendered when carrying an item, we render it manually when {@link ApplicatorItem} or {@link ApplicationTargetItem} needs it.<br>
     * This helps to choose/see the item you're changing.
     */
    @Inject(method = "renderTooltip", at = @At("HEAD"), cancellable = true)
    private void onRenderTooltip(class_332 guiGraphics, int x, int y, CallbackInfo ci) {
        if (hoveredSlot == null || !hoveredSlot.method_7681()) {
            return;
        }

        class_1799 carried = getMenu().method_34255();
        class_1799 hovered = hoveredSlot.method_7677();

        if ((carried.method_7909() instanceof ApplicatorItem applicator
              && applicator.shouldRenderSlotTooltipWhileCarrying(Minecrft.level(), carried, hovered))
          || (hovered.method_7909() instanceof ApplicationTargetItem applicationTarget
              && applicationTarget.shouldRenderSlotTooltipWhileCarrying(Minecrft.level(), carried, hovered))) {
            guiGraphics.method_51437(field_22793, getTooltipFromContainerItem(hovered), hovered.method_32347(), x, y);
            ci.cancel();
        }
    }
}
