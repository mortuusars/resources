package io.github.mortuusars.mortaar.resources;

import io.github.mortuusars.mortaar.Platform;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;

public class ResourceReference<T> {
    private final class_5321<T> key;

    protected ResourceReference(class_5321<T> key) {
        this.key = key;
    }

    public static <T> ResourceReference<T> create(class_5321<? extends class_2378<T>> registryKey, class_2960 location) {
        return new ResourceReference<>(class_5321.method_29179(registryKey, location));
    }

    // --

    public class_6880.class_6883<T> getHolderOrThrow(class_7225.class_7874 registries) {
        return registries.method_46762(key.method_58273()).method_46747(key);
    }

    public Optional<class_6880.class_6883<T>> getHolder(class_7225.class_7874 registries) {
        return registries.method_46762(key.method_58273()).method_46746(key);
    }

    public T getOrThrow(class_7225.class_7874 registries) {
        return getHolderOrThrow(registries).comp_349();
    }

    public Optional<T> get(class_7225.class_7874 registries) {
        return getHolder(registries).map(class_6880::comp_349);
    }

    // --

    /**
     * Uses current server to access the registry. Use with caution.
     */
    public class_6880.class_6883<T> getHolderOrThrow() {
        return getHolderOrThrow(Platform.getCurrentServerOrThrow().method_30611());
    }

    /**
     * Uses current server to access the registry. Use with caution.
     */
    public Optional<class_6880.class_6883<T>> getHolder() {
        return getHolder(Platform.getCurrentServerOrThrow().method_30611());
    }

    /**
     * Uses current server to access the registry. Use with caution.
     */
    public T getOrThrow() {
        return getOrThrow(Platform.getCurrentServerOrThrow().method_30611());
    }

    /**
     * Uses current server to access the registry. Use with caution.
     */
    public Optional<T> get() {
        return get(Platform.getCurrentServerOrThrow().method_30611());
    }

    // -- ResourceKey

    public boolean isFor(class_5321<? extends class_2378<?>> registryKey) {
        return key.method_31163(registryKey);
    }

    public <E> Optional<class_5321<E>> cast(class_5321<? extends class_2378<E>> registryKey) {
        return key.method_39752(registryKey);
    }

    public class_2960 location() {
        return key.method_29177();
    }

    public class_2960 registry() {
        return key.method_41185();
    }

    public class_5321<class_2378<T>> registryKey() {
        return key.method_58273();
    }

    @Override
    public @NotNull String toString() {
        return key().toString();
    }

    public class_5321<T> key() {
        return key;
    }

    // --

    public boolean equals(class_5321<?> resourceKey) {
        return this.key.equals(resourceKey);
    }

    @Override
    public boolean equals(Object object) {
        if (object == null || getClass() != object.getClass()) return false;
        ResourceReference<?> that = (ResourceReference<?>) object;
        return Objects.equals(key, that.key);
    }

    @Override
    public int hashCode() {
        return key.hashCode();
    }
}
