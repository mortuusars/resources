package io.github.mortuusars.mortaar.resources;

import io.github.mortuusars.mortaar.Platform;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;

public class MappedResourceReference<T, O> {
    private final class_5321<T> key;
    private final Function<class_6880<T>, O> objectConstructor;

    protected MappedResourceReference(class_5321<T> key, Function<class_6880<T>, O> objectConstructor) {
        this.key = key;
        this.objectConstructor = objectConstructor;
    }

    public static <T, O> MappedResourceReference<T, O> create(class_5321<? extends class_2378<T>> registryKey,
                                                              class_2960 location, Function<class_6880<T>, O> objectConstructor) {
        return new MappedResourceReference<>(class_5321.method_29179(registryKey, location), objectConstructor);
    }

    public static <T> MappedResourceReference<T, T> create(class_5321<? extends class_2378<T>> registryKey, class_2960 location) {
        return create(registryKey, location, class_6880::comp_349);
    }

    // --

    public class_6880.class_6883<T> getHolderOrThrow(class_7225.class_7874 registries) {
        return registries.method_46762(key.method_58273()).method_46747(key);
    }

    public Optional<class_6880.class_6883<T>> getHolder(class_7225.class_7874 registries) {
        return registries.method_46762(key.method_58273()).method_46746(key);
    }

    public O getOrThrow(class_7225.class_7874 registries) {
        return objectConstructor.apply(getHolderOrThrow(registries));
    }

    public Optional<O> get(class_7225.class_7874 registries) {
        return getHolder(registries).map(objectConstructor);
    }

    // --

    /**
     * Uses current server to access the registry. Use with caution.
     */
    public class_6880.class_6883<T> getHolderOrThrow() {
        return getHolderOrThrow(Platform.getCurrentServerOrThrow().method_30611());
    }

    /**
     * Uses current server to access the registry. Use with caution.
     */
    public Optional<class_6880.class_6883<T>> getHolder() {
        return getHolder(Platform.getCurrentServerOrThrow().method_30611());
    }

    /**
     * Uses current server to access the registry. Use with caution.
     */
    public O getOrThrow() {
        return getOrThrow(Platform.getCurrentServerOrThrow().method_30611());
    }

    /**
     * Uses current server to access the registry. Use with caution.
     */
    public Optional<O> get() {
        return get(Platform.getCurrentServerOrThrow().method_30611());
    }

    // -- ResourceKey

    public boolean isFor(class_5321<? extends class_2378<?>> registryKey) {
        return key.method_31163(registryKey);
    }

    public <E> Optional<class_5321<E>> cast(class_5321<? extends class_2378<E>> registryKey) {
        return key.method_39752(registryKey);
    }

    public class_2960 location() {
        return key.method_29177();
    }

    public class_2960 registry() {
        return key.method_41185();
    }

    public class_5321<class_2378<T>> registryKey() {
        return key.method_58273();
    }

    @Override
    public @NotNull String toString() {
        return key().toString();
    }

    public class_5321<T> key() {
        return key;
    }

    public Function<class_6880<T>, O> toObject() {
        return objectConstructor;
    }

    // --

    public boolean equals(class_5321<?> resourceKey) {
        return this.key.equals(resourceKey);
    }

    @Override
    public boolean equals(Object object) {
        if (object == null || getClass() != object.getClass()) return false;
        MappedResourceReference<?, ?> that = (MappedResourceReference<?, ?>) object;
        return Objects.equals(key, that.key) && Objects.equals(objectConstructor, that.objectConstructor);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key, objectConstructor);
    }
}
