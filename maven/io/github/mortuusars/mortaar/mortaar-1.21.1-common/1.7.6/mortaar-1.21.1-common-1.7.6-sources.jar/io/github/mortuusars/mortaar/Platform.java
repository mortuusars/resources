package io.github.mortuusars.mortaar;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_638;
import net.minecraft.class_9129;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import java.util.*;
import java.util.function.Consumer;

public class Platform {
    @ExpectPlatform
    public static boolean isInDevEnv() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isClient() {
        throw new AssertionError();
    }

    public static boolean isDedicatedServer() {
        return !isClient();
    }

    @ExpectPlatform
    public static boolean isModLoaded(String modId) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static boolean isModLoading(String modId) {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static Path getGameDirectory() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static Path getConfigDirectory() {
        throw new AssertionError();
    }

    @ExpectPlatform
    public static @Nullable MinecraftServer getCurrentServer() {
        throw new AssertionError();
    }

    public static Optional<MinecraftServer> getServer() {
        return Optional.ofNullable(getCurrentServer());
    }

    public static @NotNull MinecraftServer getCurrentServerOrThrow() {
        return Objects.requireNonNull(getCurrentServer());
    }

    @ExpectPlatform
    public static void openMenu(class_3222 serverPlayer, class_3908 menuProvider, Consumer<class_9129> extraDataWriter) {
        throw new AssertionError();
    }

    public static class Client {
        public static final Set<class_1091> CUSTOM_MODELS = new HashSet<>();

        public static class_1091 registerCustomModel(class_2960 location) {
            class_1091 modelLocation = new class_1091(location, "standalone");
            CUSTOM_MODELS.add(modelLocation);
            return modelLocation;
        }

        @ExpectPlatform
        public static class_1087 getModel(class_1091 location) {
            throw new AssertionError();
        }

        public static class_1087 getModelWithOverrides(class_1091 location, class_1799 stack,
                                                       @Nullable class_1937 level, @Nullable class_1309 entity, int seed) {
            class_1087 model = getModel(location);
            class_638 clientLevel = level instanceof class_638 cLevel ? cLevel : null;
            return model.method_4710().method_3495(model, stack, clientLevel, entity, seed);
        }
    }
}
