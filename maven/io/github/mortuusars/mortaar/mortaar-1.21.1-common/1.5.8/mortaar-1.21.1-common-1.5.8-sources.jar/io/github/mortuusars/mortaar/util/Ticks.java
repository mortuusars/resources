package io.github.mortuusars.mortaar.util;

import net.minecraft.class_155;

public abstract class Ticks {
    public static final int PER_SECOND = class_155.field_29702;
    public static final int PER_MINUTE = class_155.field_29703;
    public static final int PER_IN_GAME_DAY = class_155.field_29704;

    public static long fromSeconds(double seconds) {
        return (long) (seconds * PER_SECOND);
    }

    public static long fromMinutes(double minutes) {
        return (long) (minutes * PER_MINUTE);
    }
}
