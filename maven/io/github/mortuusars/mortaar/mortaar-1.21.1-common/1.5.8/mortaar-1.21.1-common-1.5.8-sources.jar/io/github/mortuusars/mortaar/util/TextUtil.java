package io.github.mortuusars.mortaar.util;

import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_327;
import net.minecraft.class_5225;
import net.minecraft.class_5348;

public class TextUtil {
    public static class_5348 truncateStringToWidth(class_327 font, class_5348 text, int width) {
        if (font.method_27525(text) <= width) {
            return text;
        }

        int ellipsisWidth = font.method_1727("...");
        class_5225 splitter = font.method_27527();

        class_5348 truncatedText = font.method_1714(text, width - ellipsisWidth);

        class_2583 style = splitter.method_27489(text, width - ellipsisWidth);
        if (style == null) {
            style = class_2583.field_24360;
        }

        return class_5348.method_29433(truncatedText, class_2561.method_43470("...").method_10862(style));
    }
}
